﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

// Token: 0x020000FC RID: 252
public partial class FindForm : Form
{
	// Token: 0x06000CF8 RID: 3320 RVA: 0x0000B556 File Offset: 0x00009756
	public FindForm(FastColoredTextBox fastColoredTextBox_1)
	{
		this.InitializeComponent();
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x0000B572 File Offset: 0x00009772
	private void btClose_Click(object sender, EventArgs e)
	{
		base.Close();
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x0000B57A File Offset: 0x0000977A
	private void btFindNext_Click(object sender, EventArgs e)
	{
		this.vmethod_0(this.tbFind.Text);
	}

	// Token: 0x06000CFB RID: 3323 RVA: 0x0004E064 File Offset: 0x0004C264
	public virtual void vmethod_0(string string_0)
	{
		try
		{
			RegexOptions regexOptions_ = this.cbMatchCase.Checked ? RegexOptions.None : RegexOptions.IgnoreCase;
			if (!this.cbRegex.Checked)
			{
				string_0 = Regex.Escape(string_0);
			}
			if (this.cbWholeWord.Checked)
			{
				string_0 = "\\b" + string_0 + "\\b";
			}
			GClass86 gclass = this.fastColoredTextBox_0.GClass86_5.method_6();
			gclass.method_40();
			if (this.bool_0)
			{
				this.gstruct2_0 = gclass.GStruct2_0;
				this.bool_0 = false;
			}
			gclass.GStruct2_0 = gclass.GStruct2_1;
			if (GStruct2.smethod_5(gclass.GStruct2_0, this.gstruct2_0))
			{
				gclass.GStruct2_1 = new GStruct2(this.fastColoredTextBox_0.method_23(this.fastColoredTextBox_0.Int32_14 - 1), this.fastColoredTextBox_0.Int32_14 - 1);
			}
			else
			{
				gclass.GStruct2_1 = this.gstruct2_0;
			}
			using (IEnumerator<GClass86> enumerator = gclass.method_30(string_0, regexOptions_).GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					GClass86 gclass86_ = enumerator.Current;
					this.fastColoredTextBox_0.GClass86_5 = gclass86_;
					this.fastColoredTextBox_0.method_51();
					this.fastColoredTextBox_0.method_4();
					return;
				}
			}
			if (GStruct2.smethod_5(gclass.GStruct2_0, this.gstruct2_0) && GStruct2.smethod_4(this.gstruct2_0, GStruct2.GStruct2_0))
			{
				this.fastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
				this.vmethod_0(string_0);
			}
			else
			{
				MessageBox.Show("Not found");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	// Token: 0x06000CFC RID: 3324 RVA: 0x0000B58D File Offset: 0x0000978D
	private void tbFind_KeyPress(object sender, KeyPressEventArgs e)
	{
		if (e.KeyChar == '\r')
		{
			this.btFindNext.PerformClick();
			e.Handled = true;
			return;
		}
		if (e.KeyChar == '\u001b')
		{
			base.Hide();
			e.Handled = true;
			return;
		}
	}

	// Token: 0x06000CFD RID: 3325 RVA: 0x0000B5C4 File Offset: 0x000097C4
	private void FindForm_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (e.CloseReason == CloseReason.UserClosing)
		{
			e.Cancel = true;
			base.Hide();
		}
		this.fastColoredTextBox_0.Focus();
	}

	// Token: 0x06000CFE RID: 3326 RVA: 0x0000B5E8 File Offset: 0x000097E8
	protected virtual bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		if (keyData == Keys.Escape)
		{
			base.Close();
			return true;
		}
		return base.ProcessCmdKey(ref msg, keyData);
	}

	// Token: 0x06000CFF RID: 3327 RVA: 0x0000B5FF File Offset: 0x000097FF
	protected virtual void OnActivated(EventArgs e)
	{
		this.tbFind.Focus();
		this.method_0();
	}

	// Token: 0x06000D00 RID: 3328 RVA: 0x0000B613 File Offset: 0x00009813
	private void method_0()
	{
		this.bool_0 = true;
	}

	// Token: 0x06000D01 RID: 3329 RVA: 0x0000B61C File Offset: 0x0000981C
	private void cbWholeWord_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000D02 RID: 3330 RVA: 0x0000B624 File Offset: 0x00009824
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000619 RID: 1561
	private bool bool_0 = true;

	// Token: 0x0400061A RID: 1562
	private GStruct2 gstruct2_0;

	// Token: 0x0400061B RID: 1563
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x0400061C RID: 1564
	private IContainer icontainer_0;
}
