﻿using System;

namespace Update
{
	// Token: 0x02000027 RID: 39
	internal class DownloaderEventArgs : EventArgs
	{
		// Token: 0x06000101 RID: 257 RVA: 0x00002B08 File Offset: 0x00000D08
		public DownloaderEventArgs(Downloader download)
		{
			this.downloader = download;
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00002B17 File Offset: 0x00000D17
		public DownloaderEventArgs(Downloader download, bool willStart) : this(download)
		{
			this.willStart = willStart;
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000103 RID: 259 RVA: 0x00002B27 File Offset: 0x00000D27
		public Downloader Downloader
		{
			get
			{
				return this.downloader;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000104 RID: 260 RVA: 0x00002B2F File Offset: 0x00000D2F
		public bool WillStart
		{
			get
			{
				return this.willStart;
			}
		}

		// Token: 0x04000092 RID: 146
		private Downloader downloader;

		// Token: 0x04000093 RID: 147
		private bool willStart;
	}
}
