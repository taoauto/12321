﻿using System;

namespace Update
{
	// Token: 0x02000024 RID: 36
	public enum DownloaderState : byte
	{
		// Token: 0x0400007C RID: 124
		NeedToPrepare,
		// Token: 0x0400007D RID: 125
		Preparing,
		// Token: 0x0400007E RID: 126
		WaitingForReconnect,
		// Token: 0x0400007F RID: 127
		Prepared,
		// Token: 0x04000080 RID: 128
		Working,
		// Token: 0x04000081 RID: 129
		Pausing,
		// Token: 0x04000082 RID: 130
		Paused,
		// Token: 0x04000083 RID: 131
		Ended,
		// Token: 0x04000084 RID: 132
		EndedWithError
	}
}
