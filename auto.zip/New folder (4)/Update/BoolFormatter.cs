﻿using System;

namespace Update
{
	// Token: 0x0200001A RID: 26
	internal static class BoolFormatter
	{
		// Token: 0x06000088 RID: 136 RVA: 0x00002670 File Offset: 0x00000870
		public static bool FromString(string s)
		{
			return s == "Yes";
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00002682 File Offset: 0x00000882
		public static string ToString(bool v)
		{
			if (v)
			{
				return "Yes";
			}
			return "No";
		}

		// Token: 0x04000055 RID: 85
		private const string Yes = "Yes";

		// Token: 0x04000056 RID: 86
		private const string No = "No";
	}
}
