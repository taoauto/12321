﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Update
{
	// Token: 0x02000023 RID: 35
	internal class Downloader
	{
		// Token: 0x06000097 RID: 151 RVA: 0x00004DD4 File Offset: 0x00002FD4
		private Downloader(ResourceLocation rl, ResourceLocation[] mirrors, string localFile)
		{
			this.threads = new List<Thread>();
			this.resourceLocation = rl;
			if (mirrors == null)
			{
				this.mirrors = new List<ResourceLocation>();
			}
			else
			{
				this.mirrors = new List<ResourceLocation>(mirrors);
			}
			this.localFile = localFile;
			this.extentedProperties = new Dictionary<string, object>();
			this.defaultDownloadProvider = rl.BindProtocolProviderInstance(this);
			this.segmentCalculator = new MinSizeSegmentCalculator();
			this.MirrorSelector = new SequentialMirrorSelector();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00002748 File Offset: 0x00000948
		public Downloader(ResourceLocation rl, ResourceLocation[] mirrors, string localFile, int segmentCount) : this(rl, mirrors, localFile)
		{
			this.SetState(DownloaderState.NeedToPrepare);
			this.createdDateTime = DateTime.Now;
			this.requestedSegmentCount = segmentCount;
			this.segments = new List<Segment>();
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004E58 File Offset: 0x00003058
		public Downloader(ResourceLocation rl, ResourceLocation[] mirrors, string localFile, List<Segment> segments, RemoteFileInfo remoteInfo, int requestedSegmentCount, DateTime createdDateTime) : this(rl, mirrors, localFile)
		{
			if (segments.Count > 0)
			{
				this.SetState(DownloaderState.Prepared);
			}
			else
			{
				this.SetState(DownloaderState.NeedToPrepare);
			}
			this.createdDateTime = createdDateTime;
			this.remoteFileInfo = remoteInfo;
			this.requestedSegmentCount = requestedSegmentCount;
			this.segments = segments;
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x0600009A RID: 154 RVA: 0x00004EA8 File Offset: 0x000030A8
		// (remove) Token: 0x0600009B RID: 155 RVA: 0x00004EE0 File Offset: 0x000030E0
		public event EventHandler Ending;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600009C RID: 156 RVA: 0x00004F18 File Offset: 0x00003118
		// (remove) Token: 0x0600009D RID: 157 RVA: 0x00004F50 File Offset: 0x00003150
		public event EventHandler InfoReceived;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600009E RID: 158 RVA: 0x00004F88 File Offset: 0x00003188
		// (remove) Token: 0x0600009F RID: 159 RVA: 0x00004FC0 File Offset: 0x000031C0
		public event EventHandler StateChanged;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060000A0 RID: 160 RVA: 0x00004FF8 File Offset: 0x000031F8
		// (remove) Token: 0x060000A1 RID: 161 RVA: 0x00005030 File Offset: 0x00003230
		public event EventHandler<SegmentEventArgs> RestartingSegment;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060000A2 RID: 162 RVA: 0x00005068 File Offset: 0x00003268
		// (remove) Token: 0x060000A3 RID: 163 RVA: 0x000050A0 File Offset: 0x000032A0
		public event EventHandler<SegmentEventArgs> SegmentStoped;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060000A4 RID: 164 RVA: 0x000050D8 File Offset: 0x000032D8
		// (remove) Token: 0x060000A5 RID: 165 RVA: 0x00005110 File Offset: 0x00003310
		public event EventHandler<SegmentEventArgs> SegmentStarting;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060000A6 RID: 166 RVA: 0x00005148 File Offset: 0x00003348
		// (remove) Token: 0x060000A7 RID: 167 RVA: 0x00005180 File Offset: 0x00003380
		public event EventHandler<SegmentEventArgs> SegmentStarted;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060000A8 RID: 168 RVA: 0x000051B8 File Offset: 0x000033B8
		// (remove) Token: 0x060000A9 RID: 169 RVA: 0x000051F0 File Offset: 0x000033F0
		public event EventHandler<SegmentEventArgs> SegmentFailed;

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000AA RID: 170 RVA: 0x00002778 File Offset: 0x00000978
		public Dictionary<string, object> ExtendedProperties
		{
			get
			{
				return this.extentedProperties;
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060000AB RID: 171 RVA: 0x00002780 File Offset: 0x00000980
		public ResourceLocation ResourceLocation
		{
			get
			{
				return this.resourceLocation;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000AC RID: 172 RVA: 0x00002788 File Offset: 0x00000988
		public List<ResourceLocation> Mirrors
		{
			get
			{
				return this.mirrors;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000AD RID: 173 RVA: 0x00002790 File Offset: 0x00000990
		public long FileSize
		{
			get
			{
				if (this.remoteFileInfo == null)
				{
					return 0L;
				}
				return this.remoteFileInfo.FileSize;
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000AE RID: 174 RVA: 0x000027A8 File Offset: 0x000009A8
		public DateTime CreatedDateTime
		{
			get
			{
				return this.createdDateTime;
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000AF RID: 175 RVA: 0x000027B0 File Offset: 0x000009B0
		public int RequestedSegments
		{
			get
			{
				return this.requestedSegmentCount;
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000B0 RID: 176 RVA: 0x000027B8 File Offset: 0x000009B8
		public string LocalFile
		{
			get
			{
				return this.localFile;
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000B1 RID: 177 RVA: 0x000027C0 File Offset: 0x000009C0
		public int Percent
		{
			get
			{
				return (int)this.Progress;
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000B2 RID: 178 RVA: 0x00005228 File Offset: 0x00003428
		public double Progress
		{
			get
			{
				int count = this.segments.Count;
				if (count > 0)
				{
					double num = 0.0;
					for (int i = 0; i < count; i++)
					{
						num += this.segments[i].Progress;
					}
					return num / (double)count;
				}
				return 0.0;
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000B3 RID: 179 RVA: 0x00005280 File Offset: 0x00003480
		public double Rate
		{
			get
			{
				double num = 0.0;
				for (int i = 0; i < this.segments.Count; i++)
				{
					num += this.segments[i].Rate;
				}
				return num;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000B4 RID: 180 RVA: 0x000052C4 File Offset: 0x000034C4
		public long Transfered
		{
			get
			{
				long num = 0L;
				for (int i = 0; i < this.segments.Count; i++)
				{
					num += this.segments[i].Transfered;
				}
				return num;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x00005300 File Offset: 0x00003500
		public TimeSpan Left
		{
			get
			{
				if (this.Rate == 0.0)
				{
					return TimeSpan.MaxValue;
				}
				double num = 0.0;
				for (int i = 0; i < this.segments.Count; i++)
				{
					num += (double)this.segments[i].MissingTransfer;
				}
				return TimeSpan.FromSeconds(num / this.Rate);
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000B6 RID: 182 RVA: 0x000027C9 File Offset: 0x000009C9
		public List<Segment> Segments
		{
			get
			{
				return this.segments;
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000B7 RID: 183 RVA: 0x000027D1 File Offset: 0x000009D1
		// (set) Token: 0x060000B8 RID: 184 RVA: 0x000027D9 File Offset: 0x000009D9
		public Exception LastError
		{
			get
			{
				return this.lastError;
			}
			set
			{
				this.lastError = value;
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000B9 RID: 185 RVA: 0x000027E2 File Offset: 0x000009E2
		public DownloaderState State
		{
			get
			{
				return this.state;
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00005368 File Offset: 0x00003568
		public bool IsWorking()
		{
			DownloaderState downloaderState = this.State;
			return downloaderState == DownloaderState.Preparing || downloaderState == DownloaderState.WaitingForReconnect || downloaderState == DownloaderState.Working;
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000BB RID: 187 RVA: 0x000027EA File Offset: 0x000009EA
		public RemoteFileInfo RemoteFileInfo
		{
			get
			{
				return this.remoteFileInfo;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000BC RID: 188 RVA: 0x000027F2 File Offset: 0x000009F2
		// (set) Token: 0x060000BD RID: 189 RVA: 0x000027FA File Offset: 0x000009FA
		public string StatusMessage
		{
			get
			{
				return this.statusMessage;
			}
			set
			{
				this.statusMessage = value;
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000BE RID: 190 RVA: 0x00002803 File Offset: 0x00000A03
		// (set) Token: 0x060000BF RID: 191 RVA: 0x0000280B File Offset: 0x00000A0B
		public ISegmentCalculator SegmentCalculator
		{
			get
			{
				return this.segmentCalculator;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}
				this.segmentCalculator = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x00002822 File Offset: 0x00000A22
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x0000282A File Offset: 0x00000A2A
		public IMirrorSelector MirrorSelector
		{
			get
			{
				return this.mirrorSelector;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}
				this.mirrorSelector = value;
				this.mirrorSelector.Init(this);
			}
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000284D File Offset: 0x00000A4D
		private void SetState(DownloaderState value)
		{
			this.state = value;
			this.OnStateChanged();
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000285C File Offset: 0x00000A5C
		private void StartToPrepare()
		{
			this.mainThread = new Thread(new ParameterizedThreadStart(this.StartDownloadThreadProc));
			this.mainThread.IsBackground = true;
			this.mainThread.Start(this.requestedSegmentCount);
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00002897 File Offset: 0x00000A97
		private void StartPrepared()
		{
			this.mainThread = new Thread(new ThreadStart(this.RestartDownload));
			this.mainThread.Start();
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x000028BB File Offset: 0x00000ABB
		protected virtual void OnRestartingSegment(Segment segment)
		{
			if (this.RestartingSegment != null)
			{
				this.RestartingSegment(this, new SegmentEventArgs(this, segment));
			}
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x000028D8 File Offset: 0x00000AD8
		protected virtual void OnSegmentStoped(Segment segment)
		{
			EventHandler<SegmentEventArgs> segmentStoped = this.SegmentStoped;
			if (segmentStoped == null)
			{
				return;
			}
			segmentStoped(this, new SegmentEventArgs(this, segment));
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000028F2 File Offset: 0x00000AF2
		protected virtual void OnSegmentFailed(Segment segment)
		{
			if (this.SegmentFailed != null)
			{
				this.SegmentFailed(this, new SegmentEventArgs(this, segment));
			}
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000290F File Offset: 0x00000B0F
		protected virtual void OnSegmentStarting(Segment segment)
		{
			if (this.SegmentStarting != null)
			{
				this.SegmentStarting(this, new SegmentEventArgs(this, segment));
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000292C File Offset: 0x00000B2C
		protected virtual void OnSegmentStarted(Segment segment)
		{
			if (this.SegmentStarted != null)
			{
				this.SegmentStarted(this, new SegmentEventArgs(this, segment));
			}
		}

		// Token: 0x060000CA RID: 202 RVA: 0x00002949 File Offset: 0x00000B49
		protected virtual void OnStateChanged()
		{
			if (this.StateChanged != null)
			{
				this.StateChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00002964 File Offset: 0x00000B64
		protected virtual void OnEnding()
		{
			if (this.Ending != null)
			{
				this.Ending(this, EventArgs.Empty);
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000297F File Offset: 0x00000B7F
		protected virtual void OnInfoReceived()
		{
			if (this.InfoReceived != null)
			{
				this.InfoReceived(this, EventArgs.Empty);
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000299A File Offset: 0x00000B9A
		public IDisposable LockSegments()
		{
			return new ObjectLocker(this.segments);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000538C File Offset: 0x0000358C
		public void WaitForConclusion()
		{
			if (!this.IsWorking() && this.mainThread != null && this.mainThread.IsAlive)
			{
				this.mainThread.Join(TimeSpan.FromSeconds(1.0));
			}
			while (this.IsWorking())
			{
				Thread.Sleep(100);
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x000053E4 File Offset: 0x000035E4
		public void Pause()
		{
			if (this.state != DownloaderState.Preparing)
			{
				if (this.state != DownloaderState.WaitingForReconnect)
				{
					if (this.state == DownloaderState.Working)
					{
						this.SetState(DownloaderState.Pausing);
						while (!this.AllWorkersStopped(5))
						{
						}
						List<Thread> obj = this.threads;
						lock (obj)
						{
							this.threads.Clear();
						}
						this.mainThread.Abort();
						this.mainThread = null;
						if (this.RemoteFileInfo != null && !this.RemoteFileInfo.AcceptRanges)
						{
							this.Segments[0].StartPosition = 0L;
						}
						this.SetState(DownloaderState.Paused);
					}
					return;
				}
			}
			this.Segments.Clear();
			this.mainThread.Abort();
			this.mainThread = null;
			this.SetState(DownloaderState.NeedToPrepare);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x000054B8 File Offset: 0x000036B8
		public void Start()
		{
			if (this.state == DownloaderState.NeedToPrepare)
			{
				this.SetState(DownloaderState.Preparing);
				this.StartToPrepare();
				return;
			}
			if (this.state != DownloaderState.Preparing && this.state != DownloaderState.Pausing && this.state != DownloaderState.Working && this.state != DownloaderState.WaitingForReconnect)
			{
				this.SetState(DownloaderState.Preparing);
				this.StartPrepared();
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000550C File Offset: 0x0000370C
		private void AllocLocalFile()
		{
			FileInfo fileInfo = new FileInfo(this.LocalFile);
			if (!Directory.Exists(fileInfo.DirectoryName))
			{
				Directory.CreateDirectory(fileInfo.DirectoryName);
			}
			if (fileInfo.Exists)
			{
				int num = 1;
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(this.LocalFile);
				string extension = Path.GetExtension(this.LocalFile);
				string path;
				do
				{
					path = PathHelper.GetWithBackslash(fileInfo.DirectoryName) + fileNameWithoutExtension + string.Format("({0})", num++) + extension;
				}
				while (File.Exists(path));
				this.localFile = path;
			}
			using (FileStream fileStream = new FileStream(this.LocalFile, FileMode.Create, FileAccess.Write))
			{
				fileStream.SetLength(Math.Max(this.FileSize, 0L));
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x000055DC File Offset: 0x000037DC
		private void StartDownloadThreadProc(object objSegmentCount)
		{
			this.SetState(DownloaderState.Preparing);
			int segmentCount = Math.Min((int)objSegmentCount, Settings.MaxSegments);
			Stream inputStream = null;
			int num = 0;
			for (;;)
			{
				this.lastError = null;
				if (this.state == DownloaderState.Pausing)
				{
					break;
				}
				this.SetState(DownloaderState.Preparing);
				num++;
				try
				{
					this.remoteFileInfo = this.defaultDownloadProvider.GetFileInfo(this.ResourceLocation, out inputStream);
					goto IL_98;
				}
				catch (ThreadAbortException)
				{
					this.SetState(DownloaderState.NeedToPrepare);
					return;
				}
				catch (Exception ex)
				{
					this.lastError = ex;
					if (num >= Settings.MaxRetries)
					{
						this.SetState(DownloaderState.NeedToPrepare);
						return;
					}
					this.SetState(DownloaderState.WaitingForReconnect);
					Thread.Sleep(TimeSpan.FromSeconds((double)Settings.RetryDelay));
				}
			}
			this.SetState(DownloaderState.NeedToPrepare);
			return;
			IL_98:
			try
			{
				this.lastError = null;
				this.StartSegments(segmentCount, inputStream);
			}
			catch (ThreadAbortException)
			{
				throw;
			}
			catch (Exception ex2)
			{
				this.lastError = ex2;
				this.SetState(DownloaderState.EndedWithError);
			}
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x000056E0 File Offset: 0x000038E0
		private void StartSegments(int segmentCount, Stream inputStream)
		{
			this.OnInfoReceived();
			this.AllocLocalFile();
			CalculatedSegment[] array;
			if (!this.remoteFileInfo.AcceptRanges)
			{
				array = new CalculatedSegment[]
				{
					new CalculatedSegment(0L, this.remoteFileInfo.FileSize)
				};
			}
			else
			{
				array = this.SegmentCalculator.GetSegments(segmentCount, this.remoteFileInfo);
			}
			List<Thread> obj = this.threads;
			lock (obj)
			{
				this.threads.Clear();
			}
			List<Segment> obj2 = this.segments;
			lock (obj2)
			{
				this.segments.Clear();
			}
			for (int i = 0; i < array.Length; i++)
			{
				Segment segment = new Segment();
				if (i == 0)
				{
					segment.InputStream = inputStream;
				}
				segment.Index = i;
				segment.InitialStartPosition = array[i].StartPosition;
				segment.StartPosition = array[i].StartPosition;
				segment.EndPosition = array[i].EndPosition;
				this.segments.Add(segment);
			}
			this.RunSegments();
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00005810 File Offset: 0x00003A10
		private void RestartDownload()
		{
			int num = 0;
			Stream stream;
			RemoteFileInfo fileInfo;
			try
			{
				for (;;)
				{
					this.lastError = null;
					this.SetState(DownloaderState.Preparing);
					num++;
					try
					{
						fileInfo = this.defaultDownloadProvider.GetFileInfo(this.ResourceLocation, out stream);
						break;
					}
					catch (Exception ex)
					{
						this.lastError = ex;
						if (num >= Settings.MaxRetries)
						{
							return;
						}
						this.SetState(DownloaderState.WaitingForReconnect);
						Thread.Sleep(TimeSpan.FromSeconds((double)Settings.RetryDelay));
					}
				}
			}
			finally
			{
				this.SetState(DownloaderState.Prepared);
			}
			try
			{
				if (fileInfo.AcceptRanges && !(fileInfo.LastModified > this.RemoteFileInfo.LastModified))
				{
					if (fileInfo.FileSize == this.RemoteFileInfo.FileSize)
					{
						if (stream != null)
						{
							stream.Dispose();
						}
						this.RunSegments();
						goto IL_B8;
					}
				}
				this.remoteFileInfo = fileInfo;
				this.StartSegments(this.RequestedSegments, stream);
				IL_B8:;
			}
			catch (ThreadAbortException)
			{
				throw;
			}
			catch (Exception ex2)
			{
				this.lastError = ex2;
				this.SetState(DownloaderState.EndedWithError);
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00005924 File Offset: 0x00003B24
		private void RunSegments()
		{
			this.SetState(DownloaderState.Working);
			using (FileStream fileStream = new FileStream(this.LocalFile, FileMode.Open, FileAccess.Write))
			{
				for (int i = 0; i < this.Segments.Count; i++)
				{
					this.Segments[i].OutputStream = fileStream;
					this.StartSegment(this.Segments[i]);
				}
				while (!this.AllWorkersStopped(1000) || this.RestartFailedSegments())
				{
				}
			}
			for (int j = 0; j < this.Segments.Count; j++)
			{
				if (this.Segments[j].State == SegmentState.Error)
				{
					this.SetState(DownloaderState.EndedWithError);
					return;
				}
			}
			if (this.State != DownloaderState.Pausing)
			{
				this.OnEnding();
			}
			this.SetState(DownloaderState.Ended);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00005A00 File Offset: 0x00003C00
		private bool RestartFailedSegments()
		{
			bool result = false;
			double num = 0.0;
			for (int i = 0; i < this.Segments.Count; i++)
			{
				if (this.Segments[i].State == SegmentState.Error && this.Segments[i].LastErrorDateTime != DateTime.MinValue && (Settings.MaxRetries == 0 || this.Segments[i].CurrentTry < Settings.MaxRetries))
				{
					result = true;
					TimeSpan timeSpan = DateTime.Now - this.Segments[i].LastErrorDateTime;
					if (timeSpan.TotalSeconds >= (double)Settings.RetryDelay)
					{
						Segment segment = this.Segments[i];
						int currentTry = segment.CurrentTry;
						segment.CurrentTry = currentTry + 1;
						this.StartSegment(this.Segments[i]);
						this.OnRestartingSegment(this.Segments[i]);
					}
					else
					{
						num = Math.Max(num, (double)(Settings.RetryDelay * 1000) - timeSpan.TotalMilliseconds);
					}
				}
			}
			Thread.Sleep((int)num);
			return result;
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00005B24 File Offset: 0x00003D24
		private void StartSegment(Segment newSegment)
		{
			Thread thread = new Thread(new ParameterizedThreadStart(this.SegmentThreadProc));
			thread.IsBackground = true;
			thread.Start(newSegment);
			List<Thread> obj = this.threads;
			lock (obj)
			{
				this.threads.Add(thread);
			}
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00005B84 File Offset: 0x00003D84
		private bool AllWorkersStopped(int timeOut)
		{
			bool flag = true;
			List<Thread> obj = this.threads;
			Thread[] array;
			lock (obj)
			{
				array = this.threads.ToArray();
			}
			foreach (Thread thread in array)
			{
				bool flag2 = thread.Join(timeOut);
				flag = (flag && flag2);
				if (flag2)
				{
					obj = this.threads;
					lock (obj)
					{
						this.threads.Remove(thread);
					}
				}
			}
			return flag;
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00005C24 File Offset: 0x00003E24
		private void SegmentThreadProc(object objSegment)
		{
			Segment segment = (Segment)objSegment;
			segment.LastError = null;
			try
			{
				if (segment.EndPosition > 0L && segment.StartPosition >= segment.EndPosition)
				{
					segment.State = SegmentState.Finished;
					this.OnSegmentStoped(segment);
				}
				else
				{
					int count = 8192;
					byte[] buffer = new byte[8192];
					segment.State = SegmentState.Connecting;
					this.OnSegmentStarting(segment);
					if (segment.InputStream == null)
					{
						ResourceLocation nextResourceLocation = this.MirrorSelector.GetNextResourceLocation();
						IProtocolProvider protocolProvider = nextResourceLocation.BindProtocolProviderInstance(this);
						while (nextResourceLocation != this.ResourceLocation)
						{
							Stream stream;
							RemoteFileInfo fileInfo = protocolProvider.GetFileInfo(nextResourceLocation, out stream);
							if (stream != null)
							{
								stream.Dispose();
							}
							if (fileInfo.FileSize == this.remoteFileInfo.FileSize && fileInfo.AcceptRanges == this.remoteFileInfo.AcceptRanges)
							{
								break;
							}
							List<ResourceLocation> obj = this.mirrors;
							lock (obj)
							{
								this.mirrors.Remove(nextResourceLocation);
							}
							nextResourceLocation = this.MirrorSelector.GetNextResourceLocation();
							protocolProvider = nextResourceLocation.BindProtocolProviderInstance(this);
						}
						segment.InputStream = protocolProvider.CreateStream(nextResourceLocation, segment.StartPosition, segment.EndPosition);
						segment.CurrentURL = nextResourceLocation.URL;
					}
					else
					{
						segment.CurrentURL = this.resourceLocation.URL;
					}
					using (segment.InputStream)
					{
						this.OnSegmentStarted(segment);
						segment.State = SegmentState.Downloading;
						segment.CurrentTry = 0;
						for (;;)
						{
							long num = (long)segment.InputStream.Read(buffer, 0, count);
							if (segment.EndPosition > 0L && segment.StartPosition + num > segment.EndPosition)
							{
								num = segment.EndPosition - segment.StartPosition;
								if (num <= 0L)
								{
									goto Block_19;
								}
							}
							Stream outputStream = segment.OutputStream;
							lock (outputStream)
							{
								segment.OutputStream.Position = segment.StartPosition;
								segment.OutputStream.Write(buffer, 0, (int)num);
							}
							segment.IncreaseStartPosition(num);
							if (segment.EndPosition > 0L && segment.StartPosition >= segment.EndPosition)
							{
								goto IL_221;
							}
							if (this.state == DownloaderState.Pausing)
							{
								break;
							}
							if (num <= 0L)
							{
								goto Block_17;
							}
						}
						segment.State = SegmentState.Paused;
						Block_17:
						goto IL_236;
						Block_19:
						segment.StartPosition = segment.EndPosition;
						goto IL_236;
						IL_221:
						segment.StartPosition = segment.EndPosition;
						IL_236:
						if (segment.State == SegmentState.Downloading)
						{
							segment.State = SegmentState.Finished;
							this.AddNewSegmentIfNeeded();
						}
					}
					this.OnSegmentStoped(segment);
				}
			}
			catch (Exception ex)
			{
				segment.State = SegmentState.Error;
				segment.LastError = ex;
				this.OnSegmentFailed(segment);
			}
			finally
			{
				segment.InputStream = null;
			}
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00005F34 File Offset: 0x00004134
		private void AddNewSegmentIfNeeded()
		{
			List<Segment> obj = this.segments;
			lock (obj)
			{
				for (int i = 0; i < this.segments.Count; i++)
				{
					Segment segment = this.segments[i];
					if (segment.State == SegmentState.Downloading && segment.Left.TotalSeconds > (double)Settings.MinSegmentLeftToStartNewSegment && segment.MissingTransfer / 2L >= (long)Settings.MinSegmentSize)
					{
						long num = segment.MissingTransfer / 2L;
						Segment segment2 = new Segment();
						segment2.Index = this.segments.Count;
						segment2.StartPosition = segment.StartPosition + num;
						segment2.InitialStartPosition = segment2.StartPosition;
						segment2.EndPosition = segment.EndPosition;
						segment2.OutputStream = segment.OutputStream;
						segment.EndPosition -= num;
						this.segments.Add(segment2);
						this.StartSegment(segment2);
						break;
					}
				}
			}
		}

		// Token: 0x04000063 RID: 99
		private string localFile;

		// Token: 0x04000064 RID: 100
		private int requestedSegmentCount;

		// Token: 0x04000065 RID: 101
		private ResourceLocation resourceLocation;

		// Token: 0x04000066 RID: 102
		private List<ResourceLocation> mirrors;

		// Token: 0x04000067 RID: 103
		private List<Segment> segments;

		// Token: 0x04000068 RID: 104
		private Thread mainThread;

		// Token: 0x04000069 RID: 105
		private List<Thread> threads;

		// Token: 0x0400006A RID: 106
		private RemoteFileInfo remoteFileInfo;

		// Token: 0x0400006B RID: 107
		private DownloaderState state;

		// Token: 0x0400006C RID: 108
		private DateTime createdDateTime;

		// Token: 0x0400006D RID: 109
		private Exception lastError;

		// Token: 0x0400006E RID: 110
		private Dictionary<string, object> extentedProperties = new Dictionary<string, object>();

		// Token: 0x0400006F RID: 111
		private IProtocolProvider defaultDownloadProvider;

		// Token: 0x04000070 RID: 112
		private ISegmentCalculator segmentCalculator;

		// Token: 0x04000071 RID: 113
		private IMirrorSelector mirrorSelector;

		// Token: 0x04000072 RID: 114
		private string statusMessage;
	}
}
