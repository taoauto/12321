﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Configuration;
using System.Net.Security;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace Update
{
	// Token: 0x02000025 RID: 37
	internal class DownloadManager
	{
		// Token: 0x060000DB RID: 219 RVA: 0x000029A7 File Offset: 0x00000BA7
		public static void DisableValidate()
		{
			DownloadManager.SetAllowUnsafeHeaderParsing20();
			ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback(DownloadManager.BypassAllCertificateStuff));
		}

		// Token: 0x060000DC RID: 220 RVA: 0x0000249E File Offset: 0x0000069E
		private static bool BypassAllCertificateStuff(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error)
		{
			return true;
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00006040 File Offset: 0x00004240
		public static bool SetAllowUnsafeHeaderParsing20()
		{
			Assembly assembly = Assembly.GetAssembly(typeof(SettingsSection));
			if (assembly != null)
			{
				Type type = assembly.GetType("System.Net.Configuration.SettingsSectionInternal");
				if (type != null)
				{
					object obj = type.InvokeMember("Section", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetProperty, null, null, new object[0]);
					if (obj != null)
					{
						FieldInfo field = type.GetField("useUnsafeHeaderParsing", BindingFlags.Instance | BindingFlags.NonPublic);
						if (field != null)
						{
							field.SetValue(obj, true);
							return true;
						}
					}
				}
			}
			return false;
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000DE RID: 222 RVA: 0x000060AC File Offset: 0x000042AC
		public static DownloadManager Instance
		{
			get
			{
				if (!DownloadManager.IsValidate)
				{
					DownloadManager.IsValidate = true;
					DownloadManager.DisableValidate();
					ProtocolProviderFactory.RegisterProtocolHandler("http", typeof(HttpProtocolProvider));
					ProtocolProviderFactory.RegisterProtocolHandler("https", typeof(HttpProtocolProvider));
					ProtocolProviderFactory.RegisterProtocolHandler("ftp", typeof(FtpProtocolProvider));
					DownloadManager.extensions = new List<IExtension>();
					DownloadManager.extensions.Add(new HttpFtpProtocolExtension());
				}
				if (DownloadManager.instance == null)
				{
					DownloadManager.instance = new DownloadManager();
				}
				return DownloadManager.instance;
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060000DF RID: 223 RVA: 0x00006138 File Offset: 0x00004338
		// (remove) Token: 0x060000E0 RID: 224 RVA: 0x00006170 File Offset: 0x00004370
		public event EventHandler BeginAddBatchDownloads;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060000E1 RID: 225 RVA: 0x000061A8 File Offset: 0x000043A8
		// (remove) Token: 0x060000E2 RID: 226 RVA: 0x000061E0 File Offset: 0x000043E0
		public event EventHandler EndAddBatchDownloads;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060000E3 RID: 227 RVA: 0x00006218 File Offset: 0x00004418
		// (remove) Token: 0x060000E4 RID: 228 RVA: 0x00006250 File Offset: 0x00004450
		public event EventHandler<DownloaderEventArgs> DownloadEnded;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060000E5 RID: 229 RVA: 0x00006288 File Offset: 0x00004488
		// (remove) Token: 0x060000E6 RID: 230 RVA: 0x000062C0 File Offset: 0x000044C0
		public event EventHandler<DownloaderEventArgs> DownloadAdded;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x060000E7 RID: 231 RVA: 0x000062F8 File Offset: 0x000044F8
		// (remove) Token: 0x060000E8 RID: 232 RVA: 0x00006330 File Offset: 0x00004530
		public event EventHandler<DownloaderEventArgs> DownloadRemoved;

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x000029CF File Offset: 0x00000BCF
		public ReadOnlyCollection<Downloader> Downloads
		{
			get
			{
				return this.downloads.AsReadOnly();
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000EA RID: 234 RVA: 0x00006368 File Offset: 0x00004568
		public double TotalDownloadRate
		{
			get
			{
				double num = 0.0;
				using (this.LockDownloadList(false))
				{
					for (int i = 0; i < this.Downloads.Count; i++)
					{
						if (this.Downloads[i].State == DownloaderState.Working)
						{
							num += this.Downloads[i].Rate;
						}
					}
				}
				return num;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000EB RID: 235 RVA: 0x000029DC File Offset: 0x00000BDC
		public int AddBatchCount
		{
			get
			{
				return this.addBatchCount;
			}
		}

		// Token: 0x060000EC RID: 236 RVA: 0x000063E4 File Offset: 0x000045E4
		private void downloader_StateChanged(object sender, EventArgs e)
		{
			Downloader downloader = (Downloader)sender;
			if (downloader.State == DownloaderState.Ended || downloader.State == DownloaderState.EndedWithError)
			{
				this.OnDownloadEnded((Downloader)sender);
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x000029E4 File Offset: 0x00000BE4
		public IDisposable LockDownloadList(bool lockForWrite)
		{
			if (lockForWrite)
			{
				return this.downloadListSync.LockForWrite();
			}
			return this.downloadListSync.LockForRead();
		}

		// Token: 0x060000EE RID: 238 RVA: 0x00002A00 File Offset: 0x00000C00
		public void RemoveDownload(int index)
		{
			this.RemoveDownload(this.downloads[index]);
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00006418 File Offset: 0x00004618
		public void RemoveDownload(Downloader downloader)
		{
			if (downloader.State != DownloaderState.NeedToPrepare || downloader.State != DownloaderState.Ended || downloader.State != DownloaderState.Paused)
			{
				downloader.Pause();
			}
			using (this.LockDownloadList(true))
			{
				this.downloads.Remove(downloader);
			}
			this.OnDownloadRemoved(downloader);
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00006480 File Offset: 0x00004680
		public void ClearEnded()
		{
			using (this.LockDownloadList(true))
			{
				for (int i = this.downloads.Count - 1; i >= 0; i--)
				{
					if (this.downloads[i].State == DownloaderState.Ended)
					{
						Downloader d = this.downloads[i];
						this.downloads.RemoveAt(i);
						this.OnDownloadRemoved(d);
					}
				}
			}
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x00006500 File Offset: 0x00004700
		public void PauseAll()
		{
			using (this.LockDownloadList(false))
			{
				for (int i = 0; i < this.Downloads.Count; i++)
				{
					this.Downloads[i].Pause();
				}
			}
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00006558 File Offset: 0x00004758
		public Downloader Add(ResourceLocation rl, ResourceLocation[] mirrors, string localFile, int segments, bool autoStart)
		{
			Downloader downloader = new Downloader(rl, mirrors, localFile, segments);
			this.Add(downloader, autoStart);
			return downloader;
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000657C File Offset: 0x0000477C
		public Downloader Add(ResourceLocation rl, ResourceLocation[] mirrors, string localFile, List<Segment> segments, RemoteFileInfo remoteInfo, int requestedSegmentCount, bool autoStart, DateTime createdDateTime)
		{
			Downloader downloader = new Downloader(rl, mirrors, localFile, segments, remoteInfo, requestedSegmentCount, createdDateTime);
			this.Add(downloader, autoStart);
			return downloader;
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x000065A4 File Offset: 0x000047A4
		public void Add(Downloader downloader, bool autoStart)
		{
			downloader.StateChanged += this.downloader_StateChanged;
			using (this.LockDownloadList(true))
			{
				this.downloads.Add(downloader);
			}
			this.OnDownloadAdded(downloader, autoStart);
			if (autoStart)
			{
				downloader.Start();
			}
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x00002A14 File Offset: 0x00000C14
		public virtual void OnBeginAddBatchDownloads()
		{
			this.addBatchCount++;
			if (this.BeginAddBatchDownloads != null)
			{
				this.BeginAddBatchDownloads(this, EventArgs.Empty);
			}
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x00002A3D File Offset: 0x00000C3D
		public virtual void OnEndAddBatchDownloads()
		{
			this.addBatchCount--;
			if (this.EndAddBatchDownloads != null)
			{
				this.EndAddBatchDownloads(this, EventArgs.Empty);
			}
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x00002A66 File Offset: 0x00000C66
		protected virtual void OnDownloadEnded(Downloader d)
		{
			if (this.DownloadEnded != null)
			{
				this.DownloadEnded(this, new DownloaderEventArgs(d));
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x00002A82 File Offset: 0x00000C82
		protected virtual void OnDownloadAdded(Downloader d, bool willStart)
		{
			if (this.DownloadAdded != null)
			{
				this.DownloadAdded(this, new DownloaderEventArgs(d, willStart));
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00002A9F File Offset: 0x00000C9F
		protected virtual void OnDownloadRemoved(Downloader d)
		{
			if (this.DownloadRemoved != null)
			{
				this.DownloadRemoved(this, new DownloaderEventArgs(d));
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x00006604 File Offset: 0x00004804
		public void SwapDownloads(int idx, bool isThreadSafe)
		{
			if (isThreadSafe)
			{
				this.InternalSwap(idx);
				return;
			}
			using (this.LockDownloadList(true))
			{
				this.InternalSwap(idx);
			}
		}

		// Token: 0x060000FB RID: 251 RVA: 0x00006648 File Offset: 0x00004848
		private void InternalSwap(int idx)
		{
			int count = this.downloads.Count;
			Downloader item = this.downloads[idx];
			Downloader item2 = this.downloads[idx - 1];
			this.downloads.RemoveAt(idx);
			this.downloads.RemoveAt(idx - 1);
			this.downloads.Insert(idx - 1, item);
			this.downloads.Insert(idx, item2);
		}

		// Token: 0x04000085 RID: 133
		private static DownloadManager instance;

		// Token: 0x04000086 RID: 134
		private static List<IExtension> extensions;

		// Token: 0x04000087 RID: 135
		private static bool IsValidate;

		// Token: 0x04000088 RID: 136
		private List<Downloader> downloads = new List<Downloader>();

		// Token: 0x04000089 RID: 137
		private int addBatchCount;

		// Token: 0x0400008A RID: 138
		private ReaderWriterObjectLocker downloadListSync = new ReaderWriterObjectLocker();
	}
}
