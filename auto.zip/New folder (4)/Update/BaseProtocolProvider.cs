﻿using System;
using System.Net;

namespace Update
{
	// Token: 0x02000032 RID: 50
	internal class BaseProtocolProvider
	{
		// Token: 0x06000121 RID: 289 RVA: 0x00002B8F File Offset: 0x00000D8F
		static BaseProtocolProvider()
		{
			ServicePointManager.DefaultConnectionLimit = int.MaxValue;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00006890 File Offset: 0x00004A90
		protected WebRequest GetRequest(ResourceLocation location)
		{
			WebRequest webRequest = WebRequest.Create(location.URL);
			webRequest.Timeout = 30000;
			this.SetProxy(webRequest);
			return webRequest;
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00002B9B File Offset: 0x00000D9B
		protected void SetProxy(WebRequest request)
		{
			request.Proxy = null;
		}
	}
}
