﻿using System;

namespace Update
{
	// Token: 0x02000019 RID: 25
	[Serializable]
	public struct CalculatedSegment
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000085 RID: 133 RVA: 0x00002650 File Offset: 0x00000850
		public long StartPosition
		{
			get
			{
				return this.startPosition;
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000086 RID: 134 RVA: 0x00002658 File Offset: 0x00000858
		public long EndPosition
		{
			get
			{
				return this.endPosition;
			}
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00002660 File Offset: 0x00000860
		public CalculatedSegment(long startPos, long endPos)
		{
			this.endPosition = endPos;
			this.startPosition = startPos;
		}

		// Token: 0x04000053 RID: 83
		private long startPosition;

		// Token: 0x04000054 RID: 84
		private long endPosition;
	}
}
