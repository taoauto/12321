﻿using System;

namespace Update
{
	// Token: 0x0200001B RID: 27
	internal static class ByteFormatter
	{
		// Token: 0x0600008A RID: 138 RVA: 0x00004CC4 File Offset: 0x00002EC4
		public static string ToString(long size)
		{
			if (size < 1024L)
			{
				return string.Format("{0} b", size);
			}
			if (size >= 1024L && size < 1048576L)
			{
				return string.Format("{0:0} KB", (float)size / 1024f);
			}
			if (size >= 1048576L && size < 1073741824L)
			{
				return string.Format("{0:0,###} MB", (float)size / 1024f);
			}
			return string.Format("{0:0,###.###} GB", (float)size / 1024f);
		}

		// Token: 0x04000057 RID: 87
		private const long KB = 1024L;

		// Token: 0x04000058 RID: 88
		private const long MB = 1048576L;

		// Token: 0x04000059 RID: 89
		private const long GB = 1073741824L;

		// Token: 0x0400005A RID: 90
		private const string BFormatPattern = "{0} b";

		// Token: 0x0400005B RID: 91
		private const string KBFormatPattern = "{0:0} KB";

		// Token: 0x0400005C RID: 92
		private const string MBFormatPattern = "{0:0,###} MB";

		// Token: 0x0400005D RID: 93
		private const string GBFormatPattern = "{0:0,###.###} GB";
	}
}
