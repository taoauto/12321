﻿using System;

// Token: 0x02000106 RID: 262
public class GClass80<T>
{
	// Token: 0x1700038E RID: 910
	// (get) Token: 0x06000D6C RID: 3436 RVA: 0x0000BA06 File Offset: 0x00009C06
	public int Int32_0
	{
		get
		{
			return this.gparam_0.Length;
		}
	}

	// Token: 0x1700038F RID: 911
	// (get) Token: 0x06000D6D RID: 3437 RVA: 0x0000BA10 File Offset: 0x00009C10
	public int Int32_1
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x06000D6E RID: 3438 RVA: 0x0000BA18 File Offset: 0x00009C18
	public GClass80(int int_2)
	{
		this.gparam_0 = new T[int_2];
		this.int_0 = 0;
		this.int_1 = 0;
	}

	// Token: 0x06000D6F RID: 3439 RVA: 0x000506C0 File Offset: 0x0004E8C0
	public T method_0()
	{
		if (this.int_0 == 0)
		{
			throw new Exception("Stack is empty");
		}
		int int32_ = this.Int32_2;
		T result = this.gparam_0[int32_];
		this.gparam_0[int32_] = default(T);
		this.int_0--;
		return result;
	}

	// Token: 0x17000390 RID: 912
	// (get) Token: 0x06000D70 RID: 3440 RVA: 0x0000BA3A File Offset: 0x00009C3A
	private int Int32_2
	{
		get
		{
			return (this.int_1 + this.int_0 - 1) % this.gparam_0.Length;
		}
	}

	// Token: 0x06000D71 RID: 3441 RVA: 0x00050718 File Offset: 0x0004E918
	public T method_1()
	{
		if (this.int_0 == 0)
		{
			return default(T);
		}
		return this.gparam_0[this.Int32_2];
	}

	// Token: 0x06000D72 RID: 3442 RVA: 0x00050748 File Offset: 0x0004E948
	public void method_2(T gparam_1)
	{
		if (this.int_0 == this.gparam_0.Length)
		{
			this.int_1 = (this.int_1 + 1) % this.gparam_0.Length;
		}
		else
		{
			this.int_0++;
		}
		this.gparam_0[this.Int32_2] = gparam_1;
	}

	// Token: 0x06000D73 RID: 3443 RVA: 0x0000BA54 File Offset: 0x00009C54
	public void method_3()
	{
		this.gparam_0 = new T[this.gparam_0.Length];
		this.int_0 = 0;
		this.int_1 = 0;
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x000507A0 File Offset: 0x0004E9A0
	public T[] method_4()
	{
		T[] array = new T[this.int_0];
		for (int i = 0; i < this.int_0; i++)
		{
			array[i] = this.gparam_0[(this.int_1 + i) % this.gparam_0.Length];
		}
		return array;
	}

	// Token: 0x040006A1 RID: 1697
	private T[] gparam_0;

	// Token: 0x040006A2 RID: 1698
	private int int_0;

	// Token: 0x040006A3 RID: 1699
	private int int_1;
}
