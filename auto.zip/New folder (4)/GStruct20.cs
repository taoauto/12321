﻿using System;

// Token: 0x02000216 RID: 534
public struct GStruct20
{
	// Token: 0x0400119F RID: 4511
	public IntPtr intptr_0;

	// Token: 0x040011A0 RID: 4512
	public IntPtr intptr_1;

	// Token: 0x040011A1 RID: 4513
	public uint uint_0;

	// Token: 0x040011A2 RID: 4514
	public uint uint_1;

	// Token: 0x040011A3 RID: 4515
	public uint uint_2;

	// Token: 0x040011A4 RID: 4516
	public uint uint_3;

	// Token: 0x040011A5 RID: 4517
	public uint uint_4;
}
