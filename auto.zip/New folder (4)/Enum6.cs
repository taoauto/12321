﻿using System;

// Token: 0x0200008F RID: 143
[Flags]
internal enum Enum6
{
	// Token: 0x0400032E RID: 814
	Unspecified = 0,
	// Token: 0x0400032F RID: 815
	Request = 1,
	// Token: 0x04000330 RID: 816
	Response = 2,
	// Token: 0x04000331 RID: 817
	Restricted = 4,
	// Token: 0x04000332 RID: 818
	MultiValue = 8,
	// Token: 0x04000333 RID: 819
	MultiValueInRequest = 16,
	// Token: 0x04000334 RID: 820
	MultiValueInResponse = 32
}
