﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x0200009E RID: 158
internal class Class77 : IAsyncResult
{
	// Token: 0x06000768 RID: 1896 RVA: 0x00007E50 File Offset: 0x00006050
	internal Class77(AsyncCallback asyncCallback_1, object object_2)
	{
		this.asyncCallback_0 = asyncCallback_1;
		this.object_0 = object_2;
		this.object_1 = new object();
	}

	// Token: 0x1700020C RID: 524
	// (get) Token: 0x06000769 RID: 1897 RVA: 0x00007E71 File Offset: 0x00006071
	// (set) Token: 0x0600076A RID: 1898 RVA: 0x00007E79 File Offset: 0x00006079
	internal byte[] Byte_0
	{
		get
		{
			return this.byte_0;
		}
		set
		{
			this.byte_0 = value;
		}
	}

	// Token: 0x1700020D RID: 525
	// (get) Token: 0x0600076B RID: 1899 RVA: 0x00007E82 File Offset: 0x00006082
	// (set) Token: 0x0600076C RID: 1900 RVA: 0x00007E8A File Offset: 0x0000608A
	internal int Int32_0
	{
		get
		{
			return this.int_0;
		}
		set
		{
			this.int_0 = value;
		}
	}

	// Token: 0x1700020E RID: 526
	// (get) Token: 0x0600076D RID: 1901 RVA: 0x00007E93 File Offset: 0x00006093
	internal Exception Exception_0
	{
		get
		{
			return this.exception_0;
		}
	}

	// Token: 0x1700020F RID: 527
	// (get) Token: 0x0600076E RID: 1902 RVA: 0x00007E9B File Offset: 0x0000609B
	internal bool Boolean_0
	{
		get
		{
			return this.exception_0 != null;
		}
	}

	// Token: 0x17000210 RID: 528
	// (get) Token: 0x0600076F RID: 1903 RVA: 0x00007EA6 File Offset: 0x000060A6
	// (set) Token: 0x06000770 RID: 1904 RVA: 0x00007EAE File Offset: 0x000060AE
	internal int Int32_1
	{
		get
		{
			return this.int_1;
		}
		set
		{
			this.int_1 = value;
		}
	}

	// Token: 0x17000211 RID: 529
	// (get) Token: 0x06000771 RID: 1905 RVA: 0x00007EB7 File Offset: 0x000060B7
	// (set) Token: 0x06000772 RID: 1906 RVA: 0x00007EBF File Offset: 0x000060BF
	internal int Int32_2
	{
		get
		{
			return this.int_2;
		}
		set
		{
			this.int_2 = value;
		}
	}

	// Token: 0x17000212 RID: 530
	// (get) Token: 0x06000773 RID: 1907 RVA: 0x00007EC8 File Offset: 0x000060C8
	public object AsyncState
	{
		get
		{
			return this.object_0;
		}
	}

	// Token: 0x17000213 RID: 531
	// (get) Token: 0x06000774 RID: 1908 RVA: 0x00038938 File Offset: 0x00036B38
	public WaitHandle AsyncWaitHandle
	{
		get
		{
			object obj = this.object_1;
			WaitHandle result;
			lock (obj)
			{
				ManualResetEvent manualResetEvent;
				if ((manualResetEvent = this.manualResetEvent_0) == null)
				{
					manualResetEvent = (this.manualResetEvent_0 = new ManualResetEvent(this.bool_0));
				}
				result = manualResetEvent;
			}
			return result;
		}
	}

	// Token: 0x17000214 RID: 532
	// (get) Token: 0x06000775 RID: 1909 RVA: 0x00007ED0 File Offset: 0x000060D0
	public bool CompletedSynchronously
	{
		get
		{
			return this.int_2 == this.int_0;
		}
	}

	// Token: 0x17000215 RID: 533
	// (get) Token: 0x06000776 RID: 1910 RVA: 0x00038994 File Offset: 0x00036B94
	public bool IsCompleted
	{
		get
		{
			object obj = this.object_1;
			bool result;
			lock (obj)
			{
				result = this.bool_0;
			}
			return result;
		}
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x000389D8 File Offset: 0x00036BD8
	internal void method_0()
	{
		object obj = this.object_1;
		lock (obj)
		{
			if (!this.bool_0)
			{
				this.bool_0 = true;
				if (this.manualResetEvent_0 != null)
				{
					this.manualResetEvent_0.Set();
				}
				if (this.asyncCallback_0 != null)
				{
					this.asyncCallback_0.BeginInvoke(this, new AsyncCallback(this.method_2), null);
				}
			}
		}
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x00007EE0 File Offset: 0x000060E0
	internal void method_1(Exception exception_1)
	{
		this.exception_0 = exception_1;
		this.method_0();
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x00007EEF File Offset: 0x000060EF
	[CompilerGenerated]
	private void method_2(IAsyncResult iasyncResult_0)
	{
		this.asyncCallback_0.EndInvoke(iasyncResult_0);
	}

	// Token: 0x04000414 RID: 1044
	private byte[] byte_0;

	// Token: 0x04000415 RID: 1045
	private AsyncCallback asyncCallback_0;

	// Token: 0x04000416 RID: 1046
	private bool bool_0;

	// Token: 0x04000417 RID: 1047
	private int int_0;

	// Token: 0x04000418 RID: 1048
	private Exception exception_0;

	// Token: 0x04000419 RID: 1049
	private int int_1;

	// Token: 0x0400041A RID: 1050
	private object object_0;

	// Token: 0x0400041B RID: 1051
	private object object_1;

	// Token: 0x0400041C RID: 1052
	private int int_2;

	// Token: 0x0400041D RID: 1053
	private ManualResetEvent manualResetEvent_0;
}
