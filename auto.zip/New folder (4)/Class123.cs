﻿using System;
using System.IO;

// Token: 0x0200013E RID: 318
internal static class Class123
{
	// Token: 0x06000FA9 RID: 4009 RVA: 0x00059450 File Offset: 0x00057650
	public static string smethod_0(string string_0)
	{
		if (!string_0.EndsWith(Path.DirectorySeparatorChar.ToString()))
		{
			string_0 += Path.DirectorySeparatorChar.ToString();
		}
		return string_0;
	}
}
