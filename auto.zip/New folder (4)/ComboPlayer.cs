﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000164 RID: 356
public class ComboPlayer : UserControl
{
	// Token: 0x0600115A RID: 4442 RVA: 0x0000DE10 File Offset: 0x0000C010
	public ComboPlayer()
	{
		this.InitializeComponent();
		this.method_0();
	}

	// Token: 0x0600115B RID: 4443 RVA: 0x0000DE24 File Offset: 0x0000C024
	private void method_0()
	{
		base.Height = this.cboPlayer.Height;
		if (this.lbSearch.Visible)
		{
			base.Height += this.lbSearch.Height;
		}
	}

	// Token: 0x1700049C RID: 1180
	// (get) Token: 0x0600115C RID: 4444 RVA: 0x0000DE5C File Offset: 0x0000C05C
	public virtual string Text
	{
		get
		{
			return this.cboPlayer.Text;
		}
	}

	// Token: 0x0600115D RID: 4445 RVA: 0x0000DE69 File Offset: 0x0000C069
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.lbSearch.Visible = false;
		this.method_0();
	}

	// Token: 0x0600115E RID: 4446 RVA: 0x0005DC34 File Offset: 0x0005BE34
	private void cboPlayer_TextChanged(object sender, EventArgs e)
	{
		ComboPlayer.Class146 @class = new ComboPlayer.Class146();
		ComboBox comboBox = sender as ComboBox;
		@class.string_0 = comboBox.Text.smethod_0();
		this.lbSearch.Visible = false;
		if (string.IsNullOrEmpty(@class.string_0))
		{
			return;
		}
		string[] array = Main.Main_0.IEnumerable_5.Select(new Func<Class159, string>(ComboPlayer.Class147.<>9.method_0)).Where(new Func<string, bool>(@class.method_0)).ToArray<string>();
		if (array.Length == 0)
		{
			return;
		}
		this.lbSearch.Items.Clear();
		ListBox.ObjectCollection items = this.lbSearch.Items;
		object[] items2 = array;
		items.AddRange(items2);
		this.lbSearch.Visible = true;
		this.method_0();
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x0000DE7D File Offset: 0x0000C07D
	private void lbSearch_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.cboPlayer.Text = this.lbSearch.SelectedItem.ToString();
		this.lbSearch.Visible = false;
		this.method_0();
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x0005DCF8 File Offset: 0x0005BEF8
	private void cboPlayer_DropDown(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add("");
		ComboBox.ObjectCollection items = this.cboPlayer.Items;
		object[] items2 = Main.Main_0.IEnumerable_5.Select(new Func<Class159, string>(ComboPlayer.Class147.<>9.method_1)).ToArray<string>();
		items.AddRange(items2);
	}

	// Token: 0x06001161 RID: 4449 RVA: 0x0000DEAC File Offset: 0x0000C0AC
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x0005DD70 File Offset: 0x0005BF70
	private void InitializeComponent()
	{
		this.lbSearch = new ListBox();
		this.cboPlayer = new ComboBox();
		base.SuspendLayout();
		this.lbSearch.Dock = DockStyle.Bottom;
		this.lbSearch.FormattingEnabled = true;
		this.lbSearch.Location = new Point(0, 139);
		this.lbSearch.Name = "lbSearch";
		this.lbSearch.Size = new Size(227, 56);
		this.lbSearch.TabIndex = 15;
		this.lbSearch.Visible = false;
		this.lbSearch.SelectedIndexChanged += this.lbSearch_SelectedIndexChanged;
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Location = new Point(0, 195);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(227, 21);
		this.cboPlayer.TabIndex = 16;
		this.cboPlayer.DropDown += this.cboPlayer_DropDown;
		this.cboPlayer.SelectedIndexChanged += this.cboPlayer_SelectedIndexChanged;
		this.cboPlayer.TextChanged += this.cboPlayer_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lbSearch);
		base.Controls.Add(this.cboPlayer);
		base.Name = "ComboPlayer";
		base.Size = new Size(227, 216);
		base.ResumeLayout(false);
	}

	// Token: 0x040008CF RID: 2255
	private IContainer icontainer_0;

	// Token: 0x040008D0 RID: 2256
	private ListBox lbSearch;

	// Token: 0x040008D1 RID: 2257
	private ComboBox cboPlayer;

	// Token: 0x02000165 RID: 357
	[CompilerGenerated]
	private sealed class Class146
	{
		// Token: 0x06001164 RID: 4452 RVA: 0x0000DECB File Offset: 0x0000C0CB
		internal bool method_0(string string_1)
		{
			return string_1.smethod_0().Contains(this.string_0);
		}

		// Token: 0x040008D2 RID: 2258
		public string string_0;
	}

	// Token: 0x02000166 RID: 358
	[CompilerGenerated]
	[Serializable]
	private sealed class Class147
	{
		// Token: 0x06001167 RID: 4455 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_0(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_1(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x040008D3 RID: 2259
		public static readonly ComboPlayer.Class147 <>9 = new ComboPlayer.Class147();

		// Token: 0x040008D4 RID: 2260
		public static Func<Class159, string> <>9__5_0;

		// Token: 0x040008D5 RID: 2261
		public static Func<Class159, string> <>9__7_0;
	}
}
