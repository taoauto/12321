﻿using System;

// Token: 0x02000293 RID: 659
internal class Class347
{
	// Token: 0x04001820 RID: 6176
	public static int int_0 = -1;

	// Token: 0x04001821 RID: 6177
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 47U,
		Int32_0 = 107,
		Int32_1 = 54,
		Int32_2 = Class347.int_0,
		String_2 = "Vạn Linh Thương"
	};

	// Token: 0x04001822 RID: 6178
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 46U,
		Int32_0 = 94,
		Int32_1 = 55,
		Int32_2 = Class347.int_0,
		String_2 = "Triệu Tử Huân"
	};

	// Token: 0x04001823 RID: 6179
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 48U,
		Int32_0 = 107,
		Int32_1 = 61,
		Int32_2 = Class347.int_0,
		String_2 = "Vạn Linh Tranh"
	};

	// Token: 0x04001824 RID: 6180
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 150,
		Int32_1 = 44,
		Int32_2 = Class347.int_0,
		String_2 = "Vạn Tàng Bảo"
	};

	// Token: 0x04001825 RID: 6181
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 8016U,
		Int32_0 = 65,
		Int32_1 = 198,
		Int32_2 = Class347.int_0,
		String_2 = "Tống Binh Tiền Tiêu"
	};

	// Token: 0x04001826 RID: 6182
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 6762U,
		Int32_0 = 73,
		Int32_1 = 111,
		Int32_2 = Class347.int_0,
		String_2 = "Người chỉ dẫn ác tặc làm phản"
	};

	// Token: 0x04001827 RID: 6183
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 10564U,
		Int32_0 = 92,
		Int32_1 = 180,
		Int32_2 = Class347.int_0,
		String_2 = "người chỉ dẫn môn phái"
	};

	// Token: 0x04001828 RID: 6184
	public static Class424 class424_7 = new Class424
	{
		UInt32_0 = 4420U,
		Int32_0 = 183,
		Int32_1 = 197,
		Int32_2 = Class347.int_0,
		String_2 = "Chỉ Dẫn Tam Quan"
	};

	// Token: 0x04001829 RID: 6185
	public static Class424 class424_8 = new Class424
	{
		UInt32_0 = 11U,
		Int32_0 = 45,
		Int32_1 = 74,
		Int32_2 = Class347.int_0,
		String_2 = "#GĐỗ Tử Bàn"
	};

	// Token: 0x0400182A RID: 6186
	public static Class424 class424_9 = new Class424
	{
		UInt32_0 = 5U,
		Int32_0 = 149,
		Int32_1 = 56,
		Int32_2 = Class347.int_0,
		String_2 = "#GTiền Vi Nhất"
	};

	// Token: 0x0400182B RID: 6187
	public static Class424 class424_10 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 148,
		Int32_1 = 96,
		Int32_2 = Class347.int_0,
		String_2 = "#Gông Phù Dung"
	};

	// Token: 0x0400182C RID: 6188
	public static Class424 class424_11 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 66,
		Int32_1 = 135,
		Int32_2 = Class347.int_0
	};

	// Token: 0x0400182D RID: 6189
	public static Class424 class424_12 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 100,
		Int32_1 = 55,
		Int32_2 = Class347.int_0,
		String_2 = "#GTrịnh Vô Danh"
	};

	// Token: 0x0400182E RID: 6190
	public static Class424 class424_13 = new Class424
	{
		UInt32_0 = 7U,
		Int32_0 = 129,
		Int32_1 = 99,
		Int32_2 = Class347.int_0,
		String_2 = "#GChu Thế Hữu"
	};

	// Token: 0x0400182F RID: 6191
	public static Class424 class424_14 = new Class424
	{
		UInt32_0 = 3U,
		Int32_0 = 135,
		Int32_1 = 50,
		Int32_2 = Class347.int_0,
		String_2 = "Võ Đại Uy"
	};
}
