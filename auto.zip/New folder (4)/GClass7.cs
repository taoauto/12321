﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Authentication;
using System.Text;
using System.Threading;

// Token: 0x02000011 RID: 17
public class GClass7 : IDisposable
{
	// Token: 0x1700004E RID: 78
	// (get) Token: 0x0600008F RID: 143 RVA: 0x00003626 File Offset: 0x00001826
	// (set) Token: 0x06000090 RID: 144 RVA: 0x0000362D File Offset: 0x0000182D
	public static bool Boolean_0 { get; set; }

	// Token: 0x1700004F RID: 79
	// (get) Token: 0x06000091 RID: 145 RVA: 0x00003635 File Offset: 0x00001835
	// (set) Token: 0x06000092 RID: 146 RVA: 0x0000363C File Offset: 0x0000183C
	public static bool Boolean_1 { get; set; }

	// Token: 0x17000050 RID: 80
	// (get) Token: 0x06000093 RID: 147 RVA: 0x00003644 File Offset: 0x00001844
	// (set) Token: 0x06000094 RID: 148 RVA: 0x0000364B File Offset: 0x0000184B
	public static GClass16 GClass16_0 { get; set; }

	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000095 RID: 149 RVA: 0x00003653 File Offset: 0x00001853
	// (remove) Token: 0x06000096 RID: 150 RVA: 0x0000366C File Offset: 0x0000186C
	public event EventHandler<GEventArgs1> Event_0
	{
		add
		{
			this.eventHandler_0 = (EventHandler<GEventArgs1>)Delegate.Combine(this.eventHandler_0, value);
		}
		remove
		{
			this.eventHandler_0 = (EventHandler<GEventArgs1>)Delegate.Remove(this.eventHandler_0, value);
		}
	}

	// Token: 0x14000002 RID: 2
	// (add) Token: 0x06000097 RID: 151 RVA: 0x00003685 File Offset: 0x00001885
	// (remove) Token: 0x06000098 RID: 152 RVA: 0x0000369E File Offset: 0x0000189E
	public event EventHandler<GEventArgs0> Event_1
	{
		add
		{
			this.eventHandler_1 = (EventHandler<GEventArgs0>)Delegate.Combine(this.eventHandler_1, value);
		}
		remove
		{
			this.eventHandler_1 = (EventHandler<GEventArgs0>)Delegate.Remove(this.eventHandler_1, value);
		}
	}

	// Token: 0x17000051 RID: 81
	// (get) Token: 0x06000099 RID: 153 RVA: 0x000036B7 File Offset: 0x000018B7
	// (set) Token: 0x0600009A RID: 154 RVA: 0x000036BF File Offset: 0x000018BF
	public Uri Uri_0 { get; set; }

	// Token: 0x17000052 RID: 82
	// (get) Token: 0x0600009B RID: 155 RVA: 0x000036C8 File Offset: 0x000018C8
	// (set) Token: 0x0600009C RID: 156 RVA: 0x000036D0 File Offset: 0x000018D0
	public Uri Uri_1 { get; private set; }

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x0600009D RID: 157 RVA: 0x000036D9 File Offset: 0x000018D9
	public GClass8 GClass8_0
	{
		get
		{
			return this.gclass8_0;
		}
	}

	// Token: 0x17000054 RID: 84
	// (get) Token: 0x0600009E RID: 158 RVA: 0x000036E1 File Offset: 0x000018E1
	// (set) Token: 0x0600009F RID: 159 RVA: 0x000036E9 File Offset: 0x000018E9
	public GClass16 GClass16_1 { get; set; }

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x060000A0 RID: 160 RVA: 0x000036F2 File Offset: 0x000018F2
	// (set) Token: 0x060000A1 RID: 161 RVA: 0x000036FA File Offset: 0x000018FA
	public bool Boolean_2 { get; set; }

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x060000A2 RID: 162 RVA: 0x00003703 File Offset: 0x00001903
	// (set) Token: 0x060000A3 RID: 163 RVA: 0x0000370B File Offset: 0x0000190B
	public int Int32_0
	{
		get
		{
			return this.int_1;
		}
		set
		{
			if (value < 1)
			{
				throw Class13.smethod_1<int>("MaximumAutomaticRedirections", 1);
			}
			this.int_1 = value;
		}
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x060000A4 RID: 164 RVA: 0x00003724 File Offset: 0x00001924
	// (set) Token: 0x060000A5 RID: 165 RVA: 0x0000372C File Offset: 0x0000192C
	public int Int32_1
	{
		get
		{
			return this.int_2;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("ConnectTimeout", 0);
			}
			this.int_2 = value;
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x060000A6 RID: 166 RVA: 0x00003745 File Offset: 0x00001945
	// (set) Token: 0x060000A7 RID: 167 RVA: 0x0000374D File Offset: 0x0000194D
	public int Int32_2
	{
		get
		{
			return this.int_3;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("ReadWriteTimeout", 0);
			}
			this.int_3 = value;
		}
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x060000A8 RID: 168 RVA: 0x00003766 File Offset: 0x00001966
	// (set) Token: 0x060000A9 RID: 169 RVA: 0x0000376E File Offset: 0x0000196E
	public bool Boolean_3 { get; set; }

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060000AA RID: 170 RVA: 0x00003777 File Offset: 0x00001977
	// (set) Token: 0x060000AB RID: 171 RVA: 0x0000377F File Offset: 0x0000197F
	public bool Boolean_4 { get; set; }

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060000AC RID: 172 RVA: 0x00003788 File Offset: 0x00001988
	// (set) Token: 0x060000AD RID: 173 RVA: 0x00003790 File Offset: 0x00001990
	public int Int32_3
	{
		get
		{
			return this.int_4;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("KeepAliveTimeout", 0);
			}
			this.int_4 = value;
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060000AE RID: 174 RVA: 0x000037A9 File Offset: 0x000019A9
	// (set) Token: 0x060000AF RID: 175 RVA: 0x000037B1 File Offset: 0x000019B1
	public int Int32_4
	{
		get
		{
			return this.int_5;
		}
		set
		{
			if (value < 1)
			{
				throw Class13.smethod_1<int>("MaximumKeepAliveRequests", 1);
			}
			this.int_5 = value;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060000B0 RID: 176 RVA: 0x000037CA File Offset: 0x000019CA
	// (set) Token: 0x060000B1 RID: 177 RVA: 0x000037D2 File Offset: 0x000019D2
	public bool Boolean_5 { get; set; }

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060000B2 RID: 178 RVA: 0x000037DB File Offset: 0x000019DB
	// (set) Token: 0x060000B3 RID: 179 RVA: 0x000037E3 File Offset: 0x000019E3
	public int Int32_5
	{
		get
		{
			return this.int_7;
		}
		set
		{
			if (value < 1)
			{
				throw Class13.smethod_1<int>("ReconnectLimit", 1);
			}
			this.int_7 = value;
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x000037FC File Offset: 0x000019FC
	// (set) Token: 0x060000B5 RID: 181 RVA: 0x00003804 File Offset: 0x00001A04
	public int Int32_6
	{
		get
		{
			return this.int_8;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("ReconnectDelay", 0);
			}
			this.int_8 = value;
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060000B6 RID: 182 RVA: 0x0000381D File Offset: 0x00001A1D
	// (set) Token: 0x060000B7 RID: 183 RVA: 0x00003825 File Offset: 0x00001A25
	public CultureInfo CultureInfo_0 { get; set; }

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060000B8 RID: 184 RVA: 0x0000382E File Offset: 0x00001A2E
	// (set) Token: 0x060000B9 RID: 185 RVA: 0x00003836 File Offset: 0x00001A36
	public Encoding Encoding_0 { get; set; }

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060000BA RID: 186 RVA: 0x0000383F File Offset: 0x00001A3F
	// (set) Token: 0x060000BB RID: 187 RVA: 0x00003847 File Offset: 0x00001A47
	public bool Boolean_6 { get; set; }

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060000BC RID: 188 RVA: 0x00003850 File Offset: 0x00001A50
	// (set) Token: 0x060000BD RID: 189 RVA: 0x00003858 File Offset: 0x00001A58
	public string String_0 { get; set; }

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060000BE RID: 190 RVA: 0x00003861 File Offset: 0x00001A61
	// (set) Token: 0x060000BF RID: 191 RVA: 0x00003869 File Offset: 0x00001A69
	public string String_1 { get; set; }

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x00003872 File Offset: 0x00001A72
	// (set) Token: 0x060000C1 RID: 193 RVA: 0x0000387F File Offset: 0x00001A7F
	public string String_2
	{
		get
		{
			return this["User-Agent"];
		}
		set
		{
			this["User-Agent"] = value;
		}
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x0000388D File Offset: 0x00001A8D
	// (set) Token: 0x060000C3 RID: 195 RVA: 0x0000389A File Offset: 0x00001A9A
	public string String_3
	{
		get
		{
			return this["Referer"];
		}
		set
		{
			this["Referer"] = value;
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060000C4 RID: 196 RVA: 0x000038A8 File Offset: 0x00001AA8
	// (set) Token: 0x060000C5 RID: 197 RVA: 0x000038B5 File Offset: 0x00001AB5
	public string String_4
	{
		get
		{
			return this["Authorization"];
		}
		set
		{
			this["Authorization"] = value;
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060000C6 RID: 198 RVA: 0x000038C3 File Offset: 0x00001AC3
	// (set) Token: 0x060000C7 RID: 199 RVA: 0x000038CB File Offset: 0x00001ACB
	public GClass5 GClass5_0 { get; set; }

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060000C8 RID: 200 RVA: 0x000038D4 File Offset: 0x00001AD4
	internal TcpClient TcpClient_0
	{
		get
		{
			return this.tcpClient_0;
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060000C9 RID: 201 RVA: 0x000038DC File Offset: 0x00001ADC
	internal Stream Stream_0
	{
		get
		{
			return this.stream_0;
		}
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060000CA RID: 202 RVA: 0x000038E4 File Offset: 0x00001AE4
	internal NetworkStream NetworkStream_0
	{
		get
		{
			return this.networkStream_0;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060000CB RID: 203 RVA: 0x000038EC File Offset: 0x00001AEC
	private GClass13 GClass13_0
	{
		get
		{
			if (this.gclass13_0 == null)
			{
				this.gclass13_0 = new GClass13();
			}
			return this.gclass13_0;
		}
	}

	// Token: 0x1700006D RID: 109
	public string this[string string_2]
	{
		get
		{
			if (string_2 == null)
			{
				throw new ArgumentNullException("headerName");
			}
			if (string_2.Length == 0)
			{
				throw Class13.smethod_0("headerName");
			}
			string empty;
			if (!this.dictionary_0.TryGetValue(string_2, out empty))
			{
				empty = string.Empty;
			}
			return empty;
		}
		set
		{
			if (string_2 == null)
			{
				throw new ArgumentNullException("headerName");
			}
			if (string_2.Length == 0)
			{
				throw Class13.smethod_0("headerName");
			}
			if (this.method_64(string_2))
			{
				throw new ArgumentException(string.Format(Class2.String_2, string_2), "headerName");
			}
			if (string.IsNullOrEmpty(value))
			{
				this.dictionary_0.Remove(string_2);
				return;
			}
			this.dictionary_0[string_2] = value;
		}
	}

	// Token: 0x1700006E RID: 110
	public string this[GEnum1 genum1_0]
	{
		get
		{
			return this[GClass6.dictionary_0[genum1_0]];
		}
		set
		{
			this[GClass6.dictionary_0[genum1_0]] = value;
		}
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00022F28 File Offset: 0x00021128
	public GClass7()
	{
		this.method_36();
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00022F90 File Offset: 0x00021190
	public GClass7(string string_2)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("baseAddress");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("baseAddress");
		}
		if (!string_2.StartsWith("http"))
		{
			string_2 = "http://" + string_2;
		}
		Uri uri = new Uri(string_2);
		if (!uri.IsAbsoluteUri)
		{
			throw new ArgumentException(Class2.String_4, "baseAddress");
		}
		this.Uri_0 = uri;
		this.method_36();
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x0002305C File Offset: 0x0002125C
	public GClass7(Uri uri_2)
	{
		if (uri_2 == null)
		{
			throw new ArgumentNullException("baseAddress");
		}
		if (!uri_2.IsAbsoluteUri)
		{
			throw new ArgumentException(Class2.String_4, "baseAddress");
		}
		this.Uri_0 = uri_2;
		this.method_36();
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x0000392E File Offset: 0x00001B2E
	public GClass8 method_0(string string_2, GClass3 gclass3_2 = null)
	{
		if (gclass3_2 != null)
		{
			this.gclass3_1 = gclass3_2;
		}
		return this.method_16(GEnum2.GET, string_2, null);
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x00003943 File Offset: 0x00001B43
	public GClass8 method_1(Uri uri_2, GClass3 gclass3_2 = null)
	{
		if (gclass3_2 != null)
		{
			this.gclass3_1 = gclass3_2;
		}
		return this.method_17(GEnum2.GET, uri_2, null);
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x00003958 File Offset: 0x00001B58
	public GClass8 method_2(string string_2)
	{
		return this.method_16(GEnum2.POST, string_2, null);
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x00003963 File Offset: 0x00001B63
	public GClass8 method_3(Uri uri_2)
	{
		return this.method_17(GEnum2.POST, uri_2, null);
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x0000396E File Offset: 0x00001B6E
	public GClass8 method_4(string string_2, GClass3 gclass3_2, bool bool_9 = false)
	{
		if (gclass3_2 == null)
		{
			throw new ArgumentNullException("reqParams");
		}
		return this.method_16(GEnum2.POST, string_2, new GClass11(gclass3_2, bool_9, this.Encoding_0));
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x00003993 File Offset: 0x00001B93
	public GClass8 method_5(Uri uri_2, GClass3 gclass3_2, bool bool_9 = false)
	{
		if (gclass3_2 == null)
		{
			throw new ArgumentNullException("reqParams");
		}
		return this.method_17(GEnum2.POST, uri_2, new GClass11(gclass3_2, bool_9, this.Encoding_0));
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x000230F8 File Offset: 0x000212F8
	public GClass8 method_6(string string_2, string string_3, string string_4)
	{
		if (string_3 == null)
		{
			throw new ArgumentNullException("str");
		}
		if (string_3.Length == 0)
		{
			throw new ArgumentNullException("str");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_4.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass12 gclass9_ = new GClass12(string_3)
		{
			String_0 = string_4
		};
		return this.method_16(GEnum2.POST, string_2, gclass9_);
	}

	// Token: 0x060000DA RID: 218 RVA: 0x00023160 File Offset: 0x00021360
	public GClass8 method_7(Uri uri_2, string string_2, string string_3)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("str");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentNullException("str");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_3.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass12 gclass9_ = new GClass12(string_2)
		{
			String_0 = string_3
		};
		return this.method_17(GEnum2.POST, uri_2, gclass9_);
	}

	// Token: 0x060000DB RID: 219 RVA: 0x000231C8 File Offset: 0x000213C8
	public GClass8 method_8(string string_2, byte[] byte_0, string string_3 = "application/octet-stream")
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_3.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass10 gclass9_ = new GClass10(byte_0)
		{
			String_0 = string_3
		};
		return this.method_16(GEnum2.POST, string_2, gclass9_);
	}

	// Token: 0x060000DC RID: 220 RVA: 0x0002321C File Offset: 0x0002141C
	public GClass8 method_9(Uri uri_2, byte[] byte_0, string string_2 = "application/octet-stream")
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass10 gclass9_ = new GClass10(byte_0)
		{
			String_0 = string_2
		};
		return this.method_17(GEnum2.POST, uri_2, gclass9_);
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00023270 File Offset: 0x00021470
	public GClass8 method_10(string string_2, Stream stream_1, string string_3 = "application/octet-stream")
	{
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_3.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass14 gclass9_ = new GClass14(stream_1, 32768)
		{
			String_0 = string_3
		};
		return this.method_16(GEnum2.POST, string_2, gclass9_);
	}

	// Token: 0x060000DE RID: 222 RVA: 0x000232C8 File Offset: 0x000214C8
	public GClass8 method_11(Uri uri_2, Stream stream_1, string string_2 = "application/octet-stream")
	{
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentNullException("contentType");
		}
		GClass14 gclass9_ = new GClass14(stream_1, 32768)
		{
			String_0 = string_2
		};
		return this.method_17(GEnum2.POST, uri_2, gclass9_);
	}

	// Token: 0x060000DF RID: 223 RVA: 0x000039B8 File Offset: 0x00001BB8
	public GClass8 method_12(string string_2, string string_3)
	{
		if (string_3 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_3.Length == 0)
		{
			throw new ArgumentNullException("path");
		}
		return this.method_16(GEnum2.POST, string_2, new GClass15(string_3, 32768));
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x000039EE File Offset: 0x00001BEE
	public GClass8 method_13(Uri uri_2, string string_2)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentNullException("path");
		}
		return this.method_17(GEnum2.POST, uri_2, new GClass15(string_2, 32768));
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00003A24 File Offset: 0x00001C24
	public GClass8 method_14(string string_2, GClass9 gclass9_1)
	{
		if (gclass9_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		return this.method_16(GEnum2.POST, string_2, gclass9_1);
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00003A3D File Offset: 0x00001C3D
	public GClass8 method_15(Uri uri_2, GClass9 gclass9_1)
	{
		if (gclass9_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		return this.method_17(GEnum2.POST, uri_2, gclass9_1);
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00023320 File Offset: 0x00021520
	public GClass8 method_16(GEnum2 genum2_1, string string_2, GClass9 gclass9_1 = null)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("address");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("address");
		}
		Uri uri_ = new Uri(string_2, UriKind.RelativeOrAbsolute);
		return this.method_17(genum2_1, uri_, gclass9_1);
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x00023360 File Offset: 0x00021560
	public GClass8 method_17(GEnum2 genum2_1, Uri uri_2, GClass9 gclass9_1 = null)
	{
		if (uri_2 == null)
		{
			throw new ArgumentNullException("address");
		}
		if (!uri_2.IsAbsoluteUri)
		{
			uri_2 = this.method_37(this.Uri_0, uri_2);
		}
		if (this.gclass3_1 != null)
		{
			uri_2 = new UriBuilder(uri_2)
			{
				Query = GClass6.smethod_1(this.gclass3_1, true)
			}.Uri;
		}
		if (gclass9_1 == null)
		{
			if (this.gclass3_0 != null)
			{
				gclass9_1 = new GClass11(this.gclass3_0, false, this.Encoding_0);
			}
			else if (this.gclass13_0 != null)
			{
				gclass9_1 = this.gclass13_0;
			}
		}
		GClass8 result;
		try
		{
			result = this.method_38(genum2_1, uri_2, gclass9_1);
		}
		finally
		{
			if (gclass9_1 != null)
			{
				gclass9_1.method_0();
			}
			this.method_65();
		}
		return result;
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x00023420 File Offset: 0x00021620
	public GClass7 method_18(string string_2, object object_0 = null)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (this.gclass3_1 == null)
		{
			this.gclass3_1 = new GClass3();
		}
		this.gclass3_1[string_2] = object_0;
		return this;
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x00023470 File Offset: 0x00021670
	public GClass7 method_19(string string_2, object object_0 = null)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (this.gclass3_0 == null)
		{
			this.gclass3_0 = new GClass3();
		}
		this.gclass3_0[string_2] = object_0;
		return this;
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00003A56 File Offset: 0x00001C56
	public GClass7 method_20(string string_2, object object_0 = null)
	{
		return this.method_21(string_2, object_0, this.Encoding_0 ?? Encoding.UTF8);
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x000234C0 File Offset: 0x000216C0
	public GClass7 method_21(string string_2, object object_0, Encoding encoding_1)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (encoding_1 == null)
		{
			throw new ArgumentNullException("encoding");
		}
		string text = (object_0 == null) ? string.Empty : object_0.ToString();
		this.GClass13_0.method_1(new GClass12(text, encoding_1), string_2);
		return this;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x00023524 File Offset: 0x00021724
	public GClass7 method_22(string string_2, byte[] byte_0)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("value");
		}
		this.GClass13_0.method_1(new GClass10(byte_0), string_2);
		return this;
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00023574 File Offset: 0x00021774
	public GClass7 method_23(string string_2, string string_3, byte[] byte_0)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("value");
		}
		this.GClass13_0.method_2(new GClass10(byte_0), string_2, string_3);
		return this;
	}

	// Token: 0x060000EB RID: 235 RVA: 0x000235D4 File Offset: 0x000217D4
	public GClass7 method_24(string string_2, string string_3, string string_4, byte[] byte_0)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("value");
		}
		this.GClass13_0.method_3(new GClass10(byte_0), string_2, string_3, string_4);
		return this;
	}

	// Token: 0x060000EC RID: 236 RVA: 0x00023644 File Offset: 0x00021844
	public GClass7 method_25(string string_2, string string_3, Stream stream_1)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		this.GClass13_0.method_2(new GClass14(stream_1, 32768), string_2, string_3);
		return this;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x000236A8 File Offset: 0x000218A8
	public GClass7 method_26(string string_2, string string_3, string string_4)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_4.Length == 0)
		{
			throw Class13.smethod_0("path");
		}
		this.GClass13_0.method_2(new GClass15(string_4, 32768), string_2, string_3);
		return this;
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00023720 File Offset: 0x00021920
	public GClass7 method_27(string string_2, string string_3)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("path");
		}
		this.GClass13_0.method_2(new GClass15(string_3, 32768), string_2, Path.GetFileName(string_3));
		return this;
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00023790 File Offset: 0x00021990
	public GClass7 method_28(string string_2, string string_3)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_3 == null)
		{
			throw new ArgumentNullException("value");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("value");
		}
		if (this.method_64(string_2))
		{
			throw new ArgumentException(string.Format(Class2.String_2, string_2), "name");
		}
		if (this.dictionary_1 == null)
		{
			this.dictionary_1 = new Dictionary<string, string>();
		}
		this.dictionary_1[string_2] = string_3;
		return this;
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00003A6F File Offset: 0x00001C6F
	public GClass7 method_29(GEnum1 genum1_0, string string_2)
	{
		this.method_28(GClass6.dictionary_0[genum1_0], string_2);
		return this;
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00003A85 File Offset: 0x00001C85
	public void method_30()
	{
		this.Dispose();
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00003A8D File Offset: 0x00001C8D
	public void Dispose()
	{
		this.vmethod_0(true);
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00003A96 File Offset: 0x00001C96
	public bool method_31(string string_2)
	{
		return this.GClass5_0 != null && this.GClass5_0.ContainsKey(string_2);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00003AAE File Offset: 0x00001CAE
	public bool method_32(string string_2)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("headerName");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("headerName");
		}
		return this.dictionary_0.ContainsKey(string_2);
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00003ADD File Offset: 0x00001CDD
	public bool method_33(GEnum1 genum1_0)
	{
		return this.method_32(GClass6.dictionary_0[genum1_0]);
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00003AF0 File Offset: 0x00001CF0
	public Dictionary<string, string>.Enumerator method_34()
	{
		return this.dictionary_0.GetEnumerator();
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x00003AFD File Offset: 0x00001CFD
	public void method_35()
	{
		this.dictionary_0.Clear();
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x00003B0A File Offset: 0x00001D0A
	protected virtual void vmethod_0(bool bool_9)
	{
		if (bool_9 && this.tcpClient_0 != null)
		{
			this.tcpClient_0.Close();
			this.tcpClient_0 = null;
			this.stream_0 = null;
			this.networkStream_0 = null;
			this.int_6 = 0;
		}
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00023820 File Offset: 0x00021A20
	protected virtual void vmethod_1(GEventArgs1 geventArgs1_0)
	{
		EventHandler<GEventArgs1> eventHandler = this.eventHandler_0;
		if (eventHandler != null)
		{
			eventHandler(this, geventArgs1_0);
		}
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00023840 File Offset: 0x00021A40
	protected virtual void vmethod_2(GEventArgs0 geventArgs0_0)
	{
		EventHandler<GEventArgs0> eventHandler = this.eventHandler_1;
		if (eventHandler != null)
		{
			eventHandler(this, geventArgs0_0);
		}
	}

	// Token: 0x060000FB RID: 251 RVA: 0x00003B3E File Offset: 0x00001D3E
	private void method_36()
	{
		this.Boolean_4 = true;
		this.Boolean_2 = true;
		this.Boolean_6 = true;
		this.gclass8_0 = new GClass8(this);
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00023860 File Offset: 0x00021A60
	private Uri method_37(Uri uri_2, Uri uri_3)
	{
		Uri result = uri_3;
		if (uri_2 == null)
		{
			result = new UriBuilder(uri_3.OriginalString).Uri;
		}
		else
		{
			Uri.TryCreate(uri_2, uri_3, out result);
		}
		return result;
	}

	// Token: 0x060000FD RID: 253 RVA: 0x00023898 File Offset: 0x00021A98
	private GClass8 method_38(GEnum2 genum2_1, Uri uri_2, GClass9 gclass9_1)
	{
		this.genum2_0 = genum2_1;
		this.gclass9_0 = gclass9_1;
		this.method_39();
		Uri uri_3 = this.Uri_1;
		this.Uri_1 = uri_2;
		bool flag = false;
		try
		{
			flag = this.method_40(uri_2, uri_3);
		}
		catch
		{
			if (!this.method_44())
			{
				throw;
			}
			return this.method_45();
		}
		if (flag)
		{
			this.int_6 = 1;
		}
		else
		{
			this.int_6++;
		}
		try
		{
			this.method_42(genum2_1);
		}
		catch (SecurityException exception_)
		{
			throw this.method_66(Class2.String_20, exception_, GEnum0.SendFailure);
		}
		catch (IOException exception_2)
		{
			if (!this.method_44())
			{
				throw this.method_66(Class2.String_20, exception_2, GEnum0.SendFailure);
			}
			return this.method_45();
		}
		GClass8 result;
		try
		{
			this.method_43(genum2_1);
			goto IL_E1;
		}
		catch (GException1 gexception)
		{
			if (this.method_44())
			{
				result = this.method_45();
			}
			else
			{
				if (!this.Boolean_4 || this.bool_2 || flag || !gexception.Boolean_0)
				{
					throw;
				}
				result = this.method_46();
			}
		}
		return result;
		IL_E1:
		this.gclass8_0.Int32_0 = this.int_9;
		this.int_9 = 0;
		this.bool_2 = false;
		this.dateTime_0 = DateTime.Now;
		if (!this.Boolean_3)
		{
			this.method_47(this.gclass8_0.GEnum3_0);
		}
		if (!this.Boolean_2 || !this.gclass8_0.Boolean_3)
		{
			this.int_0 = 0;
			return this.gclass8_0;
		}
		int num = this.int_0 + 1;
		this.int_0 = num;
		if (num > this.int_1)
		{
			throw this.method_66(Class2.String_22, null, GEnum0.Other);
		}
		this.method_65();
		return this.method_38(GEnum2.GET, this.gclass8_0.Uri_1, null);
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00023A64 File Offset: 0x00021C64
	private void method_39()
	{
		if (this.tcpClient_0 != null && !this.gclass8_0.Boolean_0 && !this.gclass8_0.Boolean_1)
		{
			try
			{
				this.gclass8_0.method_3();
			}
			catch (GException1)
			{
				this.Dispose();
			}
		}
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00023ABC File Offset: 0x00021CBC
	private bool method_40(Uri uri_2, Uri uri_3)
	{
		GClass16 gclass = this.method_49();
		int num = (this.tcpClient_0 != null) ? 1 : 0;
		bool flag = this.gclass16_1 != gclass;
		bool flag2 = uri_3 == null || uri_3.Port != uri_2.Port || uri_3.Host != uri_2.Host || uri_3.Scheme != uri_2.Scheme;
		if (num != 0 && !flag && !flag2 && !this.gclass8_0.Boolean_0 && !this.method_41())
		{
			return false;
		}
		this.gclass16_1 = gclass;
		this.Dispose();
		this.method_51(uri_2);
		return true;
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00023B5C File Offset: 0x00021D5C
	private bool method_41()
	{
		if (!this.Boolean_4)
		{
			return false;
		}
		int num = this.gclass8_0.Nullable_1 ?? this.int_5;
		if (this.int_6 >= num)
		{
			return true;
		}
		int num2 = this.gclass8_0.Nullable_0 ?? this.int_4;
		return this.dateTime_0.AddMilliseconds((double)num2) < DateTime.Now;
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00023BE4 File Offset: 0x00021DE4
	private void method_42(GEnum2 genum2_1)
	{
		long num = 0L;
		string empty = string.Empty;
		if (this.method_48(genum2_1) && this.gclass9_0 != null)
		{
			empty = this.gclass9_0.String_0;
			num = this.gclass9_0.GClass9.\u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E();
		}
		string s = this.method_52(genum2_1);
		string s2 = this.method_53(genum2_1, num, empty);
		byte[] bytes = Encoding.ASCII.GetBytes(s);
		byte[] bytes2 = Encoding.ASCII.GetBytes(s2);
		this.long_0 = 0L;
		this.long_1 = (long)(bytes.Length + bytes2.Length) + num;
		this.stream_0.Write(bytes, 0, bytes.Length);
		this.stream_0.Write(bytes2, 0, bytes2.Length);
		if (this.gclass9_0 != null && num > 0L)
		{
			this.gclass9_0.GClass9.\u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(this.stream_0);
		}
	}

	// Token: 0x06000102 RID: 258 RVA: 0x00003B61 File Offset: 0x00001D61
	private void method_43(GEnum2 genum2_1)
	{
		this.bool_3 = false;
		this.long_2 = 0L;
		this.long_3 = this.gclass8_0.method_11(genum2_1);
		this.bool_3 = true;
	}

	// Token: 0x06000103 RID: 259 RVA: 0x00003B8B File Offset: 0x00001D8B
	private bool method_44()
	{
		return this.Boolean_5 && this.int_9 < this.int_7;
	}

	// Token: 0x06000104 RID: 260 RVA: 0x00003BA5 File Offset: 0x00001DA5
	private GClass8 method_45()
	{
		this.Dispose();
		Thread.Sleep(this.int_8);
		this.int_9++;
		return this.method_38(this.genum2_0, this.Uri_1, this.gclass9_0);
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00003BDE File Offset: 0x00001DDE
	private GClass8 method_46()
	{
		this.Dispose();
		this.bool_2 = true;
		return this.method_38(this.genum2_0, this.Uri_1, this.gclass9_0);
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00023CB0 File Offset: 0x00021EB0
	private void method_47(GEnum3 genum3_0)
	{
		if (genum3_0 >= GEnum3.BadRequest && genum3_0 < GEnum3.InternalServerError)
		{
			throw new GException1(string.Format(Class2.String_13, (int)genum3_0), GEnum0.ProtocolError, this.gclass8_0.GEnum3_0, null);
		}
		if (genum3_0 >= GEnum3.InternalServerError)
		{
			throw new GException1(string.Format(Class2.String_25, (int)genum3_0), GEnum0.ProtocolError, this.gclass8_0.GEnum3_0, null);
		}
	}

	// Token: 0x06000107 RID: 263 RVA: 0x00003C05 File Offset: 0x00001E05
	private bool method_48(GEnum2 genum2_1)
	{
		return genum2_1 == GEnum2.PUT || genum2_1 == GEnum2.POST || genum2_1 == GEnum2.DELETE;
	}

	// Token: 0x06000108 RID: 264 RVA: 0x00023D20 File Offset: 0x00021F20
	private GClass16 method_49()
	{
		if (GClass7.Boolean_1)
		{
			try
			{
				IPAddress obj = IPAddress.Parse("127.0.0.1");
				IPAddress[] hostAddresses = Dns.GetHostAddresses(this.Uri_1.Host);
				for (int i = 0; i < hostAddresses.Length; i++)
				{
					if (hostAddresses[i].Equals(obj))
					{
						return null;
					}
				}
				goto IL_6B;
			}
			catch (Exception ex)
			{
				if (!(ex is SocketException) && !(ex is ArgumentException))
				{
					throw;
				}
				throw this.method_66(Class2.String_17, ex, GEnum0.Other);
			}
			GClass16 result;
			return result;
		}
		IL_6B:
		GClass16 gclass = this.GClass16_1 ?? GClass7.GClass16_0;
		if (gclass == null && GClass7.Boolean_0 && !GClass4.Boolean_0)
		{
			gclass = GClass4.GClass18_0;
		}
		return gclass;
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00023DD0 File Offset: 0x00021FD0
	private TcpClient method_50(string string_2, int int_10)
	{
		GClass7.Class3 @class = new GClass7.Class3();
		if (this.gclass16_1 == null)
		{
			@class.tcpClient_0 = new TcpClient();
			@class.exception_0 = null;
			@class.manualResetEventSlim_0 = new ManualResetEventSlim();
			try
			{
				@class.tcpClient_0.BeginConnect(string_2, int_10, new AsyncCallback(@class.method_0), @class.tcpClient_0);
			}
			catch (Exception ex)
			{
				@class.tcpClient_0.Close();
				if (!(ex is SocketException) && !(ex is SecurityException))
				{
					throw;
				}
				throw this.method_66(Class2.String_16, ex, GEnum0.ConnectFailure);
			}
			if (!@class.manualResetEventSlim_0.Wait(this.int_2))
			{
				@class.tcpClient_0.Close();
				throw this.method_66(Class2.String_14, null, GEnum0.ConnectFailure);
			}
			if (@class.exception_0 != null)
			{
				@class.tcpClient_0.Close();
				if (@class.exception_0 is SocketException)
				{
					throw this.method_66(Class2.String_16, @class.exception_0, GEnum0.ConnectFailure);
				}
				throw @class.exception_0;
			}
			else
			{
				if (!@class.tcpClient_0.Connected)
				{
					@class.tcpClient_0.Close();
					throw this.method_66(Class2.String_16, null, GEnum0.ConnectFailure);
				}
				@class.tcpClient_0.SendTimeout = this.int_3;
				@class.tcpClient_0.ReceiveTimeout = this.int_3;
			}
		}
		else
		{
			try
			{
				@class.tcpClient_0 = this.gclass16_1.GClass16.\u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string_2, int_10, null);
			}
			catch (GException2 exception_)
			{
				throw this.method_66(Class2.String_16, exception_, GEnum0.ConnectFailure);
			}
		}
		return @class.tcpClient_0;
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00023F54 File Offset: 0x00022154
	private void method_51(Uri uri_2)
	{
		this.tcpClient_0 = this.method_50(uri_2.Host, uri_2.Port);
		this.networkStream_0 = this.tcpClient_0.GetStream();
		if (uri_2.Scheme.Equals("https", StringComparison.OrdinalIgnoreCase))
		{
			try
			{
				SslStream sslStream;
				if (this.remoteCertificateValidationCallback_0 == null)
				{
					sslStream = new SslStream(this.networkStream_0, false, GClass6.remoteCertificateValidationCallback_0);
				}
				else
				{
					sslStream = new SslStream(this.networkStream_0, false, this.remoteCertificateValidationCallback_0);
				}
				sslStream.AuthenticateAsClient(uri_2.Host);
				this.stream_0 = sslStream;
				goto IL_AD;
			}
			catch (Exception ex)
			{
				if (!(ex is IOException) && !(ex is AuthenticationException))
				{
					throw;
				}
				throw this.method_66(Class2.String_21, ex, GEnum0.ConnectFailure);
			}
		}
		this.stream_0 = this.networkStream_0;
		IL_AD:
		if (this.eventHandler_0 != null || this.eventHandler_1 != null)
		{
			GClass7.Stream0 stream = new GClass7.Stream0(this.stream_0, this.tcpClient_0.SendBufferSize);
			if (this.eventHandler_0 != null)
			{
				stream.Action_1 = new Action<int>(this.method_62);
			}
			if (this.eventHandler_1 != null)
			{
				stream.Action_0 = new Action<int>(this.method_63);
			}
			this.stream_0 = stream;
		}
	}

	// Token: 0x0600010B RID: 267 RVA: 0x00024080 File Offset: 0x00022280
	private string method_52(GEnum2 genum2_1)
	{
		string arg;
		if (this.gclass16_1 != null && (this.gclass16_1.GEnum4_0 == GEnum4.Http || this.gclass16_1.GEnum4_0 == GEnum4.Chain))
		{
			arg = this.Uri_1.AbsoluteUri;
		}
		else
		{
			arg = this.Uri_1.PathAndQuery;
		}
		return string.Format("{0} {1} HTTP/{2}\r\n", genum2_1, arg, GClass7.version_0);
	}

	// Token: 0x0600010C RID: 268 RVA: 0x000240E0 File Offset: 0x000222E0
	private string method_53(GEnum2 genum2_1, long long_4 = 0L, string string_2 = null)
	{
		Dictionary<string, string> dictionary = this.method_54(genum2_1, long_4, string_2);
		this.method_59(dictionary, this.dictionary_0);
		if (this.dictionary_1 != null && this.dictionary_1.Count > 0)
		{
			this.method_59(dictionary, this.dictionary_1);
		}
		if (this.GClass5_0 != null && this.GClass5_0.Count != 0 && !dictionary.ContainsKey("Cookie"))
		{
			dictionary["Cookie"] = this.GClass5_0.ToString();
		}
		return this.method_61(dictionary);
	}

	// Token: 0x0600010D RID: 269 RVA: 0x00024168 File Offset: 0x00022368
	private Dictionary<string, string> method_54(GEnum2 genum2_1, long long_4 = 0L, string string_2 = null)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		if (this.Uri_1.IsDefaultPort)
		{
			dictionary["Host"] = this.Uri_1.Host;
		}
		else
		{
			dictionary["Host"] = string.Format("{0}:{1}", this.Uri_1.Host, this.Uri_1.Port);
		}
		GClass18 gclass = null;
		if (this.gclass16_1 != null && this.gclass16_1.GEnum4_0 == GEnum4.Http)
		{
			gclass = (this.gclass16_1 as GClass18);
		}
		else if (this.gclass16_1 != null && this.gclass16_1.GEnum4_0 == GEnum4.Chain)
		{
			gclass = this.method_60(this.gclass16_1 as GClass17);
		}
		if (gclass != null)
		{
			if (this.Boolean_4)
			{
				dictionary["Proxy-Connection"] = "keep-alive";
			}
			else
			{
				dictionary["Proxy-Connection"] = "close";
			}
			if (!string.IsNullOrEmpty(gclass.GClass16.\u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E) || !string.IsNullOrEmpty(gclass.GClass16.\u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E))
			{
				dictionary["Proxy-Authorization"] = this.method_56(gclass);
			}
		}
		else if (this.Boolean_4)
		{
			dictionary["Connection"] = "keep-alive";
		}
		else
		{
			dictionary["Connection"] = "close";
		}
		if (!string.IsNullOrEmpty(this.String_0) || !string.IsNullOrEmpty(this.String_1))
		{
			dictionary["Authorization"] = this.method_55();
		}
		if (this.Boolean_6)
		{
			dictionary["Accept-Encoding"] = "gzip,deflate";
		}
		if (this.CultureInfo_0 != null)
		{
			dictionary["Accept-Language"] = this.method_57();
		}
		if (this.Encoding_0 != null)
		{
			dictionary["Accept-Charset"] = this.method_58();
		}
		if (this.method_48(genum2_1))
		{
			if (long_4 > 0L)
			{
				dictionary["Content-Type"] = string_2;
			}
			dictionary["Content-Length"] = long_4.ToString();
		}
		return dictionary;
	}

	// Token: 0x0600010E RID: 270 RVA: 0x0002434C File Offset: 0x0002254C
	private string method_55()
	{
		string arg = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", this.String_0, this.String_1)));
		return string.Format("Basic {0}", arg);
	}

	// Token: 0x0600010F RID: 271 RVA: 0x0002438C File Offset: 0x0002258C
	private string method_56(GClass18 gclass18_0)
	{
		string arg = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", gclass18_0.GClass16.\u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E, gclass18_0.GClass16.\u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E)));
		return string.Format("Basic {0}", arg);
	}

	// Token: 0x06000110 RID: 272 RVA: 0x000243CC File Offset: 0x000225CC
	private string method_57()
	{
		string name;
		if (this.CultureInfo_0 != null)
		{
			name = this.CultureInfo_0.Name;
		}
		else
		{
			name = CultureInfo.CurrentCulture.Name;
		}
		if (name.StartsWith("en"))
		{
			return name;
		}
		return string.Format("{0},{1};q=0.8,en-US;q=0.6,en;q=0.4", name, name.Substring(0, 2));
	}

	// Token: 0x06000111 RID: 273 RVA: 0x0002441C File Offset: 0x0002261C
	private string method_58()
	{
		if (this.Encoding_0 == Encoding.UTF8)
		{
			return "utf-8;q=0.7,*;q=0.3";
		}
		string webName;
		if (this.Encoding_0 == null)
		{
			webName = Encoding.Default.WebName;
		}
		else
		{
			webName = this.Encoding_0.WebName;
		}
		return string.Format("{0},utf-8;q=0.7,*;q=0.3", webName);
	}

	// Token: 0x06000112 RID: 274 RVA: 0x00024468 File Offset: 0x00022668
	private void method_59(Dictionary<string, string> dictionary_2, Dictionary<string, string> dictionary_3)
	{
		foreach (KeyValuePair<string, string> keyValuePair in dictionary_3)
		{
			dictionary_2[keyValuePair.Key] = keyValuePair.Value;
		}
	}

	// Token: 0x06000113 RID: 275 RVA: 0x000244C4 File Offset: 0x000226C4
	private GClass18 method_60(GClass17 gclass17_0)
	{
		GClass18 gclass = null;
		foreach (GClass16 gclass2 in gclass17_0.List_0)
		{
			if (gclass2.GEnum4_0 == GEnum4.Http)
			{
				gclass = (gclass2 as GClass18);
				if (string.IsNullOrEmpty(gclass.GClass16.\u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E))
				{
					if (string.IsNullOrEmpty(gclass.GClass16.\u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E))
					{
						continue;
					}
				}
				return gclass;
			}
			if (gclass2.GEnum4_0 == GEnum4.Chain)
			{
				GClass18 gclass3 = this.method_60(gclass2 as GClass17);
				if (gclass3 != null && (!string.IsNullOrEmpty(gclass3.GClass16.\u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E) || !string.IsNullOrEmpty(gclass3.GClass16.\u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E)))
				{
					return gclass3;
				}
			}
		}
		return gclass;
	}

	// Token: 0x06000114 RID: 276 RVA: 0x00024584 File Offset: 0x00022784
	private string method_61(Dictionary<string, string> dictionary_2)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, string> keyValuePair in dictionary_2)
		{
			stringBuilder.AppendFormat("{0}: {1}\r\n", keyValuePair.Key, keyValuePair.Value);
		}
		stringBuilder.AppendLine();
		return stringBuilder.ToString();
	}

	// Token: 0x06000115 RID: 277 RVA: 0x00003C15 File Offset: 0x00001E15
	private void method_62(int int_10)
	{
		this.long_0 += (long)int_10;
		this.vmethod_1(new GEventArgs1(this.long_0, this.long_1));
	}

	// Token: 0x06000116 RID: 278 RVA: 0x00003C3D File Offset: 0x00001E3D
	private void method_63(int int_10)
	{
		this.long_2 += (long)int_10;
		if (this.bool_3)
		{
			this.vmethod_2(new GEventArgs0(this.long_2, this.long_3));
		}
	}

	// Token: 0x06000117 RID: 279 RVA: 0x00003C6D File Offset: 0x00001E6D
	private bool method_64(string string_2)
	{
		return GClass7.list_0.Contains(string_2, StringComparer.OrdinalIgnoreCase);
	}

	// Token: 0x06000118 RID: 280 RVA: 0x00003C7F File Offset: 0x00001E7F
	private void method_65()
	{
		this.gclass9_0 = null;
		this.gclass3_1 = null;
		this.gclass3_0 = null;
		this.gclass13_0 = null;
		this.dictionary_1 = null;
	}

	// Token: 0x06000119 RID: 281 RVA: 0x00003CA4 File Offset: 0x00001EA4
	private GException1 method_66(string string_2, Exception exception_0 = null, GEnum0 genum0_0 = GEnum0.Other)
	{
		return new GException1(string.Format(string_2, this.Uri_1.Host), genum0_0, GEnum3.None, exception_0);
	}

	// Token: 0x0400004A RID: 74
	public static readonly Version version_0 = new Version(1, 1);

	// Token: 0x0400004B RID: 75
	private static readonly List<string> list_0 = new List<string>
	{
		"Accept-Encoding",
		"Content-Length",
		"Content-Type",
		"Connection",
		"Proxy-Connection",
		"Host"
	};

	// Token: 0x0400004C RID: 76
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x0400004D RID: 77
	[CompilerGenerated]
	private static bool bool_1;

	// Token: 0x0400004E RID: 78
	[CompilerGenerated]
	private static GClass16 gclass16_0;

	// Token: 0x0400004F RID: 79
	private GClass8 gclass8_0;

	// Token: 0x04000050 RID: 80
	private TcpClient tcpClient_0;

	// Token: 0x04000051 RID: 81
	private Stream stream_0;

	// Token: 0x04000052 RID: 82
	private NetworkStream networkStream_0;

	// Token: 0x04000053 RID: 83
	private GClass16 gclass16_1;

	// Token: 0x04000054 RID: 84
	private int int_0;

	// Token: 0x04000055 RID: 85
	private int int_1 = 5;

	// Token: 0x04000056 RID: 86
	private int int_2 = 60000;

	// Token: 0x04000057 RID: 87
	private int int_3 = 60000;

	// Token: 0x04000058 RID: 88
	private DateTime dateTime_0;

	// Token: 0x04000059 RID: 89
	private int int_4 = 30000;

	// Token: 0x0400005A RID: 90
	private int int_5 = 100;

	// Token: 0x0400005B RID: 91
	private int int_6;

	// Token: 0x0400005C RID: 92
	private bool bool_2;

	// Token: 0x0400005D RID: 93
	private int int_7 = 3;

	// Token: 0x0400005E RID: 94
	private int int_8 = 100;

	// Token: 0x0400005F RID: 95
	private int int_9;

	// Token: 0x04000060 RID: 96
	private GEnum2 genum2_0;

	// Token: 0x04000061 RID: 97
	private GClass9 gclass9_0;

	// Token: 0x04000062 RID: 98
	private readonly Dictionary<string, string> dictionary_0 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	// Token: 0x04000063 RID: 99
	private GClass3 gclass3_0;

	// Token: 0x04000064 RID: 100
	private GClass3 gclass3_1;

	// Token: 0x04000065 RID: 101
	private Dictionary<string, string> dictionary_1;

	// Token: 0x04000066 RID: 102
	private GClass13 gclass13_0;

	// Token: 0x04000067 RID: 103
	private long long_0;

	// Token: 0x04000068 RID: 104
	private long long_1;

	// Token: 0x04000069 RID: 105
	private long long_2;

	// Token: 0x0400006A RID: 106
	private long long_3;

	// Token: 0x0400006B RID: 107
	private bool bool_3;

	// Token: 0x0400006C RID: 108
	private EventHandler<GEventArgs1> eventHandler_0;

	// Token: 0x0400006D RID: 109
	private EventHandler<GEventArgs0> eventHandler_1;

	// Token: 0x0400006E RID: 110
	[CompilerGenerated]
	private Uri uri_0;

	// Token: 0x0400006F RID: 111
	[CompilerGenerated]
	private Uri uri_1;

	// Token: 0x04000070 RID: 112
	[CompilerGenerated]
	private GClass16 gclass16_2;

	// Token: 0x04000071 RID: 113
	public RemoteCertificateValidationCallback remoteCertificateValidationCallback_0;

	// Token: 0x04000072 RID: 114
	[CompilerGenerated]
	private bool bool_4;

	// Token: 0x04000073 RID: 115
	[CompilerGenerated]
	private bool bool_5;

	// Token: 0x04000074 RID: 116
	[CompilerGenerated]
	private bool bool_6;

	// Token: 0x04000075 RID: 117
	[CompilerGenerated]
	private bool bool_7;

	// Token: 0x04000076 RID: 118
	[CompilerGenerated]
	private CultureInfo cultureInfo_0;

	// Token: 0x04000077 RID: 119
	[CompilerGenerated]
	private Encoding encoding_0;

	// Token: 0x04000078 RID: 120
	[CompilerGenerated]
	private bool bool_8;

	// Token: 0x04000079 RID: 121
	[CompilerGenerated]
	private string string_0;

	// Token: 0x0400007A RID: 122
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400007B RID: 123
	[CompilerGenerated]
	private GClass5 gclass5_0;

	// Token: 0x02000012 RID: 18
	private sealed class Stream0 : Stream
	{
		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600011B RID: 283 RVA: 0x00003CBF File Offset: 0x00001EBF
		// (set) Token: 0x0600011C RID: 284 RVA: 0x00003CC7 File Offset: 0x00001EC7
		public Action<int> Action_0 { get; set; }

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600011D RID: 285 RVA: 0x00003CD0 File Offset: 0x00001ED0
		// (set) Token: 0x0600011E RID: 286 RVA: 0x00003CD8 File Offset: 0x00001ED8
		public Action<int> Action_1 { get; set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600011F RID: 287 RVA: 0x00003CE1 File Offset: 0x00001EE1
		public bool CanRead
		{
			get
			{
				return this.stream_0.CanRead;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000120 RID: 288 RVA: 0x00003CEE File Offset: 0x00001EEE
		public bool CanSeek
		{
			get
			{
				return this.stream_0.CanSeek;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000121 RID: 289 RVA: 0x00003CFB File Offset: 0x00001EFB
		public bool CanTimeout
		{
			get
			{
				return this.stream_0.CanTimeout;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000122 RID: 290 RVA: 0x00003D08 File Offset: 0x00001F08
		public bool CanWrite
		{
			get
			{
				return this.stream_0.CanWrite;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000123 RID: 291 RVA: 0x00003D15 File Offset: 0x00001F15
		public long Length
		{
			get
			{
				return this.stream_0.Length;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000124 RID: 292 RVA: 0x00003D22 File Offset: 0x00001F22
		// (set) Token: 0x06000125 RID: 293 RVA: 0x00003D2F File Offset: 0x00001F2F
		public long Position
		{
			get
			{
				return this.stream_0.Position;
			}
			set
			{
				this.stream_0.Position = value;
			}
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00003D3D File Offset: 0x00001F3D
		public Stream0(Stream stream_1, int int_1)
		{
			this.stream_0 = stream_1;
			this.int_0 = int_1;
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00002E18 File Offset: 0x00001018
		public void Flush()
		{
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00003D53 File Offset: 0x00001F53
		public void SetLength(long value)
		{
			this.stream_0.SetLength(value);
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00003D61 File Offset: 0x00001F61
		public long Seek(long offset, SeekOrigin origin)
		{
			return this.stream_0.Seek(offset, origin);
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00024664 File Offset: 0x00022864
		public int Read(byte[] buffer, int offset, int count)
		{
			int num = this.stream_0.Read(buffer, offset, count);
			if (this.Action_0 != null)
			{
				this.Action_0(num);
			}
			return num;
		}

		// Token: 0x0600012B RID: 299 RVA: 0x00024698 File Offset: 0x00022898
		public void Write(byte[] buffer, int offset, int count)
		{
			if (this.Action_1 == null)
			{
				this.stream_0.Write(buffer, offset, count);
				return;
			}
			int num = 0;
			while (count > 0)
			{
				int num2;
				if (count >= this.int_0)
				{
					num2 = this.int_0;
					this.stream_0.Write(buffer, num, num2);
					num += this.int_0;
					count -= this.int_0;
				}
				else
				{
					num2 = count;
					this.stream_0.Write(buffer, num, num2);
					count = 0;
				}
				this.Action_1(num2);
			}
		}

		// Token: 0x0400007C RID: 124
		private Stream stream_0;

		// Token: 0x0400007D RID: 125
		private int int_0;

		// Token: 0x0400007E RID: 126
		[CompilerGenerated]
		private Action<int> action_0;

		// Token: 0x0400007F RID: 127
		[CompilerGenerated]
		private Action<int> action_1;
	}

	// Token: 0x02000013 RID: 19
	[CompilerGenerated]
	private sealed class Class3
	{
		// Token: 0x0600012D RID: 301 RVA: 0x00024718 File Offset: 0x00022918
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				this.tcpClient_0.EndConnect(iasyncResult_0);
			}
			catch (Exception ex)
			{
				this.exception_0 = ex;
			}
			this.manualResetEventSlim_0.Set();
		}

		// Token: 0x04000080 RID: 128
		public TcpClient tcpClient_0;

		// Token: 0x04000081 RID: 129
		public Exception exception_0;

		// Token: 0x04000082 RID: 130
		public ManualResetEventSlim manualResetEventSlim_0;
	}
}
