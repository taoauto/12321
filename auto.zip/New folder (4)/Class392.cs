﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

// Token: 0x020002C5 RID: 709
internal class Class392
{
	// Token: 0x06002798 RID: 10136 RVA: 0x00119208 File Offset: 0x00117408
	public Class392(string string_2, string string_3)
	{
		uint[] array = new uint[3];
		array[1] = 12U;
		this.UInt32_37 = array;
		this.uint_42 = new uint[2];
		this.UInt32_39 = new uint[]
		{
			8973056U,
			18292U
		};
		this.UInt32_40 = 7037684U;
		this.UInt32_41 = new uint[]
		{
			9892704U,
			112U,
			480U,
			4U,
			9616U,
			4U
		};
		this.UInt32_43 = 7877144U;
		this.UInt32_46 = new uint[2];
		this.UInt32_47 = new uint[]
		{
			0U,
			52U
		};
		this.UInt32_53 = new uint[]
		{
			8973040U,
			100U
		};
		this.UInt32_55 = new uint[]
		{
			0U,
			117652U
		};
		this.UInt32_57 = new uint[]
		{
			19715604U,
			18732U,
			12U
		};
		this.UInt32_58 = new uint[2];
		this.UInt32_60 = new uint[]
		{
			0U,
			0U,
			12U,
			100U
		};
		this.UInt32_61 = new uint[2];
		this.UInt32_62 = new uint[2];
		this.UInt32_63 = new uint[2];
		this.UInt32_66 = new uint[2];
		this.UInt32_68 = new uint[3];
		this.UInt32_69 = new uint[3];
		this.uint_91 = new uint[]
		{
			0U,
			64U
		};
		this.UInt32_120 = new uint[4];
		this.UInt32_122 = new uint[]
		{
			9728384U,
			8U,
			4U,
			324U
		};
		uint[] array2 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		array2[0] = Class268.UInt32_0 + 9678512U;
		this.UInt32_123 = array2;
		this.UInt32_124 = new uint[]
		{
			9728216U,
			8U,
			4U,
			324U
		};
		this.UInt32_125 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_126 = new uint[]
		{
			9731936U,
			8U,
			4U,
			324U
		};
		this.UInt32_127 = new uint[]
		{
			9741224U,
			8U,
			4U,
			324U
		};
		this.UInt32_128 = new uint[]
		{
			9728072U,
			8U,
			4U,
			324U
		};
		this.UInt32_129 = new uint[]
		{
			828592U,
			2016U,
			1904U,
			0U,
			228U,
			860U
		};
		this.UInt32_130 = new uint[]
		{
			11400376U,
			8U,
			4U,
			324U
		};
		this.UInt32_132 = new uint[]
		{
			19847460U,
			807104U
		};
		this.UInt32_135 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_136 = new uint[]
		{
			11406184U,
			40U,
			36U,
			56U,
			1760U
		};
		this.UInt32_137 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_138 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_141 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_142 = new uint[]
		{
			0U,
			116832U,
			32U
		};
		uint[] array3 = new uint[3];
		array3[1] = 117728U;
		this.UInt32_143 = array3;
		this.UInt32_144 = new uint[]
		{
			0U,
			116832U,
			36U,
			8U
		};
		this.UInt32_145 = new uint[]
		{
			0U,
			116832U,
			40U,
			8U
		};
		this.UInt32_146 = new uint[]
		{
			Class268.UInt32_0 + 11165368U,
			117076U
		};
		this.UInt32_149 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_150 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_151 = new uint[]
		{
			11735956U,
			4U,
			172U,
			600U,
			8U,
			860U
		};
		this.UInt32_152 = new uint[]
		{
			0U,
			172U,
			1780U,
			292U,
			1808U,
			1976U
		};
		this.UInt32_153 = new uint[]
		{
			0U,
			0U,
			1884U,
			736U,
			252U,
			100U
		};
		this.UInt32_155 = 58960U;
		this.UInt32_156 = new uint[]
		{
			0U,
			117808U
		};
		this.UInt32_157 = new uint[]
		{
			0U,
			64U,
			4U,
			1236U
		};
		this.UInt32_158 = new uint[]
		{
			0U,
			84U,
			436U
		};
		base..ctor();
		try
		{
			this.method_0(string_2, string_3);
		}
		catch
		{
		}
	}

	// Token: 0x06002799 RID: 10137 RVA: 0x00119644 File Offset: 0x00117844
	public Class392(string string_2, string string_3, uint uint_164)
	{
		uint[] array = new uint[3];
		array[1] = 12U;
		this.UInt32_37 = array;
		this.uint_42 = new uint[2];
		this.UInt32_39 = new uint[]
		{
			8973056U,
			18292U
		};
		this.UInt32_40 = 7037684U;
		this.UInt32_41 = new uint[]
		{
			9892704U,
			112U,
			480U,
			4U,
			9616U,
			4U
		};
		this.UInt32_43 = 7877144U;
		this.UInt32_46 = new uint[2];
		this.UInt32_47 = new uint[]
		{
			0U,
			52U
		};
		this.UInt32_53 = new uint[]
		{
			8973040U,
			100U
		};
		this.UInt32_55 = new uint[]
		{
			0U,
			117652U
		};
		this.UInt32_57 = new uint[]
		{
			19715604U,
			18732U,
			12U
		};
		this.UInt32_58 = new uint[2];
		this.UInt32_60 = new uint[]
		{
			0U,
			0U,
			12U,
			100U
		};
		this.UInt32_61 = new uint[2];
		this.UInt32_62 = new uint[2];
		this.UInt32_63 = new uint[2];
		this.UInt32_66 = new uint[2];
		this.UInt32_68 = new uint[3];
		this.UInt32_69 = new uint[3];
		this.uint_91 = new uint[]
		{
			0U,
			64U
		};
		this.UInt32_120 = new uint[4];
		this.UInt32_122 = new uint[]
		{
			9728384U,
			8U,
			4U,
			324U
		};
		uint[] array2 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		array2[0] = Class268.UInt32_0 + 9678512U;
		this.UInt32_123 = array2;
		this.UInt32_124 = new uint[]
		{
			9728216U,
			8U,
			4U,
			324U
		};
		this.UInt32_125 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_126 = new uint[]
		{
			9731936U,
			8U,
			4U,
			324U
		};
		this.UInt32_127 = new uint[]
		{
			9741224U,
			8U,
			4U,
			324U
		};
		this.UInt32_128 = new uint[]
		{
			9728072U,
			8U,
			4U,
			324U
		};
		this.UInt32_129 = new uint[]
		{
			828592U,
			2016U,
			1904U,
			0U,
			228U,
			860U
		};
		this.UInt32_130 = new uint[]
		{
			11400376U,
			8U,
			4U,
			324U
		};
		this.UInt32_132 = new uint[]
		{
			19847460U,
			807104U
		};
		this.UInt32_135 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_136 = new uint[]
		{
			11406184U,
			40U,
			36U,
			56U,
			1760U
		};
		this.UInt32_137 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_138 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_141 = new uint[]
		{
			0U,
			8U,
			4U,
			324U
		};
		this.UInt32_142 = new uint[]
		{
			0U,
			116832U,
			32U
		};
		uint[] array3 = new uint[3];
		array3[1] = 117728U;
		this.UInt32_143 = array3;
		this.UInt32_144 = new uint[]
		{
			0U,
			116832U,
			36U,
			8U
		};
		this.UInt32_145 = new uint[]
		{
			0U,
			116832U,
			40U,
			8U
		};
		this.UInt32_146 = new uint[]
		{
			Class268.UInt32_0 + 11165368U,
			117076U
		};
		this.UInt32_149 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_150 = new uint[]
		{
			0U,
			8U,
			4U,
			332U
		};
		this.UInt32_151 = new uint[]
		{
			11735956U,
			4U,
			172U,
			600U,
			8U,
			860U
		};
		this.UInt32_152 = new uint[]
		{
			0U,
			172U,
			1780U,
			292U,
			1808U,
			1976U
		};
		this.UInt32_153 = new uint[]
		{
			0U,
			0U,
			1884U,
			736U,
			252U,
			100U
		};
		this.UInt32_155 = 58960U;
		this.UInt32_156 = new uint[]
		{
			0U,
			117808U
		};
		this.UInt32_157 = new uint[]
		{
			0U,
			64U,
			4U,
			1236U
		};
		this.UInt32_158 = new uint[]
		{
			0U,
			84U,
			436U
		};
		base..ctor();
		try
		{
			this.uint_1 = uint_164;
			this.method_0(string_2, string_3);
		}
		catch
		{
		}
	}

	// Token: 0x170008A8 RID: 2216
	// (get) Token: 0x0600279A RID: 10138 RVA: 0x0001D5F7 File Offset: 0x0001B7F7
	public bool Boolean_0
	{
		get
		{
			return !this.Boolean_1 && this.UInt32_106 == 1U;
		}
	}

	// Token: 0x0600279B RID: 10139 RVA: 0x00119A84 File Offset: 0x00117C84
	public static Class392 smethod_0(string string_2, string string_3)
	{
		if (!Class392.dictionary_0.ContainsKey(string_2))
		{
			Class392 @class = new Class392(string_2, string_3);
			Class392.dictionary_0.Add(string_2, @class);
			return @class;
		}
		return Class392.dictionary_0[string_2];
	}

	// Token: 0x0600279C RID: 10140 RVA: 0x00119AC0 File Offset: 0x00117CC0
	public static Class392 smethod_1(string string_2, string string_3, uint uint_164)
	{
		if (!Class392.dictionary_0.ContainsKey(string_2))
		{
			Class392 @class = new Class392(string_2, string_3, uint_164);
			Class392.dictionary_0.Add(string_2, @class);
			return @class;
		}
		return Class392.dictionary_0[string_2];
	}

	// Token: 0x0600279D RID: 10141 RVA: 0x00119A84 File Offset: 0x00117C84
	public static Class392 smethod_2(string string_2, string string_3)
	{
		if (!Class392.dictionary_0.ContainsKey(string_2))
		{
			Class392 @class = new Class392(string_2, string_3);
			Class392.dictionary_0.Add(string_2, @class);
			return @class;
		}
		return Class392.dictionary_0[string_2];
	}

	// Token: 0x170008A9 RID: 2217
	// (get) Token: 0x0600279E RID: 10142 RVA: 0x0001D60D File Offset: 0x0001B80D
	// (set) Token: 0x0600279F RID: 10143 RVA: 0x0001D615 File Offset: 0x0001B815
	public bool Boolean_1 { get; set; }

	// Token: 0x060027A0 RID: 10144 RVA: 0x00119AFC File Offset: 0x00117CFC
	private void method_0(string string_2, string string_3)
	{
		int num = string_3.IndexOf(string_2);
		string text = string_3.Substring(0, num);
		text = Regex.Replace(text, ".*FFFF", "");
		num = string_3.IndexOf(text);
		this.string_0 = string_3.Substring(num);
		this.method_1();
		this.UInt32_106 = this.uint_0[0];
		if (this.UInt32_106 == 9U)
		{
			this.UInt32_106 = 1U;
			this.Boolean_1 = true;
		}
		this.method_1();
		this.UInt32_2 = this.uint_0;
		this.UInt32_2[0] = this.uint_1 + this.UInt32_2[0];
		this.method_1();
		this.UInt32_3 = this.uint_0[0];
		this.UInt32_4 = this.uint_0[1];
		this.UInt32_5 = this.uint_0[2];
		this.UInt32_6 = this.uint_0[3];
		this.UInt32_7 = this.uint_0[4];
		this.UInt32_8 = this.uint_0[5];
		this.UInt32_9 = this.uint_0[6];
		this.UInt32_10 = this.uint_0[7];
		this.UInt32_17 = this.uint_0[8];
		this.UInt32_11 = this.uint_0[9];
		this.UInt32_12 = this.uint_0[10];
		this.UInt32_13 = this.uint_0[11];
		this.UInt32_14 = this.uint_0[12];
		this.UInt32_15 = this.uint_0[13];
		this.UInt32_16 = this.uint_0[14];
		this.UInt32_24 = this.uint_0[15];
		this.UInt32_25 = this.uint_0[16];
		this.UInt32_26 = this.uint_0[17];
		this.UInt32_27 = this.uint_0[18];
		this.UInt32_28 = this.uint_0[19];
		this.method_1();
		this.UInt32_58 = this.uint_0;
		this.UInt32_156[0] = (this.UInt32_58[0] = this.uint_1 + this.UInt32_58[0]);
		this.method_1();
		this.UInt32_59 = this.uint_0;
		this.UInt32_158[0] = (this.UInt32_59[0] = this.uint_1 + this.UInt32_59[0]);
		this.method_1();
		this.UInt32_60 = this.uint_0;
		this.UInt32_60[0] = this.uint_1 + this.UInt32_60[0];
		this.method_1();
		this.UInt32_61 = this.uint_0;
		this.UInt32_61[0] = this.uint_1 + this.UInt32_61[0];
		this.method_1();
		this.UInt32_62 = this.uint_0;
		this.UInt32_157[0] = (this.UInt32_62[0] = this.uint_1 + this.UInt32_62[0]);
		this.method_1();
		this.UInt32_63 = this.uint_0;
		this.UInt32_63[0] = this.uint_1 + this.UInt32_63[0];
		this.method_1();
		this.UInt32_64 = this.uint_0;
		this.UInt32_64[0] = this.uint_1 + this.UInt32_64[0];
		this.method_1();
		this.UInt32_65 = this.uint_0;
		this.UInt32_65[0] = this.uint_1 + this.UInt32_65[0];
		this.method_1();
		this.UInt32_66 = this.uint_0;
		this.UInt32_66[0] = this.uint_1 + this.UInt32_66[0];
		this.UInt32_151[0] = this.UInt32_66[0];
		this.UInt32_152[0] = this.UInt32_66[0] + 4U;
		this.method_1();
		this.UInt32_67 = this.uint_0;
		this.UInt32_67[0] = this.uint_1 + this.UInt32_67[0];
		this.method_1();
		this.UInt32_68 = this.uint_0;
		this.UInt32_68[0] = this.uint_1 + this.UInt32_68[0];
		this.method_1();
		this.UInt32_69 = this.uint_0;
		this.UInt32_69[0] = this.uint_1 + this.UInt32_69[0];
		this.method_1();
		this.UInt32_70 = this.uint_0[0];
		this.UInt32_71 = this.uint_0[1];
		this.UInt32_72 = this.uint_0[2];
		this.UInt32_73 = this.uint_0[3];
		this.UInt32_30 = this.uint_0[4];
		this.UInt32_31 = this.uint_0[5];
		this.UInt32_32 = this.uint_0[6];
		this.UInt32_33 = this.uint_0[7];
		this.method_1();
		this.UInt32_74 = this.uint_0;
		this.method_1();
		this.UInt32_75 = this.uint_0[0];
		this.UInt32_76 = this.uint_0[1];
		this.UInt32_77 = this.uint_0[2];
		this.UInt32_78 = this.uint_0[3];
		this.UInt32_79 = this.uint_0[4];
		this.UInt32_81 = this.uint_0[5];
		this.UInt32_82 = this.uint_0[6];
		this.UInt32_83 = this.uint_0[7];
		this.UInt32_84 = this.uint_0[8];
		this.UInt32_80 = this.uint_0[9];
		this.UInt32_85 = this.uint_0[10];
		this.method_1();
		this.UInt32_47 = this.uint_0;
		this.UInt32_47[0] = this.uint_1 + this.UInt32_47[0];
		this.method_1();
		this.UInt32_44 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_99 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_105 = this.uint_0;
		this.UInt32_105[0] = this.uint_1 + this.UInt32_105[0];
		this.method_1();
		this.UInt32_97 = this.uint_0;
		this.UInt32_97[0] = this.uint_1 + this.UInt32_97[0];
		this.method_1();
		this.uint_42 = this.uint_0;
		this.uint_42[0] = this.uint_1 + this.uint_42[0];
		this.method_1();
		this.UInt32_54 = this.uint_0;
		this.UInt32_54[0] = this.uint_1 + this.UInt32_54[0];
		this.method_1();
		this.UInt32_113 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_114 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_115 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_116 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_117 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_118 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_46 = this.uint_0;
		this.UInt32_46[0] = this.uint_1 + this.UInt32_46[0];
		this.method_1();
		this.UInt32_119 = this.uint_0;
		this.UInt32_119[0] = this.uint_1 + this.UInt32_119[0];
		this.method_1();
		this.UInt32_101 = this.uint_0;
		this.UInt32_101[0] = this.uint_1 + this.UInt32_101[0];
		this.method_1();
		try
		{
			this.UInt32_108 = this.uint_1 + this.uint_0[0];
			this.UInt32_109 = this.uint_0[1];
			this.UInt32_110 = this.uint_0[2];
			this.UInt32_111 = this.uint_0[3];
			if (Class268.Int32_13 == 0)
			{
				Class268.Int32_13 = (int)this.UInt32_111;
			}
			this.UInt32_112 = this.uint_0[4];
		}
		catch
		{
		}
		this.method_1();
		this.UInt32_107 = this.uint_0;
		this.UInt32_107[0] = this.uint_1 + this.UInt32_107[0];
		this.method_1();
		this.UInt32_1 = this.uint_0;
		this.UInt32_1[0] = this.uint_1 + this.UInt32_1[0];
		this.method_1();
		this.UInt32_0 = this.uint_0;
		this.UInt32_0[0] = this.uint_1 + this.UInt32_0[0];
		this.method_1();
		this.UInt32_134 = this.uint_0;
		this.UInt32_134[0] = this.uint_1 + this.UInt32_134[0];
		this.method_1();
		this.UInt32_122 = this.uint_0;
		this.UInt32_122[0] = this.uint_1 + this.UInt32_122[0];
		this.method_1();
		this.UInt32_124 = this.uint_0;
		this.UInt32_124[0] = this.uint_1 + this.UInt32_124[0];
		this.method_1();
		this.UInt32_126 = this.uint_0;
		this.UInt32_126[0] = this.uint_1 + this.UInt32_126[0];
		this.method_1();
		this.UInt32_127 = this.uint_0;
		this.UInt32_127[0] = this.uint_1 + this.UInt32_127[0];
		this.method_1();
		this.UInt32_128 = this.uint_0;
		this.UInt32_128[0] = this.uint_1 + this.UInt32_128[0];
		this.method_1();
		this.UInt32_133 = this.uint_0;
		this.UInt32_133[0] = this.uint_1 + this.UInt32_133[0];
		this.method_1();
		this.UInt32_132 = this.uint_0;
		this.UInt32_132[0] = this.uint_1 + this.UInt32_132[0];
		this.method_1();
		this.UInt32_102 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_40 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_29 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_86 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.uint_91 = this.uint_0;
		this.uint_91[0] = this.uint_1 + this.uint_91[0];
		this.method_1();
		this.UInt32_36 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_37 = this.uint_0;
		this.UInt32_37[0] = this.uint_1 + this.UInt32_37[0];
		this.method_1();
		this.UInt32_35 = this.uint_1 + this.uint_0[0];
		this.UInt32_53[0] = this.UInt32_47[0];
		this.UInt32_34 = this.UInt32_58[0];
		this.method_1();
		this.UInt32_104 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_103 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_87 = (this.UInt32_42 = this.uint_1 + this.uint_0[0]);
		this.method_1();
		this.UInt32_95 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_98 = this.uint_0;
		this.UInt32_98[0] = this.uint_1 + this.UInt32_98[0];
		this.method_1();
		this.UInt32_100 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_96 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_120 = this.uint_0;
		this.UInt32_120[0] = this.uint_1 + this.UInt32_120[0];
		this.UInt32_120[3] = this.uint_1 + this.UInt32_120[3];
		this.method_1();
		this.UInt32_56 = this.uint_0;
		this.UInt32_56[0] = this.uint_1 + this.UInt32_56[0];
		this.method_1();
		this.UInt32_121 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_131 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_139 = this.uint_1 + this.uint_0[0];
		this.method_1();
		this.UInt32_140 = this.uint_1 + this.uint_0[0];
		this.UInt32_142[0] = (this.UInt32_143[0] = this.UInt32_54[0]);
		if (this.UInt32_106 != 1U)
		{
			uint[] uint32_ = this.UInt32_142;
			int num2 = 1;
			uint[] uint32_2 = this.UInt32_145;
			int num3 = 1;
			this.UInt32_144[1] = 840U;
			uint32_2[num3] = 840;
			uint32_[num2] = 840;
		}
		this.UInt32_144[0] = (this.UInt32_145[0] = this.UInt32_54[0]);
		if (this.UInt32_106 == 1U)
		{
			this.UInt32_147 = 36U;
			this.UInt32_148 = 56U;
		}
		else
		{
			this.UInt32_147 = 28U;
			this.UInt32_148 = 52U;
		}
		this.UInt32_55[0] = this.UInt32_54[0];
		this.method_1();
		this.String_0 = this.uint_0[0].ToString("x4") + this.uint_0[1].ToString("x4") + this.uint_0[2].ToString("x4") + this.uint_0[3].ToString("x4");
		this.method_1();
		this.UInt32_130 = this.uint_0;
		this.UInt32_130[0] = this.uint_1 + this.UInt32_130[0];
		this.method_1();
		this.uint_2 = this.uint_1 + this.uint_0[0];
	}

	// Token: 0x060027A1 RID: 10145 RVA: 0x0011A884 File Offset: 0x00118A84
	private void method_1()
	{
		this.string_0 = this.string_0.Remove(0, this.string_0.IndexOf("00FF") + 4);
		string text = this.string_0.Substring(0, this.string_0.IndexOf("00FF"));
		int length = text.Length;
		if (length % 2 == 1)
		{
			this.uint_0 = new uint[length / 6];
			this.method_4(text.Substring(0, 7), out this.uint_0[0]);
			for (int i = 1; i < this.uint_0.Length; i++)
			{
				this.method_4(text.Substring(i * 6 + 1, 6), out this.uint_0[i]);
			}
			return;
		}
		this.uint_0 = new uint[length / 4];
		this.method_4(text.Substring(0, 4), out this.uint_0[0]);
		for (int j = 1; j < this.uint_0.Length; j++)
		{
			this.method_4(text.Substring(j * 4, 4), out this.uint_0[j]);
		}
	}

	// Token: 0x060027A2 RID: 10146 RVA: 0x0011A994 File Offset: 0x00118B94
	private void method_2()
	{
		this.string_0 = this.string_0.Remove(0, this.string_0.IndexOf("00FF") + 4);
		string text = this.string_0.Substring(0, this.string_0.IndexOf("00FF"));
		int length = text.Length;
		this.uint_0 = new uint[length / 7];
		this.method_4(text.Substring(0, 7), out this.uint_0[0]);
		for (int i = 1; i < this.uint_0.Length; i++)
		{
			this.method_4(text.Substring(i * 7, 7), out this.uint_0[i]);
		}
	}

	// Token: 0x060027A3 RID: 10147 RVA: 0x0001D61E File Offset: 0x0001B81E
	private void method_3(string string_2, out int int_0)
	{
		int.TryParse(string_2, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int_0);
	}

	// Token: 0x060027A4 RID: 10148 RVA: 0x0001D632 File Offset: 0x0001B832
	private void method_4(string string_2, out uint uint_164)
	{
		uint.TryParse(string_2, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out uint_164);
	}

	// Token: 0x170008AA RID: 2218
	// (get) Token: 0x060027A5 RID: 10149 RVA: 0x0001D646 File Offset: 0x0001B846
	// (set) Token: 0x060027A6 RID: 10150 RVA: 0x0001D64E File Offset: 0x0001B84E
	public uint[] UInt32_0 { get; set; }

	// Token: 0x170008AB RID: 2219
	// (get) Token: 0x060027A7 RID: 10151 RVA: 0x0001D657 File Offset: 0x0001B857
	// (set) Token: 0x060027A8 RID: 10152 RVA: 0x0001D65F File Offset: 0x0001B85F
	public uint[] UInt32_1 { get; set; }

	// Token: 0x170008AC RID: 2220
	// (get) Token: 0x060027A9 RID: 10153 RVA: 0x0001D668 File Offset: 0x0001B868
	// (set) Token: 0x060027AA RID: 10154 RVA: 0x0001D670 File Offset: 0x0001B870
	public uint[] UInt32_2 { get; set; } = new uint[]
	{
		0U,
		0U,
		0U,
		4U
	};

	// Token: 0x170008AD RID: 2221
	// (get) Token: 0x060027AB RID: 10155 RVA: 0x0001D679 File Offset: 0x0001B879
	// (set) Token: 0x060027AC RID: 10156 RVA: 0x0001D681 File Offset: 0x0001B881
	public uint UInt32_3 { get; set; }

	// Token: 0x170008AE RID: 2222
	// (get) Token: 0x060027AD RID: 10157 RVA: 0x0001D68A File Offset: 0x0001B88A
	// (set) Token: 0x060027AE RID: 10158 RVA: 0x0001D692 File Offset: 0x0001B892
	public uint UInt32_4 { get; set; }

	// Token: 0x170008AF RID: 2223
	// (get) Token: 0x060027AF RID: 10159 RVA: 0x0001D69B File Offset: 0x0001B89B
	// (set) Token: 0x060027B0 RID: 10160 RVA: 0x0001D6A3 File Offset: 0x0001B8A3
	public uint UInt32_5 { get; set; }

	// Token: 0x170008B0 RID: 2224
	// (get) Token: 0x060027B1 RID: 10161 RVA: 0x0001D6AC File Offset: 0x0001B8AC
	// (set) Token: 0x060027B2 RID: 10162 RVA: 0x0001D6B4 File Offset: 0x0001B8B4
	public uint UInt32_6 { get; set; }

	// Token: 0x170008B1 RID: 2225
	// (get) Token: 0x060027B3 RID: 10163 RVA: 0x0001D6BD File Offset: 0x0001B8BD
	// (set) Token: 0x060027B4 RID: 10164 RVA: 0x0001D6C5 File Offset: 0x0001B8C5
	public uint UInt32_7 { get; set; }

	// Token: 0x170008B2 RID: 2226
	// (get) Token: 0x060027B5 RID: 10165 RVA: 0x0001D6CE File Offset: 0x0001B8CE
	// (set) Token: 0x060027B6 RID: 10166 RVA: 0x0001D6D6 File Offset: 0x0001B8D6
	public uint UInt32_8 { get; set; }

	// Token: 0x170008B3 RID: 2227
	// (get) Token: 0x060027B7 RID: 10167 RVA: 0x0001D6DF File Offset: 0x0001B8DF
	// (set) Token: 0x060027B8 RID: 10168 RVA: 0x0001D6E7 File Offset: 0x0001B8E7
	public uint UInt32_9 { get; set; }

	// Token: 0x170008B4 RID: 2228
	// (get) Token: 0x060027B9 RID: 10169 RVA: 0x0001D6F0 File Offset: 0x0001B8F0
	// (set) Token: 0x060027BA RID: 10170 RVA: 0x0001D6F8 File Offset: 0x0001B8F8
	public uint UInt32_10 { get; set; }

	// Token: 0x170008B5 RID: 2229
	// (get) Token: 0x060027BB RID: 10171 RVA: 0x0001D701 File Offset: 0x0001B901
	// (set) Token: 0x060027BC RID: 10172 RVA: 0x0001D709 File Offset: 0x0001B909
	public uint UInt32_11 { get; set; }

	// Token: 0x170008B6 RID: 2230
	// (get) Token: 0x060027BD RID: 10173 RVA: 0x0001D712 File Offset: 0x0001B912
	// (set) Token: 0x060027BE RID: 10174 RVA: 0x0001D71A File Offset: 0x0001B91A
	public uint UInt32_12 { get; set; }

	// Token: 0x170008B7 RID: 2231
	// (get) Token: 0x060027BF RID: 10175 RVA: 0x0001D723 File Offset: 0x0001B923
	// (set) Token: 0x060027C0 RID: 10176 RVA: 0x0001D72B File Offset: 0x0001B92B
	public uint UInt32_13 { get; set; }

	// Token: 0x170008B8 RID: 2232
	// (get) Token: 0x060027C1 RID: 10177 RVA: 0x0001D734 File Offset: 0x0001B934
	// (set) Token: 0x060027C2 RID: 10178 RVA: 0x0001D73C File Offset: 0x0001B93C
	public uint UInt32_14 { get; set; }

	// Token: 0x170008B9 RID: 2233
	// (get) Token: 0x060027C3 RID: 10179 RVA: 0x0001D745 File Offset: 0x0001B945
	// (set) Token: 0x060027C4 RID: 10180 RVA: 0x0001D74D File Offset: 0x0001B94D
	public uint UInt32_15 { get; set; }

	// Token: 0x170008BA RID: 2234
	// (get) Token: 0x060027C5 RID: 10181 RVA: 0x0001D756 File Offset: 0x0001B956
	// (set) Token: 0x060027C6 RID: 10182 RVA: 0x0001D75E File Offset: 0x0001B95E
	public uint UInt32_16 { get; set; }

	// Token: 0x170008BB RID: 2235
	// (get) Token: 0x060027C7 RID: 10183 RVA: 0x0001D767 File Offset: 0x0001B967
	// (set) Token: 0x060027C8 RID: 10184 RVA: 0x0001D76F File Offset: 0x0001B96F
	public uint UInt32_17 { get; set; }

	// Token: 0x170008BC RID: 2236
	// (get) Token: 0x060027C9 RID: 10185 RVA: 0x0001D778 File Offset: 0x0001B978
	// (set) Token: 0x060027CA RID: 10186 RVA: 0x0001D780 File Offset: 0x0001B980
	public uint UInt32_18 { get; set; }

	// Token: 0x170008BD RID: 2237
	// (get) Token: 0x060027CB RID: 10187 RVA: 0x0001D789 File Offset: 0x0001B989
	// (set) Token: 0x060027CC RID: 10188 RVA: 0x0001D791 File Offset: 0x0001B991
	public uint UInt32_19 { get; set; }

	// Token: 0x170008BE RID: 2238
	// (get) Token: 0x060027CD RID: 10189 RVA: 0x0001D79A File Offset: 0x0001B99A
	// (set) Token: 0x060027CE RID: 10190 RVA: 0x0001D7A2 File Offset: 0x0001B9A2
	public uint UInt32_20 { get; set; }

	// Token: 0x170008BF RID: 2239
	// (get) Token: 0x060027CF RID: 10191 RVA: 0x0001D7AB File Offset: 0x0001B9AB
	// (set) Token: 0x060027D0 RID: 10192 RVA: 0x0001D7B3 File Offset: 0x0001B9B3
	public uint UInt32_21 { get; set; }

	// Token: 0x170008C0 RID: 2240
	// (get) Token: 0x060027D1 RID: 10193 RVA: 0x0001D7BC File Offset: 0x0001B9BC
	// (set) Token: 0x060027D2 RID: 10194 RVA: 0x0001D7C4 File Offset: 0x0001B9C4
	public uint UInt32_22 { get; set; }

	// Token: 0x170008C1 RID: 2241
	// (get) Token: 0x060027D3 RID: 10195 RVA: 0x0001D7CD File Offset: 0x0001B9CD
	// (set) Token: 0x060027D4 RID: 10196 RVA: 0x0001D7D5 File Offset: 0x0001B9D5
	public uint UInt32_23 { get; set; }

	// Token: 0x170008C2 RID: 2242
	// (get) Token: 0x060027D5 RID: 10197 RVA: 0x0001D7DE File Offset: 0x0001B9DE
	// (set) Token: 0x060027D6 RID: 10198 RVA: 0x0001D7E6 File Offset: 0x0001B9E6
	public uint UInt32_24 { get; set; }

	// Token: 0x170008C3 RID: 2243
	// (get) Token: 0x060027D7 RID: 10199 RVA: 0x0001D7EF File Offset: 0x0001B9EF
	// (set) Token: 0x060027D8 RID: 10200 RVA: 0x0001D7F7 File Offset: 0x0001B9F7
	public uint UInt32_25 { get; set; }

	// Token: 0x170008C4 RID: 2244
	// (get) Token: 0x060027D9 RID: 10201 RVA: 0x0001D800 File Offset: 0x0001BA00
	// (set) Token: 0x060027DA RID: 10202 RVA: 0x0001D808 File Offset: 0x0001BA08
	public uint UInt32_26 { get; set; }

	// Token: 0x170008C5 RID: 2245
	// (get) Token: 0x060027DB RID: 10203 RVA: 0x0001D811 File Offset: 0x0001BA11
	// (set) Token: 0x060027DC RID: 10204 RVA: 0x0001D819 File Offset: 0x0001BA19
	public uint UInt32_27 { get; set; }

	// Token: 0x170008C6 RID: 2246
	// (get) Token: 0x060027DD RID: 10205 RVA: 0x0001D822 File Offset: 0x0001BA22
	// (set) Token: 0x060027DE RID: 10206 RVA: 0x0001D82A File Offset: 0x0001BA2A
	public uint UInt32_28 { get; set; }

	// Token: 0x170008C7 RID: 2247
	// (get) Token: 0x060027DF RID: 10207 RVA: 0x0001D833 File Offset: 0x0001BA33
	// (set) Token: 0x060027E0 RID: 10208 RVA: 0x0001D83B File Offset: 0x0001BA3B
	public uint UInt32_29 { get; set; }

	// Token: 0x170008C8 RID: 2248
	// (get) Token: 0x060027E1 RID: 10209 RVA: 0x0001D844 File Offset: 0x0001BA44
	// (set) Token: 0x060027E2 RID: 10210 RVA: 0x0001D84C File Offset: 0x0001BA4C
	public uint UInt32_30 { get; set; }

	// Token: 0x170008C9 RID: 2249
	// (get) Token: 0x060027E3 RID: 10211 RVA: 0x0001D855 File Offset: 0x0001BA55
	// (set) Token: 0x060027E4 RID: 10212 RVA: 0x0001D85D File Offset: 0x0001BA5D
	public uint UInt32_31 { get; set; }

	// Token: 0x170008CA RID: 2250
	// (get) Token: 0x060027E5 RID: 10213 RVA: 0x0001D866 File Offset: 0x0001BA66
	// (set) Token: 0x060027E6 RID: 10214 RVA: 0x0001D86E File Offset: 0x0001BA6E
	public uint UInt32_32 { get; set; }

	// Token: 0x170008CB RID: 2251
	// (get) Token: 0x060027E7 RID: 10215 RVA: 0x0001D877 File Offset: 0x0001BA77
	// (set) Token: 0x060027E8 RID: 10216 RVA: 0x0001D87F File Offset: 0x0001BA7F
	public uint UInt32_33 { get; set; }

	// Token: 0x170008CC RID: 2252
	// (get) Token: 0x060027E9 RID: 10217 RVA: 0x0001D888 File Offset: 0x0001BA88
	// (set) Token: 0x060027EA RID: 10218 RVA: 0x0001D890 File Offset: 0x0001BA90
	public uint UInt32_34 { get; set; }

	// Token: 0x170008CD RID: 2253
	// (get) Token: 0x060027EB RID: 10219 RVA: 0x0001D899 File Offset: 0x0001BA99
	// (set) Token: 0x060027EC RID: 10220 RVA: 0x0001D8A1 File Offset: 0x0001BAA1
	public uint UInt32_35 { get; set; }

	// Token: 0x170008CE RID: 2254
	// (get) Token: 0x060027ED RID: 10221 RVA: 0x0001D8AA File Offset: 0x0001BAAA
	// (set) Token: 0x060027EE RID: 10222 RVA: 0x0001D8B2 File Offset: 0x0001BAB2
	public uint UInt32_36 { get; set; }

	// Token: 0x170008CF RID: 2255
	// (get) Token: 0x060027EF RID: 10223 RVA: 0x0001D8BB File Offset: 0x0001BABB
	// (set) Token: 0x060027F0 RID: 10224 RVA: 0x0001D8C3 File Offset: 0x0001BAC3
	public uint[] UInt32_37 { get; set; }

	// Token: 0x170008D0 RID: 2256
	// (get) Token: 0x060027F1 RID: 10225 RVA: 0x0001D8CC File Offset: 0x0001BACC
	// (set) Token: 0x060027F2 RID: 10226 RVA: 0x0001D8D4 File Offset: 0x0001BAD4
	public uint UInt32_38 { get; set; }

	// Token: 0x170008D1 RID: 2257
	// (get) Token: 0x060027F3 RID: 10227 RVA: 0x0001D8DD File Offset: 0x0001BADD
	// (set) Token: 0x060027F4 RID: 10228 RVA: 0x0001D8E5 File Offset: 0x0001BAE5
	public uint[] UInt32_39 { get; set; }

	// Token: 0x170008D2 RID: 2258
	// (get) Token: 0x060027F5 RID: 10229 RVA: 0x0001D8EE File Offset: 0x0001BAEE
	// (set) Token: 0x060027F6 RID: 10230 RVA: 0x0001D8F6 File Offset: 0x0001BAF6
	public uint UInt32_40 { get; set; }

	// Token: 0x170008D3 RID: 2259
	// (get) Token: 0x060027F7 RID: 10231 RVA: 0x0001D8FF File Offset: 0x0001BAFF
	// (set) Token: 0x060027F8 RID: 10232 RVA: 0x0001D907 File Offset: 0x0001BB07
	public uint[] UInt32_41 { get; set; }

	// Token: 0x170008D4 RID: 2260
	// (get) Token: 0x060027F9 RID: 10233 RVA: 0x0001D910 File Offset: 0x0001BB10
	// (set) Token: 0x060027FA RID: 10234 RVA: 0x0001D918 File Offset: 0x0001BB18
	public uint UInt32_42 { get; set; }

	// Token: 0x170008D5 RID: 2261
	// (get) Token: 0x060027FB RID: 10235 RVA: 0x0001D921 File Offset: 0x0001BB21
	// (set) Token: 0x060027FC RID: 10236 RVA: 0x0001D929 File Offset: 0x0001BB29
	public uint UInt32_43 { get; set; }

	// Token: 0x170008D6 RID: 2262
	// (get) Token: 0x060027FD RID: 10237 RVA: 0x0001D932 File Offset: 0x0001BB32
	// (set) Token: 0x060027FE RID: 10238 RVA: 0x0001D93A File Offset: 0x0001BB3A
	public uint UInt32_44 { get; set; }

	// Token: 0x170008D7 RID: 2263
	// (get) Token: 0x060027FF RID: 10239 RVA: 0x0001D943 File Offset: 0x0001BB43
	// (set) Token: 0x06002800 RID: 10240 RVA: 0x0001D94B File Offset: 0x0001BB4B
	public uint UInt32_45 { get; set; }

	// Token: 0x170008D8 RID: 2264
	// (get) Token: 0x06002801 RID: 10241 RVA: 0x0001D954 File Offset: 0x0001BB54
	// (set) Token: 0x06002802 RID: 10242 RVA: 0x0001D95C File Offset: 0x0001BB5C
	public uint[] UInt32_46 { get; set; }

	// Token: 0x170008D9 RID: 2265
	// (get) Token: 0x06002803 RID: 10243 RVA: 0x0001D965 File Offset: 0x0001BB65
	// (set) Token: 0x06002804 RID: 10244 RVA: 0x0001D96D File Offset: 0x0001BB6D
	public uint[] UInt32_47 { get; set; }

	// Token: 0x170008DA RID: 2266
	// (get) Token: 0x06002805 RID: 10245 RVA: 0x0001D976 File Offset: 0x0001BB76
	// (set) Token: 0x06002806 RID: 10246 RVA: 0x0001D97E File Offset: 0x0001BB7E
	public uint UInt32_48 { get; set; }

	// Token: 0x170008DB RID: 2267
	// (get) Token: 0x06002807 RID: 10247 RVA: 0x0001D987 File Offset: 0x0001BB87
	// (set) Token: 0x06002808 RID: 10248 RVA: 0x0001D98F File Offset: 0x0001BB8F
	public uint UInt32_49 { get; set; }

	// Token: 0x170008DC RID: 2268
	// (get) Token: 0x06002809 RID: 10249 RVA: 0x0001D998 File Offset: 0x0001BB98
	// (set) Token: 0x0600280A RID: 10250 RVA: 0x0001D9A0 File Offset: 0x0001BBA0
	public uint UInt32_50 { get; set; }

	// Token: 0x170008DD RID: 2269
	// (get) Token: 0x0600280B RID: 10251 RVA: 0x0001D9A9 File Offset: 0x0001BBA9
	// (set) Token: 0x0600280C RID: 10252 RVA: 0x0001D9B1 File Offset: 0x0001BBB1
	public uint UInt32_51 { get; set; }

	// Token: 0x170008DE RID: 2270
	// (get) Token: 0x0600280D RID: 10253 RVA: 0x0001D9BA File Offset: 0x0001BBBA
	// (set) Token: 0x0600280E RID: 10254 RVA: 0x0001D9C2 File Offset: 0x0001BBC2
	public uint UInt32_52 { get; set; }

	// Token: 0x170008DF RID: 2271
	// (get) Token: 0x0600280F RID: 10255 RVA: 0x0001D9CB File Offset: 0x0001BBCB
	// (set) Token: 0x06002810 RID: 10256 RVA: 0x0001D9D3 File Offset: 0x0001BBD3
	public uint[] UInt32_53 { get; set; }

	// Token: 0x170008E0 RID: 2272
	// (get) Token: 0x06002811 RID: 10257 RVA: 0x0001D9DC File Offset: 0x0001BBDC
	// (set) Token: 0x06002812 RID: 10258 RVA: 0x0001D9E4 File Offset: 0x0001BBE4
	public uint[] UInt32_54 { get; set; }

	// Token: 0x170008E1 RID: 2273
	// (get) Token: 0x06002813 RID: 10259 RVA: 0x0001D9ED File Offset: 0x0001BBED
	// (set) Token: 0x06002814 RID: 10260 RVA: 0x0001D9F5 File Offset: 0x0001BBF5
	public uint[] UInt32_55 { get; set; }

	// Token: 0x170008E2 RID: 2274
	// (get) Token: 0x06002815 RID: 10261 RVA: 0x0001D9FE File Offset: 0x0001BBFE
	// (set) Token: 0x06002816 RID: 10262 RVA: 0x0001DA06 File Offset: 0x0001BC06
	public uint[] UInt32_56 { get; set; }

	// Token: 0x170008E3 RID: 2275
	// (get) Token: 0x06002817 RID: 10263 RVA: 0x0001DA0F File Offset: 0x0001BC0F
	// (set) Token: 0x06002818 RID: 10264 RVA: 0x0001DA17 File Offset: 0x0001BC17
	public uint[] UInt32_57 { get; set; }

	// Token: 0x170008E4 RID: 2276
	// (get) Token: 0x06002819 RID: 10265 RVA: 0x0001DA20 File Offset: 0x0001BC20
	// (set) Token: 0x0600281A RID: 10266 RVA: 0x0001DA28 File Offset: 0x0001BC28
	public uint[] UInt32_58 { get; set; }

	// Token: 0x170008E5 RID: 2277
	// (get) Token: 0x0600281B RID: 10267 RVA: 0x0001DA31 File Offset: 0x0001BC31
	// (set) Token: 0x0600281C RID: 10268 RVA: 0x0001DA39 File Offset: 0x0001BC39
	public uint[] UInt32_59 { get; set; }

	// Token: 0x170008E6 RID: 2278
	// (get) Token: 0x0600281D RID: 10269 RVA: 0x0001DA42 File Offset: 0x0001BC42
	// (set) Token: 0x0600281E RID: 10270 RVA: 0x0001DA4A File Offset: 0x0001BC4A
	public uint[] UInt32_60 { get; set; }

	// Token: 0x170008E7 RID: 2279
	// (get) Token: 0x0600281F RID: 10271 RVA: 0x0001DA53 File Offset: 0x0001BC53
	// (set) Token: 0x06002820 RID: 10272 RVA: 0x0001DA5B File Offset: 0x0001BC5B
	public uint[] UInt32_61 { get; set; }

	// Token: 0x170008E8 RID: 2280
	// (get) Token: 0x06002821 RID: 10273 RVA: 0x0001DA64 File Offset: 0x0001BC64
	// (set) Token: 0x06002822 RID: 10274 RVA: 0x0001DA6C File Offset: 0x0001BC6C
	public uint[] UInt32_62 { get; set; }

	// Token: 0x170008E9 RID: 2281
	// (get) Token: 0x06002823 RID: 10275 RVA: 0x0001DA75 File Offset: 0x0001BC75
	// (set) Token: 0x06002824 RID: 10276 RVA: 0x0001DA7D File Offset: 0x0001BC7D
	public uint[] UInt32_63 { get; set; }

	// Token: 0x170008EA RID: 2282
	// (get) Token: 0x06002825 RID: 10277 RVA: 0x0001DA86 File Offset: 0x0001BC86
	// (set) Token: 0x06002826 RID: 10278 RVA: 0x0001DA8E File Offset: 0x0001BC8E
	public uint[] UInt32_64 { get; set; }

	// Token: 0x170008EB RID: 2283
	// (get) Token: 0x06002827 RID: 10279 RVA: 0x0001DA97 File Offset: 0x0001BC97
	// (set) Token: 0x06002828 RID: 10280 RVA: 0x0001DA9F File Offset: 0x0001BC9F
	public uint[] UInt32_65 { get; set; }

	// Token: 0x170008EC RID: 2284
	// (get) Token: 0x06002829 RID: 10281 RVA: 0x0001DAA8 File Offset: 0x0001BCA8
	// (set) Token: 0x0600282A RID: 10282 RVA: 0x0001DAB0 File Offset: 0x0001BCB0
	public uint[] UInt32_66 { get; set; }

	// Token: 0x170008ED RID: 2285
	// (get) Token: 0x0600282B RID: 10283 RVA: 0x0001DAB9 File Offset: 0x0001BCB9
	// (set) Token: 0x0600282C RID: 10284 RVA: 0x0001DAC1 File Offset: 0x0001BCC1
	public uint[] UInt32_67 { get; set; }

	// Token: 0x170008EE RID: 2286
	// (get) Token: 0x0600282D RID: 10285 RVA: 0x0001DACA File Offset: 0x0001BCCA
	// (set) Token: 0x0600282E RID: 10286 RVA: 0x0001DAD2 File Offset: 0x0001BCD2
	public uint[] UInt32_68 { get; set; }

	// Token: 0x170008EF RID: 2287
	// (get) Token: 0x0600282F RID: 10287 RVA: 0x0001DADB File Offset: 0x0001BCDB
	// (set) Token: 0x06002830 RID: 10288 RVA: 0x0001DAE3 File Offset: 0x0001BCE3
	public uint[] UInt32_69 { get; set; }

	// Token: 0x170008F0 RID: 2288
	// (get) Token: 0x06002831 RID: 10289 RVA: 0x0001DAEC File Offset: 0x0001BCEC
	// (set) Token: 0x06002832 RID: 10290 RVA: 0x0001DAF4 File Offset: 0x0001BCF4
	public uint UInt32_70 { get; set; }

	// Token: 0x170008F1 RID: 2289
	// (get) Token: 0x06002833 RID: 10291 RVA: 0x0001DAFD File Offset: 0x0001BCFD
	// (set) Token: 0x06002834 RID: 10292 RVA: 0x0001DB05 File Offset: 0x0001BD05
	public uint UInt32_71 { get; set; }

	// Token: 0x170008F2 RID: 2290
	// (get) Token: 0x06002835 RID: 10293 RVA: 0x0001DB0E File Offset: 0x0001BD0E
	// (set) Token: 0x06002836 RID: 10294 RVA: 0x0001DB16 File Offset: 0x0001BD16
	public uint UInt32_72 { get; set; }

	// Token: 0x170008F3 RID: 2291
	// (get) Token: 0x06002837 RID: 10295 RVA: 0x0001DB1F File Offset: 0x0001BD1F
	// (set) Token: 0x06002838 RID: 10296 RVA: 0x0001DB27 File Offset: 0x0001BD27
	public uint UInt32_73 { get; set; }

	// Token: 0x170008F4 RID: 2292
	// (get) Token: 0x06002839 RID: 10297 RVA: 0x0001DB30 File Offset: 0x0001BD30
	// (set) Token: 0x0600283A RID: 10298 RVA: 0x0001DB38 File Offset: 0x0001BD38
	public uint[] UInt32_74 { get; set; }

	// Token: 0x170008F5 RID: 2293
	// (get) Token: 0x0600283B RID: 10299 RVA: 0x0001DB41 File Offset: 0x0001BD41
	// (set) Token: 0x0600283C RID: 10300 RVA: 0x0001DB49 File Offset: 0x0001BD49
	public uint UInt32_75 { get; set; }

	// Token: 0x170008F6 RID: 2294
	// (get) Token: 0x0600283D RID: 10301 RVA: 0x0001DB52 File Offset: 0x0001BD52
	// (set) Token: 0x0600283E RID: 10302 RVA: 0x0001DB5A File Offset: 0x0001BD5A
	public uint UInt32_76 { get; set; }

	// Token: 0x170008F7 RID: 2295
	// (get) Token: 0x0600283F RID: 10303 RVA: 0x0001DB63 File Offset: 0x0001BD63
	// (set) Token: 0x06002840 RID: 10304 RVA: 0x0001DB6B File Offset: 0x0001BD6B
	public uint UInt32_77 { get; set; }

	// Token: 0x170008F8 RID: 2296
	// (get) Token: 0x06002841 RID: 10305 RVA: 0x0001DB74 File Offset: 0x0001BD74
	// (set) Token: 0x06002842 RID: 10306 RVA: 0x0001DB7C File Offset: 0x0001BD7C
	public uint UInt32_78 { get; set; }

	// Token: 0x170008F9 RID: 2297
	// (get) Token: 0x06002843 RID: 10307 RVA: 0x0001DB85 File Offset: 0x0001BD85
	// (set) Token: 0x06002844 RID: 10308 RVA: 0x0001DB8D File Offset: 0x0001BD8D
	public uint UInt32_79 { get; set; }

	// Token: 0x170008FA RID: 2298
	// (get) Token: 0x06002845 RID: 10309 RVA: 0x0001DB96 File Offset: 0x0001BD96
	// (set) Token: 0x06002846 RID: 10310 RVA: 0x0001DB9E File Offset: 0x0001BD9E
	public uint UInt32_80 { get; set; }

	// Token: 0x170008FB RID: 2299
	// (get) Token: 0x06002847 RID: 10311 RVA: 0x0001DBA7 File Offset: 0x0001BDA7
	// (set) Token: 0x06002848 RID: 10312 RVA: 0x0001DBAF File Offset: 0x0001BDAF
	public uint UInt32_81 { get; set; }

	// Token: 0x170008FC RID: 2300
	// (get) Token: 0x06002849 RID: 10313 RVA: 0x0001DBB8 File Offset: 0x0001BDB8
	// (set) Token: 0x0600284A RID: 10314 RVA: 0x0001DBC0 File Offset: 0x0001BDC0
	public uint UInt32_82 { get; set; }

	// Token: 0x170008FD RID: 2301
	// (get) Token: 0x0600284B RID: 10315 RVA: 0x0001DBC9 File Offset: 0x0001BDC9
	// (set) Token: 0x0600284C RID: 10316 RVA: 0x0001DBD1 File Offset: 0x0001BDD1
	public uint UInt32_83 { get; set; }

	// Token: 0x170008FE RID: 2302
	// (get) Token: 0x0600284D RID: 10317 RVA: 0x0001DBDA File Offset: 0x0001BDDA
	// (set) Token: 0x0600284E RID: 10318 RVA: 0x0001DBE2 File Offset: 0x0001BDE2
	public uint UInt32_84 { get; set; }

	// Token: 0x170008FF RID: 2303
	// (get) Token: 0x0600284F RID: 10319 RVA: 0x0001DBEB File Offset: 0x0001BDEB
	// (set) Token: 0x06002850 RID: 10320 RVA: 0x0001DBF3 File Offset: 0x0001BDF3
	public uint UInt32_85 { get; set; }

	// Token: 0x17000900 RID: 2304
	// (get) Token: 0x06002851 RID: 10321 RVA: 0x0001DBFC File Offset: 0x0001BDFC
	// (set) Token: 0x06002852 RID: 10322 RVA: 0x0001DC04 File Offset: 0x0001BE04
	public uint UInt32_86 { get; set; }

	// Token: 0x17000901 RID: 2305
	// (get) Token: 0x06002853 RID: 10323 RVA: 0x0001DC0D File Offset: 0x0001BE0D
	// (set) Token: 0x06002854 RID: 10324 RVA: 0x0001DC15 File Offset: 0x0001BE15
	public uint UInt32_87 { get; set; }

	// Token: 0x17000902 RID: 2306
	// (get) Token: 0x06002855 RID: 10325 RVA: 0x0001DC1E File Offset: 0x0001BE1E
	// (set) Token: 0x06002856 RID: 10326 RVA: 0x0001DC26 File Offset: 0x0001BE26
	public uint UInt32_88 { get; set; }

	// Token: 0x17000903 RID: 2307
	// (get) Token: 0x06002857 RID: 10327 RVA: 0x0001DC2F File Offset: 0x0001BE2F
	// (set) Token: 0x06002858 RID: 10328 RVA: 0x0001DC37 File Offset: 0x0001BE37
	public uint UInt32_89 { get; set; }

	// Token: 0x17000904 RID: 2308
	// (get) Token: 0x06002859 RID: 10329 RVA: 0x0001DC40 File Offset: 0x0001BE40
	// (set) Token: 0x0600285A RID: 10330 RVA: 0x0001DC48 File Offset: 0x0001BE48
	public uint UInt32_90 { get; set; }

	// Token: 0x17000905 RID: 2309
	// (get) Token: 0x0600285B RID: 10331 RVA: 0x0001DC51 File Offset: 0x0001BE51
	// (set) Token: 0x0600285C RID: 10332 RVA: 0x0001DC59 File Offset: 0x0001BE59
	public uint UInt32_91 { get; set; }

	// Token: 0x17000906 RID: 2310
	// (get) Token: 0x0600285D RID: 10333 RVA: 0x0001DC62 File Offset: 0x0001BE62
	// (set) Token: 0x0600285E RID: 10334 RVA: 0x0001DC6A File Offset: 0x0001BE6A
	public uint UInt32_92 { get; set; }

	// Token: 0x17000907 RID: 2311
	// (get) Token: 0x0600285F RID: 10335 RVA: 0x0001DC73 File Offset: 0x0001BE73
	// (set) Token: 0x06002860 RID: 10336 RVA: 0x0001DC7B File Offset: 0x0001BE7B
	public uint UInt32_93 { get; set; }

	// Token: 0x17000908 RID: 2312
	// (get) Token: 0x06002861 RID: 10337 RVA: 0x0001DC84 File Offset: 0x0001BE84
	// (set) Token: 0x06002862 RID: 10338 RVA: 0x0001DC8C File Offset: 0x0001BE8C
	public uint UInt32_94 { get; set; }

	// Token: 0x17000909 RID: 2313
	// (get) Token: 0x06002863 RID: 10339 RVA: 0x0001DC95 File Offset: 0x0001BE95
	// (set) Token: 0x06002864 RID: 10340 RVA: 0x0001DC9D File Offset: 0x0001BE9D
	public uint UInt32_95 { get; set; }

	// Token: 0x1700090A RID: 2314
	// (get) Token: 0x06002865 RID: 10341 RVA: 0x0001DCA6 File Offset: 0x0001BEA6
	// (set) Token: 0x06002866 RID: 10342 RVA: 0x0001DCAE File Offset: 0x0001BEAE
	public uint UInt32_96 { get; set; }

	// Token: 0x1700090B RID: 2315
	// (get) Token: 0x06002867 RID: 10343 RVA: 0x0001DCB7 File Offset: 0x0001BEB7
	// (set) Token: 0x06002868 RID: 10344 RVA: 0x0001DCBF File Offset: 0x0001BEBF
	public uint[] UInt32_97 { get; set; }

	// Token: 0x1700090C RID: 2316
	// (get) Token: 0x06002869 RID: 10345 RVA: 0x0001DCC8 File Offset: 0x0001BEC8
	// (set) Token: 0x0600286A RID: 10346 RVA: 0x0001DCD0 File Offset: 0x0001BED0
	public uint[] UInt32_98 { get; set; }

	// Token: 0x1700090D RID: 2317
	// (get) Token: 0x0600286B RID: 10347 RVA: 0x0001DCD9 File Offset: 0x0001BED9
	// (set) Token: 0x0600286C RID: 10348 RVA: 0x0001DCE1 File Offset: 0x0001BEE1
	public uint UInt32_99 { get; set; }

	// Token: 0x1700090E RID: 2318
	// (get) Token: 0x0600286D RID: 10349 RVA: 0x0001DCEA File Offset: 0x0001BEEA
	// (set) Token: 0x0600286E RID: 10350 RVA: 0x0001DCF2 File Offset: 0x0001BEF2
	public uint UInt32_100 { get; set; }

	// Token: 0x1700090F RID: 2319
	// (get) Token: 0x0600286F RID: 10351 RVA: 0x0001DCFB File Offset: 0x0001BEFB
	// (set) Token: 0x06002870 RID: 10352 RVA: 0x0001DD03 File Offset: 0x0001BF03
	public uint[] UInt32_101 { get; set; }

	// Token: 0x17000910 RID: 2320
	// (get) Token: 0x06002871 RID: 10353 RVA: 0x0001DD0C File Offset: 0x0001BF0C
	// (set) Token: 0x06002872 RID: 10354 RVA: 0x0001DD14 File Offset: 0x0001BF14
	public uint UInt32_102 { get; set; }

	// Token: 0x17000911 RID: 2321
	// (get) Token: 0x06002873 RID: 10355 RVA: 0x0001DD1D File Offset: 0x0001BF1D
	// (set) Token: 0x06002874 RID: 10356 RVA: 0x0001DD25 File Offset: 0x0001BF25
	public uint UInt32_103 { get; set; }

	// Token: 0x17000912 RID: 2322
	// (get) Token: 0x06002875 RID: 10357 RVA: 0x0001DD2E File Offset: 0x0001BF2E
	// (set) Token: 0x06002876 RID: 10358 RVA: 0x0001DD36 File Offset: 0x0001BF36
	public uint UInt32_104 { get; set; }

	// Token: 0x17000913 RID: 2323
	// (get) Token: 0x06002877 RID: 10359 RVA: 0x0001DD3F File Offset: 0x0001BF3F
	// (set) Token: 0x06002878 RID: 10360 RVA: 0x0001DD47 File Offset: 0x0001BF47
	public uint[] UInt32_105 { get; set; }

	// Token: 0x17000914 RID: 2324
	// (get) Token: 0x06002879 RID: 10361 RVA: 0x0001DD50 File Offset: 0x0001BF50
	// (set) Token: 0x0600287A RID: 10362 RVA: 0x0001DD58 File Offset: 0x0001BF58
	public uint UInt32_106 { get; set; }

	// Token: 0x17000915 RID: 2325
	// (get) Token: 0x0600287B RID: 10363 RVA: 0x0001DD61 File Offset: 0x0001BF61
	// (set) Token: 0x0600287C RID: 10364 RVA: 0x0001DD69 File Offset: 0x0001BF69
	public uint[] UInt32_107 { get; set; }

	// Token: 0x17000916 RID: 2326
	// (get) Token: 0x0600287D RID: 10365 RVA: 0x0001DD72 File Offset: 0x0001BF72
	// (set) Token: 0x0600287E RID: 10366 RVA: 0x0001DD7A File Offset: 0x0001BF7A
	public uint UInt32_108 { get; set; }

	// Token: 0x17000917 RID: 2327
	// (get) Token: 0x0600287F RID: 10367 RVA: 0x0001DD83 File Offset: 0x0001BF83
	// (set) Token: 0x06002880 RID: 10368 RVA: 0x0001DD8B File Offset: 0x0001BF8B
	public uint UInt32_109 { get; set; }

	// Token: 0x17000918 RID: 2328
	// (get) Token: 0x06002881 RID: 10369 RVA: 0x0001DD94 File Offset: 0x0001BF94
	// (set) Token: 0x06002882 RID: 10370 RVA: 0x0001DD9C File Offset: 0x0001BF9C
	public uint UInt32_110 { get; set; }

	// Token: 0x17000919 RID: 2329
	// (get) Token: 0x06002883 RID: 10371 RVA: 0x0001DDA5 File Offset: 0x0001BFA5
	// (set) Token: 0x06002884 RID: 10372 RVA: 0x0001DDAD File Offset: 0x0001BFAD
	public uint UInt32_111 { get; set; }

	// Token: 0x1700091A RID: 2330
	// (get) Token: 0x06002885 RID: 10373 RVA: 0x0001DDB6 File Offset: 0x0001BFB6
	// (set) Token: 0x06002886 RID: 10374 RVA: 0x0001DDBE File Offset: 0x0001BFBE
	public uint UInt32_112 { get; set; }

	// Token: 0x1700091B RID: 2331
	// (get) Token: 0x06002887 RID: 10375 RVA: 0x0001DDC7 File Offset: 0x0001BFC7
	// (set) Token: 0x06002888 RID: 10376 RVA: 0x0001DDCF File Offset: 0x0001BFCF
	public uint UInt32_113 { get; set; }

	// Token: 0x1700091C RID: 2332
	// (get) Token: 0x06002889 RID: 10377 RVA: 0x0001DDD8 File Offset: 0x0001BFD8
	// (set) Token: 0x0600288A RID: 10378 RVA: 0x0001DDE0 File Offset: 0x0001BFE0
	public uint UInt32_114 { get; set; }

	// Token: 0x1700091D RID: 2333
	// (get) Token: 0x0600288B RID: 10379 RVA: 0x0001DDE9 File Offset: 0x0001BFE9
	// (set) Token: 0x0600288C RID: 10380 RVA: 0x0001DDF1 File Offset: 0x0001BFF1
	public uint UInt32_115 { get; set; }

	// Token: 0x1700091E RID: 2334
	// (get) Token: 0x0600288D RID: 10381 RVA: 0x0001DDFA File Offset: 0x0001BFFA
	// (set) Token: 0x0600288E RID: 10382 RVA: 0x0001DE02 File Offset: 0x0001C002
	public uint UInt32_116 { get; set; }

	// Token: 0x1700091F RID: 2335
	// (get) Token: 0x0600288F RID: 10383 RVA: 0x0001DE0B File Offset: 0x0001C00B
	// (set) Token: 0x06002890 RID: 10384 RVA: 0x0001DE13 File Offset: 0x0001C013
	public uint UInt32_117 { get; set; }

	// Token: 0x17000920 RID: 2336
	// (get) Token: 0x06002891 RID: 10385 RVA: 0x0001DE1C File Offset: 0x0001C01C
	// (set) Token: 0x06002892 RID: 10386 RVA: 0x0001DE24 File Offset: 0x0001C024
	public uint UInt32_118 { get; set; }

	// Token: 0x17000921 RID: 2337
	// (get) Token: 0x06002893 RID: 10387 RVA: 0x0001DE2D File Offset: 0x0001C02D
	// (set) Token: 0x06002894 RID: 10388 RVA: 0x0001DE35 File Offset: 0x0001C035
	public uint[] UInt32_119 { get; set; }

	// Token: 0x17000922 RID: 2338
	// (get) Token: 0x06002895 RID: 10389 RVA: 0x0001DE3E File Offset: 0x0001C03E
	// (set) Token: 0x06002896 RID: 10390 RVA: 0x0001DE46 File Offset: 0x0001C046
	public uint[] UInt32_120 { get; set; }

	// Token: 0x17000923 RID: 2339
	// (get) Token: 0x06002897 RID: 10391 RVA: 0x0001DE4F File Offset: 0x0001C04F
	// (set) Token: 0x06002898 RID: 10392 RVA: 0x0001DE57 File Offset: 0x0001C057
	public uint UInt32_121 { get; set; }

	// Token: 0x17000924 RID: 2340
	// (get) Token: 0x06002899 RID: 10393 RVA: 0x0001DE60 File Offset: 0x0001C060
	// (set) Token: 0x0600289A RID: 10394 RVA: 0x0001DE68 File Offset: 0x0001C068
	public uint[] UInt32_122 { get; set; }

	// Token: 0x17000925 RID: 2341
	// (get) Token: 0x0600289B RID: 10395 RVA: 0x0001DE71 File Offset: 0x0001C071
	// (set) Token: 0x0600289C RID: 10396 RVA: 0x0001DE79 File Offset: 0x0001C079
	public uint[] UInt32_123 { get; set; }

	// Token: 0x17000926 RID: 2342
	// (get) Token: 0x0600289D RID: 10397 RVA: 0x0001DE82 File Offset: 0x0001C082
	// (set) Token: 0x0600289E RID: 10398 RVA: 0x0001DE8A File Offset: 0x0001C08A
	public uint[] UInt32_124 { get; set; }

	// Token: 0x17000927 RID: 2343
	// (get) Token: 0x0600289F RID: 10399 RVA: 0x0001DE93 File Offset: 0x0001C093
	// (set) Token: 0x060028A0 RID: 10400 RVA: 0x0001DE9B File Offset: 0x0001C09B
	public uint[] UInt32_125 { get; set; }

	// Token: 0x17000928 RID: 2344
	// (get) Token: 0x060028A1 RID: 10401 RVA: 0x0001DEA4 File Offset: 0x0001C0A4
	// (set) Token: 0x060028A2 RID: 10402 RVA: 0x0001DEAC File Offset: 0x0001C0AC
	public uint[] UInt32_126 { get; set; }

	// Token: 0x17000929 RID: 2345
	// (get) Token: 0x060028A3 RID: 10403 RVA: 0x0001DEB5 File Offset: 0x0001C0B5
	// (set) Token: 0x060028A4 RID: 10404 RVA: 0x0001DEBD File Offset: 0x0001C0BD
	public uint[] UInt32_127 { get; set; }

	// Token: 0x1700092A RID: 2346
	// (get) Token: 0x060028A5 RID: 10405 RVA: 0x0001DEC6 File Offset: 0x0001C0C6
	// (set) Token: 0x060028A6 RID: 10406 RVA: 0x0001DECE File Offset: 0x0001C0CE
	public uint[] UInt32_128 { get; set; }

	// Token: 0x1700092B RID: 2347
	// (get) Token: 0x060028A7 RID: 10407 RVA: 0x0001DED7 File Offset: 0x0001C0D7
	// (set) Token: 0x060028A8 RID: 10408 RVA: 0x0001DEDF File Offset: 0x0001C0DF
	public uint[] UInt32_129 { get; set; }

	// Token: 0x1700092C RID: 2348
	// (get) Token: 0x060028A9 RID: 10409 RVA: 0x0001DEE8 File Offset: 0x0001C0E8
	// (set) Token: 0x060028AA RID: 10410 RVA: 0x0001DEF0 File Offset: 0x0001C0F0
	public uint[] UInt32_130 { get; set; }

	// Token: 0x1700092D RID: 2349
	// (get) Token: 0x060028AB RID: 10411 RVA: 0x0001DEF9 File Offset: 0x0001C0F9
	// (set) Token: 0x060028AC RID: 10412 RVA: 0x0001DF01 File Offset: 0x0001C101
	public uint UInt32_131 { get; set; }

	// Token: 0x1700092E RID: 2350
	// (get) Token: 0x060028AD RID: 10413 RVA: 0x0001DF0A File Offset: 0x0001C10A
	// (set) Token: 0x060028AE RID: 10414 RVA: 0x0001DF12 File Offset: 0x0001C112
	public uint[] UInt32_132 { get; set; }

	// Token: 0x1700092F RID: 2351
	// (get) Token: 0x060028AF RID: 10415 RVA: 0x0001DF1B File Offset: 0x0001C11B
	// (set) Token: 0x060028B0 RID: 10416 RVA: 0x0001DF23 File Offset: 0x0001C123
	public uint[] UInt32_133 { get; set; }

	// Token: 0x17000930 RID: 2352
	// (get) Token: 0x060028B1 RID: 10417 RVA: 0x0001DF2C File Offset: 0x0001C12C
	// (set) Token: 0x060028B2 RID: 10418 RVA: 0x0001DF34 File Offset: 0x0001C134
	public uint[] UInt32_134 { get; set; }

	// Token: 0x17000931 RID: 2353
	// (get) Token: 0x060028B3 RID: 10419 RVA: 0x0001DF3D File Offset: 0x0001C13D
	// (set) Token: 0x060028B4 RID: 10420 RVA: 0x0001DF45 File Offset: 0x0001C145
	public uint[] UInt32_135 { get; set; }

	// Token: 0x17000932 RID: 2354
	// (get) Token: 0x060028B5 RID: 10421 RVA: 0x0001DF4E File Offset: 0x0001C14E
	// (set) Token: 0x060028B6 RID: 10422 RVA: 0x0001DF56 File Offset: 0x0001C156
	public uint[] UInt32_136 { get; set; }

	// Token: 0x17000933 RID: 2355
	// (get) Token: 0x060028B7 RID: 10423 RVA: 0x0001DF5F File Offset: 0x0001C15F
	// (set) Token: 0x060028B8 RID: 10424 RVA: 0x0001DF67 File Offset: 0x0001C167
	public uint[] UInt32_137 { get; set; }

	// Token: 0x17000934 RID: 2356
	// (get) Token: 0x060028B9 RID: 10425 RVA: 0x0001DF70 File Offset: 0x0001C170
	// (set) Token: 0x060028BA RID: 10426 RVA: 0x0001DF78 File Offset: 0x0001C178
	public uint[] UInt32_138 { get; set; }

	// Token: 0x17000935 RID: 2357
	// (get) Token: 0x060028BB RID: 10427 RVA: 0x0001DF81 File Offset: 0x0001C181
	// (set) Token: 0x060028BC RID: 10428 RVA: 0x0001DF89 File Offset: 0x0001C189
	public uint UInt32_139 { get; set; }

	// Token: 0x17000936 RID: 2358
	// (get) Token: 0x060028BD RID: 10429 RVA: 0x0001DF92 File Offset: 0x0001C192
	// (set) Token: 0x060028BE RID: 10430 RVA: 0x0001DF9A File Offset: 0x0001C19A
	public uint UInt32_140 { get; set; }

	// Token: 0x17000937 RID: 2359
	// (get) Token: 0x060028BF RID: 10431 RVA: 0x0001DFA3 File Offset: 0x0001C1A3
	// (set) Token: 0x060028C0 RID: 10432 RVA: 0x0001DFAB File Offset: 0x0001C1AB
	public uint[] UInt32_141 { get; set; }

	// Token: 0x17000938 RID: 2360
	// (get) Token: 0x060028C1 RID: 10433 RVA: 0x0001DFB4 File Offset: 0x0001C1B4
	// (set) Token: 0x060028C2 RID: 10434 RVA: 0x0001DFBC File Offset: 0x0001C1BC
	public uint[] UInt32_142 { get; set; }

	// Token: 0x17000939 RID: 2361
	// (get) Token: 0x060028C3 RID: 10435 RVA: 0x0001DFC5 File Offset: 0x0001C1C5
	// (set) Token: 0x060028C4 RID: 10436 RVA: 0x0001DFCD File Offset: 0x0001C1CD
	public uint[] UInt32_143 { get; set; }

	// Token: 0x1700093A RID: 2362
	// (get) Token: 0x060028C5 RID: 10437 RVA: 0x0001DFD6 File Offset: 0x0001C1D6
	// (set) Token: 0x060028C6 RID: 10438 RVA: 0x0001DFDE File Offset: 0x0001C1DE
	public uint[] UInt32_144 { get; set; }

	// Token: 0x1700093B RID: 2363
	// (get) Token: 0x060028C7 RID: 10439 RVA: 0x0001DFE7 File Offset: 0x0001C1E7
	// (set) Token: 0x060028C8 RID: 10440 RVA: 0x0001DFEF File Offset: 0x0001C1EF
	public uint[] UInt32_145 { get; set; }

	// Token: 0x1700093C RID: 2364
	// (get) Token: 0x060028C9 RID: 10441 RVA: 0x0001DFF8 File Offset: 0x0001C1F8
	// (set) Token: 0x060028CA RID: 10442 RVA: 0x0001E000 File Offset: 0x0001C200
	public uint[] UInt32_146 { get; set; }

	// Token: 0x1700093D RID: 2365
	// (get) Token: 0x060028CB RID: 10443 RVA: 0x0001E009 File Offset: 0x0001C209
	// (set) Token: 0x060028CC RID: 10444 RVA: 0x0001E011 File Offset: 0x0001C211
	public uint UInt32_147 { get; set; }

	// Token: 0x1700093E RID: 2366
	// (get) Token: 0x060028CD RID: 10445 RVA: 0x0001E01A File Offset: 0x0001C21A
	// (set) Token: 0x060028CE RID: 10446 RVA: 0x0001E022 File Offset: 0x0001C222
	public uint UInt32_148 { get; set; }

	// Token: 0x1700093F RID: 2367
	// (get) Token: 0x060028CF RID: 10447 RVA: 0x0001E02B File Offset: 0x0001C22B
	// (set) Token: 0x060028D0 RID: 10448 RVA: 0x0001E033 File Offset: 0x0001C233
	public uint[] UInt32_149 { get; set; }

	// Token: 0x17000940 RID: 2368
	// (get) Token: 0x060028D1 RID: 10449 RVA: 0x0001E03C File Offset: 0x0001C23C
	// (set) Token: 0x060028D2 RID: 10450 RVA: 0x0001E044 File Offset: 0x0001C244
	public uint[] UInt32_150 { get; set; }

	// Token: 0x17000941 RID: 2369
	// (get) Token: 0x060028D3 RID: 10451 RVA: 0x0001E04D File Offset: 0x0001C24D
	// (set) Token: 0x060028D4 RID: 10452 RVA: 0x0001E055 File Offset: 0x0001C255
	public uint[] UInt32_151 { get; set; }

	// Token: 0x17000942 RID: 2370
	// (get) Token: 0x060028D5 RID: 10453 RVA: 0x0001E05E File Offset: 0x0001C25E
	// (set) Token: 0x060028D6 RID: 10454 RVA: 0x0001E066 File Offset: 0x0001C266
	public uint[] UInt32_152 { get; set; }

	// Token: 0x17000943 RID: 2371
	// (get) Token: 0x060028D7 RID: 10455 RVA: 0x0001E06F File Offset: 0x0001C26F
	// (set) Token: 0x060028D8 RID: 10456 RVA: 0x0001E077 File Offset: 0x0001C277
	public uint[] UInt32_153 { get; set; }

	// Token: 0x17000944 RID: 2372
	// (get) Token: 0x060028D9 RID: 10457 RVA: 0x0001E080 File Offset: 0x0001C280
	// (set) Token: 0x060028DA RID: 10458 RVA: 0x0001E088 File Offset: 0x0001C288
	public string String_0 { get; set; }

	// Token: 0x17000945 RID: 2373
	// (get) Token: 0x060028DB RID: 10459 RVA: 0x0001E091 File Offset: 0x0001C291
	// (set) Token: 0x060028DC RID: 10460 RVA: 0x0001E099 File Offset: 0x0001C299
	public uint UInt32_154 { get; set; }

	// Token: 0x17000946 RID: 2374
	// (get) Token: 0x060028DD RID: 10461 RVA: 0x0001E0A2 File Offset: 0x0001C2A2
	// (set) Token: 0x060028DE RID: 10462 RVA: 0x0001E0AA File Offset: 0x0001C2AA
	public uint UInt32_155 { get; set; }

	// Token: 0x17000947 RID: 2375
	// (get) Token: 0x060028DF RID: 10463 RVA: 0x0001E0B3 File Offset: 0x0001C2B3
	// (set) Token: 0x060028E0 RID: 10464 RVA: 0x0001E0BB File Offset: 0x0001C2BB
	public uint[] UInt32_156 { get; set; }

	// Token: 0x17000948 RID: 2376
	// (get) Token: 0x060028E1 RID: 10465 RVA: 0x0001E0C4 File Offset: 0x0001C2C4
	// (set) Token: 0x060028E2 RID: 10466 RVA: 0x0001E0CC File Offset: 0x0001C2CC
	public uint[] UInt32_157 { get; set; }

	// Token: 0x17000949 RID: 2377
	// (get) Token: 0x060028E3 RID: 10467 RVA: 0x0001E0D5 File Offset: 0x0001C2D5
	// (set) Token: 0x060028E4 RID: 10468 RVA: 0x0001E0DD File Offset: 0x0001C2DD
	public uint[] UInt32_158 { get; set; }

	// Token: 0x04001AD9 RID: 6873
	private string string_0;

	// Token: 0x04001ADA RID: 6874
	private uint[] uint_0;

	// Token: 0x04001ADB RID: 6875
	public static Dictionary<string, Class392> dictionary_0 = new Dictionary<string, Class392>();

	// Token: 0x04001ADC RID: 6876
	private uint uint_1;

	// Token: 0x04001ADD RID: 6877
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04001ADE RID: 6878
	public uint uint_2;

	// Token: 0x04001ADF RID: 6879
	[CompilerGenerated]
	private uint[] uint_3;

	// Token: 0x04001AE0 RID: 6880
	[CompilerGenerated]
	private uint[] uint_4;

	// Token: 0x04001AE1 RID: 6881
	[CompilerGenerated]
	private uint[] uint_5;

	// Token: 0x04001AE2 RID: 6882
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04001AE3 RID: 6883
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04001AE4 RID: 6884
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04001AE5 RID: 6885
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x04001AE6 RID: 6886
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x04001AE7 RID: 6887
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x04001AE8 RID: 6888
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x04001AE9 RID: 6889
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x04001AEA RID: 6890
	[CompilerGenerated]
	private uint uint_14;

	// Token: 0x04001AEB RID: 6891
	[CompilerGenerated]
	private uint uint_15;

	// Token: 0x04001AEC RID: 6892
	[CompilerGenerated]
	private uint uint_16;

	// Token: 0x04001AED RID: 6893
	[CompilerGenerated]
	private uint uint_17;

	// Token: 0x04001AEE RID: 6894
	[CompilerGenerated]
	private uint uint_18;

	// Token: 0x04001AEF RID: 6895
	[CompilerGenerated]
	private uint uint_19;

	// Token: 0x04001AF0 RID: 6896
	[CompilerGenerated]
	private uint uint_20;

	// Token: 0x04001AF1 RID: 6897
	[CompilerGenerated]
	private uint uint_21;

	// Token: 0x04001AF2 RID: 6898
	[CompilerGenerated]
	private uint uint_22;

	// Token: 0x04001AF3 RID: 6899
	[CompilerGenerated]
	private uint uint_23;

	// Token: 0x04001AF4 RID: 6900
	[CompilerGenerated]
	private uint uint_24;

	// Token: 0x04001AF5 RID: 6901
	[CompilerGenerated]
	private uint uint_25;

	// Token: 0x04001AF6 RID: 6902
	[CompilerGenerated]
	private uint uint_26;

	// Token: 0x04001AF7 RID: 6903
	[CompilerGenerated]
	private uint uint_27;

	// Token: 0x04001AF8 RID: 6904
	[CompilerGenerated]
	private uint uint_28;

	// Token: 0x04001AF9 RID: 6905
	[CompilerGenerated]
	private uint uint_29;

	// Token: 0x04001AFA RID: 6906
	[CompilerGenerated]
	private uint uint_30;

	// Token: 0x04001AFB RID: 6907
	[CompilerGenerated]
	private uint uint_31;

	// Token: 0x04001AFC RID: 6908
	[CompilerGenerated]
	private uint uint_32;

	// Token: 0x04001AFD RID: 6909
	[CompilerGenerated]
	private uint uint_33;

	// Token: 0x04001AFE RID: 6910
	[CompilerGenerated]
	private uint uint_34;

	// Token: 0x04001AFF RID: 6911
	[CompilerGenerated]
	private uint uint_35;

	// Token: 0x04001B00 RID: 6912
	[CompilerGenerated]
	private uint uint_36;

	// Token: 0x04001B01 RID: 6913
	[CompilerGenerated]
	private uint uint_37;

	// Token: 0x04001B02 RID: 6914
	[CompilerGenerated]
	private uint uint_38;

	// Token: 0x04001B03 RID: 6915
	[CompilerGenerated]
	private uint uint_39;

	// Token: 0x04001B04 RID: 6916
	[CompilerGenerated]
	private uint[] uint_40;

	// Token: 0x04001B05 RID: 6917
	[CompilerGenerated]
	private uint uint_41;

	// Token: 0x04001B06 RID: 6918
	public uint[] uint_42;

	// Token: 0x04001B07 RID: 6919
	[CompilerGenerated]
	private uint[] uint_43;

	// Token: 0x04001B08 RID: 6920
	[CompilerGenerated]
	private uint uint_44;

	// Token: 0x04001B09 RID: 6921
	[CompilerGenerated]
	private uint[] uint_45;

	// Token: 0x04001B0A RID: 6922
	[CompilerGenerated]
	private uint uint_46;

	// Token: 0x04001B0B RID: 6923
	[CompilerGenerated]
	private uint uint_47;

	// Token: 0x04001B0C RID: 6924
	[CompilerGenerated]
	private uint uint_48;

	// Token: 0x04001B0D RID: 6925
	[CompilerGenerated]
	private uint uint_49;

	// Token: 0x04001B0E RID: 6926
	[CompilerGenerated]
	private uint[] uint_50;

	// Token: 0x04001B0F RID: 6927
	[CompilerGenerated]
	private uint[] uint_51;

	// Token: 0x04001B10 RID: 6928
	[CompilerGenerated]
	private uint uint_52;

	// Token: 0x04001B11 RID: 6929
	[CompilerGenerated]
	private uint uint_53;

	// Token: 0x04001B12 RID: 6930
	[CompilerGenerated]
	private uint uint_54;

	// Token: 0x04001B13 RID: 6931
	[CompilerGenerated]
	private uint uint_55;

	// Token: 0x04001B14 RID: 6932
	[CompilerGenerated]
	private uint uint_56;

	// Token: 0x04001B15 RID: 6933
	[CompilerGenerated]
	private uint[] uint_57;

	// Token: 0x04001B16 RID: 6934
	[CompilerGenerated]
	private uint[] uint_58;

	// Token: 0x04001B17 RID: 6935
	[CompilerGenerated]
	private uint[] uint_59;

	// Token: 0x04001B18 RID: 6936
	[CompilerGenerated]
	private uint[] uint_60;

	// Token: 0x04001B19 RID: 6937
	[CompilerGenerated]
	private uint[] uint_61;

	// Token: 0x04001B1A RID: 6938
	[CompilerGenerated]
	private uint[] uint_62;

	// Token: 0x04001B1B RID: 6939
	[CompilerGenerated]
	private uint[] uint_63;

	// Token: 0x04001B1C RID: 6940
	[CompilerGenerated]
	private uint[] uint_64;

	// Token: 0x04001B1D RID: 6941
	[CompilerGenerated]
	private uint[] uint_65;

	// Token: 0x04001B1E RID: 6942
	[CompilerGenerated]
	private uint[] uint_66;

	// Token: 0x04001B1F RID: 6943
	[CompilerGenerated]
	private uint[] uint_67;

	// Token: 0x04001B20 RID: 6944
	[CompilerGenerated]
	private uint[] uint_68;

	// Token: 0x04001B21 RID: 6945
	[CompilerGenerated]
	private uint[] uint_69;

	// Token: 0x04001B22 RID: 6946
	[CompilerGenerated]
	private uint[] uint_70;

	// Token: 0x04001B23 RID: 6947
	[CompilerGenerated]
	private uint[] uint_71;

	// Token: 0x04001B24 RID: 6948
	[CompilerGenerated]
	private uint[] uint_72;

	// Token: 0x04001B25 RID: 6949
	[CompilerGenerated]
	private uint[] uint_73;

	// Token: 0x04001B26 RID: 6950
	[CompilerGenerated]
	private uint uint_74;

	// Token: 0x04001B27 RID: 6951
	[CompilerGenerated]
	private uint uint_75;

	// Token: 0x04001B28 RID: 6952
	[CompilerGenerated]
	private uint uint_76;

	// Token: 0x04001B29 RID: 6953
	[CompilerGenerated]
	private uint uint_77;

	// Token: 0x04001B2A RID: 6954
	[CompilerGenerated]
	private uint[] uint_78;

	// Token: 0x04001B2B RID: 6955
	[CompilerGenerated]
	private uint uint_79;

	// Token: 0x04001B2C RID: 6956
	[CompilerGenerated]
	private uint uint_80;

	// Token: 0x04001B2D RID: 6957
	[CompilerGenerated]
	private uint uint_81;

	// Token: 0x04001B2E RID: 6958
	[CompilerGenerated]
	private uint uint_82;

	// Token: 0x04001B2F RID: 6959
	[CompilerGenerated]
	private uint uint_83;

	// Token: 0x04001B30 RID: 6960
	[CompilerGenerated]
	private uint uint_84;

	// Token: 0x04001B31 RID: 6961
	[CompilerGenerated]
	private uint uint_85;

	// Token: 0x04001B32 RID: 6962
	[CompilerGenerated]
	private uint uint_86;

	// Token: 0x04001B33 RID: 6963
	[CompilerGenerated]
	private uint uint_87;

	// Token: 0x04001B34 RID: 6964
	[CompilerGenerated]
	private uint uint_88;

	// Token: 0x04001B35 RID: 6965
	[CompilerGenerated]
	private uint uint_89;

	// Token: 0x04001B36 RID: 6966
	[CompilerGenerated]
	private uint uint_90;

	// Token: 0x04001B37 RID: 6967
	public uint[] uint_91;

	// Token: 0x04001B38 RID: 6968
	[CompilerGenerated]
	private uint uint_92;

	// Token: 0x04001B39 RID: 6969
	[CompilerGenerated]
	private uint uint_93;

	// Token: 0x04001B3A RID: 6970
	[CompilerGenerated]
	private uint uint_94;

	// Token: 0x04001B3B RID: 6971
	[CompilerGenerated]
	private uint uint_95;

	// Token: 0x04001B3C RID: 6972
	[CompilerGenerated]
	private uint uint_96;

	// Token: 0x04001B3D RID: 6973
	[CompilerGenerated]
	private uint uint_97;

	// Token: 0x04001B3E RID: 6974
	[CompilerGenerated]
	private uint uint_98;

	// Token: 0x04001B3F RID: 6975
	[CompilerGenerated]
	private uint uint_99;

	// Token: 0x04001B40 RID: 6976
	[CompilerGenerated]
	private uint uint_100;

	// Token: 0x04001B41 RID: 6977
	[CompilerGenerated]
	private uint uint_101;

	// Token: 0x04001B42 RID: 6978
	[CompilerGenerated]
	private uint[] uint_102;

	// Token: 0x04001B43 RID: 6979
	[CompilerGenerated]
	private uint[] uint_103;

	// Token: 0x04001B44 RID: 6980
	[CompilerGenerated]
	private uint uint_104;

	// Token: 0x04001B45 RID: 6981
	[CompilerGenerated]
	private uint uint_105;

	// Token: 0x04001B46 RID: 6982
	[CompilerGenerated]
	private uint[] uint_106;

	// Token: 0x04001B47 RID: 6983
	[CompilerGenerated]
	private uint uint_107;

	// Token: 0x04001B48 RID: 6984
	[CompilerGenerated]
	private uint uint_108;

	// Token: 0x04001B49 RID: 6985
	[CompilerGenerated]
	private uint uint_109;

	// Token: 0x04001B4A RID: 6986
	[CompilerGenerated]
	private uint[] uint_110;

	// Token: 0x04001B4B RID: 6987
	[CompilerGenerated]
	private uint uint_111;

	// Token: 0x04001B4C RID: 6988
	[CompilerGenerated]
	private uint[] uint_112;

	// Token: 0x04001B4D RID: 6989
	[CompilerGenerated]
	private uint uint_113;

	// Token: 0x04001B4E RID: 6990
	[CompilerGenerated]
	private uint uint_114;

	// Token: 0x04001B4F RID: 6991
	[CompilerGenerated]
	private uint uint_115;

	// Token: 0x04001B50 RID: 6992
	[CompilerGenerated]
	private uint uint_116;

	// Token: 0x04001B51 RID: 6993
	[CompilerGenerated]
	private uint uint_117;

	// Token: 0x04001B52 RID: 6994
	[CompilerGenerated]
	private uint uint_118;

	// Token: 0x04001B53 RID: 6995
	[CompilerGenerated]
	private uint uint_119;

	// Token: 0x04001B54 RID: 6996
	[CompilerGenerated]
	private uint uint_120;

	// Token: 0x04001B55 RID: 6997
	[CompilerGenerated]
	private uint uint_121;

	// Token: 0x04001B56 RID: 6998
	[CompilerGenerated]
	private uint uint_122;

	// Token: 0x04001B57 RID: 6999
	[CompilerGenerated]
	private uint uint_123;

	// Token: 0x04001B58 RID: 7000
	[CompilerGenerated]
	private uint[] uint_124;

	// Token: 0x04001B59 RID: 7001
	[CompilerGenerated]
	private uint[] uint_125;

	// Token: 0x04001B5A RID: 7002
	[CompilerGenerated]
	private uint uint_126;

	// Token: 0x04001B5B RID: 7003
	[CompilerGenerated]
	private uint[] uint_127;

	// Token: 0x04001B5C RID: 7004
	[CompilerGenerated]
	private uint[] uint_128;

	// Token: 0x04001B5D RID: 7005
	[CompilerGenerated]
	private uint[] uint_129;

	// Token: 0x04001B5E RID: 7006
	[CompilerGenerated]
	private uint[] uint_130;

	// Token: 0x04001B5F RID: 7007
	[CompilerGenerated]
	private uint[] uint_131;

	// Token: 0x04001B60 RID: 7008
	[CompilerGenerated]
	private uint[] uint_132;

	// Token: 0x04001B61 RID: 7009
	[CompilerGenerated]
	private uint[] uint_133;

	// Token: 0x04001B62 RID: 7010
	[CompilerGenerated]
	private uint[] uint_134;

	// Token: 0x04001B63 RID: 7011
	[CompilerGenerated]
	private uint[] uint_135;

	// Token: 0x04001B64 RID: 7012
	[CompilerGenerated]
	private uint uint_136;

	// Token: 0x04001B65 RID: 7013
	[CompilerGenerated]
	private uint[] uint_137;

	// Token: 0x04001B66 RID: 7014
	[CompilerGenerated]
	private uint[] uint_138;

	// Token: 0x04001B67 RID: 7015
	[CompilerGenerated]
	private uint[] uint_139;

	// Token: 0x04001B68 RID: 7016
	[CompilerGenerated]
	private uint[] uint_140;

	// Token: 0x04001B69 RID: 7017
	[CompilerGenerated]
	private uint[] uint_141;

	// Token: 0x04001B6A RID: 7018
	[CompilerGenerated]
	private uint[] uint_142;

	// Token: 0x04001B6B RID: 7019
	[CompilerGenerated]
	private uint[] uint_143;

	// Token: 0x04001B6C RID: 7020
	[CompilerGenerated]
	private uint uint_144;

	// Token: 0x04001B6D RID: 7021
	[CompilerGenerated]
	private uint uint_145;

	// Token: 0x04001B6E RID: 7022
	[CompilerGenerated]
	private uint[] uint_146;

	// Token: 0x04001B6F RID: 7023
	[CompilerGenerated]
	private uint[] uint_147;

	// Token: 0x04001B70 RID: 7024
	[CompilerGenerated]
	private uint[] uint_148;

	// Token: 0x04001B71 RID: 7025
	[CompilerGenerated]
	private uint[] uint_149;

	// Token: 0x04001B72 RID: 7026
	[CompilerGenerated]
	private uint[] uint_150;

	// Token: 0x04001B73 RID: 7027
	[CompilerGenerated]
	private uint[] uint_151;

	// Token: 0x04001B74 RID: 7028
	[CompilerGenerated]
	private uint uint_152;

	// Token: 0x04001B75 RID: 7029
	[CompilerGenerated]
	private uint uint_153;

	// Token: 0x04001B76 RID: 7030
	[CompilerGenerated]
	private uint[] uint_154;

	// Token: 0x04001B77 RID: 7031
	[CompilerGenerated]
	private uint[] uint_155;

	// Token: 0x04001B78 RID: 7032
	[CompilerGenerated]
	private uint[] uint_156;

	// Token: 0x04001B79 RID: 7033
	[CompilerGenerated]
	private uint[] uint_157;

	// Token: 0x04001B7A RID: 7034
	[CompilerGenerated]
	private uint[] uint_158;

	// Token: 0x04001B7B RID: 7035
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001B7C RID: 7036
	[CompilerGenerated]
	private uint uint_159;

	// Token: 0x04001B7D RID: 7037
	[CompilerGenerated]
	private uint uint_160;

	// Token: 0x04001B7E RID: 7038
	[CompilerGenerated]
	private uint[] uint_161;

	// Token: 0x04001B7F RID: 7039
	[CompilerGenerated]
	private uint[] uint_162;

	// Token: 0x04001B80 RID: 7040
	[CompilerGenerated]
	private uint[] uint_163;
}
