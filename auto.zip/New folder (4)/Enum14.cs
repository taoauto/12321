﻿using System;

// Token: 0x020001C1 RID: 449
internal enum Enum14
{
	// Token: 0x04000DD9 RID: 3545
	TriLieu,
	// Token: 0x04000DDA RID: 3546
	BanRac,
	// Token: 0x04000DDB RID: 3547
	CatVang,
	// Token: 0x04000DDC RID: 3548
	CatDo,
	// Token: 0x04000DDD RID: 3549
	LayDo,
	// Token: 0x04000DDE RID: 3550
	LayVang,
	// Token: 0x04000DDF RID: 3551
	PhanGiaiTrangBiPet,
	// Token: 0x04000DE0 RID: 3552
	NhanChienCong,
	// Token: 0x04000DE1 RID: 3553
	NhanKiemChi,
	// Token: 0x04000DE2 RID: 3554
	NhanThuongQuanSonHai,
	// Token: 0x04000DE3 RID: 3555
	NhanThuongTyVo,
	// Token: 0x04000DE4 RID: 3556
	NhanBuaBaoRuong,
	// Token: 0x04000DE5 RID: 3557
	NhanLeBao,
	// Token: 0x04000DE6 RID: 3558
	NhanBong,
	// Token: 0x04000DE7 RID: 3559
	NhanKeoHallowen,
	// Token: 0x04000DE8 RID: 3560
	NhanBoiThuong,
	// Token: 0x04000DE9 RID: 3561
	LuyenKimNhanh,
	// Token: 0x04000DEA RID: 3562
	ChucPhucMaoBut,
	// Token: 0x04000DEB RID: 3563
	BonHoa,
	// Token: 0x04000DEC RID: 3564
	TrongHoa,
	// Token: 0x04000DED RID: 3565
	DoiHuyenSacCauThienThai,
	// Token: 0x04000DEE RID: 3566
	DoiKimTamTy,
	// Token: 0x04000DEF RID: 3567
	Doi999HoaHong,
	// Token: 0x04000DF0 RID: 3568
	DoiLoanPhiMatHam,
	// Token: 0x04000DF1 RID: 3569
	DoiChanNguyenLinhPhach,
	// Token: 0x04000DF2 RID: 3570
	DoiTiemNangTan,
	// Token: 0x04000DF3 RID: 3571
	DoiDaiLeHungVuong,
	// Token: 0x04000DF4 RID: 3572
	ThanhLyNhiemVu,
	// Token: 0x04000DF5 RID: 3573
	HuyVatPhamQuy,
	// Token: 0x04000DF6 RID: 3574
	DaiLeHungVuong,
	// Token: 0x04000DF7 RID: 3575
	DungDoatBaoRuong,
	// Token: 0x04000DF8 RID: 3576
	BachHoaDuyen,
	// Token: 0x04000DF9 RID: 3577
	NhanBienThan,
	// Token: 0x04000DFA RID: 3578
	TruAc,
	// Token: 0x04000DFB RID: 3579
	KhaiKhoang,
	// Token: 0x04000DFC RID: 3580
	HaiDuoc,
	// Token: 0x04000DFD RID: 3581
	TrongTrot,
	// Token: 0x04000DFE RID: 3582
	AutoBuyKNB,
	// Token: 0x04000DFF RID: 3583
	LoLyHoa,
	// Token: 0x04000E00 RID: 3584
	GomDo,
	// Token: 0x04000E01 RID: 3585
	GomDoKNB,
	// Token: 0x04000E02 RID: 3586
	NhanQuaBuiHoaHong,
	// Token: 0x04000E03 RID: 3587
	NhanHoaHongLo,
	// Token: 0x04000E04 RID: 3588
	NhiemVuVoY,
	// Token: 0x04000E05 RID: 3589
	NangTamPhap,
	// Token: 0x04000E06 RID: 3590
	Quyen3Len30,
	// Token: 0x04000E07 RID: 3591
	TuLuyenCuongLuc,
	// Token: 0x04000E08 RID: 3592
	TuLuyenNoiLuc,
	// Token: 0x04000E09 RID: 3593
	TuLuyenTheLuc,
	// Token: 0x04000E0A RID: 3594
	TuLuyenThanPhap,
	// Token: 0x04000E0B RID: 3595
	TuLuyenTheNoiThan,
	// Token: 0x04000E0C RID: 3596
	NhiemVuChinhTuyen,
	// Token: 0x04000E0D RID: 3597
	NguyenVongThienLinh,
	// Token: 0x04000E0E RID: 3598
	GiaoNguHanhPhapThiep,
	// Token: 0x04000E0F RID: 3599
	NopTuViHuyTinh,
	// Token: 0x04000E10 RID: 3600
	TangCapTruongThanhLongVan,
	// Token: 0x04000E11 RID: 3601
	SinhTieu,
	// Token: 0x04000E12 RID: 3602
	NhanPhiThuy,
	// Token: 0x04000E13 RID: 3603
	TrungAc,
	// Token: 0x04000E14 RID: 3604
	ThuTaiVanMay,
	// Token: 0x04000E15 RID: 3605
	ThanKhi9Sao,
	// Token: 0x04000E16 RID: 3606
	VoTuPho,
	// Token: 0x04000E17 RID: 3607
	LuyenKim,
	// Token: 0x04000E18 RID: 3608
	TuBaoBon,
	// Token: 0x04000E19 RID: 3609
	TuDuongCon,
	// Token: 0x04000E1A RID: 3610
	NhanCon,
	// Token: 0x04000E1B RID: 3611
	LongPhuMau,
	// Token: 0x04000E1C RID: 3612
	ThienLongTueHong,
	// Token: 0x04000E1D RID: 3613
	NhiemVuSuMon,
	// Token: 0x04000E1E RID: 3614
	NhiemVuThangCap,
	// Token: 0x04000E1F RID: 3615
	NhiemVuExp,
	// Token: 0x04000E20 RID: 3616
	NgoChanNguyen,
	// Token: 0x04000E21 RID: 3617
	NhiemVuKNBKhoa,
	// Token: 0x04000E22 RID: 3618
	MoBaoTangDo,
	// Token: 0x04000E23 RID: 3619
	DiMuaNga,
	// Token: 0x04000E24 RID: 3620
	DatDoiPhieuMieuPhong,
	// Token: 0x04000E25 RID: 3621
	DatDoiKhieuChienPhieuMieuPhong,
	// Token: 0x04000E26 RID: 3622
	DatDoiYenTuO,
	// Token: 0x04000E27 RID: 3623
	DatDoiTuTuyetTrang,
	// Token: 0x04000E28 RID: 3624
	DatDoiThieuThatSon,
	// Token: 0x04000E29 RID: 3625
	DatDoiSatTinh,
	// Token: 0x04000E2A RID: 3626
	DatDoiQ123LauLan,
	// Token: 0x04000E2B RID: 3627
	DatDoiQ123ToChau,
	// Token: 0x04000E2C RID: 3628
	DatDoiPhucDia,
	// Token: 0x04000E2D RID: 3629
	DatDoiVuongLang,
	// Token: 0x04000E2E RID: 3630
	DatDoiTamThan,
	// Token: 0x04000E2F RID: 3631
	DatDoiAcTac,
	// Token: 0x04000E30 RID: 3632
	DatDoiAcBa,
	// Token: 0x04000E31 RID: 3633
	DatDoiTangKinhCac,
	// Token: 0x04000E32 RID: 3634
	DatDoiLauLanTamBao,
	// Token: 0x04000E33 RID: 3635
	DatDoiKyCuoc,
	// Token: 0x04000E34 RID: 3636
	DatDoiTucCau,
	// Token: 0x04000E35 RID: 3637
	DatDoiDaTru,
	// Token: 0x04000E36 RID: 3638
	DatDoiMongHeo,
	// Token: 0x04000E37 RID: 3639
	DatDoiThienGiangKyThu,
	// Token: 0x04000E38 RID: 3640
	DatDoiPhungHoangLangMo,
	// Token: 0x04000E39 RID: 3641
	DatDoiMaTac,
	// Token: 0x04000E3A RID: 3642
	DatDoiBaoDoHiem,
	// Token: 0x04000E3B RID: 3643
	DatDoiQuanSonHai,
	// Token: 0x04000E3C RID: 3644
	DatDoiBossMap,
	// Token: 0x04000E3D RID: 3645
	DatDoiTyVo,
	// Token: 0x04000E3E RID: 3646
	DatDoiBinhThanh,
	// Token: 0x04000E3F RID: 3647
	LauLanTamBaoNhanh,
	// Token: 0x04000E40 RID: 3648
	KyCuocNhanh,
	// Token: 0x04000E41 RID: 3649
	PhucDiaKho,
	// Token: 0x04000E42 RID: 3650
	BinhThanhKho,
	// Token: 0x04000E43 RID: 3651
	ThoiBong,
	// Token: 0x04000E44 RID: 3652
	LinhLuong,
	// Token: 0x04000E45 RID: 3653
	DungThoLinhChau,
	// Token: 0x04000E46 RID: 3654
	DungDinhViPhu,
	// Token: 0x04000E47 RID: 3655
	LayDoThienCo,
	// Token: 0x04000E48 RID: 3656
	HopDienTich,
	// Token: 0x04000E49 RID: 3657
	HopVoHon,
	// Token: 0x04000E4A RID: 3658
	CheThanKhi,
	// Token: 0x04000E4B RID: 3659
	MoShopTrungDo,
	// Token: 0x04000E4C RID: 3660
	MoShopHungBa,
	// Token: 0x04000E4D RID: 3661
	MoShopBachBaoCac,
	// Token: 0x04000E4E RID: 3662
	MoShopQuyThi,
	// Token: 0x04000E4F RID: 3663
	MoTiemThuoc,
	// Token: 0x04000E50 RID: 3664
	SuaVoHon,
	// Token: 0x04000E51 RID: 3665
	SuaTrangBi,
	// Token: 0x04000E52 RID: 3666
	SuaThanKhi,
	// Token: 0x04000E53 RID: 3667
	GomVang,
	// Token: 0x04000E54 RID: 3668
	DuaBaoDoHiem,
	// Token: 0x04000E55 RID: 3669
	NhanX2,
	// Token: 0x04000E56 RID: 3670
	DongX2,
	// Token: 0x04000E57 RID: 3671
	Mua100KimSangDuoc,
	// Token: 0x04000E58 RID: 3672
	TrangSucCuuLe,
	// Token: 0x04000E59 RID: 3673
	TamKy,
	// Token: 0x04000E5A RID: 3674
	DuaTangBaoDo,
	// Token: 0x04000E5B RID: 3675
	GomKNB
}
