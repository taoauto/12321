﻿using System;
using System.IO;

// Token: 0x02000025 RID: 37
public class GClass14 : GClass9
{
	// Token: 0x060001DF RID: 479 RVA: 0x000268EC File Offset: 0x00024AEC
	public GClass14(Stream stream_1, int int_1 = 32768)
	{
		if (stream_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (!stream_1.CanRead || !stream_1.CanSeek)
		{
			throw new ArgumentException(Class2.String_0, "content");
		}
		if (int_1 < 1)
		{
			throw Class13.smethod_1<int>("bufferSize", 1);
		}
		this.stream_0 = stream_1;
		this.int_0 = int_1;
		this.long_0 = this.stream_0.Position;
		this.string_0 = "application/octet-stream";
	}

	// Token: 0x060001E0 RID: 480 RVA: 0x0000428E File Offset: 0x0000248E
	protected GClass14()
	{
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x0000439A File Offset: 0x0000259A
	public override long \u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E()
	{
		this.method_1();
		return this.stream_0.Length;
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00026968 File Offset: 0x00024B68
	public override void \u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(Stream stream_1)
	{
		this.method_1();
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		this.stream_0.Position = this.long_0;
		byte[] array = new byte[this.int_0];
		for (;;)
		{
			int num = this.stream_0.Read(array, 0, array.Length);
			if (num == 0)
			{
				break;
			}
			stream_1.Write(array, 0, num);
		}
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x000043AD File Offset: 0x000025AD
	protected override void \u206D\u206A\u200B\u202A\u202C\u202B\u206A\u202E\u200E\u202C\u206B\u202D\u206D\u206C\u206B\u200B\u200E\u200E\u206D\u206B\u206C\u206F\u200F\u200E\u206C\u202C\u206C\u206A\u200B\u200D\u206A\u200F\u200C\u200C\u202C\u202E\u206C\u200D\u202A\u200D\u202E(bool bool_0)
	{
		if (bool_0 && this.stream_0 != null)
		{
			this.stream_0.Dispose();
			this.stream_0 = null;
		}
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x000043CC File Offset: 0x000025CC
	private void method_1()
	{
		if (this.stream_0 == null)
		{
			throw new ObjectDisposedException("StreamContent");
		}
	}

	// Token: 0x0400011E RID: 286
	protected Stream stream_0;

	// Token: 0x0400011F RID: 287
	protected int int_0;

	// Token: 0x04000120 RID: 288
	protected long long_0;
}
