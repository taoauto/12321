﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000185 RID: 389
[Serializable]
[StructLayout(LayoutKind.Explicit)]
public struct GStruct14
{
	// Token: 0x040009FB RID: 2555
	[FieldOffset(4)]
	public uint DataEntryRva;

	// Token: 0x040009FC RID: 2556
	[FieldOffset(0)]
	public uint IntegerId;

	// Token: 0x040009FD RID: 2557
	[FieldOffset(0)]
	public uint NameRva;

	// Token: 0x040009FE RID: 2558
	[FieldOffset(4)]
	public uint SubdirectoryRva;
}
