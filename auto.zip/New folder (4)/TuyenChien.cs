﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x02000205 RID: 517
internal class TuyenChien : UserControl
{
	// Token: 0x06001ACB RID: 6859 RVA: 0x000136C8 File Offset: 0x000118C8
	public TuyenChien()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001ACC RID: 6860 RVA: 0x000C91A4 File Offset: 0x000C73A4
	private void TuyenChien_Load(object sender, EventArgs e)
	{
		this.txtName.Text = Class415.String_28;
		this.txtGuildName.Text = Class415.String_29;
		this.txtNameIgnore.Text = Class415.String_30;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_7 && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
					this.listViewIgnore.Items.Add(@class.String_2);
				}
			}
		}
		this.hashSet_0.Clear();
		foreach (KeyValuePair<int, Class159> keyValuePair2 in Main.dictionary_3)
		{
			foreach (Class393 class2 in keyValuePair2.Value.Class394_0.list_0)
			{
				if (!(class2.String_8.Trim() == "") && class2.Boolean_7 && !this.hashSet_0.Contains(class2.String_8))
				{
					this.hashSet_0.Add(class2.String_8);
					this.listViewGuildName.Items.Add(class2.String_8);
				}
			}
		}
	}

	// Token: 0x06001ACD RID: 6861 RVA: 0x000136E1 File Offset: 0x000118E1
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001ACE RID: 6862 RVA: 0x000C93D8 File Offset: 0x000C75D8
	private void method_0()
	{
		foreach (object obj in this.listViewName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtName.Text = this.txtName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtName.method_1();
	}

	// Token: 0x06001ACF RID: 6863 RVA: 0x000C94D8 File Offset: 0x000C76D8
	private void method_1()
	{
		foreach (object obj in this.listViewGuildName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtGuildName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtGuildName.Text = this.txtGuildName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtGuildName.method_1();
	}

	// Token: 0x06001AD0 RID: 6864 RVA: 0x000136E9 File Offset: 0x000118E9
	private void listViewGuildName_DoubleClick(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06001AD1 RID: 6865 RVA: 0x000C95D8 File Offset: 0x000C77D8
	private void method_2()
	{
		foreach (object obj in this.listViewIgnore.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtNameIgnore.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtNameIgnore.Text = this.txtNameIgnore.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtNameIgnore.method_1();
	}

	// Token: 0x06001AD2 RID: 6866 RVA: 0x000136F1 File Offset: 0x000118F1
	private void listViewIgnore_DoubleClick(object sender, EventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06001AD3 RID: 6867 RVA: 0x000136F9 File Offset: 0x000118F9
	private void btnOk_Click(object sender, EventArgs e)
	{
		Class415.String_28 = this.txtName.Text;
		Class415.String_29 = this.txtGuildName.Text;
		Class415.String_30 = this.txtNameIgnore.Text;
		Class415.smethod_0();
	}

	// Token: 0x06001AD4 RID: 6868 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_3(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06001AD5 RID: 6869 RVA: 0x00002E18 File Offset: 0x00001018
	private void txtName_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001AD6 RID: 6870 RVA: 0x00013730 File Offset: 0x00011930
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001AD7 RID: 6871 RVA: 0x000C96D8 File Offset: 0x000C78D8
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(TuyenChien));
		this.listViewName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtName = new Class85();
		this.listViewGuildName = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.txtGuildName = new Class85();
		this.listViewIgnore = new ListViewEx();
		this.columnHeader_2 = new ColumnHeader();
		this.txtNameIgnore = new Class85();
		this.btnOk = new Button();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.splitContainer1 = new SplitContainer();
		this.tabPage2 = new TabPage();
		this.splitContainer2 = new SplitContainer();
		this.tabPage3 = new TabPage();
		this.splitContainer3 = new SplitContainer();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabPage2.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.tabPage3.SuspendLayout();
		this.splitContainer3.Panel1.SuspendLayout();
		this.splitContainer3.Panel2.SuspendLayout();
		this.splitContainer3.SuspendLayout();
		base.SuspendLayout();
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.Dock = DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = Color.Red;
		this.listViewName.Location = new Point(0, 0);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new Size(247, 271);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = View.Details;
		this.listViewName.DoubleClick += this.listViewName_DoubleClick;
		this.columnHeader_0.Text = "Tên người chơi";
		this.columnHeader_0.Width = 181;
		this.txtName.Dock = DockStyle.Fill;
		this.txtName.Location = new Point(0, 0);
		this.txtName.Multiline = true;
		this.txtName.Name = "txtName";
		this.txtName.ScrollBars = ScrollBars.Vertical;
		this.txtName.Size = new Size(185, 271);
		this.txtName.TabIndex = 6;
		this.txtName.String_0 = "";
		this.txtName.Color_0 = Color.Gray;
		this.txtName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtName.Color_1 = Color.LightGray;
		this.txtName.TextChanged += this.txtName_TextChanged;
		this.listViewGuildName.AllowColumnReorder = true;
		this.listViewGuildName.AllowDrop = true;
		this.listViewGuildName.AllowReorder = true;
		this.listViewGuildName.AllowSort = true;
		this.listViewGuildName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1
		});
		this.listViewGuildName.Dock = DockStyle.Fill;
		this.listViewGuildName.DoubleClickActivation = false;
		this.listViewGuildName.FullRowSelect = true;
		this.listViewGuildName.GridLines = true;
		this.listViewGuildName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewGuildName.hideItems");
		this.listViewGuildName.HideSelection = false;
		this.listViewGuildName.LineColor = Color.Red;
		this.listViewGuildName.Location = new Point(0, 0);
		this.listViewGuildName.Name = "listViewGuildName";
		this.listViewGuildName.Size = new Size(247, 271);
		this.listViewGuildName.TabIndex = 9;
		this.listViewGuildName.UseCompatibleStateImageBehavior = false;
		this.listViewGuildName.View = View.Details;
		this.listViewGuildName.DoubleClick += this.listViewGuildName_DoubleClick;
		this.columnHeader_1.Text = "Tên bang";
		this.columnHeader_1.Width = 181;
		this.txtGuildName.Dock = DockStyle.Fill;
		this.txtGuildName.Location = new Point(0, 0);
		this.txtGuildName.Multiline = true;
		this.txtGuildName.Name = "txtGuildName";
		this.txtGuildName.ScrollBars = ScrollBars.Vertical;
		this.txtGuildName.Size = new Size(185, 271);
		this.txtGuildName.TabIndex = 8;
		this.txtGuildName.String_0 = "";
		this.txtGuildName.Color_0 = Color.Gray;
		this.txtGuildName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtGuildName.Color_1 = Color.LightGray;
		this.listViewIgnore.AllowColumnReorder = true;
		this.listViewIgnore.AllowDrop = true;
		this.listViewIgnore.AllowReorder = true;
		this.listViewIgnore.AllowSort = true;
		this.listViewIgnore.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_2
		});
		this.listViewIgnore.Dock = DockStyle.Fill;
		this.listViewIgnore.DoubleClickActivation = false;
		this.listViewIgnore.FullRowSelect = true;
		this.listViewIgnore.GridLines = true;
		this.listViewIgnore.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewIgnore.hideItems");
		this.listViewIgnore.HideSelection = false;
		this.listViewIgnore.LineColor = Color.Red;
		this.listViewIgnore.Location = new Point(0, 0);
		this.listViewIgnore.Name = "listViewIgnore";
		this.listViewIgnore.Size = new Size(247, 271);
		this.listViewIgnore.TabIndex = 11;
		this.listViewIgnore.UseCompatibleStateImageBehavior = false;
		this.listViewIgnore.View = View.Details;
		this.listViewIgnore.DoubleClick += this.listViewIgnore_DoubleClick;
		this.columnHeader_2.Text = "Tên người chơi không đánh";
		this.columnHeader_2.Width = 181;
		this.txtNameIgnore.Dock = DockStyle.Fill;
		this.txtNameIgnore.Location = new Point(0, 0);
		this.txtNameIgnore.Multiline = true;
		this.txtNameIgnore.Name = "txtNameIgnore";
		this.txtNameIgnore.ScrollBars = ScrollBars.Vertical;
		this.txtNameIgnore.Size = new Size(185, 271);
		this.txtNameIgnore.TabIndex = 10;
		this.txtNameIgnore.String_0 = "";
		this.txtNameIgnore.Color_0 = Color.Gray;
		this.txtNameIgnore.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtNameIgnore.Color_1 = Color.LightGray;
		this.btnOk.Dock = DockStyle.Bottom;
		this.btnOk.Location = new Point(0, 303);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new Size(450, 23);
		this.btnOk.TabIndex = 15;
		this.btnOk.Text = "Ok";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += this.btnOk_Click;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Controls.Add(this.tabPage3);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(450, 303);
		this.tabControlEx1.TabIndex = 19;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(442, 277);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Đánh Người";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtName);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Size = new Size(436, 271);
		this.splitContainer1.SplitterDistance = 185;
		this.splitContainer1.TabIndex = 0;
		this.tabPage2.Controls.Add(this.splitContainer2);
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(442, 277);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Đánh Bang";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.Location = new Point(3, 3);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Panel1.Controls.Add(this.txtGuildName);
		this.splitContainer2.Panel2.Controls.Add(this.listViewGuildName);
		this.splitContainer2.Size = new Size(436, 271);
		this.splitContainer2.SplitterDistance = 185;
		this.splitContainer2.TabIndex = 1;
		this.tabPage3.Controls.Add(this.splitContainer3);
		this.tabPage3.Location = new Point(4, 22);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new Padding(3);
		this.tabPage3.Size = new Size(442, 277);
		this.tabPage3.TabIndex = 2;
		this.tabPage3.Text = "Không Đánh";
		this.tabPage3.UseVisualStyleBackColor = true;
		this.splitContainer3.Dock = DockStyle.Fill;
		this.splitContainer3.Location = new Point(3, 3);
		this.splitContainer3.Name = "splitContainer3";
		this.splitContainer3.Panel1.Controls.Add(this.txtNameIgnore);
		this.splitContainer3.Panel2.Controls.Add(this.listViewIgnore);
		this.splitContainer3.Size = new Size(436, 271);
		this.splitContainer3.SplitterDistance = 185;
		this.splitContainer3.TabIndex = 1;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Controls.Add(this.btnOk);
		base.Name = "TuyenChien";
		base.Size = new Size(450, 326);
		base.Tag = "Tuyên Chiến - PK";
		base.Load += this.TuyenChien_Load;
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.tabPage2.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel1.PerformLayout();
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.tabPage3.ResumeLayout(false);
		this.splitContainer3.Panel1.ResumeLayout(false);
		this.splitContainer3.Panel1.PerformLayout();
		this.splitContainer3.Panel2.ResumeLayout(false);
		this.splitContainer3.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040010BC RID: 4284
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040010BD RID: 4285
	private IContainer icontainer_0;

	// Token: 0x040010BE RID: 4286
	private ListViewEx listViewName;

	// Token: 0x040010BF RID: 4287
	private ColumnHeader columnHeader_0;

	// Token: 0x040010C0 RID: 4288
	private Class85 txtName;

	// Token: 0x040010C1 RID: 4289
	private ListViewEx listViewGuildName;

	// Token: 0x040010C2 RID: 4290
	private ColumnHeader columnHeader_1;

	// Token: 0x040010C3 RID: 4291
	private Class85 txtGuildName;

	// Token: 0x040010C4 RID: 4292
	private ListViewEx listViewIgnore;

	// Token: 0x040010C5 RID: 4293
	private ColumnHeader columnHeader_2;

	// Token: 0x040010C6 RID: 4294
	private Class85 txtNameIgnore;

	// Token: 0x040010C7 RID: 4295
	private Button btnOk;

	// Token: 0x040010C8 RID: 4296
	private Control1 tabControlEx1;

	// Token: 0x040010C9 RID: 4297
	private TabPage tabPage1;

	// Token: 0x040010CA RID: 4298
	private SplitContainer splitContainer1;

	// Token: 0x040010CB RID: 4299
	private TabPage tabPage2;

	// Token: 0x040010CC RID: 4300
	private SplitContainer splitContainer2;

	// Token: 0x040010CD RID: 4301
	private TabPage tabPage3;

	// Token: 0x040010CE RID: 4302
	private SplitContainer splitContainer3;
}
