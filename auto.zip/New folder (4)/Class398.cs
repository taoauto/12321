﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

// Token: 0x020002CD RID: 717
internal class Class398 : ListView
{
	// Token: 0x06002980 RID: 10624 RVA: 0x0011CCA0 File Offset: 0x0011AEA0
	public Class398()
	{
		base.View = View.Details;
		base.FullRowSelect = true;
		base.GridLines = true;
		base.HideSelection = false;
		base.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
		Class398.SendMessage(base.Handle, 295, this.method_2(1, 1), 0);
	}

	// Token: 0x06002981 RID: 10625
	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern IntPtr SendMessage(IntPtr intptr_0, int int_3, int int_4, int int_5);

	// Token: 0x06002982 RID: 10626 RVA: 0x0001E758 File Offset: 0x0001C958
	public void method_0()
	{
		this.dictionary_0.Clear();
		this.List_0.Clear();
	}

	// Token: 0x06002983 RID: 10627 RVA: 0x0011CD0C File Offset: 0x0011AF0C
	public List<ListViewItem> method_1(string string_1)
	{
		Class398.Class399 @class = new Class398.Class399();
		@class.class398_0 = this;
		if (this.dictionary_0.Count != base.Items.Count + this.List_0.Count)
		{
			foreach (object obj in base.Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (!this.dictionary_0.ContainsValue(listViewItem))
				{
					this.dictionary_0.Add(listViewItem.Index, listViewItem);
				}
			}
			foreach (ListViewItem listViewItem2 in this.List_0)
			{
				if (!this.dictionary_0.ContainsValue(listViewItem2))
				{
					this.dictionary_0.Add(listViewItem2.Index, listViewItem2);
				}
			}
		}
		@class.list_0 = new List<ListViewItem>();
		List<ListViewItem> list = new List<ListViewItem>();
		@class.string_0 = Class398.smethod_1(string_1);
		base.Items.Cast<ListViewItem>().ToList<ListViewItem>().ForEach(new Action<ListViewItem>(@class.method_0));
		this.List_0.ForEach(new Action<ListViewItem>(@class.method_1));
		@class.list_0.ForEach(new Action<ListViewItem>(@class.method_2));
		foreach (KeyValuePair<int, ListViewItem> keyValuePair in this.dictionary_0)
		{
			if (!this.List_0.Contains(keyValuePair.Value))
			{
				list.Add(keyValuePair.Value);
			}
		}
		base.Items.Clear();
		base.Items.AddRange(list.ToArray());
		return @class.list_0;
	}

	// Token: 0x06002984 RID: 10628 RVA: 0x0001E770 File Offset: 0x0001C970
	public static string smethod_0(string string_1)
	{
		if (string.IsNullOrEmpty(string_1))
		{
			return string.Empty;
		}
		return Class398.smethod_2(Class398.smethod_3(string_1));
	}

	// Token: 0x06002985 RID: 10629 RVA: 0x0001E78B File Offset: 0x0001C98B
	public static string smethod_1(string string_1)
	{
		return Class398.smethod_0(string_1).ToLower();
	}

	// Token: 0x06002986 RID: 10630 RVA: 0x0011CF04 File Offset: 0x0011B104
	public static string smethod_2(string string_1)
	{
		if (string.IsNullOrEmpty(string_1))
		{
			return string.Empty;
		}
		for (int i = 1; i < Class398.string_0.Length; i++)
		{
			for (int j = 0; j < Class398.string_0[i].Length; j++)
			{
				string_1 = string_1.Replace(Class398.string_0[i][j], Class398.string_0[0][i - 1]);
			}
		}
		return string_1;
	}

	// Token: 0x06002987 RID: 10631 RVA: 0x0011CF70 File Offset: 0x0011B170
	public static string smethod_3(string string_1)
	{
		if (string.IsNullOrEmpty(string_1))
		{
			return string.Empty;
		}
		return new string(string_1.ToCharArray().Where(new Func<char, bool>(Class398.Class400.<>9.method_0)).ToArray<char>());
	}

	// Token: 0x1700098A RID: 2442
	// (get) Token: 0x06002988 RID: 10632 RVA: 0x0001E798 File Offset: 0x0001C998
	// (set) Token: 0x06002989 RID: 10633 RVA: 0x0001E7A0 File Offset: 0x0001C9A0
	private List<ListViewItem> List_0 { get; set; } = new List<ListViewItem>();

	// Token: 0x0600298A RID: 10634 RVA: 0x0011CFC0 File Offset: 0x0011B1C0
	private int method_2(int int_3, int int_4)
	{
		int num = (int)this.method_3(int_3);
		short num2 = this.method_3(int_4);
		int num3 = 65536 * (int)num2;
		return num | num3;
	}

	// Token: 0x0600298B RID: 10635 RVA: 0x0001E7A9 File Offset: 0x0001C9A9
	private short method_3(int int_3)
	{
		return (short)(int_3 & 32767);
	}

	// Token: 0x04001BCF RID: 7119
	private static readonly string[] string_0 = new string[]
	{
		"aAeEoOuUiIdDyY",
		"áàạảãâấầậẩẫăắằặẳẵ",
		"ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
		"éèẹẻẽêếềệểễ",
		"ÉÈẸẺẼÊẾỀỆỂỄ",
		"óòọỏõôốồộổỗơớờợởỡ",
		"ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
		"úùụủũưứừựửữ",
		"ÚÙỤỦŨƯỨỪỰỬỮ",
		"íìịỉĩ",
		"ÍÌỊỈĨ",
		"đ",
		"Đ",
		"ýỳỵỷỹ",
		"ÝỲỴỶỸ"
	};

	// Token: 0x04001BD0 RID: 7120
	private Dictionary<int, ListViewItem> dictionary_0 = new Dictionary<int, ListViewItem>();

	// Token: 0x04001BD1 RID: 7121
	[CompilerGenerated]
	private List<ListViewItem> list_0;

	// Token: 0x04001BD2 RID: 7122
	private const int int_0 = 295;

	// Token: 0x04001BD3 RID: 7123
	private const int int_1 = 1;

	// Token: 0x04001BD4 RID: 7124
	private const int int_2 = 1;

	// Token: 0x020002CE RID: 718
	[CompilerGenerated]
	private sealed class Class399
	{
		// Token: 0x0600298E RID: 10638 RVA: 0x0011D080 File Offset: 0x0011B280
		internal void method_0(ListViewItem listViewItem_0)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (object obj in listViewItem_0.SubItems)
			{
				stringBuilder.Append(Class398.smethod_1(obj.ToString()));
			}
			if (stringBuilder.ToString().Contains(this.string_0))
			{
				this.list_0.Add(listViewItem_0);
				return;
			}
			this.class398_0.List_0.Add(listViewItem_0);
		}

		// Token: 0x0600298F RID: 10639 RVA: 0x0011D118 File Offset: 0x0011B318
		internal void method_1(ListViewItem listViewItem_0)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (object obj in listViewItem_0.SubItems)
			{
				stringBuilder.Append(Class398.smethod_1(obj.ToString()));
			}
			if (stringBuilder.ToString().Contains(this.string_0))
			{
				this.list_0.Add(listViewItem_0);
			}
		}

		// Token: 0x06002990 RID: 10640 RVA: 0x0001E7B3 File Offset: 0x0001C9B3
		internal void method_2(ListViewItem listViewItem_0)
		{
			if (!this.class398_0.Items.Contains(listViewItem_0))
			{
				this.class398_0.Items.Add(listViewItem_0);
				this.class398_0.List_0.Remove(listViewItem_0);
			}
		}

		// Token: 0x04001BD5 RID: 7125
		public string string_0;

		// Token: 0x04001BD6 RID: 7126
		public List<ListViewItem> list_0;

		// Token: 0x04001BD7 RID: 7127
		public Class398 class398_0;
	}

	// Token: 0x020002CF RID: 719
	[CompilerGenerated]
	[Serializable]
	private sealed class Class400
	{
		// Token: 0x06002993 RID: 10643 RVA: 0x0001E7F8 File Offset: 0x0001C9F8
		internal bool method_0(char char_0)
		{
			return !char.IsWhiteSpace(char_0);
		}

		// Token: 0x04001BD8 RID: 7128
		public static readonly Class398.Class400 <>9 = new Class398.Class400();

		// Token: 0x04001BD9 RID: 7129
		public static Func<char, bool> <>9__8_0;
	}
}
