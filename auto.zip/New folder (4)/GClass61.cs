﻿using System;

// Token: 0x020000CA RID: 202
public abstract class GClass61 : GClass60
{
	// Token: 0x060009AA RID: 2474 RVA: 0x00009522 File Offset: 0x00007722
	public GClass61(GClass99 gclass99_1)
	{
		this.gclass99_0 = gclass99_1;
		this.class90_0 = new Class90(gclass99_1.FastColoredTextBox_0.GClass86_5);
	}

	// Token: 0x060009AB RID: 2475 RVA: 0x00009547 File Offset: 0x00007747
	public virtual void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.GClass61.\u206B\u206F\u206F\u206C\u200C\u206F\u206C\u206E\u202D\u206D\u206A\u206D\u200D\u206C\u202D\u206B\u200F\u206F\u200B\u202A\u206F\u202C\u202C\u202C\u202B\u202E\u206E\u202A\u202A\u206D\u200E\u202B\u202D\u200F\u206F\u206C\u206F\u206B\u206D\u206A\u202E(true);
	}

	// Token: 0x060009AC RID: 2476 RVA: 0x00009550 File Offset: 0x00007750
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		this.class90_1 = new Class90(this.gclass99_0.FastColoredTextBox_0.GClass86_5);
		this.GClass61.\u206B\u206F\u206F\u206C\u200C\u206F\u206C\u206E\u202D\u206D\u206A\u206D\u200D\u206C\u202D\u206B\u200F\u206F\u200B\u202A\u206F\u202C\u202C\u202C\u202B\u202E\u206E\u202A\u202A\u206D\u200E\u202B\u202D\u200F\u206F\u206C\u206F\u206B\u206D\u206A\u202E(false);
	}

	// Token: 0x060009AD RID: 2477 RVA: 0x0003EB54 File Offset: 0x0003CD54
	protected virtual void \u206B\u206F\u206F\u206C\u200C\u206F\u206C\u206E\u202D\u206D\u206A\u206D\u200D\u206C\u202D\u206B\u200F\u206F\u200B\u202A\u206F\u202C\u202C\u202C\u202B\u202E\u206E\u202A\u202A\u206D\u200E\u202B\u202D\u200F\u206F\u206C\u206F\u206B\u206D\u206A\u202E(bool bool_1)
	{
		bool flag = this.class90_0.GStruct2_0.int_1 < this.class90_1.GStruct2_0.int_1;
		if (bool_1)
		{
			if (flag)
			{
				this.gclass99_0.vmethod_10(this.class90_0.GStruct2_0.int_1, this.class90_0.GStruct2_0.int_1);
				return;
			}
			this.gclass99_0.vmethod_10(this.class90_0.GStruct2_0.int_1, this.class90_1.GStruct2_0.int_1);
			return;
		}
		else
		{
			if (flag)
			{
				this.gclass99_0.vmethod_10(this.class90_0.GStruct2_0.int_1, this.class90_1.GStruct2_0.int_1);
				return;
			}
			this.gclass99_0.vmethod_10(this.class90_1.GStruct2_0.int_1, this.class90_1.GStruct2_0.int_1);
			return;
		}
	}

	// Token: 0x060009AE RID: 2478
	public abstract GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E();

	// Token: 0x040004C5 RID: 1221
	internal Class90 class90_0;

	// Token: 0x040004C6 RID: 1222
	internal Class90 class90_1;

	// Token: 0x040004C7 RID: 1223
	internal bool bool_0;
}
