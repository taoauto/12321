﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000215 RID: 533
internal class AlarmVaoPhai : UserControl
{
	// Token: 0x06001BDE RID: 7134 RVA: 0x000142D6 File Offset: 0x000124D6
	public AlarmVaoPhai(Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.InitializeComponent();
		this.lblName.Text = class159_1.Class432_0.String_2;
	}

	// Token: 0x06001BDF RID: 7135 RVA: 0x00014301 File Offset: 0x00012501
	private void AlarmVaoPhai_Load(object sender, EventArgs e)
	{
		this.chkCoBan.Checked = this.class159_0.List_0.Contains(Enum14.NhiemVuThangCap);
	}

	// Token: 0x06001BE0 RID: 7136 RVA: 0x000D31E0 File Offset: 0x000D13E0
	private void btnOk_Click(object sender, EventArgs e)
	{
		int num = this.cboMenpai.SelectedIndex + 1;
		if (num == 10)
		{
			num = 32;
		}
		if (num == 11)
		{
			num = 37;
		}
		if (num == 12)
		{
			num = Class381.int_11;
		}
		if (num == 13)
		{
			num = Class381.int_12;
		}
		if (num == 14)
		{
			num = 0;
		}
		if (num != 0)
		{
			this.class159_0.Boolean_94 = true;
			this.class159_0.Int32_56 = num;
		}
		base.Dispose();
	}

	// Token: 0x06001BE1 RID: 7137 RVA: 0x00014320 File Offset: 0x00012520
	private void lblAlarm_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.class159_0.method_223();
		}
	}

	// Token: 0x06001BE2 RID: 7138 RVA: 0x00014320 File Offset: 0x00012520
	private void lblName_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.class159_0.method_223();
		}
	}

	// Token: 0x06001BE3 RID: 7139 RVA: 0x000D324C File Offset: 0x000D144C
	private void lblClose_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			base.Parent.Controls.Remove(this);
			if (AlarmEx.AlarmEx_0.Controls.Count == 0 && AlarmEx.AlarmEx_0.Visible)
			{
				AlarmEx.AlarmEx_0.Hide();
			}
		}
	}

	// Token: 0x06001BE4 RID: 7140 RVA: 0x000D32A0 File Offset: 0x000D14A0
	private void chkCoBan_CheckedChanged(object sender, EventArgs e)
	{
		if (Class268.Int32_17 == 0)
		{
			MessageBox.Show(this, "Chức năng này cần kích hoạt VIP", "MicroAuto", MessageBoxButtons.OK);
			this.chkCoBan.Checked = false;
		}
		this.class159_0.method_48(Enum14.NhiemVuThangCap, this.chkCoBan.Checked);
		this.class159_0.method_389();
	}

	// Token: 0x06001BE5 RID: 7141 RVA: 0x00002E18 File Offset: 0x00001018
	private void lblName_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001BE6 RID: 7142 RVA: 0x00002E18 File Offset: 0x00001018
	private void cboMenpai_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001BE7 RID: 7143 RVA: 0x0001433A File Offset: 0x0001253A
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001BE8 RID: 7144 RVA: 0x000D32F8 File Offset: 0x000D14F8
	private void InitializeComponent()
	{
		this.lblName = new Label();
		this.lblAlarm = new Label();
		this.cboMenpai = new ComboBox();
		this.label1 = new Label();
		this.btnOk = new Button();
		this.lblClose = new Label();
		this.chkCoBan = new CheckBox();
		base.SuspendLayout();
		this.lblName.Dock = DockStyle.Top;
		this.lblName.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.lblName.ForeColor = Color.DarkGreen;
		this.lblName.Location = new Point(0, 0);
		this.lblName.Name = "lblName";
		this.lblName.Size = new Size(320, 23);
		this.lblName.TabIndex = 0;
		this.lblName.Text = "tieudattai";
		this.lblName.TextAlign = ContentAlignment.MiddleCenter;
		this.lblName.Click += this.lblName_Click;
		this.lblName.MouseClick += this.lblName_MouseClick;
		this.lblAlarm.Cursor = Cursors.Hand;
		this.lblAlarm.Dock = DockStyle.Top;
		this.lblAlarm.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.lblAlarm.ForeColor = Color.Red;
		this.lblAlarm.Location = new Point(0, 23);
		this.lblAlarm.Name = "lblAlarm";
		this.lblAlarm.Size = new Size(320, 48);
		this.lblAlarm.TabIndex = 1;
		this.lblAlarm.Text = "chưa vào phái\r\nbạn có muốn auto tự vào phái không\r\n( tự vào phái khi đủ cấp )";
		this.lblAlarm.TextAlign = ContentAlignment.MiddleCenter;
		this.lblAlarm.MouseClick += this.lblAlarm_MouseClick;
		this.cboMenpai.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboMenpai.FormattingEnabled = true;
		this.cboMenpai.Items.AddRange(new object[]
		{
			"Thiếu Lâm",
			"Minh Giáo",
			"Cái Bang",
			"Võ Đang (Đánh Xa)",
			"Nga My (Đánh Xa)",
			"Tinh Túc (Đánh Xa)",
			"Thiên Long (Đánh Xa)",
			"Thiên Sơn",
			"Tiêu Dao (Đánh Xa)",
			"Mộ Dung",
			"Đường Môn (Đánh Xa)",
			"Quỷ Cốc (Đánh Xa)",
			"Đào Hoa (Đánh Xa)",
			"Để Tôi Tự Vào"
		});
		this.cboMenpai.Location = new Point(59, 77);
		this.cboMenpai.Name = "cboMenpai";
		this.cboMenpai.Size = new Size(170, 21);
		this.cboMenpai.TabIndex = 2;
		this.cboMenpai.SelectedIndexChanged += this.cboMenpai_SelectedIndexChanged;
		this.label1.AutoSize = true;
		this.label1.Location = new Point(5, 81);
		this.label1.Name = "label1";
		this.label1.Size = new Size(50, 13);
		this.label1.TabIndex = 3;
		this.label1.Text = "Vào Phái";
		this.btnOk.Location = new Point(235, 76);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new Size(75, 23);
		this.btnOk.TabIndex = 4;
		this.btnOk.Text = "Đồng Ý";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += this.btnOk_Click;
		this.lblClose.BackColor = Color.Silver;
		this.lblClose.Cursor = Cursors.Hand;
		this.lblClose.Location = new Point(300, 0);
		this.lblClose.Name = "lblClose";
		this.lblClose.Size = new Size(20, 23);
		this.lblClose.TabIndex = 5;
		this.lblClose.Text = "X";
		this.lblClose.TextAlign = ContentAlignment.MiddleCenter;
		this.lblClose.MouseClick += this.lblClose_MouseClick;
		this.chkCoBan.AutoSize = true;
		this.chkCoBan.Location = new Point(8, 104);
		this.chkCoBan.Name = "chkCoBan";
		this.chkCoBan.Size = new Size(240, 17);
		this.chkCoBan.TabIndex = 6;
		this.chkCoBan.Text = "Làm nhiệm vụ cơ bản để lên cấp và lấy vàng";
		this.chkCoBan.UseVisualStyleBackColor = true;
		this.chkCoBan.CheckedChanged += this.chkCoBan_CheckedChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.White;
		base.Controls.Add(this.chkCoBan);
		base.Controls.Add(this.lblClose);
		base.Controls.Add(this.btnOk);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.cboMenpai);
		base.Controls.Add(this.lblAlarm);
		base.Controls.Add(this.lblName);
		base.Name = "AlarmVaoPhai";
		base.Size = new Size(320, 130);
		base.Load += this.AlarmVaoPhai_Load;
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04001196 RID: 4502
	private Class159 class159_0;

	// Token: 0x04001197 RID: 4503
	private IContainer icontainer_0;

	// Token: 0x04001198 RID: 4504
	private Label lblName;

	// Token: 0x04001199 RID: 4505
	private Label lblAlarm;

	// Token: 0x0400119A RID: 4506
	private ComboBox cboMenpai;

	// Token: 0x0400119B RID: 4507
	private Label label1;

	// Token: 0x0400119C RID: 4508
	private Button btnOk;

	// Token: 0x0400119D RID: 4509
	private Label lblClose;

	// Token: 0x0400119E RID: 4510
	private CheckBox chkCoBan;
}
