﻿using System;

// Token: 0x020000C5 RID: 197
public struct GStruct0
{
	// Token: 0x0600098C RID: 2444 RVA: 0x000093E7 File Offset: 0x000075E7
	public GStruct0(char char_1)
	{
		this.char_0 = char_1;
		this.styleIndex_0 = StyleIndex.None;
	}

	// Token: 0x040004B6 RID: 1206
	public char char_0;

	// Token: 0x040004B7 RID: 1207
	public StyleIndex styleIndex_0;
}
