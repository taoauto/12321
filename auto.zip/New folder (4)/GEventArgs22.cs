﻿using System;

// Token: 0x0200020F RID: 527
public class GEventArgs22 : EventArgs
{
	// Token: 0x06001B3C RID: 6972 RVA: 0x00013B26 File Offset: 0x00011D26
	public GEventArgs22(GClass122 gclass122_1)
	{
		this.gclass122_0 = gclass122_1;
	}

	// Token: 0x0400114F RID: 4431
	public readonly GClass122 gclass122_0;
}
