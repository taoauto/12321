﻿using System;

// Token: 0x0200029F RID: 671
internal class Class359
{
	// Token: 0x17000795 RID: 1941
	// (get) Token: 0x060024AE RID: 9390 RVA: 0x0001BCC2 File Offset: 0x00019EC2
	public static string String_0
	{
		get
		{
			return "Thúc Hà Cổ Trấn";
		}
	}

	// Token: 0x04001890 RID: 6288
	public static int int_0 = 260;

	// Token: 0x04001891 RID: 6289
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 55U,
		Int32_0 = 150,
		Int32_1 = 152,
		Int32_2 = Class359.int_0,
		String_2 = "Lý Dã"
	};

	// Token: 0x04001892 RID: 6290
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 10U,
		Int32_0 = 200,
		Int32_1 = 253,
		Int32_2 = Class359.int_0,
		String_2 = "Hầu bàn Lưu"
	};

	// Token: 0x04001893 RID: 6291
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 10U,
		Int32_0 = 200,
		Int32_1 = 253,
		Int32_2 = Class359.int_0,
		String_2 = "Lưu tiểu nhị"
	};
}
