﻿using System;

// Token: 0x020002B3 RID: 691
internal class Class377
{
	// Token: 0x1700084B RID: 2123
	// (get) Token: 0x0600267A RID: 9850 RVA: 0x0001CB66 File Offset: 0x0001AD66
	public static string String_0
	{
		get
		{
			return "Võ Đang Sơn";
		}
	}

	// Token: 0x040019E2 RID: 6626
	public static int int_0 = 12;

	// Token: 0x040019E3 RID: 6627
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 12U,
		Int32_0 = 101,
		Int32_1 = 115,
		Int32_2 = Class377.int_0,
		String_2 = "Trương Quân Mộ"
	};

	// Token: 0x040019E4 RID: 6628
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 78,
		Int32_1 = 86,
		Int32_2 = Class377.int_0,
		String_2 = "Trương Huyền Tố"
	};

	// Token: 0x040019E5 RID: 6629
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 78,
		Int32_1 = 95,
		Int32_2 = Class377.int_0,
		String_2 = "Trương Trung Hành"
	};

	// Token: 0x040019E6 RID: 6630
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 83,
		Int32_1 = 85,
		Int32_2 = Class377.int_0,
		String_2 = "Du Viễn Sơn"
	};
}
