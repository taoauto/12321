﻿using System;

// Token: 0x0200004D RID: 77
internal enum Enum2 : byte
{
	// Token: 0x040001D2 RID: 466
	Off,
	// Token: 0x040001D3 RID: 467
	On
}
