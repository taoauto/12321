﻿using System;
using System.IO;

// Token: 0x02000021 RID: 33
public abstract class GClass9
{
	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x060001C6 RID: 454 RVA: 0x000042BA File Offset: 0x000024BA
	// (set) Token: 0x060001C7 RID: 455 RVA: 0x000042C2 File Offset: 0x000024C2
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = (value ?? string.Empty);
		}
	}

	// Token: 0x060001C8 RID: 456
	public abstract long \u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E();

	// Token: 0x060001C9 RID: 457
	public abstract void \u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(Stream stream_0);

	// Token: 0x060001CA RID: 458 RVA: 0x000042D4 File Offset: 0x000024D4
	public void method_0()
	{
		this.GClass9.\u206D\u206A\u200B\u202A\u202C\u202B\u206A\u202E\u200E\u202C\u206B\u202D\u206D\u206C\u206B\u200B\u200E\u200E\u206D\u206B\u206C\u206F\u200F\u200E\u206C\u202C\u206C\u206A\u200B\u200D\u206A\u200F\u200C\u200C\u202C\u202E\u206C\u200D\u202A\u200D\u202E(true);
	}

	// Token: 0x060001CB RID: 459 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void \u206D\u206A\u200B\u202A\u202C\u202B\u206A\u202E\u200E\u202C\u206B\u202D\u206D\u206C\u206B\u200B\u200E\u200E\u206D\u206B\u206C\u206F\u200F\u200E\u206C\u202C\u206C\u206A\u200B\u200D\u206A\u200F\u200C\u200C\u202C\u202E\u206C\u200D\u202A\u200D\u202E(bool bool_0)
	{
	}

	// Token: 0x04000111 RID: 273
	protected string string_0 = string.Empty;
}
