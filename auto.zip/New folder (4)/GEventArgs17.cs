﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000F3 RID: 243
public class GEventArgs17 : EventArgs
{
	// Token: 0x17000364 RID: 868
	// (get) Token: 0x06000CBB RID: 3259 RVA: 0x0000B2C8 File Offset: 0x000094C8
	// (set) Token: 0x06000CBC RID: 3260 RVA: 0x0000B2D0 File Offset: 0x000094D0
	public FCTBAction FCTBAction_0 { get; private set; }

	// Token: 0x06000CBD RID: 3261 RVA: 0x0000B2D9 File Offset: 0x000094D9
	public GEventArgs17(FCTBAction fctbaction_1)
	{
		this.FCTBAction_0 = fctbaction_1;
	}

	// Token: 0x040005E7 RID: 1511
	[CompilerGenerated]
	private FCTBAction fctbaction_0;
}
