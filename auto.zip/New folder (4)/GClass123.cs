﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x02000217 RID: 535
public class GClass123
{
	// Token: 0x170006A9 RID: 1705
	// (get) Token: 0x06001BE9 RID: 7145 RVA: 0x00014359 File Offset: 0x00012559
	// (set) Token: 0x06001BEA RID: 7146 RVA: 0x00014361 File Offset: 0x00012561
	public bool Boolean_0 { get; set; }

	// Token: 0x06001BEB RID: 7147 RVA: 0x0001436A File Offset: 0x0001256A
	public GClass123(uint uint_1)
	{
		this.uint_0 = uint_1;
	}

	// Token: 0x06001BEC RID: 7148
	[DllImport("kernel32.dll")]
	protected static extern bool ReadProcessMemory(IntPtr intptr_0, IntPtr intptr_1, byte[] byte_0, uint uint_1, int int_0);

	// Token: 0x06001BED RID: 7149
	[DllImport("kernel32.dll")]
	protected static extern int VirtualQueryEx(IntPtr intptr_0, IntPtr intptr_1, out GStruct20 gstruct20_0, int int_0);

	// Token: 0x06001BEE RID: 7150 RVA: 0x000D38BC File Offset: 0x000D1ABC
	public static List<GStruct20> smethod_0(int int_0)
	{
		IntPtr handle = Process.GetProcessById(int_0).Handle;
		List<GStruct20> list = new List<GStruct20>();
		IntPtr intptr_ = 0;
		for (;;)
		{
			GStruct20 gstruct = default(GStruct20);
			if (GClass123.VirtualQueryEx(handle, intptr_, out gstruct, Marshal.SizeOf(gstruct)) == 0)
			{
				break;
			}
			if ((gstruct.uint_2 & 4096U) != 0U && (gstruct.uint_3 & 256U) == 0U)
			{
				list.Add(gstruct);
			}
			intptr_ = new IntPtr(gstruct.intptr_0.ToInt32() + (int)gstruct.uint_1);
		}
		return list;
	}

	// Token: 0x170006AA RID: 1706
	// (get) Token: 0x06001BEF RID: 7151 RVA: 0x00014379 File Offset: 0x00012579
	// (set) Token: 0x06001BF0 RID: 7152 RVA: 0x00014381 File Offset: 0x00012581
	protected List<GStruct20> List_0 { get; set; }

	// Token: 0x06001BF1 RID: 7153 RVA: 0x000D3944 File Offset: 0x000D1B44
	protected void method_0(IntPtr intptr_0)
	{
		IntPtr intptr_ = 0;
		for (;;)
		{
			GStruct20 gstruct = default(GStruct20);
			if (GClass123.VirtualQueryEx(intptr_0, intptr_, out gstruct, Marshal.SizeOf(gstruct)) == 0)
			{
				break;
			}
			if ((gstruct.uint_2 & 4096U) != 0U && (gstruct.uint_3 & 256U) == 0U)
			{
				this.List_0.Add(gstruct);
			}
			intptr_ = new IntPtr(gstruct.intptr_0.ToInt32() + (int)gstruct.uint_1);
		}
	}

	// Token: 0x06001BF2 RID: 7154 RVA: 0x000D39BC File Offset: 0x000D1BBC
	public static bool smethod_1(byte[] byte_0, byte[] byte_1, int int_0)
	{
		for (int i = 0; i < byte_1.Length; i++)
		{
			if (byte_1[i] != 255)
			{
				if (byte_1[i] == 1)
				{
					if (byte_0[int_0 + i] == 0)
					{
						return false;
					}
				}
				else if (byte_0[int_0 + i] != byte_1[i])
				{
					return false;
				}
			}
		}
		return true;
	}

	// Token: 0x06001BF3 RID: 7155 RVA: 0x000D3A04 File Offset: 0x000D1C04
	protected IntPtr method_1(byte[] byte_0, byte[] byte_1)
	{
		for (int i = 0; i < byte_0.Length - byte_1.Length; i++)
		{
			if (GClass123.smethod_1(byte_0, byte_1, i))
			{
				return (IntPtr)i;
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BF4 RID: 7156 RVA: 0x000D3A3C File Offset: 0x000D1C3C
	protected List<int> method_2(byte[] byte_0, byte[] byte_1)
	{
		List<int> list = new List<int>();
		for (int i = 0; i < byte_0.Length - byte_1.Length; i++)
		{
			if (GClass123.smethod_1(byte_0, byte_1, i))
			{
				list.Add(i);
			}
		}
		return list;
	}

	// Token: 0x06001BF5 RID: 7157 RVA: 0x000D3A74 File Offset: 0x000D1C74
	public IntPtr method_3(byte[] byte_0, uint uint_1, uint uint_2)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if ((int)this.List_0[i].intptr_0 >= (int)uint_1 && (int)this.List_0[i].intptr_0 <= (int)uint_2)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				IntPtr value = this.method_1(byte_, byte_0);
				if (value != IntPtr.Zero)
				{
					return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BF6 RID: 7158 RVA: 0x000D3B8C File Offset: 0x000D1D8C
	public IntPtr method_4(byte[] byte_0, uint uint_1, uint uint_2)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if ((int)this.List_0[i].intptr_0 >= (int)uint_1 && (int)this.List_0[i].intptr_0 <= (int)uint_2 && this.List_0[i].uint_4 == 131072U)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				IntPtr value = this.method_1(byte_, byte_0);
				if (value != IntPtr.Zero)
				{
					return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BF7 RID: 7159 RVA: 0x000D3CC0 File Offset: 0x000D1EC0
	public IntPtr method_5(byte[] byte_0, uint uint_1, uint uint_2, int int_0, int int_1 = 0)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if ((int)this.List_0[i].intptr_0 >= (int)uint_1 && (int)this.List_0[i].intptr_0 <= (int)uint_2 && this.List_0[i].uint_4 == 131072U && (int_0 <= (int)this.List_0[i].intptr_0 || int_0 >= (int)this.List_0[i].intptr_0 + (int)this.List_0[i].uint_1) && (int_1 == 0 || int_1 <= (int)this.List_0[i].intptr_0 || int_1 >= (int)this.List_0[i].intptr_0 + (int)this.List_0[i].uint_1))
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				IntPtr value = this.method_1(byte_, byte_0);
				if (value != IntPtr.Zero)
				{
					return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BF8 RID: 7160 RVA: 0x000D3E8C File Offset: 0x000D208C
	public IntPtr method_6(byte[] byte_0, uint uint_1)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if (((int)this.List_0[i].intptr_0 <= (int)uint_1 || (int)this.List_0[i].intptr_0 >= (int)uint_1) && this.List_0[i].uint_4 == 131072U)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				IntPtr value = this.method_1(byte_, byte_0);
				if (value != IntPtr.Zero)
				{
					return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BF9 RID: 7161 RVA: 0x000D3FBC File Offset: 0x000D21BC
	public List<int> method_7(byte[] byte_0)
	{
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return list;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if (this.List_0[i].uint_4 == 131072U)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				list = this.method_2(byte_, byte_0);
				if (list.Count > 0)
				{
					for (int j = 0; j < list.Count; j++)
					{
						list[j] = (int)this.List_0[i].intptr_0 + list[j];
					}
					for (int k = 0; k < list.Count; k++)
					{
						list2.Add(list[k]);
					}
					if (list2.Count >= 4)
					{
						return list2;
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06001BFA RID: 7162 RVA: 0x000D4100 File Offset: 0x000D2300
	public List<int> method_8(byte[] byte_0, uint uint_1, uint uint_2)
	{
		List<int> list = new List<int>();
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return list;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if ((int)this.List_0[i].intptr_0 >= (int)uint_1 && (int)this.List_0[i].intptr_0 <= (int)uint_2 && this.List_0[i].uint_4 == 131072U)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				list = this.method_2(byte_, byte_0);
				if (list.Count > 0)
				{
					for (int j = 0; j < list.Count; j++)
					{
						list[j] = (int)this.List_0[i].intptr_0 + list[j];
					}
					return list;
				}
			}
		}
		return list;
	}

	// Token: 0x06001BFB RID: 7163 RVA: 0x000D4244 File Offset: 0x000D2444
	public IntPtr method_9(byte[] byte_0, int int_0)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if ((int)this.List_0[i].intptr_0 >= int_0)
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
				IntPtr value = this.method_1(byte_, byte_0);
				if (value != IntPtr.Zero)
				{
					return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BFC RID: 7164 RVA: 0x000D4340 File Offset: 0x000D2540
	public IntPtr method_10(byte[] byte_0)
	{
		Process processById = Process.GetProcessById((int)this.uint_0);
		if (processById.Id == 0)
		{
			return IntPtr.Zero;
		}
		this.List_0 = new List<GStruct20>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			byte[] byte_ = new byte[this.List_0[i].uint_1];
			GClass123.ReadProcessMemory(processById.Handle, this.List_0[i].intptr_0, byte_, this.List_0[i].uint_1, 0);
			IntPtr value = this.method_1(byte_, byte_0);
			if (value != IntPtr.Zero)
			{
				return new IntPtr(this.List_0[i].intptr_0.ToInt32() + value.ToInt32());
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001BFD RID: 7165 RVA: 0x0001438A File Offset: 0x0001258A
	public static string smethod_2(uint uint_1)
	{
		if (uint_1 == 256U)
		{
			return "MEM_COMMIT";
		}
		if (uint_1 == 65536U)
		{
			return "MEM_FREE";
		}
		if (uint_1 == 8192U)
		{
			return "MEM_RESERVE";
		}
		return "UNKNOWN";
	}

	// Token: 0x06001BFE RID: 7166 RVA: 0x000143BB File Offset: 0x000125BB
	public static string smethod_3(uint uint_1)
	{
		if (uint_1 == 16777216U)
		{
			return "MEM_IMAGE";
		}
		if (uint_1 == 262144U)
		{
			return "MEM_MAPPED";
		}
		if (uint_1 == 131072U)
		{
			return "MEM_PRIVATE";
		}
		return "UNKNOWN";
	}

	// Token: 0x040011A6 RID: 4518
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040011A7 RID: 4519
	protected uint uint_0;

	// Token: 0x040011A8 RID: 4520
	[CompilerGenerated]
	private List<GStruct20> list_0;
}
