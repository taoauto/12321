﻿using System;

// Token: 0x02000294 RID: 660
internal class Class348
{
	// Token: 0x1700078A RID: 1930
	// (get) Token: 0x0600248C RID: 9356 RVA: 0x0001BC75 File Offset: 0x00019E75
	public static string String_0
	{
		get
		{
			return "Bích Duẩn Xuân Lâm";
		}
	}

	// Token: 0x04001830 RID: 6192
	public static int int_0 = 769;

	// Token: 0x04001831 RID: 6193
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 100,
		Int32_1 = 143,
		Int32_2 = Class348.int_0,
		String_2 = "Giả Minh Đạt"
	};

	// Token: 0x04001832 RID: 6194
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 379,
		Int32_1 = 210,
		Int32_2 = Class348.int_0,
		String_2 = "Loan Anh Bác"
	};
}
