﻿using System;
using System.Collections.Specialized;
using System.Text;

// Token: 0x020000A5 RID: 165
internal sealed class Class79 : NameValueCollection
{
	// Token: 0x060007B0 RID: 1968 RVA: 0x00008196 File Offset: 0x00006396
	public Class79()
	{
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x0000819E File Offset: 0x0000639E
	public Class79(int int_0) : base(int_0)
	{
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x000081A7 File Offset: 0x000063A7
	private static string smethod_0(string string_0, Encoding encoding_0)
	{
		if (string_0.IndexOfAny(new char[]
		{
			'%',
			'+'
		}) <= -1)
		{
			return string_0;
		}
		return Class78.smethod_27(string_0, encoding_0);
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x000081CB File Offset: 0x000063CB
	public static Class79 smethod_1(string string_0)
	{
		return Class79.smethod_2(string_0, Encoding.UTF8);
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x0003AA70 File Offset: 0x00038C70
	public static Class79 smethod_2(string string_0, Encoding encoding_0)
	{
		if (string_0 == null)
		{
			return new Class79(1);
		}
		if (string_0.Length == 0)
		{
			return new Class79(1);
		}
		if (string_0 == "?")
		{
			return new Class79(1);
		}
		if (string_0[0] == '?')
		{
			string_0 = string_0.Substring(1);
		}
		if (encoding_0 == null)
		{
			encoding_0 = Encoding.UTF8;
		}
		Class79 @class = new Class79();
		foreach (string text in string_0.Split(new char[]
		{
			'&'
		}))
		{
			int length = text.Length;
			if (length != 0 && !(text == "="))
			{
				int num = text.IndexOf('=');
				if (num < 0)
				{
					@class.Add(null, Class79.smethod_0(text, encoding_0));
				}
				else if (num == 0)
				{
					@class.Add(null, Class79.smethod_0(text.Substring(1), encoding_0));
				}
				else
				{
					string name = Class79.smethod_0(text.Substring(0, num), encoding_0);
					int num2 = num + 1;
					string value = (num2 < length) ? Class79.smethod_0(text.Substring(num2), encoding_0) : string.Empty;
					@class.Add(name, value);
				}
			}
		}
		return @class;
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x0003AB94 File Offset: 0x00038D94
	public string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string text in this.AllKeys)
		{
			stringBuilder.AppendFormat("{0}={1}&", text, base[text]);
		}
		if (stringBuilder.Length > 0)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			int i = stringBuilder2.Length;
			stringBuilder2.Length = i - 1;
		}
		return stringBuilder.ToString();
	}
}
