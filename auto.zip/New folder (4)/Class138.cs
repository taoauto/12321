﻿using System;

// Token: 0x02000157 RID: 343
internal class Class138 : Interface7
{
	// Token: 0x1700042A RID: 1066
	// (get) Token: 0x0600104C RID: 4172 RVA: 0x0000D4CD File Offset: 0x0000B6CD
	// (set) Token: 0x0600104D RID: 4173 RVA: 0x0000D4D4 File Offset: 0x0000B6D4
	public string String_0
	{
		get
		{
			return Class144.string_1;
		}
		set
		{
			Class144.string_1 = value;
		}
	}

	// Token: 0x1700042B RID: 1067
	// (get) Token: 0x0600104E RID: 4174 RVA: 0x0000D4DC File Offset: 0x0000B6DC
	// (set) Token: 0x0600104F RID: 4175 RVA: 0x0000D4E3 File Offset: 0x0000B6E3
	public string String_1
	{
		get
		{
			return Class144.string_2;
		}
		set
		{
			Class144.string_2 = value;
		}
	}

	// Token: 0x1700042C RID: 1068
	// (get) Token: 0x06001050 RID: 4176 RVA: 0x0000D4EB File Offset: 0x0000B6EB
	// (set) Token: 0x06001051 RID: 4177 RVA: 0x0000D4F2 File Offset: 0x0000B6F2
	public string String_2
	{
		get
		{
			return Class144.string_3;
		}
		set
		{
			Class144.string_3 = value;
		}
	}

	// Token: 0x1700042D RID: 1069
	// (get) Token: 0x06001052 RID: 4178 RVA: 0x0000D4FA File Offset: 0x0000B6FA
	// (set) Token: 0x06001053 RID: 4179 RVA: 0x0000D501 File Offset: 0x0000B701
	public string String_3
	{
		get
		{
			return Class144.string_4;
		}
		set
		{
			Class144.string_4 = value;
		}
	}

	// Token: 0x1700042E RID: 1070
	// (get) Token: 0x06001054 RID: 4180 RVA: 0x0000D509 File Offset: 0x0000B709
	// (set) Token: 0x06001055 RID: 4181 RVA: 0x0000D510 File Offset: 0x0000B710
	public bool Boolean_0
	{
		get
		{
			return Class144.bool_0;
		}
		set
		{
			Class144.bool_0 = value;
		}
	}

	// Token: 0x1700042F RID: 1071
	// (get) Token: 0x06001056 RID: 4182 RVA: 0x0000D518 File Offset: 0x0000B718
	// (set) Token: 0x06001057 RID: 4183 RVA: 0x0000D51F File Offset: 0x0000B71F
	public bool Boolean_1
	{
		get
		{
			return Class144.bool_1;
		}
		set
		{
			Class144.bool_1 = value;
		}
	}

	// Token: 0x17000430 RID: 1072
	// (get) Token: 0x06001058 RID: 4184 RVA: 0x0000D527 File Offset: 0x0000B727
	// (set) Token: 0x06001059 RID: 4185 RVA: 0x0000D52E File Offset: 0x0000B72E
	public int Int32_0
	{
		get
		{
			return Class144.int_5;
		}
		set
		{
			Class144.int_5 = value;
		}
	}
}
