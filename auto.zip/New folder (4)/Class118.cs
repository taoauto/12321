﻿using System;
using System.ComponentModel;

// Token: 0x02000131 RID: 305
internal class Class118 : TypeDescriptionProvider
{
	// Token: 0x06000F7C RID: 3964 RVA: 0x0000CDB3 File Offset: 0x0000AFB3
	public Class118(Type type_0) : base(Class118.smethod_0(type_0))
	{
	}

	// Token: 0x06000F7D RID: 3965 RVA: 0x0000CDC1 File Offset: 0x0000AFC1
	private static TypeDescriptionProvider smethod_0(Type type_0)
	{
		return TypeDescriptor.GetProvider(type_0);
	}

	// Token: 0x06000F7E RID: 3966 RVA: 0x0000CDC9 File Offset: 0x0000AFC9
	public virtual ICustomTypeDescriptor GetTypeDescriptor(Type objectType, object instance)
	{
		return new Class119(base.GetTypeDescriptor(objectType, instance), instance);
	}
}
