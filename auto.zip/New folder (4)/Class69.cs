﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;

// Token: 0x0200008A RID: 138
internal sealed class Class69
{
	// Token: 0x0600065D RID: 1629 RVA: 0x00002E70 File Offset: 0x00001070
	private Class69()
	{
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x00035D5C File Offset: 0x00033F5C
	private static void smethod_0(string string_0, GClass37 gclass37_0)
	{
		Class74 @class = new Class74(string_0, gclass37_0);
		IPAddress ipaddress = Class69.smethod_1(@class.String_0);
		if (ipaddress == null)
		{
			string string_ = "The URI prefix includes an invalid host.";
			throw new GException5(87, string_);
		}
		if (!ipaddress.smethod_87())
		{
			string string_2 = "The URI prefix includes an invalid host.";
			throw new GException5(87, string_2);
		}
		int num;
		if (!int.TryParse(@class.String_3, out num))
		{
			string string_3 = "The URI prefix includes an invalid port.";
			throw new GException5(87, string_3);
		}
		if (!num.smethod_46())
		{
			string string_4 = "The URI prefix includes an invalid port.";
			throw new GException5(87, string_4);
		}
		string string_5 = @class.String_2;
		if (string_5.IndexOf('%') != -1)
		{
			string string_6 = "The URI prefix includes an invalid path.";
			throw new GException5(87, string_6);
		}
		if (string_5.IndexOf("//", StringComparison.Ordinal) != -1)
		{
			string string_7 = "The URI prefix includes an invalid path.";
			throw new GException5(87, string_7);
		}
		IPEndPoint ipendPoint = new IPEndPoint(ipaddress, num);
		Class68 class2;
		if (Class69.dictionary_0.TryGetValue(ipendPoint, out class2))
		{
			if (class2.Boolean_0 ^ @class.Boolean_0)
			{
				string string_8 = "The URI prefix includes an invalid scheme.";
				throw new GException5(87, string_8);
			}
		}
		else
		{
			class2 = new Class68(ipendPoint, @class.Boolean_0, gclass37_0.String_0, gclass37_0.GClass44_0, gclass37_0.Boolean_1);
			Class69.dictionary_0.Add(ipendPoint, class2);
		}
		class2.method_3(@class);
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x00007153 File Offset: 0x00005353
	private static IPAddress smethod_1(string string_0)
	{
		if (string_0 == "*")
		{
			return IPAddress.Any;
		}
		if (string_0 == "+")
		{
			return IPAddress.Any;
		}
		return string_0.smethod_63();
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x00035E8C File Offset: 0x0003408C
	private static void smethod_2(string string_0, GClass37 gclass37_0)
	{
		Class74 @class = new Class74(string_0, gclass37_0);
		IPAddress ipaddress = Class69.smethod_1(@class.String_0);
		if (ipaddress == null)
		{
			return;
		}
		if (!ipaddress.smethod_87())
		{
			return;
		}
		int num;
		if (!int.TryParse(@class.String_3, out num))
		{
			return;
		}
		if (!num.smethod_46())
		{
			return;
		}
		string string_ = @class.String_2;
		if (string_.IndexOf('%') != -1)
		{
			return;
		}
		if (string_.IndexOf("//", StringComparison.Ordinal) != -1)
		{
			return;
		}
		IPEndPoint key = new IPEndPoint(ipaddress, num);
		Class68 class2;
		if (!Class69.dictionary_0.TryGetValue(key, out class2))
		{
			return;
		}
		if (class2.Boolean_0 ^ @class.Boolean_0)
		{
			return;
		}
		class2.method_5(@class);
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x00035F2C File Offset: 0x0003412C
	internal static bool smethod_3(IPEndPoint ipendPoint_0)
	{
		object syncRoot = ((ICollection)Class69.dictionary_0).SyncRoot;
		bool result;
		lock (syncRoot)
		{
			Class68 @class;
			if (!Class69.dictionary_0.TryGetValue(ipendPoint_0, out @class))
			{
				result = false;
			}
			else
			{
				Class69.dictionary_0.Remove(ipendPoint_0);
				@class.method_4();
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x00035F94 File Offset: 0x00034194
	public static void smethod_4(GClass37 gclass37_0)
	{
		List<string> list = new List<string>();
		object syncRoot = ((ICollection)Class69.dictionary_0).SyncRoot;
		lock (syncRoot)
		{
			try
			{
				foreach (string text in gclass37_0.GClass39_0)
				{
					Class69.smethod_0(text, gclass37_0);
					list.Add(text);
				}
			}
			catch
			{
				foreach (string string_ in list)
				{
					Class69.smethod_2(string_, gclass37_0);
				}
				throw;
			}
		}
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x0003606C File Offset: 0x0003426C
	public static void smethod_5(string string_0, GClass37 gclass37_0)
	{
		object syncRoot = ((ICollection)Class69.dictionary_0).SyncRoot;
		lock (syncRoot)
		{
			Class69.smethod_0(string_0, gclass37_0);
		}
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x000360B4 File Offset: 0x000342B4
	public static void smethod_6(GClass37 gclass37_0)
	{
		object syncRoot = ((ICollection)Class69.dictionary_0).SyncRoot;
		lock (syncRoot)
		{
			foreach (string string_ in gclass37_0.GClass39_0)
			{
				Class69.smethod_2(string_, gclass37_0);
			}
		}
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x0003612C File Offset: 0x0003432C
	public static void smethod_7(string string_0, GClass37 gclass37_0)
	{
		object syncRoot = ((ICollection)Class69.dictionary_0).SyncRoot;
		lock (syncRoot)
		{
			Class69.smethod_2(string_0, gclass37_0);
		}
	}

	// Token: 0x04000311 RID: 785
	private static readonly Dictionary<IPEndPoint, Class68> dictionary_0 = new Dictionary<IPEndPoint, Class68>();
}
