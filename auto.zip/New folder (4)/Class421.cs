﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020002FF RID: 767
internal class Class421
{
	// Token: 0x06002BEE RID: 11246 RVA: 0x000201DC File Offset: 0x0001E3DC
	public Class421(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x170009EF RID: 2543
	// (get) Token: 0x06002BEF RID: 11247 RVA: 0x000201EB File Offset: 0x0001E3EB
	// (set) Token: 0x06002BF0 RID: 11248 RVA: 0x000201F3 File Offset: 0x0001E3F3
	public string String_0 { get; set; }

	// Token: 0x170009F0 RID: 2544
	// (get) Token: 0x06002BF1 RID: 11249 RVA: 0x000201FC File Offset: 0x0001E3FC
	// (set) Token: 0x06002BF2 RID: 11250 RVA: 0x00020204 File Offset: 0x0001E404
	public bool Boolean_0 { get; set; }

	// Token: 0x170009F1 RID: 2545
	// (get) Token: 0x06002BF3 RID: 11251 RVA: 0x0002020D File Offset: 0x0001E40D
	// (set) Token: 0x06002BF4 RID: 11252 RVA: 0x00020215 File Offset: 0x0001E415
	public int Int32_0 { get; set; }

	// Token: 0x170009F2 RID: 2546
	// (get) Token: 0x06002BF5 RID: 11253 RVA: 0x0002021E File Offset: 0x0001E41E
	public bool Boolean_1
	{
		get
		{
			return this.Int32_0 == 512 || this.Int32_0 == 513;
		}
	}

	// Token: 0x170009F3 RID: 2547
	// (get) Token: 0x06002BF6 RID: 11254 RVA: 0x0002023C File Offset: 0x0001E43C
	public string String_1
	{
		get
		{
			return Class426.smethod_57(this.String_0);
		}
	}

	// Token: 0x06002BF7 RID: 11255 RVA: 0x00127494 File Offset: 0x00125694
	public void method_0()
	{
		foreach (Class422 @class in Class422.smethod_0(this.class159_0))
		{
			if ((ulong)@class.uint_2 == (ulong)((long)this.int_1))
			{
				@class.method_0(256);
				break;
			}
		}
	}

	// Token: 0x170009F4 RID: 2548
	// (get) Token: 0x06002BF8 RID: 11256 RVA: 0x00020249 File Offset: 0x0001E449
	// (set) Token: 0x06002BF9 RID: 11257 RVA: 0x00020251 File Offset: 0x0001E451
	public uint UInt32_0 { get; set; }

	// Token: 0x170009F5 RID: 2549
	// (get) Token: 0x06002BFA RID: 11258 RVA: 0x0002025A File Offset: 0x0001E45A
	public uint UInt32_1
	{
		get
		{
			return this.class159_0.Class405_0.method_14(this.UInt32_0 + 54U);
		}
	}

	// Token: 0x170009F6 RID: 2550
	// (get) Token: 0x06002BFB RID: 11259 RVA: 0x00020275 File Offset: 0x0001E475
	public uint UInt32_2
	{
		get
		{
			return this.class159_0.Class405_0.method_14(this.UInt32_0 + 58U);
		}
	}

	// Token: 0x170009F7 RID: 2551
	// (get) Token: 0x06002BFC RID: 11260 RVA: 0x00020290 File Offset: 0x0001E490
	public uint UInt32_3
	{
		get
		{
			return this.class159_0.Class405_0.method_14(this.UInt32_0 + 62U);
		}
	}

	// Token: 0x170009F8 RID: 2552
	// (get) Token: 0x06002BFD RID: 11261 RVA: 0x000202AB File Offset: 0x0001E4AB
	// (set) Token: 0x06002BFE RID: 11262 RVA: 0x000202C6 File Offset: 0x0001E4C6
	public int Int32_1
	{
		get
		{
			return (int)this.class159_0.Class405_0.method_11(this.UInt32_0 + 13U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U, 1);
		}
	}

	// Token: 0x170009F9 RID: 2553
	// (get) Token: 0x06002BFF RID: 11263 RVA: 0x000202E2 File Offset: 0x0001E4E2
	// (set) Token: 0x06002C00 RID: 11264 RVA: 0x000202C6 File Offset: 0x0001E4C6
	public int Int32_2
	{
		get
		{
			return (int)(this.UInt32_0 + 13U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U, 1);
		}
	}

	// Token: 0x170009FA RID: 2554
	// (get) Token: 0x06002C01 RID: 11265 RVA: 0x000202ED File Offset: 0x0001E4ED
	// (set) Token: 0x06002C02 RID: 11266 RVA: 0x0002030A File Offset: 0x0001E50A
	public int Int32_3
	{
		get
		{
			return (int)this.class159_0.Class405_0.method_11(this.UInt32_0 + 13U + 4U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U + 4U, 1);
		}
	}

	// Token: 0x170009FB RID: 2555
	// (get) Token: 0x06002C03 RID: 11267 RVA: 0x00020328 File Offset: 0x0001E528
	// (set) Token: 0x06002C04 RID: 11268 RVA: 0x00020345 File Offset: 0x0001E545
	public int Int32_4
	{
		get
		{
			return (int)this.class159_0.Class405_0.method_11(this.UInt32_0 + 13U + 8U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U + 8U, 1);
		}
	}

	// Token: 0x170009FC RID: 2556
	// (get) Token: 0x06002C05 RID: 11269 RVA: 0x00020363 File Offset: 0x0001E563
	// (set) Token: 0x06002C06 RID: 11270 RVA: 0x00020345 File Offset: 0x0001E545
	public int Int32_5
	{
		get
		{
			return (int)this.class159_0.Class405_0.method_11(this.UInt32_0 + 13U + 12U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U + 8U, 1);
		}
	}

	// Token: 0x170009FD RID: 2557
	// (get) Token: 0x06002C07 RID: 11271 RVA: 0x00020381 File Offset: 0x0001E581
	// (set) Token: 0x06002C08 RID: 11272 RVA: 0x00020345 File Offset: 0x0001E545
	public int Int32_6
	{
		get
		{
			return (int)this.class159_0.Class405_0.method_11(this.UInt32_0 + 13U + 16U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.UInt32_0 + 13U + 8U, 1);
		}
	}

	// Token: 0x06002C09 RID: 11273 RVA: 0x00127508 File Offset: 0x00125708
	public static bool smethod_0(Class159 class159_1, string string_3)
	{
		class159_1.Class368_0.method_17();
		foreach (uint num in Class421.smethod_3(class159_1.Class392_0.UInt32_107, class159_1))
		{
			if (new Class421(class159_1)
			{
				String_0 = class159_1.Class405_0.method_32(num + 224U, false)
			}.String_0.Contains(string_3))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06002C0A RID: 11274 RVA: 0x001275A0 File Offset: 0x001257A0
	public static List<Class421> smethod_1(Class159 class159_1)
	{
		List<uint> list = Class421.smethod_3(class159_1.Class392_0.UInt32_107, class159_1);
		List<Class421> list2 = new List<Class421>();
		List<Class422> list3 = Class422.smethod_0(class159_1);
		foreach (uint num in list)
		{
			Class421 @class = new Class421(class159_1);
			@class.int_0 = (int)num;
			@class.String_0 = class159_1.Class405_0.method_32(num + 192U, false).Trim();
			if (@class.String_0 == "Quả Ngân Võ Lâm Ấn Kiếm Tiền")
			{
				@class.String_0 = "Quả Ngân Võ Lâm Ấn Bang HộiBuôn Bán";
			}
			if (@class.String_0 == "#{CJG_101231_121}")
			{
				@class.String_0 = "Cái Bang Nghi Vấn Ban Đầu";
			}
			if (Class363.dictionary_3.ContainsKey(@class.String_0))
			{
				@class.String_0 = Class363.dictionary_3[@class.String_0];
			}
			if (!(@class.String_0 == ""))
			{
				@class.int_2 = (int)class159_1.Class405_0.method_11(num + 24U);
				@class.int_1 = (int)class159_1.Class405_0.method_11(num + 16U);
				@class.int_3 = (int)class159_1.Class405_0.method_11(num + 48U);
				@class.int_4 = (int)class159_1.Class405_0.method_11(num + 52U);
				@class.string_2 = class159_1.Class405_0.method_32(num + 60U, false);
				@class.string_1 = class159_1.Class405_0.method_32(num + 200U, false);
				if (@class.int_1 > 0)
				{
					list2.Add(@class);
					foreach (Class422 class2 in list3)
					{
						if ((ulong)class2.uint_2 == (ulong)((long)@class.int_1))
						{
							if (class2.UInt32_0 >= 256U)
							{
								@class.Boolean_0 = true;
							}
							@class.Int32_0 = (int)class2.UInt32_0;
							@class.UInt32_0 = class2.uint_0;
						}
					}
				}
			}
		}
		return list2;
	}

	// Token: 0x06002C0B RID: 11275 RVA: 0x001277EC File Offset: 0x001259EC
	public static List<uint> smethod_2(uint uint_1, Class159 class159_1)
	{
		List<uint> list = new List<uint>();
		Class421.smethod_4(uint_1, list, class159_1);
		return list;
	}

	// Token: 0x06002C0C RID: 11276 RVA: 0x00127808 File Offset: 0x00125A08
	public static List<uint> smethod_3(uint[] uint_1, Class159 class159_1)
	{
		uint num = class159_1.Class405_0.method_20(uint_1);
		if (num > 0U)
		{
			return Class421.smethod_2(num, class159_1);
		}
		return new List<uint>();
	}

	// Token: 0x06002C0D RID: 11277 RVA: 0x00127834 File Offset: 0x00125A34
	private static void smethod_4(uint uint_1, List<uint> list_0, Class159 class159_1)
	{
		if (list_0.Count > 1000)
		{
			return;
		}
		if (!list_0.Contains(uint_1))
		{
			list_0.Add(uint_1);
			uint num = class159_1.Class405_0.method_11(uint_1);
			if (num > 0U)
			{
				Class421.smethod_4(num, list_0, class159_1);
			}
			uint num2 = class159_1.Class405_0.method_11(uint_1 + 4U);
			if (num2 > 0U)
			{
				Class421.smethod_4(num2, list_0, class159_1);
			}
			uint num3 = class159_1.Class405_0.method_11(uint_1 + 8U);
			if (num3 > 0U)
			{
				Class421.smethod_4(num3, list_0, class159_1);
			}
		}
	}

	// Token: 0x04001D39 RID: 7481
	public int int_0;

	// Token: 0x04001D3A RID: 7482
	public int int_1;

	// Token: 0x04001D3B RID: 7483
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001D3C RID: 7484
	public string string_1;

	// Token: 0x04001D3D RID: 7485
	public int int_2;

	// Token: 0x04001D3E RID: 7486
	public int int_3;

	// Token: 0x04001D3F RID: 7487
	public int int_4;

	// Token: 0x04001D40 RID: 7488
	public string string_2;

	// Token: 0x04001D41 RID: 7489
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04001D42 RID: 7490
	[CompilerGenerated]
	private int int_5;

	// Token: 0x04001D43 RID: 7491
	private Class159 class159_0;

	// Token: 0x04001D44 RID: 7492
	[CompilerGenerated]
	private uint uint_0;
}
