﻿using System;

// Token: 0x020000A3 RID: 163
internal enum Enum9
{
	// Token: 0x0400042D RID: 1069
	None,
	// Token: 0x0400042E RID: 1070
	Cr,
	// Token: 0x0400042F RID: 1071
	Lf
}
