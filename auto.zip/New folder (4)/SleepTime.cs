﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000329 RID: 809
public class SleepTime : UserControl
{
	// Token: 0x06002E52 RID: 11858 RVA: 0x00021AB9 File Offset: 0x0001FCB9
	public SleepTime()
	{
		this.InitializeComponent();
	}

	// Token: 0x06002E53 RID: 11859 RVA: 0x001362BC File Offset: 0x001344BC
	private void btnAdd_Click(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem();
		listViewItem.Text = string.Concat(new string[]
		{
			this.txtHFrom.Text.smethod_18().ToString(),
			":",
			this.txtMFrom.Text.smethod_18().ToString(),
			" -> ",
			this.txtHEnd.Text.smethod_18().ToString(),
			":",
			this.txtMEnd.Text.smethod_18().ToString()
		});
		this.lv.Items.Add(listViewItem);
		this.method_0();
	}

	// Token: 0x06002E54 RID: 11860 RVA: 0x0013637C File Offset: 0x0013457C
	public void method_0()
	{
		string text = "";
		foreach (object obj in this.lv.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = text + listViewItem.Text + "\r\n";
		}
		Class159.Class220_0.method_1("Config", "SleepTime", text);
	}

	// Token: 0x06002E55 RID: 11861 RVA: 0x00136404 File Offset: 0x00134604
	private void SleepTime_Load(object sender, EventArgs e)
	{
		foreach (string text in Class159.Class220_0.method_0("Config", "SleepTime").Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length > 3)
			{
				ListViewItem value = new ListViewItem(text.Trim());
				this.lv.Items.Add(value);
			}
		}
	}

	// Token: 0x06002E56 RID: 11862 RVA: 0x00021AC7 File Offset: 0x0001FCC7
	private void method_1(object sender, FormClosingEventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06002E57 RID: 11863 RVA: 0x00136474 File Offset: 0x00134674
	private void lv_DoubleClick(object sender, EventArgs e)
	{
		this.lv.SelectedItems.Cast<ListViewItem>().ToList<ListViewItem>().ForEach(new Action<ListViewItem>(SleepTime.Class447.<>9.method_0));
		this.method_0();
	}

	// Token: 0x06002E58 RID: 11864 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06002E59 RID: 11865 RVA: 0x00021ACF File Offset: 0x0001FCCF
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06002E5A RID: 11866 RVA: 0x001364C0 File Offset: 0x001346C0
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(SleepTime));
		this.lv = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.panel1 = new Panel();
		this.splitContainer1 = new SplitContainer();
		this.txtMFrom = new Class85();
		this.txtHFrom = new Class85();
		this.label1 = new Label();
		this.txtMEnd = new Class85();
		this.txtHEnd = new Class85();
		this.label2 = new Label();
		this.btnAdd = new Button();
		this.button1 = new Button();
		this.panel1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.lv.AllowColumnReorder = true;
		this.lv.AllowDrop = true;
		this.lv.AllowReorder = true;
		this.lv.AllowSort = true;
		this.lv.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lv.Dock = DockStyle.Fill;
		this.lv.DoubleClickActivation = false;
		this.lv.FullRowSelect = true;
		this.lv.GridLines = true;
		this.lv.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lv.hideItems");
		this.lv.HideSelection = false;
		this.lv.LineColor = Color.Red;
		this.lv.Location = new Point(0, 85);
		this.lv.Name = "lv";
		this.lv.Size = new Size(232, 263);
		this.lv.TabIndex = 1;
		this.lv.UseCompatibleStateImageBehavior = false;
		this.lv.View = View.Details;
		this.lv.DoubleClick += this.lv_DoubleClick;
		this.columnHeader_0.Text = "Thời Gian";
		this.columnHeader_0.Width = 166;
		this.panel1.Controls.Add(this.splitContainer1);
		this.panel1.Controls.Add(this.btnAdd);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(0, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(232, 85);
		this.panel1.TabIndex = 2;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtMFrom);
		this.splitContainer1.Panel1.Controls.Add(this.txtHFrom);
		this.splitContainer1.Panel1.Controls.Add(this.label1);
		this.splitContainer1.Panel2.Controls.Add(this.txtMEnd);
		this.splitContainer1.Panel2.Controls.Add(this.txtHEnd);
		this.splitContainer1.Panel2.Controls.Add(this.label2);
		this.splitContainer1.Size = new Size(232, 62);
		this.splitContainer1.SplitterDistance = 116;
		this.splitContainer1.TabIndex = 1;
		this.txtMFrom.Dock = DockStyle.Top;
		this.txtMFrom.Location = new Point(0, 43);
		this.txtMFrom.Name = "txtMFrom";
		this.txtMFrom.Size = new Size(116, 20);
		this.txtMFrom.TabIndex = 2;
		this.txtMFrom.String_0 = "Phút";
		this.txtMFrom.Color_0 = Color.Gray;
		this.txtMFrom.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtMFrom.Color_1 = Color.LightGray;
		this.txtHFrom.Dock = DockStyle.Top;
		this.txtHFrom.Location = new Point(0, 23);
		this.txtHFrom.Name = "txtHFrom";
		this.txtHFrom.Size = new Size(116, 20);
		this.txtHFrom.TabIndex = 1;
		this.txtHFrom.String_0 = "Giờ";
		this.txtHFrom.Color_0 = Color.Gray;
		this.txtHFrom.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtHFrom.Color_1 = Color.LightGray;
		this.label1.Dock = DockStyle.Top;
		this.label1.Location = new Point(0, 0);
		this.label1.Name = "label1";
		this.label1.Size = new Size(116, 23);
		this.label1.TabIndex = 0;
		this.label1.Text = "Bắt Đầu";
		this.label1.TextAlign = ContentAlignment.MiddleCenter;
		this.txtMEnd.Dock = DockStyle.Top;
		this.txtMEnd.Location = new Point(0, 43);
		this.txtMEnd.Name = "txtMEnd";
		this.txtMEnd.Size = new Size(112, 20);
		this.txtMEnd.TabIndex = 4;
		this.txtMEnd.String_0 = "Phút";
		this.txtMEnd.Color_0 = Color.Gray;
		this.txtMEnd.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtMEnd.Color_1 = Color.LightGray;
		this.txtHEnd.Dock = DockStyle.Top;
		this.txtHEnd.Location = new Point(0, 23);
		this.txtHEnd.Name = "txtHEnd";
		this.txtHEnd.Size = new Size(112, 20);
		this.txtHEnd.TabIndex = 3;
		this.txtHEnd.String_0 = "Giờ";
		this.txtHEnd.Color_0 = Color.Gray;
		this.txtHEnd.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtHEnd.Color_1 = Color.LightGray;
		this.label2.Dock = DockStyle.Top;
		this.label2.Location = new Point(0, 0);
		this.label2.Name = "label2";
		this.label2.Size = new Size(112, 23);
		this.label2.TabIndex = 1;
		this.label2.Text = "Kết Thúc";
		this.label2.TextAlign = ContentAlignment.MiddleCenter;
		this.btnAdd.Dock = DockStyle.Bottom;
		this.btnAdd.Location = new Point(0, 62);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new Size(232, 23);
		this.btnAdd.TabIndex = 0;
		this.btnAdd.Text = "Thêm";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += this.btnAdd_Click;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 348);
		this.button1.Name = "button1";
		this.button1.Size = new Size(232, 23);
		this.button1.TabIndex = 4;
		this.button1.Text = "Ok";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lv);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.button1);
		base.Name = "SleepTime";
		base.Size = new Size(232, 371);
		base.Load += this.SleepTime_Load;
		this.panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04001FA1 RID: 8097
	private IContainer icontainer_0;

	// Token: 0x04001FA2 RID: 8098
	private ListViewEx lv;

	// Token: 0x04001FA3 RID: 8099
	private ColumnHeader columnHeader_0;

	// Token: 0x04001FA4 RID: 8100
	private Panel panel1;

	// Token: 0x04001FA5 RID: 8101
	private SplitContainer splitContainer1;

	// Token: 0x04001FA6 RID: 8102
	private Button btnAdd;

	// Token: 0x04001FA7 RID: 8103
	private Label label1;

	// Token: 0x04001FA8 RID: 8104
	private Label label2;

	// Token: 0x04001FA9 RID: 8105
	private Class85 txtMFrom;

	// Token: 0x04001FAA RID: 8106
	private Class85 txtHFrom;

	// Token: 0x04001FAB RID: 8107
	private Class85 txtMEnd;

	// Token: 0x04001FAC RID: 8108
	private Class85 txtHEnd;

	// Token: 0x04001FAD RID: 8109
	private Button button1;

	// Token: 0x0200032A RID: 810
	[CompilerGenerated]
	[Serializable]
	private sealed class Class447
	{
		// Token: 0x06002E5D RID: 11869 RVA: 0x00021AFA File Offset: 0x0001FCFA
		internal void method_0(ListViewItem listViewItem_0)
		{
			listViewItem_0.Remove();
		}

		// Token: 0x04001FAE RID: 8110
		public static readonly SleepTime.Class447 <>9 = new SleepTime.Class447();

		// Token: 0x04001FAF RID: 8111
		public static Action<ListViewItem> <>9__5_0;
	}
}
