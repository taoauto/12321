﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200018B RID: 395
public class GClass109
{
	// Token: 0x0600123A RID: 4666 RVA: 0x00068E90 File Offset: 0x00067090
	public GClass109(GClass116 gclass116_0)
	{
		GStruct6 gstruct = gclass116_0.GStruct10_0.OptionalHeader.DataDirectory[2];
		if (gstruct.VirtualAddress > 0U && gstruct.Size > 0U)
		{
			uint uint_;
			GStruct13 gstruct2;
			if (!gclass116_0.method_3<GStruct13>((long)((ulong)(uint_ = gclass116_0.method_11(gstruct.VirtualAddress))), SeekOrigin.Begin, out gstruct2))
			{
				throw gclass116_0.vmethod_1();
			}
			GStruct14 gstruct14_ = new GStruct14
			{
				SubdirectoryRva = 2147483648U
			};
			this.GClass111_0 = new GClass109.GClass111(gclass116_0, gstruct14_, false, uint_);
		}
	}

	// Token: 0x170004AE RID: 1198
	// (get) Token: 0x0600123B RID: 4667 RVA: 0x0000E615 File Offset: 0x0000C815
	// (set) Token: 0x0600123C RID: 4668 RVA: 0x0000E61D File Offset: 0x0000C81D
	public GClass109.GClass111 GClass111_0 { get; private set; }

	// Token: 0x04000A1B RID: 2587
	[CompilerGenerated]
	private GClass109.GClass111 gclass111_0;

	// Token: 0x0200018C RID: 396
	public class GClass111 : GClass109.GClass110
	{
		// Token: 0x0600123D RID: 4669 RVA: 0x0000E626 File Offset: 0x0000C826
		public GClass111(GClass116 gclass116_1, GStruct14 gstruct14_1, bool bool_1, uint uint_3) : base(gclass116_1, gstruct14_1, bool_1, uint_3)
		{
			if (!gclass116_1.method_3<GStruct13>((long)((ulong)(uint_3 + (gstruct14_1.SubdirectoryRva ^ 2147483648U))), SeekOrigin.Begin, out this.gstruct13_0))
			{
				throw gclass116_1.vmethod_1();
			}
		}

		// Token: 0x0600123E RID: 4670 RVA: 0x00068F18 File Offset: 0x00067118
		private void method_0()
		{
			List<GClass109.GClass111> list = new List<GClass109.GClass111>();
			List<GClass109.GClass112> list2 = new List<GClass109.GClass112>();
			int numberOfNamedEntries = (int)this.gstruct13_0.NumberOfNamedEntries;
			for (int i = 0; i < numberOfNamedEntries + (int)this.gstruct13_0.NumberOfIdEntries; i++)
			{
				GStruct14 gstruct;
				if (this.gclass116_0.method_3<GStruct14>((long)((ulong)(this.uint_0 + 16U + (this.gstruct14_0.SubdirectoryRva ^ 2147483648U)) + (ulong)((long)i * 8L)), SeekOrigin.Begin, out gstruct))
				{
					if ((gstruct.SubdirectoryRva & 2147483648U) != 0U)
					{
						list.Add(new GClass109.GClass111(this.gclass116_0, gstruct, i < numberOfNamedEntries, this.uint_0));
					}
					else
					{
						list2.Add(new GClass109.GClass112(this.gclass116_0, gstruct, i < numberOfNamedEntries, this.uint_0));
					}
				}
			}
			this.gclass112_0 = list2.ToArray();
			this.gclass111_0 = list.ToArray();
		}

		// Token: 0x170004AF RID: 1199
		// (get) Token: 0x0600123F RID: 4671 RVA: 0x0000E659 File Offset: 0x0000C859
		public GClass109.GClass111[] GClass111_0
		{
			get
			{
				if (this.gclass111_0 == null)
				{
					this.method_0();
				}
				return this.gclass111_0;
			}
		}

		// Token: 0x170004B0 RID: 1200
		// (get) Token: 0x06001240 RID: 4672 RVA: 0x0000E66F File Offset: 0x0000C86F
		public GClass109.GClass112[] GClass112_0
		{
			get
			{
				if (this.gclass112_0 == null)
				{
					this.method_0();
				}
				return this.gclass112_0;
			}
		}

		// Token: 0x04000A1C RID: 2588
		private GStruct13 gstruct13_0;

		// Token: 0x04000A1D RID: 2589
		private GClass109.GClass111[] gclass111_0;

		// Token: 0x04000A1E RID: 2590
		private GClass109.GClass112[] gclass112_0;

		// Token: 0x04000A1F RID: 2591
		private const uint uint_1 = 16U;

		// Token: 0x04000A20 RID: 2592
		private const uint uint_2 = 8U;
	}

	// Token: 0x0200018D RID: 397
	public class GClass112 : GClass109.GClass110
	{
		// Token: 0x06001241 RID: 4673 RVA: 0x0000E685 File Offset: 0x0000C885
		public GClass112(GClass116 gclass116_1, GStruct14 gstruct14_1, bool bool_1, uint uint_1) : base(gclass116_1, gstruct14_1, bool_1, uint_1)
		{
			if (!gclass116_1.method_3<GStruct12>((long)((ulong)(this.uint_0 + gstruct14_1.DataEntryRva)), SeekOrigin.Begin, out this.gstruct12_0))
			{
				throw gclass116_1.vmethod_1();
			}
		}

		// Token: 0x06001242 RID: 4674 RVA: 0x00068FF0 File Offset: 0x000671F0
		public byte[] method_0()
		{
			byte[] array = new byte[this.gstruct12_0.Size];
			if (!this.gclass116_0.method_2((long)((ulong)this.gclass116_0.method_11(this.gstruct12_0.OffsetToData)), SeekOrigin.Begin, array))
			{
				throw this.gclass116_0.vmethod_1();
			}
			return array;
		}

		// Token: 0x04000A21 RID: 2593
		private GStruct12 gstruct12_0;
	}

	// Token: 0x0200018E RID: 398
	public abstract class GClass110
	{
		// Token: 0x06001243 RID: 4675 RVA: 0x00069044 File Offset: 0x00067244
		public GClass110(GClass116 gclass116_1, GStruct14 gstruct14_1, bool bool_1, uint uint_1)
		{
			this.gclass116_0 = gclass116_1;
			this.gstruct14_0 = gstruct14_1;
			this.Boolean_0 = bool_1;
			if (bool_1)
			{
				ushort num = 0;
				if (gclass116_1.method_3<ushort>((long)((ulong)(uint_1 + (gstruct14_1.NameRva & 2147483647U))), SeekOrigin.Begin, out num))
				{
					byte[] array = new byte[(int)num << 1];
					if (gclass116_1.method_2(0L, SeekOrigin.Current, array))
					{
						this.string_0 = Encoding.Unicode.GetString(array);
					}
				}
				if (this.string_0 == null)
				{
					throw gclass116_1.vmethod_1();
				}
			}
			this.uint_0 = uint_1;
		}

		// Token: 0x170004B1 RID: 1201
		// (get) Token: 0x06001244 RID: 4676 RVA: 0x0000E6B6 File Offset: 0x0000C8B6
		public int Int32_0
		{
			get
			{
				if (!this.Boolean_0)
				{
					return (int)this.gstruct14_0.IntegerId;
				}
				return -1;
			}
		}

		// Token: 0x170004B2 RID: 1202
		// (get) Token: 0x06001245 RID: 4677 RVA: 0x0000E6CD File Offset: 0x0000C8CD
		// (set) Token: 0x06001246 RID: 4678 RVA: 0x0000E6D5 File Offset: 0x0000C8D5
		public bool Boolean_0 { get; protected set; }

		// Token: 0x170004B3 RID: 1203
		// (get) Token: 0x06001247 RID: 4679 RVA: 0x0000E6DE File Offset: 0x0000C8DE
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x04000A22 RID: 2594
		protected GStruct14 gstruct14_0;

		// Token: 0x04000A23 RID: 2595
		private string string_0;

		// Token: 0x04000A24 RID: 2596
		protected GClass116 gclass116_0;

		// Token: 0x04000A25 RID: 2597
		protected uint uint_0;

		// Token: 0x04000A26 RID: 2598
		[CompilerGenerated]
		private bool bool_0;
	}
}
