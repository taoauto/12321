﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000233 RID: 563
internal class FrmLocdoOpt : UserControl
{
	// Token: 0x06001E87 RID: 7815 RVA: 0x00016A14 File Offset: 0x00014C14
	public FrmLocdoOpt(Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.InitializeComponent();
	}

	// Token: 0x06001E88 RID: 7816 RVA: 0x00016A29 File Offset: 0x00014C29
	private void txtLst_TextChanged(object sender, EventArgs e)
	{
		this.class159_0.String_4 = this.txtLst.Text;
	}

	// Token: 0x06001E89 RID: 7817 RVA: 0x000E3444 File Offset: 0x000E1644
	private void FrmLocdoOpt_Load(object sender, EventArgs e)
	{
		new List<string>();
		this.txtLst.Text = this.class159_0.String_4;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Select(new Func<string, ListViewItem>(FrmLocdoOpt.Class267.<>9.method_0)).ToArray<ListViewItem>());
		base.Tag = "Chỉ Nhặt - OnlyPick - " + this.class159_0.Class432_0.String_2;
	}

	// Token: 0x06001E8A RID: 7818 RVA: 0x00002E18 File Offset: 0x00001018
	private void lvName_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001E8B RID: 7819 RVA: 0x000E34CC File Offset: 0x000E16CC
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtLst.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtLst.Text = this.txtLst.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
	}

	// Token: 0x06001E8C RID: 7820 RVA: 0x00016A41 File Offset: 0x00014C41
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001E8D RID: 7821 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuName_Opening(object sender, CancelEventArgs e)
	{
	}

	// Token: 0x06001E8E RID: 7822 RVA: 0x00016A41 File Offset: 0x00014C41
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001E8F RID: 7823 RVA: 0x00016A49 File Offset: 0x00014C49
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearch.Text);
	}

	// Token: 0x06001E90 RID: 7824 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_1(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06001E91 RID: 7825 RVA: 0x00016A62 File Offset: 0x00014C62
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001E92 RID: 7826 RVA: 0x000E35C0 File Offset: 0x000E17C0
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(FrmLocdoOpt));
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtLst = new Class85();
		this.txtSearch = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.menuName.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(246, 319);
		this.lvName.TabIndex = 11;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.SelectedIndexChanged += this.lvName_SelectedIndexChanged;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 198;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuName.Opening += this.menuName_Opening;
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtLst.Dock = DockStyle.Fill;
		this.txtLst.Location = new Point(0, 0);
		this.txtLst.Multiline = true;
		this.txtLst.Name = "txtLst";
		this.txtLst.Size = new Size(229, 339);
		this.txtLst.TabIndex = 12;
		this.txtLst.String_0 = "Chỉ Nhặt Những Vật Phẩm Sau";
		this.txtLst.Color_0 = Color.Gray;
		this.txtLst.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtLst.Color_1 = Color.LightGray;
		this.txtLst.TextChanged += this.txtLst_TextChanged;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(246, 20);
		this.txtSearch.TabIndex = 13;
		this.txtSearch.String_0 = "Search";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtLst);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(479, 339);
		this.splitContainer1.SplitterDistance = 229;
		this.splitContainer1.TabIndex = 14;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Name = "FrmLocdoOpt";
		base.Size = new Size(479, 339);
		base.Load += this.FrmLocdoOpt_Load;
		this.menuName.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040012F3 RID: 4851
	private Class159 class159_0;

	// Token: 0x040012F4 RID: 4852
	private IContainer icontainer_0;

	// Token: 0x040012F5 RID: 4853
	private ListViewEx lvName;

	// Token: 0x040012F6 RID: 4854
	private ColumnHeader columnHeader_0;

	// Token: 0x040012F7 RID: 4855
	private ContextMenuStrip menuName;

	// Token: 0x040012F8 RID: 4856
	private ToolStripMenuItem menuAddName;

	// Token: 0x040012F9 RID: 4857
	private Class85 txtLst;

	// Token: 0x040012FA RID: 4858
	private Class85 txtSearch;

	// Token: 0x040012FB RID: 4859
	private SplitContainer splitContainer1;

	// Token: 0x02000234 RID: 564
	[CompilerGenerated]
	[Serializable]
	private sealed class Class267
	{
		// Token: 0x06001E95 RID: 7829 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x040012FC RID: 4860
		public static readonly FrmLocdoOpt.Class267 <>9 = new FrmLocdoOpt.Class267();

		// Token: 0x040012FD RID: 4861
		public static Func<string, ListViewItem> <>9__3_0;
	}
}
