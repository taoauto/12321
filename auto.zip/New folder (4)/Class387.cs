﻿using System;

// Token: 0x020002BE RID: 702
internal class Class387
{
	// Token: 0x17000878 RID: 2168
	// (get) Token: 0x0600270D RID: 9997 RVA: 0x0001D16A File Offset: 0x0001B36A
	public static string String_0
	{
		get
		{
			return "https://microauto.org/tieudattai/";
		}
	}
}
