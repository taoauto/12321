﻿using System;
using System.Collections.Generic;

// Token: 0x02000160 RID: 352
internal class Class143 : Interface4
{
	// Token: 0x060010C1 RID: 4289 RVA: 0x0000D998 File Offset: 0x0000BB98
	public void imethod_0(Class130 class130_1)
	{
		this.int_0 = 0;
		this.class130_0 = class130_1;
	}

	// Token: 0x060010C2 RID: 4290 RVA: 0x0005BC80 File Offset: 0x00059E80
	public Class141 imethod_1()
	{
		if (this.class130_0.List_0 != null && this.class130_0.List_0.Count != 0)
		{
			List<Class141> list_ = this.class130_0.List_0;
			Class141 result;
			lock (list_)
			{
				if (this.int_0 >= this.class130_0.List_0.Count)
				{
					this.int_0 = 0;
					result = this.class130_0.Class141_0;
				}
				else
				{
					List<Class141> list_2 = this.class130_0.List_0;
					int num = this.int_0;
					this.int_0 = num + 1;
					result = list_2[num];
				}
			}
			return result;
		}
		return this.class130_0.Class141_0;
	}

	// Token: 0x0400087E RID: 2174
	private Class130 class130_0;

	// Token: 0x0400087F RID: 2175
	private int int_0;
}
