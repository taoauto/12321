﻿using System;
using System.Collections;
using System.Collections.Generic;

// Token: 0x020000C1 RID: 193
public abstract class GClass56 : ICollection<GClass58>, IDisposable, IEnumerable<GClass58>, IEnumerable
{
	// Token: 0x06000959 RID: 2393
	public abstract void Add(GClass58 item);

	// Token: 0x0600095A RID: 2394
	public abstract void Clear();

	// Token: 0x0600095B RID: 2395
	public abstract bool Contains(GClass58 item);

	// Token: 0x0600095C RID: 2396
	public abstract void CopyTo(GClass58[] array, int arrayIndex);

	// Token: 0x170002A1 RID: 673
	// (get) Token: 0x0600095D RID: 2397
	public abstract int Count { get; }

	// Token: 0x170002A2 RID: 674
	// (get) Token: 0x0600095E RID: 2398
	public abstract bool IsReadOnly { get; }

	// Token: 0x0600095F RID: 2399
	public abstract bool Remove(GClass58 item);

	// Token: 0x06000960 RID: 2400
	public abstract IEnumerator<GClass58> GetEnumerator();

	// Token: 0x06000961 RID: 2401 RVA: 0x000091C4 File Offset: 0x000073C4
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	// Token: 0x06000962 RID: 2402
	public abstract void Dispose();

	// Token: 0x06000963 RID: 2403
	public abstract void \u202B\u206E\u202B\u202C\u200F\u200D\u206D\u206D\u202E\u202E\u202C\u202B\u200C\u202B\u206A\u206A\u202E\u202E\u202D\u200E\u206A\u202E\u200C\u206A\u206B\u202B\u202B\u202A\u206E\u200F\u202C\u202B\u202A\u200C\u206D\u206D\u206A\u202D\u206E\u206C\u202E(int int_0, string string_0);

	// Token: 0x06000964 RID: 2404
	public abstract void \u202B\u206E\u202B\u202C\u200F\u200D\u206D\u206D\u202E\u202E\u202C\u202B\u200C\u202B\u206A\u206A\u202E\u202E\u202D\u200E\u206A\u202E\u200C\u206A\u206B\u202B\u202B\u202A\u206E\u200F\u202C\u202B\u202A\u200C\u206D\u206D\u206A\u202D\u206E\u206C\u202E(int int_0);

	// Token: 0x06000965 RID: 2405
	public abstract bool \u206B\u206C\u200F\u206F\u200F\u202D\u202C\u200F\u200C\u206B\u202C\u200C\u200C\u200B\u206D\u206F\u206A\u206C\u200C\u200E\u200E\u206C\u200E\u206D\u206F\u202D\u202A\u200C\u200B\u202E\u206E\u206D\u202A\u200E\u202A\u202A\u200C\u206B\u206C\u202E\u202E(int int_0);

	// Token: 0x06000966 RID: 2406
	public abstract bool \u202E\u200F\u206E\u200D\u202D\u202A\u200B\u202A\u200E\u202B\u202C\u206B\u206D\u200C\u200D\u202E\u206B\u206C\u206C\u200D\u206C\u206E\u202A\u206E\u200F\u202E\u206B\u206F\u206B\u206A\u200E\u202C\u200E\u202D\u200C\u202A\u200C\u200B\u206E\u200F\u202E(int int_0);

	// Token: 0x06000967 RID: 2407
	public abstract GClass58 \u202E\u206A\u206E\u200F\u206A\u206B\u200D\u202E\u200D\u206F\u206E\u202A\u200C\u202B\u202E\u202D\u206B\u200E\u206F\u200C\u200C\u200F\u206B\u200F\u200F\u206C\u206B\u206F\u202A\u202B\u206B\u200C\u202D\u206A\u202B\u200D\u200D\u202A\u206F\u202D\u202E(int int_0);
}
