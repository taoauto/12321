﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

// Token: 0x020000D6 RID: 214
public class GControl1 : Control
{
	// Token: 0x170002B4 RID: 692
	// (get) Token: 0x060009E4 RID: 2532 RVA: 0x00009719 File Offset: 0x00007919
	// (set) Token: 0x060009E5 RID: 2533 RVA: 0x00009721 File Offset: 0x00007921
	[Description("Target FastColoredTextBox")]
	public FastColoredTextBox FastColoredTextBox_0
	{
		get
		{
			return this.fastColoredTextBox_0;
		}
		set
		{
			if (this.fastColoredTextBox_0 != null)
			{
				this.vmethod_1(this.fastColoredTextBox_0);
			}
			this.fastColoredTextBox_0 = value;
			if (value != null)
			{
				this.vmethod_2(this.fastColoredTextBox_0);
			}
			this.vmethod_0();
		}
	}

	// Token: 0x170002B5 RID: 693
	// (get) Token: 0x060009E6 RID: 2534 RVA: 0x00009753 File Offset: 0x00007953
	// (set) Token: 0x060009E7 RID: 2535 RVA: 0x0000975B File Offset: 0x0000795B
	[Description("Scale")]
	[DefaultValue(0.3f)]
	public float Single_0
	{
		get
		{
			return this.float_0;
		}
		set
		{
			this.float_0 = value;
			this.method_1();
		}
	}

	// Token: 0x170002B6 RID: 694
	// (get) Token: 0x060009E8 RID: 2536 RVA: 0x0000976A File Offset: 0x0000796A
	// (set) Token: 0x060009E9 RID: 2537 RVA: 0x00009772 File Offset: 0x00007972
	[Description("Scrollbar visibility")]
	[DefaultValue(true)]
	public bool Boolean_0
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
			this.method_1();
		}
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x00040680 File Offset: 0x0003E880
	public GControl1()
	{
		this.ForeColor = Color.Maroon;
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		Application.Idle += this.method_0;
	}

	// Token: 0x060009EB RID: 2539 RVA: 0x00009781 File Offset: 0x00007981
	private void method_0(object sender, EventArgs e)
	{
		if (this.bool_0)
		{
			base.Invalidate();
		}
	}

	// Token: 0x060009EC RID: 2540 RVA: 0x00009791 File Offset: 0x00007991
	protected virtual void vmethod_0()
	{
		this.method_1();
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, EventArgs.Empty);
		}
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x000097B2 File Offset: 0x000079B2
	protected virtual void vmethod_1(FastColoredTextBox fastColoredTextBox_1)
	{
		fastColoredTextBox_1.Scroll -= this.vmethod_5;
		fastColoredTextBox_1.Event_9 -= this.vmethod_4;
		fastColoredTextBox_1.Event_7 -= this.vmethod_3;
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x000097ED File Offset: 0x000079ED
	protected virtual void vmethod_2(FastColoredTextBox fastColoredTextBox_1)
	{
		fastColoredTextBox_1.Scroll += this.vmethod_5;
		fastColoredTextBox_1.Event_9 += this.vmethod_4;
		fastColoredTextBox_1.Event_7 += this.vmethod_3;
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x00009828 File Offset: 0x00007A28
	protected virtual void vmethod_3(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x00009828 File Offset: 0x00007A28
	protected virtual void vmethod_4(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x060009F1 RID: 2545 RVA: 0x00009828 File Offset: 0x00007A28
	protected virtual void vmethod_5(object sender, ScrollEventArgs e)
	{
		this.method_1();
	}

	// Token: 0x060009F2 RID: 2546 RVA: 0x00009830 File Offset: 0x00007A30
	protected virtual void OnResize(EventArgs e)
	{
		base.OnResize(e);
		this.method_1();
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x0000983F File Offset: 0x00007A3F
	public void method_1()
	{
		this.bool_0 = true;
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x000406E0 File Offset: 0x0003E8E0
	protected virtual void OnPaint(PaintEventArgs e)
	{
		if (this.fastColoredTextBox_0 == null)
		{
			return;
		}
		float num = this.Single_0 * 100f / (float)this.fastColoredTextBox_0.Int32_21;
		if (num <= 1E-45f)
		{
			return;
		}
		GClass86 gclass86_ = this.fastColoredTextBox_0.GClass86_4;
		if (this.gstruct2_0.int_1 > gclass86_.GStruct2_0.int_1)
		{
			this.gstruct2_0.int_1 = gclass86_.GStruct2_0.int_1;
		}
		else
		{
			Point point_ = this.fastColoredTextBox_0.method_95(gclass86_.GStruct2_1);
			point_.Offset(0, -(int)((float)base.ClientSize.Height / num) + this.fastColoredTextBox_0.Int32_2);
			GStruct2 gstruct = this.fastColoredTextBox_0.method_84(point_);
			if (gstruct.int_1 > this.gstruct2_0.int_1)
			{
				this.gstruct2_0.int_1 = gstruct.int_1;
			}
		}
		this.gstruct2_0.int_0 = 0;
		int count = this.fastColoredTextBox_0.IList_0.Count;
		float num2 = (float)gclass86_.GStruct2_0.int_1 / (float)count;
		float num3 = (float)gclass86_.GStruct2_1.int_1 / (float)count;
		e.Graphics.ScaleTransform(num, num);
		SizeF sizeF = new SizeF((float)base.ClientSize.Width / num, (float)base.ClientSize.Height / num);
		this.fastColoredTextBox_0.method_70(e.Graphics, this.gstruct2_0, sizeF.ToSize());
		Point point = this.fastColoredTextBox_0.method_95(this.gstruct2_0);
		Point point2 = this.fastColoredTextBox_0.method_95(gclass86_.GStruct2_0);
		Point point3 = this.fastColoredTextBox_0.method_95(gclass86_.GStruct2_1);
		int num4 = point2.Y - point.Y;
		int num5 = point3.Y + this.fastColoredTextBox_0.Int32_2 - point.Y;
		e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
		using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(50, this.ForeColor)))
		{
			using (Pen pen = new Pen(solidBrush, 1f / num))
			{
				Rectangle rect = new Rectangle(0, num4, (int)((float)(base.ClientSize.Width - 1) / num), num5 - num4);
				e.Graphics.FillRectangle(solidBrush, rect);
				e.Graphics.DrawRectangle(pen, rect);
			}
		}
		if (this.bool_1)
		{
			e.Graphics.ResetTransform();
			e.Graphics.SmoothingMode = SmoothingMode.None;
			using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(200, this.ForeColor)))
			{
				RectangleF rect2 = new RectangleF((float)(base.ClientSize.Width - 3), (float)base.ClientSize.Height * num2, 2f, (float)base.ClientSize.Height * (num3 - num2));
				e.Graphics.FillRectangle(solidBrush2, rect2);
			}
		}
		this.bool_0 = false;
	}

	// Token: 0x060009F5 RID: 2549 RVA: 0x00009848 File Offset: 0x00007A48
	protected virtual void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.method_2(e.Location);
		}
		base.OnMouseDown(e);
	}

	// Token: 0x060009F6 RID: 2550 RVA: 0x0000986A File Offset: 0x00007A6A
	protected virtual void OnMouseMove(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.method_2(e.Location);
		}
		base.OnMouseMove(e);
	}

	// Token: 0x060009F7 RID: 2551 RVA: 0x00040A18 File Offset: 0x0003EC18
	private void method_2(Point point_0)
	{
		if (this.fastColoredTextBox_0 == null)
		{
			return;
		}
		float num = this.Single_0 * 100f / (float)this.fastColoredTextBox_0.Int32_21;
		if (num <= 1E-45f)
		{
			return;
		}
		Point point_ = this.fastColoredTextBox_0.method_95(this.gstruct2_0);
		point_ = new Point(0, point_.Y + (int)((float)point_0.Y / num));
		GStruct2 gstruct = this.fastColoredTextBox_0.method_84(point_);
		this.fastColoredTextBox_0.method_53(new GClass86(this.fastColoredTextBox_0, gstruct, gstruct), true);
		base.BeginInvoke(new MethodInvoker(this.method_3));
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x0000988C File Offset: 0x00007A8C
	private void method_3()
	{
		this.Refresh();
		this.fastColoredTextBox_0.Refresh();
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x0000989F File Offset: 0x00007A9F
	protected virtual void Dispose(bool disposing)
	{
		if (disposing)
		{
			Application.Idle -= this.method_0;
			if (this.fastColoredTextBox_0 != null)
			{
				this.vmethod_1(this.fastColoredTextBox_0);
			}
		}
		base.Dispose(disposing);
	}

	// Token: 0x040004DC RID: 1244
	public EventHandler eventHandler_0;

	// Token: 0x040004DD RID: 1245
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040004DE RID: 1246
	private float float_0 = 0.3f;

	// Token: 0x040004DF RID: 1247
	private bool bool_0 = true;

	// Token: 0x040004E0 RID: 1248
	private GStruct2 gstruct2_0 = GStruct2.GStruct2_0;

	// Token: 0x040004E1 RID: 1249
	private bool bool_1 = true;
}
