﻿using System;
using System.Diagnostics;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020002F2 RID: 754
internal static class Class414
{
	// Token: 0x06002B12 RID: 11026 RVA: 0x00123910 File Offset: 0x00121B10
	[STAThread]
	private static void Main()
	{
		Application.ThreadException += Class414.smethod_3;
		AppDomain.CurrentDomain.UnhandledException += Class414.smethod_0;
		if (!Class414.smethod_1())
		{
			Class414.smethod_2();
			Application.Exit();
			return;
		}
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Application.Run(new Main());
	}

	// Token: 0x06002B13 RID: 11027 RVA: 0x00002E18 File Offset: 0x00001018
	private static void smethod_0(object sender, UnhandledExceptionEventArgs e)
	{
	}

	// Token: 0x06002B14 RID: 11028 RVA: 0x0001F43B File Offset: 0x0001D63B
	internal static bool smethod_1()
	{
		return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
	}

	// Token: 0x06002B15 RID: 11029 RVA: 0x0012396C File Offset: 0x00121B6C
	private static bool smethod_2()
	{
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			UseShellExecute = true,
			WorkingDirectory = Environment.CurrentDirectory,
			FileName = Application.ExecutablePath,
			Verb = "runas"
		};
		bool result;
		try
		{
			Process.Start(startInfo);
			result = true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06002B16 RID: 11030 RVA: 0x00002E18 File Offset: 0x00001018
	private static void smethod_3(object sender, ThreadExceptionEventArgs e)
	{
	}
}
