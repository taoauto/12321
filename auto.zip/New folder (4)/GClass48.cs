﻿using System;
using System.Collections.ObjectModel;
using System.Text;

// Token: 0x020000B1 RID: 177
public class GClass48 : Encoding
{
	// Token: 0x1700026F RID: 623
	// (get) Token: 0x06000886 RID: 2182 RVA: 0x0003C5EC File Offset: 0x0003A7EC
	protected GClass49 GClass49_0
	{
		get
		{
			GClass49 gclass = this.gclass49_0;
			if (gclass == null)
			{
				gclass = (this.gclass49_0 = new GClass49());
			}
			DecoderFallback decoderFallback = base.DecoderFallback;
			if (decoderFallback != null && decoderFallback != gclass.Fallback)
			{
				gclass.Fallback = decoderFallback;
			}
			return gclass;
		}
	}

	// Token: 0x17000270 RID: 624
	// (get) Token: 0x06000887 RID: 2183 RVA: 0x0003C630 File Offset: 0x0003A830
	protected GClass50 GClass50_0
	{
		get
		{
			GClass50 gclass = this.gclass50_0;
			if (gclass == null)
			{
				gclass = (this.gclass50_0 = new GClass50());
			}
			EncoderFallback encoderFallback = base.EncoderFallback;
			if (encoderFallback != null && encoderFallback != gclass.Fallback)
			{
				gclass.Fallback = encoderFallback;
			}
			return gclass;
		}
	}

	// Token: 0x17000271 RID: 625
	// (get) Token: 0x06000888 RID: 2184 RVA: 0x000088A2 File Offset: 0x00006AA2
	public virtual string BodyName
	{
		get
		{
			return "viscii-simple";
		}
	}

	// Token: 0x17000272 RID: 626
	// (get) Token: 0x06000889 RID: 2185 RVA: 0x000088A9 File Offset: 0x00006AA9
	public virtual string EncodingName
	{
		get
		{
			return this.BodyName;
		}
	}

	// Token: 0x17000273 RID: 627
	// (get) Token: 0x0600088A RID: 2186 RVA: 0x0000354C File Offset: 0x0000174C
	public virtual bool IsSingleByte
	{
		get
		{
			return true;
		}
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x000088B1 File Offset: 0x00006AB1
	public virtual object Clone()
	{
		GClass48 gclass = (GClass48)base.Clone();
		gclass.gclass49_0 = null;
		gclass.gclass50_0 = null;
		return gclass;
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x000088CC File Offset: 0x00006ACC
	public virtual Decoder GetDecoder()
	{
		return new GClass49();
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x000088D3 File Offset: 0x00006AD3
	public virtual Encoder GetEncoder()
	{
		return new GClass50();
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x000088DA File Offset: 0x00006ADA
	public virtual int GetByteCount(char[] chars, int index, int count)
	{
		return this.GClass50_0.GetByteCount(chars, index, count, true);
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x000088EB File Offset: 0x00006AEB
	public virtual int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex)
	{
		return this.GClass50_0.GetBytes(chars, charIndex, charCount, bytes, byteIndex, true);
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00008900 File Offset: 0x00006B00
	public virtual int GetCharCount(byte[] bytes, int index, int count)
	{
		return this.GClass49_0.GetCharCount(bytes, index, count, true);
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x00008911 File Offset: 0x00006B11
	public virtual int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
	{
		return this.GClass49_0.GetChars(bytes, byteIndex, byteCount, chars, charIndex, true);
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x00008926 File Offset: 0x00006B26
	public virtual int GetMaxByteCount(int charCount)
	{
		return charCount;
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x00008926 File Offset: 0x00006B26
	public virtual int GetMaxCharCount(int byteCount)
	{
		return byteCount;
	}

	// Token: 0x04000473 RID: 1139
	public static readonly ReadOnlyCollection<char> readOnlyCollection_0 = Array.AsReadOnly<char>(new char[]
	{
		'\0',
		'\u0001',
		'Ẳ',
		'\u0003',
		'\u0004',
		'Ẵ',
		'Ẫ',
		'\a',
		'\b',
		'\t',
		'\n',
		'\v',
		'\f',
		'\r',
		'\u000e',
		'\u000f',
		'\u0010',
		'\u0011',
		'\u0012',
		'\u0013',
		'Ỷ',
		'\u0015',
		'\u0016',
		'\u0017',
		'\u0018',
		'Ỹ',
		'\u001a',
		'\u001b',
		'\u001c',
		'\u001d',
		'Ỵ',
		'\u001f',
		' ',
		'!',
		'"',
		'#',
		'$',
		'%',
		'&',
		'\'',
		'(',
		')',
		'*',
		'+',
		',',
		'-',
		'.',
		'/',
		'0',
		'1',
		'2',
		'3',
		'4',
		'5',
		'6',
		'7',
		'8',
		'9',
		':',
		';',
		'<',
		'=',
		'>',
		'?',
		'@',
		'A',
		'B',
		'C',
		'D',
		'E',
		'F',
		'G',
		'H',
		'I',
		'J',
		'K',
		'L',
		'M',
		'N',
		'O',
		'P',
		'Q',
		'R',
		'S',
		'T',
		'U',
		'V',
		'W',
		'X',
		'Y',
		'Z',
		'[',
		'\\',
		']',
		'^',
		'_',
		'`',
		'a',
		'b',
		'c',
		'd',
		'e',
		'f',
		'g',
		'h',
		'i',
		'j',
		'k',
		'l',
		'm',
		'n',
		'o',
		'p',
		'q',
		'r',
		's',
		't',
		'u',
		'v',
		'w',
		'x',
		'y',
		'z',
		'{',
		'|',
		'}',
		'~',
		'\u007f',
		'Ạ',
		'Ắ',
		'Ằ',
		'Ặ',
		'Ấ',
		'Ầ',
		'Ẩ',
		'Ậ',
		'Ẽ',
		'Ẹ',
		'Ế',
		'Ề',
		'Ể',
		'Ễ',
		'Ệ',
		'Ố',
		'Ồ',
		'Ổ',
		'Ỗ',
		'Ộ',
		'Ợ',
		'Ớ',
		'Ờ',
		'Ở',
		'Ị',
		'Ỏ',
		'Ọ',
		'Ỉ',
		'Ủ',
		'Ũ',
		'Ụ',
		'Ỳ',
		'Õ',
		'ắ',
		'ằ',
		'ặ',
		'ấ',
		'ầ',
		'ẩ',
		'ậ',
		'ẽ',
		'ẹ',
		'ế',
		'ề',
		'ể',
		'ễ',
		'ệ',
		'ố',
		'ồ',
		'ổ',
		'ỗ',
		'Ỡ',
		'Ơ',
		'ộ',
		'ờ',
		'ở',
		'ị',
		'Ự',
		'Ứ',
		'Ừ',
		'Ử',
		'ơ',
		'ớ',
		'Ư',
		'À',
		'Á',
		'Â',
		'Ã',
		'Ả',
		'Ă',
		'ẳ',
		'ẵ',
		'È',
		'É',
		'Ê',
		'Ẻ',
		'Ì',
		'Í',
		'Ĩ',
		'ỳ',
		'Đ',
		'ứ',
		'Ò',
		'Ó',
		'Ô',
		'ạ',
		'ỷ',
		'ừ',
		'ử',
		'Ù',
		'Ú',
		'ỹ',
		'ỵ',
		'Ý',
		'ỡ',
		'ư',
		'à',
		'á',
		'â',
		'ã',
		'ả',
		'ă',
		'ữ',
		'ẫ',
		'è',
		'é',
		'ê',
		'ẻ',
		'ì',
		'í',
		'ĩ',
		'ỉ',
		'đ',
		'ự',
		'ò',
		'ó',
		'ô',
		'õ',
		'ỏ',
		'ọ',
		'ụ',
		'ù',
		'ú',
		'ũ',
		'ủ',
		'ý',
		'ợ',
		'Ữ'
	});

	// Token: 0x04000474 RID: 1140
	private GClass49 gclass49_0;

	// Token: 0x04000475 RID: 1141
	private GClass50 gclass50_0;
}
