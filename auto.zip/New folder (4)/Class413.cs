﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

// Token: 0x020002F0 RID: 752
internal class Class413
{
	// Token: 0x06002B0B RID: 11019
	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenThread(Class413.Enum18 enum18_0, bool bool_0, uint uint_0);

	// Token: 0x06002B0C RID: 11020
	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr intptr_0);

	// Token: 0x06002B0D RID: 11021
	[DllImport("kernel32.dll")]
	private static extern uint SuspendThread(IntPtr intptr_0);

	// Token: 0x06002B0E RID: 11022
	[DllImport("kernel32.dll")]
	private static extern int ResumeThread(IntPtr intptr_0);

	// Token: 0x06002B0F RID: 11023 RVA: 0x001237D0 File Offset: 0x001219D0
	public static void smethod_0(int int_0)
	{
		Process processById = Process.GetProcessById(int_0);
		if (processById.ProcessName == string.Empty)
		{
			return;
		}
		foreach (object obj in processById.Threads)
		{
			ProcessThread processThread = (ProcessThread)obj;
			IntPtr intPtr = Class413.OpenThread(Class413.Enum18.SUSPEND_RESUME, false, (uint)processThread.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				Class413.SuspendThread(intPtr);
				Class413.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x06002B10 RID: 11024 RVA: 0x0012386C File Offset: 0x00121A6C
	public static void smethod_1(int int_0)
	{
		Process processById = Process.GetProcessById(int_0);
		if (processById.ProcessName == string.Empty)
		{
			return;
		}
		foreach (object obj in processById.Threads)
		{
			ProcessThread processThread = (ProcessThread)obj;
			IntPtr intPtr = Class413.OpenThread(Class413.Enum18.SUSPEND_RESUME, false, (uint)processThread.Id);
			if (!(intPtr == IntPtr.Zero))
			{
				int num;
				do
				{
					num = Class413.ResumeThread(intPtr);
				}
				while (num > 0);
				Class413.CloseHandle(intPtr);
			}
		}
	}

	// Token: 0x020002F1 RID: 753
	[Flags]
	public enum Enum18
	{
		// Token: 0x04001CA6 RID: 7334
		TERMINATE = 1,
		// Token: 0x04001CA7 RID: 7335
		SUSPEND_RESUME = 2,
		// Token: 0x04001CA8 RID: 7336
		GET_CONTEXT = 8,
		// Token: 0x04001CA9 RID: 7337
		SET_CONTEXT = 16,
		// Token: 0x04001CAA RID: 7338
		SET_INFORMATION = 32,
		// Token: 0x04001CAB RID: 7339
		QUERY_INFORMATION = 64,
		// Token: 0x04001CAC RID: 7340
		SET_THREAD_TOKEN = 128,
		// Token: 0x04001CAD RID: 7341
		IMPERSONATE = 256,
		// Token: 0x04001CAE RID: 7342
		DIRECT_IMPERSONATION = 512
	}
}
