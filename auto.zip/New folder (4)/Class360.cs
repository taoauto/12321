﻿using System;

// Token: 0x020002A0 RID: 672
internal class Class360
{
	// Token: 0x17000796 RID: 1942
	// (get) Token: 0x060024B1 RID: 9393 RVA: 0x0001BCC9 File Offset: 0x00019EC9
	public static string String_0
	{
		get
		{
			return "Tô Châu";
		}
	}

	// Token: 0x04001894 RID: 6292
	public static int int_0 = 1;

	// Token: 0x04001895 RID: 6293
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 136U,
		Int32_0 = 293,
		Int32_1 = 229,
		Int32_2 = Class360.int_0,
		String_2 = "Chu Trọng Thanh"
	};

	// Token: 0x04001896 RID: 6294
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 24U,
		Int32_0 = 267,
		Int32_1 = 263,
		Int32_2 = Class360.int_0,
		String_2 = "Văn Ngạn Bác"
	};

	// Token: 0x04001897 RID: 6295
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 172U,
		Int32_0 = 200,
		Int32_1 = 334,
		Int32_2 = Class360.int_0,
		String_2 = "Độc Cô Hối"
	};

	// Token: 0x04001898 RID: 6296
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 54U,
		Int32_0 = 222,
		Int32_1 = 235,
		Int32_2 = Class360.int_0,
		String_2 = "Liễu Kim Thiềm"
	};

	// Token: 0x04001899 RID: 6297
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 147U,
		Int32_0 = 285,
		Int32_1 = 242,
		Int32_2 = Class360.int_0,
		String_2 = "Vu Thiên Thiên"
	};

	// Token: 0x0400189A RID: 6298
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 157U,
		Int32_0 = 282,
		Int32_1 = 276,
		Int32_2 = Class360.int_0,
		String_2 = "Lương Đạo Sĩ"
	};

	// Token: 0x0400189B RID: 6299
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 174U,
		Int32_0 = 363,
		Int32_1 = 243,
		Int32_2 = Class360.int_0,
		String_2 = "Mộ Bạch"
	};

	// Token: 0x0400189C RID: 6300
	public static Class424 class424_7 = new Class424
	{
		UInt32_0 = 155U,
		Int32_0 = 343,
		Int32_1 = 246,
		Int32_2 = Class360.int_0,
		String_2 = "Lương Hỏa Kế"
	};

	// Token: 0x0400189D RID: 6301
	public static Class424 class424_8 = new Class424
	{
		UInt32_0 = 157U,
		Int32_0 = 355,
		Int32_1 = 268,
		Int32_2 = Class360.int_0,
		String_2 = "Vân San San"
	};

	// Token: 0x0400189E RID: 6302
	public static Class424 class424_9 = new Class424
	{
		UInt32_0 = 169U,
		Int32_0 = 350,
		Int32_1 = 229,
		Int32_2 = Class360.int_0,
		String_2 = "Trương Sĩ Tâm"
	};

	// Token: 0x0400189F RID: 6303
	public static Class424 class424_10 = new Class424
	{
		UInt32_0 = 33U,
		Int32_0 = 351,
		Int32_1 = 204,
		Int32_2 = Class360.int_0,
		String_2 = "Hoa Kiếm Ảnh"
	};

	// Token: 0x040018A0 RID: 6304
	public static Class424 class424_11 = new Class424
	{
		UInt32_0 = 33U,
		Int32_0 = 354,
		Int32_1 = 203,
		Int32_2 = Class360.int_0,
		String_2 = "Hoa Kiếm Vũ"
	};

	// Token: 0x040018A1 RID: 6305
	public static Class424 class424_12 = new Class424
	{
		UInt32_0 = 159U,
		Int32_0 = 355,
		Int32_1 = 240,
		Int32_2 = Class360.int_0,
		String_2 = "Âu Dã Vu"
	};

	// Token: 0x040018A2 RID: 6306
	public static Class424 class424_13 = new Class424
	{
		UInt32_0 = 108U,
		Int32_0 = 355,
		Int32_1 = 234,
		Int32_2 = Class360.int_0,
		String_2 = "Âu Dã Tử"
	};

	// Token: 0x040018A3 RID: 6307
	public static Class424 class424_14 = new Class424
	{
		UInt32_0 = 139U,
		Int32_0 = 355,
		Int32_1 = 249,
		Int32_2 = Class360.int_0,
		String_2 = "Tiết Phi"
	};

	// Token: 0x040018A4 RID: 6308
	public static Class424 class424_15 = new Class424
	{
		UInt32_0 = 48U,
		Int32_0 = 351,
		Int32_1 = 250,
		Int32_2 = Class360.int_0,
		String_2 = "Tiết Chúc"
	};

	// Token: 0x040018A5 RID: 6309
	public static Class424 class424_16 = new Class424
	{
		UInt32_0 = 115U,
		Int32_0 = 224,
		Int32_1 = 226,
		Int32_2 = Class360.int_0,
		String_2 = "Ngô Giới"
	};

	// Token: 0x040018A6 RID: 6310
	public static Class424 class424_17 = new Class424
	{
		UInt32_0 = 3U,
		Int32_0 = 230,
		Int32_1 = 350,
		Int32_2 = Class360.int_0,
		String_2 = "Liễu Nguyệt Hồng"
	};

	// Token: 0x040018A7 RID: 6311
	public static Class424 class424_18 = new Class424
	{
		UInt32_0 = 163U,
		Int32_0 = 195,
		Int32_1 = 214,
		Int32_2 = Class360.int_0,
		String_2 = "Phan Thanh Thanh"
	};

	// Token: 0x040018A8 RID: 6312
	public static Class424 class424_19 = new Class424
	{
		UInt32_0 = 120U,
		Int32_0 = 342,
		Int32_1 = 311,
		Int32_2 = Class360.int_0,
		String_2 = "Hô Diên Báo"
	};

	// Token: 0x040018A9 RID: 6313
	public static Class424 class424_20 = new Class424
	{
		UInt32_0 = 121U,
		Int32_0 = 342,
		Int32_1 = 311,
		Int32_2 = Class360.int_0,
		String_2 = "Hồ Diên Báo"
	};

	// Token: 0x040018AA RID: 6314
	public static Class424 class424_21 = new Class424
	{
		UInt32_0 = 138U,
		Int32_0 = 134,
		Int32_1 = 260,
		Int32_2 = Class360.int_0,
		String_2 = "Tiền Hoành Vũ"
	};

	// Token: 0x040018AB RID: 6315
	public static Class424 class424_22 = new Class424
	{
		UInt32_0 = 19U,
		Int32_0 = 191,
		Int32_1 = 279,
		Int32_2 = Class360.int_0,
		String_2 = "Hầu bàn Tào"
	};

	// Token: 0x040018AC RID: 6316
	public static Class424 class424_23 = new Class424
	{
		UInt32_0 = 19U,
		Int32_0 = 185,
		Int32_1 = 279,
		Int32_2 = Class360.int_0,
		String_2 = "Hầu bàn Tào "
	};

	// Token: 0x040018AD RID: 6317
	public static Class424 class424_24 = new Class424
	{
		UInt32_0 = 47U,
		Int32_0 = 171,
		Int32_1 = 238,
		Int32_2 = Class360.int_0,
		String_2 = "Vân Phi Phi"
	};

	// Token: 0x040018AE RID: 6318
	public static Class424 class424_25 = new Class424
	{
		UInt32_0 = 156U,
		Int32_0 = 322,
		Int32_1 = 264,
		Int32_2 = Class360.int_0
	};

	// Token: 0x040018AF RID: 6319
	public static Class424 class424_26 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 166,
		Int32_1 = 311,
		Int32_2 = Class360.int_0,
		String_2 = "Tô Thức"
	};

	// Token: 0x040018B0 RID: 6320
	public static Class424 class424_27 = new Class424
	{
		UInt32_0 = 110U,
		Int32_0 = 131,
		Int32_1 = 261,
		Int32_2 = Class360.int_0,
		String_2 = "Tiền Hồng Vũ"
	};
}
