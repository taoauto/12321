﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200002D RID: 45
public class GClass17 : GClass16
{
	// Token: 0x170000AA RID: 170
	// (get) Token: 0x060001FB RID: 507 RVA: 0x00004517 File Offset: 0x00002717
	private static Random Random_0
	{
		get
		{
			if (GClass17.random_0 == null)
			{
				GClass17.random_0 = new Random();
			}
			return GClass17.random_0;
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x060001FC RID: 508 RVA: 0x0000452F File Offset: 0x0000272F
	// (set) Token: 0x060001FD RID: 509 RVA: 0x00004537 File Offset: 0x00002737
	public bool Boolean_0 { get; set; }

	// Token: 0x170000AC RID: 172
	// (get) Token: 0x060001FE RID: 510 RVA: 0x00004540 File Offset: 0x00002740
	public List<GClass16> List_0
	{
		get
		{
			return this.list_0;
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x060001FF RID: 511 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x06000200 RID: 512 RVA: 0x00004192 File Offset: 0x00002392
	public override string \u206A\u200F\u206E\u206E\u206F\u200F\u200E\u206C\u200E\u200C\u206D\u200B\u202A\u206C\u206B\u200D\u200D\u200C\u202E\u202A\u202C\u200E\u206D\u206D\u200C\u206A\u202B\u200E\u200D\u206B\u200C\u200B\u206C\u202C\u206E\u202A\u202C\u206C\u202C\u202E\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x06000201 RID: 513 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x06000202 RID: 514 RVA: 0x00004192 File Offset: 0x00002392
	public override int \u202E\u200D\u202E\u200E\u200F\u206F\u200D\u200F\u202A\u202D\u202D\u202A\u200B\u202C\u206D\u200D\u206B\u202E\u206A\u206F\u202A\u200C\u200B\u206A\u200E\u200E\u206E\u200D\u202B\u200F\u202C\u200F\u206E\u200E\u206E\u202A\u206A\u202C\u202E\u202A\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x06000203 RID: 515 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x06000204 RID: 516 RVA: 0x00004192 File Offset: 0x00002392
	public override string \u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x06000205 RID: 517 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x06000206 RID: 518 RVA: 0x00004192 File Offset: 0x00002392
	public override string \u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170000B1 RID: 177
	// (get) Token: 0x06000207 RID: 519 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x06000208 RID: 520 RVA: 0x00004192 File Offset: 0x00002392
	public override int \u202B\u206E\u206C\u200C\u200F\u202D\u206A\u206A\u206D\u200B\u200E\u200D\u206B\u206B\u202B\u200C\u200C\u206F\u200C\u206B\u200D\u202D\u206A\u200E\u202A\u200C\u206A\u200D\u202E\u202C\u206C\u206F\u206D\u200B\u200C\u202E\u206B\u206F\u202D\u200D\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170000B2 RID: 178
	// (get) Token: 0x06000209 RID: 521 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x0600020A RID: 522 RVA: 0x00004192 File Offset: 0x00002392
	public override int \u206B\u202B\u200B\u206F\u202A\u202D\u202E\u206B\u200D\u200D\u200F\u202B\u202B\u206E\u200F\u206E\u202C\u206C\u200E\u200E\u202E\u206C\u202B\u202E\u200C\u206A\u206B\u200E\u206D\u206F\u206D\u200E\u206F\u200C\u206F\u206B\u200B\u206E\u202E\u202B\u202E
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00004548 File Offset: 0x00002748
	public GClass17(bool bool_1 = false) : base(GEnum4.Chain)
	{
		this.Boolean_0 = bool_1;
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00026A9C File Offset: 0x00024C9C
	public override TcpClient \u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string string_3, int int_3, TcpClient tcpClient_0 = null)
	{
		if (this.list_0.Count == 0)
		{
			throw new InvalidOperationException(Class2.String_30);
		}
		List<GClass16> list;
		if (this.Boolean_0)
		{
			list = this.list_0.ToList<GClass16>();
			for (int i = 0; i < list.Count; i++)
			{
				int index = GClass17.Random_0.Next(list.Count);
				GClass16 value = list[i];
				list[i] = list[index];
				list[index] = value;
			}
		}
		else
		{
			list = this.list_0;
		}
		int num = list.Count - 1;
		TcpClient tcpClient_ = tcpClient_0;
		for (int j = 0; j < num; j++)
		{
			tcpClient_ = list[j].GClass16.\u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(list[j + 1].GClass16.\u206A\u200F\u206E\u206E\u206F\u200F\u200E\u206C\u200E\u200C\u206D\u200B\u202A\u206C\u206B\u200D\u200D\u200C\u202E\u202A\u202C\u200E\u206D\u206D\u200C\u206A\u202B\u200E\u200D\u206B\u200C\u200B\u206C\u202C\u206E\u202A\u202C\u206C\u202C\u202E\u202E, list[j + 1].GClass16.\u202E\u200D\u202E\u200E\u200F\u206F\u200D\u200F\u202A\u202D\u202D\u202A\u200B\u202C\u206D\u200D\u206B\u202E\u206A\u206F\u202A\u200C\u200B\u206A\u200E\u200E\u206E\u200D\u202B\u200F\u202C\u200F\u206E\u200E\u206E\u202A\u206A\u202C\u202E\u202A\u202E, tcpClient_);
		}
		return list[num].GClass16.\u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string_3, int_3, tcpClient_);
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00026B7C File Offset: 0x00024D7C
	public override string \u202B\u202E\u206A\u200C\u202B\u206D\u206F\u200E\u200D\u200C\u206F\u200E\u206F\u200F\u200F\u202B\u206E\u200C\u206B\u206E\u202C\u200B\u206F\u206E\u206C\u200D\u202C\u206C\u200B\u200F\u206D\u206C\u206C\u202A\u202B\u202A\u206E\u206E\u200D\u206B\u202E()
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (GClass16 gclass in this.list_0)
		{
			stringBuilder.AppendLine(gclass.ToString());
		}
		return stringBuilder.ToString();
	}

	// Token: 0x170000B3 RID: 179
	// (get) Token: 0x0600020E RID: 526 RVA: 0x00026BE4 File Offset: 0x00024DE4
	public string String_0
	{
		get
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (GClass16 gclass in this.list_0)
			{
				stringBuilder.AppendLine(gclass.vmethod_0());
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00004563 File Offset: 0x00002763
	public void method_3(GClass16 gclass16_0)
	{
		if (gclass16_0 == null)
		{
			throw new ArgumentNullException("proxy");
		}
		this.list_0.Add(gclass16_0);
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0000457F File Offset: 0x0000277F
	public void method_4(string string_3)
	{
		this.list_0.Add(GClass18.smethod_2(string_3));
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00004592 File Offset: 0x00002792
	public void method_5(string string_3)
	{
		this.list_0.Add(GClass19.smethod_2(string_3));
	}

	// Token: 0x06000212 RID: 530 RVA: 0x000045A5 File Offset: 0x000027A5
	public void method_6(string string_3)
	{
		this.list_0.Add(GClass20.smethod_4(string_3));
	}

	// Token: 0x06000213 RID: 531 RVA: 0x000045B8 File Offset: 0x000027B8
	public void method_7(string string_3)
	{
		this.list_0.Add(GClass21.smethod_2(string_3));
	}

	// Token: 0x0400012C RID: 300
	[ThreadStatic]
	private static Random random_0;

	// Token: 0x0400012D RID: 301
	private List<GClass16> list_0 = new List<GClass16>();

	// Token: 0x0400012E RID: 302
	[CompilerGenerated]
	private bool bool_0;
}
