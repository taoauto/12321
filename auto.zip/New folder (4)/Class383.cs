﻿using System;
using System.Runtime.CompilerServices;
using System.Text;
using System.Xml;

// Token: 0x020002BA RID: 698
internal class Class383
{
	// Token: 0x1700084F RID: 2127
	// (get) Token: 0x060026B9 RID: 9913 RVA: 0x0001CECE File Offset: 0x0001B0CE
	// (set) Token: 0x060026BA RID: 9914 RVA: 0x0001CED6 File Offset: 0x0001B0D6
	public XmlNode XmlNode_0 { get; set; }

	// Token: 0x060026BB RID: 9915 RVA: 0x0001CEDF File Offset: 0x0001B0DF
	public Class383()
	{
		this.XmlNode_0 = Class382.xmlDocument_0.CreateElement("Script");
	}

	// Token: 0x060026BC RID: 9916 RVA: 0x0001CEFC File Offset: 0x0001B0FC
	public Class383(XmlNode xmlNode_1)
	{
		this.XmlNode_0 = xmlNode_1;
	}

	// Token: 0x17000850 RID: 2128
	// (get) Token: 0x060026BD RID: 9917 RVA: 0x00115D74 File Offset: 0x00113F74
	// (set) Token: 0x060026BE RID: 9918 RVA: 0x00115DB8 File Offset: 0x00113FB8
	public string String_0
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["ID"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["ID"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("ID");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000851 RID: 2129
	// (get) Token: 0x060026BF RID: 9919 RVA: 0x00115E20 File Offset: 0x00114020
	// (set) Token: 0x060026C0 RID: 9920 RVA: 0x00115EB8 File Offset: 0x001140B8
	public string String_1
	{
		get
		{
			if (this.String_6.Contains("Thiên sư kỳ đãi"))
			{
				try
				{
					return (Class426.smethod_43(this.XmlNode_0.Attributes["Level"].Value) + 5).ToString();
				}
				catch
				{
				}
				return "";
			}
			try
			{
				return this.XmlNode_0.Attributes["Level"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Level"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Level");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000852 RID: 2130
	// (get) Token: 0x060026C1 RID: 9921 RVA: 0x00115F20 File Offset: 0x00114120
	// (set) Token: 0x060026C2 RID: 9922 RVA: 0x00115F64 File Offset: 0x00114164
	public string String_2
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["InfoEx"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["InfoEx"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("InfoEx");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000853 RID: 2131
	// (get) Token: 0x060026C3 RID: 9923 RVA: 0x00115FCC File Offset: 0x001141CC
	// (set) Token: 0x060026C4 RID: 9924 RVA: 0x00116010 File Offset: 0x00114210
	public string String_3
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["MD"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["MD"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("MD");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000854 RID: 2132
	// (get) Token: 0x060026C5 RID: 9925 RVA: 0x00116078 File Offset: 0x00114278
	// (set) Token: 0x060026C6 RID: 9926 RVA: 0x00116110 File Offset: 0x00114310
	public string String_4
	{
		get
		{
			if (this.Boolean_2)
			{
				return "[Completed]";
			}
			if (this.Boolean_7)
			{
				return "[BienThan]";
			}
			if (this.Boolean_1)
			{
				return "[IsComplete]";
			}
			if (this.String_8 != "0")
			{
				return "[IsCollect]";
			}
			if (this.Boolean_3)
			{
				return "[UseItem]";
			}
			try
			{
				return this.XmlNode_0.Attributes["Monter"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Monter"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Monter");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000855 RID: 2133
	// (get) Token: 0x060026C7 RID: 9927 RVA: 0x00116178 File Offset: 0x00114378
	public string String_5
	{
		get
		{
			string result;
			try
			{
				result = Class426.smethod_64(this.String_13.Split(new char[]
				{
					':'
				})[0]).Replace(" ", "");
			}
			catch
			{
				result = "";
			}
			return result;
		}
	}

	// Token: 0x17000856 RID: 2134
	// (get) Token: 0x060026C8 RID: 9928 RVA: 0x001161D0 File Offset: 0x001143D0
	// (set) Token: 0x060026C9 RID: 9929 RVA: 0x00116244 File Offset: 0x00114444
	public string String_6
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["Name"].Value;
			}
			catch
			{
			}
			XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Name");
			xmlAttribute.Value = "";
			this.XmlNode_0.Attributes.Append(xmlAttribute);
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Name"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Name");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000857 RID: 2135
	// (get) Token: 0x060026CA RID: 9930 RVA: 0x001162AC File Offset: 0x001144AC
	// (set) Token: 0x060026CB RID: 9931 RVA: 0x001162F0 File Offset: 0x001144F0
	public string String_7
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["Recv"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Recv"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Recv");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000858 RID: 2136
	// (get) Token: 0x060026CC RID: 9932 RVA: 0x00116358 File Offset: 0x00114558
	public Class424 Class424_0
	{
		get
		{
			Class424 @class = new Class424();
			if (this.String_7.Length == 12)
			{
				@class.UInt32_0 = (uint)Class405.smethod_0(this.String_7.Substring(0, 3));
				@class.Int32_0 = Class405.smethod_0(this.String_7.Substring(3, 3));
				@class.Int32_1 = Class405.smethod_0(this.String_7.Substring(6, 3));
				@class.Int32_2 = Class405.smethod_0(this.String_7.Substring(9, 3));
				if (@class.Int32_2 == 0)
				{
					@class.Int32_2 = Class352.int_0;
				}
			}
			return @class;
		}
	}

	// Token: 0x17000859 RID: 2137
	// (get) Token: 0x060026CD RID: 9933 RVA: 0x001163F0 File Offset: 0x001145F0
	public Class424 Class424_1
	{
		get
		{
			Class424 @class = new Class424();
			if (this.String_12.Length >= 18)
			{
				@class.String_1 = this.String_12.Substring(6, 3);
				@class.Int32_0 = Class405.smethod_0(this.String_12.Substring(9, 3));
				@class.Int32_1 = Class405.smethod_0(this.String_12.Substring(12, 3));
				@class.Int32_2 = Class405.smethod_0(this.String_12.Substring(15, 3));
				if (@class.Int32_2 == 0)
				{
					@class.Int32_2 = Class352.int_0;
				}
			}
			return @class;
		}
	}

	// Token: 0x1700085A RID: 2138
	// (get) Token: 0x060026CE RID: 9934 RVA: 0x00116484 File Offset: 0x00114684
	public Class424 Class424_2
	{
		get
		{
			Class424 @class = new Class424();
			if (this.String_12.Length >= 30)
			{
				@class.String_1 = this.String_12.Substring(18, 3);
				@class.Int32_0 = Class405.smethod_0(this.String_12.Substring(21, 3));
				@class.Int32_1 = Class405.smethod_0(this.String_12.Substring(24, 3));
				@class.Int32_2 = Class405.smethod_0(this.String_12.Substring(27, 3));
				if (@class.Int32_2 == 0)
				{
					@class.Int32_2 = Class352.int_0;
				}
			}
			return @class;
		}
	}

	// Token: 0x1700085B RID: 2139
	// (get) Token: 0x060026CF RID: 9935 RVA: 0x0011651C File Offset: 0x0011471C
	public Class424 Class424_3
	{
		get
		{
			Class424 @class = new Class424();
			if (this.String_12.Length >= 42)
			{
				@class.String_1 = this.String_12.Substring(30, 3);
				@class.Int32_0 = Class405.smethod_0(this.String_12.Substring(33, 3));
				@class.Int32_1 = Class405.smethod_0(this.String_12.Substring(36, 3));
				@class.Int32_2 = Class405.smethod_0(this.String_12.Substring(39, 3));
				if (@class.Int32_2 == 0)
				{
					@class.Int32_2 = Class352.int_0;
				}
			}
			return @class;
		}
	}

	// Token: 0x1700085C RID: 2140
	// (get) Token: 0x060026D0 RID: 9936 RVA: 0x0001CF0B File Offset: 0x0001B10B
	public bool Boolean_0
	{
		get
		{
			return this.String_12.Length >= 43 && this.String_12[42] == '1';
		}
	}

	// Token: 0x1700085D RID: 2141
	// (get) Token: 0x060026D1 RID: 9937 RVA: 0x001165B4 File Offset: 0x001147B4
	// (set) Token: 0x060026D2 RID: 9938 RVA: 0x001165EC File Offset: 0x001147EC
	public string String_8
	{
		get
		{
			if (this.String_12.Length >= 44)
			{
				return this.String_12[43].ToString();
			}
			return "0";
		}
		set
		{
			if (this.String_12.Length >= 44)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				stringBuilder[43] = value.ToString()[0];
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x1700085E RID: 2142
	// (get) Token: 0x060026D3 RID: 9939 RVA: 0x0001CF2F File Offset: 0x0001B12F
	// (set) Token: 0x060026D4 RID: 9940 RVA: 0x00116634 File Offset: 0x00114834
	public bool Boolean_1
	{
		get
		{
			return this.String_12.Length >= 45 && this.String_12[44] == '1';
		}
		set
		{
			if (this.String_12.Length >= 45)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[44] = '1';
				}
				else
				{
					stringBuilder[44] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x1700085F RID: 2143
	// (get) Token: 0x060026D5 RID: 9941 RVA: 0x0001CF53 File Offset: 0x0001B153
	// (set) Token: 0x060026D6 RID: 9942 RVA: 0x00116684 File Offset: 0x00114884
	public bool Boolean_2
	{
		get
		{
			return this.String_12.Length >= 46 && this.String_12[45] == '1';
		}
		set
		{
			if (this.String_12.Length >= 46)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[45] = '1';
				}
				else
				{
					stringBuilder[45] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000860 RID: 2144
	// (get) Token: 0x060026D7 RID: 9943 RVA: 0x0001CF77 File Offset: 0x0001B177
	// (set) Token: 0x060026D8 RID: 9944 RVA: 0x001166D4 File Offset: 0x001148D4
	public bool Boolean_3
	{
		get
		{
			return this.String_12.Length >= 47 && this.String_12[46] == '1';
		}
		set
		{
			if (this.String_12.Length >= 47)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[46] = '1';
				}
				else
				{
					stringBuilder[46] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000861 RID: 2145
	// (get) Token: 0x060026D9 RID: 9945 RVA: 0x00116724 File Offset: 0x00114924
	// (set) Token: 0x060026DA RID: 9946 RVA: 0x00116760 File Offset: 0x00114960
	public int Int32_0
	{
		get
		{
			if (this.String_12.Length >= 48)
			{
				return Class426.smethod_43(this.String_12[47].ToString()) - 1;
			}
			return -1;
		}
		set
		{
			if (this.String_12.Length >= 48)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				stringBuilder[47] = value.ToString()[0];
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000862 RID: 2146
	// (get) Token: 0x060026DB RID: 9947 RVA: 0x001167AC File Offset: 0x001149AC
	// (set) Token: 0x060026DC RID: 9948 RVA: 0x001167E8 File Offset: 0x001149E8
	public int Int32_1
	{
		get
		{
			if (this.String_12.Length >= 49)
			{
				return Class426.smethod_43(this.String_12[48].ToString()) - 1;
			}
			return -1;
		}
		set
		{
			if (this.String_12.Length >= 49)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				stringBuilder[48] = value.ToString()[0];
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000863 RID: 2147
	// (get) Token: 0x060026DD RID: 9949 RVA: 0x0001CF9B File Offset: 0x0001B19B
	// (set) Token: 0x060026DE RID: 9950 RVA: 0x00116834 File Offset: 0x00114A34
	public bool Boolean_4
	{
		get
		{
			return this.String_12.Length >= 50 && this.String_12[49] == '1';
		}
		set
		{
			if (this.String_12.Length >= 50)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[49] = '1';
				}
				else
				{
					stringBuilder[49] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000864 RID: 2148
	// (get) Token: 0x060026DF RID: 9951 RVA: 0x0001CFBF File Offset: 0x0001B1BF
	// (set) Token: 0x060026E0 RID: 9952 RVA: 0x00116884 File Offset: 0x00114A84
	public bool Boolean_5
	{
		get
		{
			return this.String_12.Length >= 51 && this.String_12[50] == '1';
		}
		set
		{
			if (this.String_12.Length >= 51)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[50] = '1';
				}
				else
				{
					stringBuilder[50] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000865 RID: 2149
	// (get) Token: 0x060026E1 RID: 9953 RVA: 0x001168D4 File Offset: 0x00114AD4
	// (set) Token: 0x060026E2 RID: 9954 RVA: 0x00116920 File Offset: 0x00114B20
	public bool Boolean_6
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["BienThan"].Value == "True";
			}
			catch
			{
			}
			return false;
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["BienThan"].Value = value.ToString();
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("BienThan");
				xmlAttribute.Value = value.ToString();
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000866 RID: 2150
	// (get) Token: 0x060026E3 RID: 9955 RVA: 0x0001CFE3 File Offset: 0x0001B1E3
	// (set) Token: 0x060026E4 RID: 9956 RVA: 0x00116994 File Offset: 0x00114B94
	public bool Boolean_7
	{
		get
		{
			return this.String_12.Length >= 52 && this.String_12[51] == '1';
		}
		set
		{
			if (this.String_12.Length >= 52)
			{
				StringBuilder stringBuilder = new StringBuilder(this.String_12);
				if (value)
				{
					stringBuilder[51] = '1';
				}
				else
				{
					stringBuilder[51] = '0';
				}
				this.String_12 = stringBuilder.ToString();
			}
		}
	}

	// Token: 0x17000867 RID: 2151
	// (get) Token: 0x060026E5 RID: 9957 RVA: 0x001169E4 File Offset: 0x00114BE4
	// (set) Token: 0x060026E6 RID: 9958 RVA: 0x00116A28 File Offset: 0x00114C28
	public string String_9
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["Send"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Send"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Send");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x17000868 RID: 2152
	// (get) Token: 0x060026E7 RID: 9959 RVA: 0x00116A90 File Offset: 0x00114C90
	public Class424 Class424_4
	{
		get
		{
			Class424 @class = new Class424();
			if (this.String_9.Length == 12)
			{
				@class.UInt32_0 = (uint)Class405.smethod_0(this.String_9.Substring(0, 3));
				@class.Int32_0 = Class405.smethod_0(this.String_9.Substring(3, 3));
				@class.Int32_1 = Class405.smethod_0(this.String_9.Substring(6, 3));
				@class.Int32_2 = Class405.smethod_0(this.String_9.Substring(9, 3));
				if (@class.Int32_2 == 0)
				{
					@class.Int32_2 = Class352.int_0;
				}
			}
			return @class;
		}
	}

	// Token: 0x17000869 RID: 2153
	// (get) Token: 0x060026E8 RID: 9960 RVA: 0x0001D007 File Offset: 0x0001B207
	public string String_10
	{
		get
		{
			if (this.String_12.Length >= 6)
			{
				return this.String_12.Substring(3, 3);
			}
			return "000";
		}
	}

	// Token: 0x060026E9 RID: 9961 RVA: 0x00116B28 File Offset: 0x00114D28
	public bool method_0(Class389 class389_0)
	{
		return !(class389_0.string_0.Trim() == string.Empty) && (this.String_10 == class389_0.String_0 || this.String_11 == class389_0.String_0 || this.String_6.Contains(class389_0.string_0) || Class426.smethod_57(this.String_6) == Class426.smethod_57(class389_0.string_0) || (this.String_6 == "Quả Ngân Võ Lâm Ấn Bang HộiBuôn Bán" && class389_0.string_0 == "Quả Ngân Võ Lâm Ấn Kiếm Tiền") || this.String_6 == "#{YD_100806_58}");
	}

	// Token: 0x1700086A RID: 2154
	// (get) Token: 0x060026EA RID: 9962 RVA: 0x0001D02A File Offset: 0x0001B22A
	public string String_11
	{
		get
		{
			if (this.String_12.Length >= 3)
			{
				return this.String_12.Substring(0, 3);
			}
			return "000";
		}
	}

	// Token: 0x1700086B RID: 2155
	// (get) Token: 0x060026EB RID: 9963 RVA: 0x00116BE8 File Offset: 0x00114DE8
	// (set) Token: 0x060026EC RID: 9964 RVA: 0x00116C2C File Offset: 0x00114E2C
	public string String_12
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["Do"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Do"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Do");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x1700086C RID: 2156
	// (get) Token: 0x060026ED RID: 9965 RVA: 0x00116C94 File Offset: 0x00114E94
	// (set) Token: 0x060026EE RID: 9966 RVA: 0x00116CD8 File Offset: 0x00114ED8
	public string String_13
	{
		get
		{
			try
			{
				return this.XmlNode_0.Attributes["Info"].Value;
			}
			catch
			{
			}
			return "";
		}
		set
		{
			try
			{
				this.XmlNode_0.Attributes["Info"].Value = value;
			}
			catch
			{
				XmlAttribute xmlAttribute = Class382.xmlDocument_0.CreateAttribute("Info");
				xmlAttribute.Value = value;
				this.XmlNode_0.Attributes.Append(xmlAttribute);
			}
		}
	}

	// Token: 0x04001A8A RID: 6794
	[CompilerGenerated]
	private XmlNode xmlNode_0;
}
