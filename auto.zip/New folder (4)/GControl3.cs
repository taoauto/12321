﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000134 RID: 308
[ToolboxItem(false)]
public class GControl3 : UserControl
{
	// Token: 0x17000400 RID: 1024
	// (get) Token: 0x06000F88 RID: 3976 RVA: 0x0000CE37 File Offset: 0x0000B037
	// (set) Token: 0x06000F89 RID: 3977 RVA: 0x0000CE3F File Offset: 0x0000B03F
	public Color Color_0 { get; set; }

	// Token: 0x17000401 RID: 1025
	// (get) Token: 0x06000F8A RID: 3978 RVA: 0x0000CE48 File Offset: 0x0000B048
	// (set) Token: 0x06000F8B RID: 3979 RVA: 0x0000CE50 File Offset: 0x0000B050
	public Color Color_1 { get; set; }

	// Token: 0x17000402 RID: 1026
	// (get) Token: 0x06000F8C RID: 3980 RVA: 0x0000CE59 File Offset: 0x0000B059
	// (set) Token: 0x06000F8D RID: 3981 RVA: 0x0000CE61 File Offset: 0x0000B061
	public string String_0 { get; set; }

	// Token: 0x17000403 RID: 1027
	// (get) Token: 0x06000F8E RID: 3982 RVA: 0x0000CE6A File Offset: 0x0000B06A
	// (set) Token: 0x06000F8F RID: 3983 RVA: 0x0000CE72 File Offset: 0x0000B072
	public StringAlignment StringAlignment_0 { get; set; }

	// Token: 0x06000F90 RID: 3984 RVA: 0x0000CE7B File Offset: 0x0000B07B
	public GControl3()
	{
		base.SetStyle(ControlStyles.Selectable, false);
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
	}

	// Token: 0x06000F91 RID: 3985 RVA: 0x000590D8 File Offset: 0x000572D8
	protected virtual void OnPaint(PaintEventArgs e)
	{
		using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(base.ClientRectangle, this.Color_0, this.BackColor, 90f))
		{
			e.Graphics.FillRectangle(linearGradientBrush, 0, 0, base.ClientSize.Width - 1, base.ClientSize.Height - 1);
		}
		using (Pen pen = new Pen(this.Color_1))
		{
			e.Graphics.DrawRectangle(pen, 0, 0, base.ClientSize.Width - 1, base.ClientSize.Height - 1);
		}
		if (!string.IsNullOrEmpty(this.String_0))
		{
			StringFormat stringFormat = new StringFormat();
			stringFormat.Alignment = this.StringAlignment_0;
			stringFormat.LineAlignment = StringAlignment.Center;
			using (SolidBrush solidBrush = new SolidBrush(this.ForeColor))
			{
				e.Graphics.DrawString(this.String_0, this.Font, solidBrush, new RectangleF(1f, 1f, (float)(base.ClientSize.Width - 2), (float)(base.ClientSize.Height - 2)), stringFormat);
			}
		}
	}

	// Token: 0x04000800 RID: 2048
	[CompilerGenerated]
	private Color color_0;

	// Token: 0x04000801 RID: 2049
	[CompilerGenerated]
	private Color color_1;

	// Token: 0x04000802 RID: 2050
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000803 RID: 2051
	[CompilerGenerated]
	private StringAlignment stringAlignment_0;
}
