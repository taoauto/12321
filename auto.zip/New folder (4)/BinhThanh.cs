﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000169 RID: 361
internal class BinhThanh : UserControl
{
	// Token: 0x06001181 RID: 4481 RVA: 0x0000E05D File Offset: 0x0000C25D
	public BinhThanh(Class234 class234_1)
	{
		this.class234_0 = class234_1;
		this.InitializeComponent();
	}

	// Token: 0x06001182 RID: 4482 RVA: 0x0005F364 File Offset: 0x0005D564
	private void BinhThanh_Load(object sender, EventArgs e)
	{
		if (!Class268.Boolean_1)
		{
			this.CheckBox_0.Enabled = false;
		}
		int num = 51;
		List<string> list = new List<string>();
		list.Add(num.ToString() + "," + (54 + 3).ToString());
		list.Add(num.ToString() + "," + (54 + 6).ToString());
		list.Add(num.ToString() + "," + (54 - 3).ToString());
		list.Add(num.ToString() + "," + (54 - 6).ToString());
		list.Add((num - 3).ToString() + "," + (54 + 3).ToString());
		list.Add((num - 3).ToString() + "," + (54 + 6).ToString());
		list.Add((num - 3).ToString() + "," + (54 - 3).ToString());
		list.Add((num - 3).ToString() + "," + (54 - 6).ToString());
		list.Add((num + 3).ToString() + "," + (54 + 3).ToString());
		list.Add((num + 3).ToString() + "," + (54 + 6).ToString());
		list.Add((num + 3).ToString() + "," + (54 - 3).ToString());
		list.Add((num + 3).ToString() + "," + (54 - 6).ToString());
		int num2 = 0;
		foreach (Class159 @class in this.class234_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.Class432_0.String_2);
			listViewItem.Tag = @class;
			listViewItem.SubItems.Add(list[num2]);
			this.listViewEx1.Items.Add(listViewItem);
			num2++;
		}
		this.listViewEx1.Columns[0].Text = "Name [" + this.listViewEx1.Items.Count.ToString() + "]";
		foreach (Class159 class2 in this.class234_0.IEnumerable_1)
		{
			ListViewItem listViewItem2 = new ListViewItem(class2.Class432_0.String_2);
			listViewItem2.Tag = class2;
			listViewItem2.SubItems.Add(list[num2]);
			this.listViewEx2.Items.Add(listViewItem2);
			num2++;
		}
		this.listViewEx2.Columns[0].Text = "Name [" + this.listViewEx2.Items.Count.ToString() + "]";
		this.btn1_Click(null, null);
	}

	// Token: 0x06001183 RID: 4483 RVA: 0x0005F700 File Offset: 0x0005D900
	private void btn3_Click(object sender, EventArgs e)
	{
		this.int_0 = 3;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "134,110";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "142,64";
		}
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x0005F7DC File Offset: 0x0005D9DC
	private void method_0(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "173,100";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "174,36";
		}
	}

	// Token: 0x06001185 RID: 4485 RVA: 0x0005F8B4 File Offset: 0x0005DAB4
	private void btn4_Click(object sender, EventArgs e)
	{
		this.int_0 = 4;
		this.listViewEx1.Items.Clear();
		this.listViewEx2.Items.Clear();
		List<string> list = new List<string>();
		list.Add("178,103");
		list.Add("172,94");
		list.Add("167,97");
		list.Add("167,103");
		list.Add("179,95");
		list.Add("173,105");
		list.Add("174,43");
		list.Add("180,37");
		list.Add("179,32");
		list.Add("168,34");
		list.Add("172,30");
		list.Add("170,41");
		int num = 0;
		foreach (Class159 @class in this.class234_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.Class432_0.String_2);
			listViewItem.Tag = @class;
			listViewItem.SubItems.Add(list[num]);
			this.listViewEx1.Items.Add(listViewItem);
			num++;
		}
		foreach (Class159 class2 in this.class234_0.IEnumerable_1)
		{
			ListViewItem listViewItem2 = new ListViewItem(class2.Class432_0.String_2);
			listViewItem2.Tag = class2;
			listViewItem2.SubItems.Add(list[num]);
			this.listViewEx2.Items.Add(listViewItem2);
			num++;
		}
	}

	// Token: 0x06001186 RID: 4486 RVA: 0x0005FA7C File Offset: 0x0005DC7C
	private void btn5_Click(object sender, EventArgs e)
	{
		this.int_0 = 5;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "203,134";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "203,134";
		}
	}

	// Token: 0x06001187 RID: 4487 RVA: 0x0005FB58 File Offset: 0x0005DD58
	private void btn6_Click(object sender, EventArgs e)
	{
		this.int_0 = 6;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "191,195";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "191,195";
		}
	}

	// Token: 0x06001188 RID: 4488 RVA: 0x0005FC34 File Offset: 0x0005DE34
	private void btn1_Click(object sender, EventArgs e)
	{
		this.int_0 = 1;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "65,90";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "65,90";
		}
	}

	// Token: 0x06001189 RID: 4489 RVA: 0x0005FD10 File Offset: 0x0005DF10
	private void btn2_Click(object sender, EventArgs e)
	{
		this.int_0 = 2;
		this.listViewEx1.Items.Clear();
		this.listViewEx2.Items.Clear();
		List<string> list = new List<string>();
		int num = 51;
		list.Add(num.ToString() + "," + (54 + 2).ToString());
		list.Add(num.ToString() + "," + (54 + 6).ToString());
		list.Add(num.ToString() + "," + (54 - 2).ToString());
		list.Add(num.ToString() + "," + (54 - 6).ToString());
		list.Add((num - 3).ToString() + "," + (54 + 2).ToString());
		list.Add((num - 3).ToString() + "," + (54 + 6).ToString());
		list.Add((num - 3).ToString() + "," + (54 - 2).ToString());
		list.Add((num - 3).ToString() + "," + (54 - 6).ToString());
		list.Add((num + 3).ToString() + "," + (54 + 2).ToString());
		list.Add((num + 3).ToString() + "," + (54 + 6).ToString());
		list.Add((num + 3).ToString() + "," + (54 - 2).ToString());
		list.Add((num + 3).ToString() + "," + (54 - 6).ToString());
		int num2 = 0;
		foreach (Class159 @class in this.class234_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.Class432_0.String_2);
			listViewItem.Tag = @class;
			listViewItem.SubItems.Add(list[num2]);
			this.listViewEx1.Items.Add(listViewItem);
			num2++;
		}
		foreach (Class159 class2 in this.class234_0.IEnumerable_1)
		{
			ListViewItem listViewItem2 = new ListViewItem(class2.Class432_0.String_2);
			listViewItem2.Tag = class2;
			listViewItem2.SubItems.Add(list[num2]);
			this.listViewEx2.Items.Add(listViewItem2);
			num2++;
		}
	}

	// Token: 0x0600118A RID: 4490 RVA: 0x0006003C File Offset: 0x0005E23C
	private void method_1(object sender, EventArgs e)
	{
		this.listViewEx1.Items.Clear();
		this.listViewEx2.Items.Clear();
		List<string> list = new List<string>();
		list.Add("190,195");
		list.Add("194,195");
		list.Add("186,195");
		list.Add("198,195");
		list.Add("190,190");
		list.Add("194,190");
		list.Add("186,190");
		list.Add("198,190");
		list.Add("190,200");
		list.Add("194,200");
		list.Add("186,200");
		list.Add("198,200");
		int num = 0;
		foreach (Class159 @class in this.class234_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.Class432_0.String_2);
			listViewItem.Tag = @class;
			listViewItem.SubItems.Add(list[num]);
			this.listViewEx1.Items.Add(listViewItem);
			num++;
		}
		foreach (Class159 class2 in this.class234_0.IEnumerable_1)
		{
			ListViewItem listViewItem2 = new ListViewItem(class2.Class432_0.String_2);
			listViewItem2.Tag = class2;
			listViewItem2.SubItems.Add(list[num]);
			this.listViewEx2.Items.Add(listViewItem2);
			num++;
		}
	}

	// Token: 0x0600118B RID: 4491 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_2(object sender, EventArgs e)
	{
	}

	// Token: 0x0600118C RID: 4492 RVA: 0x000601FC File Offset: 0x0005E3FC
	private void btn7_Click(object sender, EventArgs e)
	{
		this.int_0 = 7;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "142,178";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "142,178";
		}
	}

	// Token: 0x0600118D RID: 4493 RVA: 0x000602D8 File Offset: 0x0005E4D8
	private void btn8_Click(object sender, EventArgs e)
	{
		this.int_0 = 8;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			object tag = listViewItem.Tag;
			listViewItem.SubItems[1].Text = "53,203";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			object tag2 = listViewItem2.Tag;
			listViewItem2.SubItems[1].Text = "53,203";
		}
	}

	// Token: 0x0600118E RID: 4494 RVA: 0x0000E07D File Offset: 0x0000C27D
	private void listViewEx1_DoubleClick(object sender, EventArgs e)
	{
		if (this.listViewEx1.SelectedItems.Count == 0)
		{
			return;
		}
		((Class159)this.listViewEx1.SelectedItems[0].Tag).method_223();
	}

	// Token: 0x0600118F RID: 4495 RVA: 0x0000E0B2 File Offset: 0x0000C2B2
	private void listViewEx2_DoubleClick(object sender, EventArgs e)
	{
		if (this.listViewEx2.SelectedItems.Count == 0)
		{
			return;
		}
		((Class159)this.listViewEx2.SelectedItems[0].Tag).method_223();
	}

	// Token: 0x06001190 RID: 4496 RVA: 0x000603B4 File Offset: 0x0005E5B4
	private void button11_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			(((ListViewItem)obj).Tag as Class159).method_272();
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			(((ListViewItem)obj2).Tag as Class159).method_272();
		}
	}

	// Token: 0x06001191 RID: 4497 RVA: 0x00060470 File Offset: 0x0005E670
	private void button12_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			(((ListViewItem)obj).Tag as Class159).method_270();
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			(((ListViewItem)obj2).Tag as Class159).method_270();
		}
	}

	// Token: 0x06001192 RID: 4498 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_3(object sender, EventArgs e)
	{
	}

	// Token: 0x06001193 RID: 4499 RVA: 0x0006052C File Offset: 0x0005E72C
	private void method_4(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			Class159 @class = listViewItem.Tag as Class159;
			if (this.int_1 == 0)
			{
				@class.list_4.Clear();
			}
			if (listViewItem.SubItems[1].Text == "Cao Dương")
			{
				@class.method_238((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2);
			}
			else if (listViewItem.SubItems[1].Text == "142,178")
			{
				@class.method_235(listViewItem.SubItems[1].Text);
			}
			else
			{
				@class.method_235(listViewItem.SubItems[1].Text);
			}
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			Class159 class2 = listViewItem2.Tag as Class159;
			if (this.int_1 == 0)
			{
				class2.list_4.Clear();
			}
			if (listViewItem2.SubItems[1].Text == "Cao Dương")
			{
				class2.method_238((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2);
			}
			else if (listViewItem2.SubItems[1].Text == "142,178")
			{
				class2.method_235(listViewItem2.SubItems[1].Text);
			}
			else
			{
				class2.method_235(listViewItem2.SubItems[1].Text);
			}
		}
	}

	// Token: 0x06001194 RID: 4500 RVA: 0x00060744 File Offset: 0x0005E944
	private void method_5(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			Class159 @class = listViewItem.Tag as Class159;
			if (this.int_1 == 0)
			{
				@class.list_4.Clear();
			}
			if (listViewItem.SubItems[1].Text == "Cao Dương")
			{
				@class.method_70((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2, false, 3f, 30f);
			}
			else if (listViewItem.SubItems[1].Text == "142,178")
			{
				@class.method_67(listViewItem.SubItems[1].Text);
			}
			else
			{
				@class.method_67(listViewItem.SubItems[1].Text);
			}
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj2;
			Class159 class2 = listViewItem2.Tag as Class159;
			if (this.int_1 == 0)
			{
				class2.list_4.Clear();
			}
			if (listViewItem2.SubItems[1].Text == "Cao Dương")
			{
				class2.method_70((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2, false, 3f, 30f);
			}
			else if (listViewItem2.SubItems[1].Text == "142,178")
			{
				class2.method_67(listViewItem2.SubItems[1].Text);
			}
			else
			{
				class2.method_67(listViewItem2.SubItems[1].Text);
			}
		}
	}

	// Token: 0x06001195 RID: 4501 RVA: 0x00002E18 File Offset: 0x00001018
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x170004A4 RID: 1188
	// (get) Token: 0x06001196 RID: 4502 RVA: 0x0000E0E7 File Offset: 0x0000C2E7
	// (set) Token: 0x06001197 RID: 4503 RVA: 0x0000E0EF File Offset: 0x0000C2EF
	private CheckBox CheckBox_0 { get; set; } = new CheckBox();

	// Token: 0x06001198 RID: 4504 RVA: 0x00060978 File Offset: 0x0005EB78
	private void timer_0_Tick(object sender, EventArgs e)
	{
		bool flag = false;
		bool flag2 = true;
		using (IEnumerator enumerator = this.listViewEx1.Items.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if ((((ListViewItem)enumerator.Current).Tag as Class159).method_122(109f, 202f) >= 8f)
				{
					flag2 = false;
				}
			}
		}
		using (IEnumerator enumerator = this.listViewEx2.Items.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if ((((ListViewItem)enumerator.Current).Tag as Class159).method_122(109f, 202f) >= 8f)
				{
					flag2 = false;
				}
			}
		}
		if (flag2 && this.CheckBox_0.Checked)
		{
			this.int_0 = 8;
			if (this.int_0 == 8)
			{
				foreach (object obj in this.listViewEx1.Items)
				{
					ListViewItem listViewItem = (ListViewItem)obj;
					object tag = listViewItem.Tag;
					listViewItem.SubItems[1].Text = "53,203";
				}
				foreach (object obj2 in this.listViewEx2.Items)
				{
					ListViewItem listViewItem2 = (ListViewItem)obj2;
					object tag2 = listViewItem2.Tag;
					listViewItem2.SubItems[1].Text = "53,203";
				}
				this.checkBox1.Checked = true;
			}
		}
		using (IEnumerator enumerator = this.listViewEx1.Items.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if ((((ListViewItem)enumerator.Current).Tag as Class159).Class394_0.method_3(20f, -1f, -1f).Count > 0)
				{
					flag = true;
				}
			}
		}
		using (IEnumerator enumerator = this.listViewEx2.Items.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if ((((ListViewItem)enumerator.Current).Tag as Class159).Class394_0.method_3(20f, -1f, -1f).Count > 0)
				{
					flag = true;
				}
			}
		}
		if (this.checkBox1.Checked)
		{
			foreach (object obj3 in this.listViewEx1.Items)
			{
				ListViewItem listViewItem3 = (ListViewItem)obj3;
				Class159 @class = listViewItem3.Tag as Class159;
				if (listViewItem3.SubItems[1].Text == "Cao Dương")
				{
					if (@class.method_70((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2, false, 3f, 30f) && flag)
					{
						@class.method_272();
					}
				}
				else
				{
					@class.method_67(listViewItem3.SubItems[1].Text);
				}
			}
			using (IEnumerator enumerator = this.listViewEx2.Items.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object obj4 = enumerator.Current;
					ListViewItem listViewItem4 = (ListViewItem)obj4;
					Class159 class2 = listViewItem4.Tag as Class159;
					if (listViewItem4.SubItems[1].Text == "Cao Dương")
					{
						if (!class2.method_70((float)Class353.class424_1.Int32_0, (float)Class353.class424_1.Int32_1, Class353.class424_1.Int32_2, false, 3f, 30f))
						{
						}
					}
					else if (class2.method_67(listViewItem4.SubItems[1].Text) && flag)
					{
						class2.method_272();
					}
				}
				return;
			}
		}
		if (this.CheckBox_0.Checked)
		{
			foreach (object obj5 in this.listViewEx1.Items)
			{
				Class159 class3 = ((ListViewItem)obj5).Tag as Class159;
				if (flag)
				{
					class3.method_272();
				}
			}
			foreach (object obj6 in this.listViewEx2.Items)
			{
				Class159 class4 = ((ListViewItem)obj6).Tag as Class159;
				if (flag)
				{
					class4.method_272();
				}
			}
		}
	}

	// Token: 0x06001199 RID: 4505 RVA: 0x0000E0F8 File Offset: 0x0000C2F8
	private void method_6(object sender, EventArgs e)
	{
		if (!Class268.Boolean_1)
		{
			MessageBox.Show(this, "Chức năng này phải mua", "MicroAuto", MessageBoxButtons.YesNo);
			this.CheckBox_0.Checked = false;
		}
	}

	// Token: 0x0600119A RID: 4506 RVA: 0x00002E18 File Offset: 0x00001018
	private void listViewEx2_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x0600119B RID: 4507 RVA: 0x00060EC0 File Offset: 0x0005F0C0
	private void button3_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewEx1.Items)
		{
			((ListViewItem)obj).SubItems[1].Text = "Cao Dương";
		}
		foreach (object obj2 in this.listViewEx2.Items)
		{
			((ListViewItem)obj2).SubItems[1].Text = "Cao Dương";
		}
	}

	// Token: 0x0600119C RID: 4508 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x0600119D RID: 4509 RVA: 0x0000E11F File Offset: 0x0000C31F
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600119E RID: 4510 RVA: 0x00060F88 File Offset: 0x0005F188
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BinhThanh));
		this.btn3 = new Button();
		this.btn4 = new Button();
		this.btn5 = new Button();
		this.btn6 = new Button();
		this.btn1 = new Button();
		this.btn2 = new Button();
		this.btn7 = new Button();
		this.btn8 = new Button();
		this.button11 = new Button();
		this.button12 = new Button();
		this.splitContainer1 = new SplitContainer();
		this.listViewEx2 = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.listViewEx1 = new ListViewEx();
		this.columnHeader_2 = new ColumnHeader();
		this.columnHeader_3 = new ColumnHeader();
		this.splitContainer2 = new SplitContainer();
		this.panel4 = new Panel();
		this.panel1 = new Panel();
		this.panel3 = new Panel();
		this.panel2 = new Panel();
		this.panel5 = new Panel();
		this.panel6 = new Panel();
		this.checkBox1 = new CheckBox();
		this.button3 = new Button();
		this.timer_0 = new Timer(this.icontainer_0);
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.button1 = new Button();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.panel4.SuspendLayout();
		this.panel1.SuspendLayout();
		this.panel3.SuspendLayout();
		this.panel2.SuspendLayout();
		this.panel5.SuspendLayout();
		this.panel6.SuspendLayout();
		base.SuspendLayout();
		this.btn3.Dock = DockStyle.Left;
		this.btn3.Location = new Point(0, 0);
		this.btn3.Name = "btn3";
		this.btn3.Size = new Size(87, 20);
		this.btn3.TabIndex = 7;
		this.btn3.Text = "Boss 2";
		this.btn3.UseVisualStyleBackColor = true;
		this.btn3.Click += this.btn3_Click;
		this.btn4.Dock = DockStyle.Fill;
		this.btn4.Location = new Point(87, 0);
		this.btn4.Name = "btn4";
		this.btn4.Size = new Size(98, 20);
		this.btn4.TabIndex = 9;
		this.btn4.Text = "Vào Boss 2";
		this.btn4.UseVisualStyleBackColor = true;
		this.btn4.Click += this.btn4_Click;
		this.btn5.Dock = DockStyle.Left;
		this.btn5.Location = new Point(0, 0);
		this.btn5.Name = "btn5";
		this.btn5.Size = new Size(87, 20);
		this.btn5.TabIndex = 10;
		this.btn5.Text = "Boss 3";
		this.btn5.UseVisualStyleBackColor = true;
		this.btn5.Click += this.btn5_Click;
		this.btn6.Dock = DockStyle.Fill;
		this.btn6.Location = new Point(87, 0);
		this.btn6.Name = "btn6";
		this.btn6.Size = new Size(98, 20);
		this.btn6.TabIndex = 11;
		this.btn6.Text = "Vào Boss 3";
		this.btn6.UseVisualStyleBackColor = true;
		this.btn6.Click += this.btn6_Click;
		this.btn1.Dock = DockStyle.Left;
		this.btn1.Location = new Point(0, 0);
		this.btn1.Name = "btn1";
		this.btn1.Size = new Size(87, 20);
		this.btn1.TabIndex = 12;
		this.btn1.Text = "Boss 1";
		this.btn1.UseVisualStyleBackColor = true;
		this.btn1.Click += this.btn1_Click;
		this.btn2.Dock = DockStyle.Fill;
		this.btn2.Location = new Point(87, 0);
		this.btn2.Name = "btn2";
		this.btn2.Size = new Size(98, 20);
		this.btn2.TabIndex = 13;
		this.btn2.Text = "Vào Boss 1";
		this.btn2.UseVisualStyleBackColor = true;
		this.btn2.Click += this.btn2_Click;
		this.btn7.Dock = DockStyle.Left;
		this.btn7.Location = new Point(0, 0);
		this.btn7.Name = "btn7";
		this.btn7.Size = new Size(87, 20);
		this.btn7.TabIndex = 15;
		this.btn7.Text = "Boss 4";
		this.btn7.UseVisualStyleBackColor = true;
		this.btn7.Click += this.btn7_Click;
		this.btn8.Dock = DockStyle.Fill;
		this.btn8.Location = new Point(87, 0);
		this.btn8.Name = "btn8";
		this.btn8.Size = new Size(98, 20);
		this.btn8.TabIndex = 16;
		this.btn8.Text = "Vào Boss 4";
		this.btn8.UseVisualStyleBackColor = true;
		this.btn8.Click += this.btn8_Click;
		this.button11.Dock = DockStyle.Fill;
		this.button11.Location = new Point(87, 0);
		this.button11.Name = "button11";
		this.button11.Size = new Size(110, 20);
		this.button11.TabIndex = 17;
		this.button11.Text = "Xuống Ngựa";
		this.button11.UseVisualStyleBackColor = true;
		this.button11.Click += this.button11_Click;
		this.button12.Dock = DockStyle.Left;
		this.button12.Location = new Point(0, 0);
		this.button12.Name = "button12";
		this.button12.Size = new Size(87, 20);
		this.button12.TabIndex = 18;
		this.button12.Text = "Lên Ngựa";
		this.button12.UseVisualStyleBackColor = true;
		this.button12.Click += this.button12_Click;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.listViewEx2);
		this.splitContainer1.Panel2.Controls.Add(this.listViewEx1);
		this.splitContainer1.Size = new Size(386, 244);
		this.splitContainer1.SplitterDistance = 183;
		this.splitContainer1.TabIndex = 21;
		this.listViewEx2.AllowColumnReorder = true;
		this.listViewEx2.AllowDrop = true;
		this.listViewEx2.AllowReorder = true;
		this.listViewEx2.AllowSort = false;
		this.listViewEx2.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.listViewEx2.Dock = DockStyle.Fill;
		this.listViewEx2.DoubleClickActivation = false;
		this.listViewEx2.FullRowSelect = true;
		this.listViewEx2.GridLines = true;
		this.listViewEx2.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewEx2.hideItems");
		this.listViewEx2.HideSelection = false;
		this.listViewEx2.LineColor = Color.Red;
		this.listViewEx2.Location = new Point(0, 0);
		this.listViewEx2.Name = "listViewEx2";
		this.listViewEx2.Size = new Size(183, 244);
		this.listViewEx2.TabIndex = 4;
		this.listViewEx2.UseCompatibleStateImageBehavior = false;
		this.listViewEx2.View = View.Details;
		this.listViewEx2.SelectedIndexChanged += this.listViewEx2_SelectedIndexChanged;
		this.listViewEx2.DoubleClick += this.listViewEx2_DoubleClick;
		this.columnHeader_0.Text = "Tổ Đội";
		this.columnHeader_0.Width = 70;
		this.columnHeader_1.Text = "Tọa Độ";
		this.columnHeader_1.Width = 50;
		this.listViewEx1.AllowColumnReorder = true;
		this.listViewEx1.AllowDrop = true;
		this.listViewEx1.AllowReorder = true;
		this.listViewEx1.AllowSort = false;
		this.listViewEx1.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_2,
			this.columnHeader_3
		});
		this.listViewEx1.Dock = DockStyle.Fill;
		this.listViewEx1.DoubleClickActivation = false;
		this.listViewEx1.FullRowSelect = true;
		this.listViewEx1.GridLines = true;
		this.listViewEx1.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewEx1.hideItems");
		this.listViewEx1.HideSelection = false;
		this.listViewEx1.LineColor = Color.Red;
		this.listViewEx1.Location = new Point(0, 0);
		this.listViewEx1.Name = "listViewEx1";
		this.listViewEx1.Size = new Size(199, 244);
		this.listViewEx1.TabIndex = 5;
		this.listViewEx1.UseCompatibleStateImageBehavior = false;
		this.listViewEx1.View = View.Details;
		this.listViewEx1.DoubleClick += this.listViewEx1_DoubleClick;
		this.columnHeader_2.Text = "Tổ Đội";
		this.columnHeader_2.Width = 70;
		this.columnHeader_3.Text = "Tọa Độ";
		this.columnHeader_3.Width = 50;
		this.splitContainer2.Dock = DockStyle.Bottom;
		this.splitContainer2.Location = new Point(0, 244);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Panel1.Controls.Add(this.panel4);
		this.splitContainer2.Panel1.Controls.Add(this.panel1);
		this.splitContainer2.Panel1.Controls.Add(this.panel3);
		this.splitContainer2.Panel1.Controls.Add(this.panel2);
		this.splitContainer2.Panel2.Controls.Add(this.button1);
		this.splitContainer2.Panel2.Controls.Add(this.panel5);
		this.splitContainer2.Panel2.Controls.Add(this.panel6);
		this.splitContainer2.Size = new Size(386, 83);
		this.splitContainer2.SplitterDistance = 185;
		this.splitContainer2.TabIndex = 22;
		this.panel4.Controls.Add(this.btn8);
		this.panel4.Controls.Add(this.btn7);
		this.panel4.Dock = DockStyle.Bottom;
		this.panel4.Location = new Point(0, 3);
		this.panel4.Name = "panel4";
		this.panel4.Size = new Size(185, 20);
		this.panel4.TabIndex = 26;
		this.panel1.Controls.Add(this.btn2);
		this.panel1.Controls.Add(this.btn1);
		this.panel1.Dock = DockStyle.Bottom;
		this.panel1.Location = new Point(0, 23);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(185, 20);
		this.panel1.TabIndex = 23;
		this.panel3.Controls.Add(this.btn6);
		this.panel3.Controls.Add(this.btn5);
		this.panel3.Dock = DockStyle.Bottom;
		this.panel3.Location = new Point(0, 43);
		this.panel3.Name = "panel3";
		this.panel3.Size = new Size(185, 20);
		this.panel3.TabIndex = 25;
		this.panel2.Controls.Add(this.btn4);
		this.panel2.Controls.Add(this.btn3);
		this.panel2.Dock = DockStyle.Bottom;
		this.panel2.Location = new Point(0, 63);
		this.panel2.Name = "panel2";
		this.panel2.Size = new Size(185, 20);
		this.panel2.TabIndex = 24;
		this.panel5.Controls.Add(this.button11);
		this.panel5.Controls.Add(this.button12);
		this.panel5.Dock = DockStyle.Bottom;
		this.panel5.Location = new Point(0, 43);
		this.panel5.Name = "panel5";
		this.panel5.Size = new Size(197, 20);
		this.panel5.TabIndex = 27;
		this.panel6.Controls.Add(this.checkBox1);
		this.panel6.Controls.Add(this.button3);
		this.panel6.Dock = DockStyle.Bottom;
		this.panel6.Location = new Point(0, 63);
		this.panel6.Name = "panel6";
		this.panel6.Size = new Size(197, 20);
		this.panel6.TabIndex = 28;
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = DockStyle.Right;
		this.checkBox1.Location = new Point(122, 0);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new Size(75, 20);
		this.checkBox1.TabIndex = 23;
		this.checkBox1.Text = "Di Chuyển";
		this.toolTip_0.SetToolTip(this.checkBox1, "Nhân vật sẽ di chuyển liên tục đến tọa độ chỉ định\r\nSử dụng ngựa và chống kẹt");
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.button3.Dock = DockStyle.Left;
		this.button3.Location = new Point(0, 0);
		this.button3.Name = "button3";
		this.button3.Size = new Size(87, 20);
		this.button3.TabIndex = 19;
		this.button3.Text = "Lâu Lan";
		this.button3.UseVisualStyleBackColor = true;
		this.button3.Click += this.button3_Click;
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += this.timer_0_Tick;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.IsBalloon = true;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 20);
		this.button1.Name = "button1";
		this.button1.Size = new Size(197, 23);
		this.button1.TabIndex = 29;
		this.button1.Text = "Close";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.splitContainer2);
		base.Name = "BinhThanh";
		base.Size = new Size(386, 327);
		base.Load += this.BinhThanh_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.panel4.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.panel3.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel5.ResumeLayout(false);
		this.panel6.ResumeLayout(false);
		this.panel6.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x040008F2 RID: 2290
	private Class234 class234_0;

	// Token: 0x040008F3 RID: 2291
	private int int_0;

	// Token: 0x040008F4 RID: 2292
	private int int_1;

	// Token: 0x040008F5 RID: 2293
	[CompilerGenerated]
	private CheckBox checkBox_0;

	// Token: 0x040008F6 RID: 2294
	private IContainer icontainer_0;

	// Token: 0x040008F7 RID: 2295
	private ListViewEx listViewEx2;

	// Token: 0x040008F8 RID: 2296
	private ColumnHeader columnHeader_0;

	// Token: 0x040008F9 RID: 2297
	private ColumnHeader columnHeader_1;

	// Token: 0x040008FA RID: 2298
	private ListViewEx listViewEx1;

	// Token: 0x040008FB RID: 2299
	private ColumnHeader columnHeader_2;

	// Token: 0x040008FC RID: 2300
	private ColumnHeader columnHeader_3;

	// Token: 0x040008FD RID: 2301
	private Button btn3;

	// Token: 0x040008FE RID: 2302
	private Button btn4;

	// Token: 0x040008FF RID: 2303
	private Button btn5;

	// Token: 0x04000900 RID: 2304
	private Button btn6;

	// Token: 0x04000901 RID: 2305
	private Button btn1;

	// Token: 0x04000902 RID: 2306
	private Button btn2;

	// Token: 0x04000903 RID: 2307
	private Button btn7;

	// Token: 0x04000904 RID: 2308
	private Button btn8;

	// Token: 0x04000905 RID: 2309
	private Button button11;

	// Token: 0x04000906 RID: 2310
	private Button button12;

	// Token: 0x04000907 RID: 2311
	private SplitContainer splitContainer1;

	// Token: 0x04000908 RID: 2312
	private SplitContainer splitContainer2;

	// Token: 0x04000909 RID: 2313
	private CheckBox checkBox1;

	// Token: 0x0400090A RID: 2314
	private Timer timer_0;

	// Token: 0x0400090B RID: 2315
	private ToolTip toolTip_0;

	// Token: 0x0400090C RID: 2316
	private Button button3;

	// Token: 0x0400090D RID: 2317
	private Panel panel4;

	// Token: 0x0400090E RID: 2318
	private Panel panel1;

	// Token: 0x0400090F RID: 2319
	private Panel panel3;

	// Token: 0x04000910 RID: 2320
	private Panel panel2;

	// Token: 0x04000911 RID: 2321
	private Panel panel5;

	// Token: 0x04000912 RID: 2322
	private Panel panel6;

	// Token: 0x04000913 RID: 2323
	private Button button1;
}
