﻿using System;

// Token: 0x020000CB RID: 203
public class GClass62 : GClass61
{
	// Token: 0x060009AF RID: 2479 RVA: 0x00009574 File Offset: 0x00007774
	public GClass62(GClass99 gclass99_1, char char_2) : base(gclass99_1)
	{
		this.char_0 = char_2;
	}

	// Token: 0x060009B0 RID: 2480 RVA: 0x0003EC3C File Offset: 0x0003CE3C
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.gclass99_0.vmethod_13();
		switch (this.char_0)
		{
		case '\b':
		{
			this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = this.class90_1.GStruct2_0;
			char c = '\0';
			if (this.char_1 != '\0')
			{
				this.gclass99_0.FastColoredTextBox_0.method_101(this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0.int_1);
				GClass62.smethod_0(this.char_1, ref c, this.gclass99_0);
				goto IL_1C8;
			}
			goto IL_1C8;
		}
		case '\t':
			this.gclass99_0.FastColoredTextBox_0.method_101(this.class90_0.GStruct2_0.int_1);
			for (int i = this.class90_0.Int32_0; i < this.class90_1.Int32_0; i++)
			{
				this.gclass99_0[this.class90_0.GStruct2_0.int_1].RemoveAt(this.class90_0.GStruct2_0.int_0);
			}
			this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = this.class90_0.GStruct2_0;
			goto IL_1C8;
		case '\n':
			GClass62.smethod_2(this.class90_0.GStruct2_0.int_1, this.gclass99_0);
			goto IL_1C8;
		case '\r':
			goto IL_1C8;
		}
		this.gclass99_0.FastColoredTextBox_0.method_101(this.class90_0.GStruct2_0.int_1);
		this.gclass99_0[this.class90_0.GStruct2_0.int_1].RemoveAt(this.class90_0.GStruct2_0.int_0);
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = this.class90_0.GStruct2_0;
		IL_1C8:
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(this.class90_0.GStruct2_0.int_1, this.class90_0.GStruct2_0.int_1));
		base.GClass61.\u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E();
	}

	// Token: 0x060009B1 RID: 2481 RVA: 0x0003EE48 File Offset: 0x0003D048
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		this.gclass99_0.FastColoredTextBox_0.method_101(this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0.int_1);
		string text = this.char_0.ToString();
		this.gclass99_0.vmethod_14(ref text);
		if (text.Length == 1)
		{
			this.char_0 = text[0];
		}
		if (string.IsNullOrEmpty(text))
		{
			throw new ArgumentOutOfRangeException();
		}
		if (this.gclass99_0.Count == 0)
		{
			GClass62.smethod_1(this.gclass99_0);
		}
		GClass62.smethod_0(this.char_0, ref this.char_1, this.gclass99_0);
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0.int_1, this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0.int_1));
		base.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
	}

	// Token: 0x060009B2 RID: 2482 RVA: 0x0003EF38 File Offset: 0x0003D138
	internal static void smethod_0(char char_2, ref char char_3, GClass99 gclass99_1)
	{
		FastColoredTextBox fastColoredTextBox_ = gclass99_1.FastColoredTextBox_0;
		switch (char_2)
		{
		case '\b':
			if (fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 == 0 && fastColoredTextBox_.GClass86_5.GStruct2_0.int_1 == 0)
			{
				return;
			}
			if (fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 != 0)
			{
				char_3 = gclass99_1[fastColoredTextBox_.GClass86_5.GStruct2_0.int_1][fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 - 1].char_0;
				gclass99_1[fastColoredTextBox_.GClass86_5.GStruct2_0.int_1].RemoveAt(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 - 1);
				fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 - 1, fastColoredTextBox_.GClass86_5.GStruct2_0.int_1);
				return;
			}
			if (!gclass99_1.FastColoredTextBox_0.bool_0)
			{
				throw new ArgumentOutOfRangeException("Cant insert this char in ColumnRange mode");
			}
			if (fastColoredTextBox_.list_0[fastColoredTextBox_.GClass86_5.GStruct2_0.int_1 - 1].genum17_0 != GEnum17.Visible)
			{
				fastColoredTextBox_.method_101(fastColoredTextBox_.GClass86_5.GStruct2_0.int_1 - 1);
			}
			char_3 = '\n';
			GClass62.smethod_2(fastColoredTextBox_.GClass86_5.GStruct2_0.int_1 - 1, gclass99_1);
			return;
		case '\t':
		{
			int num = fastColoredTextBox_.Int32_5 - fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 % fastColoredTextBox_.Int32_5;
			if (num == 0)
			{
				num = fastColoredTextBox_.Int32_5;
			}
			for (int i = 0; i < num; i++)
			{
				gclass99_1[fastColoredTextBox_.GClass86_5.GStruct2_0.int_1].Insert(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0, new GStruct0(' '));
			}
			fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 + num, fastColoredTextBox_.GClass86_5.GStruct2_0.int_1);
			return;
		}
		case '\n':
			if (!gclass99_1.FastColoredTextBox_0.bool_0)
			{
				throw new ArgumentOutOfRangeException("Cant insert this char in ColumnRange mode");
			}
			if (gclass99_1.Count == 0)
			{
				GClass62.smethod_1(gclass99_1);
			}
			GClass62.smethod_1(gclass99_1);
			return;
		case '\r':
			return;
		}
		gclass99_1[fastColoredTextBox_.GClass86_5.GStruct2_0.int_1].Insert(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0, new GStruct0(char_2));
		fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(fastColoredTextBox_.GClass86_5.GStruct2_0.int_0 + 1, fastColoredTextBox_.GClass86_5.GStruct2_0.int_1);
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x0003F1D8 File Offset: 0x0003D3D8
	internal static void smethod_1(GClass99 gclass99_1)
	{
		FastColoredTextBox fastColoredTextBox_ = gclass99_1.FastColoredTextBox_0;
		if (!fastColoredTextBox_.Boolean_22 && fastColoredTextBox_.Int32_14 > 0)
		{
			return;
		}
		if (gclass99_1.Count == 0)
		{
			gclass99_1.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, gclass99_1.vmethod_0());
		}
		else
		{
			GClass62.smethod_3(fastColoredTextBox_.GClass86_5.GStruct2_0.int_1, fastColoredTextBox_.GClass86_5.GStruct2_0.int_0, gclass99_1);
		}
		fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(0, fastColoredTextBox_.GClass86_5.GStruct2_0.int_1 + 1);
		gclass99_1.vmethod_11(new GClass99.GEventArgs20(0, 1));
	}

	// Token: 0x060009B4 RID: 2484 RVA: 0x0003F26C File Offset: 0x0003D46C
	internal static void smethod_2(int int_0, GClass99 gclass99_1)
	{
		FastColoredTextBox fastColoredTextBox_ = gclass99_1.FastColoredTextBox_0;
		if (int_0 + 1 >= gclass99_1.Count)
		{
			return;
		}
		fastColoredTextBox_.method_101(int_0);
		fastColoredTextBox_.method_101(int_0 + 1);
		int count = gclass99_1[int_0].Count;
		if (gclass99_1[int_0 + 1].Count == 0)
		{
			gclass99_1.vmethod_8(int_0 + 1);
		}
		else
		{
			gclass99_1[int_0].vmethod_2(gclass99_1[int_0 + 1]);
			gclass99_1.vmethod_8(int_0 + 1);
		}
		fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(count, int_0);
		gclass99_1.vmethod_11(new GClass99.GEventArgs20(0, 1));
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x0003F304 File Offset: 0x0003D504
	internal static void smethod_3(int int_0, int int_1, GClass99 gclass99_1)
	{
		GClass81 gclass = gclass99_1.vmethod_0();
		for (int i = int_1; i < gclass99_1[int_0].Count; i++)
		{
			gclass.Add(gclass99_1[int_0][i]);
		}
		gclass99_1[int_0].vmethod_0(int_1, gclass99_1[int_0].Count - int_1);
		gclass99_1.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(int_0 + 1, gclass);
	}

	// Token: 0x060009B6 RID: 2486 RVA: 0x00009584 File Offset: 0x00007784
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		return new GClass62(this.gclass99_0, this.char_0);
	}

	// Token: 0x040004C8 RID: 1224
	public char char_0;

	// Token: 0x040004C9 RID: 1225
	private char char_1;
}
