﻿using System;
using System.IO;

// Token: 0x020000FB RID: 251
internal class Class102 : TextReader
{
	// Token: 0x06000CF6 RID: 3318 RVA: 0x0000B546 File Offset: 0x00009746
	public virtual int Read()
	{
		return base.Read();
	}
}
