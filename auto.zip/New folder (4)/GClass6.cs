﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Security;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.Win32;

// Token: 0x0200000C RID: 12
public static class GClass6
{
	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000075 RID: 117 RVA: 0x00003534 File Offset: 0x00001734
	private static Random Random_0
	{
		get
		{
			if (GClass6.random_0 == null)
			{
				GClass6.random_0 = new Random();
			}
			return GClass6.random_0;
		}
	}

	// Token: 0x06000076 RID: 118 RVA: 0x000224AC File Offset: 0x000206AC
	static GClass6()
	{
		GClass6.remoteCertificateValidationCallback_0 = new RemoteCertificateValidationCallback(GClass6.smethod_9);
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00022708 File Offset: 0x00020908
	public static string smethod_0(string string_1, Encoding encoding_0 = null)
	{
		if (string.IsNullOrEmpty(string_1))
		{
			return string.Empty;
		}
		encoding_0 = (encoding_0 ?? Encoding.UTF8);
		byte[] bytes = encoding_0.GetBytes(string_1);
		int num = 0;
		int num2 = 0;
		foreach (char c in bytes)
		{
			if (c == ' ')
			{
				num++;
			}
			else if (!GClass6.smethod_10(c))
			{
				num2++;
			}
		}
		if (num == 0 && num2 == 0)
		{
			return string_1;
		}
		int num3 = 0;
		byte[] array = new byte[bytes.Length + num2 * 2];
		for (int j = 0; j < bytes.Length; j++)
		{
			char c2 = (char)bytes[j];
			if (GClass6.smethod_10(c2))
			{
				array[num3++] = bytes[j];
			}
			else if (c2 == ' ')
			{
				array[num3++] = 43;
			}
			else
			{
				array[num3++] = 37;
				array[num3++] = (byte)GClass6.smethod_11(bytes[j] >> 4 & 15);
				array[num3++] = (byte)GClass6.smethod_11((int)(bytes[j] & 15));
			}
		}
		return Encoding.ASCII.GetString(array);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00022808 File Offset: 0x00020A08
	public static string smethod_1(IEnumerable<KeyValuePair<string, string>> ienumerable_0, bool bool_0)
	{
		if (ienumerable_0 == null)
		{
			throw new ArgumentNullException("parameters");
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, string> keyValuePair in ienumerable_0)
		{
			if (!string.IsNullOrEmpty(keyValuePair.Key))
			{
				stringBuilder.Append(keyValuePair.Key);
				stringBuilder.Append('=');
				if (bool_0)
				{
					stringBuilder.Append(keyValuePair.Value);
				}
				else
				{
					stringBuilder.Append(Uri.EscapeDataString(keyValuePair.Value ?? string.Empty));
				}
				stringBuilder.Append('&');
			}
		}
		if (stringBuilder.Length != 0)
		{
			stringBuilder.Remove(stringBuilder.Length - 1, 1);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000079 RID: 121 RVA: 0x000228DC File Offset: 0x00020ADC
	public static string smethod_2(IEnumerable<KeyValuePair<string, string>> ienumerable_0, bool bool_0, Encoding encoding_0 = null)
	{
		if (ienumerable_0 == null)
		{
			throw new ArgumentNullException("parameters");
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, string> keyValuePair in ienumerable_0)
		{
			if (!string.IsNullOrEmpty(keyValuePair.Key))
			{
				stringBuilder.Append(keyValuePair.Key);
				stringBuilder.Append('=');
				if (bool_0)
				{
					stringBuilder.Append(keyValuePair.Value);
				}
				else
				{
					stringBuilder.Append(GClass6.smethod_0(keyValuePair.Value ?? string.Empty, encoding_0));
				}
				stringBuilder.Append('&');
			}
		}
		if (stringBuilder.Length != 0)
		{
			stringBuilder.Remove(stringBuilder.Length - 1, 1);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600007A RID: 122 RVA: 0x000229B0 File Offset: 0x00020BB0
	public static string smethod_3(string string_1)
	{
		string result = "application/octet-stream";
		try
		{
			using (RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(string_1))
			{
				if (registryKey != null)
				{
					object value = registryKey.GetValue("Content Type");
					if (value != null)
					{
						result = value.ToString();
					}
				}
			}
		}
		catch (IOException)
		{
		}
		catch (ObjectDisposedException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		catch (SecurityException)
		{
		}
		return result;
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00022A44 File Offset: 0x00020C44
	public static string smethod_4()
	{
		string text = GClass6.smethod_12();
		string text2 = null;
		string text3 = null;
		string text4 = null;
		string text5;
		if (text.Contains("NT 5.1"))
		{
			text2 = "9.0";
			text3 = "5.0";
			text4 = "5.0";
			text5 = ".NET CLR 2.0.50727; .NET CLR 3.5.30729";
		}
		else if (text.Contains("NT 6.0"))
		{
			text2 = "9.0";
			text3 = "5.0";
			text4 = "5.0";
			text5 = ".NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.5.30729";
		}
		else
		{
			switch (GClass6.Random_0.Next(3))
			{
			case 0:
				text2 = "10.0";
				text4 = "6.0";
				text3 = "5.0";
				break;
			case 1:
				text2 = "10.6";
				text4 = "6.0";
				text3 = "5.0";
				break;
			case 2:
				text2 = "11.0";
				text4 = "7.0";
				text3 = "5.0";
				break;
			}
			text5 = ".NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E";
		}
		return string.Format("Mozilla/{0} (compatible; MSIE {1}; {2}; Trident/{3}; {4})", new object[]
		{
			text3,
			text2,
			text,
			text4,
			text5
		});
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00022B3C File Offset: 0x00020D3C
	public static string smethod_5()
	{
		string arg = null;
		string arg2 = null;
		switch (GClass6.Random_0.Next(4))
		{
		case 0:
			arg = "12.16";
			arg2 = "2.12.388";
			break;
		case 1:
			arg = "12.14";
			arg2 = "2.12.388";
			break;
		case 2:
			arg = "12.02";
			arg2 = "2.10.289";
			break;
		case 3:
			arg = "12.00";
			arg2 = "2.10.181";
			break;
		}
		return string.Format("Opera/9.80 ({0}); U) Presto/{1} Version/{2}", GClass6.smethod_12(), arg2, arg);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00022BB8 File Offset: 0x00020DB8
	public static string smethod_6()
	{
		string arg = null;
		string arg2 = null;
		switch (GClass6.Random_0.Next(5))
		{
		case 0:
			arg = "41.0.2228.0";
			arg2 = "537.36";
			break;
		case 1:
			arg = "41.0.2227.1";
			arg2 = "537.36";
			break;
		case 2:
			arg = "41.0.2224.3";
			arg2 = "537.36";
			break;
		case 3:
			arg = "41.0.2225.0";
			arg2 = "537.36";
			break;
		case 4:
			arg = "41.0.2226.0";
			arg2 = "537.36";
			break;
		}
		return string.Format("Mozilla/5.0 ({0}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{1} Safari/{2}", GClass6.smethod_12(), arg, arg2);
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00022C48 File Offset: 0x00020E48
	public static string smethod_7()
	{
		string arg = null;
		string arg2 = null;
		switch (GClass6.Random_0.Next(5))
		{
		case 0:
			arg2 = "36.0";
			arg = "20100101";
			break;
		case 1:
			arg2 = "33.0";
			arg = "20100101";
			break;
		case 2:
			arg2 = "31.0";
			arg = "20100101";
			break;
		case 3:
			arg2 = "29.0";
			arg = "20120101";
			break;
		case 4:
			arg2 = "28.0";
			arg = "20100101";
			break;
		}
		return string.Format("Mozilla/5.0 ({0}; rv:{1}) Gecko/{2} Firefox/{1}", GClass6.smethod_12(), arg2, arg);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00022CD8 File Offset: 0x00020ED8
	public static string smethod_8()
	{
		string text = null;
		string text2 = null;
		string text3 = null;
		string text4 = null;
		switch (GClass6.Random_0.Next(3))
		{
		case 0:
			text = "iOS";
			text2 = "7.0.73345";
			text3 = "11.62";
			text4 = "2.10.229";
			break;
		case 1:
			text = "J2ME/MIDP";
			text2 = "7.1.23511";
			text3 = "12.00";
			text4 = "2.10.181";
			break;
		case 2:
			text = "Android";
			text2 = "7.5.54678";
			text3 = "12.02";
			text4 = "2.10.289";
			break;
		}
		return string.Format("Opera/9.80 ({0}; Opera Mini/{1}/28.2555; U; ru) Presto/{2} Version/{3}", new object[]
		{
			text,
			text2,
			text4,
			text3
		});
	}

	// Token: 0x06000080 RID: 128 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_9(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00022D7C File Offset: 0x00020F7C
	private static bool smethod_10(char char_0)
	{
		if ((char_0 >= 'a' && char_0 <= 'z') || (char_0 >= 'A' && char_0 <= 'Z') || (char_0 >= '0' && char_0 <= '9'))
		{
			return true;
		}
		if (char_0 != '!')
		{
			switch (char_0)
			{
			case '(':
			case ')':
			case '*':
			case '-':
			case '.':
				return true;
			case '+':
			case ',':
				break;
			default:
				if (char_0 == '_')
				{
					return true;
				}
				break;
			}
			return false;
		}
		return true;
	}

	// Token: 0x06000082 RID: 130 RVA: 0x0000354F File Offset: 0x0000174F
	private static char smethod_11(int int_0)
	{
		if (int_0 <= 9)
		{
			return (char)(int_0 + 48);
		}
		return (char)(int_0 - 10 + 65);
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00022DE0 File Offset: 0x00020FE0
	private static string smethod_12()
	{
		string text = "Windows NT ";
		switch (GClass6.Random_0.Next(4))
		{
		case 0:
			text += "5.1";
			break;
		case 1:
			text += "6.0";
			break;
		case 2:
			text += "6.1";
			break;
		case 3:
			text += "6.2";
			break;
		}
		if (GClass6.Random_0.NextDouble() < 0.2)
		{
			text += "; WOW64";
		}
		return text;
	}

	// Token: 0x0400000A RID: 10
	public const string string_0 = "\r\n";

	// Token: 0x0400000B RID: 11
	public static readonly RemoteCertificateValidationCallback remoteCertificateValidationCallback_0;

	// Token: 0x0400000C RID: 12
	internal static readonly Dictionary<GEnum1, string> dictionary_0 = new Dictionary<GEnum1, string>
	{
		{
			GEnum1.Accept,
			"Accept"
		},
		{
			GEnum1.AcceptCharset,
			"Accept-Charset"
		},
		{
			GEnum1.AcceptLanguage,
			"Accept-Language"
		},
		{
			GEnum1.AcceptDatetime,
			"Accept-Datetime"
		},
		{
			GEnum1.CacheControl,
			"Cache-Control"
		},
		{
			GEnum1.ContentType,
			"Content-Type"
		},
		{
			GEnum1.Date,
			"Date"
		},
		{
			GEnum1.Expect,
			"Expect"
		},
		{
			GEnum1.From,
			"From"
		},
		{
			GEnum1.IfMatch,
			"If-Match"
		},
		{
			GEnum1.IfModifiedSince,
			"If-Modified-Since"
		},
		{
			GEnum1.IfNoneMatch,
			"If-None-Match"
		},
		{
			GEnum1.IfRange,
			"If-Range"
		},
		{
			GEnum1.IfUnmodifiedSince,
			"If-Unmodified-Since"
		},
		{
			GEnum1.MaxForwards,
			"Max-Forwards"
		},
		{
			GEnum1.Pragma,
			"Pragma"
		},
		{
			GEnum1.Range,
			"Range"
		},
		{
			GEnum1.Referer,
			"Referer"
		},
		{
			GEnum1.Upgrade,
			"Upgrade"
		},
		{
			GEnum1.UserAgent,
			"User-Agent"
		},
		{
			GEnum1.Via,
			"Via"
		},
		{
			GEnum1.Warning,
			"Warning"
		},
		{
			GEnum1.DNT,
			"DNT"
		},
		{
			GEnum1.AccessControlAllowOrigin,
			"Access-Control-Allow-Origin"
		},
		{
			GEnum1.AcceptRanges,
			"Accept-Ranges"
		},
		{
			GEnum1.Age,
			"Age"
		},
		{
			GEnum1.Allow,
			"Allow"
		},
		{
			GEnum1.ContentEncoding,
			"Content-Encoding"
		},
		{
			GEnum1.ContentLanguage,
			"Content-Language"
		},
		{
			GEnum1.ContentLength,
			"Content-Length"
		},
		{
			GEnum1.ContentLocation,
			"Content-Location"
		},
		{
			GEnum1.ContentMD5,
			"Content-MD5"
		},
		{
			GEnum1.ContentDisposition,
			"Content-Disposition"
		},
		{
			GEnum1.ContentRange,
			"Content-Range"
		},
		{
			GEnum1.ETag,
			"ETag"
		},
		{
			GEnum1.Expires,
			"Expires"
		},
		{
			GEnum1.LastModified,
			"Last-Modified"
		},
		{
			GEnum1.Link,
			"Link"
		},
		{
			GEnum1.Location,
			"Location"
		},
		{
			GEnum1.P3P,
			"P3P"
		},
		{
			GEnum1.Refresh,
			"Refresh"
		},
		{
			GEnum1.RetryAfter,
			"Retry-After"
		},
		{
			GEnum1.Server,
			"Server"
		},
		{
			GEnum1.TransferEncoding,
			"Transfer-Encoding"
		}
	};

	// Token: 0x0400000D RID: 13
	[ThreadStatic]
	private static Random random_0;
}
