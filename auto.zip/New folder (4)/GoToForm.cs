﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020000FD RID: 253
public partial class GoToForm : Form
{
	// Token: 0x17000374 RID: 884
	// (get) Token: 0x06000D04 RID: 3332 RVA: 0x0000B643 File Offset: 0x00009843
	// (set) Token: 0x06000D05 RID: 3333 RVA: 0x0000B64B File Offset: 0x0000984B
	public int Int32_0 { get; set; }

	// Token: 0x17000375 RID: 885
	// (get) Token: 0x06000D06 RID: 3334 RVA: 0x0000B654 File Offset: 0x00009854
	// (set) Token: 0x06000D07 RID: 3335 RVA: 0x0000B65C File Offset: 0x0000985C
	public int Int32_1 { get; set; }

	// Token: 0x06000D08 RID: 3336 RVA: 0x0000B665 File Offset: 0x00009865
	public GoToForm()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000D09 RID: 3337 RVA: 0x0004E6DC File Offset: 0x0004C8DC
	protected virtual void OnLoad(EventArgs e)
	{
		base.OnLoad(e);
		this.tbLineNumber.Text = this.Int32_0.ToString();
		this.label.Text = string.Format("Line number (1 - {0}):", this.Int32_1);
	}

	// Token: 0x06000D0A RID: 3338 RVA: 0x0000B673 File Offset: 0x00009873
	protected virtual void OnShown(EventArgs e)
	{
		base.OnShown(e);
		this.tbLineNumber.Focus();
	}

	// Token: 0x06000D0B RID: 3339 RVA: 0x0004E72C File Offset: 0x0004C92C
	private void btnOk_Click(object sender, EventArgs e)
	{
		int num;
		if (int.TryParse(this.tbLineNumber.Text, out num))
		{
			num = Math.Min(num, this.Int32_1);
			num = Math.Max(1, num);
			this.Int32_0 = num;
		}
		base.DialogResult = DialogResult.OK;
		base.Close();
	}

	// Token: 0x06000D0C RID: 3340 RVA: 0x0000B688 File Offset: 0x00009888
	private void btnCancel_Click(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		base.Close();
	}

	// Token: 0x06000D0D RID: 3341 RVA: 0x0000B697 File Offset: 0x00009897
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000624 RID: 1572
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000625 RID: 1573
	[CompilerGenerated]
	private int int_1;

	// Token: 0x04000626 RID: 1574
	private IContainer icontainer_0;
}
