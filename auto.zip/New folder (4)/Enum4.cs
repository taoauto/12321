﻿using System;

// Token: 0x02000052 RID: 82
internal enum Enum4 : byte
{
	// Token: 0x040001EA RID: 490
	Off,
	// Token: 0x040001EB RID: 491
	On
}
