﻿using System;

// Token: 0x02000036 RID: 54
public enum GEnum5
{
	// Token: 0x04000165 RID: 357
	Little,
	// Token: 0x04000166 RID: 358
	Big
}
