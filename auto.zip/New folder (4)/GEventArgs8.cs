﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020000E5 RID: 229
public class GEventArgs8 : PaintEventArgs
{
	// Token: 0x06000C6F RID: 3183 RVA: 0x0000AF9D File Offset: 0x0000919D
	public GEventArgs8(int int_1, Rectangle rectangle_1, Graphics graphics_0, Rectangle rectangle_2) : base(graphics_0, rectangle_2)
	{
		this.Int32_0 = int_1;
		this.Rectangle_0 = rectangle_1;
	}

	// Token: 0x17000343 RID: 835
	// (get) Token: 0x06000C70 RID: 3184 RVA: 0x0000AFB6 File Offset: 0x000091B6
	// (set) Token: 0x06000C71 RID: 3185 RVA: 0x0000AFBE File Offset: 0x000091BE
	public int Int32_0 { get; private set; }

	// Token: 0x17000344 RID: 836
	// (get) Token: 0x06000C72 RID: 3186 RVA: 0x0000AFC7 File Offset: 0x000091C7
	// (set) Token: 0x06000C73 RID: 3187 RVA: 0x0000AFCF File Offset: 0x000091CF
	public Rectangle Rectangle_0 { get; private set; }

	// Token: 0x040005B6 RID: 1462
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040005B7 RID: 1463
	[CompilerGenerated]
	private Rectangle rectangle_0;
}
