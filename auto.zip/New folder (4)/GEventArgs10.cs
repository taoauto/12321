﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000E7 RID: 231
public class GEventArgs10 : EventArgs
{
	// Token: 0x06000C79 RID: 3193 RVA: 0x0000B010 File Offset: 0x00009210
	public GEventArgs10(int int_2, int int_3, List<int> list_1)
	{
		this.Int32_0 = int_2;
		this.Int32_1 = int_3;
		this.List_0 = list_1;
	}

	// Token: 0x17000347 RID: 839
	// (get) Token: 0x06000C7A RID: 3194 RVA: 0x0000B02D File Offset: 0x0000922D
	// (set) Token: 0x06000C7B RID: 3195 RVA: 0x0000B035 File Offset: 0x00009235
	public int Int32_0 { get; private set; }

	// Token: 0x17000348 RID: 840
	// (get) Token: 0x06000C7C RID: 3196 RVA: 0x0000B03E File Offset: 0x0000923E
	// (set) Token: 0x06000C7D RID: 3197 RVA: 0x0000B046 File Offset: 0x00009246
	public int Int32_1 { get; private set; }

	// Token: 0x17000349 RID: 841
	// (get) Token: 0x06000C7E RID: 3198 RVA: 0x0000B04F File Offset: 0x0000924F
	// (set) Token: 0x06000C7F RID: 3199 RVA: 0x0000B057 File Offset: 0x00009257
	public List<int> List_0 { get; private set; }

	// Token: 0x040005BA RID: 1466
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040005BB RID: 1467
	[CompilerGenerated]
	private int int_1;

	// Token: 0x040005BC RID: 1468
	[CompilerGenerated]
	private List<int> list_0;
}
