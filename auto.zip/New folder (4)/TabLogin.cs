﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

// Token: 0x02000221 RID: 545
internal class TabLogin : UserControl
{
	// Token: 0x170006B7 RID: 1719
	// (get) Token: 0x06001D5E RID: 7518 RVA: 0x00015A3D File Offset: 0x00013C3D
	// (set) Token: 0x06001D5F RID: 7519 RVA: 0x00015A44 File Offset: 0x00013C44
	public static List<TabLogin> List_0 { get; set; } = new List<TabLogin>();

	// Token: 0x06001D60 RID: 7520 RVA: 0x000D8AC8 File Offset: 0x000D6CC8
	public TabLogin()
	{
		this.InitializeComponent();
		MicroLogin.MicroLogin_0.splitContainer1.Visible = false;
		LoginUser loginUser = new LoginUser();
		base.Controls.Add(loginUser);
		loginUser.Disposed += this.method_7;
		loginUser.Dock = DockStyle.Fill;
		loginUser.BringToFront();
	}

	// Token: 0x06001D61 RID: 7521 RVA: 0x000D8BC0 File Offset: 0x000D6DC0
	private void method_0(Class145 class145_1)
	{
		using (List<KeyValuePair<int, Class159>>.Enumerator enumerator = Main.dictionary_3.Where(new Func<KeyValuePair<int, Class159>, bool>(TabLogin.Class252.<>9.method_0)).ToList<KeyValuePair<int, Class159>>().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				TabLogin.Class251 @class = new TabLogin.Class251();
				@class.keyValuePair_0 = enumerator.Current;
				try
				{
					if (this.List_1.Where(new Func<Class145, bool>(@class.method_0)).Count<Class145>() <= 0)
					{
						if (@class.keyValuePair_0.Value.Class432_0.Boolean_18 || @class.keyValuePair_0.Value.Class432_0.Boolean_17)
						{
							class145_1.String_20 = "Login";
							class145_1.class159_0 = @class.keyValuePair_0.Value;
							class145_1.Boolean_3 = false;
							class145_1.class159_0.Boolean_9 = true;
							class145_1.class159_0.Class145_0 = class145_1;
							class145_1.class159_0.UInt32_0 = 0U;
							class145_1.bool_10 = false;
							class145_1.bool_4 = false;
							class145_1.class159_0.Int32_19 = 0;
							class145_1.class159_0.bool_25 = false;
							class145_1.class159_0.String_12 = "";
							class145_1.class159_0.list_14.Add(base.Handle);
							class145_1.class159_0.stopwatch_31 = Stopwatch.StartNew();
							return;
						}
					}
				}
				catch
				{
				}
			}
		}
		bool flag = true;
		if (class145_1.stopwatch_0 != null && class145_1.stopwatch_0.Elapsed.TotalSeconds <= 20.0)
		{
			return;
		}
		int count = this.List_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_1)).ToList<Class145>().Count;
		if (Main.Int32_0 >= count)
		{
			flag = false;
		}
		if (Main.dictionary_3.Count >= Class268.int_27)
		{
			flag = false;
		}
		if (MicroLogin.stopwatch_0 == null)
		{
			MicroLogin.stopwatch_0 = Stopwatch.StartNew();
		}
		else if (MicroLogin.stopwatch_0.Elapsed.TotalSeconds < (double)MicroLogin.Int32_2)
		{
			flag = false;
		}
		if (flag)
		{
			if ((!Class426.smethod_10(class145_1.String_19) || !File.Exists(class145_1.String_19)) && !MicroLogin.bool_0)
			{
				MicroLogin.bool_0 = true;
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Filter = "Game.exe |Game.exe";
				if (openFileDialog.ShowDialog(this) == DialogResult.OK)
				{
					try
					{
						Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + class145_1.String_5 + "\"]").Attributes["Path"].Value = openFileDialog.FileName;
						Publisher.smethod_1();
					}
					catch
					{
						XmlAttribute xmlAttribute = Publisher.xmlDocument_0.CreateAttribute("Path");
						xmlAttribute.Value = openFileDialog.FileName;
						Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + class145_1.String_5 + "\"]").Attributes.Append(xmlAttribute);
						Publisher.smethod_1();
					}
				}
				MicroLogin.bool_0 = false;
			}
			MicroLogin.stopwatch_0 = Stopwatch.StartNew();
			class145_1.Stopwatch_1 = Stopwatch.StartNew();
			class145_1.bool_10 = false;
			class145_1.bool_4 = false;
			int num;
			if (Class268.int_27 - Main.dictionary_3.Count <= 0)
			{
				num = 0;
			}
			else
			{
				num = this.Int32_0;
				if (num > Class268.int_27 - Main.dictionary_3.Count)
				{
					num = Class268.int_27 - Main.dictionary_3.Count;
				}
			}
			int num2 = 0;
			while (num2 < num && num2 < MicroLogin.Int32_1)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				processStartInfo.FileName = class145_1.String_19;
				processStartInfo.Arguments = "-fl";
				if (class145_1.String_5.Contains("Tình Kiếm"))
				{
					ProcessStartInfo processStartInfo2 = processStartInfo;
					processStartInfo2.Arguments = processStartInfo2.Arguments + " " + Class426.smethod_11(15);
				}
				processStartInfo.WorkingDirectory = Path.GetDirectoryName(class145_1.String_19);
				Process.Start(processStartInfo);
				num2++;
			}
		}
	}

	// Token: 0x170006B8 RID: 1720
	// (get) Token: 0x06001D62 RID: 7522 RVA: 0x00015A4C File Offset: 0x00013C4C
	public int Int32_0
	{
		get
		{
			return this.List_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_2)).ToList<Class145>().Count;
		}
	}

	// Token: 0x06001D63 RID: 7523 RVA: 0x00015A82 File Offset: 0x00013C82
	public void method_1()
	{
		if (!this.bool_2)
		{
			this.bool_2 = true;
			this.thread_0 = new Thread(new ThreadStart(this.method_18));
			this.thread_0.Start();
			return;
		}
	}

	// Token: 0x06001D64 RID: 7524 RVA: 0x000859B8 File Offset: 0x00083BB8
	public int method_2(string string_2)
	{
		int num = Class426.smethod_43(string_2) * 60;
		int num2 = Class426.smethod_43(Regex.Replace(string_2, ".*:", ""));
		return num + num2;
	}

	// Token: 0x06001D65 RID: 7525 RVA: 0x000D9010 File Offset: 0x000D7210
	private void method_3()
	{
		if (this.Boolean_0 && this.nudStop.Value > 0m)
		{
			return;
		}
		if (MicroLogin.Boolean_13)
		{
			string[] array = Class159.Class220_0.method_0("Config", "SleepTime").Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Length > 2)
				{
					string text2 = text;
					if (text2.Split(new char[]
					{
						'-'
					}).Length > 1)
					{
						int num = this.method_2(text2.Split(new char[]
						{
							'-'
						})[0]);
						int num2 = this.method_2(text2.Split(new char[]
						{
							'-'
						})[1]);
						int num3 = DateTime.Now.Hour * 60 + DateTime.Now.Minute;
						if (num3 >= num && num3 < num2)
						{
							try
							{
								Process.GetProcessesByName("Game").ToList<Process>().ForEach(new Action<Process>(TabLogin.Class252.<>9.method_3));
							}
							catch
							{
							}
							return;
						}
					}
				}
			}
		}
		if (MicroLogin.Boolean_14)
		{
			bool flag = false;
			if (Main.class330_0.DateTime_0.Hour == 23 && Main.class330_0.DateTime_0.Minute == 59 && Main.class330_0.DateTime_0.Second >= 55)
			{
				flag = true;
			}
			if (Main.class330_0.DateTime_0.Hour == 0 && Main.class330_0.DateTime_0.Minute == 0 && Main.class330_0.DateTime_0.Second <= 5)
			{
				flag = true;
			}
			if (flag)
			{
				this.List_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_4));
			}
		}
		else if (MicroLogin.Boolean_2 && Main.class330_0 != null)
		{
			bool flag2 = false;
			if (Main.class330_0.DateTime_0.Hour == 23 && Main.class330_0.DateTime_0.Minute == 59 && Main.class330_0.DateTime_0.Second >= 55)
			{
				flag2 = true;
			}
			if (Main.class330_0.DateTime_0.Hour == 0 && Main.class330_0.DateTime_0.Minute == 0 && Main.class330_0.DateTime_0.Second <= 5)
			{
				flag2 = true;
			}
			if (flag2)
			{
				foreach (Class145 @class in this.List_1)
				{
					@class.Boolean_9 = true;
					if (@class.String_20 == "xong BHD")
					{
						@class.String_20 = "Đang chờ làm BHD...";
						if (@class.class159_0 != null)
						{
							@class.class159_0.bool_25 = false;
							@class.class159_0.method_48(Enum14.BachHoaDuyen, true);
							@class.class159_0.bool_27 = false;
							@class.class159_0.bool_26 = false;
						}
					}
				}
			}
		}
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3.Where(new Func<KeyValuePair<int, Class159>, bool>(this.method_19)).ToList<KeyValuePair<int, Class159>>())
		{
			if (keyValuePair.Value.Class432_0.Boolean_34)
			{
				keyValuePair.Value.list_14.Add(base.Handle);
				foreach (Class145 class2 in this.List_1)
				{
					if (!class2.String_20.Contains("xong") && !class2.String_20.Contains("đơ") && !string.IsNullOrEmpty(keyValuePair.Value.Class432_0.String_1) && !string.IsNullOrEmpty(class2.String_9) && class2.String_9.Contains(keyValuePair.Value.Class432_0.String_1) && !string.IsNullOrEmpty(keyValuePair.Value.Class432_0.String_1))
					{
						class2.class159_0 = keyValuePair.Value;
						class2.class159_0.Class145_0 = class2;
						class2.Boolean_5 = true;
						break;
					}
				}
			}
		}
		int num4 = 0;
		int num5 = Class426.smethod_41(this.txtLimit.Text);
		using (List<Class145>.Enumerator enumerator = this.List_1.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				TabLogin.Class253 class3 = new TabLogin.Class253();
				class3.class145_0 = enumerator.Current;
				if (class3.class145_0.class159_0 == null)
				{
					if (num5 > 0)
					{
						if (this.List_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_5)).Count<Class145>() >= num5)
						{
							break;
						}
					}
					if (class3.class145_0.String_20.Contains("Đang chờ") && (!MicroLogin.Boolean_7 || !class3.class145_0.Boolean_31 || this.List_1.Where(new Func<Class145, bool>(class3.method_0)).Count<Class145>() < MicroLogin.Int32_4) && (!MicroLogin.Boolean_8 || (!class3.class145_0.bool_12 && !class3.class145_0.Boolean_29) || this.List_1.Where(new Func<Class145, bool>(class3.method_1)).Count<Class145>() < MicroLogin.Int32_5) && (!MicroLogin.Boolean_9 || !class3.class145_0.Boolean_30 || this.List_1.Where(new Func<Class145, bool>(class3.method_2)).Count<Class145>() < MicroLogin.Int32_6))
					{
						if (num4++ >= 100)
						{
							break;
						}
						this.method_0(class3.class145_0);
						if (!(class3.class145_0.String_20 == "Login"))
						{
							break;
						}
						if (num4++ > 6)
						{
							break;
						}
					}
				}
			}
		}
		foreach (Class145 class4 in this.List_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_6)))
		{
			Class159 class159_ = class4.class159_0;
			if (class4.listViewItem_0 != null)
			{
				if (!class4.String_20.Contains("xong") && !class4.String_20.Contains("đơ"))
				{
					if (class159_ != null)
					{
						class159_.Int32_65 = class4.Int32_2;
						if (class159_.Class432_0.Boolean_34 && class159_.Boolean_65)
						{
							if (class4.Boolean_11)
							{
								class159_.Boolean_116 = true;
								class159_.Boolean_108 = true;
							}
							if (class4.String_0 != null)
							{
								class159_.method_48(Enum14.DatDoiAcBa, true);
								if (Class432.smethod_4(class4.String_0) > 0)
								{
									class159_.Int32_40 = Class432.smethod_4(class4.String_0);
								}
							}
							if (class4.Boolean_10)
							{
								class159_.method_48(Enum14.TrungAc, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_12)
							{
								class159_.method_305();
							}
							if (class4.Boolean_13)
							{
								class159_.method_48(Enum14.NhiemVuThangCap, true);
							}
							if (class4.Boolean_14)
							{
								class159_.method_48(Enum14.NhiemVuExp, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_15)
							{
								class159_.method_48(Enum14.NhanLeBao, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_17)
							{
								class159_.method_48(Enum14.NhanBoiThuong, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_18)
							{
								if (class159_.Int32_59 == 0)
								{
									class159_.method_160();
								}
								class159_.method_48(Enum14.DatDoiAcTac, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_19)
							{
								class159_.method_48(Enum14.DatDoiThieuThatSon, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_20)
							{
								class159_.method_48(Enum14.DatDoiLauLanTamBao, true);
								class159_.method_48(Enum14.DatDoiKyCuoc, true);
								class159_.Boolean_108 = true;
								class4.Boolean_20 = false;
							}
							if (class4.Boolean_9)
							{
								class159_.method_48(Enum14.BachHoaDuyen, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_22)
							{
								class159_.method_48(Enum14.GomDo, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_2)
							{
								class159_.method_48(Enum14.GomDo, true);
								class159_.method_48(Enum14.GomKNB, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_23)
							{
								class159_.method_48(Enum14.GomDoKNB, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_21)
							{
								class159_.method_48(Enum14.DiMuaNga, true);
							}
							if (class4.Boolean_32)
							{
								class159_.method_48(Enum14.Doi999HoaHong, true);
							}
							if (class4.Boolean_16)
							{
								class159_.method_48(Enum14.NhanBienThan, true);
							}
							if (class4.Boolean_25)
							{
								class159_.method_48(Enum14.NhanBong, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_31)
							{
								class159_.method_48(Enum14.BonHoa, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_24)
							{
								class159_.method_48(Enum14.NhanQuaBuiHoaHong, true);
								class159_.Boolean_108 = true;
							}
							if (class4.Boolean_28)
							{
								Class159 class5 = class159_;
								Class159 class6 = class159_;
								class159_.Boolean_108 = true;
								class6.Boolean_111 = true;
								class5.Boolean_108 = true;
								class159_.method_48(Enum14.NhanBong, true);
							}
							if (class4.Boolean_27)
							{
								Class159 class7 = class159_;
								Class159 class8 = class159_;
								class159_.Boolean_64 = true;
								class8.Boolean_112 = true;
								class7.Boolean_108 = true;
								class159_.method_48(Enum14.NhanBong, true);
							}
							if (class4.Boolean_26)
							{
								class159_.Boolean_26 = true;
							}
							if (class4.Boolean_29)
							{
								Class159 class9 = class159_;
								class159_.Boolean_109 = true;
								class9.Boolean_108 = true;
								class159_.method_48(Enum14.BachHoaDuyen, true);
								class159_.method_48(Enum14.BonHoa, true);
								class159_.method_48(Enum14.TrongHoa, true);
							}
							if (class4.bool_12)
							{
								class159_.Boolean_108 = true;
								class159_.method_48(Enum14.BonHoa, true);
								class159_.method_48(Enum14.TrongHoa, true);
							}
							if (class4.Boolean_30)
							{
								class159_.Boolean_108 = true;
								class159_.method_48(Enum14.NhanBienThan, true);
							}
							if (class4.Boolean_1)
							{
								class159_.method_48(Enum14.BachHoaDuyen, true);
								class159_.Boolean_110 = true;
							}
							if (class4.bool_13)
							{
								class159_.method_48(Enum14.BachHoaDuyen, true);
								class159_.Boolean_109 = true;
							}
						}
						if (class4.Boolean_3 && (class4.class159_0.Class432_0.Boolean_18 || class4.class159_0.Class432_0.Boolean_22))
						{
							class4.class159_0.Boolean_9 = false;
							if (!CalendarEx.bool_0 && class4.Boolean_0)
							{
								class4.String_20 = "Exit...";
							}
							else
							{
								class4.String_20 = "Đang chờ...";
							}
							class4.class159_0 = null;
							class4.Boolean_3 = false;
						}
						else if (class4.class159_0.Process_0.HasExited)
						{
							if (!CalendarEx.bool_0 && class4.Boolean_0)
							{
								class4.String_20 = "Exit...";
							}
							else
							{
								class4.String_20 = "Đang chờ...";
								class4.stopwatch_0 = Stopwatch.StartNew();
								class4.Boolean_33 = false;
							}
							class4.class159_0 = null;
							class4.Boolean_3 = false;
						}
						else if (!MicroLogin.Boolean_11 && class4.class159_0.bool_25)
						{
							class4.String_20 = "xong BHD";
							class4.class159_0 = null;
						}
						else
						{
							if (class4.Boolean_7)
							{
								class4.String_20 = "Captcha";
							}
							if (class4.Boolean_8)
							{
								class4.stopwatch_0 = Stopwatch.StartNew();
								if (class4.String_20 != "Online")
								{
									class4.String_20 = "Online";
								}
								class4.Boolean_33 = false;
								if (class4.String_14 != class159_.Class432_0.UInt32_2.ToString())
								{
									class4.String_14 = class159_.Class432_0.UInt32_2.ToString();
								}
								class4.Boolean_0 = true;
								if (MicroLogin.Boolean_4 && class4.Boolean_6 && (ulong)class4.class159_0.Class432_0.UInt32_2 >= (ulong)((long)MicroLogin.Int32_3))
								{
									class4.class159_0.bool_25 = true;
								}
								else
								{
									if (!class4.Boolean_5)
									{
										class4.Boolean_5 = true;
										if (!class4.String_9.Contains(class159_.Class432_0.String_1))
										{
											class4.String_9 = class159_.Class432_0.String_1;
										}
									}
									class4.bool_10 = false;
									class4.bool_4 = false;
									if (!class4.Boolean_6 && class159_.Boolean_65 && (class159_.Class432_0.UInt32_2 <= 10U || !(class159_.Class432_0.String_16 == "Không Có")))
									{
										if (!string.IsNullOrEmpty(class4.class159_0.Class432_0.String_2))
										{
											class4.Boolean_6 = true;
										}
										class4.String_8 = class4.class159_0.Class432_0.String_2;
										class4.String_14 = class4.class159_0.Class432_0.UInt32_2.ToString();
										class4.String_13 = class4.class159_0.Class432_0.UInt32_1.ToString();
									}
									class4.Boolean_3 = true;
								}
							}
							else
							{
								class4.Boolean_6 = false;
								if (!class4.class159_0.Class432_0.Boolean_51)
								{
									class4.String_20 = "Login";
								}
								if (class159_.Boolean_29)
								{
									if (!class159_.Class432_0.Boolean_24)
									{
										class4.stopwatch_3 = Stopwatch.StartNew();
									}
									if (!class159_.Class432_0.Boolean_22)
									{
										class4.Stopwatch_0 = Stopwatch.StartNew();
									}
									if (class159_.Class432_0.Boolean_17)
									{
										class159_.Class368_0.method_18();
									}
									else if (class159_.Class432_0.Boolean_18)
									{
										if (class4.stopwatch_0 == null || class4.stopwatch_0.Elapsed.TotalSeconds > (double)MicroLogin.int_9)
										{
											class4.bool_5 = false;
											Class145 class10 = class4;
											class4.bool_4 = false;
											class10.bool_10 = false;
											if (class4.Int32_0 != -1)
											{
												if (class159_.Class392_0.UInt32_106 == 1U)
												{
													if (class4.String_6 == "Thiên Long 15")
													{
														class159_.method_282("setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServerEvent_Area_SwitchPage(2);setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServerEvent_ServerBn_Clicked(" + 2.ToString() + ",0); SelectServerEvent_SelectOk();", false);
													}
													else if (class4.Int32_0 > 0)
													{
														class159_.method_282("setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServerEvent_Area_SwitchPage(6);setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServerEvent_ServerBn_Clicked(" + (class4.Int32_0 - 1).ToString() + ",0); SelectServerEvent_SelectOk();", false);
													}
												}
												else
												{
													class159_.method_282("setmetatable(_G, {__index = LoginSelectServer_Env}); local index = GameProduceLogin:GetServerAreaCount() - 1; setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServer_SelectAreaServer(index); setmetatable(_G, {__index = LoginSelectServer_Env}); SelectServer_ConfirmSelectLine(" + class4.Int32_0.ToString() + ");", false);
												}
											}
										}
									}
									else if (class159_.Class432_0.Boolean_22)
									{
										class4.stopwatch_1 = Stopwatch.StartNew();
										if (!class4.bool_10)
										{
											if (class4.Int32_1 != -1)
											{
												class159_.Class368_0.method_10(class4.Int32_1);
											}
											foreach (char int_ in class4.String_2)
											{
												Class438.PostMessage(class159_.IntPtr_0, 258, (int)int_, 0);
											}
											Class438.PostMessage(class159_.IntPtr_0, 256, 9, 0);
											Class438.PostMessage(class159_.IntPtr_0, 257, 9, 0);
											foreach (char int_2 in class4.String_4)
											{
												Class438.PostMessage(class159_.IntPtr_0, 258, (int)int_2, 0);
											}
											Class438.PostMessage(class159_.IntPtr_0, 256, 13, 0);
											Class438.PostMessage(class159_.IntPtr_0, 257, 13, 0);
											class4.bool_10 = true;
											class4.bool_4 = false;
											class4.bool_5 = false;
										}
										else
										{
											if (!Main.Boolean_13)
											{
												if (class4.Stopwatch_0.Elapsed.TotalSeconds < 22.0)
												{
													class4.class159_0.method_410("Auto tự chọn máy chủ sau " + ((int)(22.0 - class4.Stopwatch_0.Elapsed.TotalSeconds)).ToString() + " giây");
												}
												else
												{
													class4.bool_4 = true;
													class4.bool_10 = false;
													class4.int_2 = 0;
													class159_.Class368_0.method_12();
												}
											}
											if (!class159_.Class432_0.Boolean_23)
											{
												class4.int_2++;
												if (class4.int_2 > 10)
												{
													class4.int_2 = 0;
													Class438.PostMessage(class159_.IntPtr_0, 256, 13, 0);
													Class438.PostMessage(class159_.IntPtr_0, 257, 13, 0);
												}
											}
										}
									}
									else if (class159_.Class432_0.Boolean_24)
									{
										class4.bool_10 = false;
										class4.stopwatch_1 = Stopwatch.StartNew();
										if (!Main.Boolean_13)
										{
											if (class4.stopwatch_3.Elapsed.TotalSeconds > 30.0)
											{
												class4.bool_4 = false;
												class4.bool_10 = false;
												class4.bool_5 = false;
												class4.int_2 = 0;
												class159_.Class368_0.method_19();
											}
											else
											{
												class4.class159_0.method_410("Auto tự chọn máy chủ sau " + ((int)(30.0 - class4.stopwatch_3.Elapsed.TotalSeconds)).ToString() + " giây");
											}
										}
										if (!class4.bool_4)
										{
											if (!class4.bool_5)
											{
												if (class4.String_15 == "")
												{
													class159_.method_282("setmetatable(_G, {__index = LoginSelectRole_Env}); if this:IsVisible() then SelectRole_EnterGame(); end", false);
												}
												if (class4.String_15 != "")
												{
													if (class4.String_15 == "1")
													{
														class159_.method_282("setmetatable(_G, {__index = LoginSelectRole_Env}); if this:IsVisible() then strName ,iMenPai ,iLevel ,iDelTime ,strFaceImgName ,iCYGSate = GameProduceLogin:GetRoleInfo(0); if strName == nil or strName == '' then  SelectRole_DoubleClicked(0); else SelectRole_Clicked(0); GameProduceLogin:MoveToCharacter(0);  SelectRole_EnterGame();  end end", false);
													}
													else if (class4.String_15 == "2")
													{
														class159_.method_282("setmetatable(_G, {__index = LoginSelectRole_Env}); if this:IsVisible() then strName ,iMenPai ,iLevel ,iDelTime ,strFaceImgName ,iCYGSate = GameProduceLogin:GetRoleInfo(1); if strName == nil or strName == '' then  SelectRole_DoubleClicked(1); else SelectRole_Clicked(1); GameProduceLogin:MoveToCharacter(0);  SelectRole_EnterGame();  end end", false);
													}
													else if (class4.String_15 == "3")
													{
														class159_.method_282("setmetatable(_G, {__index = LoginSelectRole_Env}); if this:IsVisible() then strName ,iMenPai ,iLevel ,iDelTime ,strFaceImgName ,iCYGSate = GameProduceLogin:GetRoleInfo(2); if strName == nil or strName == '' then  SelectRole_DoubleClicked(2); else SelectRole_Clicked(2); GameProduceLogin:MoveToCharacter(0);  SelectRole_EnterGame();  end end", false);
													}
												}
												class4.bool_5 = true;
												class4.bool_4 = false;
											}
											else
											{
												class4.bool_4 = false;
											}
										}
									}
									else if (class159_.Class432_0.Boolean_25)
									{
										if (Class268.Boolean_70 && Setting.smethod_0("chkAutoCreatePlayer") && class4.stopwatch_1.Elapsed.TotalSeconds > 15.0 && !class4.Boolean_33)
										{
											class4.Boolean_33 = true;
											string string_ = "setmetatable(_G, {__index = LoginCreateRole_Env}); if this:IsVisible() then GameProduceLogin:SetFaceId(0, 1); GameProduceLogin:CreateRole('" + Class426.smethod_56(Class426.random_2.Next(3, 5)) + Class426.smethod_56(Class426.random_2.Next(3, 5)) + "',0) end";
											class159_.method_282(string_, false);
											class4.stopwatch_1 = Stopwatch.StartNew();
										}
										if (class4.stopwatch_1.Elapsed.TotalSeconds > 100.0)
										{
											class4.Boolean_33 = false;
											class4.bool_4 = false;
											class4.bool_10 = false;
											class4.int_2 = 0;
											class159_.Class368_0.method_19();
										}
										else
										{
											class4.class159_0.method_410("Auto tự chọn máy chủ sau " + ((int)(100.0 - class4.stopwatch_1.Elapsed.TotalSeconds)).ToString() + " giây");
										}
									}
								}
							}
						}
					}
				}
				else
				{
					class4.Boolean_3 = false;
				}
			}
		}
	}

	// Token: 0x170006B9 RID: 1721
	// (get) Token: 0x06001D66 RID: 7526 RVA: 0x00015AB6 File Offset: 0x00013CB6
	// (set) Token: 0x06001D67 RID: 7527 RVA: 0x00015ABE File Offset: 0x00013CBE
	public int Int32_1 { get; set; }

	// Token: 0x170006BA RID: 1722
	// (get) Token: 0x06001D68 RID: 7528 RVA: 0x00015AC7 File Offset: 0x00013CC7
	// (set) Token: 0x06001D69 RID: 7529 RVA: 0x00015ACF File Offset: 0x00013CCF
	public List<Class145> List_1 { get; set; } = new List<Class145>();

	// Token: 0x06001D6A RID: 7530 RVA: 0x00015AD8 File Offset: 0x00013CD8
	private void method_4(object sender, EventArgs e)
	{
		this.method_5();
	}

	// Token: 0x06001D6B RID: 7531 RVA: 0x00015AE0 File Offset: 0x00013CE0
	private void method_5()
	{
		base.Enabled = false;
		Task.Run(new Action(this.method_20));
	}

	// Token: 0x06001D6C RID: 7532 RVA: 0x000DA4BC File Offset: 0x000D86BC
	private void method_6(object sender, EventArgs e)
	{
		Class412 @class = (Class412)sender;
		if (@class.Boolean_2)
		{
			this.method_5();
			return;
		}
		base.Enabled = true;
		MessageBox.Show(this, @class.String_2, "MicroAuto", MessageBoxButtons.OK);
		TabLogin.bool_4 = true;
	}

	// Token: 0x06001D6D RID: 7533 RVA: 0x000DA500 File Offset: 0x000D8700
	private void TabLogin_Load(object sender, EventArgs e)
	{
		this.lvLogin.Columns[2].DisplayIndex = 3;
		this.lvLogin.Columns[3].DisplayIndex = 2;
		this.txtLimit.Text = MicroLogin.Int32_0.ToString();
		if (MicroLogin.Int32_0.ToString() == "0")
		{
			this.txtLimit.Text = "";
		}
		foreach (string text in Class159.Class220_0.method_0("Config", "Column").Split(new char[]
		{
			','
		}))
		{
			if (text == "1")
			{
				this.userToolStripMenuItem.Checked = true;
			}
			if (text == "3")
			{
				this.serverToolStripMenuItem.Checked = true;
			}
			if (text == "7")
			{
				this.toolStripMenuItem_49.Checked = true;
			}
			if (text == "8")
			{
				this.shitToolStripMenuItem.Checked = true;
			}
			if (text == "9")
			{
				this.toolStripMenuItem_50.Checked = true;
			}
			if (text == "10")
			{
				this.infoToolStripMenuItem.Checked = true;
			}
			this.list_4.Remove(text.smethod_18());
		}
		this.lvLogin.Columns.Cast<ColumnHeader>().smethod_13(new Action<ColumnHeader>(this.method_21));
		this.method_9();
	}

	// Token: 0x06001D6E RID: 7534 RVA: 0x000DA688 File Offset: 0x000D8888
	public void method_7(object sender, EventArgs e)
	{
		MicroLogin.MicroLogin_0.splitContainer1.Visible = true;
		try
		{
			base.Parent.Tag = "loged";
			LoginUser loginUser = null;
			if (sender != null)
			{
				loginUser = (sender as LoginUser);
				this.xmlDocument_0 = loginUser.xmlDocument_0;
				this.string_0 = loginUser.String_1;
			}
			if (this.string_0 == "Offline")
			{
				TabLogin.tabLogin_0 = this;
				base.Parent.Text = "Offline";
				this.List_1 = MicroLogin.List_0;
			}
			else
			{
				this.string_1 = loginUser.String_0;
				this.class145_0 = new Class145(this.xmlDocument_0, this.string_1);
				this.List_1 = this.class145_0.method_6();
			}
			this.lvLogin.Items.Clear();
			this.method_1();
			this.method_11();
			this.txtSearch.String_0 = "Search... [" + this.string_0.Trim() + "]";
			TabLogin.List_0.Add(this);
			this.panel1.Visible = true;
		}
		catch
		{
		}
	}

	// Token: 0x06001D6F RID: 7535 RVA: 0x000DA7B0 File Offset: 0x000D89B0
	public void method_8()
	{
		if (MicroLogin.MicroLogin_0.CboNPH.Text == "")
		{
			MessageBox.Show(this, "Vui lòng chọn nhà phát hành", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		if (MicroLogin.MicroLogin_0.CboServer.Text == "")
		{
			MessageBox.Show(this, "Vui lòng chọn server", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		if (MicroLogin.MicroLogin_0.TxtUser.Text == "")
		{
			MessageBox.Show(this, "Vui lòng điền user đăng nhập", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		if (MicroLogin.MicroLogin_0.TxtPass.Text == "")
		{
			MessageBox.Show(this, "Vui lòng điền mật khẩu đăng nhập", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		string a = "";
		try
		{
			a = Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + MicroLogin.MicroLogin_0.CboNPH.Text + "\"]").Attributes["Path"].Value;
		}
		catch
		{
		}
		if (a == "")
		{
			MessageBox.Show(this, "Bạn cần phải chọn đường dẫn gameạn cần phải chọn đường dẫn game\r\nFile Game.exe nằm trong thư mục Bin của game", "MicroAuto", MessageBoxButtons.OK);
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Game.exe |Game.exe";
			if (openFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				try
				{
					Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + MicroLogin.MicroLogin_0.CboNPH.Text + "\"]").Attributes["Path"].Value = openFileDialog.FileName;
					Publisher.smethod_1();
					goto IL_1E2;
				}
				catch
				{
					XmlAttribute xmlAttribute = Publisher.xmlDocument_0.CreateAttribute("Path");
					xmlAttribute.Value = openFileDialog.FileName;
					Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + MicroLogin.MicroLogin_0.CboNPH.Text + "\"]").Attributes.Append(xmlAttribute);
					Publisher.smethod_1();
					goto IL_1E2;
				}
			}
			return;
		}
		IL_1E2:
		Class145 @class = new Class145(MicroLogin.MicroLogin_0.TxtUser.Text, MicroLogin.MicroLogin_0.TxtPass.Text, MicroLogin.MicroLogin_0.CboNPH.Text, MicroLogin.MicroLogin_0.CboServer.Text, MicroLogin.MicroLogin_0.CboTail.Text, "", "", this.xmlDocument_0, this.string_1);
		@class.listViewItem_0 = new ListViewItem((this.List_1.Count + 1).ToString());
		@class.listViewItem_0.SubItems.Add(@class.String_2);
		@class.listViewItem_0.SubItems.Add(@class.String_8);
		@class.listViewItem_0.SubItems.Add(@class.String_6);
		@class.listViewItem_0.SubItems.Add(@class.String_15);
		@class.listViewItem_0.SubItems.Add(@class.String_20);
		@class.listViewItem_0.SubItems.Add(@class.String_14);
		@class.listViewItem_0.SubItems.Add(@class.String_16);
		@class.listViewItem_0.SubItems.Add(@class.String_17);
		@class.listViewItem_0.SubItems.Add(@class.String_18);
		@class.listViewItem_0.SubItems.Add(@class.String_12);
		@class.listViewItem_0.Tag = @class;
		this.List_1.Add(@class);
		this.method_11();
		if (this.string_0 == "Offline")
		{
			MicroLogin.MicroLogin_0.method_1();
		}
	}

	// Token: 0x06001D70 RID: 7536 RVA: 0x000DAB64 File Offset: 0x000D8D64
	private void lvLogin_DoubleClick(object sender, EventArgs e)
	{
		if (this.ListViewItem_0 == null)
		{
			return;
		}
		Class145 @class = (Class145)this.ListViewItem_0.Tag;
		if (!(@class.String_20 == "xong BHD") && !(@class.String_20 == "xong BTD"))
		{
			if (@class.class159_0 != null && !(@class.String_20 == "Exit..."))
			{
				@class.class159_0.method_223();
			}
			else if (@class.String_20 == "" || @class.String_20 == "Exit..." || @class.String_20 == "...")
			{
				@class.String_20 = "Đang chờ...";
				@class.Boolean_4 = true;
				return;
			}
			return;
		}
		try
		{
			@class.class159_0.method_223();
		}
		catch
		{
		}
	}

	// Token: 0x06001D71 RID: 7537 RVA: 0x00015AFB File Offset: 0x00013CFB
	private void lvLogin_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.timer_1.Stop();
		this.timer_1.Start();
	}

	// Token: 0x06001D72 RID: 7538 RVA: 0x000DAC44 File Offset: 0x000D8E44
	private void lvLogin_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Delete)
		{
			this.toolStripMenuItem27_Click(null, null);
		}
		if (e.KeyCode == Keys.Return)
		{
			foreach (ListViewItem listViewItem in this.IEnumerable_0)
			{
				Class145 @class = (Class145)listViewItem.Tag;
				if (@class.class159_0 == null)
				{
					@class.String_20 = "Đang chờ...";
				}
			}
		}
		if (e.KeyCode == Keys.A && e.Control)
		{
			this.lvLogin.smethod_12();
		}
		if (e.Control)
		{
			if (e.KeyCode == Keys.Up && this.IEnumerable_1.Count<Class145>() > 0)
			{
				int num = this.List_1.FindIndex(new Predicate<Class145>(this.method_22));
				List<Class145> list = this.IEnumerable_1.ToList<Class145>();
				if (this.string_0 == "Offline")
				{
					MicroLogin.List_0 = this.List_1.Except(list).ToList<Class145>();
					list.Reverse();
					foreach (Class145 item in list)
					{
						MicroLogin.List_0.Insert(num - 1, item);
					}
					this.List_1 = MicroLogin.List_0;
				}
				else
				{
					this.List_1 = this.List_1.Except(list).ToList<Class145>();
					list.Reverse();
					foreach (Class145 item2 in list)
					{
						this.List_1.Insert(num - 1, item2);
					}
				}
				this.method_11();
				this.lvLogin.SelectedIndices.Clear();
			}
			if (e.KeyCode == Keys.Down && this.IEnumerable_1.Count<Class145>() > 0)
			{
				int num2 = this.List_1.FindIndex(new Predicate<Class145>(this.method_23));
				List<Class145> list2 = this.IEnumerable_1.ToList<Class145>();
				if (this.string_0 == "Offline")
				{
					MicroLogin.List_0 = this.List_1.Except(list2).ToList<Class145>();
					list2.Reverse();
					foreach (Class145 item3 in list2)
					{
						MicroLogin.List_0.Insert(num2 + 1, item3);
					}
					this.List_1 = MicroLogin.List_0;
				}
				else
				{
					this.List_1 = this.List_1.Except(list2).ToList<Class145>();
					list2.Reverse();
					foreach (Class145 item4 in list2)
					{
						this.List_1.Insert(num2 + 1, item4);
					}
				}
				this.method_11();
				this.lvLogin.SelectedIndices.Clear();
			}
			if (e.KeyCode == Keys.X)
			{
				this.cutToolStripMenuItem1_Click(null, null);
			}
			if (e.KeyCode == Keys.C)
			{
				this.toolStripMenuItem25_Click(null, null);
			}
			if (e.KeyCode == Keys.V)
			{
				this.toolStripMenuItem26_Click(null, null);
			}
		}
	}

	// Token: 0x170006BB RID: 1723
	// (get) Token: 0x06001D73 RID: 7539 RVA: 0x00015B13 File Offset: 0x00013D13
	// (set) Token: 0x06001D74 RID: 7540 RVA: 0x00015B1B File Offset: 0x00013D1B
	private bool Boolean_0 { get; set; }

	// Token: 0x06001D75 RID: 7541 RVA: 0x00015B24 File Offset: 0x00013D24
	private void chkStop_CheckedChanged(object sender, EventArgs e)
	{
		this.int_1 = (int)this.nudStop.Value;
		this.stopwatch_0 = Stopwatch.StartNew();
		this.Boolean_0 = this.chkStop.Checked;
	}

	// Token: 0x06001D76 RID: 7542 RVA: 0x00015B58 File Offset: 0x00013D58
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.method_11();
	}

	// Token: 0x06001D77 RID: 7543 RVA: 0x00015B60 File Offset: 0x00013D60
	private void nudStop_ValueChanged(object sender, EventArgs e)
	{
		this.int_1 = (int)this.nudStop.Value;
		this.stopwatch_0 = Stopwatch.StartNew();
	}

	// Token: 0x06001D78 RID: 7544 RVA: 0x000DAFB0 File Offset: 0x000D91B0
	private void method_9()
	{
		int num = 0;
		for (;;)
		{
			IEnumerable<ColumnHeader> source = this.lvLogin.Columns.Cast<ColumnHeader>();
			Func<ColumnHeader, int> selector;
			if ((selector = TabLogin.Class252.<>9__52_0) == null)
			{
				goto IL_D4;
			}
			IL_1D:
			if (source.Sum(selector) + 40 < base.Width)
			{
				break;
			}
			using (IEnumerator<ColumnHeader> enumerator = this.lvLogin.Columns.Cast<ColumnHeader>().Reverse<ColumnHeader>().OrderByDescending(new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_8)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ColumnHeader columnHeader = enumerator.Current;
					if (!this.list_4.Contains(columnHeader.Index) && columnHeader.Width > 0)
					{
						columnHeader.Tag = columnHeader.Width;
						columnHeader.Width = 0;
						this.list_2.Add(columnHeader.Index);
						break;
					}
				}
				goto IL_F0;
			}
			goto IL_D4;
			IL_F0:
			if (num++ > this.lvLogin.Columns.Count)
			{
				break;
			}
			continue;
			IL_D4:
			selector = (TabLogin.Class252.<>9__52_0 = new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_9));
			goto IL_1D;
		}
		num = 0;
		for (;;)
		{
			IEnumerable<ColumnHeader> source2 = this.lvLogin.Columns.Cast<ColumnHeader>();
			Func<ColumnHeader, int> selector2;
			if ((selector2 = TabLogin.Class252.<>9__52_1) == null)
			{
				goto IL_28A;
			}
			IL_127:
			if (source2.Sum(selector2) + 40 >= base.Width)
			{
				break;
			}
			using (IEnumerator<ColumnHeader> enumerator = this.lvLogin.Columns.Cast<ColumnHeader>().OrderBy(new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_10)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ColumnHeader columnHeader2 = enumerator.Current;
					if (!this.list_4.Contains(columnHeader2.Index))
					{
						if (this.lvLogin.Columns.Cast<ColumnHeader>().Sum(new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_11)) + 40 >= base.Width)
						{
							break;
						}
						if (columnHeader2.Width == 0 && columnHeader2.Tag != null)
						{
							if (this.lvLogin.Columns.Cast<ColumnHeader>().Sum(new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_12)) + 40 + columnHeader2.Tag.ToString().smethod_18() < base.Width)
							{
								this.list_2.Remove(columnHeader2.Index);
								columnHeader2.Width = columnHeader2.Tag.ToString().smethod_18();
								columnHeader2.Tag = columnHeader2.Width;
								break;
							}
						}
					}
				}
				goto IL_2A6;
			}
			goto IL_28A;
			IL_2A6:
			if (num++ > this.lvLogin.Columns.Count)
			{
				break;
			}
			continue;
			IL_28A:
			selector2 = (TabLogin.Class252.<>9__52_1 = new Func<ColumnHeader, int>(TabLogin.Class252.<>9.method_13));
			goto IL_127;
		}
	}

	// Token: 0x06001D79 RID: 7545 RVA: 0x000DB2B4 File Offset: 0x000D94B4
	private void lvLogin_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
	{
		if (this.lvLogin.Columns[e.ColumnIndex].Width == 0 && this.list_2.Contains(e.ColumnIndex))
		{
			e.Cancel = true;
			e.NewWidth = this.lvLogin.Columns[e.ColumnIndex].Width;
		}
		if (e.ColumnIndex == 1 || this.list_4.Contains(e.ColumnIndex))
		{
			e.Cancel = true;
			e.NewWidth = this.lvLogin.Columns[e.ColumnIndex].Width;
		}
	}

	// Token: 0x06001D7A RID: 7546 RVA: 0x00015AD8 File Offset: 0x00013CD8
	private void method_10(object sender, EventArgs e)
	{
		this.method_5();
	}

	// Token: 0x06001D7B RID: 7547 RVA: 0x000DB360 File Offset: 0x000D9560
	private void method_11()
	{
		try
		{
			if (this.thread_1 != null)
			{
				if (this.thread_1.IsAlive)
				{
					this.thread_1.Abort();
					this.thread_1 = null;
				}
				this.thread_1 = null;
			}
			if (this.thread_1 == null)
			{
				this.thread_1 = new Thread(new ThreadStart(this.method_24));
				this.thread_1.Start();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001D7C RID: 7548 RVA: 0x000DB3DC File Offset: 0x000D95DC
	private void lvLogin_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
	{
		if (this.list_3.Count >= e.ItemIndex)
		{
			Class145 @class = this.list_3[e.ItemIndex];
			if (@class.listViewItem_0 == null)
			{
				@class.listViewItem_0 = new ListViewItem((e.ItemIndex + 1).ToString());
				@class.listViewItem_0.SubItems.Add(@class.String_2);
				@class.listViewItem_0.SubItems.Add(@class.String_8);
				@class.listViewItem_0.SubItems.Add(@class.String_6);
				@class.listViewItem_0.SubItems.Add(@class.String_15);
				@class.listViewItem_0.SubItems.Add(@class.String_20);
				@class.listViewItem_0.SubItems.Add(@class.String_14);
				@class.listViewItem_0.SubItems.Add(@class.String_16);
				@class.listViewItem_0.SubItems.Add(@class.String_17);
				@class.listViewItem_0.SubItems.Add(@class.String_18);
				@class.listViewItem_0.SubItems.Add(@class.String_12);
				@class.listViewItem_0.Tag = @class;
			}
			e.Item = @class.listViewItem_0;
		}
	}

	// Token: 0x170006BC RID: 1724
	// (get) Token: 0x06001D7D RID: 7549 RVA: 0x00015B83 File Offset: 0x00013D83
	public IEnumerable<ListViewItem> IEnumerable_0
	{
		get
		{
			TabLogin.Class256 @class = new TabLogin.Class256(-2);
			@class.tabLogin_0 = this;
			return @class;
		}
	}

	// Token: 0x170006BD RID: 1725
	// (get) Token: 0x06001D7E RID: 7550 RVA: 0x00015B93 File Offset: 0x00013D93
	public IEnumerable<Class145> IEnumerable_1
	{
		get
		{
			TabLogin.Class257 @class = new TabLogin.Class257(-2);
			@class.tabLogin_0 = this;
			return @class;
		}
	}

	// Token: 0x170006BE RID: 1726
	// (get) Token: 0x06001D7F RID: 7551 RVA: 0x000DB538 File Offset: 0x000D9738
	public ListViewItem ListViewItem_0
	{
		get
		{
			using (IEnumerator enumerator = this.lvLogin.SelectedIndices.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					int index = (int)enumerator.Current;
					return this.lvLogin.Items[index];
				}
			}
			return null;
		}
	}

	// Token: 0x06001D80 RID: 7552 RVA: 0x000DB5A4 File Offset: 0x000D97A4
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.lvLogin.Columns[0].Text = "[" + this.list_3.Count.ToString() + "]";
		this.lvLogin.Refresh();
	}

	// Token: 0x06001D81 RID: 7553 RVA: 0x000DB5F4 File Offset: 0x000D97F4
	private void timer_1_Tick(object sender, EventArgs e)
	{
		if (this.ListViewItem_0 == null)
		{
			return;
		}
		Class145 @class = (Class145)this.ListViewItem_0.Tag;
		MicroLogin.MicroLogin_0.TxtUser.Text = @class.String_2;
		MicroLogin.MicroLogin_0.TxtPass.Text = @class.String_4;
		MicroLogin.MicroLogin_0.CboNPH.SelectedIndex = MicroLogin.MicroLogin_0.CboNPH.FindString(@class.String_5);
		MicroLogin.MicroLogin_0.CboServer.SelectedIndex = MicroLogin.MicroLogin_0.CboServer.FindString(@class.String_6);
		MicroLogin.MicroLogin_0.CboTail.SelectedIndex = MicroLogin.MicroLogin_0.CboTail.FindString(@class.String_7);
		this.timer_1.Stop();
	}

	// Token: 0x06001D82 RID: 7554 RVA: 0x000DB6BC File Offset: 0x000D98BC
	private void menuListView_Opening(object sender, CancelEventArgs e)
	{
		try
		{
			this.muChuyenServer.DropDownItems.Clear();
			foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + MicroLogin.MicroLogin_0.CboNPH.Text + "\"]/Servers").SelectNodes("Server"))
			{
				XmlNode xmlNode = (XmlNode)obj;
				TabLogin.Class258 @class = new TabLogin.Class258();
				@class.tabLogin_0 = this;
				@class.toolStripMenuItem_0 = new ToolStripMenuItem(xmlNode.InnerText);
				this.muChuyenServer.DropDownItems.Add(@class.toolStripMenuItem_0);
				@class.toolStripMenuItem_0.Click += @class.method_0;
			}
		}
		catch
		{
		}
		this.toolStripMenuItem_2.Enabled = Class268.Boolean_20;
		this.toolStripMenuItem_1.Enabled = Class268.Boolean_22;
		if (User.Boolean_1)
		{
			this.toolStripMenuItem_15.Text = "Select Server";
		}
		this.toolStripMenuItem_0.Visible = Class268.Boolean_27;
		this.toolStripMenuItem23.Text = "Refresh [" + this.lvLogin.SelectedIndices.Count.ToString() + "]";
		this.toolStripMenuItem_3.Visible = Class268.Boolean_16;
		this.toolStripMenuItem_17.Visible = (this.toolStripMenuItem_4.Visible = Class268.Boolean_16);
		this.muNhanThoiBong.Visible = Class268.Boolean_69;
		this.toolStripMenuItem_32.Text = "Tạo Nhóm [" + this.IEnumerable_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_14)).Count<Class145>().ToString() + "]";
		try
		{
			if (this.lvLogin.PointToClient(Cursor.Position).Y <= 22)
			{
				using (IEnumerator enumerator = this.menuListView.Items.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj2 = enumerator.Current;
						ToolStripItem toolStripItem = (ToolStripItem)obj2;
						if (toolStripItem.Tag == null)
						{
							toolStripItem.Visible = false;
						}
						else if (toolStripItem.Tag.ToString() == "cl")
						{
							toolStripItem.Visible = true;
						}
						else
						{
							toolStripItem.Visible = false;
						}
					}
					goto IL_2E1;
				}
			}
			foreach (object obj3 in this.menuListView.Items)
			{
				ToolStripItem toolStripItem2 = (ToolStripItem)obj3;
				if (toolStripItem2.Tag == null)
				{
					toolStripItem2.Visible = true;
				}
				else if (toolStripItem2.Tag.ToString() == "cl")
				{
					toolStripItem2.Visible = false;
				}
				else
				{
					toolStripItem2.Visible = true;
				}
			}
			IL_2E1:;
		}
		catch
		{
		}
	}

	// Token: 0x06001D83 RID: 7555 RVA: 0x000DBA2C File Offset: 0x000D9C2C
	private void method_12(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			if (@class.class159_0 == null)
			{
				@class.String_20 = "Đang chờ làm Q Dưa...";
				@class.Boolean_11 = true;
			}
			else
			{
				@class.class159_0.Boolean_116 = true;
			}
		}
	}

	// Token: 0x06001D84 RID: 7556 RVA: 0x00015BA3 File Offset: 0x00013DA3
	private void toolStripMenuItem20_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_15));
	}

	// Token: 0x06001D85 RID: 7557 RVA: 0x000DBA9C File Offset: 0x000D9C9C
	private void toolStripMenuItem21_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			@class.String_20 = "Đang chờ làm BHD...";
			@class.Boolean_22 = true;
		}
	}

	// Token: 0x06001D86 RID: 7558 RVA: 0x000DBAF4 File Offset: 0x000D9CF4
	private void treoShopChoTaToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			@class.String_20 = "Đang chờ làm BHD...";
			@class.Boolean_23 = true;
		}
	}

	// Token: 0x06001D87 RID: 7559 RVA: 0x000DBB4C File Offset: 0x000D9D4C
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			@class.String_20 = "Đang chờ làm BHD...";
			@class.Boolean_24 = true;
		}
	}

	// Token: 0x06001D88 RID: 7560 RVA: 0x00015BD4 File Offset: 0x00013DD4
	private void toolStripMenuItem_1_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_16));
	}

	// Token: 0x06001D89 RID: 7561 RVA: 0x00015C05 File Offset: 0x00013E05
	private void toolStripMenuItem_2_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_17));
	}

	// Token: 0x06001D8A RID: 7562 RVA: 0x00015C36 File Offset: 0x00013E36
	private void toolStripMenuItem_3_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_18));
	}

	// Token: 0x06001D8B RID: 7563 RVA: 0x00015C67 File Offset: 0x00013E67
	private void toolStripMenuItem_4_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_19));
	}

	// Token: 0x06001D8C RID: 7564 RVA: 0x00015C98 File Offset: 0x00013E98
	private void muNhanThoiBong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_20));
	}

	// Token: 0x06001D8D RID: 7565 RVA: 0x000DBBA4 File Offset: 0x000D9DA4
	private void toolStripMenuItem_5_Click(object sender, EventArgs e)
	{
		List<Class145> list = new List<Class145>();
		List<string> list2 = new List<string>();
		foreach (Class145 @class in this.List_1)
		{
			string item = string.Concat(new string[]
			{
				@class.String_2,
				"|",
				@class.String_4,
				"|",
				@class.String_5,
				"|",
				@class.String_6,
				"|",
				@class.String_15
			});
			if (!list2.Contains(item))
			{
				list2.Add(item);
			}
			else
			{
				list.Add(@class);
			}
		}
		if (list.Count > 0)
		{
			if (MessageBox.Show(this, "Có " + list.Count.ToString() + " tài khoản trùng\r\nBạn có muốn di chuyển xuống dưới không", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				if (this.string_0 == "Offline")
				{
					MicroLogin.List_0 = this.List_1.Except(list).ToList<Class145>();
					MicroLogin.List_0.AddRange(list);
					this.List_1 = MicroLogin.List_0;
				}
				else
				{
					this.List_1 = this.List_1.Except(list).ToList<Class145>();
					this.List_1.AddRange(list);
				}
				if (this.string_0 == "Offline")
				{
					MicroLogin.MicroLogin_0.method_1();
				}
				MessageBox.Show(this, "Đã di chuyển " + list.Count.ToString() + " tài khoản trùng xuống dưới", "MicroAuto", MessageBoxButtons.OK);
			}
		}
		else
		{
			MessageBox.Show(this, "Không có tải khoản trùng", "MicroAuto", MessageBoxButtons.OK);
		}
		this.method_11();
	}

	// Token: 0x06001D8E RID: 7566 RVA: 0x000DBD78 File Offset: 0x000D9F78
	private void toolStripMenuItem_6_Click(object sender, EventArgs e)
	{
		List<Class145> list = new List<Class145>();
		List<string> list2 = new List<string>();
		foreach (Class145 @class in this.List_1)
		{
			string item = string.Concat(new string[]
			{
				@class.String_2,
				"|",
				@class.String_4,
				"|",
				@class.String_5,
				"|",
				@class.String_6,
				"|",
				@class.String_15
			});
			if (!list2.Contains(item))
			{
				list2.Add(item);
			}
			else
			{
				list.Add(@class);
			}
		}
		if (list.Count > 0)
		{
			if (MessageBox.Show(this, "Có " + list.Count.ToString() + " tài khoản trùng\r\nBạn có muốn xóa không", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				if (this.string_0 == "Offline")
				{
					MicroLogin.List_0 = this.List_1.Except(list).ToList<Class145>();
					this.List_1 = MicroLogin.List_0;
				}
				else
				{
					this.List_1 = this.List_1.Except(list).ToList<Class145>();
				}
				if (this.string_0 == "Offline")
				{
					MicroLogin.MicroLogin_0.method_1();
				}
				MessageBox.Show(this, "Đã xóa " + list.Count.ToString() + " tài khoản trùng lặp", "MicroAuto", MessageBoxButtons.OK);
			}
		}
		else
		{
			MessageBox.Show(this, "Không có tải khoản trùng", "MicroAuto", MessageBoxButtons.OK);
		}
		this.method_11();
	}

	// Token: 0x06001D8F RID: 7567 RVA: 0x000DBF34 File Offset: 0x000DA134
	private void toolStripMenuItem_7_Click(object sender, EventArgs e)
	{
		if (this.string_0 == "Offline")
		{
			MicroLogin.List_0 = this.List_1.Except(this.IEnumerable_1).ToList<Class145>();
			MicroLogin.List_0.AddRange(this.IEnumerable_1);
			this.List_1 = MicroLogin.List_0;
		}
		else
		{
			this.List_1 = this.List_1.Except(this.IEnumerable_1).ToList<Class145>();
			this.List_1.AddRange(this.IEnumerable_1);
		}
		this.method_11();
		if (this.string_0 == "Offline")
		{
			MicroLogin.MicroLogin_0.method_1();
		}
	}

	// Token: 0x06001D90 RID: 7568 RVA: 0x000DBFDC File Offset: 0x000DA1DC
	private void toolStripMenuItem_8_Click(object sender, EventArgs e)
	{
		try
		{
			if (this.string_0 == "Offline")
			{
				MicroLogin.List_0 = this.List_1.Except(this.IEnumerable_1).ToList<Class145>();
				MicroLogin.List_0.InsertRange(0, this.IEnumerable_1);
				this.List_1 = MicroLogin.List_0;
			}
			else
			{
				this.List_1 = this.List_1.Except(this.IEnumerable_1).ToList<Class145>();
				this.List_1.InsertRange(0, this.IEnumerable_1);
			}
			this.method_11();
			if (this.string_0 == "Offline")
			{
				MicroLogin.MicroLogin_0.method_1();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message + ":" + ex.StackTrace);
		}
	}

	// Token: 0x06001D91 RID: 7569 RVA: 0x000DC0B8 File Offset: 0x000DA2B8
	private void toolStripMenuItem_9_Click(object sender, EventArgs e)
	{
		this.lvLogin.BeginUpdate();
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_21));
		this.lvLogin.EndUpdate();
	}

	// Token: 0x06001D92 RID: 7570 RVA: 0x000DC10C File Offset: 0x000DA30C
	private void cleanNameToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvLogin.BeginUpdate();
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_22));
		this.lvLogin.EndUpdate();
	}

	// Token: 0x06001D93 RID: 7571 RVA: 0x00015CC9 File Offset: 0x00013EC9
	private void toolStripMenuItem_11_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_23));
	}

	// Token: 0x06001D94 RID: 7572 RVA: 0x00015CFA File Offset: 0x00013EFA
	private void toolStripMenuItem_12_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_24));
	}

	// Token: 0x06001D95 RID: 7573 RVA: 0x00015D2B File Offset: 0x00013F2B
	private void toolStripMenuItem_13_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_25));
	}

	// Token: 0x06001D96 RID: 7574 RVA: 0x00015D5C File Offset: 0x00013F5C
	private void toolStripMenuItem_14_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_26));
	}

	// Token: 0x06001D97 RID: 7575 RVA: 0x000DC160 File Offset: 0x000DA360
	private void toolStripMenuItem_15_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_27)).smethod_13(new Action<Class145>(TabLogin.Class252.<>9.method_28));
	}

	// Token: 0x06001D98 RID: 7576 RVA: 0x000DC1BC File Offset: 0x000DA3BC
	private void toolStripMenuItem_16_Click(object sender, EventArgs e)
	{
		foreach (IEnumerable<Class145> source in this.IEnumerable_1.ToArray<Class145>().smethod_27(6))
		{
			Setting.Dictionary_0[source.FirstOrDefault<Class145>().String_8] = source.Select(new Func<Class145, string>(TabLogin.Class252.<>9.method_29)).ToList<string>();
		}
	}

	// Token: 0x06001D99 RID: 7577 RVA: 0x000DC250 File Offset: 0x000DA450
	private void toolStripMenuItem_17_Click(object sender, EventArgs e)
	{
		Main.list_3.Clear();
		if (this.IEnumerable_0.Count<ListViewItem>() > 1)
		{
			Main.Main_0.timer_3.Start();
			Main.int_9 = Class380.int_1;
			Class268.list_0.Clear();
			foreach (ListViewItem listViewItem in this.IEnumerable_0)
			{
				Class159 class159_ = ((Class145)listViewItem.Tag).class159_0;
				Main.list_3.Add(class159_);
				class159_.Boolean_81 = true;
				class159_.string_23 = "";
				Class268.list_0.Add(class159_.Class432_0.String_2);
			}
			return;
		}
	}

	// Token: 0x06001D9A RID: 7578 RVA: 0x000DC318 File Offset: 0x000DA518
	private void loginAccLvl30ToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			if (@class.class159_0 == null && Class426.smethod_41(@class.String_14) < 30)
			{
				@class.String_20 = "Đang chờ...";
			}
		}
	}

	// Token: 0x06001D9B RID: 7579 RVA: 0x000DC384 File Offset: 0x000DA584
	private void toolStripMenuItem_18_Click(object sender, EventArgs e)
	{
		if (this.string_0 == "Offline")
		{
			MicroLogin.List_0 = this.List_1.OrderBy(new Func<Class145, Guid>(TabLogin.Class252.<>9.method_30)).ToList<Class145>();
			this.List_1 = MicroLogin.List_0;
		}
		else
		{
			this.List_1 = this.List_1.OrderBy(new Func<Class145, Guid>(TabLogin.Class252.<>9.method_31)).ToList<Class145>();
		}
		this.method_11();
	}

	// Token: 0x06001D9C RID: 7580 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_13(object sender, EventArgs e)
	{
	}

	// Token: 0x06001D9D RID: 7581 RVA: 0x000DC420 File Offset: 0x000DA620
	private void toolStripMenuItem_19_Click(object sender, EventArgs e)
	{
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		int num5 = 0;
		int num6 = 0;
		foreach (Class145 @class in this.List_1)
		{
			if (@class.String_16 != "0")
			{
				num++;
				num2 += Class426.smethod_43(@class.String_16);
			}
			if (@class.String_17 != "0")
			{
				num3++;
				num4 += Class426.smethod_43(@class.String_17);
			}
			if (@class.String_18 != "0")
			{
				num5++;
				num6 += Class426.smethod_43(@class.String_18);
			}
		}
		MessageBox.Show(this, string.Concat(new string[]
		{
			"Tổng cộng có ",
			Class426.smethod_14(num),
			" Player => Có ",
			Class426.smethod_14(num2),
			" mầm hoa\r\nTổng cộng có ",
			Class426.smethod_14(num3),
			" Player => Có ",
			Class426.smethod_14(num4),
			" phân bón\r\nTổng cộng có ",
			Class426.smethod_14(num5),
			" Player => Có ",
			Class426.smethod_14(num6),
			" mao bút\r\n"
		}), "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x06001D9E RID: 7582 RVA: 0x00015D8D File Offset: 0x00013F8D
	private void toolStripMenuItem_21_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_32));
	}

	// Token: 0x06001D9F RID: 7583 RVA: 0x00015DBE File Offset: 0x00013FBE
	private void toolStripMenuItem_22_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_33));
	}

	// Token: 0x06001DA0 RID: 7584 RVA: 0x00015DEF File Offset: 0x00013FEF
	private void toolStripMenuItem_23_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_34));
	}

	// Token: 0x06001DA1 RID: 7585 RVA: 0x00015E20 File Offset: 0x00014020
	private void toolStripMenuItem_25_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_35));
	}

	// Token: 0x06001DA2 RID: 7586 RVA: 0x00015E51 File Offset: 0x00014051
	private void toolStripMenuItem_24_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_36));
	}

	// Token: 0x06001DA3 RID: 7587 RVA: 0x00015E82 File Offset: 0x00014082
	private void toolStripMenuItem_26_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_37));
	}

	// Token: 0x06001DA4 RID: 7588 RVA: 0x00015EB3 File Offset: 0x000140B3
	private void toolStripMenuItem6_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_38));
	}

	// Token: 0x06001DA5 RID: 7589 RVA: 0x00015EE4 File Offset: 0x000140E4
	private void toolStripMenuItem_27_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_39));
	}

	// Token: 0x06001DA6 RID: 7590 RVA: 0x00015F15 File Offset: 0x00014115
	private void toolStripMenuItem_28_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_40));
	}

	// Token: 0x06001DA7 RID: 7591 RVA: 0x00015F46 File Offset: 0x00014146
	private void toolStripMenuItem_29_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_41));
	}

	// Token: 0x06001DA8 RID: 7592 RVA: 0x00015F77 File Offset: 0x00014177
	private void toolStripMenuItem7_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_42));
	}

	// Token: 0x06001DA9 RID: 7593 RVA: 0x00015FA8 File Offset: 0x000141A8
	private void toolStripMenuItem8_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_43));
	}

	// Token: 0x06001DAA RID: 7594 RVA: 0x00015FD9 File Offset: 0x000141D9
	private void toolStripMenuItem9_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_44));
	}

	// Token: 0x06001DAB RID: 7595 RVA: 0x0001600A File Offset: 0x0001420A
	private void toolStripMenuItem10_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_45));
	}

	// Token: 0x06001DAC RID: 7596 RVA: 0x0001603B File Offset: 0x0001423B
	private void toolStripMenuItem11_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_46));
	}

	// Token: 0x06001DAD RID: 7597 RVA: 0x000DC584 File Offset: 0x000DA784
	private void toolStripMenuItem22_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			if (@class.class159_0 == null)
			{
				@class.String_20 = "Đang chờ...";
			}
		}
	}

	// Token: 0x06001DAE RID: 7598 RVA: 0x000DC5E0 File Offset: 0x000DA7E0
	private void toolStripMenuItem23_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			@class.String_20 = "...";
			@class.Boolean_33 = false;
			@class.method_0();
			if (@class.class159_0 != null)
			{
				@class.class159_0.Boolean_9 = false;
				@class.class159_0 = null;
				@class.Boolean_3 = false;
			}
		}
		Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(TabLogin.Class252.<>9.method_47));
	}

	// Token: 0x06001DAF RID: 7599 RVA: 0x000DC690 File Offset: 0x000DA890
	private void toolStripMenuItem24_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			if (@class.class159_0 != null)
			{
				@class.class159_0.method_224(true);
			}
			@class.class159_0 = null;
			@class.String_20 = "...";
			@class.method_0();
		}
	}

	// Token: 0x06001DB0 RID: 7600 RVA: 0x000DC704 File Offset: 0x000DA904
	private void toolStripMenuItem25_Click(object sender, EventArgs e)
	{
		MicroLogin.list_1.Clear();
		foreach (Class145 item in this.IEnumerable_1)
		{
			MicroLogin.list_1.Add(item);
		}
	}

	// Token: 0x06001DB1 RID: 7601 RVA: 0x000DC760 File Offset: 0x000DA960
	private void toolStripMenuItem26_Click(object sender, EventArgs e)
	{
		try
		{
			foreach (Class145 @class in MicroLogin.list_1)
			{
				Class145 class2 = new Class145(@class.String_2, @class.String_4, @class.String_5, @class.String_6, @class.String_7, @class.String_8, @class.String_9, this.xmlDocument_0, this.string_1);
				class2.String_14 = @class.String_14;
				class2.String_15 = @class.String_15;
				class2.String_10 = @class.String_10;
				class2.String_11 = @class.String_11;
				class2.String_13 = @class.String_13;
				class2.String_16 = @class.String_16;
				class2.String_17 = @class.String_17;
				class2.String_18 = @class.String_18;
				class2.listViewItem_0 = new ListViewItem((this.List_1.Count + 1).ToString());
				class2.listViewItem_0.SubItems.Add(class2.String_2);
				class2.listViewItem_0.SubItems.Add(class2.String_8);
				class2.listViewItem_0.SubItems.Add(class2.String_6);
				class2.listViewItem_0.SubItems.Add(class2.String_15);
				class2.listViewItem_0.SubItems.Add(class2.String_20);
				class2.listViewItem_0.SubItems.Add(class2.String_14);
				class2.listViewItem_0.SubItems.Add(class2.String_16);
				class2.listViewItem_0.SubItems.Add(class2.String_17);
				class2.listViewItem_0.SubItems.Add(class2.String_18);
				class2.listViewItem_0.SubItems.Add(class2.String_12);
				class2.listViewItem_0.Tag = class2;
				this.List_1.Add(class2);
			}
			foreach (string text in MicroLogin.String_0.Split(new char[]
			{
				'#'
			}))
			{
				if (text.Length >= 6)
				{
					string text2 = text;
					Class145 class3 = new Class145(text2, text2, "VinaGame", "Thánh Hỏa", "", "", "", this.xmlDocument_0, this.string_1);
					class3.listViewItem_0 = new ListViewItem((this.List_1.Count + 1).ToString());
					class3.listViewItem_0.SubItems.Add(class3.String_2);
					class3.listViewItem_0.SubItems.Add(class3.String_8);
					class3.listViewItem_0.SubItems.Add(class3.String_6);
					class3.listViewItem_0.SubItems.Add(class3.String_15);
					class3.listViewItem_0.SubItems.Add(class3.String_20);
					class3.listViewItem_0.SubItems.Add(class3.String_14);
					class3.listViewItem_0.SubItems.Add(class3.String_16);
					class3.listViewItem_0.SubItems.Add(class3.String_17);
					class3.listViewItem_0.SubItems.Add(class3.String_18);
					class3.listViewItem_0.SubItems.Add(class3.String_12);
					class3.listViewItem_0.Tag = class3;
					this.List_1.Add(class3);
				}
			}
			this.method_11();
			if (this.string_0 == "Offline")
			{
				MicroLogin.MicroLogin_0.method_1();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001DB2 RID: 7602 RVA: 0x000DCB5C File Offset: 0x000DAD5C
	private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		MicroLogin.list_1.Clear();
		foreach (Class145 item in this.IEnumerable_1)
		{
			MicroLogin.list_1.Add(item);
		}
		if (this.string_0 == "Offline")
		{
			MicroLogin.List_0 = this.List_1.Except(MicroLogin.list_1).ToList<Class145>();
			this.List_1 = MicroLogin.List_0;
		}
		else
		{
			this.List_1 = this.List_1.Except(MicroLogin.list_1).ToList<Class145>();
		}
		this.method_11();
	}

	// Token: 0x06001DB3 RID: 7603 RVA: 0x000DCC14 File Offset: 0x000DAE14
	private void toolStripMenuItem27_Click(object sender, EventArgs e)
	{
		try
		{
			if (this.ListViewItem_0 != null)
			{
				if (MessageBox.Show(this, "Bạn có muốn xóa thông tin những acc đã chọn", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					if (this.string_0 == "Offline")
					{
						MicroLogin.List_0 = this.List_1.Except(this.IEnumerable_1.ToList<Class145>()).ToList<Class145>();
						this.List_1 = MicroLogin.List_0;
					}
					else
					{
						this.List_1 = this.List_1.Except(this.IEnumerable_1.ToList<Class145>()).ToList<Class145>();
					}
					this.method_11();
					if (this.string_0 == "Offline")
					{
						MicroLogin.MicroLogin_0.method_1();
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001DB4 RID: 7604 RVA: 0x000DCCDC File Offset: 0x000DAEDC
	private void getTeamInfoToolStripMenuItem_Click(object sender, EventArgs e)
	{
		using (IEnumerator<Class145> enumerator = this.IEnumerable_1.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				TabLogin.Class259 @class = new TabLogin.Class259();
				@class.class145_0 = enumerator.Current;
				try
				{
					@class.class145_0.String_10 = string.Join(",", Setting.Dictionary_0.Where(new Func<KeyValuePair<string, List<string>>, bool>(@class.method_0)).Select(new Func<KeyValuePair<string, List<string>>, string>(TabLogin.Class252.<>9.method_48)).ToArray<string>());
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x06001DB5 RID: 7605 RVA: 0x000DCD94 File Offset: 0x000DAF94
	private void tagToolStripMenuItem_Click(object sender, EventArgs e)
	{
		TabLogin.Class260 @class = new TabLogin.Class260();
		@class.tabLogin_0 = this;
		@class.inputBox_0 = new InputBox();
		@class.inputBox_0.Disposed += @class.method_0;
		@class.inputBox_0.Show(this);
	}

	// Token: 0x06001DB6 RID: 7606 RVA: 0x0001606C File Offset: 0x0001426C
	private void method_14(object sender, EventArgs e)
	{
		if (!(this.string_0 == "guess@yahoo.com") && !string.IsNullOrEmpty(this.string_0))
		{
			this.method_5();
			return;
		}
		MessageBox.Show(this, "Tài khoản nặc danh không thể lưu", "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x06001DB7 RID: 7607 RVA: 0x000160A6 File Offset: 0x000142A6
	private void toolStripMenuItem_31_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_49));
	}

	// Token: 0x06001DB8 RID: 7608 RVA: 0x000DCDDC File Offset: 0x000DAFDC
	private void txtGoTo_TextChanged(object sender, EventArgs e)
	{
		this.txtGoTo.Text = Class426.smethod_41(this.txtGoTo.Text).ToString();
		this.txtGoTo.Select(this.txtGoTo.Text.Length, 0);
		try
		{
			this.lvLogin.EnsureVisible(Class426.smethod_41(this.txtGoTo.Text) - 1);
			this.lvLogin.SelectedIndices.Add(Class426.smethod_41(this.txtGoTo.Text) - 1);
		}
		catch
		{
		}
	}

	// Token: 0x06001DB9 RID: 7609 RVA: 0x000160D7 File Offset: 0x000142D7
	private void toolStripMenuItem_32_Click(object sender, EventArgs e)
	{
		Task.Run(new Action(this.method_25));
	}

	// Token: 0x06001DBA RID: 7610 RVA: 0x000DCE80 File Offset: 0x000DB080
	private void label4_MouseClick(object sender, MouseEventArgs e)
	{
		if (this.string_0 == "Offline")
		{
			this.smethod_15(new Action(TabLogin.Class252.<>9.method_52));
			return;
		}
		TabLogin.List_0.Remove(this);
		try
		{
			this.thread_0.Abort();
		}
		catch
		{
		}
		base.Parent.Dispose();
		base.Dispose();
		base.Parent.Dispose();
	}

	// Token: 0x06001DBB RID: 7611 RVA: 0x000DCF10 File Offset: 0x000DB110
	private void toolStripMenuItem_33_Click(object sender, EventArgs e)
	{
		List<Class145> list = new List<Class145>();
		List<string> list2 = new List<string>();
		foreach (Class145 @class in this.List_1)
		{
			string string_ = @class.String_8;
			if (!string.IsNullOrEmpty(string_) && string_ != ",,,")
			{
				if (!list2.Contains(string_))
				{
					list2.Add(string_);
				}
				else
				{
					list.Add(@class);
				}
			}
		}
		if (list.Count > 0)
		{
			if (MessageBox.Show(this, "Có " + list.Count.ToString() + " tài khoản trùng\r\nBạn có muốn xóa tên không", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				foreach (Class145 class2 in this.List_1)
				{
					if (list.Select(new Func<Class145, string>(TabLogin.Class252.<>9.method_53)).Contains(class2.String_8))
					{
						if (class2.class159_0 != null)
						{
							class2.class159_0.method_224(true);
						}
						class2.String_8 = (class2.String_9 = "");
					}
				}
				MessageBox.Show(this, "Đã xóa tên " + list.Count.ToString() + " tài khoản trùng tên", "MicroAuto", MessageBoxButtons.OK);
			}
		}
		else
		{
			MessageBox.Show(this, "Không có tải khoản trùng", "MicroAuto", MessageBoxButtons.OK);
		}
		this.method_11();
	}

	// Token: 0x06001DBC RID: 7612 RVA: 0x0001606C File Offset: 0x0001426C
	private void method_15(object sender, MouseEventArgs e)
	{
		if (!(this.string_0 == "guess@yahoo.com") && !string.IsNullOrEmpty(this.string_0))
		{
			this.method_5();
			return;
		}
		MessageBox.Show(this, "Tài khoản nặc danh không thể lưu", "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x06001DBD RID: 7613 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_16(object sender, EventArgs e)
	{
	}

	// Token: 0x06001DBE RID: 7614 RVA: 0x000160EB File Offset: 0x000142EB
	private void toolStripMenuItem_34_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_54));
	}

	// Token: 0x06001DBF RID: 7615 RVA: 0x0001611C File Offset: 0x0001431C
	private void toolStripMenuItem_35_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_55));
	}

	// Token: 0x06001DC0 RID: 7616 RVA: 0x0001614D File Offset: 0x0001434D
	private void toolStripMenuItem_36_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_56));
	}

	// Token: 0x06001DC1 RID: 7617 RVA: 0x0001617E File Offset: 0x0001437E
	private void toolStripMenuItem_37_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_57));
	}

	// Token: 0x06001DC2 RID: 7618 RVA: 0x000161AF File Offset: 0x000143AF
	private void toolStripMenuItem_38_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_58));
	}

	// Token: 0x06001DC3 RID: 7619 RVA: 0x000161E0 File Offset: 0x000143E0
	private void toolStripMenuItem_40_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_59));
	}

	// Token: 0x06001DC4 RID: 7620 RVA: 0x00016211 File Offset: 0x00014411
	private void toolStripMenuItem_41_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_60));
	}

	// Token: 0x06001DC5 RID: 7621 RVA: 0x00016242 File Offset: 0x00014442
	private void toolStripMenuItem_42_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_61));
	}

	// Token: 0x06001DC6 RID: 7622 RVA: 0x00016273 File Offset: 0x00014473
	private void toolStripMenuItem_44_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_62));
	}

	// Token: 0x06001DC7 RID: 7623 RVA: 0x000162A4 File Offset: 0x000144A4
	private void toolStripMenuItem_45_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_63));
	}

	// Token: 0x06001DC8 RID: 7624 RVA: 0x000162D5 File Offset: 0x000144D5
	private void toolStripMenuItem_46_Click(object sender, EventArgs e)
	{
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(TabLogin.Class252.<>9.method_64));
	}

	// Token: 0x06001DC9 RID: 7625 RVA: 0x00016306 File Offset: 0x00014506
	private void toolStripMenuItem_47_Click(object sender, EventArgs e)
	{
		MicroLogin.int_5 = 0;
		MicroLogin.stopwatch_3 = null;
		Class159.Int32_20 = 0;
		Class159.Stopwatch_1 = Stopwatch.StartNew();
	}

	// Token: 0x06001DCA RID: 7626 RVA: 0x000DD0C4 File Offset: 0x000DB2C4
	private void lvLogin_ColumnClick(object sender, ColumnClickEventArgs e)
	{
		TabLogin.Class261 @class = new TabLogin.Class261();
		@class.columnClickEventArgs_0 = e;
		if (this.List_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_65)).Count<Class145>() > 0)
		{
			MessageBox.Show(this, "Ctrl + A để chọn toàn bộ acc trước rồi mới sắp xếp được nhé", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		if (MessageBox.Show(this, "Bạn có muốn sắp xếp danh sách Accounts", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.No)
		{
			return;
		}
		this.bool_7 = !this.bool_7;
		try
		{
			TabLogin.Class262 class2 = new TabLogin.Class262();
			class2.int_0 = Convert.ToInt32(@class.columnClickEventArgs_0.Column.ToString());
			if (class2.int_0 != 0 && class2.int_0 != 4 && class2.int_0 < 6)
			{
				if (this.string_0 == "Offline")
				{
					if (this.bool_7)
					{
						MicroLogin.List_0 = this.List_1.OrderBy(new Func<Class145, string>(class2.method_4)).ToList<Class145>();
						this.List_1 = MicroLogin.List_0;
					}
					else
					{
						MicroLogin.List_0 = this.List_1.OrderByDescending(new Func<Class145, string>(@class.method_0)).ToList<Class145>();
						this.List_1 = MicroLogin.List_0;
					}
				}
				else if (this.bool_7)
				{
					this.List_1 = this.List_1.OrderBy(new Func<Class145, string>(class2.method_5)).ToList<Class145>();
				}
				else
				{
					this.List_1 = this.List_1.OrderByDescending(new Func<Class145, string>(@class.method_1)).ToList<Class145>();
				}
			}
			else if (this.string_0 == "Offline")
			{
				if (this.bool_7)
				{
					MicroLogin.List_0 = this.List_1.OrderBy(new Func<Class145, int>(class2.method_0)).ToList<Class145>();
					this.List_1 = MicroLogin.List_0;
				}
				else
				{
					MicroLogin.List_0 = this.List_1.OrderByDescending(new Func<Class145, int>(class2.method_1)).ToList<Class145>();
					this.List_1 = MicroLogin.List_0;
				}
			}
			else if (this.bool_7)
			{
				this.List_1 = this.List_1.OrderBy(new Func<Class145, int>(class2.method_2)).ToList<Class145>();
			}
			else
			{
				this.List_1 = this.List_1.OrderByDescending(new Func<Class145, int>(class2.method_3)).ToList<Class145>();
			}
		}
		catch
		{
		}
		this.method_11();
	}

	// Token: 0x06001DCB RID: 7627 RVA: 0x00002E18 File Offset: 0x00001018
	private void txtLimit_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001DCC RID: 7628 RVA: 0x000DD34C File Offset: 0x000DB54C
	private void toolStripMenuItem_48_Click(object sender, EventArgs e)
	{
		foreach (Class145 @class in this.IEnumerable_1)
		{
			@class.String_20 = "Đang chờ làm BHD...";
			@class.Boolean_2 = true;
		}
	}

	// Token: 0x06001DCD RID: 7629 RVA: 0x000DD3A4 File Offset: 0x000DB5A4
	private void timer_2_Tick(object sender, EventArgs e)
	{
		try
		{
			this.nudStop.Value = this.nudStop.Value - 1m;
		}
		catch
		{
		}
	}

	// Token: 0x06001DCE RID: 7630 RVA: 0x000DD3E8 File Offset: 0x000DB5E8
	private void label1_MouseClick(object sender, MouseEventArgs e)
	{
		if (this.string_0 == "Offline")
		{
			Task.Run(new Action(this.method_26));
			return;
		}
		if (!(this.string_0 == "guess@yahoo.com") && !string.IsNullOrEmpty(this.string_0))
		{
			this.method_5();
			return;
		}
		this.smethod_15(new Action(TabLogin.Class252.<>9.method_67));
	}

	// Token: 0x06001DCF RID: 7631 RVA: 0x00002E18 File Offset: 0x00001018
	private void lvLogin_MouseClick(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001DD0 RID: 7632 RVA: 0x00002E18 File Offset: 0x00001018
	private void lvLogin_MouseMove(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001DD1 RID: 7633 RVA: 0x000DD468 File Offset: 0x000DB668
	private void userToolStripMenuItem_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 1;
		this.list_5.Remove(1);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 80;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD2 RID: 7634 RVA: 0x000DD4FC File Offset: 0x000DB6FC
	private void serverToolStripMenuItem_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 3;
		this.list_5.Remove(3);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 70;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD3 RID: 7635 RVA: 0x000DD590 File Offset: 0x000DB790
	private void toolStripMenuItem_49_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 7;
		this.list_5.Remove(7);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 40;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD4 RID: 7636 RVA: 0x000DD624 File Offset: 0x000DB824
	private void shitToolStripMenuItem_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 8;
		this.list_5.Remove(8);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 40;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD5 RID: 7637 RVA: 0x000DD6B8 File Offset: 0x000DB8B8
	private void toolStripMenuItem_50_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 9;
		this.list_5.Remove(9);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 40;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD6 RID: 7638 RVA: 0x000DD750 File Offset: 0x000DB950
	private void method_17()
	{
		Class159.Class220_0.method_1("Config", "Column", string.Join(",", this.list_5.Select(new Func<int, string>(TabLogin.Class252.<>9.method_68)).ToArray<string>()));
	}

	// Token: 0x06001DD7 RID: 7639 RVA: 0x000DD7AC File Offset: 0x000DB9AC
	private void infoToolStripMenuItem_Click(object sender, EventArgs e)
	{
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		toolStripMenuItem.Checked = !toolStripMenuItem.Checked;
		int num = 10;
		this.list_5.Remove(10);
		if (toolStripMenuItem.Checked)
		{
			this.lvLogin.Columns[num].Width = 120;
			this.list_4.Remove(num);
			this.list_5.Add(num);
		}
		else
		{
			this.lvLogin.Columns[num].Width = 0;
			this.list_4.Add(num);
		}
		this.method_17();
	}

	// Token: 0x06001DD8 RID: 7640 RVA: 0x000DD844 File Offset: 0x000DBA44
	private void toolStripMenuItem_63_Click(object sender, EventArgs e)
	{
		TabLogin.Class263 @class = new TabLogin.Class263();
		@class.object_0 = sender;
		this.IEnumerable_1.ToList<Class145>().ForEach(new Action<Class145>(@class.method_0));
	}

	// Token: 0x06001DD9 RID: 7641 RVA: 0x00016324 File Offset: 0x00014524
	private void TabLogin_Resize(object sender, EventArgs e)
	{
		this.method_9();
	}

	// Token: 0x06001DDA RID: 7642 RVA: 0x0001632C File Offset: 0x0001452C
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001DDB RID: 7643 RVA: 0x000DD87C File Offset: 0x000DBA7C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		this.chkStop = new CheckBox();
		this.menuListView = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem5 = new ToolStripMenuItem();
		this.toolStripMenuItem1 = new ToolStripMenuItem();
		this.toolStripMenuItem_34 = new ToolStripMenuItem();
		this.toolStripMenuItem_35 = new ToolStripMenuItem();
		this.toolStripMenuItem_36 = new ToolStripMenuItem();
		this.toolStripMenuItem_37 = new ToolStripMenuItem();
		this.toolStripMenuItem_38 = new ToolStripMenuItem();
		this.toolStripMenuItem_43 = new ToolStripMenuItem();
		this.toolStripMenuItem_44 = new ToolStripMenuItem();
		this.toolStripMenuItem_45 = new ToolStripMenuItem();
		this.toolStripMenuItem_46 = new ToolStripMenuItem();
		this.muAcBa = new ToolStripMenuItem();
		this.toolStripMenuItem_51 = new ToolStripMenuItem();
		this.toolStripSeparator24 = new ToolStripSeparator();
		this.toolStripMenuItem_52 = new ToolStripMenuItem();
		this.toolStripMenuItem_53 = new ToolStripMenuItem();
		this.toolStripMenuItem_54 = new ToolStripMenuItem();
		this.toolStripMenuItem_55 = new ToolStripMenuItem();
		this.toolStripMenuItem_56 = new ToolStripMenuItem();
		this.toolStripMenuItem_57 = new ToolStripMenuItem();
		this.toolStripMenuItem_58 = new ToolStripMenuItem();
		this.toolStripMenuItem_59 = new ToolStripMenuItem();
		this.toolStripMenuItem_60 = new ToolStripMenuItem();
		this.ngamyToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_61 = new ToolStripMenuItem();
		this.toolStripMenuItem_62 = new ToolStripMenuItem();
		this.toolStripMenuItem_63 = new ToolStripMenuItem();
		this.toolStripMenuItem_39 = new ToolStripMenuItem();
		this.toolStripMenuItem_40 = new ToolStripMenuItem();
		this.toolStripMenuItem_41 = new ToolStripMenuItem();
		this.toolStripMenuItem_42 = new ToolStripMenuItem();
		this.toolStripSeparator11 = new ToolStripSeparator();
		this.toolStripMenuItem20 = new ToolStripMenuItem();
		this.toolStripMenuItem21 = new ToolStripMenuItem();
		this.treoShopChoTaToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_48 = new ToolStripMenuItem();
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.toolStripMenuItem_3 = new ToolStripMenuItem();
		this.toolStripMenuItem_4 = new ToolStripMenuItem();
		this.toolStripMenuItem_1 = new ToolStripMenuItem();
		this.toolStripMenuItem_2 = new ToolStripMenuItem();
		this.muNhanThoiBong = new ToolStripMenuItem();
		this.managerToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_5 = new ToolStripMenuItem();
		this.toolStripMenuItem_6 = new ToolStripMenuItem();
		this.toolStripMenuItem_33 = new ToolStripMenuItem();
		this.toolStripSeparator2 = new ToolStripSeparator();
		this.toolStripMenuItem_7 = new ToolStripMenuItem();
		this.toolStripMenuItem_8 = new ToolStripMenuItem();
		this.toolStripMenuItem_9 = new ToolStripMenuItem();
		this.cleanNameToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_18 = new ToolStripMenuItem();
		this.toolStripSeparator3 = new ToolStripSeparator();
		this.toolStripMenuItem_10 = new ToolStripMenuItem();
		this.toolStripMenuItem_11 = new ToolStripMenuItem();
		this.toolStripMenuItem_12 = new ToolStripMenuItem();
		this.toolStripMenuItem_13 = new ToolStripMenuItem();
		this.toolStripMenuItem_14 = new ToolStripMenuItem();
		this.toolStripMenuItem_15 = new ToolStripMenuItem();
		this.toolStripMenuItem_16 = new ToolStripMenuItem();
		this.toolStripMenuItem_17 = new ToolStripMenuItem();
		this.loginAccLvl30ToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_19 = new ToolStripMenuItem();
		this.toolStripMenuItem_31 = new ToolStripMenuItem();
		this.muChuyenServer = new ToolStripMenuItem();
		this.toolStripMenuItem_20 = new ToolStripMenuItem();
		this.toolStripMenuItem_21 = new ToolStripMenuItem();
		this.toolStripSeparator12 = new ToolStripSeparator();
		this.toolStripMenuItem_22 = new ToolStripMenuItem();
		this.toolStripMenuItem_23 = new ToolStripMenuItem();
		this.toolStripMenuItem_24 = new ToolStripMenuItem();
		this.toolStripSeparator13 = new ToolStripSeparator();
		this.toolStripMenuItem_25 = new ToolStripMenuItem();
		this.toolStripMenuItem_26 = new ToolStripMenuItem();
		this.toolStripMenuItem6 = new ToolStripMenuItem();
		this.toolStripMenuItem_27 = new ToolStripMenuItem();
		this.toolStripMenuItem_28 = new ToolStripMenuItem();
		this.toolStripSeparator14 = new ToolStripSeparator();
		this.toolStripMenuItem_29 = new ToolStripMenuItem();
		this.toolStripMenuItem_30 = new ToolStripMenuItem();
		this.toolStripMenuItem7 = new ToolStripMenuItem();
		this.toolStripMenuItem8 = new ToolStripMenuItem();
		this.toolStripMenuItem9 = new ToolStripMenuItem();
		this.toolStripMenuItem10 = new ToolStripMenuItem();
		this.toolStripMenuItem11 = new ToolStripMenuItem();
		this.toolStripSeparator15 = new ToolStripSeparator();
		this.toolStripMenuItem22 = new ToolStripMenuItem();
		this.toolStripMenuItem23 = new ToolStripMenuItem();
		this.toolStripMenuItem24 = new ToolStripMenuItem();
		this.toolStripSeparator16 = new ToolStripSeparator();
		this.cutToolStripMenuItem1 = new ToolStripMenuItem();
		this.toolStripMenuItem25 = new ToolStripMenuItem();
		this.toolStripMenuItem26 = new ToolStripMenuItem();
		this.toolStripMenuItem27 = new ToolStripMenuItem();
		this.toolStripSeparator4 = new ToolStripSeparator();
		this.getTeamInfoToolStripMenuItem = new ToolStripMenuItem();
		this.tagToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_32 = new ToolStripMenuItem();
		this.toolStripMenuItem_47 = new ToolStripMenuItem();
		this.userToolStripMenuItem = new ToolStripMenuItem();
		this.serverToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_49 = new ToolStripMenuItem();
		this.shitToolStripMenuItem = new ToolStripMenuItem();
		this.toolStripMenuItem_50 = new ToolStripMenuItem();
		this.infoToolStripMenuItem = new ToolStripMenuItem();
		this.nudStop = new NumericUpDown();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.label4 = new Label();
		this.txtLimit = new Class85();
		this.label1 = new Label();
		this.timer_0 = new System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_1 = new System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_2 = new System.Windows.Forms.Timer(this.icontainer_0);
		this.panel1 = new Panel();
		this.txtSearch = new Class85();
		this.txtGoTo = new Class85();
		this.lvLogin = new GClass1();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.columnHeader_3 = new ColumnHeader();
		this.columnHeader_4 = new ColumnHeader();
		this.columnHeader_5 = new ColumnHeader();
		this.columnHeader_6 = new ColumnHeader();
		this.columnHeader_7 = new ColumnHeader();
		this.columnHeader_8 = new ColumnHeader();
		this.columnHeader_9 = new ColumnHeader();
		this.columnHeader_10 = new ColumnHeader();
		this.menuListView.SuspendLayout();
		((ISupportInitialize)this.nudStop).BeginInit();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.chkStop.AutoSize = true;
		this.chkStop.Dock = DockStyle.Right;
		this.chkStop.Location = new Point(575, 0);
		this.chkStop.Name = "chkStop";
		this.chkStop.Size = new Size(48, 20);
		this.chkStop.TabIndex = 64;
		this.chkStop.Text = "Stop";
		this.chkStop.UseVisualStyleBackColor = true;
		this.chkStop.CheckedChanged += this.chkStop_CheckedChanged;
		this.menuListView.ImageScalingSize = new Size(24, 24);
		this.menuListView.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem5,
			this.managerToolStripMenuItem,
			this.muChuyenServer,
			this.toolStripMenuItem_20,
			this.toolStripSeparator15,
			this.toolStripMenuItem22,
			this.toolStripMenuItem23,
			this.toolStripMenuItem24,
			this.toolStripSeparator16,
			this.cutToolStripMenuItem1,
			this.toolStripMenuItem25,
			this.toolStripMenuItem26,
			this.toolStripMenuItem27,
			this.toolStripSeparator4,
			this.getTeamInfoToolStripMenuItem,
			this.tagToolStripMenuItem,
			this.toolStripMenuItem_32,
			this.toolStripMenuItem_47,
			this.userToolStripMenuItem,
			this.serverToolStripMenuItem,
			this.toolStripMenuItem_49,
			this.shitToolStripMenuItem,
			this.toolStripMenuItem_50,
			this.infoToolStripMenuItem
		});
		this.menuListView.Name = "menuListView";
		this.menuListView.Size = new Size(214, 484);
		this.menuListView.Opening += this.menuListView_Opening;
		this.toolStripMenuItem5.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem1,
			this.toolStripMenuItem_43,
			this.toolStripMenuItem_39,
			this.toolStripSeparator11,
			this.toolStripMenuItem20,
			this.toolStripMenuItem21,
			this.treoShopChoTaToolStripMenuItem,
			this.toolStripMenuItem_48,
			this.toolStripMenuItem_0,
			this.toolStripMenuItem_3,
			this.toolStripMenuItem_4,
			this.toolStripMenuItem_1,
			this.toolStripMenuItem_2,
			this.muNhanThoiBong
		});
		this.toolStripMenuItem5.Name = "toolStripMenuItem5";
		this.toolStripMenuItem5.Size = new Size(213, 22);
		this.toolStripMenuItem5.Text = "Đăng Nhập Và";
		this.toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_34,
			this.toolStripMenuItem_35,
			this.toolStripMenuItem_36,
			this.toolStripMenuItem_37,
			this.toolStripMenuItem_38
		});
		this.toolStripMenuItem1.Name = "toolStripMenuItem1";
		this.toolStripMenuItem1.Size = new Size(206, 22);
		this.toolStripMenuItem1.Text = "Làm Nhiệm Vụ";
		this.toolStripMenuItem_34.Name = "dưaHấuToolStripMenuItem";
		this.toolStripMenuItem_34.Size = new Size(187, 22);
		this.toolStripMenuItem_34.Text = "Dưa Hấu";
		this.toolStripMenuItem_34.Click += this.toolStripMenuItem_34_Click;
		this.toolStripMenuItem_35.Name = "trừngÁcToolStripMenuItem";
		this.toolStripMenuItem_35.Size = new Size(187, 22);
		this.toolStripMenuItem_35.Text = "Trừng Ác";
		this.toolStripMenuItem_35.Click += this.toolStripMenuItem_35_Click;
		this.toolStripMenuItem_36.Name = "tiềmNăngTánToolStripMenuItem";
		this.toolStripMenuItem_36.Size = new Size(187, 22);
		this.toolStripMenuItem_36.Text = "Tiềm Năng Tán";
		this.toolStripMenuItem_36.Click += this.toolStripMenuItem_36_Click;
		this.toolStripMenuItem_37.Name = "nhiệmVụThăngCấpToolStripMenuItem";
		this.toolStripMenuItem_37.Size = new Size(187, 22);
		this.toolStripMenuItem_37.Text = "Nhiệm Vụ Thăng Cấp";
		this.toolStripMenuItem_37.Click += this.toolStripMenuItem_37_Click;
		this.toolStripMenuItem_38.Name = "nhiệmVụExp2838ToolStripMenuItem";
		this.toolStripMenuItem_38.Size = new Size(187, 22);
		this.toolStripMenuItem_38.Text = "Nhiệm Vụ Exp 28-38";
		this.toolStripMenuItem_38.Click += this.toolStripMenuItem_38_Click;
		this.toolStripMenuItem_43.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_44,
			this.toolStripMenuItem_45,
			this.toolStripMenuItem_46,
			this.muAcBa
		});
		this.toolStripMenuItem_43.Name = "phụBảnToolStripMenuItem";
		this.toolStripMenuItem_43.Size = new Size(206, 22);
		this.toolStripMenuItem_43.Text = "Phụ Bản";
		this.toolStripMenuItem_44.Name = "ácTặcToolStripMenuItem";
		this.toolStripMenuItem_44.Size = new Size(221, 22);
		this.toolStripMenuItem_44.Text = "Ác Tặc";
		this.toolStripMenuItem_44.Click += this.toolStripMenuItem_44_Click;
		this.toolStripMenuItem_45.Name = "thiếuThấtSơnToolStripMenuItem";
		this.toolStripMenuItem_45.Size = new Size(221, 22);
		this.toolStripMenuItem_45.Text = "Thiếu Thất Sơn";
		this.toolStripMenuItem_45.Click += this.toolStripMenuItem_45_Click;
		this.toolStripMenuItem_46.Name = "lâuLanTầmBảoToolStripMenuItem";
		this.toolStripMenuItem_46.Size = new Size(221, 22);
		this.toolStripMenuItem_46.Text = "Lâu Lan Tầm Bảo + Kỳ Cuộc";
		this.toolStripMenuItem_46.Click += this.toolStripMenuItem_46_Click;
		this.muAcBa.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_51,
			this.toolStripSeparator24,
			this.toolStripMenuItem_52,
			this.toolStripMenuItem_53,
			this.toolStripMenuItem_54,
			this.toolStripMenuItem_55,
			this.toolStripMenuItem_56,
			this.toolStripMenuItem_57,
			this.toolStripMenuItem_58,
			this.toolStripMenuItem_59,
			this.toolStripMenuItem_60,
			this.ngamyToolStripMenuItem,
			this.toolStripMenuItem_61,
			this.toolStripMenuItem_62,
			this.toolStripMenuItem_63
		});
		this.muAcBa.Name = "muAcBa";
		this.muAcBa.Size = new Size(221, 22);
		this.muAcBa.Text = "Ác Bá";
		this.toolStripMenuItem_51.Name = "tựĐộngToolStripMenuItem2";
		this.toolStripMenuItem_51.Size = new Size(138, 22);
		this.toolStripMenuItem_51.Text = "Tự Động";
		this.toolStripMenuItem_51.Click += this.toolStripMenuItem_63_Click;
		this.toolStripSeparator24.Name = "toolStripSeparator24";
		this.toolStripSeparator24.Size = new Size(135, 6);
		this.toolStripMenuItem_52.Name = "đàoHoaToolStripMenuItem";
		this.toolStripMenuItem_52.Size = new Size(138, 22);
		this.toolStripMenuItem_52.Text = "Đào Hoa";
		this.toolStripMenuItem_52.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_53.Name = "quỷCốcToolStripMenuItem";
		this.toolStripMenuItem_53.Size = new Size(138, 22);
		this.toolStripMenuItem_53.Text = "Quỷ Cốc";
		this.toolStripMenuItem_53.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_54.Name = "đườngMônToolStripMenuItem";
		this.toolStripMenuItem_54.Size = new Size(138, 22);
		this.toolStripMenuItem_54.Text = "Đường Môn";
		this.toolStripMenuItem_54.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_55.Name = "mộDungToolStripMenuItem";
		this.toolStripMenuItem_55.Size = new Size(138, 22);
		this.toolStripMenuItem_55.Text = "Mộ Dung";
		this.toolStripMenuItem_55.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_56.Name = "tinhTúcToolStripMenuItem";
		this.toolStripMenuItem_56.Size = new Size(138, 22);
		this.toolStripMenuItem_56.Text = "Tinh Túc";
		this.toolStripMenuItem_56.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_57.Name = "tiêuDaoToolStripMenuItem";
		this.toolStripMenuItem_57.Size = new Size(138, 22);
		this.toolStripMenuItem_57.Text = "Tiêu Dao";
		this.toolStripMenuItem_57.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_58.Name = "thiếuLâmToolStripMenuItem";
		this.toolStripMenuItem_58.Size = new Size(138, 22);
		this.toolStripMenuItem_58.Text = "Thiếu Lâm";
		this.toolStripMenuItem_58.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_59.Name = "thiênSơnToolStripMenuItem";
		this.toolStripMenuItem_59.Size = new Size(138, 22);
		this.toolStripMenuItem_59.Text = "Thiên Sơn";
		this.toolStripMenuItem_59.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_60.Name = "thiênLongToolStripMenuItem";
		this.toolStripMenuItem_60.Size = new Size(138, 22);
		this.toolStripMenuItem_60.Text = "Thiên Long";
		this.toolStripMenuItem_60.Click += this.toolStripMenuItem_63_Click;
		this.ngamyToolStripMenuItem.Name = "ngamyToolStripMenuItem";
		this.ngamyToolStripMenuItem.Size = new Size(138, 22);
		this.ngamyToolStripMenuItem.Text = "Ngamy";
		this.ngamyToolStripMenuItem.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_61.Name = "võĐangToolStripMenuItem";
		this.toolStripMenuItem_61.Size = new Size(138, 22);
		this.toolStripMenuItem_61.Text = "Võ Đang";
		this.toolStripMenuItem_61.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_62.Name = "minhGiáoToolStripMenuItem";
		this.toolStripMenuItem_62.Size = new Size(138, 22);
		this.toolStripMenuItem_62.Text = "Minh Giáo";
		this.toolStripMenuItem_62.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_63.Name = "cáiBangToolStripMenuItem";
		this.toolStripMenuItem_63.Size = new Size(138, 22);
		this.toolStripMenuItem_63.Text = "Cái Bang";
		this.toolStripMenuItem_63.Click += this.toolStripMenuItem_63_Click;
		this.toolStripMenuItem_39.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_40,
			this.toolStripMenuItem_41,
			this.toolStripMenuItem_42
		});
		this.toolStripMenuItem_39.Name = "nhậnToolStripMenuItem";
		this.toolStripMenuItem_39.Size = new Size(206, 22);
		this.toolStripMenuItem_39.Text = "Nhận";
		this.toolStripMenuItem_40.Name = "lễBaoToolStripMenuItem";
		this.toolStripMenuItem_40.Size = new Size(135, 22);
		this.toolStripMenuItem_40.Text = "Lễ Bao";
		this.toolStripMenuItem_40.Click += this.toolStripMenuItem_40_Click;
		this.toolStripMenuItem_41.Name = "biếnThânToolStripMenuItem";
		this.toolStripMenuItem_41.Size = new Size(135, 22);
		this.toolStripMenuItem_41.Text = "Biến Thân";
		this.toolStripMenuItem_41.Click += this.toolStripMenuItem_41_Click;
		this.toolStripMenuItem_42.Name = "bồiThườngToolStripMenuItem";
		this.toolStripMenuItem_42.Size = new Size(135, 22);
		this.toolStripMenuItem_42.Text = "Bồi Thường";
		this.toolStripMenuItem_42.Click += this.toolStripMenuItem_42_Click;
		this.toolStripSeparator11.Name = "toolStripSeparator11";
		this.toolStripSeparator11.Size = new Size(203, 6);
		this.toolStripMenuItem20.Name = "toolStripMenuItem20";
		this.toolStripMenuItem20.Size = new Size(206, 22);
		this.toolStripMenuItem20.Text = "Đi Mua Ngựa";
		this.toolStripMenuItem20.Click += this.toolStripMenuItem20_Click;
		this.toolStripMenuItem21.Name = "toolStripMenuItem21";
		this.toolStripMenuItem21.Size = new Size(206, 22);
		this.toolStripMenuItem21.Text = "Giao Dịch Gom Đồ";
		this.toolStripMenuItem21.Click += this.toolStripMenuItem21_Click;
		this.treoShopChoTaToolStripMenuItem.Name = "treoShopChoTaToolStripMenuItem";
		this.treoShopChoTaToolStripMenuItem.Size = new Size(206, 22);
		this.treoShopChoTaToolStripMenuItem.Text = "Treo Shop Gom Đồ";
		this.treoShopChoTaToolStripMenuItem.Click += this.treoShopChoTaToolStripMenuItem_Click;
		this.toolStripMenuItem_48.Name = "đưaKNBChoTaToolStripMenuItem";
		this.toolStripMenuItem_48.Size = new Size(206, 22);
		this.toolStripMenuItem_48.Text = "Đưa KNB Cho Ta";
		this.toolStripMenuItem_48.Click += this.toolStripMenuItem_48_Click;
		this.toolStripMenuItem_0.Name = "nhậnQuàBụiHoaHồngToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(206, 22);
		this.toolStripMenuItem_0.Text = "Nhận Quà Bụi Hoa Hồng";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.toolStripMenuItem_3.Name = "kếtNghĩaNhậnBóngToolStripMenuItem";
		this.toolStripMenuItem_3.Size = new Size(206, 22);
		this.toolStripMenuItem_3.Text = "Kết Nghĩa + Nhận Bóng";
		this.toolStripMenuItem_3.Click += this.toolStripMenuItem_3_Click;
		this.toolStripMenuItem_4.Name = "sưToolStripMenuItem";
		this.toolStripMenuItem_4.Size = new Size(206, 22);
		this.toolStripMenuItem_4.Text = "Sư Đồ + Nhận Bóng";
		this.toolStripMenuItem_4.Click += this.toolStripMenuItem_4_Click;
		this.toolStripMenuItem_1.Name = "nhậnBóngToolStripMenuItem";
		this.toolStripMenuItem_1.Size = new Size(206, 22);
		this.toolStripMenuItem_1.Text = "Nhận Bóng";
		this.toolStripMenuItem_1.Click += this.toolStripMenuItem_1_Click;
		this.toolStripMenuItem_2.Name = "thổiBóngToolStripMenuItem";
		this.toolStripMenuItem_2.Size = new Size(206, 22);
		this.toolStripMenuItem_2.Text = "Thổi Bóng";
		this.toolStripMenuItem_2.Click += this.toolStripMenuItem_2_Click;
		this.muNhanThoiBong.Name = "muNhanThoiBong";
		this.muNhanThoiBong.Size = new Size(206, 22);
		this.muNhanThoiBong.Text = "Nhận Bóng + Thổi Bóng";
		this.muNhanThoiBong.Click += this.muNhanThoiBong_Click;
		this.managerToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_5,
			this.toolStripMenuItem_6,
			this.toolStripMenuItem_33,
			this.toolStripSeparator2,
			this.toolStripMenuItem_7,
			this.toolStripMenuItem_8,
			this.toolStripMenuItem_9,
			this.cleanNameToolStripMenuItem,
			this.toolStripMenuItem_18,
			this.toolStripSeparator3,
			this.toolStripMenuItem_10,
			this.toolStripMenuItem_15,
			this.toolStripMenuItem_16,
			this.toolStripMenuItem_17,
			this.loginAccLvl30ToolStripMenuItem,
			this.toolStripMenuItem_19,
			this.toolStripMenuItem_31
		});
		this.managerToolStripMenuItem.Name = "managerToolStripMenuItem";
		this.managerToolStripMenuItem.Size = new Size(213, 22);
		this.managerToolStripMenuItem.Text = "Thao Tác";
		this.toolStripMenuItem_5.Name = "kiểmTraTrùngLặpToolStripMenuItem";
		this.toolStripMenuItem_5.Size = new Size(227, 22);
		this.toolStripMenuItem_5.Text = "Kiểm Tra Trùng Lặp";
		this.toolStripMenuItem_5.Click += this.toolStripMenuItem_5_Click;
		this.toolStripMenuItem_6.Name = "xóaTàiKhoảnTrùngLặpToolStripMenuItem1";
		this.toolStripMenuItem_6.Size = new Size(227, 22);
		this.toolStripMenuItem_6.Text = "Xóa Tài Khoản Trùng Lặp";
		this.toolStripMenuItem_6.Click += this.toolStripMenuItem_6_Click;
		this.toolStripMenuItem_33.Name = "xóaTênTrùngToolStripMenuItem";
		this.toolStripMenuItem_33.Size = new Size(227, 22);
		this.toolStripMenuItem_33.Text = "Xóa Tên Trùng";
		this.toolStripMenuItem_33.Click += this.toolStripMenuItem_33_Click;
		this.toolStripSeparator2.Name = "toolStripSeparator2";
		this.toolStripSeparator2.Size = new Size(224, 6);
		this.toolStripMenuItem_7.Name = "diChuyểnXuốngDướiCùngToolStripMenuItem";
		this.toolStripMenuItem_7.Size = new Size(227, 22);
		this.toolStripMenuItem_7.Text = "Di Chuyển Xuống Dưới Cùng";
		this.toolStripMenuItem_7.Click += this.toolStripMenuItem_7_Click;
		this.toolStripMenuItem_8.Name = "diChuyểnLênTrênCùngToolStripMenuItem";
		this.toolStripMenuItem_8.Size = new Size(227, 22);
		this.toolStripMenuItem_8.Text = "Di Chuyển Lên Trên Cùng";
		this.toolStripMenuItem_8.Click += this.toolStripMenuItem_8_Click;
		this.toolStripMenuItem_9.Name = "xóaToànBộTênToolStripMenuItem";
		this.toolStripMenuItem_9.Size = new Size(227, 22);
		this.toolStripMenuItem_9.Text = "Clean Status";
		this.toolStripMenuItem_9.Click += this.toolStripMenuItem_9_Click;
		this.cleanNameToolStripMenuItem.Name = "cleanNameToolStripMenuItem";
		this.cleanNameToolStripMenuItem.Size = new Size(227, 22);
		this.cleanNameToolStripMenuItem.Text = "Clean Name";
		this.cleanNameToolStripMenuItem.Click += this.cleanNameToolStripMenuItem_Click;
		this.toolStripMenuItem_18.Name = "sắpXếpNgẫuNhiênToolStripMenuItem";
		this.toolStripMenuItem_18.Size = new Size(227, 22);
		this.toolStripMenuItem_18.Text = "Sắp Xếp Ngẫu Nghiên";
		this.toolStripMenuItem_18.Click += this.toolStripMenuItem_18_Click;
		this.toolStripSeparator3.Name = "toolStripSeparator3";
		this.toolStripSeparator3.Size = new Size(224, 6);
		this.toolStripMenuItem_10.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_11,
			this.toolStripMenuItem_12,
			this.toolStripMenuItem_13,
			this.toolStripMenuItem_14
		});
		this.toolStripMenuItem_10.Name = "chọnNhânVậtLoginToolStripMenuItem1";
		this.toolStripMenuItem_10.Size = new Size(227, 22);
		this.toolStripMenuItem_10.Text = "Chọn Nhân Vật Login";
		this.toolStripMenuItem_11.Name = "nhânVật1ToolStripMenuItem";
		this.toolStripMenuItem_11.Size = new Size(132, 22);
		this.toolStripMenuItem_11.Text = "Nhân Vật 1";
		this.toolStripMenuItem_11.Click += this.toolStripMenuItem_11_Click;
		this.toolStripMenuItem_12.Name = "nhânVật2ToolStripMenuItem";
		this.toolStripMenuItem_12.Size = new Size(132, 22);
		this.toolStripMenuItem_12.Text = "Nhân Vật 2";
		this.toolStripMenuItem_12.Click += this.toolStripMenuItem_12_Click;
		this.toolStripMenuItem_13.Name = "nhânVật3ToolStripMenuItem";
		this.toolStripMenuItem_13.Size = new Size(132, 22);
		this.toolStripMenuItem_13.Text = "Nhân Vật 3";
		this.toolStripMenuItem_13.Click += this.toolStripMenuItem_13_Click;
		this.toolStripMenuItem_14.Name = "mặcĐịnhToolStripMenuItem";
		this.toolStripMenuItem_14.Size = new Size(132, 22);
		this.toolStripMenuItem_14.Text = "Mặc Định";
		this.toolStripMenuItem_14.Click += this.toolStripMenuItem_14_Click;
		this.toolStripMenuItem_15.Name = "chọnMáyChủToolStripMenuItem1";
		this.toolStripMenuItem_15.Size = new Size(227, 22);
		this.toolStripMenuItem_15.Text = "Chọn Máy Chủ";
		this.toolStripMenuItem_15.Click += this.toolStripMenuItem_15_Click;
		this.toolStripMenuItem_16.Name = "setNhómToolStripMenuItem";
		this.toolStripMenuItem_16.Size = new Size(227, 22);
		this.toolStripMenuItem_16.Text = "Set Nhóm";
		this.toolStripMenuItem_16.Click += this.toolStripMenuItem_16_Click;
		this.toolStripMenuItem_17.Name = "kếtNghĩaToolStripMenuItem";
		this.toolStripMenuItem_17.Size = new Size(227, 22);
		this.toolStripMenuItem_17.Text = "Kết Nghĩa";
		this.toolStripMenuItem_17.Click += this.toolStripMenuItem_17_Click;
		this.loginAccLvl30ToolStripMenuItem.Name = "loginAccLvl30ToolStripMenuItem";
		this.loginAccLvl30ToolStripMenuItem.Size = new Size(227, 22);
		this.loginAccLvl30ToolStripMenuItem.Text = "Login Acc Lvl < 30";
		this.loginAccLvl30ToolStripMenuItem.Click += this.loginAccLvl30ToolStripMenuItem_Click;
		this.toolStripMenuItem_19.Name = "đếmTàiNguyênToolStripMenuItem";
		this.toolStripMenuItem_19.Size = new Size(227, 22);
		this.toolStripMenuItem_19.Text = "Đếm Tài Nguyên";
		this.toolStripMenuItem_19.Click += this.toolStripMenuItem_19_Click;
		this.toolStripMenuItem_31.Name = "chọnMáyChủToolStripMenuItem";
		this.toolStripMenuItem_31.Size = new Size(227, 22);
		this.toolStripMenuItem_31.Text = "Chọn Máy Chủ";
		this.toolStripMenuItem_31.Click += this.toolStripMenuItem_31_Click;
		this.muChuyenServer.Name = "muChuyenServer";
		this.muChuyenServer.Size = new Size(213, 22);
		this.muChuyenServer.Text = "Chuyển Server";
		this.toolStripMenuItem_20.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_21,
			this.toolStripSeparator12,
			this.toolStripMenuItem_22,
			this.toolStripMenuItem_23,
			this.toolStripMenuItem_24,
			this.toolStripSeparator13,
			this.toolStripMenuItem_25,
			this.toolStripMenuItem_26,
			this.toolStripMenuItem6,
			this.toolStripMenuItem_27,
			this.toolStripMenuItem_28,
			this.toolStripSeparator14,
			this.toolStripMenuItem_29,
			this.toolStripMenuItem_30
		});
		this.toolStripMenuItem_20.Name = "báchHoaDuyênToolStripMenuItem";
		this.toolStripMenuItem_20.Size = new Size(213, 22);
		this.toolStripMenuItem_20.Text = "Bách Hoa Duyên";
		this.toolStripMenuItem_21.Name = "chạyBáchHoaDuyênToolStripMenuItem";
		this.toolStripMenuItem_21.Size = new Size(287, 22);
		this.toolStripMenuItem_21.Text = "Chạy Bách Hoa Duyên";
		this.toolStripMenuItem_21.Click += this.toolStripMenuItem_21_Click;
		this.toolStripSeparator12.Name = "toolStripSeparator12";
		this.toolStripSeparator12.Size = new Size(284, 6);
		this.toolStripMenuItem_22.Name = "nhậnMầmHoaHồngBiếnThânToolStripMenuItem";
		this.toolStripMenuItem_22.Size = new Size(287, 22);
		this.toolStripMenuItem_22.Text = "Nhận Mầm + Hoa Hồng + Biến Thân";
		this.toolStripMenuItem_22.Click += this.toolStripMenuItem_22_Click;
		this.toolStripMenuItem_23.Name = "nhậnMầmHoaHồngToolStripMenuItem";
		this.toolStripMenuItem_23.Size = new Size(287, 22);
		this.toolStripMenuItem_23.Text = "Nhận Mầm + Hoa Hồng";
		this.toolStripMenuItem_23.Click += this.toolStripMenuItem_23_Click;
		this.toolStripMenuItem_24.Name = "nhậnHoaHồngToolStripMenuItem";
		this.toolStripMenuItem_24.Size = new Size(287, 22);
		this.toolStripMenuItem_24.Text = "Nhận Hoa Hồng";
		this.toolStripMenuItem_24.Click += this.toolStripMenuItem_24_Click;
		this.toolStripSeparator13.Name = "toolStripSeparator13";
		this.toolStripSeparator13.Size = new Size(284, 6);
		this.toolStripMenuItem_25.Name = "trồngHoaBónHoaNhậnBiếnThânToolStripMenuItem";
		this.toolStripMenuItem_25.Size = new Size(287, 22);
		this.toolStripMenuItem_25.Text = "Trồng Hoa + Bón Hoa + Nhận Biến Thân";
		this.toolStripMenuItem_25.Click += this.toolStripMenuItem_25_Click;
		this.toolStripMenuItem_26.Name = "trồngHoaBónHoaToolStripMenuItem";
		this.toolStripMenuItem_26.Size = new Size(287, 22);
		this.toolStripMenuItem_26.Text = "Trồng Hoa + Bón Hoa";
		this.toolStripMenuItem_26.Click += this.toolStripMenuItem_26_Click;
		this.toolStripMenuItem6.Name = "toolStripMenuItem6";
		this.toolStripMenuItem6.Size = new Size(287, 22);
		this.toolStripMenuItem6.Text = "Trồng Hoa + Bón Hoa + Nhận Mầm";
		this.toolStripMenuItem6.Click += this.toolStripMenuItem6_Click;
		this.toolStripMenuItem_27.Name = "némBiếnThânToolStripMenuItem";
		this.toolStripMenuItem_27.Size = new Size(287, 22);
		this.toolStripMenuItem_27.Text = "Ném Biến Thân";
		this.toolStripMenuItem_27.Click += this.toolStripMenuItem_27_Click;
		this.toolStripMenuItem_28.Name = "bónHoaToolStripMenuItem";
		this.toolStripMenuItem_28.Size = new Size(287, 22);
		this.toolStripMenuItem_28.Text = "Bón Hoa";
		this.toolStripMenuItem_28.Click += this.toolStripMenuItem_28_Click;
		this.toolStripSeparator14.Name = "toolStripSeparator14";
		this.toolStripSeparator14.Size = new Size(284, 6);
		this.toolStripMenuItem_29.Name = "đổi999HoaHồngToolStripMenuItem1";
		this.toolStripMenuItem_29.Size = new Size(287, 22);
		this.toolStripMenuItem_29.Text = "Đổi 999 Hoa Hồng";
		this.toolStripMenuItem_29.Click += this.toolStripMenuItem_29_Click;
		this.toolStripMenuItem_30.DropDownItems.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem7,
			this.toolStripMenuItem8,
			this.toolStripMenuItem9,
			this.toolStripMenuItem10,
			this.toolStripMenuItem11
		});
		this.toolStripMenuItem_30.Name = "trồngHoaTạiTọaĐộToolStripMenuItem";
		this.toolStripMenuItem_30.Size = new Size(287, 22);
		this.toolStripMenuItem_30.Text = "Trồng Hoa Tại Tọa Độ";
		this.toolStripMenuItem7.Name = "toolStripMenuItem7";
		this.toolStripMenuItem7.Size = new Size(80, 22);
		this.toolStripMenuItem7.Text = "1";
		this.toolStripMenuItem7.Click += this.toolStripMenuItem7_Click;
		this.toolStripMenuItem8.Name = "toolStripMenuItem8";
		this.toolStripMenuItem8.Size = new Size(80, 22);
		this.toolStripMenuItem8.Text = "2";
		this.toolStripMenuItem8.Click += this.toolStripMenuItem8_Click;
		this.toolStripMenuItem9.Name = "toolStripMenuItem9";
		this.toolStripMenuItem9.Size = new Size(80, 22);
		this.toolStripMenuItem9.Text = "3";
		this.toolStripMenuItem9.Click += this.toolStripMenuItem9_Click;
		this.toolStripMenuItem10.Name = "toolStripMenuItem10";
		this.toolStripMenuItem10.Size = new Size(80, 22);
		this.toolStripMenuItem10.Text = "4";
		this.toolStripMenuItem10.Click += this.toolStripMenuItem10_Click;
		this.toolStripMenuItem11.Name = "toolStripMenuItem11";
		this.toolStripMenuItem11.Size = new Size(80, 22);
		this.toolStripMenuItem11.Text = "5";
		this.toolStripMenuItem11.Click += this.toolStripMenuItem11_Click;
		this.toolStripSeparator15.Name = "toolStripSeparator15";
		this.toolStripSeparator15.Size = new Size(210, 6);
		this.toolStripMenuItem22.Name = "toolStripMenuItem22";
		this.toolStripMenuItem22.Size = new Size(213, 22);
		this.toolStripMenuItem22.Text = "Login [Enter]";
		this.toolStripMenuItem22.Click += this.toolStripMenuItem22_Click;
		this.toolStripMenuItem23.Name = "toolStripMenuItem23";
		this.toolStripMenuItem23.Size = new Size(213, 22);
		this.toolStripMenuItem23.Text = "Refresh";
		this.toolStripMenuItem23.Click += this.toolStripMenuItem23_Click;
		this.toolStripMenuItem24.Name = "toolStripMenuItem24";
		this.toolStripMenuItem24.Size = new Size(213, 22);
		this.toolStripMenuItem24.Text = "Exit";
		this.toolStripMenuItem24.Click += this.toolStripMenuItem24_Click;
		this.toolStripSeparator16.Name = "toolStripSeparator16";
		this.toolStripSeparator16.Size = new Size(210, 6);
		this.cutToolStripMenuItem1.Name = "cutToolStripMenuItem1";
		this.cutToolStripMenuItem1.Size = new Size(213, 22);
		this.cutToolStripMenuItem1.Text = "Cut [Ctrl + X]";
		this.cutToolStripMenuItem1.Click += this.cutToolStripMenuItem1_Click;
		this.toolStripMenuItem25.Name = "toolStripMenuItem25";
		this.toolStripMenuItem25.Size = new Size(213, 22);
		this.toolStripMenuItem25.Text = "Copy [Ctrl + C]";
		this.toolStripMenuItem25.Click += this.toolStripMenuItem25_Click;
		this.toolStripMenuItem26.Name = "toolStripMenuItem26";
		this.toolStripMenuItem26.Size = new Size(213, 22);
		this.toolStripMenuItem26.Text = "Paste [Ctrl + V]";
		this.toolStripMenuItem26.Click += this.toolStripMenuItem26_Click;
		this.toolStripMenuItem27.Name = "toolStripMenuItem27";
		this.toolStripMenuItem27.Size = new Size(213, 22);
		this.toolStripMenuItem27.Text = "Delete [Delete]";
		this.toolStripMenuItem27.Click += this.toolStripMenuItem27_Click;
		this.toolStripSeparator4.Name = "toolStripSeparator4";
		this.toolStripSeparator4.Size = new Size(210, 6);
		this.getTeamInfoToolStripMenuItem.Name = "getTeamInfoToolStripMenuItem";
		this.getTeamInfoToolStripMenuItem.Size = new Size(213, 22);
		this.getTeamInfoToolStripMenuItem.Text = "GetTeamInfo";
		this.getTeamInfoToolStripMenuItem.Click += this.getTeamInfoToolStripMenuItem_Click;
		this.tagToolStripMenuItem.Name = "tagToolStripMenuItem";
		this.tagToolStripMenuItem.Size = new Size(213, 22);
		this.tagToolStripMenuItem.Text = "Tag";
		this.tagToolStripMenuItem.Click += this.tagToolStripMenuItem_Click;
		this.toolStripMenuItem_32.Name = "tạoNhómToolStripMenuItem";
		this.toolStripMenuItem_32.Size = new Size(213, 22);
		this.toolStripMenuItem_32.Text = "Tạo Nhóm";
		this.toolStripMenuItem_32.Click += this.toolStripMenuItem_32_Click;
		this.toolStripMenuItem_47.Name = "tínhLạiTốcĐộXongBHDToolStripMenuItem";
		this.toolStripMenuItem_47.Size = new Size(213, 22);
		this.toolStripMenuItem_47.Text = "Tính Lại Tốc Độ Xong BHD";
		this.toolStripMenuItem_47.Click += this.toolStripMenuItem_47_Click;
		this.userToolStripMenuItem.Name = "userToolStripMenuItem";
		this.userToolStripMenuItem.Size = new Size(213, 22);
		this.userToolStripMenuItem.Tag = "cl";
		this.userToolStripMenuItem.Text = "User";
		this.userToolStripMenuItem.Click += this.userToolStripMenuItem_Click;
		this.serverToolStripMenuItem.Name = "serverToolStripMenuItem";
		this.serverToolStripMenuItem.Size = new Size(213, 22);
		this.serverToolStripMenuItem.Tag = "cl";
		this.serverToolStripMenuItem.Text = "Server";
		this.serverToolStripMenuItem.Click += this.serverToolStripMenuItem_Click;
		this.toolStripMenuItem_49.Name = "mầmToolStripMenuItem";
		this.toolStripMenuItem_49.Size = new Size(213, 22);
		this.toolStripMenuItem_49.Tag = "cl";
		this.toolStripMenuItem_49.Text = "Mầm";
		this.toolStripMenuItem_49.Click += this.toolStripMenuItem_49_Click;
		this.shitToolStripMenuItem.Name = "shitToolStripMenuItem";
		this.shitToolStripMenuItem.Size = new Size(213, 22);
		this.shitToolStripMenuItem.Tag = "cl";
		this.shitToolStripMenuItem.Text = "Shit";
		this.shitToolStripMenuItem.Click += this.shitToolStripMenuItem_Click;
		this.toolStripMenuItem_50.Name = "bútToolStripMenuItem";
		this.toolStripMenuItem_50.Size = new Size(213, 22);
		this.toolStripMenuItem_50.Tag = "cl";
		this.toolStripMenuItem_50.Text = "Bút";
		this.toolStripMenuItem_50.Click += this.toolStripMenuItem_50_Click;
		this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
		this.infoToolStripMenuItem.Size = new Size(213, 22);
		this.infoToolStripMenuItem.Tag = "cl";
		this.infoToolStripMenuItem.Text = "Info";
		this.infoToolStripMenuItem.Click += this.infoToolStripMenuItem_Click;
		this.nudStop.Dock = DockStyle.Right;
		this.nudStop.Location = new Point(623, 0);
		NumericUpDown numericUpDown = this.nudStop;
		int[] array = new int[4];
		array[0] = 99999;
		numericUpDown.Maximum = new decimal(array);
		this.nudStop.Name = "nudStop";
		this.nudStop.Size = new Size(50, 20);
		this.nudStop.TabIndex = 69;
		this.toolTip_0.SetToolTip(this.nudStop, "Tạm dừng X phút");
		NumericUpDown numericUpDown2 = this.nudStop;
		int[] array2 = new int[4];
		array2[0] = 60;
		numericUpDown2.Value = new decimal(array2);
		this.nudStop.ValueChanged += this.nudStop_ValueChanged;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.label4.BackColor = Color.White;
		this.label4.Cursor = Cursors.Hand;
		this.label4.Dock = DockStyle.Right;
		this.label4.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.label4.ForeColor = Color.Black;
		this.label4.Location = new Point(721, 0);
		this.label4.Name = "label4";
		this.label4.Size = new Size(20, 20);
		this.label4.TabIndex = 73;
		this.label4.Text = "x";
		this.label4.TextAlign = ContentAlignment.TopRight;
		this.toolTip_0.SetToolTip(this.label4, "Thoát");
		this.label4.MouseClick += this.label4_MouseClick;
		this.txtLimit.Dock = DockStyle.Right;
		this.txtLimit.Location = new Point(487, 0);
		this.txtLimit.Name = "txtLimit";
		this.txtLimit.Size = new Size(44, 20);
		this.txtLimit.TabIndex = 72;
		this.toolTip_0.SetToolTip(this.txtLimit, "Cài đặt số acc Login tối đa");
		this.txtLimit.String_0 = "Limit";
		this.txtLimit.Color_0 = Color.Gray;
		this.txtLimit.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtLimit.Color_1 = Color.LightGray;
		this.txtLimit.TextChanged += this.txtLimit_TextChanged;
		this.label1.BackColor = Color.White;
		this.label1.Cursor = Cursors.Hand;
		this.label1.Dock = DockStyle.Right;
		this.label1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.label1.ForeColor = Color.Black;
		this.label1.Location = new Point(673, 0);
		this.label1.Name = "label1";
		this.label1.Size = new Size(48, 20);
		this.label1.TabIndex = 75;
		this.label1.Text = "Save";
		this.label1.TextAlign = ContentAlignment.MiddleCenter;
		this.toolTip_0.SetToolTip(this.label1, "Save");
		this.label1.MouseClick += this.label1_MouseClick;
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += this.timer_0_Tick;
		this.timer_1.Enabled = true;
		this.timer_1.Interval = 150;
		this.timer_1.Tick += this.timer_1_Tick;
		this.timer_2.Enabled = true;
		this.timer_2.Interval = 60000;
		this.timer_2.Tick += this.timer_2_Tick;
		this.panel1.Controls.Add(this.txtSearch);
		this.panel1.Controls.Add(this.txtLimit);
		this.panel1.Controls.Add(this.txtGoTo);
		this.panel1.Controls.Add(this.chkStop);
		this.panel1.Controls.Add(this.nudStop);
		this.panel1.Controls.Add(this.label1);
		this.panel1.Controls.Add(this.label4);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(0, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(741, 20);
		this.panel1.TabIndex = 75;
		this.panel1.Visible = false;
		this.txtSearch.Dock = DockStyle.Fill;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(487, 20);
		this.txtSearch.TabIndex = 67;
		this.txtSearch.String_0 = "Search...";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Arial", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		this.txtGoTo.Dock = DockStyle.Right;
		this.txtGoTo.Location = new Point(531, 0);
		this.txtGoTo.Name = "txtGoTo";
		this.txtGoTo.Size = new Size(44, 20);
		this.txtGoTo.TabIndex = 71;
		this.txtGoTo.String_0 = "GoTo.";
		this.txtGoTo.Color_0 = Color.Gray;
		this.txtGoTo.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtGoTo.Color_1 = Color.LightGray;
		this.txtGoTo.TextChanged += this.txtGoTo_TextChanged;
		this.lvLogin.AllowColumnReorder = true;
		this.lvLogin.AllowDrop = true;
		this.lvLogin.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1,
			this.columnHeader_2,
			this.columnHeader_3,
			this.columnHeader_4,
			this.columnHeader_5,
			this.columnHeader_6,
			this.columnHeader_7,
			this.columnHeader_8,
			this.columnHeader_9,
			this.columnHeader_10
		});
		this.lvLogin.ContextMenuStrip = this.menuListView;
		this.lvLogin.Dock = DockStyle.Fill;
		this.lvLogin.FullRowSelect = true;
		this.lvLogin.GridLines = true;
		this.lvLogin.HideSelection = false;
		this.lvLogin.Location = new Point(0, 20);
		this.lvLogin.Name = "lvLogin";
		this.lvLogin.Size = new Size(741, 421);
		this.lvLogin.TabIndex = 46;
		this.lvLogin.UseCompatibleStateImageBehavior = false;
		this.lvLogin.View = View.Details;
		this.lvLogin.VirtualMode = true;
		this.lvLogin.ColumnClick += this.lvLogin_ColumnClick;
		this.lvLogin.ColumnWidthChanging += this.lvLogin_ColumnWidthChanging;
		this.lvLogin.RetrieveVirtualItem += this.lvLogin_RetrieveVirtualItem;
		this.lvLogin.SelectedIndexChanged += this.lvLogin_SelectedIndexChanged;
		this.lvLogin.DoubleClick += this.lvLogin_DoubleClick;
		this.lvLogin.KeyDown += this.lvLogin_KeyDown;
		this.lvLogin.MouseClick += this.lvLogin_MouseClick;
		this.lvLogin.MouseMove += this.lvLogin_MouseMove;
		this.columnHeader_0.Text = "#";
		this.columnHeader_0.Width = 50;
		this.columnHeader_1.Text = "User";
		this.columnHeader_1.Width = 80;
		this.columnHeader_2.Text = "Name";
		this.columnHeader_2.Width = 80;
		this.columnHeader_3.Text = "Server";
		this.columnHeader_3.Width = 70;
		this.columnHeader_4.Text = "Idx";
		this.columnHeader_4.Width = 32;
		this.columnHeader_5.Text = "Status";
		this.columnHeader_5.Width = 82;
		this.columnHeader_6.Text = "Lvl";
		this.columnHeader_6.Width = 40;
		this.columnHeader_7.Text = "Mầm";
		this.columnHeader_7.Width = 40;
		this.columnHeader_8.Text = "Shit";
		this.columnHeader_8.Width = 40;
		this.columnHeader_9.Text = "Bút";
		this.columnHeader_9.Width = 40;
		this.columnHeader_10.Text = "Info";
		this.columnHeader_10.Width = 120;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.White;
		base.Controls.Add(this.lvLogin);
		base.Controls.Add(this.panel1);
		base.Name = "TabLogin";
		base.Size = new Size(741, 441);
		base.Load += this.TabLogin_Load;
		base.Resize += this.TabLogin_Resize;
		this.menuListView.ResumeLayout(false);
		((ISupportInitialize)this.nudStop).EndInit();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x06001DDD RID: 7645 RVA: 0x000E0C74 File Offset: 0x000DEE74
	[CompilerGenerated]
	private void method_18()
	{
		Thread.CurrentThread.IsBackground = true;
		for (;;)
		{
			try
			{
				if (base.IsDisposed)
				{
					break;
				}
				this.method_3();
			}
			catch
			{
			}
			Thread.Sleep(1200);
		}
	}

	// Token: 0x06001DDE RID: 7646 RVA: 0x00016369 File Offset: 0x00014569
	[CompilerGenerated]
	private bool method_19(KeyValuePair<int, Class159> keyValuePair_0)
	{
		return !keyValuePair_0.Value.list_14.Contains(base.Handle);
	}

	// Token: 0x06001DDF RID: 7647 RVA: 0x000E0CC0 File Offset: 0x000DEEC0
	[CompilerGenerated]
	private void method_20()
	{
		XmlNode xmlNode = this.xmlDocument_0.SelectSingleNode("/*");
		xmlNode.RemoveAll();
		foreach (Class145 @class in this.List_1)
		{
			xmlNode.AppendChild(@class.xmlNode_0);
		}
		foreach (object obj in this.xmlDocument_0.SelectSingleNode("Accounts").SelectNodes("Account"))
		{
			XmlElement xmlElement = (XmlElement)obj;
			if (xmlElement.InnerXml.Trim() == string.Empty)
			{
				xmlElement.IsEmpty = true;
			}
		}
		try
		{
			GClass7 gclass = new GClass7();
			gclass.method_19("cmd", "rgsave");
			gclass.method_19("email", this.string_0);
			gclass.method_19("pass", Class426.Class430.smethod_3(this.string_1));
			gclass.method_19("xml", this.xmlDocument_0.InnerXml);
			gclass.String_2 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36";
			gclass.method_2(Class387.String_0).ToString();
		}
		catch (Exception ex)
		{
			string message = ex.Message;
		}
		base.Enabled = true;
		this.smethod_15(new Action(TabLogin.Class252.<>9.method_7));
	}

	// Token: 0x06001DE0 RID: 7648 RVA: 0x00016385 File Offset: 0x00014585
	[CompilerGenerated]
	private void method_21(ColumnHeader columnHeader_11)
	{
		if (this.list_4.Contains(columnHeader_11.Index))
		{
			columnHeader_11.Width = 0;
		}
	}

	// Token: 0x06001DE1 RID: 7649 RVA: 0x000163A1 File Offset: 0x000145A1
	[CompilerGenerated]
	private bool method_22(Class145 class145_1)
	{
		return class145_1 == this.IEnumerable_1.ToList<Class145>()[0];
	}

	// Token: 0x06001DE2 RID: 7650 RVA: 0x000163A1 File Offset: 0x000145A1
	[CompilerGenerated]
	private bool method_23(Class145 class145_1)
	{
		return class145_1 == this.IEnumerable_1.ToList<Class145>()[0];
	}

	// Token: 0x06001DE3 RID: 7651 RVA: 0x000E0E60 File Offset: 0x000DF060
	[CompilerGenerated]
	private void method_24()
	{
		try
		{
			TabLogin.Class254 @class = new TabLogin.Class254();
			@class.tabLogin_0 = this;
			Thread.CurrentThread.IsBackground = true;
			while (!base.IsHandleCreated)
			{
				Thread.Sleep(1000);
			}
			@class.list_0 = new List<Class145>();
			if (this.txtSearch.Text.Length > 0)
			{
				TabLogin.Class255 class2 = new TabLogin.Class255();
				class2.string_0 = this.txtSearch.Text.smethod_0();
				@class.list_0 = this.List_1.Where(new Func<Class145, bool>(class2.method_0)).ToList<Class145>();
			}
			else
			{
				@class.list_0 = this.List_1;
			}
			base.Invoke(new Action(@class.method_0));
		}
		catch
		{
		}
	}

	// Token: 0x06001DE4 RID: 7652 RVA: 0x000E0F2C File Offset: 0x000DF12C
	[CompilerGenerated]
	private void method_25()
	{
		Main.smethod_11(this.IEnumerable_1.Where(new Func<Class145, bool>(TabLogin.Class252.<>9.method_50)).Select(new Func<Class145, Class159>(TabLogin.Class252.<>9.method_51)).ToList<Class159>());
	}

	// Token: 0x06001DE5 RID: 7653 RVA: 0x000163B7 File Offset: 0x000145B7
	[CompilerGenerated]
	private void method_26()
	{
		MicroLogin.smethod_1();
		this.smethod_15(new Action(TabLogin.Class252.<>9.method_66));
	}

	// Token: 0x040011ED RID: 4589
	[CompilerGenerated]
	private static List<TabLogin> list_0;

	// Token: 0x040011EE RID: 4590
	public bool bool_0;

	// Token: 0x040011EF RID: 4591
	public Class145 class145_0;

	// Token: 0x040011F0 RID: 4592
	public static bool bool_1 = false;

	// Token: 0x040011F1 RID: 4593
	private Thread thread_0;

	// Token: 0x040011F2 RID: 4594
	private bool bool_2;

	// Token: 0x040011F3 RID: 4595
	public static TabLogin tabLogin_0;

	// Token: 0x040011F4 RID: 4596
	public Dictionary<string, string> dictionary_0 = new Dictionary<string, string>();

	// Token: 0x040011F5 RID: 4597
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040011F6 RID: 4598
	[CompilerGenerated]
	private List<Class145> list_1;

	// Token: 0x040011F7 RID: 4599
	public Dictionary<string, string> dictionary_1 = new Dictionary<string, string>();

	// Token: 0x040011F8 RID: 4600
	private bool bool_3 = true;

	// Token: 0x040011F9 RID: 4601
	public static bool bool_4 = true;

	// Token: 0x040011FA RID: 4602
	public static bool bool_5 = true;

	// Token: 0x040011FB RID: 4603
	private string string_0;

	// Token: 0x040011FC RID: 4604
	private string string_1;

	// Token: 0x040011FD RID: 4605
	public XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x040011FE RID: 4606
	[CompilerGenerated]
	private bool bool_6;

	// Token: 0x040011FF RID: 4607
	public int int_1 = 30;

	// Token: 0x04001200 RID: 4608
	public Stopwatch stopwatch_0 = Stopwatch.StartNew();

	// Token: 0x04001201 RID: 4609
	private List<int> list_2 = new List<int>();

	// Token: 0x04001202 RID: 4610
	private Thread thread_1;

	// Token: 0x04001203 RID: 4611
	public List<Class145> list_3 = new List<Class145>();

	// Token: 0x04001204 RID: 4612
	private bool bool_7;

	// Token: 0x04001205 RID: 4613
	public List<int> list_4 = new List<int>
	{
		1,
		3,
		7,
		8,
		9,
		10
	};

	// Token: 0x04001206 RID: 4614
	public List<int> list_5 = new List<int>();

	// Token: 0x04001207 RID: 4615
	private IContainer icontainer_0;

	// Token: 0x04001208 RID: 4616
	private GClass1 lvLogin;

	// Token: 0x04001209 RID: 4617
	private ColumnHeader columnHeader_0;

	// Token: 0x0400120A RID: 4618
	private ColumnHeader columnHeader_1;

	// Token: 0x0400120B RID: 4619
	private ColumnHeader columnHeader_2;

	// Token: 0x0400120C RID: 4620
	private ColumnHeader columnHeader_3;

	// Token: 0x0400120D RID: 4621
	private ColumnHeader columnHeader_4;

	// Token: 0x0400120E RID: 4622
	private ColumnHeader columnHeader_5;

	// Token: 0x0400120F RID: 4623
	private ColumnHeader columnHeader_6;

	// Token: 0x04001210 RID: 4624
	private Class85 txtSearch;

	// Token: 0x04001211 RID: 4625
	private CheckBox chkStop;

	// Token: 0x04001212 RID: 4626
	private NumericUpDown nudStop;

	// Token: 0x04001213 RID: 4627
	private ToolTip toolTip_0;

	// Token: 0x04001214 RID: 4628
	private ColumnHeader columnHeader_7;

	// Token: 0x04001215 RID: 4629
	private ColumnHeader columnHeader_8;

	// Token: 0x04001216 RID: 4630
	private ColumnHeader columnHeader_9;

	// Token: 0x04001217 RID: 4631
	private ColumnHeader columnHeader_10;

	// Token: 0x04001218 RID: 4632
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04001219 RID: 4633
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x0400121A RID: 4634
	private ContextMenuStrip menuListView;

	// Token: 0x0400121B RID: 4635
	private ToolStripMenuItem toolStripMenuItem5;

	// Token: 0x0400121C RID: 4636
	private ToolStripSeparator toolStripSeparator11;

	// Token: 0x0400121D RID: 4637
	private ToolStripMenuItem toolStripMenuItem20;

	// Token: 0x0400121E RID: 4638
	private ToolStripMenuItem toolStripMenuItem21;

	// Token: 0x0400121F RID: 4639
	private ToolStripMenuItem treoShopChoTaToolStripMenuItem;

	// Token: 0x04001220 RID: 4640
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04001221 RID: 4641
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x04001222 RID: 4642
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x04001223 RID: 4643
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x04001224 RID: 4644
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04001225 RID: 4645
	private ToolStripMenuItem muNhanThoiBong;

	// Token: 0x04001226 RID: 4646
	private ToolStripMenuItem managerToolStripMenuItem;

	// Token: 0x04001227 RID: 4647
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04001228 RID: 4648
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x04001229 RID: 4649
	private ToolStripSeparator toolStripSeparator2;

	// Token: 0x0400122A RID: 4650
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x0400122B RID: 4651
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x0400122C RID: 4652
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x0400122D RID: 4653
	private ToolStripMenuItem cleanNameToolStripMenuItem;

	// Token: 0x0400122E RID: 4654
	private ToolStripSeparator toolStripSeparator3;

	// Token: 0x0400122F RID: 4655
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x04001230 RID: 4656
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x04001231 RID: 4657
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x04001232 RID: 4658
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x04001233 RID: 4659
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x04001234 RID: 4660
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x04001235 RID: 4661
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x04001236 RID: 4662
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x04001237 RID: 4663
	private ToolStripMenuItem loginAccLvl30ToolStripMenuItem;

	// Token: 0x04001238 RID: 4664
	private ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x04001239 RID: 4665
	private ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x0400123A RID: 4666
	private ToolStripMenuItem muChuyenServer;

	// Token: 0x0400123B RID: 4667
	private ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x0400123C RID: 4668
	private ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x0400123D RID: 4669
	private ToolStripSeparator toolStripSeparator12;

	// Token: 0x0400123E RID: 4670
	private ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x0400123F RID: 4671
	private ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x04001240 RID: 4672
	private ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x04001241 RID: 4673
	private ToolStripSeparator toolStripSeparator13;

	// Token: 0x04001242 RID: 4674
	private ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x04001243 RID: 4675
	private ToolStripMenuItem toolStripMenuItem_26;

	// Token: 0x04001244 RID: 4676
	private ToolStripMenuItem toolStripMenuItem6;

	// Token: 0x04001245 RID: 4677
	private ToolStripMenuItem toolStripMenuItem_27;

	// Token: 0x04001246 RID: 4678
	private ToolStripMenuItem toolStripMenuItem_28;

	// Token: 0x04001247 RID: 4679
	private ToolStripSeparator toolStripSeparator14;

	// Token: 0x04001248 RID: 4680
	private ToolStripMenuItem toolStripMenuItem_29;

	// Token: 0x04001249 RID: 4681
	private ToolStripMenuItem toolStripMenuItem_30;

	// Token: 0x0400124A RID: 4682
	private ToolStripMenuItem toolStripMenuItem7;

	// Token: 0x0400124B RID: 4683
	private ToolStripMenuItem toolStripMenuItem8;

	// Token: 0x0400124C RID: 4684
	private ToolStripMenuItem toolStripMenuItem9;

	// Token: 0x0400124D RID: 4685
	private ToolStripMenuItem toolStripMenuItem10;

	// Token: 0x0400124E RID: 4686
	private ToolStripMenuItem toolStripMenuItem11;

	// Token: 0x0400124F RID: 4687
	private ToolStripSeparator toolStripSeparator15;

	// Token: 0x04001250 RID: 4688
	private ToolStripMenuItem toolStripMenuItem22;

	// Token: 0x04001251 RID: 4689
	private ToolStripMenuItem toolStripMenuItem23;

	// Token: 0x04001252 RID: 4690
	private ToolStripMenuItem toolStripMenuItem24;

	// Token: 0x04001253 RID: 4691
	private ToolStripSeparator toolStripSeparator16;

	// Token: 0x04001254 RID: 4692
	private ToolStripMenuItem toolStripMenuItem25;

	// Token: 0x04001255 RID: 4693
	private ToolStripMenuItem cutToolStripMenuItem1;

	// Token: 0x04001256 RID: 4694
	private ToolStripMenuItem toolStripMenuItem26;

	// Token: 0x04001257 RID: 4695
	private ToolStripMenuItem toolStripMenuItem27;

	// Token: 0x04001258 RID: 4696
	private ToolStripMenuItem getTeamInfoToolStripMenuItem;

	// Token: 0x04001259 RID: 4697
	private ToolStripMenuItem tagToolStripMenuItem;

	// Token: 0x0400125A RID: 4698
	private ToolStripMenuItem toolStripMenuItem_31;

	// Token: 0x0400125B RID: 4699
	private Class85 txtGoTo;

	// Token: 0x0400125C RID: 4700
	private ToolStripSeparator toolStripSeparator4;

	// Token: 0x0400125D RID: 4701
	private ToolStripMenuItem toolStripMenuItem_32;

	// Token: 0x0400125E RID: 4702
	private Class85 txtLimit;

	// Token: 0x0400125F RID: 4703
	private Label label4;

	// Token: 0x04001260 RID: 4704
	private ToolStripMenuItem toolStripMenuItem_33;

	// Token: 0x04001261 RID: 4705
	private ToolStripMenuItem toolStripMenuItem1;

	// Token: 0x04001262 RID: 4706
	private ToolStripMenuItem toolStripMenuItem_34;

	// Token: 0x04001263 RID: 4707
	private ToolStripMenuItem toolStripMenuItem_35;

	// Token: 0x04001264 RID: 4708
	private ToolStripMenuItem toolStripMenuItem_36;

	// Token: 0x04001265 RID: 4709
	private ToolStripMenuItem toolStripMenuItem_37;

	// Token: 0x04001266 RID: 4710
	private ToolStripMenuItem toolStripMenuItem_38;

	// Token: 0x04001267 RID: 4711
	private ToolStripMenuItem toolStripMenuItem_39;

	// Token: 0x04001268 RID: 4712
	private ToolStripMenuItem toolStripMenuItem_40;

	// Token: 0x04001269 RID: 4713
	private ToolStripMenuItem toolStripMenuItem_41;

	// Token: 0x0400126A RID: 4714
	private ToolStripMenuItem toolStripMenuItem_42;

	// Token: 0x0400126B RID: 4715
	private ToolStripMenuItem toolStripMenuItem_43;

	// Token: 0x0400126C RID: 4716
	private ToolStripMenuItem toolStripMenuItem_44;

	// Token: 0x0400126D RID: 4717
	private ToolStripMenuItem toolStripMenuItem_45;

	// Token: 0x0400126E RID: 4718
	private ToolStripMenuItem toolStripMenuItem_46;

	// Token: 0x0400126F RID: 4719
	private ToolStripMenuItem toolStripMenuItem_47;

	// Token: 0x04001270 RID: 4720
	private ToolStripMenuItem toolStripMenuItem_48;

	// Token: 0x04001271 RID: 4721
	private System.Windows.Forms.Timer timer_2;

	// Token: 0x04001272 RID: 4722
	private Panel panel1;

	// Token: 0x04001273 RID: 4723
	private Label label1;

	// Token: 0x04001274 RID: 4724
	private ToolStripMenuItem userToolStripMenuItem;

	// Token: 0x04001275 RID: 4725
	private ToolStripMenuItem serverToolStripMenuItem;

	// Token: 0x04001276 RID: 4726
	private ToolStripMenuItem toolStripMenuItem_49;

	// Token: 0x04001277 RID: 4727
	private ToolStripMenuItem shitToolStripMenuItem;

	// Token: 0x04001278 RID: 4728
	private ToolStripMenuItem toolStripMenuItem_50;

	// Token: 0x04001279 RID: 4729
	private ToolStripMenuItem infoToolStripMenuItem;

	// Token: 0x0400127A RID: 4730
	private ToolStripMenuItem muAcBa;

	// Token: 0x0400127B RID: 4731
	private ToolStripMenuItem toolStripMenuItem_51;

	// Token: 0x0400127C RID: 4732
	private ToolStripSeparator toolStripSeparator24;

	// Token: 0x0400127D RID: 4733
	private ToolStripMenuItem toolStripMenuItem_52;

	// Token: 0x0400127E RID: 4734
	private ToolStripMenuItem toolStripMenuItem_53;

	// Token: 0x0400127F RID: 4735
	private ToolStripMenuItem toolStripMenuItem_54;

	// Token: 0x04001280 RID: 4736
	private ToolStripMenuItem toolStripMenuItem_55;

	// Token: 0x04001281 RID: 4737
	private ToolStripMenuItem toolStripMenuItem_56;

	// Token: 0x04001282 RID: 4738
	private ToolStripMenuItem toolStripMenuItem_57;

	// Token: 0x04001283 RID: 4739
	private ToolStripMenuItem toolStripMenuItem_58;

	// Token: 0x04001284 RID: 4740
	private ToolStripMenuItem toolStripMenuItem_59;

	// Token: 0x04001285 RID: 4741
	private ToolStripMenuItem toolStripMenuItem_60;

	// Token: 0x04001286 RID: 4742
	private ToolStripMenuItem ngamyToolStripMenuItem;

	// Token: 0x04001287 RID: 4743
	private ToolStripMenuItem toolStripMenuItem_61;

	// Token: 0x04001288 RID: 4744
	private ToolStripMenuItem toolStripMenuItem_62;

	// Token: 0x04001289 RID: 4745
	private ToolStripMenuItem toolStripMenuItem_63;

	// Token: 0x02000222 RID: 546
	[CompilerGenerated]
	private sealed class Class251
	{
		// Token: 0x06001DE7 RID: 7655 RVA: 0x000163E3 File Offset: 0x000145E3
		internal bool method_0(Class145 class145_0)
		{
			return class145_0.class159_0 == this.keyValuePair_0.Value;
		}

		// Token: 0x0400128A RID: 4746
		public KeyValuePair<int, Class159> keyValuePair_0;
	}

	// Token: 0x02000223 RID: 547
	[CompilerGenerated]
	[Serializable]
	private sealed class Class252
	{
		// Token: 0x06001DEA RID: 7658 RVA: 0x00016404 File Offset: 0x00014604
		internal bool method_0(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return !keyValuePair_0.Value.Boolean_9 && !keyValuePair_0.Value.Process_0.HasExited;
		}

		// Token: 0x06001DEB RID: 7659 RVA: 0x0001642A File Offset: 0x0001462A
		internal bool method_1(Class145 class145_0)
		{
			return class145_0.String_20.Contains("Đang chờ");
		}

		// Token: 0x06001DEC RID: 7660 RVA: 0x0001643C File Offset: 0x0001463C
		internal bool method_2(Class145 class145_0)
		{
			return class145_0.String_20.Contains("Đang");
		}

		// Token: 0x06001DED RID: 7661 RVA: 0x0001644E File Offset: 0x0001464E
		internal void method_3(Process process_0)
		{
			process_0.Kill();
		}

		// Token: 0x06001DEE RID: 7662 RVA: 0x00016456 File Offset: 0x00014656
		internal void method_4(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Trừng Ác...";
			class145_0.Boolean_10 = true;
		}

		// Token: 0x06001DEF RID: 7663 RVA: 0x0001646A File Offset: 0x0001466A
		internal bool method_5(Class145 class145_0)
		{
			return class145_0.class159_0 != null;
		}

		// Token: 0x06001DF0 RID: 7664 RVA: 0x0001646A File Offset: 0x0001466A
		internal bool method_6(Class145 class145_0)
		{
			return class145_0.class159_0 != null;
		}

		// Token: 0x06001DF1 RID: 7665 RVA: 0x00016475 File Offset: 0x00014675
		internal void method_7()
		{
			new Loader("Lưu Danh Sách Online Thành Công").method_1();
		}

		// Token: 0x06001DF2 RID: 7666 RVA: 0x00016486 File Offset: 0x00014686
		internal int method_8(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.DisplayIndex;
		}

		// Token: 0x06001DF3 RID: 7667 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_9(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x06001DF4 RID: 7668 RVA: 0x00016486 File Offset: 0x00014686
		internal int method_10(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.DisplayIndex;
		}

		// Token: 0x06001DF5 RID: 7669 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_11(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x06001DF6 RID: 7670 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_12(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x06001DF7 RID: 7671 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_13(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x06001DF8 RID: 7672 RVA: 0x00016496 File Offset: 0x00014696
		internal bool method_14(Class145 class145_0)
		{
			return class145_0.class159_0 != null && class145_0.class159_0.Class432_0.Boolean_34;
		}

		// Token: 0x06001DF9 RID: 7673 RVA: 0x000164B2 File Offset: 0x000146B2
		internal void method_15(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Mua Ngựa...";
			class145_0.Boolean_21 = true;
		}

		// Token: 0x06001DFA RID: 7674 RVA: 0x000164C6 File Offset: 0x000146C6
		internal void method_16(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Nhận Bóng...";
			class145_0.Boolean_25 = true;
		}

		// Token: 0x06001DFB RID: 7675 RVA: 0x000164DA File Offset: 0x000146DA
		internal void method_17(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Thổi Bóng...";
			class145_0.Boolean_26 = true;
		}

		// Token: 0x06001DFC RID: 7676 RVA: 0x000164EE File Offset: 0x000146EE
		internal void method_18(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Kết Nghĩa Nhận Bóng...";
			class145_0.Boolean_28 = true;
		}

		// Token: 0x06001DFD RID: 7677 RVA: 0x00016502 File Offset: 0x00014702
		internal void method_19(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Sư Đồ Nhận Bóng...";
			class145_0.Boolean_27 = true;
		}

		// Token: 0x06001DFE RID: 7678 RVA: 0x000E0F94 File Offset: 0x000DF194
		internal void method_20(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Nhận Thổi Bóng...";
			class145_0.Boolean_26 = true;
			class145_0.Boolean_25 = true;
		}

		// Token: 0x06001DFF RID: 7679 RVA: 0x00016516 File Offset: 0x00014716
		internal void method_21(Class145 class145_0)
		{
			class145_0.String_20 = "";
		}

		// Token: 0x06001E00 RID: 7680 RVA: 0x00016523 File Offset: 0x00014723
		internal void method_22(Class145 class145_0)
		{
			class145_0.String_8 = "";
			class145_0.String_9 = "";
		}

		// Token: 0x06001E01 RID: 7681 RVA: 0x0001653B File Offset: 0x0001473B
		internal void method_23(Class145 class145_0)
		{
			class145_0.String_15 = "1";
		}

		// Token: 0x06001E02 RID: 7682 RVA: 0x00016548 File Offset: 0x00014748
		internal void method_24(Class145 class145_0)
		{
			class145_0.String_15 = "2";
		}

		// Token: 0x06001E03 RID: 7683 RVA: 0x00016555 File Offset: 0x00014755
		internal void method_25(Class145 class145_0)
		{
			class145_0.String_15 = "3";
		}

		// Token: 0x06001E04 RID: 7684 RVA: 0x00016562 File Offset: 0x00014762
		internal void method_26(Class145 class145_0)
		{
			class145_0.String_15 = "";
		}

		// Token: 0x06001E05 RID: 7685 RVA: 0x0001646A File Offset: 0x0001466A
		internal bool method_27(Class145 class145_0)
		{
			return class145_0.class159_0 != null;
		}

		// Token: 0x06001E06 RID: 7686 RVA: 0x0001656F File Offset: 0x0001476F
		internal void method_28(Class145 class145_0)
		{
			class145_0.class159_0.method_226();
		}

		// Token: 0x06001E07 RID: 7687 RVA: 0x0001657C File Offset: 0x0001477C
		internal string method_29(Class145 class145_0)
		{
			return class145_0.String_8;
		}

		// Token: 0x06001E08 RID: 7688 RVA: 0x00011247 File Offset: 0x0000F447
		internal Guid method_30(Class145 class145_0)
		{
			return Guid.NewGuid();
		}

		// Token: 0x06001E09 RID: 7689 RVA: 0x00011247 File Offset: 0x0000F447
		internal Guid method_31(Class145 class145_0)
		{
			return Guid.NewGuid();
		}

		// Token: 0x06001E0A RID: 7690 RVA: 0x00016584 File Offset: 0x00014784
		internal void method_32(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Bách Hoa Duyên...";
			class145_0.Boolean_9 = true;
		}

		// Token: 0x06001E0B RID: 7691 RVA: 0x000E0FBC File Offset: 0x000DF1BC
		internal void method_33(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ nhận Mầm, Hoa Hồng, Biến Thân...";
			class145_0.Boolean_16 = true;
			class145_0.bool_13 = true;
			class145_0.Boolean_9 = true;
		}

		// Token: 0x06001E0C RID: 7692 RVA: 0x000E0FEC File Offset: 0x000DF1EC
		internal void method_34(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ nhận Mầm, Hoa Hồng...";
			class145_0.bool_13 = true;
			class145_0.Boolean_9 = true;
		}

		// Token: 0x06001E0D RID: 7693 RVA: 0x000E1014 File Offset: 0x000DF214
		internal void method_35(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Trồng, Bón, Nhận...";
			class145_0.Boolean_16 = true;
			class145_0.Boolean_29 = true;
		}

		// Token: 0x06001E0E RID: 7694 RVA: 0x000E103C File Offset: 0x000DF23C
		internal void method_36(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ nhận Hoa Hồng...";
			class145_0.Boolean_1 = true;
			class145_0.Boolean_9 = true;
		}

		// Token: 0x06001E0F RID: 7695 RVA: 0x00016598 File Offset: 0x00014798
		internal void method_37(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Trồng, Bón...";
			class145_0.bool_12 = true;
		}

		// Token: 0x06001E10 RID: 7696 RVA: 0x000165AC File Offset: 0x000147AC
		internal void method_38(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Trồng, Bón, Nhận...";
			class145_0.Boolean_29 = true;
		}

		// Token: 0x06001E11 RID: 7697 RVA: 0x000165C0 File Offset: 0x000147C0
		internal void method_39(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Ném Biến Thân...";
			class145_0.Boolean_30 = true;
		}

		// Token: 0x06001E12 RID: 7698 RVA: 0x000165D4 File Offset: 0x000147D4
		internal void method_40(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Bón Hoa...";
			class145_0.Boolean_31 = true;
		}

		// Token: 0x06001E13 RID: 7699 RVA: 0x000165E8 File Offset: 0x000147E8
		internal void method_41(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Đổi 999 Hoa Hồng...";
			class145_0.Boolean_32 = true;
		}

		// Token: 0x06001E14 RID: 7700 RVA: 0x000165FC File Offset: 0x000147FC
		internal void method_42(Class145 class145_0)
		{
			class145_0.Int32_2 = 1;
		}

		// Token: 0x06001E15 RID: 7701 RVA: 0x00016605 File Offset: 0x00014805
		internal void method_43(Class145 class145_0)
		{
			class145_0.Int32_2 = 2;
		}

		// Token: 0x06001E16 RID: 7702 RVA: 0x0001660E File Offset: 0x0001480E
		internal void method_44(Class145 class145_0)
		{
			class145_0.Int32_2 = 3;
		}

		// Token: 0x06001E17 RID: 7703 RVA: 0x00016617 File Offset: 0x00014817
		internal void method_45(Class145 class145_0)
		{
			class145_0.Int32_2 = 4;
		}

		// Token: 0x06001E18 RID: 7704 RVA: 0x00016620 File Offset: 0x00014820
		internal void method_46(Class145 class145_0)
		{
			class145_0.Int32_2 = 5;
		}

		// Token: 0x06001E19 RID: 7705 RVA: 0x00016629 File Offset: 0x00014829
		internal void method_47(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.list_14.Clear();
		}

		// Token: 0x06001E1A RID: 7706 RVA: 0x0001663C File Offset: 0x0001483C
		internal string method_48(KeyValuePair<string, List<string>> keyValuePair_0)
		{
			return keyValuePair_0.Key;
		}

		// Token: 0x06001E1B RID: 7707 RVA: 0x00016645 File Offset: 0x00014845
		internal void method_49(Class145 class145_0)
		{
			if (class145_0.class159_0 != null)
			{
				class145_0.class159_0.method_226();
			}
		}

		// Token: 0x06001E1C RID: 7708 RVA: 0x00016496 File Offset: 0x00014696
		internal bool method_50(Class145 class145_0)
		{
			return class145_0.class159_0 != null && class145_0.class159_0.Class432_0.Boolean_34;
		}

		// Token: 0x06001E1D RID: 7709 RVA: 0x0001665A File Offset: 0x0001485A
		internal Class159 method_51(Class145 class145_0)
		{
			return class145_0.class159_0;
		}

		// Token: 0x06001E1E RID: 7710 RVA: 0x00016662 File Offset: 0x00014862
		internal void method_52()
		{
			new Loader("Không Thể Thoát").method_1();
		}

		// Token: 0x06001E1F RID: 7711 RVA: 0x0001657C File Offset: 0x0001477C
		internal string method_53(Class145 class145_0)
		{
			return class145_0.String_8;
		}

		// Token: 0x06001E20 RID: 7712 RVA: 0x00016673 File Offset: 0x00014873
		internal void method_54(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Q Dưa...";
			class145_0.Boolean_11 = true;
		}

		// Token: 0x06001E21 RID: 7713 RVA: 0x00016456 File Offset: 0x00014656
		internal void method_55(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Trừng Ác...";
			class145_0.Boolean_10 = true;
		}

		// Token: 0x06001E22 RID: 7714 RVA: 0x00016687 File Offset: 0x00014887
		internal void method_56(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Tiềm Năng Tán...";
			class145_0.Boolean_12 = true;
		}

		// Token: 0x06001E23 RID: 7715 RVA: 0x0001669B File Offset: 0x0001489B
		internal void method_57(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Nhiệm Vụ Thăng Cấp...";
			class145_0.Boolean_13 = true;
		}

		// Token: 0x06001E24 RID: 7716 RVA: 0x000166AF File Offset: 0x000148AF
		internal void method_58(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ làm Nhiệm Vụ Exp...";
			class145_0.Boolean_14 = true;
		}

		// Token: 0x06001E25 RID: 7717 RVA: 0x000166C3 File Offset: 0x000148C3
		internal void method_59(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Nhận Lễ Bao...";
			class145_0.Boolean_15 = true;
		}

		// Token: 0x06001E26 RID: 7718 RVA: 0x000166D7 File Offset: 0x000148D7
		internal void method_60(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Nhận Biến Thân...";
			class145_0.Boolean_16 = true;
		}

		// Token: 0x06001E27 RID: 7719 RVA: 0x000166EB File Offset: 0x000148EB
		internal void method_61(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Nhận Bồi Thường...";
			class145_0.Boolean_17 = true;
		}

		// Token: 0x06001E28 RID: 7720 RVA: 0x000166FF File Offset: 0x000148FF
		internal void method_62(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Ác Tặc...";
			class145_0.Boolean_18 = true;
		}

		// Token: 0x06001E29 RID: 7721 RVA: 0x00016713 File Offset: 0x00014913
		internal void method_63(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Thiếu Thất Sơn...";
			class145_0.Boolean_19 = true;
		}

		// Token: 0x06001E2A RID: 7722 RVA: 0x00016727 File Offset: 0x00014927
		internal void method_64(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Lâu Lan Tầm Bảo...";
			class145_0.Boolean_20 = true;
		}

		// Token: 0x06001E2B RID: 7723 RVA: 0x0001673B File Offset: 0x0001493B
		internal bool method_65(Class145 class145_0)
		{
			return class145_0.listViewItem_0 == null;
		}

		// Token: 0x06001E2C RID: 7724 RVA: 0x00016746 File Offset: 0x00014946
		internal void method_66()
		{
			new Loader("Lưu Danh Sách Login Thành Công").method_1();
		}

		// Token: 0x06001E2D RID: 7725 RVA: 0x00016757 File Offset: 0x00014957
		internal void method_67()
		{
			new Loader("Không Thể Lưu").method_1();
		}

		// Token: 0x06001E2E RID: 7726 RVA: 0x00016768 File Offset: 0x00014968
		internal string method_68(int int_0)
		{
			return int_0.ToString();
		}

		// Token: 0x0400128B RID: 4747
		public static readonly TabLogin.Class252 <>9 = new TabLogin.Class252();

		// Token: 0x0400128C RID: 4748
		public static Func<KeyValuePair<int, Class159>, bool> <>9__7_1;

		// Token: 0x0400128D RID: 4749
		public static Func<Class145, bool> <>9__7_0;

		// Token: 0x0400128E RID: 4750
		public static Func<Class145, bool> <>9__9_0;

		// Token: 0x0400128F RID: 4751
		public static Action<Process> <>9__16_0;

		// Token: 0x04001290 RID: 4752
		public static Action<Class145> <>9__16_1;

		// Token: 0x04001291 RID: 4753
		public static Func<Class145, bool> <>9__16_3;

		// Token: 0x04001292 RID: 4754
		public static Func<Class145, bool> <>9__16_7;

		// Token: 0x04001293 RID: 4755
		public static Action <>9__30_1;

		// Token: 0x04001294 RID: 4756
		public static Func<ColumnHeader, int> <>9__52_2;

		// Token: 0x04001295 RID: 4757
		public static Func<ColumnHeader, int> <>9__52_0;

		// Token: 0x04001296 RID: 4758
		public static Func<ColumnHeader, int> <>9__52_3;

		// Token: 0x04001297 RID: 4759
		public static Func<ColumnHeader, int> <>9__52_4;

		// Token: 0x04001298 RID: 4760
		public static Func<ColumnHeader, int> <>9__52_5;

		// Token: 0x04001299 RID: 4761
		public static Func<ColumnHeader, int> <>9__52_1;

		// Token: 0x0400129A RID: 4762
		public static Func<Class145, bool> <>9__67_0;

		// Token: 0x0400129B RID: 4763
		public static Action<Class145> <>9__69_0;

		// Token: 0x0400129C RID: 4764
		public static Action<Class145> <>9__73_0;

		// Token: 0x0400129D RID: 4765
		public static Action<Class145> <>9__74_0;

		// Token: 0x0400129E RID: 4766
		public static Action<Class145> <>9__75_0;

		// Token: 0x0400129F RID: 4767
		public static Action<Class145> <>9__76_0;

		// Token: 0x040012A0 RID: 4768
		public static Action<Class145> <>9__77_0;

		// Token: 0x040012A1 RID: 4769
		public static Action<Class145> <>9__82_0;

		// Token: 0x040012A2 RID: 4770
		public static Action<Class145> <>9__83_0;

		// Token: 0x040012A3 RID: 4771
		public static Action<Class145> <>9__84_0;

		// Token: 0x040012A4 RID: 4772
		public static Action<Class145> <>9__85_0;

		// Token: 0x040012A5 RID: 4773
		public static Action<Class145> <>9__86_0;

		// Token: 0x040012A6 RID: 4774
		public static Action<Class145> <>9__87_0;

		// Token: 0x040012A7 RID: 4775
		public static Func<Class145, bool> <>9__88_0;

		// Token: 0x040012A8 RID: 4776
		public static Action<Class145> <>9__88_1;

		// Token: 0x040012A9 RID: 4777
		public static Func<Class145, string> <>9__89_0;

		// Token: 0x040012AA RID: 4778
		public static Func<Class145, Guid> <>9__92_0;

		// Token: 0x040012AB RID: 4779
		public static Func<Class145, Guid> <>9__92_1;

		// Token: 0x040012AC RID: 4780
		public static Action<Class145> <>9__95_0;

		// Token: 0x040012AD RID: 4781
		public static Action<Class145> <>9__96_0;

		// Token: 0x040012AE RID: 4782
		public static Action<Class145> <>9__97_0;

		// Token: 0x040012AF RID: 4783
		public static Action<Class145> <>9__98_0;

		// Token: 0x040012B0 RID: 4784
		public static Action<Class145> <>9__99_0;

		// Token: 0x040012B1 RID: 4785
		public static Action<Class145> <>9__100_0;

		// Token: 0x040012B2 RID: 4786
		public static Action<Class145> <>9__101_0;

		// Token: 0x040012B3 RID: 4787
		public static Action<Class145> <>9__102_0;

		// Token: 0x040012B4 RID: 4788
		public static Action<Class145> <>9__103_0;

		// Token: 0x040012B5 RID: 4789
		public static Action<Class145> <>9__104_0;

		// Token: 0x040012B6 RID: 4790
		public static Action<Class145> <>9__105_0;

		// Token: 0x040012B7 RID: 4791
		public static Action<Class145> <>9__106_0;

		// Token: 0x040012B8 RID: 4792
		public static Action<Class145> <>9__107_0;

		// Token: 0x040012B9 RID: 4793
		public static Action<Class145> <>9__108_0;

		// Token: 0x040012BA RID: 4794
		public static Action<Class145> <>9__109_0;

		// Token: 0x040012BB RID: 4795
		public static Action<KeyValuePair<int, Class159>> <>9__111_0;

		// Token: 0x040012BC RID: 4796
		public static Func<KeyValuePair<string, List<string>>, string> <>9__117_1;

		// Token: 0x040012BD RID: 4797
		public static Action<Class145> <>9__120_0;

		// Token: 0x040012BE RID: 4798
		public static Func<Class145, bool> <>9__122_1;

		// Token: 0x040012BF RID: 4799
		public static Func<Class145, Class159> <>9__122_2;

		// Token: 0x040012C0 RID: 4800
		public static Action <>9__123_0;

		// Token: 0x040012C1 RID: 4801
		public static Func<Class145, string> <>9__124_0;

		// Token: 0x040012C2 RID: 4802
		public static Action<Class145> <>9__127_0;

		// Token: 0x040012C3 RID: 4803
		public static Action<Class145> <>9__128_0;

		// Token: 0x040012C4 RID: 4804
		public static Action<Class145> <>9__129_0;

		// Token: 0x040012C5 RID: 4805
		public static Action<Class145> <>9__130_0;

		// Token: 0x040012C6 RID: 4806
		public static Action<Class145> <>9__131_0;

		// Token: 0x040012C7 RID: 4807
		public static Action<Class145> <>9__132_0;

		// Token: 0x040012C8 RID: 4808
		public static Action<Class145> <>9__133_0;

		// Token: 0x040012C9 RID: 4809
		public static Action<Class145> <>9__134_0;

		// Token: 0x040012CA RID: 4810
		public static Action<Class145> <>9__135_0;

		// Token: 0x040012CB RID: 4811
		public static Action<Class145> <>9__136_0;

		// Token: 0x040012CC RID: 4812
		public static Action<Class145> <>9__137_0;

		// Token: 0x040012CD RID: 4813
		public static Func<Class145, bool> <>9__140_0;

		// Token: 0x040012CE RID: 4814
		public static Action <>9__144_2;

		// Token: 0x040012CF RID: 4815
		public static Action <>9__144_1;

		// Token: 0x040012D0 RID: 4816
		public static Func<int, string> <>9__154_0;
	}

	// Token: 0x02000224 RID: 548
	[CompilerGenerated]
	private sealed class Class253
	{
		// Token: 0x06001E30 RID: 7728 RVA: 0x00016771 File Offset: 0x00014971
		internal bool method_0(Class145 class145_1)
		{
			return class145_1.class159_0 != null && class145_1.Boolean_31 && class145_1.Int32_2 == this.class145_0.Int32_2;
		}

		// Token: 0x06001E31 RID: 7729 RVA: 0x00016798 File Offset: 0x00014998
		internal bool method_1(Class145 class145_1)
		{
			return class145_1.class159_0 != null && (class145_1.bool_12 || class145_1.Boolean_29) && class145_1.Int32_2 == this.class145_0.Int32_2;
		}

		// Token: 0x06001E32 RID: 7730 RVA: 0x000167C7 File Offset: 0x000149C7
		internal bool method_2(Class145 class145_1)
		{
			return class145_1.class159_0 != null && class145_1.Boolean_30 && class145_1.Int32_2 == this.class145_0.Int32_2;
		}

		// Token: 0x040012D1 RID: 4817
		public Class145 class145_0;
	}

	// Token: 0x02000225 RID: 549
	[CompilerGenerated]
	private sealed class Class254
	{
		// Token: 0x06001E34 RID: 7732 RVA: 0x000E1064 File Offset: 0x000DF264
		internal void method_0()
		{
			this.tabLogin_0.lvLogin.BeginUpdate();
			this.tabLogin_0.list_3 = this.list_0;
			this.tabLogin_0.lvLogin.VirtualListSize = this.tabLogin_0.list_3.Count;
			this.tabLogin_0.lvLogin.Columns[0].Text = "[" + this.tabLogin_0.list_3.Count.ToString() + "]";
			this.tabLogin_0.lvLogin.EndUpdate();
		}

		// Token: 0x040012D2 RID: 4818
		public List<Class145> list_0;

		// Token: 0x040012D3 RID: 4819
		public TabLogin tabLogin_0;
	}

	// Token: 0x02000226 RID: 550
	[CompilerGenerated]
	private sealed class Class255
	{
		// Token: 0x06001E36 RID: 7734 RVA: 0x000167EE File Offset: 0x000149EE
		internal bool method_0(Class145 class145_0)
		{
			return class145_0.String_3.Contains(this.string_0);
		}

		// Token: 0x040012D4 RID: 4820
		public string string_0;
	}

	// Token: 0x02000229 RID: 553
	[CompilerGenerated]
	private sealed class Class258
	{
		// Token: 0x06001E4A RID: 7754 RVA: 0x000E13E4 File Offset: 0x000DF5E4
		internal void method_0(object sender, EventArgs e)
		{
			foreach (Class145 @class in this.tabLogin_0.IEnumerable_1)
			{
				@class.String_6 = this.toolStripMenuItem_0.Text;
			}
		}

		// Token: 0x040012DF RID: 4831
		public ToolStripMenuItem toolStripMenuItem_0;

		// Token: 0x040012E0 RID: 4832
		public TabLogin tabLogin_0;
	}

	// Token: 0x0200022A RID: 554
	[CompilerGenerated]
	private sealed class Class259
	{
		// Token: 0x06001E4C RID: 7756 RVA: 0x00016855 File Offset: 0x00014A55
		internal bool method_0(KeyValuePair<string, List<string>> keyValuePair_0)
		{
			return keyValuePair_0.Value.Contains(this.class145_0.String_8);
		}

		// Token: 0x040012E1 RID: 4833
		public Class145 class145_0;
	}

	// Token: 0x0200022B RID: 555
	[CompilerGenerated]
	private sealed class Class260
	{
		// Token: 0x06001E4E RID: 7758 RVA: 0x000E1440 File Offset: 0x000DF640
		internal void method_0(object sender, EventArgs e)
		{
			if (this.inputBox_0.String_0 != null)
			{
				foreach (Class145 @class in this.tabLogin_0.IEnumerable_1)
				{
					try
					{
						@class.String_11 = this.inputBox_0.String_0;
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x040012E2 RID: 4834
		public InputBox inputBox_0;

		// Token: 0x040012E3 RID: 4835
		public TabLogin tabLogin_0;
	}

	// Token: 0x0200022C RID: 556
	[CompilerGenerated]
	private sealed class Class261
	{
		// Token: 0x06001E50 RID: 7760 RVA: 0x000E14BC File Offset: 0x000DF6BC
		internal string method_0(Class145 class145_0)
		{
			return class145_0.listViewItem_0.SubItems[Convert.ToInt32(this.columnClickEventArgs_0.Column.ToString())].Text;
		}

		// Token: 0x06001E51 RID: 7761 RVA: 0x000E14BC File Offset: 0x000DF6BC
		internal string method_1(Class145 class145_0)
		{
			return class145_0.listViewItem_0.SubItems[Convert.ToInt32(this.columnClickEventArgs_0.Column.ToString())].Text;
		}

		// Token: 0x040012E4 RID: 4836
		public ColumnClickEventArgs columnClickEventArgs_0;
	}

	// Token: 0x0200022D RID: 557
	[CompilerGenerated]
	private sealed class Class262
	{
		// Token: 0x06001E53 RID: 7763 RVA: 0x0001686E File Offset: 0x00014A6E
		internal int method_0(Class145 class145_0)
		{
			return Class426.smethod_41(class145_0.listViewItem_0.SubItems[this.int_0].Text);
		}

		// Token: 0x06001E54 RID: 7764 RVA: 0x0001686E File Offset: 0x00014A6E
		internal int method_1(Class145 class145_0)
		{
			return Class426.smethod_41(class145_0.listViewItem_0.SubItems[this.int_0].Text);
		}

		// Token: 0x06001E55 RID: 7765 RVA: 0x0001686E File Offset: 0x00014A6E
		internal int method_2(Class145 class145_0)
		{
			return Class426.smethod_41(class145_0.listViewItem_0.SubItems[this.int_0].Text);
		}

		// Token: 0x06001E56 RID: 7766 RVA: 0x0001686E File Offset: 0x00014A6E
		internal int method_3(Class145 class145_0)
		{
			return Class426.smethod_41(class145_0.listViewItem_0.SubItems[this.int_0].Text);
		}

		// Token: 0x06001E57 RID: 7767 RVA: 0x00016890 File Offset: 0x00014A90
		internal string method_4(Class145 class145_0)
		{
			return class145_0.listViewItem_0.SubItems[this.int_0].Text;
		}

		// Token: 0x06001E58 RID: 7768 RVA: 0x00016890 File Offset: 0x00014A90
		internal string method_5(Class145 class145_0)
		{
			return class145_0.listViewItem_0.SubItems[this.int_0].Text;
		}

		// Token: 0x040012E5 RID: 4837
		public int int_0;
	}

	// Token: 0x0200022E RID: 558
	[CompilerGenerated]
	private sealed class Class263
	{
		// Token: 0x06001E5A RID: 7770 RVA: 0x000168AD File Offset: 0x00014AAD
		internal void method_0(Class145 class145_0)
		{
			class145_0.String_20 = "Đang chờ Ác Bá...";
			class145_0.String_0 = (this.object_0 as ToolStripMenuItem).Text;
		}

		// Token: 0x040012E6 RID: 4838
		public object object_0;
	}
}
