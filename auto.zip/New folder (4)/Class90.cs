﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000C9 RID: 201
internal class Class90
{
	// Token: 0x170002AF RID: 687
	// (get) Token: 0x060009A4 RID: 2468 RVA: 0x000094E0 File Offset: 0x000076E0
	// (set) Token: 0x060009A5 RID: 2469 RVA: 0x000094E8 File Offset: 0x000076E8
	public GStruct2 GStruct2_0 { get; set; }

	// Token: 0x170002B0 RID: 688
	// (get) Token: 0x060009A6 RID: 2470 RVA: 0x000094F1 File Offset: 0x000076F1
	// (set) Token: 0x060009A7 RID: 2471 RVA: 0x000094F9 File Offset: 0x000076F9
	public GStruct2 GStruct2_1 { get; set; }

	// Token: 0x060009A8 RID: 2472 RVA: 0x00009502 File Offset: 0x00007702
	public Class90(GClass86 gclass86_0)
	{
		this.GStruct2_0 = gclass86_0.GStruct2_0;
		this.GStruct2_1 = gclass86_0.GStruct2_1;
	}

	// Token: 0x170002B1 RID: 689
	// (get) Token: 0x060009A9 RID: 2473 RVA: 0x0003EAE4 File Offset: 0x0003CCE4
	internal int Int32_0
	{
		get
		{
			if (this.GStruct2_1.int_1 < this.GStruct2_0.int_1)
			{
				return this.GStruct2_1.int_0;
			}
			if (this.GStruct2_1.int_1 > this.GStruct2_0.int_1)
			{
				return this.GStruct2_0.int_0;
			}
			return Math.Min(this.GStruct2_1.int_0, this.GStruct2_0.int_0);
		}
	}

	// Token: 0x040004C3 RID: 1219
	[CompilerGenerated]
	private GStruct2 gstruct2_0;

	// Token: 0x040004C4 RID: 1220
	[CompilerGenerated]
	private GStruct2 gstruct2_1;
}
