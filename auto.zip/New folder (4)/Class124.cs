﻿using System;

// Token: 0x0200013F RID: 319
internal static class Class124
{
	// Token: 0x06000FAA RID: 4010 RVA: 0x00059488 File Offset: 0x00057688
	public static string smethod_0(TimeSpan timeSpan_0)
	{
		if (timeSpan_0 == TimeSpan.MaxValue)
		{
			return "?";
		}
		string text = timeSpan_0.ToString();
		int num = text.LastIndexOf('.');
		if (num > 0)
		{
			return text.Remove(num);
		}
		return text;
	}
}
