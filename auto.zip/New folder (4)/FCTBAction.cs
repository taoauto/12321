﻿using System;

// Token: 0x02000102 RID: 258
public enum FCTBAction
{
	// Token: 0x04000639 RID: 1593
	None,
	// Token: 0x0400063A RID: 1594
	AutocompleteMenu,
	// Token: 0x0400063B RID: 1595
	AutoIndentChars,
	// Token: 0x0400063C RID: 1596
	BookmarkLine,
	// Token: 0x0400063D RID: 1597
	ClearHints,
	// Token: 0x0400063E RID: 1598
	ClearWordLeft,
	// Token: 0x0400063F RID: 1599
	ClearWordRight,
	// Token: 0x04000640 RID: 1600
	CommentSelected,
	// Token: 0x04000641 RID: 1601
	Copy,
	// Token: 0x04000642 RID: 1602
	Cut,
	// Token: 0x04000643 RID: 1603
	DeleteCharRight,
	// Token: 0x04000644 RID: 1604
	FindChar,
	// Token: 0x04000645 RID: 1605
	FindDialog,
	// Token: 0x04000646 RID: 1606
	FindNext,
	// Token: 0x04000647 RID: 1607
	GoDown,
	// Token: 0x04000648 RID: 1608
	GoDownWithSelection,
	// Token: 0x04000649 RID: 1609
	GoDown_ColumnSelectionMode,
	// Token: 0x0400064A RID: 1610
	GoEnd,
	// Token: 0x0400064B RID: 1611
	GoEndWithSelection,
	// Token: 0x0400064C RID: 1612
	GoFirstLine,
	// Token: 0x0400064D RID: 1613
	GoFirstLineWithSelection,
	// Token: 0x0400064E RID: 1614
	GoHome,
	// Token: 0x0400064F RID: 1615
	GoHomeWithSelection,
	// Token: 0x04000650 RID: 1616
	GoLastLine,
	// Token: 0x04000651 RID: 1617
	GoLastLineWithSelection,
	// Token: 0x04000652 RID: 1618
	GoLeft,
	// Token: 0x04000653 RID: 1619
	GoLeftWithSelection,
	// Token: 0x04000654 RID: 1620
	GoLeft_ColumnSelectionMode,
	// Token: 0x04000655 RID: 1621
	GoPageDown,
	// Token: 0x04000656 RID: 1622
	GoPageDownWithSelection,
	// Token: 0x04000657 RID: 1623
	GoPageUp,
	// Token: 0x04000658 RID: 1624
	GoPageUpWithSelection,
	// Token: 0x04000659 RID: 1625
	GoRight,
	// Token: 0x0400065A RID: 1626
	GoRightWithSelection,
	// Token: 0x0400065B RID: 1627
	GoRight_ColumnSelectionMode,
	// Token: 0x0400065C RID: 1628
	GoToDialog,
	// Token: 0x0400065D RID: 1629
	GoNextBookmark,
	// Token: 0x0400065E RID: 1630
	GoPrevBookmark,
	// Token: 0x0400065F RID: 1631
	GoUp,
	// Token: 0x04000660 RID: 1632
	GoUpWithSelection,
	// Token: 0x04000661 RID: 1633
	GoUp_ColumnSelectionMode,
	// Token: 0x04000662 RID: 1634
	GoWordLeft,
	// Token: 0x04000663 RID: 1635
	GoWordLeftWithSelection,
	// Token: 0x04000664 RID: 1636
	GoWordRight,
	// Token: 0x04000665 RID: 1637
	GoWordRightWithSelection,
	// Token: 0x04000666 RID: 1638
	IndentIncrease,
	// Token: 0x04000667 RID: 1639
	IndentDecrease,
	// Token: 0x04000668 RID: 1640
	LowerCase,
	// Token: 0x04000669 RID: 1641
	MacroExecute,
	// Token: 0x0400066A RID: 1642
	MacroRecord,
	// Token: 0x0400066B RID: 1643
	MoveSelectedLinesDown,
	// Token: 0x0400066C RID: 1644
	MoveSelectedLinesUp,
	// Token: 0x0400066D RID: 1645
	NavigateBackward,
	// Token: 0x0400066E RID: 1646
	NavigateForward,
	// Token: 0x0400066F RID: 1647
	Paste,
	// Token: 0x04000670 RID: 1648
	Redo,
	// Token: 0x04000671 RID: 1649
	ReplaceDialog,
	// Token: 0x04000672 RID: 1650
	ReplaceMode,
	// Token: 0x04000673 RID: 1651
	ScrollDown,
	// Token: 0x04000674 RID: 1652
	ScrollUp,
	// Token: 0x04000675 RID: 1653
	SelectAll,
	// Token: 0x04000676 RID: 1654
	UnbookmarkLine,
	// Token: 0x04000677 RID: 1655
	Undo,
	// Token: 0x04000678 RID: 1656
	UpperCase,
	// Token: 0x04000679 RID: 1657
	ZoomIn,
	// Token: 0x0400067A RID: 1658
	ZoomNormal,
	// Token: 0x0400067B RID: 1659
	ZoomOut,
	// Token: 0x0400067C RID: 1660
	CustomAction1,
	// Token: 0x0400067D RID: 1661
	CustomAction2,
	// Token: 0x0400067E RID: 1662
	CustomAction3,
	// Token: 0x0400067F RID: 1663
	CustomAction4,
	// Token: 0x04000680 RID: 1664
	CustomAction5,
	// Token: 0x04000681 RID: 1665
	CustomAction6,
	// Token: 0x04000682 RID: 1666
	CustomAction7,
	// Token: 0x04000683 RID: 1667
	CustomAction8,
	// Token: 0x04000684 RID: 1668
	CustomAction9,
	// Token: 0x04000685 RID: 1669
	CustomAction10,
	// Token: 0x04000686 RID: 1670
	CustomAction11,
	// Token: 0x04000687 RID: 1671
	CustomAction12,
	// Token: 0x04000688 RID: 1672
	CustomAction13,
	// Token: 0x04000689 RID: 1673
	CustomAction14,
	// Token: 0x0400068A RID: 1674
	CustomAction15,
	// Token: 0x0400068B RID: 1675
	CustomAction16,
	// Token: 0x0400068C RID: 1676
	CustomAction17,
	// Token: 0x0400068D RID: 1677
	CustomAction18,
	// Token: 0x0400068E RID: 1678
	CustomAction19,
	// Token: 0x0400068F RID: 1679
	CustomAction20
}
