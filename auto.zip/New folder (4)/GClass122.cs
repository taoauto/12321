﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Design;

// Token: 0x02000212 RID: 530
[ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.ToolStrip)]
public class GClass122 : ToolStripButton
{
	// Token: 0x06001B75 RID: 7029 RVA: 0x00013EE5 File Offset: 0x000120E5
	public GClass122()
	{
		this.method_0();
	}

	// Token: 0x06001B76 RID: 7030 RVA: 0x00013F09 File Offset: 0x00012109
	public GClass122(Image image_0) : base(image_0)
	{
		this.method_0();
	}

	// Token: 0x06001B77 RID: 7031 RVA: 0x00013F2E File Offset: 0x0001212E
	public GClass122(string string_0) : base(string_0)
	{
		this.method_0();
	}

	// Token: 0x06001B78 RID: 7032 RVA: 0x00013F53 File Offset: 0x00012153
	public GClass122(string string_0, Image image_0) : base(string_0, image_0)
	{
		this.method_0();
	}

	// Token: 0x06001B79 RID: 7033 RVA: 0x00013F79 File Offset: 0x00012179
	public GClass122(string string_0, Image image_0, EventHandler eventHandler_0) : base(string_0, image_0, eventHandler_0)
	{
		this.method_0();
	}

	// Token: 0x06001B7A RID: 7034 RVA: 0x00013FA0 File Offset: 0x000121A0
	public GClass122(string string_0, Image image_0, EventHandler eventHandler_0, string string_1) : base(string_0, image_0, eventHandler_0, string_1)
	{
		this.method_0();
	}

	// Token: 0x06001B7B RID: 7035 RVA: 0x00013FC9 File Offset: 0x000121C9
	private void method_0()
	{
		this.font_0 = this.Font;
	}

	// Token: 0x06001B7C RID: 7036 RVA: 0x000D19EC File Offset: 0x000CFBEC
	public virtual Size GetPreferredSize(Size constrainingSize)
	{
		Size preferredSize = base.GetPreferredSize(constrainingSize);
		if (base.Owner != null && base.Owner.Orientation == Orientation.Vertical)
		{
			preferredSize.Width += 3;
			preferredSize.Height += 10;
		}
		return preferredSize;
	}

	// Token: 0x17000688 RID: 1672
	// (get) Token: 0x06001B7D RID: 7037 RVA: 0x00013FD7 File Offset: 0x000121D7
	protected virtual Padding DefaultMargin
	{
		get
		{
			return new Padding(0);
		}
	}

	// Token: 0x17000689 RID: 1673
	// (get) Token: 0x06001B7E RID: 7038 RVA: 0x00013FDF File Offset: 0x000121DF
	// (set) Token: 0x06001B7F RID: 7039 RVA: 0x00002E18 File Offset: 0x00001018
	[Browsable(false)]
	public Padding Padding_0
	{
		get
		{
			return base.Margin;
		}
		set
		{
		}
	}

	// Token: 0x1700068A RID: 1674
	// (get) Token: 0x06001B80 RID: 7040 RVA: 0x00013FE7 File Offset: 0x000121E7
	// (set) Token: 0x06001B81 RID: 7041 RVA: 0x00002E18 File Offset: 0x00001018
	[Browsable(false)]
	public Padding Padding_1
	{
		get
		{
			return base.Padding;
		}
		set
		{
		}
	}

	// Token: 0x1700068B RID: 1675
	// (get) Token: 0x06001B82 RID: 7042 RVA: 0x00013FEF File Offset: 0x000121EF
	// (set) Token: 0x06001B83 RID: 7043 RVA: 0x00013FF7 File Offset: 0x000121F7
	[Category("Appearance")]
	[Description("Text color when TabButton is highlighted")]
	public Color Color_0
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
		}
	}

	// Token: 0x1700068C RID: 1676
	// (get) Token: 0x06001B84 RID: 7044 RVA: 0x00014000 File Offset: 0x00012200
	// (set) Token: 0x06001B85 RID: 7045 RVA: 0x00014008 File Offset: 0x00012208
	[Category("Appearance")]
	[Description("Text color when TabButton is selected")]
	public Color Color_1
	{
		get
		{
			return this.color_1;
		}
		set
		{
			this.color_1 = value;
		}
	}

	// Token: 0x1700068D RID: 1677
	// (get) Token: 0x06001B86 RID: 7046 RVA: 0x00014011 File Offset: 0x00012211
	// (set) Token: 0x06001B87 RID: 7047 RVA: 0x00014028 File Offset: 0x00012228
	[Category("Appearance")]
	[Description("Font when TabButton is selected")]
	public Font Font_0
	{
		get
		{
			if (this.font_0 != null)
			{
				return this.font_0;
			}
			return this.Font;
		}
		set
		{
			this.font_0 = value;
		}
	}

	// Token: 0x1700068E RID: 1678
	// (get) Token: 0x06001B88 RID: 7048 RVA: 0x00014031 File Offset: 0x00012231
	// (set) Token: 0x06001B89 RID: 7049 RVA: 0x00002E18 File Offset: 0x00001018
	[Browsable(false)]
	[DefaultValue(false)]
	public bool Boolean_0
	{
		get
		{
			return this.Boolean_1;
		}
		set
		{
		}
	}

	// Token: 0x1700068F RID: 1679
	// (get) Token: 0x06001B8A RID: 7050 RVA: 0x000D1A38 File Offset: 0x000CFC38
	// (set) Token: 0x06001B8B RID: 7051 RVA: 0x000D1A60 File Offset: 0x000CFC60
	[Browsable(false)]
	public bool Boolean_1
	{
		get
		{
			GClass121 gclass = base.Owner as GClass121;
			return gclass != null && this == gclass.GClass122_0;
		}
		set
		{
			if (!value)
			{
				return;
			}
			GClass121 gclass = base.Owner as GClass121;
			if (gclass == null)
			{
				return;
			}
			gclass.GClass122_0 = this;
		}
	}

	// Token: 0x06001B8C RID: 7052 RVA: 0x00014039 File Offset: 0x00012239
	protected virtual void OnOwnerChanged(EventArgs e)
	{
		if (base.Owner != null && !(base.Owner is GClass121))
		{
			throw new Exception("Cannot add TabStripButton to " + base.Owner.GetType().Name);
		}
		base.OnOwnerChanged(e);
	}

	// Token: 0x04001159 RID: 4441
	private Color color_0 = Control.DefaultForeColor;

	// Token: 0x0400115A RID: 4442
	private Color color_1 = Control.DefaultForeColor;

	// Token: 0x0400115B RID: 4443
	private Font font_0;
}
