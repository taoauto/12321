﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020002EA RID: 746
public class GControl4 : TabControl
{
	// Token: 0x06002AB3 RID: 10931 RVA: 0x0001F176 File Offset: 0x0001D376
	public GControl4()
	{
		base.SizeMode = TabSizeMode.Fixed;
		base.Alignment = TabAlignment.Left;
		base.DrawMode = TabDrawMode.OwnerDrawFixed;
		this.GEnum24_0 = GControl4.GEnum24.Left;
		this.bool_0 = false;
	}

	// Token: 0x170009A3 RID: 2467
	// (get) Token: 0x06002AB4 RID: 10932 RVA: 0x0001F1A1 File Offset: 0x0001D3A1
	// (set) Token: 0x06002AB5 RID: 10933 RVA: 0x0001F1AF File Offset: 0x0001D3AF
	[DefaultValue(typeof(GControl4.GEnum24), "Left")]
	[Description("Determines whether the tabs appear on the left or right side of the Control.")]
	public GControl4.GEnum24 GEnum24_0
	{
		get
		{
			if (base.Alignment != TabAlignment.Left)
			{
				return GControl4.GEnum24.Right;
			}
			return GControl4.GEnum24.Left;
		}
		set
		{
			if (value != this.GEnum24_0)
			{
				if (value == GControl4.GEnum24.Left)
				{
					base.Alignment = TabAlignment.Left;
				}
				else
				{
					base.Alignment = TabAlignment.Right;
				}
				base.RecreateHandle();
			}
		}
	}

	// Token: 0x170009A4 RID: 2468
	// (get) Token: 0x06002AB6 RID: 10934 RVA: 0x0001F1D3 File Offset: 0x0001D3D3
	// (set) Token: 0x06002AB7 RID: 10935 RVA: 0x00121EEC File Offset: 0x001200EC
	[Description("The ImageList object from which this tab takes its images.")]
	public ImageList ImageList_0
	{
		get
		{
			return base.ImageList;
		}
		set
		{
			if (value != base.ImageList)
			{
				if (base.ImageList != null)
				{
					base.ImageList.RecreateHandle -= this.method_4;
				}
				base.ImageList = value;
				if (value != null)
				{
					base.ImageList.RecreateHandle += this.method_4;
				}
				if (!this.bool_0)
				{
					this.method_0();
				}
			}
		}
	}

	// Token: 0x170009A5 RID: 2469
	// (get) Token: 0x06002AB8 RID: 10936 RVA: 0x0001F1DB File Offset: 0x0001D3DB
	// (set) Token: 0x06002AB9 RID: 10937 RVA: 0x00121F50 File Offset: 0x00120150
	[AmbientValue(typeof(Size), "0, 0")]
	public Size Size_0
	{
		get
		{
			return base.ItemSize.smethod_1();
		}
		set
		{
			if (value.Width >= 0 && value.Height >= 0)
			{
				value = value.smethod_1();
				this.bool_0 = (this.bool_0 || value != base.ItemSize);
				base.ItemSize = value;
				return;
			}
			throw new ArgumentOutOfRangeException("ItemSize", "The width and/or height of the ItemSize cannot be less than 0.");
		}
	}

	// Token: 0x06002ABA RID: 10938 RVA: 0x0001F1E8 File Offset: 0x0001D3E8
	[EditorBrowsable(EditorBrowsableState.Never)]
	public void method_0()
	{
		base.ItemSize = this.vmethod_0().smethod_1();
		this.bool_0 = false;
	}

	// Token: 0x06002ABB RID: 10939 RVA: 0x0001F202 File Offset: 0x0001D402
	private bool method_1()
	{
		return this.bool_0;
	}

	// Token: 0x170009A6 RID: 2470
	// (get) Token: 0x06002ABC RID: 10940 RVA: 0x0001F20A File Offset: 0x0001D40A
	// (set) Token: 0x06002ABD RID: 10941 RVA: 0x0001F212 File Offset: 0x0001D412
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[Obsolete("Not intended to be used in this class.", true)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	[Bindable(false)]
	public TabDrawMode TabDrawMode_0 { get; set; }

	// Token: 0x170009A7 RID: 2471
	// (get) Token: 0x06002ABE RID: 10942 RVA: 0x0001F21B File Offset: 0x0001D41B
	// (set) Token: 0x06002ABF RID: 10943 RVA: 0x0001F223 File Offset: 0x0001D423
	[Browsable(false)]
	[Bindable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[Obsolete("Not intended to be used in this class.", true)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public bool Boolean_0 { get; set; }

	// Token: 0x170009A8 RID: 2472
	// (get) Token: 0x06002AC0 RID: 10944 RVA: 0x0001F22C File Offset: 0x0001D42C
	// (set) Token: 0x06002AC1 RID: 10945 RVA: 0x0001F234 File Offset: 0x0001D434
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[Obsolete("Not intended to be used in this class.", true)]
	[Browsable(false)]
	[Bindable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public TabSizeMode TabSizeMode_0 { get; set; }

	// Token: 0x06002AC2 RID: 10946 RVA: 0x00121FB0 File Offset: 0x001201B0
	protected virtual void OnDrawItem(DrawItemEventArgs e)
	{
		base.OnDrawItem(e);
		Graphics graphics = e.Graphics;
		TabPage tabPage = base.TabPages[e.Index];
		if (base.SelectedIndex == e.Index)
		{
			graphics.FillRectangle(new SolidBrush(e.ForeColor), base.GetTabRect(e.Index));
		}
		if (this.method_3(e.Index))
		{
			int num = this.ImageList_0.Images.IndexOfKey(tabPage.ImageKey);
			num = ((num != -1) ? num : tabPage.ImageIndex);
			this.ImageList_0.Draw(graphics, this.vmethod_1(e.Index).Location, num);
		}
		graphics.DrawString(tabPage.Text, this.Font, SystemBrushes.ControlText, this.vmethod_2(e.Index));
	}

	// Token: 0x06002AC3 RID: 10947 RVA: 0x0001F23D File Offset: 0x0001D43D
	protected virtual void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		this.method_0();
	}

	// Token: 0x06002AC4 RID: 10948 RVA: 0x00122084 File Offset: 0x00120284
	protected virtual Size vmethod_0()
	{
		if (base.TabCount == 0)
		{
			return base.ItemSize;
		}
		int num = TextRenderer.MeasureText("bp", this.Font).Height;
		int num2 = base.TabPages.OfType<TabPage>().Max(new Func<TabPage, int>(this.method_5));
		if (this.method_2())
		{
			num = Math.Max(num, this.ImageList_0.ImageSize.Height);
			num2 += this.ImageList_0.ImageSize.Width + base.Padding.X;
		}
		return new Size(Math.Min(128, num2 + 2 * base.Padding.X), num + 2 * base.Padding.Y);
	}

	// Token: 0x06002AC5 RID: 10949 RVA: 0x00122150 File Offset: 0x00120350
	protected virtual Rectangle vmethod_1(int int_0)
	{
		Rectangle tabRect = base.GetTabRect(int_0);
		Size imageSize = this.ImageList_0.ImageSize;
		tabRect.Inflate(-base.Padding.X, -base.Padding.Y);
		if (this.GEnum24_0 == GControl4.GEnum24.Left)
		{
			return new Rectangle(tabRect.Location, imageSize);
		}
		return new Rectangle(new Point(tabRect.Right - imageSize.Width, tabRect.Top), imageSize);
	}

	// Token: 0x06002AC6 RID: 10950 RVA: 0x001221D0 File Offset: 0x001203D0
	protected virtual Rectangle vmethod_2(int int_0)
	{
		int height = TextRenderer.MeasureText(base.TabPages[int_0].Text, this.Font).Height;
		Rectangle tabRect = base.GetTabRect(int_0);
		tabRect.Inflate(-base.Padding.X, -base.Padding.Y);
		if (this.method_2())
		{
			int num = this.ImageList_0.ImageSize.Width + base.Padding.X;
			tabRect.Width -= num;
			if (this.GEnum24_0 == GControl4.GEnum24.Left)
			{
				tabRect.Offset(num, 0);
			}
		}
		return tabRect;
	}

	// Token: 0x06002AC7 RID: 10951 RVA: 0x0012227C File Offset: 0x0012047C
	private bool method_2()
	{
		for (int i = 0; i <= base.TabCount - 1; i++)
		{
			if (this.method_3(i))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06002AC8 RID: 10952 RVA: 0x001222A8 File Offset: 0x001204A8
	private bool method_3(int int_0)
	{
		TabPage tabPage = base.TabPages[int_0];
		return this.ImageList_0 != null && !this.ImageList_0.Images.Empty && (tabPage.ImageIndex.smethod_0(0, this.ImageList_0.Images.Count - 1) || this.ImageList_0.Images.Keys.Contains(tabPage.ImageKey));
	}

	// Token: 0x06002AC9 RID: 10953 RVA: 0x0001F24C File Offset: 0x0001D44C
	private void method_4(object sender, EventArgs e)
	{
		if (!this.bool_0)
		{
			this.method_0();
		}
	}

	// Token: 0x06002ACA RID: 10954 RVA: 0x0012231C File Offset: 0x0012051C
	[CompilerGenerated]
	private int method_5(TabPage tabPage_0)
	{
		return TextRenderer.MeasureText(tabPage_0.Text, this.Font).Width + base.Padding.X / 2;
	}

	// Token: 0x04001C79 RID: 7289
	private bool bool_0;

	// Token: 0x04001C7A RID: 7290
	[CompilerGenerated]
	private TabDrawMode tabDrawMode_0;

	// Token: 0x04001C7B RID: 7291
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04001C7C RID: 7292
	[CompilerGenerated]
	private TabSizeMode tabSizeMode_0;

	// Token: 0x020002EB RID: 747
	public enum GEnum24
	{
		// Token: 0x04001C7E RID: 7294
		Left,
		// Token: 0x04001C7F RID: 7295
		Right
	}
}
