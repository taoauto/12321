﻿using System;

// Token: 0x0200014B RID: 331
internal interface Interface0
{
	// Token: 0x17000426 RID: 1062
	// (get) Token: 0x06001026 RID: 4134
	string String_0 { get; }

	// Token: 0x17000427 RID: 1063
	// (get) Token: 0x06001027 RID: 4135
	Interface3 Interface3_0 { get; }
}
