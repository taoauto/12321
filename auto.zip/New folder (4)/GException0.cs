﻿using System;
using System.Runtime.Serialization;

// Token: 0x02000007 RID: 7
[Serializable]
public class GException0 : Exception
{
	// Token: 0x0600001B RID: 27 RVA: 0x00002F28 File Offset: 0x00001128
	public GException0() : this(Class2.String_37, null)
	{
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002F36 File Offset: 0x00001136
	public GException0(string string_0, Exception exception_0 = null) : base(string_0, exception_0)
	{
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002F40 File Offset: 0x00001140
	protected GException0(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0) : base(serializationInfo_0, streamingContext_0)
	{
	}
}
