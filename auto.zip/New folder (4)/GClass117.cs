﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000192 RID: 402
[Serializable]
public class GClass117 : GClass113, IDisposable
{
	// Token: 0x06001258 RID: 4696 RVA: 0x0000E7AC File Offset: 0x0000C9AC
	public GClass117(int int_0)
	{
		if (int_0 > 0)
		{
			this.IntPtr_0 = Marshal.AllocHGlobal(int_0);
			this.Int32_0 = int_0;
			return;
		}
		this.IntPtr_0 = IntPtr.Zero;
		this.Int32_0 = 0;
	}

	// Token: 0x06001259 RID: 4697 RVA: 0x00069378 File Offset: 0x00067578
	private bool method_0(int int_0)
	{
		bool result;
		try
		{
			if (int_0 > this.Int32_0)
			{
				this.IntPtr_0 = ((this.IntPtr_0 == IntPtr.Zero) ? Marshal.AllocHGlobal(int_0) : Marshal.ReAllocHGlobal(this.IntPtr_0, new IntPtr(int_0)));
				this.Int32_0 = int_0;
			}
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x0600125A RID: 4698 RVA: 0x000693E8 File Offset: 0x000675E8
	public bool method_1<T>(T gparam_0) where T : struct
	{
		bool result;
		try
		{
			if (this.method_0(Marshal.SizeOf(typeof(T))))
			{
				Marshal.StructureToPtr(gparam_0, this.IntPtr_0, false);
				result = true;
			}
			else
			{
				result = false;
			}
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x0600125B RID: 4699 RVA: 0x0000E7DE File Offset: 0x0000C9DE
	public bool method_2(byte[] byte_0, int int_0, int int_1)
	{
		if (byte_0 != null && this.method_0(int_1))
		{
			Marshal.Copy(byte_0, int_0, this.IntPtr_0, int_1);
			return true;
		}
		if (byte_0 == null)
		{
			this.vmethod_2(new ArgumentException("Attempting to commit a null reference", "data"));
		}
		return false;
	}

	// Token: 0x0600125C RID: 4700 RVA: 0x0000E816 File Offset: 0x0000CA16
	public void Dispose()
	{
		this.method_3(true);
		GC.SuppressFinalize(this);
	}

	// Token: 0x0600125D RID: 4701 RVA: 0x0000E825 File Offset: 0x0000CA25
	private void method_3(bool bool_0)
	{
		if (!this._disposed)
		{
			if (bool_0)
			{
				this.method_6(0);
			}
			this._disposed = true;
		}
	}

	// Token: 0x0600125E RID: 4702 RVA: 0x00069444 File Offset: 0x00067644
	public byte[] method_4(int int_0)
	{
		byte[] result;
		try
		{
			if (int_0 > this.Int32_0 || int_0 <= 0)
			{
				throw new ArgumentException("There is either not enough memory allocated to read 'count' bytes, or 'count' is negative (" + int_0.ToString() + ")", "count");
			}
			byte[] array = new byte[int_0];
			Marshal.Copy(this.IntPtr_0, array, 0, int_0);
			result = array;
		}
		catch (Exception exception_)
		{
			this.vmethod_2(exception_);
			result = null;
		}
		return result;
	}

	// Token: 0x0600125F RID: 4703 RVA: 0x000694B8 File Offset: 0x000676B8
	public bool method_5<T>(out T gparam_0) where T : struct
	{
		gparam_0 = default(T);
		bool result;
		try
		{
			if (this.Int32_0 < Marshal.SizeOf(typeof(T)))
			{
				throw new InvalidCastException("Not enough unmanaged memory is allocated to contain this structure type.");
			}
			gparam_0 = (T)((object)Marshal.PtrToStructure(this.IntPtr_0, typeof(T)));
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001260 RID: 4704 RVA: 0x00069530 File Offset: 0x00067730
	public bool method_6(int int_0)
	{
		if (int_0 < 0)
		{
			return this.vmethod_2(new ArgumentException("Attempting to resize to less than zero bytes of memory", "size"));
		}
		if (int_0 == this.Int32_0)
		{
			return true;
		}
		if (int_0 > this.Int32_0)
		{
			return this.method_0(int_0);
		}
		bool result;
		try
		{
			if (int_0 == 0)
			{
				Marshal.FreeHGlobal(this.IntPtr_0);
				this.IntPtr_0 = IntPtr.Zero;
			}
			else if (int_0 > 0)
			{
				this.IntPtr_0 = Marshal.ReAllocHGlobal(this.IntPtr_0, new IntPtr(int_0));
			}
			this.Int32_0 = int_0;
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001261 RID: 4705 RVA: 0x000695D4 File Offset: 0x000677D4
	public bool method_7<T>() where T : struct
	{
		bool result;
		try
		{
			if (this.Int32_0 < Marshal.SizeOf(typeof(T)))
			{
				throw new InvalidCastException("Not enough unmanaged memory is allocated to contain this structure type.");
			}
			Marshal.DestroyStructure(this.IntPtr_0, typeof(T));
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001262 RID: 4706 RVA: 0x0000E841 File Offset: 0x0000CA41
	public bool method_8<T>(T gparam_0, out byte[] byte_0) where T : struct
	{
		byte_0 = null;
		if (this.method_1<T>(gparam_0))
		{
			byte_0 = this.method_4(Marshal.SizeOf(typeof(T)));
			this.method_7<T>();
		}
		return byte_0 != null;
	}

	// Token: 0x06001263 RID: 4707 RVA: 0x0000E872 File Offset: 0x0000CA72
	public bool method_9<T>(byte[] byte_0, out T gparam_0) where T : struct
	{
		gparam_0 = default(T);
		if (byte_0 == null)
		{
			return this.vmethod_2(new ArgumentException("Attempted to translate a null reference to a structure.", "buffer"));
		}
		return this.method_2(byte_0, 0, byte_0.Length) && this.method_5<T>(out gparam_0);
	}

	// Token: 0x06001264 RID: 4708 RVA: 0x0000E8AA File Offset: 0x0000CAAA
	public bool method_10<T, U>(T gparam_0, out U gparam_1) where T : struct where U : struct
	{
		gparam_1 = default(U);
		return this.method_1<T>(gparam_0) && this.method_5<U>(out gparam_1) && this.method_7<T>();
	}

	// Token: 0x170004B4 RID: 1204
	// (get) Token: 0x06001265 RID: 4709 RVA: 0x0000E8CD File Offset: 0x0000CACD
	// (set) Token: 0x06001266 RID: 4710 RVA: 0x0000E8D5 File Offset: 0x0000CAD5
	public IntPtr IntPtr_0 { get; private set; }

	// Token: 0x170004B5 RID: 1205
	// (get) Token: 0x06001267 RID: 4711 RVA: 0x0000E8DE File Offset: 0x0000CADE
	// (set) Token: 0x06001268 RID: 4712 RVA: 0x0000E8E6 File Offset: 0x0000CAE6
	public int Int32_0 { get; private set; }

	// Token: 0x04000A2F RID: 2607
	private bool _disposed;
}
