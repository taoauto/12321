﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020001FD RID: 509
internal class Class237
{
	// Token: 0x1700065C RID: 1628
	// (get) Token: 0x06001A6B RID: 6763 RVA: 0x000131E7 File Offset: 0x000113E7
	// (set) Token: 0x06001A6C RID: 6764 RVA: 0x000131EF File Offset: 0x000113EF
	public uint UInt32_0 { get; set; }

	// Token: 0x1700065D RID: 1629
	// (get) Token: 0x06001A6D RID: 6765 RVA: 0x000131F8 File Offset: 0x000113F8
	// (set) Token: 0x06001A6E RID: 6766 RVA: 0x00013200 File Offset: 0x00011400
	public uint UInt32_1 { get; set; }

	// Token: 0x1700065E RID: 1630
	// (get) Token: 0x06001A6F RID: 6767 RVA: 0x00013209 File Offset: 0x00011409
	// (set) Token: 0x06001A70 RID: 6768 RVA: 0x00013211 File Offset: 0x00011411
	public uint UInt32_2 { get; set; }

	// Token: 0x1700065F RID: 1631
	// (get) Token: 0x06001A71 RID: 6769 RVA: 0x0001321A File Offset: 0x0001141A
	// (set) Token: 0x06001A72 RID: 6770 RVA: 0x00013222 File Offset: 0x00011422
	public uint UInt32_3 { get; set; }

	// Token: 0x17000660 RID: 1632
	// (get) Token: 0x06001A73 RID: 6771 RVA: 0x0001322B File Offset: 0x0001142B
	// (set) Token: 0x06001A74 RID: 6772 RVA: 0x00013233 File Offset: 0x00011433
	public uint UInt32_4 { get; set; }

	// Token: 0x17000661 RID: 1633
	// (get) Token: 0x06001A75 RID: 6773 RVA: 0x0001323C File Offset: 0x0001143C
	// (set) Token: 0x06001A76 RID: 6774 RVA: 0x00013244 File Offset: 0x00011444
	public string String_0 { get; set; } = string.Empty;

	// Token: 0x17000662 RID: 1634
	// (get) Token: 0x06001A77 RID: 6775 RVA: 0x0001324D File Offset: 0x0001144D
	// (set) Token: 0x06001A78 RID: 6776 RVA: 0x00013255 File Offset: 0x00011455
	public uint UInt32_5 { get; set; }

	// Token: 0x17000663 RID: 1635
	// (get) Token: 0x06001A79 RID: 6777 RVA: 0x0001325E File Offset: 0x0001145E
	// (set) Token: 0x06001A7A RID: 6778 RVA: 0x00013266 File Offset: 0x00011466
	public uint UInt32_6 { get; set; }

	// Token: 0x17000664 RID: 1636
	// (get) Token: 0x06001A7B RID: 6779 RVA: 0x0001326F File Offset: 0x0001146F
	// (set) Token: 0x06001A7C RID: 6780 RVA: 0x00013277 File Offset: 0x00011477
	public uint UInt32_7 { get; set; }

	// Token: 0x17000665 RID: 1637
	// (get) Token: 0x06001A7D RID: 6781 RVA: 0x00013280 File Offset: 0x00011480
	// (set) Token: 0x06001A7E RID: 6782 RVA: 0x00013288 File Offset: 0x00011488
	public uint UInt32_8 { get; set; }

	// Token: 0x17000666 RID: 1638
	// (get) Token: 0x06001A7F RID: 6783 RVA: 0x00013291 File Offset: 0x00011491
	// (set) Token: 0x06001A80 RID: 6784 RVA: 0x00013299 File Offset: 0x00011499
	public uint UInt32_9 { get; set; }

	// Token: 0x17000667 RID: 1639
	// (get) Token: 0x06001A81 RID: 6785 RVA: 0x000132A2 File Offset: 0x000114A2
	// (set) Token: 0x06001A82 RID: 6786 RVA: 0x000132AA File Offset: 0x000114AA
	public string String_1 { get; set; } = string.Empty;

	// Token: 0x17000668 RID: 1640
	// (get) Token: 0x06001A83 RID: 6787 RVA: 0x000132B3 File Offset: 0x000114B3
	// (set) Token: 0x06001A84 RID: 6788 RVA: 0x000132BB File Offset: 0x000114BB
	public bool Boolean_0 { get; set; }

	// Token: 0x17000669 RID: 1641
	// (get) Token: 0x06001A85 RID: 6789 RVA: 0x000132C4 File Offset: 0x000114C4
	// (set) Token: 0x06001A86 RID: 6790 RVA: 0x000132CC File Offset: 0x000114CC
	public uint UInt32_10 { get; set; }

	// Token: 0x1700066A RID: 1642
	// (get) Token: 0x06001A87 RID: 6791 RVA: 0x000132D5 File Offset: 0x000114D5
	public bool Boolean_1
	{
		get
		{
			return this.UInt32_6 > this.UInt32_5 && this.UInt32_6 > this.UInt32_7 && this.UInt32_6 > this.UInt32_9 && this.UInt32_6 > this.UInt32_8;
		}
	}

	// Token: 0x1700066B RID: 1643
	// (get) Token: 0x06001A88 RID: 6792 RVA: 0x00013312 File Offset: 0x00011512
	public bool Boolean_2
	{
		get
		{
			return this.UInt32_5 > this.UInt32_6 && this.UInt32_5 > this.UInt32_7 && this.UInt32_5 > this.UInt32_9 && this.UInt32_5 > this.UInt32_8;
		}
	}

	// Token: 0x1700066C RID: 1644
	// (get) Token: 0x06001A89 RID: 6793 RVA: 0x0001334F File Offset: 0x0001154F
	public bool Boolean_3
	{
		get
		{
			return this.UInt32_7 > this.UInt32_5 && this.UInt32_7 > this.UInt32_6 && this.UInt32_7 > this.UInt32_9 && this.UInt32_7 > this.UInt32_8;
		}
	}

	// Token: 0x1700066D RID: 1645
	// (get) Token: 0x06001A8A RID: 6794 RVA: 0x0001338C File Offset: 0x0001158C
	public bool Boolean_4
	{
		get
		{
			return this.UInt32_8 > this.UInt32_5 && this.UInt32_8 > this.UInt32_6 && this.UInt32_8 > this.UInt32_7 && this.UInt32_8 > this.UInt32_9;
		}
	}

	// Token: 0x0400108D RID: 4237
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x0400108E RID: 4238
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x0400108F RID: 4239
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001090 RID: 4240
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001091 RID: 4241
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04001092 RID: 4242
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001093 RID: 4243
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04001094 RID: 4244
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04001095 RID: 4245
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04001096 RID: 4246
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04001097 RID: 4247
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x04001098 RID: 4248
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001099 RID: 4249
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x0400109A RID: 4250
	[CompilerGenerated]
	private uint uint_10;
}
