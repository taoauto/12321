﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000153 RID: 339
internal static class Class133
{
	// Token: 0x14000046 RID: 70
	// (add) Token: 0x06001035 RID: 4149 RVA: 0x0005AEB4 File Offset: 0x000590B4
	// (remove) Token: 0x06001036 RID: 4150 RVA: 0x0005AEE8 File Offset: 0x000590E8
	public static event EventHandler<EventArgs0> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs0> eventHandler = Class133.eventHandler_0;
			EventHandler<EventArgs0> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs0> value2 = (EventHandler<EventArgs0>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs0>>(ref Class133.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs0> eventHandler = Class133.eventHandler_0;
			EventHandler<EventArgs0> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs0> value2 = (EventHandler<EventArgs0>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs0>>(ref Class133.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06001037 RID: 4151 RVA: 0x0000D46F File Offset: 0x0000B66F
	public static void smethod_0(string string_0, Type type_0)
	{
		Class133.hashtable_0[string_0] = type_0;
	}

	// Token: 0x06001038 RID: 4152 RVA: 0x0005AF1C File Offset: 0x0005911C
	public static Interface5 smethod_1(string string_0, Class130 class130_0)
	{
		Interface5 @interface = Class133.smethod_5(string_0);
		if (class130_0 != null)
		{
			@interface.imethod_0(class130_0);
		}
		return @interface;
	}

	// Token: 0x06001039 RID: 4153 RVA: 0x0000D47D File Offset: 0x0000B67D
	public static Interface5 smethod_2(string string_0)
	{
		return Class133.smethod_5(string_0);
	}

	// Token: 0x0600103A RID: 4154 RVA: 0x0005AF3C File Offset: 0x0005913C
	public static Type smethod_3(string string_0)
	{
		int num = string_0.IndexOf("://");
		if (num > 0)
		{
			string key = string_0.Substring(0, num);
			return Class133.hashtable_0[key] as Type;
		}
		return null;
	}

	// Token: 0x0600103B RID: 4155 RVA: 0x0005AF74 File Offset: 0x00059174
	public static Interface5 smethod_4(Type type_0, Class130 class130_0)
	{
		Interface5 @interface = Class133.smethod_6(type_0);
		if (Class133.eventHandler_0 != null)
		{
			EventArgs0 eventArgs = new EventArgs0(@interface, null);
			Class133.eventHandler_0(null, eventArgs);
			@interface = eventArgs.Interface5_0;
		}
		if (class130_0 != null)
		{
			@interface.imethod_0(class130_0);
		}
		return @interface;
	}

	// Token: 0x0600103C RID: 4156 RVA: 0x0005AFB8 File Offset: 0x000591B8
	private static Interface5 smethod_5(string string_0)
	{
		Interface5 @interface = Class133.smethod_6(Class133.smethod_3(string_0));
		if (Class133.eventHandler_0 != null)
		{
			EventArgs0 eventArgs = new EventArgs0(@interface, string_0);
			Class133.eventHandler_0(null, eventArgs);
			@interface = eventArgs.Interface5_0;
		}
		return @interface;
	}

	// Token: 0x0600103D RID: 4157 RVA: 0x0000D485 File Offset: 0x0000B685
	private static Interface5 smethod_6(Type type_0)
	{
		return (Interface5)Activator.CreateInstance(type_0);
	}

	// Token: 0x0400084D RID: 2125
	private static Hashtable hashtable_0 = new Hashtable();

	// Token: 0x0400084E RID: 2126
	[CompilerGenerated]
	private static EventHandler<EventArgs0> eventHandler_0;
}
