﻿using System;
using System.ComponentModel;

// Token: 0x02000133 RID: 307
internal class Class120 : EventDescriptor
{
	// Token: 0x06000F82 RID: 3970 RVA: 0x0000CDF0 File Offset: 0x0000AFF0
	public Class120(MemberDescriptor memberDescriptor_0) : base(memberDescriptor_0)
	{
	}

	// Token: 0x06000F83 RID: 3971 RVA: 0x0000CDF9 File Offset: 0x0000AFF9
	public virtual void AddEventHandler(object component, Delegate value)
	{
		(component as FastColoredTextBox).Event_3 += (value as EventHandler);
	}

	// Token: 0x170003FD RID: 1021
	// (get) Token: 0x06000F84 RID: 3972 RVA: 0x0000CE0C File Offset: 0x0000B00C
	public virtual Type ComponentType
	{
		get
		{
			return typeof(FastColoredTextBox);
		}
	}

	// Token: 0x170003FE RID: 1022
	// (get) Token: 0x06000F85 RID: 3973 RVA: 0x0000CE18 File Offset: 0x0000B018
	public virtual Type EventType
	{
		get
		{
			return typeof(EventHandler);
		}
	}

	// Token: 0x170003FF RID: 1023
	// (get) Token: 0x06000F86 RID: 3974 RVA: 0x0000354C File Offset: 0x0000174C
	public virtual bool IsMulticast
	{
		get
		{
			return true;
		}
	}

	// Token: 0x06000F87 RID: 3975 RVA: 0x0000CE24 File Offset: 0x0000B024
	public virtual void RemoveEventHandler(object component, Delegate value)
	{
		(component as FastColoredTextBox).Event_3 -= (value as EventHandler);
	}
}
