﻿using System;

// Token: 0x020002B4 RID: 692
internal class Class378
{
	// Token: 0x1700084C RID: 2124
	// (get) Token: 0x0600267D RID: 9853 RVA: 0x0001CB6D File Offset: 0x0001AD6D
	// (set) Token: 0x0600267E RID: 9854 RVA: 0x0001CB83 File Offset: 0x0001AD83
	public static string String_0
	{
		get
		{
			return Class159.Class220_0.method_0("Config", "GamePath");
		}
		set
		{
			Class159.Class220_0.method_1("Config", "GamePath", value);
		}
	}
}
