﻿using System;

// Token: 0x020002A1 RID: 673
internal class Class361
{
	// Token: 0x17000797 RID: 1943
	// (get) Token: 0x060024B4 RID: 9396 RVA: 0x0001BCD0 File Offset: 0x00019ED0
	public static string String_0
	{
		get
		{
			return "Viêm La Thiên";
		}
	}

	// Token: 0x040018B1 RID: 6321
	public static int int_0 = 666;

	// Token: 0x040018B2 RID: 6322
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 22U,
		Int32_0 = 157,
		Int32_1 = 201,
		Int32_2 = Class361.int_0,
		String_2 = "Thông Báo Hậu Cần"
	};

	// Token: 0x040018B3 RID: 6323
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 167,
		Int32_1 = 197,
		Int32_2 = Class361.int_0,
		String_2 = "Phong Bộ Quy"
	};
}
