﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000186 RID: 390
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct15
{
	// Token: 0x0600121C RID: 4636 RVA: 0x00068A9C File Offset: 0x00066C9C
	public string ToString()
	{
		string text = Encoding.UTF8.GetString(this.Name);
		if (text.Contains("\0"))
		{
			text = text.Substring(0, text.IndexOf("\0"));
		}
		return text;
	}

	// Token: 0x040009FF RID: 2559
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
	public byte[] Name;

	// Token: 0x04000A00 RID: 2560
	public uint VirtualSize;

	// Token: 0x04000A01 RID: 2561
	public uint VirtualAddress;

	// Token: 0x04000A02 RID: 2562
	public uint SizeOfRawData;

	// Token: 0x04000A03 RID: 2563
	public uint PointerToRawData;

	// Token: 0x04000A04 RID: 2564
	public uint PointerToRelocations;

	// Token: 0x04000A05 RID: 2565
	public uint PointerToLineNumbers;

	// Token: 0x04000A06 RID: 2566
	public ushort NumberOfRelocations;

	// Token: 0x04000A07 RID: 2567
	public ushort NumberOfLineNumbers;

	// Token: 0x04000A08 RID: 2568
	public uint Characteristics;
}
