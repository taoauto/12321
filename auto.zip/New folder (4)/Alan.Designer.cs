﻿// Token: 0x020001FF RID: 511
internal partial class Alan : global::System.Windows.Forms.Form
{
	// Token: 0x06001AA5 RID: 6821 RVA: 0x000C8A04 File Offset: 0x000C6C04
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_1 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.timer_0.Enabled = true;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.timer_1.Enabled = true;
		this.timer_1.Interval = 1000;
		this.timer_1.Tick += new global::System.EventHandler(this.timer_1_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.White;
		base.ClientSize = new global::System.Drawing.Size(360, 90);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		this.MaximumSize = new global::System.Drawing.Size(360, 90);
		base.Name = "Alan";
		base.Opacity = 0.75;
		base.ShowInTaskbar = false;
		this.Text = "AlarmEx";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Alan_Load);
		base.ResumeLayout(false);
	}

	// Token: 0x040010A7 RID: 4263
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x040010A8 RID: 4264
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x040010A9 RID: 4265
	private global::System.Windows.Forms.Timer timer_1;
}
