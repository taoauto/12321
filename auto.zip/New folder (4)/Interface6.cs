﻿using System;

// Token: 0x02000151 RID: 337
internal interface Interface6
{
	// Token: 0x06001032 RID: 4146
	GStruct4[] imethod_0(int int_0, Class140 class140_0);
}
