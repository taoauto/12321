﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020002B8 RID: 696
internal partial class ScriptManager : Form
{
	// Token: 0x0600268A RID: 9866 RVA: 0x0001CBDD File Offset: 0x0001ADDD
	public ScriptManager(Class383 class383_1, Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.class383_0 = class383_1;
		this.InitializeComponent();
	}

	// Token: 0x0600268B RID: 9867 RVA: 0x00112388 File Offset: 0x00110588
	private void ScriptManager_Load(object sender, EventArgs e)
	{
		this.txtID.Text = this.class383_0.String_0;
		this.txtMD.Text = this.class383_0.String_3;
		this.txtInfo.Text = this.class383_0.String_13;
		if (this.class383_0.String_7.Length == 12)
		{
			this.recvID.Value = Class405.smethod_0(this.class383_0.String_7.Substring(0, 3));
			try
			{
				this.recvX.Value = Class405.smethod_0(this.class383_0.String_7.Substring(3, 3));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			this.recvY.Value = Class405.smethod_0(this.class383_0.String_7.Substring(6, 3));
			this.recvMAP.Value = Class405.smethod_0(this.class383_0.String_7.Substring(9, 3));
		}
		if (this.class383_0.String_9.Length == 12)
		{
			this.sendID.Value = Class405.smethod_0(this.class383_0.String_9.Substring(0, 3));
			this.sendX.Value = Class405.smethod_0(this.class383_0.String_9.Substring(3, 3));
			this.sendY.Value = Class405.smethod_0(this.class383_0.String_9.Substring(6, 3));
			this.sendMAP.Value = Class405.smethod_0(this.class383_0.String_9.Substring(9, 3));
		}
		this.txdDo.Text = this.class383_0.String_12;
		this.atk1MD.Text = this.class383_0.Class424_1.String_1;
		this.atk1X.Value = this.class383_0.Class424_1.Int32_0;
		this.atk1Y.Value = this.class383_0.Class424_1.Int32_1;
		this.atk1Map.Value = this.class383_0.Class424_1.Int32_2;
		this.atk2MD.Text = this.class383_0.Class424_2.String_1;
		this.atk2X.Value = this.class383_0.Class424_2.Int32_0;
		this.atk2Y.Value = this.class383_0.Class424_2.Int32_1;
		this.atk2Map.Value = this.class383_0.Class424_2.Int32_2;
		this.atk3MD.Text = this.class383_0.Class424_3.String_1;
		this.atk3X.Value = this.class383_0.Class424_3.Int32_0;
		this.atk3Y.Value = this.class383_0.Class424_3.Int32_1;
		this.atk3Map.Value = this.class383_0.Class424_3.Int32_2;
		this.chkPick.Checked = this.class383_0.Boolean_4;
		this.chkIsThuThap.Checked = this.class383_0.Boolean_5;
		this.chkCompleted.Checked = this.class383_0.Boolean_2;
		this.chkUseItem.Checked = this.class383_0.Boolean_3;
		this.txtName.Text = this.class383_0.String_6;
		this.nudColloect.Value = Class426.smethod_43(this.class383_0.String_8);
		this.chkComplete.Checked = this.class383_0.Boolean_1;
		this.txtMonter.Text = this.class383_0.String_4;
		this.chkBienThan.Checked = this.class383_0.Boolean_7;
	}

	// Token: 0x1400004C RID: 76
	// (add) Token: 0x0600268C RID: 9868 RVA: 0x001127B8 File Offset: 0x001109B8
	// (remove) Token: 0x0600268D RID: 9869 RVA: 0x001127F0 File Offset: 0x001109F0
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x0600268E RID: 9870 RVA: 0x00112828 File Offset: 0x00110A28
	public void btnEdit_Click(object sender, EventArgs e)
	{
		this.class383_0.String_0 = this.txtID.Text;
		this.class383_0.String_3 = this.txtMD.Text;
		this.class383_0.String_7 = ScriptManager.smethod_0(this.recvID.Value) + ScriptManager.smethod_0(this.recvX.Value) + ScriptManager.smethod_0(this.recvY.Value) + ScriptManager.smethod_0(this.recvMAP.Value);
		this.class383_0.String_9 = ScriptManager.smethod_0(this.sendID.Value) + ScriptManager.smethod_0(this.sendX.Value) + ScriptManager.smethod_0(this.sendY.Value) + ScriptManager.smethod_0(this.sendMAP.Value);
		this.class383_0.String_12 = this.txdDo.Text;
		this.class383_0.String_6 = this.txtName.Text;
		this.class383_0.String_13 = this.txtInfo.Text;
		this.class383_0.String_4 = this.txtMonter.Text;
		Class382.smethod_4();
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, null);
		}
	}

	// Token: 0x0600268F RID: 9871 RVA: 0x00112974 File Offset: 0x00110B74
	public static string smethod_0(decimal decimal_0)
	{
		return ((int)decimal_0).ToString("X8").Substring(5, 3);
	}

	// Token: 0x06002690 RID: 9872 RVA: 0x0011299C File Offset: 0x00110B9C
	private void recvClick1_ValueChanged(object sender, EventArgs e)
	{
		string text = "000";
		if (this.sendClick1.Value + this.sendClick2.Value != 0m)
		{
			text = Class426.Class430.smethod_3(this.sendClick1.ToString() + this.sendClick2.ToString()).Substring(0, 3);
		}
		string text2 = "000";
		if (this.recvClick1.Value + this.recvClick2.Value != 0m)
		{
			text2 = Class426.Class430.smethod_3(this.recvClick1.ToString() + this.recvClick2.ToString()).Substring(0, 3);
		}
		if (text == "000")
		{
			text = text2;
		}
		if (text2 == "000")
		{
			text2 = text;
		}
		this.class383_0.String_12 = text2 + text;
	}

	// Token: 0x06002691 RID: 9873 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk1MD_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06002692 RID: 9874 RVA: 0x0001CBF9 File Offset: 0x0001ADF9
	private void button1_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06002693 RID: 9875 RVA: 0x00112A84 File Offset: 0x00110C84
	private void method_0()
	{
		string text;
		if (this.class383_0.String_12.Length >= 58)
		{
			text = this.class383_0.String_12.Substring(42, 16);
		}
		else
		{
			text = "0000000000000000";
		}
		if (this.class383_0.String_12.Length > 6)
		{
			this.class383_0.String_12 = this.class383_0.String_12.Substring(0, 6);
		}
		else
		{
			this.class383_0.String_12 = "000000";
		}
		this.txdDo.Text = string.Concat(new string[]
		{
			this.class383_0.String_12,
			this.atk1MD.Text,
			ScriptManager.smethod_0(this.atk1X.Value),
			ScriptManager.smethod_0(this.atk1Y.Value),
			ScriptManager.smethod_0(this.atk1Map.Value)
		});
		this.txdDo.Text = string.Concat(new string[]
		{
			this.txdDo.Text,
			this.atk2MD.Text,
			ScriptManager.smethod_0(this.atk2X.Value),
			ScriptManager.smethod_0(this.atk2Y.Value),
			ScriptManager.smethod_0(this.atk2Map.Value)
		});
		this.txdDo.Text = string.Concat(new string[]
		{
			this.txdDo.Text,
			this.atk3MD.Text,
			ScriptManager.smethod_0(this.atk3X.Value),
			ScriptManager.smethod_0(this.atk3Y.Value),
			ScriptManager.smethod_0(this.atk3Map.Value)
		});
		if (text != "")
		{
			this.txdDo.Text = this.txdDo.Text + text;
		}
		else
		{
			this.txdDo.Text = this.txdDo.Text + "1000000000000000";
		}
		this.class383_0.String_12 = this.txdDo.Text;
	}

	// Token: 0x06002694 RID: 9876 RVA: 0x0001CC01 File Offset: 0x0001AE01
	private void method_1(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_2 = !this.class383_0.Boolean_2;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x06002695 RID: 9877 RVA: 0x0001CC3A File Offset: 0x0001AE3A
	private void method_2(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_3 = !this.class383_0.Boolean_3;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x06002696 RID: 9878 RVA: 0x0001CC73 File Offset: 0x0001AE73
	private void numericUpDown1_ValueChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Int32_0 = (int)this.numericUpDown1.Value;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x06002697 RID: 9879 RVA: 0x0001CCAE File Offset: 0x0001AEAE
	private void numericUpDown2_ValueChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Int32_1 = (int)this.numericUpDown2.Value;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x06002698 RID: 9880 RVA: 0x00112CAC File Offset: 0x00110EAC
	private void btnGet_Click(object sender, EventArgs e)
	{
		this.atk1X.Value = (int)this.class159_0.Single_3;
		this.atk1Y.Value = (int)this.class159_0.Single_4;
		this.atk1Map.Value = this.class159_0.Class432_0.UInt32_29;
	}

	// Token: 0x06002699 RID: 9881 RVA: 0x00112D14 File Offset: 0x00110F14
	private void nudColloect_ValueChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.String_8 = this.nudColloect.Value.ToString();
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269A RID: 9882 RVA: 0x0001CCE9 File Offset: 0x0001AEE9
	private void method_3(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_1 = !this.class383_0.Boolean_1;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269B RID: 9883 RVA: 0x0001CD22 File Offset: 0x0001AF22
	private void chkPick_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_4 = this.chkPick.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269C RID: 9884 RVA: 0x0001CD58 File Offset: 0x0001AF58
	private void chkCompleted_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_2 = this.chkCompleted.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269D RID: 9885 RVA: 0x0001CD8E File Offset: 0x0001AF8E
	private void chkUseItem_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_3 = this.chkUseItem.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269E RID: 9886 RVA: 0x0001CDC4 File Offset: 0x0001AFC4
	private void chkIsThuThap_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_5 = this.chkIsThuThap.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x0600269F RID: 9887 RVA: 0x00002E18 File Offset: 0x00001018
	private void txtInfoEx_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A0 RID: 9888 RVA: 0x0001CDFA File Offset: 0x0001AFFA
	private void chkComplete_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_1 = this.chkComplete.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x060026A1 RID: 9889 RVA: 0x0001CE30 File Offset: 0x0001B030
	private void chkBienThan_CheckedChanged(object sender, EventArgs e)
	{
		this.button1_Click(null, null);
		this.class383_0.Boolean_7 = this.chkBienThan.Checked;
		this.txdDo.Text = this.class383_0.String_12;
	}

	// Token: 0x060026A2 RID: 9890 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk1X_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A3 RID: 9891 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk1Y_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A4 RID: 9892 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk1Map_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A5 RID: 9893 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk2X_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A6 RID: 9894 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk2Y_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A7 RID: 9895 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk2Map_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A8 RID: 9896 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk3X_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026A9 RID: 9897 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk3Y_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026AA RID: 9898 RVA: 0x00002E18 File Offset: 0x00001018
	private void atk3Map_ValueChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060026AB RID: 9899 RVA: 0x00112D60 File Offset: 0x00110F60
	private void button2_Click(object sender, EventArgs e)
	{
		this.class159_0.method_282("MISSIONINFO = ''; cnt = 0; while true do local name, content = DataPool:GetPlayerMission_Memo(cnt); if string.len(name) > 0 then MISSIONINFO = MISSIONINFO .. name .. '=' .. content .. ';'; end cnt = cnt + 1; if cnt == 20 then return end end return MISSIONINFO;", false);
		this.class159_0.method_393(false);
		string text = this.class159_0.method_393(false);
		MessageBox.Show(text);
		if (MessageBox.Show(this, "Bạn có muốn thêm info", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			text = text.Replace("=", ":");
			text = text.Replace("   ", "");
			text = text.Replace("  ", "");
			text.Trim(new char[]
			{
				';'
			});
			foreach (string text2 in text.Split(new char[]
			{
				';'
			}))
			{
				new ListViewItem(text2.Split(new char[]
				{
					'='
				})[0]).SubItems.Add(text2.Split(new char[]
				{
					'='
				})[1]);
			}
		}
	}

	// Token: 0x060026AC RID: 9900 RVA: 0x0001CE66 File Offset: 0x0001B066
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001A34 RID: 6708
	private Class383 class383_0;

	// Token: 0x04001A35 RID: 6709
	private Class159 class159_0;

	// Token: 0x04001A36 RID: 6710
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04001A37 RID: 6711
	private IContainer icontainer_0;
}
