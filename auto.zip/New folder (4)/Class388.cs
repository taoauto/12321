﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020002C1 RID: 705
internal class Class388
{
	// Token: 0x17000891 RID: 2193
	// (get) Token: 0x06002758 RID: 10072 RVA: 0x0001D40D File Offset: 0x0001B60D
	// (set) Token: 0x06002759 RID: 10073 RVA: 0x0001D415 File Offset: 0x0001B615
	public uint UInt32_0 { get; set; }

	// Token: 0x17000892 RID: 2194
	// (get) Token: 0x0600275A RID: 10074 RVA: 0x0001D41E File Offset: 0x0001B61E
	// (set) Token: 0x0600275B RID: 10075 RVA: 0x0001D426 File Offset: 0x0001B626
	public uint UInt32_1 { get; set; }

	// Token: 0x17000893 RID: 2195
	// (get) Token: 0x0600275C RID: 10076 RVA: 0x0001D42F File Offset: 0x0001B62F
	// (set) Token: 0x0600275D RID: 10077 RVA: 0x0001D437 File Offset: 0x0001B637
	public uint UInt32_2 { get; set; }

	// Token: 0x17000894 RID: 2196
	// (get) Token: 0x0600275E RID: 10078 RVA: 0x0001D440 File Offset: 0x0001B640
	// (set) Token: 0x0600275F RID: 10079 RVA: 0x0001D448 File Offset: 0x0001B648
	public uint UInt32_3 { get; set; }

	// Token: 0x17000895 RID: 2197
	// (get) Token: 0x06002760 RID: 10080 RVA: 0x0001D451 File Offset: 0x0001B651
	// (set) Token: 0x06002761 RID: 10081 RVA: 0x0001D459 File Offset: 0x0001B659
	public string String_0 { get; set; }

	// Token: 0x04001AC1 RID: 6849
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001AC2 RID: 6850
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001AC3 RID: 6851
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001AC4 RID: 6852
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001AC5 RID: 6853
	[CompilerGenerated]
	private string string_0;
}
