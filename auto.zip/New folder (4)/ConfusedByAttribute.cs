﻿using System;

// Token: 0x0200033E RID: 830
internal class ConfusedByAttribute : Attribute
{
	// Token: 0x06002E5F RID: 11871 RVA: 0x00021B02 File Offset: 0x0001FD02
	public ConfusedByAttribute(string string_0)
	{
	}
}
