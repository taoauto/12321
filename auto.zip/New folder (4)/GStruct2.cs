﻿using System;

// Token: 0x0200010F RID: 271
public struct GStruct2 : IEquatable<GStruct2>
{
	// Token: 0x06000DC7 RID: 3527 RVA: 0x0000BDB2 File Offset: 0x00009FB2
	public GStruct2(int int_2, int int_3)
	{
		this.int_0 = int_2;
		this.int_1 = int_3;
	}

	// Token: 0x06000DC8 RID: 3528 RVA: 0x0000BDC2 File Offset: 0x00009FC2
	public void method_0(int int_2, int int_3)
	{
		this.int_0 += int_2;
		this.int_1 += int_3;
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x0000BDE0 File Offset: 0x00009FE0
	public bool Equals(GStruct2 other)
	{
		return this.int_0 == other.int_0 && this.int_1 == other.int_1;
	}

	// Token: 0x06000DCA RID: 3530 RVA: 0x0000BE00 File Offset: 0x0000A000
	public bool Equals(object obj)
	{
		return obj is GStruct2 && this.Equals((GStruct2)obj);
	}

	// Token: 0x06000DCB RID: 3531 RVA: 0x0000BE18 File Offset: 0x0000A018
	public int GetHashCode()
	{
		return this.int_0.GetHashCode() ^ this.int_1.GetHashCode();
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0000BE31 File Offset: 0x0000A031
	public static bool smethod_0(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return !gstruct2_0.Equals(gstruct2_1);
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x0000BE3E File Offset: 0x0000A03E
	public static bool smethod_1(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return gstruct2_0.Equals(gstruct2_1);
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x0000BE48 File Offset: 0x0000A048
	public static bool smethod_2(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return gstruct2_0.int_1 < gstruct2_1.int_1 || (gstruct2_0.int_1 <= gstruct2_1.int_1 && gstruct2_0.int_0 < gstruct2_1.int_0);
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x0000BE7B File Offset: 0x0000A07B
	public static bool smethod_3(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return gstruct2_0.Equals(gstruct2_1) || gstruct2_0.int_1 < gstruct2_1.int_1 || (gstruct2_0.int_1 <= gstruct2_1.int_1 && gstruct2_0.int_0 < gstruct2_1.int_0);
	}

	// Token: 0x06000DD0 RID: 3536 RVA: 0x0000BEBA File Offset: 0x0000A0BA
	public static bool smethod_4(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return gstruct2_0.int_1 > gstruct2_1.int_1 || (gstruct2_0.int_1 >= gstruct2_1.int_1 && gstruct2_0.int_0 > gstruct2_1.int_0);
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x0000BEED File Offset: 0x0000A0ED
	public static bool smethod_5(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return gstruct2_0.Equals(gstruct2_1) || gstruct2_0.int_1 > gstruct2_1.int_1 || (gstruct2_0.int_1 >= gstruct2_1.int_1 && gstruct2_0.int_0 > gstruct2_1.int_0);
	}

	// Token: 0x06000DD2 RID: 3538 RVA: 0x0000BF2C File Offset: 0x0000A12C
	public static GStruct2 smethod_6(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return new GStruct2(gstruct2_0.int_0 + gstruct2_1.int_0, gstruct2_0.int_1 + gstruct2_1.int_1);
	}

	// Token: 0x170003A9 RID: 937
	// (get) Token: 0x06000DD3 RID: 3539 RVA: 0x00050DCC File Offset: 0x0004EFCC
	public static GStruct2 GStruct2_0
	{
		get
		{
			return default(GStruct2);
		}
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x00050DE4 File Offset: 0x0004EFE4
	public string ToString()
	{
		return string.Concat(new string[]
		{
			"(",
			this.int_0.ToString(),
			",",
			this.int_1.ToString(),
			")"
		});
	}

	// Token: 0x040006C2 RID: 1730
	public int int_0;

	// Token: 0x040006C3 RID: 1731
	public int int_1;
}
