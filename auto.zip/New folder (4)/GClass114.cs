﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000172 RID: 370
public abstract class GClass114 : GClass113
{
	// Token: 0x060011E9 RID: 4585 RVA: 0x00066FC8 File Offset: 0x000651C8
	public static GClass114 smethod_0(GEnum22 genum22_1)
	{
		GClass114 gclass;
		switch (genum22_1)
		{
		case GEnum22.Standard:
			gclass = new Class157();
			break;
		case GEnum22.ThreadHijack:
			gclass = new Class158();
			break;
		case GEnum22.ManualMap:
			gclass = new Class155();
			break;
		default:
			return null;
		}
		if (gclass != null)
		{
			gclass.GEnum22_0 = genum22_1;
		}
		return gclass;
	}

	// Token: 0x060011EA RID: 4586 RVA: 0x0006700C File Offset: 0x0006520C
	public virtual IntPtr vmethod_4(GClass116 gclass116_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intptr_ = GClass120.OpenProcess(1082U, false, int_0);
		IntPtr result = this.GClass114.\u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(gclass116_0, intptr_);
		GClass120.CloseHandle(intptr_);
		return result;
	}

	// Token: 0x060011EB RID: 4587
	public abstract IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(GClass116 gclass116_0, IntPtr intptr_0);

	// Token: 0x060011EC RID: 4588 RVA: 0x0006703C File Offset: 0x0006523C
	public virtual IntPtr vmethod_5(string string_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intptr_ = GClass120.OpenProcess(1082U, false, int_0);
		IntPtr result = this.GClass114.\u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string_0, intptr_);
		GClass120.CloseHandle(intptr_);
		return result;
	}

	// Token: 0x060011ED RID: 4589
	public abstract IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string string_0, IntPtr intptr_0);

	// Token: 0x060011EE RID: 4590 RVA: 0x0006706C File Offset: 0x0006526C
	public virtual IntPtr[] vmethod_6(GClass116[] gclass116_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intptr_ = GClass120.OpenProcess(1082U, false, int_0);
		IntPtr[] result = this.GClass114.\u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(gclass116_0, intptr_);
		GClass120.CloseHandle(intptr_);
		return result;
	}

	// Token: 0x060011EF RID: 4591
	public abstract IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(GClass116[] gclass116_0, IntPtr intptr_0);

	// Token: 0x060011F0 RID: 4592 RVA: 0x0006709C File Offset: 0x0006529C
	public virtual IntPtr[] vmethod_7(string[] string_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intptr_ = GClass120.OpenProcess(1082U, false, int_0);
		IntPtr[] result = this.GClass114.\u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(string_0, intptr_);
		GClass120.CloseHandle(intptr_);
		return result;
	}

	// Token: 0x060011F1 RID: 4593
	public abstract IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(string[] string_0, IntPtr intptr_0);

	// Token: 0x060011F2 RID: 4594 RVA: 0x000670CC File Offset: 0x000652CC
	public virtual bool vmethod_8(IntPtr intptr_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intPtr = GClass120.OpenProcess(1082U, false, int_0);
		bool result = this.GClass114.\u200B\u200E\u200B\u200D\u206B\u200C\u200E\u202C\u202E\u206F\u202B\u206F\u206B\u206E\u206C\u200B\u206B\u206A\u202D\u202E\u202B\u202E\u206C\u200B\u206E\u202E\u202C\u206E\u202A\u206B\u206B\u202B\u200C\u200B\u202C\u202B\u200B\u206C\u202C\u202E\u202E(intptr_0, intPtr);
		GClass120.CloseHandle(intPtr);
		return result;
	}

	// Token: 0x060011F3 RID: 4595
	public abstract bool \u200B\u200E\u200B\u200D\u206B\u200C\u200E\u202C\u202E\u206F\u202B\u206F\u206B\u206E\u206C\u200B\u206B\u206A\u202D\u202E\u202B\u202E\u206C\u200B\u206E\u202E\u202C\u206E\u202A\u206B\u206B\u202B\u200C\u200B\u202C\u202B\u200B\u206C\u202C\u202E\u202E(IntPtr intptr_0, IntPtr intptr_1);

	// Token: 0x060011F4 RID: 4596 RVA: 0x000670FC File Offset: 0x000652FC
	public virtual bool[] vmethod_9(IntPtr[] intptr_0, int int_0)
	{
		this.vmethod_0();
		IntPtr intPtr = GClass120.OpenProcess(1082U, false, int_0);
		bool[] result = this.GClass114.\u202A\u206C\u202A\u206B\u206D\u206C\u206F\u206C\u206C\u200D\u200C\u202E\u202A\u200B\u202E\u206C\u202A\u202E\u200B\u202D\u200E\u206A\u206B\u200B\u200E\u200D\u200B\u206F\u206D\u206D\u200C\u200B\u200E\u206B\u200D\u206C\u206E\u200B\u206A\u202B\u202E(intptr_0, intPtr);
		GClass120.CloseHandle(intPtr);
		return result;
	}

	// Token: 0x060011F5 RID: 4597
	public abstract bool[] \u202A\u206C\u202A\u206B\u206D\u206C\u206F\u206C\u206C\u200D\u200C\u202E\u202A\u200B\u202E\u206C\u202A\u202E\u200B\u202D\u200E\u206A\u206B\u200B\u200E\u200D\u200B\u206F\u206D\u206D\u200C\u200B\u200E\u206B\u200D\u206C\u206E\u200B\u206A\u202B\u202E(IntPtr[] intptr_0, IntPtr intptr_1);

	// Token: 0x170004A6 RID: 1190
	// (get) Token: 0x060011F6 RID: 4598 RVA: 0x0000E452 File Offset: 0x0000C652
	// (set) Token: 0x060011F7 RID: 4599 RVA: 0x0000E45A File Offset: 0x0000C65A
	public GEnum22 GEnum22_0 { get; protected set; }

	// Token: 0x04000970 RID: 2416
	[CompilerGenerated]
	private GEnum22 genum22_0;
}
