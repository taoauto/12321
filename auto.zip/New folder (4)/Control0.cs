﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020002BF RID: 703
[ToolboxBitmap(typeof(TrackBar))]
[DefaultEvent("Scroll")]
[DefaultProperty("BarInnerColor")]
internal class Control0 : Control
{
	// Token: 0x1400004D RID: 77
	// (add) Token: 0x0600270F RID: 9999 RVA: 0x00116E78 File Offset: 0x00115078
	// (remove) Token: 0x06002710 RID: 10000 RVA: 0x00116EB0 File Offset: 0x001150B0
	[Description("Event fires when the Value property changes")]
	[Category("Action")]
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400004E RID: 78
	// (add) Token: 0x06002711 RID: 10001 RVA: 0x00116EE8 File Offset: 0x001150E8
	// (remove) Token: 0x06002712 RID: 10002 RVA: 0x00116F20 File Offset: 0x00115120
	[Description("Event fires when the Slider position is changed")]
	[Category("Behavior")]
	public event ScrollEventHandler Event_1
	{
		[CompilerGenerated]
		add
		{
			ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
			ScrollEventHandler scrollEventHandler2;
			do
			{
				scrollEventHandler2 = scrollEventHandler;
				ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Combine(scrollEventHandler2, value);
				scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
			}
			while (scrollEventHandler != scrollEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
			ScrollEventHandler scrollEventHandler2;
			do
			{
				scrollEventHandler2 = scrollEventHandler;
				ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Remove(scrollEventHandler2, value);
				scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
			}
			while (scrollEventHandler != scrollEventHandler2);
		}
	}

	// Token: 0x17000879 RID: 2169
	// (get) Token: 0x06002713 RID: 10003 RVA: 0x0001D171 File Offset: 0x0001B371
	[Browsable(false)]
	public Rectangle Rectangle_0
	{
		get
		{
			return this.rectangle_0;
		}
	}

	// Token: 0x1700087A RID: 2170
	// (get) Token: 0x06002714 RID: 10004 RVA: 0x0001D179 File Offset: 0x0001B379
	// (set) Token: 0x06002715 RID: 10005 RVA: 0x00116F58 File Offset: 0x00115158
	[Description("Set Slider thumb size")]
	[Category("ColorSlider")]
	[DefaultValue(15)]
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
		set
		{
			if (!(value > 0 & value < ((this.orientation_0 == Orientation.Horizontal) ? base.ClientRectangle.Width : base.ClientRectangle.Height)))
			{
				throw new ArgumentOutOfRangeException("TrackSize has to be greather than zero and lower than half of Slider width");
			}
			this.int_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700087B RID: 2171
	// (get) Token: 0x06002716 RID: 10006 RVA: 0x0001D181 File Offset: 0x0001B381
	// (set) Token: 0x06002717 RID: 10007 RVA: 0x00116FB0 File Offset: 0x001151B0
	[DefaultValue(typeof(GraphicsPath), "null")]
	[Category("ColorSlider")]
	[Description("Set Slider's thumb's custom shape")]
	[Browsable(false)]
	public GraphicsPath GraphicsPath_0
	{
		get
		{
			return this.graphicsPath_0;
		}
		set
		{
			this.graphicsPath_0 = value;
			this.int_0 = (int)((this.orientation_0 == Orientation.Horizontal) ? value.GetBounds().Width : value.GetBounds().Height) + 1;
			base.Invalidate();
		}
	}

	// Token: 0x1700087C RID: 2172
	// (get) Token: 0x06002718 RID: 10008 RVA: 0x0001D189 File Offset: 0x0001B389
	// (set) Token: 0x06002719 RID: 10009 RVA: 0x00116FFC File Offset: 0x001151FC
	[Description("Set Slider's thumb round rect size")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Size), "8; 8")]
	public Size Size_0
	{
		get
		{
			return this.size_0;
		}
		set
		{
			int num = value.Height;
			int num2 = value.Width;
			if (num <= 0)
			{
				num = 1;
			}
			if (num2 <= 0)
			{
				num2 = 1;
			}
			this.size_0 = new Size(num2, num);
			base.Invalidate();
		}
	}

	// Token: 0x1700087D RID: 2173
	// (get) Token: 0x0600271A RID: 10010 RVA: 0x0001D191 File Offset: 0x0001B391
	// (set) Token: 0x0600271B RID: 10011 RVA: 0x00117038 File Offset: 0x00115238
	[DefaultValue(typeof(Size), "8; 8")]
	[Description("Set Slider's border round rect size")]
	[Category("ColorSlider")]
	public Size Size_1
	{
		get
		{
			return this.size_1;
		}
		set
		{
			int num = value.Height;
			int num2 = value.Width;
			if (num <= 0)
			{
				num = 1;
			}
			if (num2 <= 0)
			{
				num2 = 1;
			}
			this.size_1 = new Size(num2, num);
			base.Invalidate();
		}
	}

	// Token: 0x1700087E RID: 2174
	// (get) Token: 0x0600271C RID: 10012 RVA: 0x0001D199 File Offset: 0x0001B399
	// (set) Token: 0x0600271D RID: 10013 RVA: 0x00117074 File Offset: 0x00115274
	[DefaultValue(Orientation.Horizontal)]
	[Description("Set Slider orientation")]
	[Category("ColorSlider")]
	public Orientation Orientation_0
	{
		get
		{
			return this.orientation_0;
		}
		set
		{
			if (this.orientation_0 != value)
			{
				this.orientation_0 = value;
				int width = base.Width;
				base.Width = base.Height;
				base.Height = width;
				if (this.graphicsPath_0 != null)
				{
					this.int_0 = (int)((this.orientation_0 == Orientation.Horizontal) ? this.graphicsPath_0.GetBounds().Width : this.graphicsPath_0.GetBounds().Height) + 1;
				}
				base.Invalidate();
			}
		}
	}

	// Token: 0x1700087F RID: 2175
	// (get) Token: 0x0600271E RID: 10014 RVA: 0x0001D1A1 File Offset: 0x0001B3A1
	// (set) Token: 0x0600271F RID: 10015 RVA: 0x001170F4 File Offset: 0x001152F4
	[Description("Set Slider value")]
	[Category("ColorSlider")]
	[DefaultValue(50)]
	public int Int32_1
	{
		get
		{
			return this.int_1;
		}
		set
		{
			if (value >= this.int_2 & value <= this.int_3)
			{
				this.int_1 = value;
				if (this.eventHandler_0 != null)
				{
					this.eventHandler_0(this, new EventArgs());
				}
				base.Invalidate();
				return;
			}
			throw new ArgumentOutOfRangeException("Value is outside appropriate range (min, max)");
		}
	}

	// Token: 0x17000880 RID: 2176
	// (get) Token: 0x06002720 RID: 10016 RVA: 0x0001D1A9 File Offset: 0x0001B3A9
	// (set) Token: 0x06002721 RID: 10017 RVA: 0x00117150 File Offset: 0x00115350
	[Description("Set Slider minimal point")]
	[Category("ColorSlider")]
	[DefaultValue(0)]
	public int Int32_2
	{
		get
		{
			return this.int_2;
		}
		set
		{
			if (value < this.int_3)
			{
				this.int_2 = value;
				if (this.int_1 < this.int_2)
				{
					this.int_1 = this.int_2;
					if (this.eventHandler_0 != null)
					{
						this.eventHandler_0(this, new EventArgs());
					}
				}
				base.Invalidate();
				return;
			}
			throw new ArgumentOutOfRangeException("Minimal value is greather than maximal one");
		}
	}

	// Token: 0x17000881 RID: 2177
	// (get) Token: 0x06002722 RID: 10018 RVA: 0x0001D1B1 File Offset: 0x0001B3B1
	// (set) Token: 0x06002723 RID: 10019 RVA: 0x001171B4 File Offset: 0x001153B4
	[DefaultValue(100)]
	[Description("Set Slider maximal point")]
	[Category("ColorSlider")]
	public int Int32_3
	{
		get
		{
			return this.int_3;
		}
		set
		{
			if (value > this.int_2)
			{
				this.int_3 = value;
				if (this.int_1 > this.int_3)
				{
					this.int_1 = this.int_3;
					if (this.eventHandler_0 != null)
					{
						this.eventHandler_0(this, new EventArgs());
					}
				}
				base.Invalidate();
				return;
			}
			throw new ArgumentOutOfRangeException("Maximal value is lower than minimal one");
		}
	}

	// Token: 0x17000882 RID: 2178
	// (get) Token: 0x06002724 RID: 10020 RVA: 0x0001D1B9 File Offset: 0x0001B3B9
	// (set) Token: 0x06002725 RID: 10021 RVA: 0x0001D1C1 File Offset: 0x0001B3C1
	[Description("Set trackbar's small change")]
	[Category("ColorSlider")]
	[DefaultValue(1)]
	public uint UInt32_0
	{
		get
		{
			return this.uint_0;
		}
		set
		{
			this.uint_0 = value;
		}
	}

	// Token: 0x17000883 RID: 2179
	// (get) Token: 0x06002726 RID: 10022 RVA: 0x0001D1CA File Offset: 0x0001B3CA
	// (set) Token: 0x06002727 RID: 10023 RVA: 0x0001D1D2 File Offset: 0x0001B3D2
	[Description("Set trackbar's large change")]
	[Category("ColorSlider")]
	[DefaultValue(5)]
	public uint UInt32_1
	{
		get
		{
			return this.uint_1;
		}
		set
		{
			this.uint_1 = value;
		}
	}

	// Token: 0x17000884 RID: 2180
	// (get) Token: 0x06002728 RID: 10024 RVA: 0x0001D1DB File Offset: 0x0001B3DB
	// (set) Token: 0x06002729 RID: 10025 RVA: 0x0001D1E3 File Offset: 0x0001B3E3
	[Description("Set whether to draw focus rectangle")]
	[Category("ColorSlider")]
	[DefaultValue(true)]
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000885 RID: 2181
	// (get) Token: 0x0600272A RID: 10026 RVA: 0x0001D1F2 File Offset: 0x0001B3F2
	// (set) Token: 0x0600272B RID: 10027 RVA: 0x0001D1FA File Offset: 0x0001B3FA
	[Category("ColorSlider")]
	[DefaultValue(true)]
	[Description("Set whether to draw semitransparent thumb")]
	public bool Boolean_1
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000886 RID: 2182
	// (get) Token: 0x0600272C RID: 10028 RVA: 0x0001D209 File Offset: 0x0001B409
	// (set) Token: 0x0600272D RID: 10029 RVA: 0x0001D211 File Offset: 0x0001B411
	[Description("Set whether mouse entry and exit actions have impact on how control look")]
	[Category("ColorSlider")]
	[DefaultValue(true)]
	public bool Boolean_2
	{
		get
		{
			return this.bool_2;
		}
		set
		{
			this.bool_2 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000887 RID: 2183
	// (get) Token: 0x0600272E RID: 10030 RVA: 0x0001D220 File Offset: 0x0001B420
	// (set) Token: 0x0600272F RID: 10031 RVA: 0x0001D228 File Offset: 0x0001B428
	[Description("Set to how many parts is bar divided when using mouse wheel")]
	[Category("ColorSlider")]
	[DefaultValue(10)]
	public int Int32_4
	{
		get
		{
			return this.int_4;
		}
		set
		{
			if (value <= 0)
			{
				throw new ArgumentOutOfRangeException("MouseWheelBarPartitions has to be greather than zero");
			}
			this.int_4 = value;
		}
	}

	// Token: 0x17000888 RID: 2184
	// (get) Token: 0x06002730 RID: 10032 RVA: 0x0001D240 File Offset: 0x0001B440
	// (set) Token: 0x06002731 RID: 10033 RVA: 0x0001D248 File Offset: 0x0001B448
	[Description("Set Slider thumb outer color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "White")]
	public Color Color_0
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000889 RID: 2185
	// (get) Token: 0x06002732 RID: 10034 RVA: 0x0001D257 File Offset: 0x0001B457
	// (set) Token: 0x06002733 RID: 10035 RVA: 0x0001D25F File Offset: 0x0001B45F
	[DefaultValue(typeof(Color), "Gainsboro")]
	[Description("Set Slider thumb inner color")]
	[Category("ColorSlider")]
	public Color Color_1
	{
		get
		{
			return this.color_1;
		}
		set
		{
			this.color_1 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088A RID: 2186
	// (get) Token: 0x06002734 RID: 10036 RVA: 0x0001D26E File Offset: 0x0001B46E
	// (set) Token: 0x06002735 RID: 10037 RVA: 0x0001D276 File Offset: 0x0001B476
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "Silver")]
	[Description("Set Slider thumb pen color")]
	public Color Color_2
	{
		get
		{
			return this.color_2;
		}
		set
		{
			this.color_2 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088B RID: 2187
	// (get) Token: 0x06002736 RID: 10038 RVA: 0x0001D285 File Offset: 0x0001B485
	// (set) Token: 0x06002737 RID: 10039 RVA: 0x0001D28D File Offset: 0x0001B48D
	[Description("Set Slider bar outer color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "SkyBlue")]
	public Color Color_3
	{
		get
		{
			return this.color_3;
		}
		set
		{
			this.color_3 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088C RID: 2188
	// (get) Token: 0x06002738 RID: 10040 RVA: 0x0001D29C File Offset: 0x0001B49C
	// (set) Token: 0x06002739 RID: 10041 RVA: 0x0001D2A4 File Offset: 0x0001B4A4
	[Description("Set Slider bar inner color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "DarkSlateBlue")]
	public Color Color_4
	{
		get
		{
			return this.color_4;
		}
		set
		{
			this.color_4 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088D RID: 2189
	// (get) Token: 0x0600273A RID: 10042 RVA: 0x0001D2B3 File Offset: 0x0001B4B3
	// (set) Token: 0x0600273B RID: 10043 RVA: 0x0001D2BB File Offset: 0x0001B4BB
	[Description("Set Slider bar pen color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "Gainsboro")]
	public Color Color_5
	{
		get
		{
			return this.color_5;
		}
		set
		{
			this.color_5 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088E RID: 2190
	// (get) Token: 0x0600273C RID: 10044 RVA: 0x0001D2CA File Offset: 0x0001B4CA
	// (set) Token: 0x0600273D RID: 10045 RVA: 0x0001D2D2 File Offset: 0x0001B4D2
	[Description("Set Slider's elapsed part outer color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "DarkGreen")]
	public Color Color_6
	{
		get
		{
			return this.color_6;
		}
		set
		{
			this.color_6 = value;
			base.Invalidate();
		}
	}

	// Token: 0x1700088F RID: 2191
	// (get) Token: 0x0600273E RID: 10046 RVA: 0x0001D2E1 File Offset: 0x0001B4E1
	// (set) Token: 0x0600273F RID: 10047 RVA: 0x0001D2E9 File Offset: 0x0001B4E9
	[Description("Set Slider's elapsed part inner color")]
	[Category("ColorSlider")]
	[DefaultValue(typeof(Color), "Chartreuse")]
	public Color Color_7
	{
		get
		{
			return this.color_7;
		}
		set
		{
			this.color_7 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000890 RID: 2192
	// (get) Token: 0x06002740 RID: 10048 RVA: 0x0001D2F8 File Offset: 0x0001B4F8
	// (set) Token: 0x06002741 RID: 10049 RVA: 0x00117218 File Offset: 0x00115418
	[Category("ColorSlider")]
	[DefaultValue(typeof(Control0.Enum16), "PerlBlueGreen")]
	[Description("Set Slider color schema. Has no effect when slider colors are changed manually after schema was applied.")]
	public Control0.Enum16 Enum16_0
	{
		get
		{
			return this.enum16_0;
		}
		set
		{
			this.enum16_0 = value;
			byte b = (byte)value;
			this.color_0 = this.color_8[(int)b, 0];
			this.color_1 = this.color_8[(int)b, 1];
			this.color_2 = this.color_8[(int)b, 2];
			this.color_3 = this.color_8[(int)b, 3];
			this.color_4 = this.color_8[(int)b, 4];
			this.color_5 = this.color_8[(int)b, 5];
			this.color_6 = this.color_8[(int)b, 6];
			this.color_7 = this.color_8[(int)b, 7];
			base.Invalidate();
		}
	}

	// Token: 0x06002742 RID: 10050 RVA: 0x001172D0 File Offset: 0x001154D0
	public Control0(int int_5, int int_6, int int_7)
	{
		Color[,] array = new Color[4, 8];
		array[0, 0] = Color.White;
		array[0, 1] = Color.Gainsboro;
		array[0, 2] = Color.Silver;
		array[0, 3] = Color.SkyBlue;
		array[0, 4] = Color.DarkSlateBlue;
		array[0, 5] = Color.Gainsboro;
		array[0, 6] = Color.DarkGreen;
		array[0, 7] = Color.Chartreuse;
		array[1, 0] = Color.White;
		array[1, 1] = Color.Gainsboro;
		array[1, 2] = Color.Silver;
		array[1, 3] = Color.Red;
		array[1, 4] = Color.DarkRed;
		array[1, 5] = Color.Gainsboro;
		array[1, 6] = Color.Coral;
		array[1, 7] = Color.LightCoral;
		array[2, 0] = Color.White;
		array[2, 1] = Color.Gainsboro;
		array[2, 2] = Color.Silver;
		array[2, 3] = Color.GreenYellow;
		array[2, 4] = Color.Yellow;
		array[2, 5] = Color.Gold;
		array[2, 6] = Color.Orange;
		array[2, 7] = Color.OrangeRed;
		array[3, 0] = Color.White;
		array[3, 1] = Color.Gainsboro;
		array[3, 2] = Color.Silver;
		array[3, 3] = Color.Red;
		array[3, 4] = Color.Crimson;
		array[3, 5] = Color.Gainsboro;
		array[3, 6] = Color.DarkViolet;
		array[3, 7] = Color.Violet;
		this.color_8 = array;
		base..ctor();
		this.method_2();
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.UserMouse | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this.BackColor = Color.Transparent;
		this.Int32_2 = int_5;
		this.Int32_3 = int_6;
		this.Int32_1 = int_7;
	}

	// Token: 0x06002743 RID: 10051 RVA: 0x0001D300 File Offset: 0x0001B500
	public Control0() : this(0, 100, 50)
	{
	}

	// Token: 0x06002744 RID: 10052 RVA: 0x00117578 File Offset: 0x00115778
	protected virtual void OnPaint(PaintEventArgs e)
	{
		if (!base.Enabled)
		{
			Color[] array = Control0.smethod_1(new Color[]
			{
				this.color_0,
				this.color_1,
				this.color_2,
				this.color_3,
				this.color_4,
				this.color_5,
				this.color_6,
				this.color_7
			});
			this.method_0(e, array[0], array[1], array[2], array[3], array[4], array[5], array[6], array[7]);
			return;
		}
		if (this.bool_2 && this.bool_3)
		{
			Color[] array2 = Control0.smethod_2(new Color[]
			{
				this.color_0,
				this.color_1,
				this.color_2,
				this.color_3,
				this.color_4,
				this.color_5,
				this.color_6,
				this.color_7
			});
			this.method_0(e, array2[0], array2[1], array2[2], array2[3], array2[4], array2[5], array2[6], array2[7]);
			return;
		}
		this.method_0(e, this.color_0, this.color_1, this.color_2, this.color_3, this.color_4, this.color_5, this.color_6, this.color_7);
	}

	// Token: 0x06002745 RID: 10053 RVA: 0x00117748 File Offset: 0x00115948
	private void method_0(PaintEventArgs paintEventArgs_0, Color color_9, Color color_10, Color color_11, Color color_12, Color color_13, Color color_14, Color color_15, Color color_16)
	{
		try
		{
			if (this.orientation_0 == Orientation.Horizontal)
			{
				int x = (this.int_1 - this.int_2) * (base.ClientRectangle.Width - this.int_0) / (this.int_3 - this.int_2);
				this.rectangle_0 = new Rectangle(x, 1, this.int_0 - 1, base.ClientRectangle.Height - 3);
			}
			else
			{
				int y = (this.int_1 - this.int_2) * (base.ClientRectangle.Height - this.int_0) / (this.int_3 - this.int_2);
				this.rectangle_0 = new Rectangle(1, y, base.ClientRectangle.Width - 3, this.int_0 - 1);
			}
			this.rectangle_1 = base.ClientRectangle;
			this.rectangle_3 = this.rectangle_0;
			LinearGradientMode linearGradientMode;
			if (this.orientation_0 == Orientation.Horizontal)
			{
				this.rectangle_1.Inflate(-1, -this.rectangle_1.Height / 3);
				this.rectangle_2 = this.rectangle_1;
				this.rectangle_2.Height = this.rectangle_2.Height / 2;
				linearGradientMode = LinearGradientMode.Vertical;
				this.rectangle_3.Height = this.rectangle_3.Height / 2;
				this.rectangle_4 = this.rectangle_1;
				this.rectangle_4.Width = this.rectangle_0.Left + this.int_0 / 2;
			}
			else
			{
				this.rectangle_1.Inflate(-this.rectangle_1.Width / 3, -1);
				this.rectangle_2 = this.rectangle_1;
				this.rectangle_2.Width = this.rectangle_2.Width / 2;
				linearGradientMode = LinearGradientMode.Horizontal;
				this.rectangle_3.Width = this.rectangle_3.Width / 2;
				this.rectangle_4 = this.rectangle_1;
				this.rectangle_4.Height = this.rectangle_0.Top + this.int_0 / 2;
			}
			GraphicsPath graphicsPath;
			if (this.graphicsPath_0 == null)
			{
				graphicsPath = Control0.smethod_0(this.rectangle_0, this.size_0);
			}
			else
			{
				graphicsPath = this.graphicsPath_0;
				Matrix matrix = new Matrix();
				matrix.Translate((float)this.rectangle_0.Left - graphicsPath.GetBounds().Left, (float)this.rectangle_0.Top - graphicsPath.GetBounds().Top);
				graphicsPath.Transform(matrix);
			}
			using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(this.rectangle_2, color_12, color_13, linearGradientMode))
			{
				linearGradientBrush.WrapMode = WrapMode.TileFlipXY;
				paintEventArgs_0.Graphics.FillRectangle(linearGradientBrush, this.rectangle_1);
				using (LinearGradientBrush linearGradientBrush2 = new LinearGradientBrush(this.rectangle_2, color_15, color_16, linearGradientMode))
				{
					linearGradientBrush2.WrapMode = WrapMode.TileFlipXY;
					if (base.Capture && this.bool_1)
					{
						Region region = new Region(this.rectangle_4);
						region.Exclude(graphicsPath);
						paintEventArgs_0.Graphics.FillRegion(linearGradientBrush2, region);
					}
					else
					{
						paintEventArgs_0.Graphics.FillRectangle(linearGradientBrush2, this.rectangle_4);
					}
				}
				using (Pen pen = new Pen(color_14, 0.5f))
				{
					paintEventArgs_0.Graphics.DrawRectangle(pen, this.rectangle_1);
				}
			}
			Color color = color_9;
			Color color2 = color_10;
			if (base.Capture && this.bool_1)
			{
				color = Color.FromArgb(175, color_9);
				color2 = Color.FromArgb(175, color_10);
			}
			using (LinearGradientBrush linearGradientBrush3 = new LinearGradientBrush(this.rectangle_3, color, color2, linearGradientMode))
			{
				linearGradientBrush3.WrapMode = WrapMode.TileFlipXY;
				paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				paintEventArgs_0.Graphics.FillPath(linearGradientBrush3, graphicsPath);
				Color color3 = color_11;
				if (this.bool_2 && (base.Capture || this.bool_4))
				{
					color3 = ControlPaint.Dark(color3);
				}
				using (Pen pen2 = new Pen(color3))
				{
					paintEventArgs_0.Graphics.DrawPath(pen2, graphicsPath);
				}
			}
			if (this.Focused & this.bool_0)
			{
				using (Pen pen3 = new Pen(Color.FromArgb(200, color_14)))
				{
					pen3.DashStyle = DashStyle.Dot;
					Rectangle clientRectangle = base.ClientRectangle;
					clientRectangle.Width -= 2;
					int num = clientRectangle.Height;
					clientRectangle.Height = num - 1;
					num = clientRectangle.X;
					clientRectangle.X = num + 1;
					using (GraphicsPath graphicsPath2 = Control0.smethod_0(clientRectangle, this.size_1))
					{
						paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
						paintEventArgs_0.Graphics.DrawPath(pen3, graphicsPath2);
					}
				}
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine("DrawBackGround Error in " + base.Name + ":" + ex.Message);
		}
	}

	// Token: 0x06002746 RID: 10054 RVA: 0x0001D30D File Offset: 0x0001B50D
	protected virtual void OnEnabledChanged(EventArgs e)
	{
		base.OnEnabledChanged(e);
		base.Invalidate();
	}

	// Token: 0x06002747 RID: 10055 RVA: 0x0001D31C File Offset: 0x0001B51C
	protected virtual void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		this.bool_3 = true;
		base.Invalidate();
	}

	// Token: 0x06002748 RID: 10056 RVA: 0x0001D332 File Offset: 0x0001B532
	protected virtual void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		this.bool_3 = false;
		this.bool_4 = false;
		base.Invalidate();
	}

	// Token: 0x06002749 RID: 10057 RVA: 0x00117CC8 File Offset: 0x00115EC8
	protected virtual void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		if (e.Button == MouseButtons.Left)
		{
			base.Capture = true;
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.ThumbTrack, this.int_1));
			}
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, new EventArgs());
			}
			this.OnMouseMove(e);
		}
	}

	// Token: 0x0600274A RID: 10058 RVA: 0x00117D30 File Offset: 0x00115F30
	protected virtual void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		this.bool_4 = Control0.smethod_3(e.Location, this.rectangle_0);
		if (base.Capture & e.Button == MouseButtons.Left)
		{
			ScrollEventType type = ScrollEventType.ThumbPosition;
			Point location = e.Location;
			int num = (this.orientation_0 == Orientation.Horizontal) ? location.X : location.Y;
			int num2 = this.int_0 >> 1;
			num -= num2;
			float num3 = (float)(this.int_3 - this.int_2) / (float)(((this.orientation_0 == Orientation.Horizontal) ? base.ClientSize.Width : base.ClientSize.Height) - 2 * num2);
			this.int_1 = (int)((float)num * num3 + (float)this.int_2);
			if (this.int_1 <= this.int_2)
			{
				this.int_1 = this.int_2;
				type = ScrollEventType.First;
			}
			else if (this.int_1 >= this.int_3)
			{
				this.int_1 = this.int_3;
				type = ScrollEventType.Last;
			}
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(type, this.int_1));
			}
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, new EventArgs());
			}
		}
		base.Invalidate();
	}

	// Token: 0x0600274B RID: 10059 RVA: 0x00117E70 File Offset: 0x00116070
	protected virtual void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		base.Capture = false;
		this.bool_4 = Control0.smethod_3(e.Location, this.rectangle_0);
		if (this.scrollEventHandler_0 != null)
		{
			this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.EndScroll, this.int_1));
		}
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, new EventArgs());
		}
		base.Invalidate();
	}

	// Token: 0x0600274C RID: 10060 RVA: 0x00117EE4 File Offset: 0x001160E4
	protected virtual void OnMouseWheel(MouseEventArgs e)
	{
		base.OnMouseWheel(e);
		int num = e.Delta / 120 * (this.int_3 - this.int_2) / this.int_4;
		this.method_1(this.Int32_1 + num);
	}

	// Token: 0x0600274D RID: 10061 RVA: 0x0001D34F File Offset: 0x0001B54F
	protected virtual void OnGotFocus(EventArgs e)
	{
		base.OnGotFocus(e);
		base.Invalidate();
	}

	// Token: 0x0600274E RID: 10062 RVA: 0x0001D35E File Offset: 0x0001B55E
	protected virtual void OnLostFocus(EventArgs e)
	{
		base.OnLostFocus(e);
		base.Invalidate();
	}

	// Token: 0x0600274F RID: 10063 RVA: 0x00117F28 File Offset: 0x00116128
	protected virtual void OnKeyUp(KeyEventArgs e)
	{
		base.OnKeyUp(e);
		switch (e.KeyCode)
		{
		case Keys.Prior:
			this.method_1(this.Int32_1 + (int)this.uint_1);
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.LargeIncrement, this.Int32_1));
			}
			break;
		case Keys.Next:
			this.method_1(this.Int32_1 - (int)this.uint_1);
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.LargeDecrement, this.Int32_1));
			}
			break;
		case Keys.End:
			this.Int32_1 = this.int_3;
			break;
		case Keys.Home:
			this.Int32_1 = this.int_2;
			break;
		case Keys.Left:
		case Keys.Down:
			this.method_1(this.Int32_1 - (int)this.uint_0);
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.SmallDecrement, this.Int32_1));
			}
			break;
		case Keys.Up:
		case Keys.Right:
			this.method_1(this.Int32_1 + (int)this.uint_0);
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.SmallIncrement, this.Int32_1));
			}
			break;
		}
		if (this.scrollEventHandler_0 != null && this.Int32_1 == this.int_2)
		{
			this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.First, this.Int32_1));
		}
		if (this.scrollEventHandler_0 != null && this.Int32_1 == this.int_3)
		{
			this.scrollEventHandler_0(this, new ScrollEventArgs(ScrollEventType.Last, this.Int32_1));
		}
		Point point = base.PointToClient(Cursor.Position);
		this.OnMouseMove(new MouseEventArgs(MouseButtons.None, 0, point.X, point.Y, 0));
	}

	// Token: 0x06002750 RID: 10064 RVA: 0x0001D36D File Offset: 0x0001B56D
	protected virtual bool ProcessDialogKey(Keys keyData)
	{
		if (keyData == Keys.Tab | Control.ModifierKeys == Keys.Shift)
		{
			return base.ProcessDialogKey(keyData);
		}
		this.OnKeyDown(new KeyEventArgs(keyData));
		return true;
	}

	// Token: 0x06002751 RID: 10065 RVA: 0x001180F0 File Offset: 0x001162F0
	public static GraphicsPath smethod_0(Rectangle rectangle_5, Size size_2)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		graphicsPath.AddLine(rectangle_5.Left + size_2.Width / 2, rectangle_5.Top, rectangle_5.Right - size_2.Width / 2, rectangle_5.Top);
		graphicsPath.AddArc(rectangle_5.Right - size_2.Width, rectangle_5.Top, size_2.Width, size_2.Height, 270f, 90f);
		graphicsPath.AddLine(rectangle_5.Right, rectangle_5.Top + size_2.Height / 2, rectangle_5.Right, rectangle_5.Bottom - size_2.Width / 2);
		graphicsPath.AddArc(rectangle_5.Right - size_2.Width, rectangle_5.Bottom - size_2.Height, size_2.Width, size_2.Height, 0f, 90f);
		graphicsPath.AddLine(rectangle_5.Right - size_2.Width / 2, rectangle_5.Bottom, rectangle_5.Left + size_2.Width / 2, rectangle_5.Bottom);
		graphicsPath.AddArc(rectangle_5.Left, rectangle_5.Bottom - size_2.Height, size_2.Width, size_2.Height, 90f, 90f);
		graphicsPath.AddLine(rectangle_5.Left, rectangle_5.Bottom - size_2.Height / 2, rectangle_5.Left, rectangle_5.Top + size_2.Height / 2);
		graphicsPath.AddArc(rectangle_5.Left, rectangle_5.Top, size_2.Width, size_2.Height, 180f, 90f);
		return graphicsPath;
	}

	// Token: 0x06002752 RID: 10066 RVA: 0x001182AC File Offset: 0x001164AC
	public static Color[] smethod_1(params Color[] color_9)
	{
		Color[] array = new Color[color_9.Length];
		for (int i = 0; i < color_9.Length; i++)
		{
			int num = (int)((double)color_9[i].R * 0.3 + (double)color_9[i].G * 0.6 + (double)color_9[i].B * 0.1);
			array[i] = Color.FromArgb(-65793 * (255 - num) - 1);
		}
		return array;
	}

	// Token: 0x06002753 RID: 10067 RVA: 0x00118338 File Offset: 0x00116538
	public static Color[] smethod_2(params Color[] color_9)
	{
		Color[] array = new Color[color_9.Length];
		for (int i = 0; i < color_9.Length; i++)
		{
			array[i] = ControlPaint.Light(color_9[i]);
		}
		return array;
	}

	// Token: 0x06002754 RID: 10068 RVA: 0x0001D398 File Offset: 0x0001B598
	private void method_1(int int_5)
	{
		if (int_5 < this.int_2)
		{
			this.Int32_1 = this.int_2;
			return;
		}
		if (int_5 > this.int_3)
		{
			this.Int32_1 = this.int_3;
			return;
		}
		this.Int32_1 = int_5;
	}

	// Token: 0x06002755 RID: 10069 RVA: 0x00118370 File Offset: 0x00116570
	private static bool smethod_3(Point point_0, Rectangle rectangle_5)
	{
		return point_0.X > rectangle_5.Left & point_0.X < rectangle_5.Right & point_0.Y > rectangle_5.Top & point_0.Y < rectangle_5.Bottom;
	}

	// Token: 0x06002756 RID: 10070 RVA: 0x0001D3CD File Offset: 0x0001B5CD
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06002757 RID: 10071 RVA: 0x0001D3EC File Offset: 0x0001B5EC
	private void method_2()
	{
		base.SuspendLayout();
		base.Size = new Size(200, 30);
		base.ResumeLayout(false);
	}

	// Token: 0x04001A9A RID: 6810
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04001A9B RID: 6811
	[CompilerGenerated]
	private ScrollEventHandler scrollEventHandler_0;

	// Token: 0x04001A9C RID: 6812
	private Rectangle rectangle_0;

	// Token: 0x04001A9D RID: 6813
	private Rectangle rectangle_1;

	// Token: 0x04001A9E RID: 6814
	private Rectangle rectangle_2;

	// Token: 0x04001A9F RID: 6815
	private Rectangle rectangle_3;

	// Token: 0x04001AA0 RID: 6816
	private Rectangle rectangle_4;

	// Token: 0x04001AA1 RID: 6817
	private int int_0 = 15;

	// Token: 0x04001AA2 RID: 6818
	private GraphicsPath graphicsPath_0;

	// Token: 0x04001AA3 RID: 6819
	private Size size_0 = new Size(8, 8);

	// Token: 0x04001AA4 RID: 6820
	private Size size_1 = new Size(8, 8);

	// Token: 0x04001AA5 RID: 6821
	private Orientation orientation_0;

	// Token: 0x04001AA6 RID: 6822
	private int int_1 = 50;

	// Token: 0x04001AA7 RID: 6823
	private int int_2;

	// Token: 0x04001AA8 RID: 6824
	private int int_3 = 100;

	// Token: 0x04001AA9 RID: 6825
	private uint uint_0 = 1U;

	// Token: 0x04001AAA RID: 6826
	private uint uint_1 = 5U;

	// Token: 0x04001AAB RID: 6827
	private bool bool_0 = true;

	// Token: 0x04001AAC RID: 6828
	private bool bool_1 = true;

	// Token: 0x04001AAD RID: 6829
	private bool bool_2 = true;

	// Token: 0x04001AAE RID: 6830
	private int int_4 = 10;

	// Token: 0x04001AAF RID: 6831
	private Color color_0 = Color.White;

	// Token: 0x04001AB0 RID: 6832
	private Color color_1 = Color.Gainsboro;

	// Token: 0x04001AB1 RID: 6833
	private Color color_2 = Color.Silver;

	// Token: 0x04001AB2 RID: 6834
	private Color color_3 = Color.SkyBlue;

	// Token: 0x04001AB3 RID: 6835
	private Color color_4 = Color.DarkSlateBlue;

	// Token: 0x04001AB4 RID: 6836
	private Color color_5 = Color.Gainsboro;

	// Token: 0x04001AB5 RID: 6837
	private Color color_6 = Color.DarkGreen;

	// Token: 0x04001AB6 RID: 6838
	private Color color_7 = Color.Chartreuse;

	// Token: 0x04001AB7 RID: 6839
	private Color[,] color_8;

	// Token: 0x04001AB8 RID: 6840
	private Control0.Enum16 enum16_0;

	// Token: 0x04001AB9 RID: 6841
	private bool bool_3;

	// Token: 0x04001ABA RID: 6842
	private bool bool_4;

	// Token: 0x04001ABB RID: 6843
	private IContainer icontainer_0;

	// Token: 0x020002C0 RID: 704
	public enum Enum16
	{
		// Token: 0x04001ABD RID: 6845
		PerlBlueGreen,
		// Token: 0x04001ABE RID: 6846
		PerlRedCoral,
		// Token: 0x04001ABF RID: 6847
		PerlGold,
		// Token: 0x04001AC0 RID: 6848
		PerlRoyalColors
	}
}
