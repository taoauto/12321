﻿using System;

// Token: 0x02000170 RID: 368
internal class Class149
{
}
