﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020002BB RID: 699
internal class Class384
{
	// Token: 0x060026EF RID: 9967
	[DllImport("user32.dll")]
	public static extern int GetKeyState(int int_4);

	// Token: 0x060026F0 RID: 9968 RVA: 0x00116D40 File Offset: 0x00114F40
	public static bool smethod_0(int int_4)
	{
		return Convert.ToBoolean(Class384.GetKeyState(int_4) & 32768);
	}

	// Token: 0x060026F1 RID: 9969
	[DllImport("user32.dll")]
	public static extern IntPtr SendMessage(IntPtr intptr_0, int int_4, int int_5, int int_6);

	// Token: 0x04001A8B RID: 6795
	public static int int_0 = 160;

	// Token: 0x04001A8C RID: 6796
	public static int int_1 = 161;

	// Token: 0x04001A8D RID: 6797
	public static int int_2 = 162;

	// Token: 0x04001A8E RID: 6798
	public static int int_3 = 163;
}
