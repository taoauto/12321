﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Xml;
using _i;

// Token: 0x0200020A RID: 522
internal class CalendarEx : UserControl
{
	// Token: 0x17000677 RID: 1655
	// (get) Token: 0x06001B09 RID: 6921 RVA: 0x000139C9 File Offset: 0x00011BC9
	// (set) Token: 0x06001B0A RID: 6922 RVA: 0x000139D0 File Offset: 0x00011BD0
	public static Dictionary<string, string> Dictionary_0 { get; set; } = new Dictionary<string, string>();

	// Token: 0x06001B0B RID: 6923 RVA: 0x000CD570 File Offset: 0x000CB770
	public static void smethod_0()
	{
		try
		{
			CalendarEx.xmlDocument_0.LoadXml(Class159.Class220_0.method_0("Item", "Balls"));
		}
		catch
		{
			if (CalendarEx.xmlDocument_0.SelectSingleNode("Balls") == null)
			{
				CalendarEx.xmlDocument_0.InsertBefore(CalendarEx.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), CalendarEx.xmlDocument_0.DocumentElement);
				CalendarEx.xmlDocument_0.AppendChild(CalendarEx.xmlDocument_0.CreateNode(XmlNodeType.Element, "Balls", ""));
				Class159.Class220_0.method_1("Item", "Balls", CalendarEx.xmlDocument_0.OuterXml);
			}
		}
		try
		{
			CalendarEx.xmlDocument_1.LoadXml(Class159.Class220_0.method_0("Item", "TyVos"));
		}
		catch
		{
			if (CalendarEx.xmlDocument_1.SelectSingleNode("TyVos") == null)
			{
				CalendarEx.xmlDocument_1.InsertBefore(CalendarEx.xmlDocument_1.CreateXmlDeclaration("1.0", "UTF-8", null), CalendarEx.xmlDocument_1.DocumentElement);
				CalendarEx.xmlDocument_1.AppendChild(CalendarEx.xmlDocument_1.CreateNode(XmlNodeType.Element, "TyVos", ""));
				Class159.Class220_0.method_1("Item", "TyVos", CalendarEx.xmlDocument_1.OuterXml);
			}
		}
		try
		{
			CalendarEx.xmlDocument_2.LoadXml(Class159.Class220_0.method_0("Item", "QuanDoan"));
		}
		catch
		{
			if (CalendarEx.xmlDocument_2.SelectSingleNode("QuanDoans") == null)
			{
				CalendarEx.xmlDocument_2.InsertBefore(CalendarEx.xmlDocument_2.CreateXmlDeclaration("1.0", "UTF-8", null), CalendarEx.xmlDocument_2.DocumentElement);
				CalendarEx.xmlDocument_2.AppendChild(CalendarEx.xmlDocument_2.CreateNode(XmlNodeType.Element, "QuanDoans", ""));
				Class159.Class220_0.method_1("Item", "QuanDoan", CalendarEx.xmlDocument_2.OuterXml);
			}
		}
		CalendarEx.dictionary_1.Clear();
		CalendarEx.dictionary_2.Clear();
		CalendarEx.dictionary_3.Clear();
		try
		{
			if (CalendarEx.xmlDocument_0.SelectSingleNode("Balls").SelectNodes("Ball") != null)
			{
				foreach (object obj in CalendarEx.xmlDocument_0.SelectSingleNode("Balls").SelectNodes("Ball"))
				{
					XmlElement xmlElement = (XmlElement)obj;
					if (xmlElement.Attributes["Name"] != null)
					{
						string value = xmlElement.Attributes["Name"].Value;
						if (!CalendarEx.dictionary_1.ContainsKey(value))
						{
							if (xmlElement.Attributes["Member"] == null)
							{
								CalendarEx.dictionary_1.Add(value, "");
							}
							else
							{
								CalendarEx.dictionary_1.Add(value, xmlElement.Attributes["Member"].Value);
							}
						}
					}
				}
			}
			if (CalendarEx.xmlDocument_1.SelectSingleNode("TyVos").SelectNodes("TyVo") != null)
			{
				foreach (object obj2 in CalendarEx.xmlDocument_1.SelectSingleNode("TyVos").SelectNodes("TyVo"))
				{
					XmlElement xmlElement2 = (XmlElement)obj2;
					if (xmlElement2.Attributes["Name"] != null)
					{
						string value2 = xmlElement2.Attributes["Name"].Value;
						if (!CalendarEx.dictionary_2.ContainsKey(value2))
						{
							if (xmlElement2.Attributes["Member"] == null)
							{
								CalendarEx.dictionary_2.Add(value2, "");
							}
							else
							{
								CalendarEx.dictionary_2.Add(value2, xmlElement2.Attributes["Member"].Value);
							}
						}
					}
				}
			}
			if (CalendarEx.xmlDocument_2.SelectSingleNode("QuanDoans").SelectNodes("QuanDoan") != null)
			{
				foreach (object obj3 in CalendarEx.xmlDocument_2.SelectSingleNode("QuanDoans").SelectNodes("QuanDoan"))
				{
					XmlElement xmlElement3 = (XmlElement)obj3;
					if (xmlElement3.Attributes["Name"] != null)
					{
						string value3 = xmlElement3.Attributes["Name"].Value;
						if (!CalendarEx.dictionary_3.ContainsKey(value3))
						{
							if (xmlElement3.Attributes["Member"] == null)
							{
								CalendarEx.dictionary_3.Add(value3, "");
							}
							else
							{
								CalendarEx.dictionary_3.Add(value3, xmlElement3.Attributes["Member"].Value);
							}
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + ex.StackTrace);
		}
	}

	// Token: 0x06001B0C RID: 6924 RVA: 0x000139D8 File Offset: 0x00011BD8
	public CalendarEx()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001B0D RID: 6925 RVA: 0x00002E18 File Offset: 0x00001018
	private void CalendarEx_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B0E RID: 6926 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B0F RID: 6927 RVA: 0x00002E18 File Offset: 0x00001018
	private void btnAddTeam_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B10 RID: 6928 RVA: 0x000CDB00 File Offset: 0x000CBD00
	private void btnAllBallName_Click(object sender, EventArgs e)
	{
		if (!string.IsNullOrEmpty(this.txtBallName.Text) && !CalendarEx.dictionary_1.ContainsKey(this.txtBallName.Text))
		{
			try
			{
				XmlElement xmlElement = CalendarEx.xmlDocument_0.CreateElement("Ball");
				XmlAttribute xmlAttribute = CalendarEx.xmlDocument_0.CreateAttribute("Name");
				xmlAttribute.Value = this.txtBallName.Text;
				xmlElement.Attributes.Append(xmlAttribute);
				CalendarEx.xmlDocument_0.SelectSingleNode("/*").AppendChild(xmlElement);
				ListViewItem listViewItem = new ListViewItem(this.txtBallName.Text);
				listViewItem.Tag = "";
				this.listViewBallID.Items.Add(listViewItem);
				listViewItem.Selected = true;
				Class159.Class220_0.method_1("Item", "Balls", CalendarEx.xmlDocument_0.OuterXml);
			}
			catch
			{
			}
		}
	}

	// Token: 0x06001B11 RID: 6929 RVA: 0x000CDBF8 File Offset: 0x000CBDF8
	private void listViewBallID_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.listViewBallMem.Items.Clear();
		if (this.listViewBallID.SelectedItems.Count > 0)
		{
			foreach (string text in (this.listViewBallID.SelectedItems[0].Tag as string).Split(new char[]
			{
				';'
			}))
			{
				if (text.Split(new char[]
				{
					'-'
				}).Length == 2)
				{
					string tag = text.Split(new char[]
					{
						'-'
					})[0];
					ListViewItem listViewItem = new ListViewItem(text.Split(new char[]
					{
						'-'
					})[1]);
					listViewItem.Tag = tag;
					this.listViewBallMem.Items.Add(listViewItem);
				}
			}
		}
	}

	// Token: 0x06001B12 RID: 6930 RVA: 0x000CDCC8 File Offset: 0x000CBEC8
	private void deleteBall_Click(object sender, EventArgs e)
	{
		while (this.listViewBallID.SelectedItems.Count > 0)
		{
			try
			{
				string text = this.listViewBallID.SelectedItems[0].Text;
				XmlNode oldChild = CalendarEx.xmlDocument_0.SelectSingleNode("//Balls/Ball[@Name=\"" + text + "\"]");
				CalendarEx.xmlDocument_0.SelectSingleNode("/*").RemoveChild(oldChild);
				CalendarEx.dictionary_1.Remove(text);
				this.listViewBallID.SelectedItems[0].Remove();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
				break;
			}
		}
		Class159.Class220_0.method_1("Item", "Balls", CalendarEx.xmlDocument_0.OuterXml);
	}

	// Token: 0x06001B13 RID: 6931 RVA: 0x000CDDA8 File Offset: 0x000CBFA8
	private void deleteBallMem_Click(object sender, EventArgs e)
	{
		try
		{
			while (this.listViewBallMem.SelectedItems.Count > 0)
			{
				string text = this.listViewBallID.SelectedItems[0].Text;
				XmlNode xmlNode = CalendarEx.xmlDocument_0.SelectSingleNode("//Balls/Ball[@Name=\"" + text + "\"]");
				XmlNode xmlNode2 = xmlNode.Attributes["Member"];
				string value = xmlNode.Attributes["Member"].Value;
				object tag = this.listViewBallMem.SelectedItems[0].Tag;
				xmlNode2.Value = value.Replace(((tag != null) ? tag.ToString() : null) + "-" + this.listViewBallMem.SelectedItems[0].Text, "").Trim(new char[]
				{
					';'
				});
				CalendarEx.dictionary_1[text] = xmlNode.Attributes["Member"].Value;
				this.listViewBallID.SelectedItems[0].Tag = xmlNode.Attributes["Member"].Value;
				this.listViewBallMem.SelectedItems[0].Remove();
			}
			Class159.Class220_0.method_1("Item", "Balls", CalendarEx.xmlDocument_0.OuterXml);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + ex.StackTrace);
		}
	}

	// Token: 0x06001B14 RID: 6932 RVA: 0x000CDF40 File Offset: 0x000CC140
	private void lvTyVoId_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.lvTyVoMem.Items.Clear();
		if (this.lvTyVoId.SelectedItems.Count > 0)
		{
			foreach (string text in Class426.smethod_46(this.lvTyVoId.SelectedItems[0].Tag as string, "[", "]"))
			{
				ListViewItem listViewItem = new ListViewItem(text);
				listViewItem.Tag = text;
				this.lvTyVoMem.Items.Add(listViewItem);
			}
		}
	}

	// Token: 0x06001B15 RID: 6933 RVA: 0x000CDFF4 File Offset: 0x000CC1F4
	private void toolStripMenuItem1_Click(object sender, EventArgs e)
	{
		while (this.lvTyVoId.SelectedItems.Count > 0)
		{
			try
			{
				string text = this.lvTyVoId.SelectedItems[0].Text;
				XmlNode oldChild = CalendarEx.xmlDocument_1.SelectSingleNode("//TyVos/TyVo[@Name=\"" + text + "\"]");
				CalendarEx.xmlDocument_1.SelectSingleNode("/*").RemoveChild(oldChild);
				CalendarEx.dictionary_2.Remove(text);
				this.lvTyVoId.SelectedItems[0].Remove();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
				break;
			}
		}
		Class159.Class220_0.method_1("Item", "TyVos", CalendarEx.xmlDocument_1.OuterXml);
	}

	// Token: 0x06001B16 RID: 6934 RVA: 0x000CE0D4 File Offset: 0x000CC2D4
	private void toolStripMenuItem2_Click(object sender, EventArgs e)
	{
		while (this.lvQuanDoan.SelectedItems.Count > 0)
		{
			try
			{
				string text = this.lvQuanDoan.SelectedItems[0].Text;
				XmlNode oldChild = CalendarEx.xmlDocument_2.SelectSingleNode("//QuanDoans/QuanDoan[@Name=\"" + text + "\"]");
				CalendarEx.xmlDocument_2.SelectSingleNode("/*").RemoveChild(oldChild);
				CalendarEx.dictionary_3.Remove(text);
				this.lvQuanDoan.SelectedItems[0].Remove();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
				break;
			}
		}
		Class159.Class220_0.method_1("Item", "QuanDoan", CalendarEx.xmlDocument_2.OuterXml);
	}

	// Token: 0x06001B17 RID: 6935 RVA: 0x000CE1B4 File Offset: 0x000CC3B4
	private void lvQuanDoan_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.lvQuanDoanMem.Items.Clear();
		if (this.lvQuanDoan.SelectedItems.Count > 0)
		{
			foreach (string text in Class426.smethod_46(this.lvQuanDoan.SelectedItems[0].Tag as string, "[", "]"))
			{
				ListViewItem listViewItem = new ListViewItem(text);
				listViewItem.Tag = text;
				this.lvQuanDoanMem.Items.Add(listViewItem);
			}
		}
	}

	// Token: 0x06001B18 RID: 6936 RVA: 0x000CE268 File Offset: 0x000CC468
	private void lvQuanDoanMem_DragDrop(object sender, DragEventArgs e)
	{
		try
		{
			string b = "";
			if (CalendarEx.xmlDocument_2.SelectSingleNode("QuanDoans").SelectNodes("QuanDoan") != null)
			{
				foreach (object obj in CalendarEx.xmlDocument_2.SelectSingleNode("QuanDoans").SelectNodes("QuanDoan"))
				{
					XmlElement xmlElement = (XmlElement)obj;
					if (xmlElement.Attributes["Name"] != null)
					{
						string value = xmlElement.Attributes["Name"].Value;
						if (value == this.lvQuanDoan.SelectedItems[0].Text)
						{
							b = value;
							string text = "";
							foreach (object obj2 in this.lvQuanDoanMem.Items)
							{
								ListViewItem listViewItem = (ListViewItem)obj2;
								text = text + "[" + listViewItem.Text + "]";
							}
							xmlElement.Attributes["Member"].Value = text;
						}
					}
				}
			}
			Class159.Class220_0.method_1("Item", "QuanDoan", CalendarEx.xmlDocument_2.OuterXml);
			CalendarEx.smethod_0();
			this.lvQuanDoan.Items.Clear();
			this.lvQuanDoanMem.Items.Clear();
			foreach (KeyValuePair<string, string> keyValuePair in CalendarEx.dictionary_3)
			{
				ListViewItem listViewItem2 = new ListViewItem(keyValuePair.Key);
				listViewItem2.Tag = keyValuePair.Value;
				this.lvQuanDoan.Items.Add(listViewItem2);
			}
			foreach (object obj3 in this.lvQuanDoan.Items)
			{
				ListViewItem listViewItem3 = (ListViewItem)obj3;
				if (listViewItem3.Text == b)
				{
					listViewItem3.Selected = true;
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001B19 RID: 6937 RVA: 0x000CE52C File Offset: 0x000CC72C
	private void cboPlayer_DropDown(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		ComboBox.ObjectCollection items = this.cboPlayer.Items;
		object[] items2 = Main.Main_0.IEnumerable_5.Select(new Func<Class159, string>(CalendarEx.Class241.<>9.method_0)).ToArray<string>();
		items.AddRange(items2);
	}

	// Token: 0x06001B1A RID: 6938 RVA: 0x00002E18 File Offset: 0x00001018
	private void button1_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B1B RID: 6939 RVA: 0x00002E18 File Offset: 0x00001018
	private void listViewTeamMem_DoubleClick(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B1C RID: 6940 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B1D RID: 6941 RVA: 0x00002E18 File Offset: 0x00001018
	private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B1E RID: 6942 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_2(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B1F RID: 6943 RVA: 0x000139E6 File Offset: 0x00011BE6
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001B20 RID: 6944 RVA: 0x000CE590 File Offset: 0x000CC790
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(CalendarEx));
		this.menuDelete = new ContextMenuStrip(this.icontainer_0);
		this.deleteToolStripMenuItem = new ToolStripMenuItem();
		this.listViewTeamMem = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.btnAddTeam = new Button();
		this.listViewBallMem = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.menuDeleteTeam = new ContextMenuStrip(this.icontainer_0);
		this.deleteBallMem = new ToolStripMenuItem();
		this.listViewBallID = new ListViewEx();
		this.columnHeader_2 = new ColumnHeader();
		this.menuDeleteTeam_1 = new ContextMenuStrip(this.icontainer_0);
		this.deleteBall = new ToolStripMenuItem();
		this.btnAllBallName = new Button();
		this.txtTeam = new Class85();
		this.txtBallName = new Class85();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.splitContainer1 = new SplitContainer();
		this.lvTeamName = new ListViewEx();
		this.columnHeader_7 = new ColumnHeader();
		this.cboPlayer = new ComboBox();
		this.button1 = new Button();
		this.tabPage2 = new TabPage();
		this.splitContainer2 = new SplitContainer();
		this.tabPage3 = new TabPage();
		this.splitContainer3 = new SplitContainer();
		this.lvTyVoId = new ListViewEx();
		this.columnHeader_3 = new ColumnHeader();
		this.menuDeleteTeam_2 = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem1 = new ToolStripMenuItem();
		this.lvTyVoMem = new ListViewEx();
		this.columnHeader_4 = new ColumnHeader();
		this.tabPage4 = new TabPage();
		this.splitContainer4 = new SplitContainer();
		this.lvQuanDoan = new ListViewEx();
		this.columnHeader_5 = new ColumnHeader();
		this.menuDeleteTeam_3 = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem2 = new ToolStripMenuItem();
		this.lvQuanDoanMem = new ListViewEx();
		this.columnHeader_6 = new ColumnHeader();
		this.menuDelete.SuspendLayout();
		this.menuDeleteTeam.SuspendLayout();
		this.menuDeleteTeam_1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabPage2.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.tabPage3.SuspendLayout();
		this.splitContainer3.Panel1.SuspendLayout();
		this.splitContainer3.Panel2.SuspendLayout();
		this.splitContainer3.SuspendLayout();
		this.menuDeleteTeam_2.SuspendLayout();
		this.tabPage4.SuspendLayout();
		this.splitContainer4.Panel1.SuspendLayout();
		this.splitContainer4.Panel2.SuspendLayout();
		this.splitContainer4.SuspendLayout();
		this.menuDeleteTeam_3.SuspendLayout();
		base.SuspendLayout();
		this.menuDelete.Items.AddRange(new ToolStripItem[]
		{
			this.deleteToolStripMenuItem
		});
		this.menuDelete.Name = "menuDelete";
		this.menuDelete.Size = new Size(108, 26);
		this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
		this.deleteToolStripMenuItem.Size = new Size(107, 22);
		this.deleteToolStripMenuItem.Text = "Delete";
		this.deleteToolStripMenuItem.Click += this.deleteToolStripMenuItem_Click;
		this.listViewTeamMem.AllowColumnReorder = true;
		this.listViewTeamMem.AllowDrop = true;
		this.listViewTeamMem.AllowReorder = true;
		this.listViewTeamMem.AllowSort = false;
		this.listViewTeamMem.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewTeamMem.ContextMenuStrip = this.menuDelete;
		this.listViewTeamMem.Dock = DockStyle.Fill;
		this.listViewTeamMem.DoubleClickActivation = false;
		this.listViewTeamMem.FullRowSelect = true;
		this.listViewTeamMem.GridLines = true;
		this.listViewTeamMem.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewTeamMem.hideItems");
		this.listViewTeamMem.HideSelection = false;
		this.listViewTeamMem.LineColor = Color.Red;
		this.listViewTeamMem.Location = new Point(0, 0);
		this.listViewTeamMem.Name = "listViewTeamMem";
		this.listViewTeamMem.Size = new Size(264, 297);
		this.listViewTeamMem.TabIndex = 1;
		this.listViewTeamMem.UseCompatibleStateImageBehavior = false;
		this.listViewTeamMem.View = View.Details;
		this.listViewTeamMem.DoubleClick += this.listViewTeamMem_DoubleClick;
		this.columnHeader_0.Text = "Member";
		this.columnHeader_0.Width = 160;
		this.btnAddTeam.Dock = DockStyle.Bottom;
		this.btnAddTeam.Location = new Point(0, 318);
		this.btnAddTeam.Name = "btnAddTeam";
		this.btnAddTeam.Size = new Size(257, 23);
		this.btnAddTeam.TabIndex = 4;
		this.btnAddTeam.Text = "Add";
		this.btnAddTeam.UseVisualStyleBackColor = true;
		this.btnAddTeam.Click += this.btnAddTeam_Click;
		this.listViewBallMem.AllowColumnReorder = true;
		this.listViewBallMem.AllowDrop = true;
		this.listViewBallMem.AllowReorder = true;
		this.listViewBallMem.AllowSort = false;
		this.listViewBallMem.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1
		});
		this.listViewBallMem.ContextMenuStrip = this.menuDeleteTeam;
		this.listViewBallMem.Dock = DockStyle.Fill;
		this.listViewBallMem.DoubleClickActivation = false;
		this.listViewBallMem.FullRowSelect = true;
		this.listViewBallMem.GridLines = true;
		this.listViewBallMem.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewBallMem.hideItems");
		this.listViewBallMem.HideSelection = false;
		this.listViewBallMem.LineColor = Color.Red;
		this.listViewBallMem.Location = new Point(0, 0);
		this.listViewBallMem.Name = "listViewBallMem";
		this.listViewBallMem.Size = new Size(263, 341);
		this.listViewBallMem.TabIndex = 9;
		this.listViewBallMem.UseCompatibleStateImageBehavior = false;
		this.listViewBallMem.View = View.Details;
		this.columnHeader_1.Text = "Ball Mem [2]";
		this.columnHeader_1.Width = 160;
		this.menuDeleteTeam.Items.AddRange(new ToolStripItem[]
		{
			this.deleteBallMem
		});
		this.menuDeleteTeam.Name = "menuDeleteTeam";
		this.menuDeleteTeam.Size = new Size(108, 26);
		this.deleteBallMem.Name = "deleteBallMem";
		this.deleteBallMem.Size = new Size(107, 22);
		this.deleteBallMem.Text = "Delete";
		this.deleteBallMem.Click += this.deleteBallMem_Click;
		this.listViewBallID.AllowColumnReorder = true;
		this.listViewBallID.AllowDrop = true;
		this.listViewBallID.AllowReorder = true;
		this.listViewBallID.AllowSort = false;
		this.listViewBallID.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_2
		});
		this.listViewBallID.ContextMenuStrip = this.menuDeleteTeam_1;
		this.listViewBallID.Dock = DockStyle.Fill;
		this.listViewBallID.DoubleClickActivation = false;
		this.listViewBallID.FullRowSelect = true;
		this.listViewBallID.GridLines = true;
		this.listViewBallID.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewBallID.hideItems");
		this.listViewBallID.HideSelection = false;
		this.listViewBallID.LineColor = Color.Red;
		this.listViewBallID.Location = new Point(0, 0);
		this.listViewBallID.Name = "listViewBallID";
		this.listViewBallID.Size = new Size(258, 298);
		this.listViewBallID.TabIndex = 8;
		this.listViewBallID.UseCompatibleStateImageBehavior = false;
		this.listViewBallID.View = View.Details;
		this.listViewBallID.SelectedIndexChanged += this.listViewBallID_SelectedIndexChanged;
		this.columnHeader_2.Text = "Ball ID";
		this.columnHeader_2.Width = 160;
		this.menuDeleteTeam_1.Items.AddRange(new ToolStripItem[]
		{
			this.deleteBall
		});
		this.menuDeleteTeam_1.Name = "menuDeleteTeam";
		this.menuDeleteTeam_1.Size = new Size(108, 26);
		this.deleteBall.Name = "deleteBall";
		this.deleteBall.Size = new Size(107, 22);
		this.deleteBall.Text = "Delete";
		this.deleteBall.Click += this.deleteBall_Click;
		this.btnAllBallName.Dock = DockStyle.Bottom;
		this.btnAllBallName.Location = new Point(0, 318);
		this.btnAllBallName.Name = "btnAllBallName";
		this.btnAllBallName.Size = new Size(258, 23);
		this.btnAllBallName.TabIndex = 11;
		this.btnAllBallName.Text = "Add";
		this.btnAllBallName.UseVisualStyleBackColor = true;
		this.btnAllBallName.Click += this.btnAllBallName_Click;
		this.txtTeam.Dock = DockStyle.Bottom;
		this.txtTeam.Location = new Point(0, 298);
		this.txtTeam.Name = "txtTeam";
		this.txtTeam.Size = new Size(257, 20);
		this.txtTeam.TabIndex = 13;
		this.txtTeam.String_0 = "Tên Nhóm";
		this.txtTeam.Color_0 = Color.Gray;
		this.txtTeam.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtTeam.Color_1 = Color.LightGray;
		this.txtBallName.Dock = DockStyle.Bottom;
		this.txtBallName.Location = new Point(0, 298);
		this.txtBallName.Name = "txtBallName";
		this.txtBallName.Size = new Size(258, 20);
		this.txtBallName.TabIndex = 14;
		this.txtBallName.String_0 = "Tên Nhóm Kết Bái Nhận Bóng";
		this.txtBallName.Color_0 = Color.Gray;
		this.txtBallName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtBallName.Color_1 = Color.LightGray;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Controls.Add(this.tabPage3);
		this.tabControlEx1.Controls.Add(this.tabPage4);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(539, 373);
		this.tabControlEx1.TabIndex = 16;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(531, 347);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Đội Ngũ";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.lvTeamName);
		this.splitContainer1.Panel1.Controls.Add(this.txtTeam);
		this.splitContainer1.Panel1.Controls.Add(this.btnAddTeam);
		this.splitContainer1.Panel2.Controls.Add(this.listViewTeamMem);
		this.splitContainer1.Panel2.Controls.Add(this.cboPlayer);
		this.splitContainer1.Panel2.Controls.Add(this.button1);
		this.splitContainer1.Size = new Size(525, 341);
		this.splitContainer1.SplitterDistance = 257;
		this.splitContainer1.TabIndex = 0;
		this.lvTeamName.AllowColumnReorder = true;
		this.lvTeamName.AllowDrop = true;
		this.lvTeamName.AllowReorder = true;
		this.lvTeamName.AllowSort = false;
		this.lvTeamName.CheckBoxes = true;
		this.lvTeamName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_7
		});
		this.lvTeamName.ContextMenuStrip = this.menuDelete;
		this.lvTeamName.Dock = DockStyle.Fill;
		this.lvTeamName.DoubleClickActivation = false;
		this.lvTeamName.FullRowSelect = true;
		this.lvTeamName.GridLines = true;
		this.lvTeamName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvTeamName.hideItems");
		this.lvTeamName.HideSelection = false;
		this.lvTeamName.LineColor = Color.Red;
		this.lvTeamName.Location = new Point(0, 0);
		this.lvTeamName.Name = "lvTeamName";
		this.lvTeamName.Size = new Size(257, 298);
		this.lvTeamName.TabIndex = 14;
		this.lvTeamName.UseCompatibleStateImageBehavior = false;
		this.lvTeamName.View = View.Details;
		this.lvTeamName.VirtualMode = true;
		this.columnHeader_7.Text = "Member";
		this.columnHeader_7.Width = 160;
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Location = new Point(0, 297);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(264, 21);
		this.cboPlayer.TabIndex = 15;
		this.cboPlayer.DropDown += this.cboPlayer_DropDown;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 318);
		this.button1.Name = "button1";
		this.button1.Size = new Size(264, 23);
		this.button1.TabIndex = 5;
		this.button1.Text = "Add";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.tabPage2.Controls.Add(this.splitContainer2);
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(531, 347);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Nhận Bóng";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.Location = new Point(3, 3);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Panel1.Controls.Add(this.listViewBallID);
		this.splitContainer2.Panel1.Controls.Add(this.txtBallName);
		this.splitContainer2.Panel1.Controls.Add(this.btnAllBallName);
		this.splitContainer2.Panel2.Controls.Add(this.listViewBallMem);
		this.splitContainer2.Size = new Size(525, 341);
		this.splitContainer2.SplitterDistance = 258;
		this.splitContainer2.TabIndex = 1;
		this.tabPage3.Controls.Add(this.splitContainer3);
		this.tabPage3.Location = new Point(4, 22);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new Padding(3);
		this.tabPage3.Size = new Size(531, 347);
		this.tabPage3.TabIndex = 2;
		this.tabPage3.Text = "Tỷ Võ";
		this.tabPage3.UseVisualStyleBackColor = true;
		this.splitContainer3.Dock = DockStyle.Fill;
		this.splitContainer3.Location = new Point(3, 3);
		this.splitContainer3.Name = "splitContainer3";
		this.splitContainer3.Panel1.Controls.Add(this.lvTyVoId);
		this.splitContainer3.Panel2.Controls.Add(this.lvTyVoMem);
		this.splitContainer3.Size = new Size(525, 341);
		this.splitContainer3.SplitterDistance = 258;
		this.splitContainer3.TabIndex = 2;
		this.lvTyVoId.AllowColumnReorder = true;
		this.lvTyVoId.AllowDrop = true;
		this.lvTyVoId.AllowReorder = true;
		this.lvTyVoId.AllowSort = false;
		this.lvTyVoId.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_3
		});
		this.lvTyVoId.ContextMenuStrip = this.menuDeleteTeam_2;
		this.lvTyVoId.Dock = DockStyle.Fill;
		this.lvTyVoId.DoubleClickActivation = false;
		this.lvTyVoId.FullRowSelect = true;
		this.lvTyVoId.GridLines = true;
		this.lvTyVoId.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvTyVoId.hideItems");
		this.lvTyVoId.HideSelection = false;
		this.lvTyVoId.LineColor = Color.Red;
		this.lvTyVoId.Location = new Point(0, 0);
		this.lvTyVoId.Name = "lvTyVoId";
		this.lvTyVoId.Size = new Size(258, 341);
		this.lvTyVoId.TabIndex = 8;
		this.lvTyVoId.UseCompatibleStateImageBehavior = false;
		this.lvTyVoId.View = View.Details;
		this.lvTyVoId.SelectedIndexChanged += this.lvTyVoId_SelectedIndexChanged;
		this.columnHeader_3.Text = "Tỷ Võ ID";
		this.columnHeader_3.Width = 160;
		this.menuDeleteTeam_2.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem1
		});
		this.menuDeleteTeam_2.Name = "menuDeleteTeam";
		this.menuDeleteTeam_2.Size = new Size(108, 26);
		this.toolStripMenuItem1.Name = "toolStripMenuItem1";
		this.toolStripMenuItem1.Size = new Size(107, 22);
		this.toolStripMenuItem1.Text = "Delete";
		this.toolStripMenuItem1.Click += this.toolStripMenuItem1_Click;
		this.lvTyVoMem.AllowColumnReorder = true;
		this.lvTyVoMem.AllowDrop = true;
		this.lvTyVoMem.AllowReorder = true;
		this.lvTyVoMem.AllowSort = false;
		this.lvTyVoMem.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_4
		});
		this.lvTyVoMem.Dock = DockStyle.Fill;
		this.lvTyVoMem.DoubleClickActivation = false;
		this.lvTyVoMem.FullRowSelect = true;
		this.lvTyVoMem.GridLines = true;
		this.lvTyVoMem.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvTyVoMem.hideItems");
		this.lvTyVoMem.HideSelection = false;
		this.lvTyVoMem.LineColor = Color.Red;
		this.lvTyVoMem.Location = new Point(0, 0);
		this.lvTyVoMem.Name = "lvTyVoMem";
		this.lvTyVoMem.Size = new Size(263, 341);
		this.lvTyVoMem.TabIndex = 9;
		this.lvTyVoMem.UseCompatibleStateImageBehavior = false;
		this.lvTyVoMem.View = View.Details;
		this.columnHeader_4.Text = "Tỷ Võ Mem [3]";
		this.columnHeader_4.Width = 160;
		this.tabPage4.Controls.Add(this.splitContainer4);
		this.tabPage4.Location = new Point(4, 22);
		this.tabPage4.Name = "tabPage4";
		this.tabPage4.Padding = new Padding(3);
		this.tabPage4.Size = new Size(531, 347);
		this.tabPage4.TabIndex = 3;
		this.tabPage4.Text = "Quân Đoàn";
		this.tabPage4.UseVisualStyleBackColor = true;
		this.splitContainer4.Dock = DockStyle.Fill;
		this.splitContainer4.Location = new Point(3, 3);
		this.splitContainer4.Name = "splitContainer4";
		this.splitContainer4.Panel1.Controls.Add(this.lvQuanDoan);
		this.splitContainer4.Panel2.Controls.Add(this.lvQuanDoanMem);
		this.splitContainer4.Size = new Size(525, 341);
		this.splitContainer4.SplitterDistance = 258;
		this.splitContainer4.TabIndex = 3;
		this.lvQuanDoan.AllowColumnReorder = true;
		this.lvQuanDoan.AllowDrop = true;
		this.lvQuanDoan.AllowReorder = true;
		this.lvQuanDoan.AllowSort = false;
		this.lvQuanDoan.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_5
		});
		this.lvQuanDoan.ContextMenuStrip = this.menuDeleteTeam_3;
		this.lvQuanDoan.Dock = DockStyle.Fill;
		this.lvQuanDoan.DoubleClickActivation = false;
		this.lvQuanDoan.FullRowSelect = true;
		this.lvQuanDoan.GridLines = true;
		this.lvQuanDoan.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvQuanDoan.hideItems");
		this.lvQuanDoan.HideSelection = false;
		this.lvQuanDoan.LineColor = Color.Red;
		this.lvQuanDoan.Location = new Point(0, 0);
		this.lvQuanDoan.Name = "lvQuanDoan";
		this.lvQuanDoan.Size = new Size(258, 341);
		this.lvQuanDoan.TabIndex = 8;
		this.lvQuanDoan.UseCompatibleStateImageBehavior = false;
		this.lvQuanDoan.View = View.Details;
		this.lvQuanDoan.SelectedIndexChanged += this.lvQuanDoan_SelectedIndexChanged;
		this.columnHeader_5.Text = "Quân Đoàn ID";
		this.columnHeader_5.Width = 160;
		this.menuDeleteTeam_3.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem2
		});
		this.menuDeleteTeam_3.Name = "menuDeleteTeam";
		this.menuDeleteTeam_3.Size = new Size(108, 26);
		this.toolStripMenuItem2.Name = "toolStripMenuItem2";
		this.toolStripMenuItem2.Size = new Size(107, 22);
		this.toolStripMenuItem2.Text = "Delete";
		this.toolStripMenuItem2.Click += this.toolStripMenuItem2_Click;
		this.lvQuanDoanMem.AllowColumnReorder = true;
		this.lvQuanDoanMem.AllowDrop = true;
		this.lvQuanDoanMem.AllowReorder = true;
		this.lvQuanDoanMem.AllowSort = false;
		this.lvQuanDoanMem.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_6
		});
		this.lvQuanDoanMem.Dock = DockStyle.Fill;
		this.lvQuanDoanMem.DoubleClickActivation = false;
		this.lvQuanDoanMem.FullRowSelect = true;
		this.lvQuanDoanMem.GridLines = true;
		this.lvQuanDoanMem.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvQuanDoanMem.hideItems");
		this.lvQuanDoanMem.HideSelection = false;
		this.lvQuanDoanMem.LineColor = Color.Red;
		this.lvQuanDoanMem.Location = new Point(0, 0);
		this.lvQuanDoanMem.Name = "lvQuanDoanMem";
		this.lvQuanDoanMem.Size = new Size(263, 341);
		this.lvQuanDoanMem.TabIndex = 9;
		this.lvQuanDoanMem.UseCompatibleStateImageBehavior = false;
		this.lvQuanDoanMem.View = View.Details;
		this.lvQuanDoanMem.DragDrop += this.lvQuanDoanMem_DragDrop;
		this.columnHeader_6.Text = "Quân Đoàn Mem";
		this.columnHeader_6.Width = 160;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Name = "CalendarEx";
		base.Size = new Size(539, 373);
		base.Load += this.CalendarEx_Load;
		this.menuDelete.ResumeLayout(false);
		this.menuDeleteTeam.ResumeLayout(false);
		this.menuDeleteTeam_1.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.tabPage2.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel1.PerformLayout();
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.tabPage3.ResumeLayout(false);
		this.splitContainer3.Panel1.ResumeLayout(false);
		this.splitContainer3.Panel2.ResumeLayout(false);
		this.splitContainer3.ResumeLayout(false);
		this.menuDeleteTeam_2.ResumeLayout(false);
		this.tabPage4.ResumeLayout(false);
		this.splitContainer4.Panel1.ResumeLayout(false);
		this.splitContainer4.Panel2.ResumeLayout(false);
		this.splitContainer4.ResumeLayout(false);
		this.menuDeleteTeam_3.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04001106 RID: 4358
	public static XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x04001107 RID: 4359
	public static XmlDocument xmlDocument_1 = new XmlDocument();

	// Token: 0x04001108 RID: 4360
	public static XmlDocument xmlDocument_2 = new XmlDocument();

	// Token: 0x04001109 RID: 4361
	public static List<List<string>> list_0 = new List<List<string>>();

	// Token: 0x0400110A RID: 4362
	[CompilerGenerated]
	private static Dictionary<string, string> dictionary_0;

	// Token: 0x0400110B RID: 4363
	public static Dictionary<string, string> dictionary_1 = new Dictionary<string, string>();

	// Token: 0x0400110C RID: 4364
	public static Dictionary<string, string> dictionary_2 = new Dictionary<string, string>();

	// Token: 0x0400110D RID: 4365
	public static Dictionary<string, string> dictionary_3 = new Dictionary<string, string>();

	// Token: 0x0400110E RID: 4366
	public static bool bool_0 = false;

	// Token: 0x0400110F RID: 4367
	public static bool bool_1 = false;

	// Token: 0x04001110 RID: 4368
	private IContainer icontainer_0;

	// Token: 0x04001111 RID: 4369
	private ListViewEx listViewTeamMem;

	// Token: 0x04001112 RID: 4370
	private ColumnHeader columnHeader_0;

	// Token: 0x04001113 RID: 4371
	private Button btnAddTeam;

	// Token: 0x04001114 RID: 4372
	private ListViewEx listViewBallMem;

	// Token: 0x04001115 RID: 4373
	private ColumnHeader columnHeader_1;

	// Token: 0x04001116 RID: 4374
	private ListViewEx listViewBallID;

	// Token: 0x04001117 RID: 4375
	private ColumnHeader columnHeader_2;

	// Token: 0x04001118 RID: 4376
	private Button btnAllBallName;

	// Token: 0x04001119 RID: 4377
	private ContextMenuStrip menuDeleteTeam_1;

	// Token: 0x0400111A RID: 4378
	private ToolStripMenuItem deleteBall;

	// Token: 0x0400111B RID: 4379
	private ContextMenuStrip menuDeleteTeam;

	// Token: 0x0400111C RID: 4380
	private ToolStripMenuItem deleteBallMem;

	// Token: 0x0400111D RID: 4381
	private Class85 txtTeam;

	// Token: 0x0400111E RID: 4382
	private Class85 txtBallName;

	// Token: 0x0400111F RID: 4383
	private Control1 tabControlEx1;

	// Token: 0x04001120 RID: 4384
	private TabPage tabPage1;

	// Token: 0x04001121 RID: 4385
	private SplitContainer splitContainer1;

	// Token: 0x04001122 RID: 4386
	private TabPage tabPage2;

	// Token: 0x04001123 RID: 4387
	private SplitContainer splitContainer2;

	// Token: 0x04001124 RID: 4388
	private TabPage tabPage3;

	// Token: 0x04001125 RID: 4389
	private SplitContainer splitContainer3;

	// Token: 0x04001126 RID: 4390
	private ListViewEx lvTyVoId;

	// Token: 0x04001127 RID: 4391
	private ColumnHeader columnHeader_3;

	// Token: 0x04001128 RID: 4392
	private ListViewEx lvTyVoMem;

	// Token: 0x04001129 RID: 4393
	private ColumnHeader columnHeader_4;

	// Token: 0x0400112A RID: 4394
	private ContextMenuStrip menuDeleteTeam_2;

	// Token: 0x0400112B RID: 4395
	private ToolStripMenuItem toolStripMenuItem1;

	// Token: 0x0400112C RID: 4396
	private TabPage tabPage4;

	// Token: 0x0400112D RID: 4397
	private SplitContainer splitContainer4;

	// Token: 0x0400112E RID: 4398
	private ListViewEx lvQuanDoan;

	// Token: 0x0400112F RID: 4399
	private ColumnHeader columnHeader_5;

	// Token: 0x04001130 RID: 4400
	private ListViewEx lvQuanDoanMem;

	// Token: 0x04001131 RID: 4401
	private ColumnHeader columnHeader_6;

	// Token: 0x04001132 RID: 4402
	private ContextMenuStrip menuDeleteTeam_3;

	// Token: 0x04001133 RID: 4403
	private ToolStripMenuItem toolStripMenuItem2;

	// Token: 0x04001134 RID: 4404
	private Button button1;

	// Token: 0x04001135 RID: 4405
	private ComboBox cboPlayer;

	// Token: 0x04001136 RID: 4406
	private ContextMenuStrip menuDelete;

	// Token: 0x04001137 RID: 4407
	private ToolStripMenuItem deleteToolStripMenuItem;

	// Token: 0x04001138 RID: 4408
	private ListViewEx lvTeamName;

	// Token: 0x04001139 RID: 4409
	private ColumnHeader columnHeader_7;

	// Token: 0x0200020B RID: 523
	[CompilerGenerated]
	[Serializable]
	private sealed class Class241
	{
		// Token: 0x06001B24 RID: 6948 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_0(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x0400113A RID: 4410
		public static readonly CalendarEx.Class241 <>9 = new CalendarEx.Class241();

		// Token: 0x0400113B RID: 4411
		public static Func<Class159, string> <>9__27_0;
	}
}
