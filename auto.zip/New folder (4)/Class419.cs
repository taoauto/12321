﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x020002F9 RID: 761
internal static class Class419
{
	// Token: 0x06002BCD RID: 11213
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr CreateCompatibleDC(IntPtr intptr_0);

	// Token: 0x06002BCE RID: 11214
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteDC(IntPtr intptr_0);

	// Token: 0x06002BCF RID: 11215
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr CreateCompatibleBitmap(IntPtr intptr_0, int int_10, int int_11);

	// Token: 0x06002BD0 RID: 11216
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr SelectObject(IntPtr intptr_0, IntPtr intptr_1);

	// Token: 0x06002BD1 RID: 11217
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteObject(IntPtr intptr_0);

	// Token: 0x06002BD2 RID: 11218
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool StretchBlt(IntPtr intptr_0, int int_10, int int_11, int int_12, int int_13, IntPtr intptr_1, int int_14, int int_15, int int_16, int int_17, uint uint_1);

	// Token: 0x06002BD3 RID: 11219
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool BitBlt(IntPtr intptr_0, int int_10, int int_11, int int_12, int int_13, IntPtr intptr_1, int int_14, int int_15, uint uint_1);

	// Token: 0x06002BD4 RID: 11220
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern uint GetPixel(IntPtr intptr_0, int int_10, int int_11);

	// Token: 0x06002BD5 RID: 11221
	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern uint SetPixel(IntPtr intptr_0, int int_10, int int_11, uint uint_1);

	// Token: 0x06002BD6 RID: 11222
	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
	public static extern IntPtr SendMessageW(IntPtr intptr_0, uint uint_1, IntPtr intptr_1, IntPtr intptr_2);

	// Token: 0x06002BD7 RID: 11223
	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
	public static extern uint RealGetWindowClassW(IntPtr intptr_0, StringBuilder stringBuilder_0, uint uint_1);

	// Token: 0x04001D1D RID: 7453
	public const uint uint_0 = 13369376U;

	// Token: 0x04001D1E RID: 7454
	public const int int_0 = 4877;

	// Token: 0x04001D1F RID: 7455
	public const int int_1 = 48;

	// Token: 0x04001D20 RID: 7456
	public const int int_2 = 794;

	// Token: 0x04001D21 RID: 7457
	public const int int_3 = 2;

	// Token: 0x04001D22 RID: 7458
	public const int int_4 = 130;

	// Token: 0x04001D23 RID: 7459
	public const int int_5 = 70;

	// Token: 0x04001D24 RID: 7460
	public const int int_6 = 528;

	// Token: 0x04001D25 RID: 7461
	public const int int_7 = 1;

	// Token: 0x04001D26 RID: 7462
	public const int int_8 = 512;

	// Token: 0x04001D27 RID: 7463
	public const int int_9 = 513;

	// Token: 0x020002FA RID: 762
	public struct Struct7
	{
		// Token: 0x04001D28 RID: 7464
		public int int_0;

		// Token: 0x04001D29 RID: 7465
		public int int_1;
	}

	// Token: 0x020002FB RID: 763
	public struct Struct8
	{
		// Token: 0x04001D2A RID: 7466
		public Class419.Struct7 struct7_0;

		// Token: 0x04001D2B RID: 7467
		public uint uint_0;
	}

	// Token: 0x020002FC RID: 764
	public struct Struct9
	{
		// Token: 0x04001D2C RID: 7468
		public IntPtr intptr_0;

		// Token: 0x04001D2D RID: 7469
		public IntPtr intptr_1;

		// Token: 0x04001D2E RID: 7470
		public int int_0;

		// Token: 0x04001D2F RID: 7471
		public int int_1;

		// Token: 0x04001D30 RID: 7472
		public int int_2;

		// Token: 0x04001D31 RID: 7473
		public int int_3;

		// Token: 0x04001D32 RID: 7474
		public int int_4;
	}
}
