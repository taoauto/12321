﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200000B RID: 11
public class GClass5 : Dictionary<string, string>
{
	// Token: 0x17000049 RID: 73
	// (get) Token: 0x06000071 RID: 113 RVA: 0x0000350F File Offset: 0x0000170F
	// (set) Token: 0x06000072 RID: 114 RVA: 0x00003517 File Offset: 0x00001717
	public bool Boolean_0 { get; set; }

	// Token: 0x06000073 RID: 115 RVA: 0x00003520 File Offset: 0x00001720
	public GClass5(bool bool_1 = false) : base(StringComparer.OrdinalIgnoreCase)
	{
		this.Boolean_0 = bool_1;
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00022424 File Offset: 0x00020624
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, string> keyValuePair in this)
		{
			stringBuilder.AppendFormat("{0}={1}; ", keyValuePair.Key, keyValuePair.Value);
		}
		if (stringBuilder.Length > 0)
		{
			stringBuilder.Remove(stringBuilder.Length - 2, 2);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x04000009 RID: 9
	[CompilerGenerated]
	private bool bool_0;
}
