﻿using System;

// Token: 0x02000156 RID: 342
internal class Class137 : Interface0
{
	// Token: 0x17000428 RID: 1064
	// (get) Token: 0x06001048 RID: 4168 RVA: 0x0000D4B2 File Offset: 0x0000B6B2
	public string String_0
	{
		get
		{
			return "HTTP/FTP";
		}
	}

	// Token: 0x17000429 RID: 1065
	// (get) Token: 0x06001049 RID: 4169 RVA: 0x0000D4B9 File Offset: 0x0000B6B9
	public Interface3 Interface3_0
	{
		get
		{
			return new Class139();
		}
	}

	// Token: 0x0600104A RID: 4170 RVA: 0x0000D4C0 File Offset: 0x0000B6C0
	public Class137() : this(new Class138())
	{
	}

	// Token: 0x0600104B RID: 4171 RVA: 0x0005B210 File Offset: 0x00059410
	public Class137(Interface7 interface7_1)
	{
		if (interface7_1 == null)
		{
			throw new ArgumentNullException("parameters");
		}
		if (Class137.interface7_0 != null)
		{
			throw new InvalidOperationException("The type HttpFtpProtocolExtension is already initialized.");
		}
		Class137.interface7_0 = interface7_1;
		Class133.smethod_0("http", typeof(Class136));
		Class133.smethod_0("https", typeof(Class136));
		Class133.smethod_0("ftp", typeof(Class135));
	}

	// Token: 0x0400084F RID: 2127
	internal static Interface7 interface7_0;
}
