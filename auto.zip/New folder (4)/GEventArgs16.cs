﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000F2 RID: 242
public class GEventArgs16 : EventArgs
{
	// Token: 0x06000CB8 RID: 3256 RVA: 0x0000B2A8 File Offset: 0x000094A8
	public GEventArgs16(GClass78 gclass78_1)
	{
		this.GClass78_0 = gclass78_1;
	}

	// Token: 0x17000363 RID: 867
	// (get) Token: 0x06000CB9 RID: 3257 RVA: 0x0000B2B7 File Offset: 0x000094B7
	// (set) Token: 0x06000CBA RID: 3258 RVA: 0x0000B2BF File Offset: 0x000094BF
	public GClass78 GClass78_0 { get; private set; }

	// Token: 0x040005E6 RID: 1510
	[CompilerGenerated]
	private GClass78 gclass78_0;
}
