﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Configuration;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Web;
using System.Windows.Forms;

// Token: 0x020002EE RID: 750
internal class Class412
{
	// Token: 0x170009A9 RID: 2473
	// (get) Token: 0x06002AD5 RID: 10965 RVA: 0x0001F2F7 File Offset: 0x0001D4F7
	// (set) Token: 0x06002AD6 RID: 10966 RVA: 0x0001F2FE File Offset: 0x0001D4FE
	public static int Int32_0 { get; set; } = 0;

	// Token: 0x170009AA RID: 2474
	// (get) Token: 0x06002AD7 RID: 10967 RVA: 0x0001F306 File Offset: 0x0001D506
	// (set) Token: 0x06002AD8 RID: 10968 RVA: 0x0001F30D File Offset: 0x0001D50D
	public static int Int32_1 { get; set; } = int.MaxValue;

	// Token: 0x170009AB RID: 2475
	// (get) Token: 0x06002AD9 RID: 10969 RVA: 0x0001F315 File Offset: 0x0001D515
	// (set) Token: 0x06002ADA RID: 10970 RVA: 0x0001F31D File Offset: 0x0001D51D
	public int Int32_2 { get; set; } = 1;

	// Token: 0x170009AC RID: 2476
	// (get) Token: 0x06002ADB RID: 10971 RVA: 0x0001F326 File Offset: 0x0001D526
	// (set) Token: 0x06002ADC RID: 10972 RVA: 0x0001F32E File Offset: 0x0001D52E
	public object Object_0 { get; set; }

	// Token: 0x06002ADD RID: 10973 RVA: 0x00122A94 File Offset: 0x00120C94
	public static string smethod_0(string string_12, string string_13 = null, string string_14 = null, bool bool_5 = false)
	{
		string result;
		for (;;)
		{
			try
			{
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_12);
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.AllowAutoRedirect = false;
				httpWebRequest.Method = "POST";
				httpWebRequest.UserAgent = Class412.string_11;
				httpWebRequest.Headers.Add("api-key: zMXF92H7U8t6ldgTWbjmSXAkGwdwxiA8");
				httpWebRequest.Headers.Add("speed: -1");
				httpWebRequest.Headers.Add("voice: lannhi");
				httpWebRequest.Headers.Add("Accept-Encoding: *");
				httpWebRequest.Accept = "*/*";
				httpWebRequest.Connection = "keepalive";
				httpWebRequest.Referer = "https://www.facebook.com/";
				httpWebRequest.Headers.Add("Cookie: " + string_14);
				httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
				httpWebRequest.Proxy = null;
				httpWebRequest.ContentType = "application/x-www-form-urlencoded";
				if (string_13 != null)
				{
					StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream());
					streamWriter.Write(string_13);
					streamWriter.Close();
				}
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
				string text = streamReader.ReadToEnd();
				streamReader.Close();
				httpWebResponse.Close();
				result = text;
			}
			catch (Exception ex)
			{
				if (bool_5)
				{
					continue;
				}
				result = ex.Message;
			}
			break;
		}
		return result;
	}

	// Token: 0x06002ADE RID: 10974 RVA: 0x00122BDC File Offset: 0x00120DDC
	public static string smethod_1(string string_12, string string_13 = null, bool bool_5 = false)
	{
		string result;
		for (;;)
		{
			try
			{
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_12);
				if (string_13 != null)
				{
					httpWebRequest.Headers.Add("Cookie: " + string_13);
				}
				httpWebRequest.Method = "GET";
				httpWebRequest.AllowAutoRedirect = false;
				httpWebRequest.UserAgent = Class412.string_11;
				httpWebRequest.Headers.Add("Accept-Encoding: *");
				httpWebRequest.Connection = "keepalive";
				httpWebRequest.Proxy = null;
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				for (int i = 0; i < httpWebResponse.Headers.Count; i++)
				{
					if (httpWebResponse.Headers.Keys[i] == "Location")
					{
						httpWebResponse.Close();
						return httpWebResponse.Headers[i];
					}
				}
				StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
				string text = streamReader.ReadToEnd();
				streamReader.Close();
				httpWebResponse.Close();
				result = text;
			}
			catch (Exception ex)
			{
				if (bool_5)
				{
					continue;
				}
				result = ex.Message;
			}
			break;
		}
		return result;
	}

	// Token: 0x06002ADF RID: 10975 RVA: 0x00122D00 File Offset: 0x00120F00
	public static Bitmap smethod_2(string string_12, string string_13 = null)
	{
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_12);
		if (string_13 != null)
		{
			httpWebRequest.Headers.Add("Cookie: " + string_13);
		}
		httpWebRequest.Method = "GET";
		httpWebRequest.AllowAutoRedirect = false;
		httpWebRequest.UserAgent = Class412.string_11;
		httpWebRequest.Headers.Add("Accept-Encoding: *");
		httpWebRequest.Connection = "keepalive";
		httpWebRequest.Proxy = null;
		httpWebRequest.ServicePoint.Expect100Continue = false;
		httpWebRequest.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
		return new Bitmap(Image.FromStream(((HttpWebResponse)httpWebRequest.GetResponse()).GetResponseStream()));
	}

	// Token: 0x170009AD RID: 2477
	// (get) Token: 0x06002AE0 RID: 10976 RVA: 0x0001F337 File Offset: 0x0001D537
	// (set) Token: 0x06002AE1 RID: 10977 RVA: 0x0001F33F File Offset: 0x0001D53F
	public string String_0 { get; set; } = string.Empty;

	// Token: 0x06002AE2 RID: 10978 RVA: 0x0001F348 File Offset: 0x0001D548
	public void method_0()
	{
		this.method_1();
		new Thread(new ThreadStart(this.method_6))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x170009AE RID: 2478
	// (get) Token: 0x06002AE3 RID: 10979 RVA: 0x0001F36D File Offset: 0x0001D56D
	// (set) Token: 0x06002AE4 RID: 10980 RVA: 0x0001F375 File Offset: 0x0001D575
	public Stream Stream_0 { get; set; }

	// Token: 0x170009AF RID: 2479
	// (get) Token: 0x06002AE5 RID: 10981 RVA: 0x0001F37E File Offset: 0x0001D57E
	// (set) Token: 0x06002AE6 RID: 10982 RVA: 0x0001F386 File Offset: 0x0001D586
	public bool Boolean_0 { get; set; }

	// Token: 0x06002AE7 RID: 10983 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1()
	{
	}

	// Token: 0x06002AE8 RID: 10984 RVA: 0x0001F38F File Offset: 0x0001D58F
	public void method_2()
	{
		this.method_1();
		new Thread(new ThreadStart(this.method_8))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06002AE9 RID: 10985 RVA: 0x00122DA0 File Offset: 0x00120FA0
	public void method_3()
	{
		try
		{
			this.httpWebRequest_0.Abort();
		}
		catch
		{
		}
	}

	// Token: 0x170009B0 RID: 2480
	// (get) Token: 0x06002AEA RID: 10986 RVA: 0x0001F3B4 File Offset: 0x0001D5B4
	// (set) Token: 0x06002AEB RID: 10987 RVA: 0x0001F3BC File Offset: 0x0001D5BC
	public string String_1 { get; set; } = string.Empty;

	// Token: 0x14000056 RID: 86
	// (add) Token: 0x06002AEC RID: 10988 RVA: 0x00122DD0 File Offset: 0x00120FD0
	// (remove) Token: 0x06002AED RID: 10989 RVA: 0x00122E08 File Offset: 0x00121008
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x170009B1 RID: 2481
	// (get) Token: 0x06002AEE RID: 10990 RVA: 0x0001F3C5 File Offset: 0x0001D5C5
	// (set) Token: 0x06002AEF RID: 10991 RVA: 0x0001F3CD File Offset: 0x0001D5CD
	public bool Boolean_1 { get; set; }

	// Token: 0x170009B2 RID: 2482
	// (get) Token: 0x06002AF0 RID: 10992 RVA: 0x0001F3D6 File Offset: 0x0001D5D6
	public bool Boolean_2
	{
		get
		{
			return this.string_5 != string.Empty;
		}
	}

	// Token: 0x170009B3 RID: 2483
	// (get) Token: 0x06002AF1 RID: 10993 RVA: 0x0001F3E8 File Offset: 0x0001D5E8
	// (set) Token: 0x06002AF2 RID: 10994 RVA: 0x0001F3FF File Offset: 0x0001D5FF
	public string String_2
	{
		get
		{
			if (this.Boolean_2)
			{
				return this.string_5;
			}
			return this.string_4;
		}
		set
		{
			this.string_4 = value;
		}
	}

	// Token: 0x06002AF3 RID: 10995 RVA: 0x00122E40 File Offset: 0x00121040
	private HttpWebRequest method_4(string string_12, CookieContainer cookieContainer_1)
	{
		this.httpWebRequest_0 = (HttpWebRequest)WebRequest.Create(string_12);
		this.httpWebRequest_0.CookieContainer = cookieContainer_1;
		this.httpWebRequest_0.Method = "GET";
		this.httpWebRequest_0.UserAgent = Class412.string_11;
		this.httpWebRequest_0.Headers.Add("Accept-Encoding: *");
		this.httpWebRequest_0.Connection = "keepalive";
		this.httpWebRequest_0.Proxy = null;
		this.httpWebRequest_0.ServicePoint.Expect100Continue = false;
		this.httpWebRequest_0.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
		return this.httpWebRequest_0;
	}

	// Token: 0x06002AF4 RID: 10996 RVA: 0x00122EE0 File Offset: 0x001210E0
	private HttpWebRequest method_5(string string_12, string string_13, CookieContainer cookieContainer_1, string string_14)
	{
		this.httpWebRequest_0 = (HttpWebRequest)WebRequest.Create(string_12);
		try
		{
			this.httpWebRequest_0.Referer = string_14;
		}
		catch
		{
		}
		this.httpWebRequest_0.ServicePoint.Expect100Continue = false;
		this.httpWebRequest_0.AllowAutoRedirect = true;
		this.httpWebRequest_0.CookieContainer = cookieContainer_1;
		this.httpWebRequest_0.Method = "POST";
		this.httpWebRequest_0.UserAgent = Class412.string_11;
		this.httpWebRequest_0.Headers.Add("Accept-Encoding: *");
		this.httpWebRequest_0.Accept = "*/*";
		this.httpWebRequest_0.Connection = "keepalive";
		this.httpWebRequest_0.AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate);
		this.httpWebRequest_0.Proxy = null;
		this.httpWebRequest_0.ContentType = "application/x-www-form-urlencoded";
		StreamWriter streamWriter = new StreamWriter(this.httpWebRequest_0.GetRequestStream());
		streamWriter.Write(string_13);
		streamWriter.Close();
		return this.httpWebRequest_0;
	}

	// Token: 0x170009B4 RID: 2484
	// (get) Token: 0x06002AF5 RID: 10997 RVA: 0x0001F408 File Offset: 0x0001D608
	// (set) Token: 0x06002AF6 RID: 10998 RVA: 0x0001F410 File Offset: 0x0001D610
	public bool Boolean_3 { get; set; }

	// Token: 0x170009B5 RID: 2485
	// (get) Token: 0x06002AF7 RID: 10999 RVA: 0x0001F419 File Offset: 0x0001D619
	// (set) Token: 0x06002AF8 RID: 11000 RVA: 0x0001F421 File Offset: 0x0001D621
	public bool Boolean_4 { get; set; }

	// Token: 0x06002AF9 RID: 11001 RVA: 0x00122FE8 File Offset: 0x001211E8
	private void method_6()
	{
		Thread.Sleep(this.Int32_2);
		while (Class412.Int32_0 >= Class412.Int32_1)
		{
			Thread.Sleep(1000);
		}
		Class412.Int32_0++;
		if (this.Boolean_4)
		{
			this.string_1 = string.Concat(new string[]
			{
				this.string_1,
				"&serial=",
				Class403.String_0,
				"&version=",
				HttpUtility.UrlEncode(Class268.String_0),
				"&li=&md=",
				Class268.String_3,
				"&vip=",
				Class268.Int32_17.ToString(),
				Class412.string_8,
				Class412.string_9
			});
		}
		else if (!this.Boolean_3)
		{
			this.String_0 = string.Concat(new string[]
			{
				this.String_0,
				"&serial=",
				Class403.String_0,
				"&version=",
				HttpUtility.UrlEncode(Class268.String_0),
				"&li=&md=",
				Class268.String_3,
				"&vip=",
				Class268.Int32_17.ToString(),
				Class412.string_8,
				Class412.string_9
			});
		}
		try
		{
			this.method_7();
		}
		catch (Exception ex)
		{
			if (this.Boolean_1)
			{
				for (;;)
				{
					try
					{
						this.method_7();
						if (!this.String_2.Contains("Resource Limit"))
						{
							break;
						}
						this.string_5 = ex.Message;
						Class412.int_3++;
						Class412.string_10 = this.string_1;
						this.method_1();
					}
					catch
					{
						this.string_5 = ex.Message;
						Class412.int_3++;
						Class412.string_10 = this.string_1;
						this.method_1();
					}
				}
			}
			else
			{
				this.string_5 = ex.Message;
				Class412.int_3++;
				Class412.string_10 = this.string_1;
			}
		}
		Class412.Int32_0--;
		this.method_9();
	}

	// Token: 0x06002AFA RID: 11002 RVA: 0x0012320C File Offset: 0x0012140C
	private void method_7()
	{
		HttpWebRequest httpWebRequest_ = this.method_5(this.string_1, this.String_0, this.cookieContainer_0, this.string_3);
		Class412.smethod_7(this, httpWebRequest_);
	}

	// Token: 0x06002AFB RID: 11003 RVA: 0x00123240 File Offset: 0x00121440
	private void method_8()
	{
		Thread.Sleep(this.Int32_2);
		while (Class412.Int32_0 >= Class412.Int32_1)
		{
			Thread.Sleep(1000);
		}
		Class412.Int32_0++;
		try
		{
			HttpWebRequest httpWebRequest_ = this.method_4(this.string_1, this.cookieContainer_0);
			Class412.smethod_7(this, httpWebRequest_);
		}
		catch (Exception ex)
		{
			this.string_5 = ex.Message;
			Class412.int_3++;
			Class412.string_10 = this.string_1;
		}
		Class412.Int32_0--;
		this.method_9();
	}

	// Token: 0x06002AFC RID: 11004 RVA: 0x001232E4 File Offset: 0x001214E4
	private void method_9()
	{
		try
		{
			if (this.control_0 == null || !this.control_0.IsDisposed)
			{
				if (this.eventHandler_0 != null)
				{
					if (this.control_0 != null)
					{
						if (this.control_0.InvokeRequired)
						{
							this.control_0.Invoke(new Class412.Delegate8(this.method_9));
						}
						else
						{
							this.eventHandler_0(this, null);
						}
					}
					else
					{
						this.eventHandler_0(this, null);
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x06002AFD RID: 11005 RVA: 0x00123374 File Offset: 0x00121574
	public static void smethod_3()
	{
		ServicePointManager.DefaultConnectionLimit = int.MaxValue;
		Class412.smethod_5();
		ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback(Class412.smethod_6));
		ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Class412.smethod_4);
	}

	// Token: 0x06002AFE RID: 11006 RVA: 0x001233C4 File Offset: 0x001215C4
	public void method_10(string string_12, string string_13 = "facebook.com")
	{
		foreach (string text in string_12.Split(new char[]
		{
			';'
		}))
		{
			if (text.Split(new char[]
			{
				'='
			}).Length == 2)
			{
				try
				{
					this.cookieContainer_0.Add(new Cookie(HttpUtility.UrlEncode(text.Split(new char[]
					{
						'='
					})[0].Trim()), text.Split(new char[]
					{
						'='
					})[1].Trim(), "/", string_13));
					this.cookieContainer_0.Add(new Cookie(HttpUtility.UrlEncode(text.Split(new char[]
					{
						'='
					})[0].Trim()), text.Split(new char[]
					{
						'='
					})[1].Trim(), "/", "www." + string_13));
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x06002AFF RID: 11007 RVA: 0x0000354C File Offset: 0x0000174C
	public static bool smethod_4(object object_1, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x06002B00 RID: 11008 RVA: 0x0005A790 File Offset: 0x00058990
	public static bool smethod_5()
	{
		Assembly assembly = Assembly.GetAssembly(typeof(SettingsSection));
		if (assembly != null)
		{
			Type type = assembly.GetType("System.Net.Configuration.SettingsSectionInternal");
			if (type != null)
			{
				object obj = type.InvokeMember("Section", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetProperty, null, null, new object[0]);
				if (obj != null)
				{
					FieldInfo field = type.GetField("useUnsafeHeaderParsing", BindingFlags.Instance | BindingFlags.NonPublic);
					if (field != null)
					{
						field.SetValue(obj, true);
						return true;
					}
				}
			}
		}
		return false;
	}

	// Token: 0x06002B01 RID: 11009 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_6(object object_1, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x06002B02 RID: 11010 RVA: 0x001234CC File Offset: 0x001216CC
	private static Class412 smethod_7(Class412 class412_0, HttpWebRequest httpWebRequest_1)
	{
		HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest_1.GetResponse();
		foreach (object obj in httpWebResponse.Cookies)
		{
			Cookie cookie = (Cookie)obj;
			string text = cookie.Domain.TrimStart(new char[]
			{
				'.'
			}).Replace("www.", "");
			class412_0.cookieContainer_0.Add(new Cookie(cookie.Name, cookie.Value, cookie.Path, text));
			class412_0.cookieContainer_0.Add(new Cookie(cookie.Name, cookie.Value, cookie.Path, "www." + text));
			class412_0.string_6 = string.Concat(new string[]
			{
				class412_0.string_6,
				cookie.Name,
				"=",
				cookie.Value,
				";"
			});
		}
		for (int i = 0; i < httpWebResponse.Headers.Count; i++)
		{
			class412_0.string_7 = string.Concat(new string[]
			{
				class412_0.string_7,
				httpWebResponse.Headers.Keys[i],
				": ",
				httpWebResponse.Headers[i],
				"\n"
			});
		}
		class412_0.Stream_0 = httpWebResponse.GetResponseStream();
		StreamReader streamReader = new StreamReader(class412_0.Stream_0);
		if (class412_0.Boolean_5)
		{
			try
			{
				Image original = Image.FromStream(class412_0.Stream_0);
				class412_0.bitmap_0 = new Bitmap(original);
			}
			catch
			{
			}
		}
		class412_0.string_4 = streamReader.ReadToEnd();
		if (!class412_0.Boolean_0)
		{
			streamReader.Close();
		}
		return class412_0;
	}

	// Token: 0x170009B6 RID: 2486
	// (get) Token: 0x06002B03 RID: 11011 RVA: 0x0001F42A File Offset: 0x0001D62A
	// (set) Token: 0x06002B04 RID: 11012 RVA: 0x0001F432 File Offset: 0x0001D632
	public bool Boolean_5 { get; set; }

	// Token: 0x04001C89 RID: 7305
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x04001C8A RID: 7306
	[CompilerGenerated]
	private static int int_1;

	// Token: 0x04001C8B RID: 7307
	[CompilerGenerated]
	private int int_2;

	// Token: 0x04001C8C RID: 7308
	[CompilerGenerated]
	private object object_0;

	// Token: 0x04001C8D RID: 7309
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001C8E RID: 7310
	[CompilerGenerated]
	private Stream stream_0;

	// Token: 0x04001C8F RID: 7311
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04001C90 RID: 7312
	public string string_1 = string.Empty;

	// Token: 0x04001C91 RID: 7313
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04001C92 RID: 7314
	public string string_3 = string.Empty;

	// Token: 0x04001C93 RID: 7315
	public string string_4 = string.Empty;

	// Token: 0x04001C94 RID: 7316
	public string string_5 = string.Empty;

	// Token: 0x04001C95 RID: 7317
	public string string_6 = string.Empty;

	// Token: 0x04001C96 RID: 7318
	public string string_7 = string.Empty;

	// Token: 0x04001C97 RID: 7319
	public Control control_0;

	// Token: 0x04001C98 RID: 7320
	public CookieContainer cookieContainer_0 = new CookieContainer();

	// Token: 0x04001C99 RID: 7321
	public static int int_3;

	// Token: 0x04001C9A RID: 7322
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04001C9B RID: 7323
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04001C9C RID: 7324
	public static string string_8 = "&ispri=" + Class426.smethod_22(false).ToString();

	// Token: 0x04001C9D RID: 7325
	public static string string_9 = "&multed=" + Class426.smethod_22(false).ToString();

	// Token: 0x04001C9E RID: 7326
	private HttpWebRequest httpWebRequest_0;

	// Token: 0x04001C9F RID: 7327
	[CompilerGenerated]
	private bool bool_2;

	// Token: 0x04001CA0 RID: 7328
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x04001CA1 RID: 7329
	public static string string_10 = "";

	// Token: 0x04001CA2 RID: 7330
	private static string string_11 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + new Random().Next(70, 90).ToString() + ".0.4280.141 Safari/537.36";

	// Token: 0x04001CA3 RID: 7331
	public Bitmap bitmap_0;

	// Token: 0x04001CA4 RID: 7332
	[CompilerGenerated]
	private bool bool_4;

	// Token: 0x020002EF RID: 751
	// (Invoke) Token: 0x06002B08 RID: 11016
	private delegate void Delegate8();
}
