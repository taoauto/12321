﻿using System;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

// Token: 0x02000085 RID: 133
public class GClass32
{
	// Token: 0x060005E1 RID: 1505 RVA: 0x00006C3C File Offset: 0x00004E3C
	public GClass32()
	{
		this.sslProtocols_0 = SslProtocols.Default;
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x00006C4F File Offset: 0x00004E4F
	public GClass32(string string_1)
	{
		this.string_0 = string_1;
		this.sslProtocols_0 = SslProtocols.Default;
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x000342E0 File Offset: 0x000324E0
	public GClass32(GClass32 gclass32_0)
	{
		if (gclass32_0 == null)
		{
			throw new ArgumentNullException("configuration");
		}
		this.bool_0 = gclass32_0.bool_0;
		this.localCertificateSelectionCallback_0 = gclass32_0.localCertificateSelectionCallback_0;
		this.x509CertificateCollection_0 = gclass32_0.x509CertificateCollection_0;
		this.sslProtocols_0 = gclass32_0.sslProtocols_0;
		this.remoteCertificateValidationCallback_0 = gclass32_0.remoteCertificateValidationCallback_0;
		this.string_0 = gclass32_0.string_0;
	}

	// Token: 0x1700017E RID: 382
	// (get) Token: 0x060005E4 RID: 1508 RVA: 0x00006C69 File Offset: 0x00004E69
	// (set) Token: 0x060005E5 RID: 1509 RVA: 0x00006C71 File Offset: 0x00004E71
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x1700017F RID: 383
	// (get) Token: 0x060005E6 RID: 1510 RVA: 0x00006C7A File Offset: 0x00004E7A
	// (set) Token: 0x060005E7 RID: 1511 RVA: 0x00006C82 File Offset: 0x00004E82
	public X509CertificateCollection X509CertificateCollection_0
	{
		get
		{
			return this.x509CertificateCollection_0;
		}
		set
		{
			this.x509CertificateCollection_0 = value;
		}
	}

	// Token: 0x17000180 RID: 384
	// (get) Token: 0x060005E8 RID: 1512 RVA: 0x00006C8B File Offset: 0x00004E8B
	// (set) Token: 0x060005E9 RID: 1513 RVA: 0x00006CAD File Offset: 0x00004EAD
	public LocalCertificateSelectionCallback LocalCertificateSelectionCallback_0
	{
		get
		{
			if (this.localCertificateSelectionCallback_0 == null)
			{
				this.localCertificateSelectionCallback_0 = new LocalCertificateSelectionCallback(GClass32.smethod_0);
			}
			return this.localCertificateSelectionCallback_0;
		}
		set
		{
			this.localCertificateSelectionCallback_0 = value;
		}
	}

	// Token: 0x17000181 RID: 385
	// (get) Token: 0x060005EA RID: 1514 RVA: 0x00006CB6 File Offset: 0x00004EB6
	// (set) Token: 0x060005EB RID: 1515 RVA: 0x00006CBE File Offset: 0x00004EBE
	public SslProtocols SslProtocols_0
	{
		get
		{
			return this.sslProtocols_0;
		}
		set
		{
			this.sslProtocols_0 = value;
		}
	}

	// Token: 0x17000182 RID: 386
	// (get) Token: 0x060005EC RID: 1516 RVA: 0x00006CC7 File Offset: 0x00004EC7
	// (set) Token: 0x060005ED RID: 1517 RVA: 0x00006CE9 File Offset: 0x00004EE9
	public RemoteCertificateValidationCallback RemoteCertificateValidationCallback_0
	{
		get
		{
			if (this.remoteCertificateValidationCallback_0 == null)
			{
				this.remoteCertificateValidationCallback_0 = new RemoteCertificateValidationCallback(GClass32.smethod_1);
			}
			return this.remoteCertificateValidationCallback_0;
		}
		set
		{
			this.remoteCertificateValidationCallback_0 = value;
		}
	}

	// Token: 0x17000183 RID: 387
	// (get) Token: 0x060005EE RID: 1518 RVA: 0x00006CF2 File Offset: 0x00004EF2
	// (set) Token: 0x060005EF RID: 1519 RVA: 0x00006CFA File Offset: 0x00004EFA
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
		}
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x00006D03 File Offset: 0x00004F03
	private static X509Certificate smethod_0(object object_0, string string_1, X509CertificateCollection x509CertificateCollection_1, X509Certificate x509Certificate_0, string[] string_2)
	{
		return null;
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_1(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x040002ED RID: 749
	private bool bool_0;

	// Token: 0x040002EE RID: 750
	private LocalCertificateSelectionCallback localCertificateSelectionCallback_0;

	// Token: 0x040002EF RID: 751
	private X509CertificateCollection x509CertificateCollection_0;

	// Token: 0x040002F0 RID: 752
	private SslProtocols sslProtocols_0;

	// Token: 0x040002F1 RID: 753
	private RemoteCertificateValidationCallback remoteCertificateValidationCallback_0;

	// Token: 0x040002F2 RID: 754
	private string string_0;
}
