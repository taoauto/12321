﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000028 RID: 40
public sealed class GEventArgs1 : EventArgs
{
	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x060001ED RID: 493 RVA: 0x00004442 File Offset: 0x00002642
	// (set) Token: 0x060001EE RID: 494 RVA: 0x0000444A File Offset: 0x0000264A
	public long Int64_0 { get; private set; }

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x060001EF RID: 495 RVA: 0x00004453 File Offset: 0x00002653
	// (set) Token: 0x060001F0 RID: 496 RVA: 0x0000445B File Offset: 0x0000265B
	public long Int64_1 { get; private set; }

	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x060001F1 RID: 497 RVA: 0x00004464 File Offset: 0x00002664
	public double Double_0
	{
		get
		{
			return (double)this.Int64_0 / (double)this.Int64_1 * 100.0;
		}
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x0000447F File Offset: 0x0000267F
	public GEventArgs1(long long_2, long long_3)
	{
		this.Int64_0 = long_2;
		this.Int64_1 = long_3;
	}

	// Token: 0x04000123 RID: 291
	[CompilerGenerated]
	private long long_0;

	// Token: 0x04000124 RID: 292
	[CompilerGenerated]
	private long long_1;
}
