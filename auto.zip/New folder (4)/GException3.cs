﻿using System;

// Token: 0x0200005E RID: 94
public class GException3 : Exception
{
	// Token: 0x06000408 RID: 1032 RVA: 0x000058B1 File Offset: 0x00003AB1
	internal GException3() : this(GEnum6.Abnormal, null, null)
	{
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x000058C0 File Offset: 0x00003AC0
	internal GException3(Exception exception_0) : this(GEnum6.Abnormal, null, exception_0)
	{
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x000058CF File Offset: 0x00003ACF
	internal GException3(string string_0) : this(GEnum6.Abnormal, string_0, null)
	{
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x000058DE File Offset: 0x00003ADE
	internal GException3(GEnum6 genum6_1) : this(genum6_1, null, null)
	{
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x000058E9 File Offset: 0x00003AE9
	internal GException3(string string_0, Exception exception_0) : this(GEnum6.Abnormal, string_0, exception_0)
	{
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x000058F8 File Offset: 0x00003AF8
	internal GException3(GEnum6 genum6_1, Exception exception_0) : this(genum6_1, null, exception_0)
	{
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x00005903 File Offset: 0x00003B03
	internal GException3(GEnum6 genum6_1, string string_0) : this(genum6_1, string_0, null)
	{
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0000590E File Offset: 0x00003B0E
	internal GException3(GEnum6 genum6_1, string string_0, Exception exception_0) : base(string_0 ?? genum6_1.smethod_32(), exception_0)
	{
		this.genum6_0 = genum6_1;
	}

	// Token: 0x17000101 RID: 257
	// (get) Token: 0x06000410 RID: 1040 RVA: 0x00005929 File Offset: 0x00003B29
	public GEnum6 GEnum6_0
	{
		get
		{
			return this.genum6_0;
		}
	}

	// Token: 0x0400023B RID: 571
	private GEnum6 genum6_0;
}
