﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x02000203 RID: 515
internal class Class239
{
	// Token: 0x06001AB3 RID: 6835 RVA: 0x00013637 File Offset: 0x00011837
	public Class239(int int_4)
	{
		this.int_0 = int_4;
	}

	// Token: 0x06001AB4 RID: 6836
	[DllImport("kernel32.dll")]
	protected static extern bool ReadProcessMemory(IntPtr intptr_0, int int_4, byte[] byte_1, uint uint_0, int int_5);

	// Token: 0x06001AB5 RID: 6837
	[DllImport("kernel32.dll")]
	protected static extern int VirtualQueryEx(IntPtr intptr_0, IntPtr intptr_1, out Class239.Struct2 struct2_0, int int_4);

	// Token: 0x17000670 RID: 1648
	// (get) Token: 0x06001AB6 RID: 6838 RVA: 0x00013646 File Offset: 0x00011846
	// (set) Token: 0x06001AB7 RID: 6839 RVA: 0x0001364E File Offset: 0x0001184E
	protected List<Class239.Struct2> List_0 { get; set; }

	// Token: 0x06001AB8 RID: 6840 RVA: 0x000C8CE4 File Offset: 0x000C6EE4
	protected void method_0(IntPtr intptr_0)
	{
		IntPtr intptr_ = 0;
		for (;;)
		{
			Class239.Struct2 @struct = default(Class239.Struct2);
			if (Class239.VirtualQueryEx(intptr_0, intptr_, out @struct, Marshal.SizeOf(@struct)) == 0)
			{
				break;
			}
			if ((@struct.uint_2 & 4096U) != 0U && (@struct.uint_3 & 256U) == 0U)
			{
				this.List_0.Add(@struct);
			}
			intptr_ = new IntPtr(@struct.int_0 + (int)@struct.uint_1);
		}
	}

	// Token: 0x06001AB9 RID: 6841 RVA: 0x000C8D58 File Offset: 0x000C6F58
	protected int method_1(byte[] byte_1, int[] int_4, int int_5 = 0)
	{
		int num = int_4.Length - 1;
		while (int_5 <= byte_1.Length - int_4.Length)
		{
			int num2 = num;
			while (int_4[num2] == -1 || (int_4[num2] == 256 && byte_1[int_5 + num2] > 1) || (int)byte_1[int_5 + num2] == int_4[num2])
			{
				if (num2 == 0)
				{
					return int_5;
				}
				num2--;
			}
			int_5++;
		}
		return 0;
	}

	// Token: 0x17000671 RID: 1649
	// (get) Token: 0x06001ABA RID: 6842 RVA: 0x00013657 File Offset: 0x00011857
	// (set) Token: 0x06001ABB RID: 6843 RVA: 0x0001365F File Offset: 0x0001185F
	public int Int32_0 { get; set; }

	// Token: 0x17000672 RID: 1650
	// (get) Token: 0x06001ABC RID: 6844 RVA: 0x00013668 File Offset: 0x00011868
	// (set) Token: 0x06001ABD RID: 6845 RVA: 0x00013670 File Offset: 0x00011870
	public int Int32_1 { get; set; }

	// Token: 0x17000673 RID: 1651
	// (get) Token: 0x06001ABE RID: 6846 RVA: 0x00013679 File Offset: 0x00011879
	// (set) Token: 0x06001ABF RID: 6847 RVA: 0x00013681 File Offset: 0x00011881
	public byte[] Byte_0 { get; set; }

	// Token: 0x06001AC0 RID: 6848 RVA: 0x00002E18 File Offset: 0x00001018
	public void method_2()
	{
	}

	// Token: 0x06001AC1 RID: 6849 RVA: 0x0001368A File Offset: 0x0001188A
	public uint method_3(string string_0)
	{
		return this.method_5(Class239.smethod_0(string_0));
	}

	// Token: 0x06001AC2 RID: 6850 RVA: 0x00013698 File Offset: 0x00011898
	public uint method_4(string string_0)
	{
		return this.method_6(Class239.smethod_0(string_0));
	}

	// Token: 0x06001AC3 RID: 6851 RVA: 0x000C8DB4 File Offset: 0x000C6FB4
	public uint method_5(int[] int_4)
	{
		this.Int32_0 = 0;
		this.Int32_1 = 0;
		Process processById = Process.GetProcessById(this.int_0);
		if (processById.Id == 0)
		{
			return 0U;
		}
		this.List_0 = new List<Class239.Struct2>();
		this.method_0(processById.Handle);
		for (int i = 0; i < this.List_0.Count; i++)
		{
			if (!this.Boolean_0 || (this.List_0[i].uint_2 == 4096U && this.List_0[i].uint_3 == 4U && this.List_0[i].uint_4 == 131072U && this.List_0[i].uint_0 == 4U && this.List_0[i].uint_1 < 15728640U))
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				Class239.ReadProcessMemory(processById.Handle, this.List_0[i].int_0, byte_, this.List_0[i].uint_1, 0);
				this.Byte_0 = byte_;
				this.Int32_0 = i;
				int num = this.method_1(byte_, int_4, 0);
				if (num != 0)
				{
					this.Int32_1 = num;
					this.Int32_2 = this.List_0[i].int_0;
					return (uint)(this.List_0[i].int_0 + num);
				}
			}
		}
		return 0U;
	}

	// Token: 0x17000674 RID: 1652
	// (get) Token: 0x06001AC4 RID: 6852 RVA: 0x000136A6 File Offset: 0x000118A6
	// (set) Token: 0x06001AC5 RID: 6853 RVA: 0x000136AE File Offset: 0x000118AE
	public bool Boolean_0 { get; set; }

	// Token: 0x17000675 RID: 1653
	// (get) Token: 0x06001AC6 RID: 6854 RVA: 0x000136B7 File Offset: 0x000118B7
	// (set) Token: 0x06001AC7 RID: 6855 RVA: 0x000136BF File Offset: 0x000118BF
	public int Int32_2 { get; set; }

	// Token: 0x06001AC8 RID: 6856 RVA: 0x000C8F30 File Offset: 0x000C7130
	public uint method_6(int[] int_4)
	{
		if (this.List_0 == null)
		{
			return this.method_5(int_4);
		}
		Process processById = Process.GetProcessById(this.int_0);
		if (this.Int32_1 != 0 && this.Int32_0 < this.List_0.Count)
		{
			int num = this.method_1(this.Byte_0, int_4, this.Int32_1 + 1);
			if (num != 0)
			{
				this.Int32_1 = num;
				return (uint)(this.List_0[this.Int32_0].int_0 + num);
			}
		}
		for (int i = this.Int32_0 + 1; i < this.List_0.Count; i++)
		{
			if (!this.Boolean_0 || (this.List_0[i].uint_2 == 4096U && this.List_0[i].uint_3 == 4U && this.List_0[i].uint_4 == 131072U && this.List_0[i].uint_0 == 4U && this.List_0[i].uint_1 < 15728640U))
			{
				byte[] byte_ = new byte[this.List_0[i].uint_1];
				Class239.ReadProcessMemory(processById.Handle, this.List_0[i].int_0, byte_, this.List_0[i].uint_1, 0);
				this.Byte_0 = byte_;
				this.Int32_0 = i;
				int num2 = this.method_1(byte_, int_4, 0);
				if (num2 != 0)
				{
					this.Int32_1 = num2;
					this.Int32_2 = this.List_0[i].int_0;
					return (uint)(this.List_0[i].int_0 + num2);
				}
			}
		}
		this.Int32_1 = 0;
		return 0U;
	}

	// Token: 0x06001AC9 RID: 6857 RVA: 0x000C90F4 File Offset: 0x000C72F4
	public static int[] smethod_0(string string_0)
	{
		string_0 = string_0.Replace(" ", "");
		if (string_0.Length % 2 != 0)
		{
			string_0 += "0";
		}
		int[] array = new int[string_0.Length / 2];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = Class239.smethod_1(string_0.Substring(i * 2, 2));
		}
		return array;
	}

	// Token: 0x06001ACA RID: 6858 RVA: 0x000C915C File Offset: 0x000C735C
	public static int smethod_1(string string_0)
	{
		if (string_0.Contains("?"))
		{
			return -1;
		}
		if (string_0.Contains("#"))
		{
			return 256;
		}
		int result = -1;
		int.TryParse(string_0, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x040010AE RID: 4270
	protected int int_0;

	// Token: 0x040010AF RID: 4271
	[CompilerGenerated]
	private List<Class239.Struct2> list_0;

	// Token: 0x040010B0 RID: 4272
	[CompilerGenerated]
	private int int_1;

	// Token: 0x040010B1 RID: 4273
	[CompilerGenerated]
	private int int_2;

	// Token: 0x040010B2 RID: 4274
	[CompilerGenerated]
	private byte[] byte_0;

	// Token: 0x040010B3 RID: 4275
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040010B4 RID: 4276
	[CompilerGenerated]
	private int int_3;

	// Token: 0x02000204 RID: 516
	protected struct Struct2
	{
		// Token: 0x040010B5 RID: 4277
		public int int_0;

		// Token: 0x040010B6 RID: 4278
		public IntPtr intptr_0;

		// Token: 0x040010B7 RID: 4279
		public uint uint_0;

		// Token: 0x040010B8 RID: 4280
		public uint uint_1;

		// Token: 0x040010B9 RID: 4281
		public uint uint_2;

		// Token: 0x040010BA RID: 4282
		public uint uint_3;

		// Token: 0x040010BB RID: 4283
		public uint uint_4;
	}
}
