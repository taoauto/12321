﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using Microsoft.VisualBasic;
using _i;

// Token: 0x020002F3 RID: 755
internal class Publisher : UserControl
{
	// Token: 0x06002B17 RID: 11031 RVA: 0x0001F451 File Offset: 0x0001D651
	public Publisher()
	{
		this.InitializeComponent();
	}

	// Token: 0x06002B18 RID: 11032 RVA: 0x001239C8 File Offset: 0x00121BC8
	public static void smethod_0()
	{
		try
		{
			try
			{
				Publisher.xmlDocument_0.LoadXml(Class159.Class220_0.method_0("Item", "Publishers"));
			}
			catch
			{
				try
				{
					Publisher.xmlDocument_0.LoadXml(GClass130.String_7);
					Publisher.smethod_1();
				}
				catch
				{
				}
			}
		}
		catch
		{
			if (Publisher.xmlDocument_0.SelectSingleNode("/*") == null)
			{
				Publisher.xmlDocument_0.InsertBefore(Publisher.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), Publisher.xmlDocument_0.DocumentElement);
				Publisher.xmlDocument_0.AppendChild(Publisher.xmlDocument_0.CreateNode(XmlNodeType.Element, "Publishers", ""));
				Publisher.smethod_1();
			}
		}
	}

	// Token: 0x170009B7 RID: 2487
	// (get) Token: 0x06002B19 RID: 11033 RVA: 0x00123AA0 File Offset: 0x00121CA0
	// (set) Token: 0x06002B1A RID: 11034 RVA: 0x00123AE8 File Offset: 0x00121CE8
	public static string String_0
	{
		get
		{
			string result;
			try
			{
				result = Publisher.xmlDocument_0.SelectSingleNode("Publishers").SelectSingleNode("Version").InnerText;
			}
			catch
			{
				result = "1.0";
			}
			return result;
		}
		set
		{
			try
			{
				Publisher.xmlDocument_0.SelectSingleNode("Publishers").SelectSingleNode("Version").InnerText = Class268.String_2;
				Publisher.smethod_1();
			}
			catch
			{
				XmlElement xmlElement = Publisher.xmlDocument_0.CreateElement("Version");
				xmlElement.InnerText = value;
				Publisher.xmlDocument_0.SelectSingleNode("Publishers").AppendChild(xmlElement);
				Publisher.smethod_1();
			}
		}
	}

	// Token: 0x06002B1B RID: 11035 RVA: 0x0001F45F File Offset: 0x0001D65F
	public static void smethod_1()
	{
		Class159.Class220_0.method_1("Item", "Publishers", Publisher.xmlDocument_0.OuterXml);
	}

	// Token: 0x06002B1C RID: 11036 RVA: 0x0001F47F File Offset: 0x0001D67F
	private void Publisher_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06002B1D RID: 11037 RVA: 0x00123B64 File Offset: 0x00121D64
	private void method_0()
	{
		this.listViewNPH.Items.Clear();
		try
		{
			foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("Publishers").SelectNodes("Publisher"))
			{
				XmlNode xmlNode = (XmlNode)obj;
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = xmlNode.Attributes["Name"].Value;
				listViewItem.Tag = xmlNode;
				this.listViewNPH.Items.Add(listViewItem);
			}
		}
		catch
		{
		}
		if (this.listViewNPH.SelectedItems.Count == 0 && this.listViewNPH.Items.Count > 0)
		{
			this.listViewNPH.Items[0].Selected = true;
			this.listViewNPH.Select();
		}
	}

	// Token: 0x06002B1E RID: 11038 RVA: 0x00123C6C File Offset: 0x00121E6C
	private void menuAddServer_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		string text = Interaction.InputBox("Nhập vào tên Server muốn thêm", "MicroAuto", "", -1, -1);
		if (text != "")
		{
			XmlElement xmlElement = Publisher.xmlDocument_0.CreateElement("Server");
			xmlElement.InnerText = text;
			try
			{
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Servers").AppendChild(xmlElement);
			}
			catch
			{
				XmlNode newChild = Publisher.xmlDocument_0.CreateElement("Servers");
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]").AppendChild(newChild);
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Servers").AppendChild(xmlElement);
			}
			Publisher.smethod_1();
			this.method_1();
		}
	}

	// Token: 0x06002B1F RID: 11039 RVA: 0x00123D9C File Offset: 0x00121F9C
	private void listViewNPH_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		this.listViewServer.Items.Clear();
		try
		{
			this.txtPath.Text = Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]").Attributes["Path"].Value;
		}
		catch
		{
			this.txtPath.Text = "";
		}
		this.Text = "Nhà Phát Hành - " + this.listViewNPH.SelectedItems[0].Text;
		this.method_1();
		this.method_2();
	}

	// Token: 0x06002B20 RID: 11040 RVA: 0x00123E74 File Offset: 0x00122074
	private void method_1()
	{
		this.listViewServer.Items.Clear();
		int num = 0;
		try
		{
			foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Servers").SelectNodes("Server"))
			{
				XmlNode xmlNode = (XmlNode)obj;
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = num++.ToString();
				listViewItem.SubItems.Add(xmlNode.InnerText);
				listViewItem.Tag = xmlNode;
				this.listViewServer.Items.Add(listViewItem);
			}
		}
		catch
		{
		}
	}

	// Token: 0x06002B21 RID: 11041 RVA: 0x00123F68 File Offset: 0x00122168
	private void method_2()
	{
		this.listViewTail.Items.Clear();
		int num = 0;
		try
		{
			foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Tails").SelectNodes("Tail"))
			{
				XmlNode xmlNode = (XmlNode)obj;
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = num++.ToString();
				listViewItem.SubItems.Add(xmlNode.InnerText);
				listViewItem.Tag = xmlNode;
				this.listViewTail.Items.Add(listViewItem);
			}
		}
		catch
		{
		}
	}

	// Token: 0x06002B22 RID: 11042 RVA: 0x0012405C File Offset: 0x0012225C
	private void menuDeleteServer_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count != 0 && this.listViewServer.SelectedItems.Count != 0)
		{
			if (MessageBox.Show(this, "Bạn có muốn xóa Server đã chọn", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				foreach (object obj in this.listViewServer.SelectedItems)
				{
					XmlNode oldChild = (XmlNode)((ListViewItem)obj).Tag;
					Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Servers").RemoveChild(oldChild);
					Publisher.smethod_1();
				}
				this.method_1();
			}
			return;
		}
	}

	// Token: 0x06002B23 RID: 11043 RVA: 0x0001F487 File Offset: 0x0001D687
	private void btnReset_Click(object sender, EventArgs e)
	{
		if (MessageBox.Show(this, "Bạn có muốn xóa mọi thiết lập và dùng thiết lập mặc định", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			Class159.Class220_0.method_1("Item", "Publishers", GClass130.String_7);
		}
		Publisher.smethod_0();
		this.method_0();
	}

	// Token: 0x06002B24 RID: 11044 RVA: 0x00124144 File Offset: 0x00122344
	private void menuEditServer_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count != 0 && this.listViewServer.SelectedItems.Count != 0)
		{
			XmlNode xmlNode = (XmlNode)this.listViewServer.SelectedItems[0].Tag;
			string text = Interaction.InputBox("Nhập vào tên Server muốn đổi", "MicroAuto", xmlNode.InnerText, -1, -1);
			if (text != "" && text != xmlNode.InnerText)
			{
				xmlNode.InnerText = text;
				Publisher.smethod_1();
				this.method_1();
			}
			return;
		}
	}

	// Token: 0x06002B25 RID: 11045 RVA: 0x001241D8 File Offset: 0x001223D8
	private void menuAddNPH_Click(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Nhập vào tên Nhà Phát Hành muốn thêm", "MicroAuto", "", -1, -1);
		if (text != "")
		{
			XmlElement xmlElement = Publisher.xmlDocument_0.CreateElement("Publisher");
			XmlAttribute xmlAttribute = Publisher.xmlDocument_0.CreateAttribute("Name");
			xmlAttribute.Value = text;
			xmlElement.Attributes.Append(xmlAttribute);
			Publisher.xmlDocument_0.SelectSingleNode("//Publishers").AppendChild(xmlElement);
			Publisher.smethod_1();
			this.method_0();
		}
	}

	// Token: 0x06002B26 RID: 11046 RVA: 0x00124260 File Offset: 0x00122460
	private void menuEditNPH_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		XmlNode xmlNode = (XmlNode)this.listViewNPH.SelectedItems[0].Tag;
		string text = Interaction.InputBox("Nhập vào tên Nhà Phát Hành muốn đổi", "MicroAuto", xmlNode.Attributes["Name"].Value, -1, -1);
		if (text != "" && text != xmlNode.Attributes["Name"].Value)
		{
			xmlNode.Attributes["Name"].Value = text;
			Publisher.smethod_1();
			this.method_0();
		}
	}

	// Token: 0x06002B27 RID: 11047 RVA: 0x00124310 File Offset: 0x00122510
	private void menuDeleteNPH_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		if (MessageBox.Show(this, "Bạn có muốn xóa Nhà Phát Hành đã chọn", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			foreach (object obj in this.listViewNPH.SelectedItems)
			{
				XmlNode oldChild = (XmlNode)((ListViewItem)obj).Tag;
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers").RemoveChild(oldChild);
				Publisher.smethod_1();
			}
			this.method_0();
		}
	}

	// Token: 0x06002B28 RID: 11048 RVA: 0x001243BC File Offset: 0x001225BC
	private void menuAddTail_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		string text = Interaction.InputBox("Nhập vào tên đuôi muốn thêm", "MicroAuto", "", -1, -1);
		if (text != "")
		{
			XmlElement xmlElement = Publisher.xmlDocument_0.CreateElement("Tail");
			xmlElement.InnerText = text;
			try
			{
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Tails").AppendChild(xmlElement);
			}
			catch
			{
				XmlNode newChild = Publisher.xmlDocument_0.CreateElement("Tails");
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]").AppendChild(newChild);
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Tails").AppendChild(xmlElement);
			}
			Publisher.smethod_1();
			this.method_2();
		}
	}

	// Token: 0x06002B29 RID: 11049 RVA: 0x001244EC File Offset: 0x001226EC
	private void menuEditTail_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count != 0 && this.listViewTail.SelectedItems.Count != 0)
		{
			XmlNode xmlNode = (XmlNode)this.listViewTail.SelectedItems[0].Tag;
			string text = Interaction.InputBox("Nhập vào tên đuôi muốn đổi", "MicroAuto", xmlNode.InnerText, -1, -1);
			if (text != "" && text != xmlNode.InnerText)
			{
				xmlNode.InnerText = text;
				Publisher.smethod_1();
				this.method_2();
			}
			return;
		}
	}

	// Token: 0x06002B2A RID: 11050 RVA: 0x00124580 File Offset: 0x00122780
	private void menuDeleteTail_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count != 0 && this.listViewTail.SelectedItems.Count != 0)
		{
			if (MessageBox.Show(this, "Bạn có muốn xóa đuôi đã chọn", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				foreach (object obj in this.listViewTail.SelectedItems)
				{
					XmlNode oldChild = (XmlNode)((ListViewItem)obj).Tag;
					Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Tails").RemoveChild(oldChild);
					Publisher.smethod_1();
				}
				this.method_2();
			}
			return;
		}
	}

	// Token: 0x06002B2B RID: 11051 RVA: 0x00124668 File Offset: 0x00122868
	private void btnPath_Click(object sender, EventArgs e)
	{
		if (this.listViewNPH.SelectedItems.Count == 0)
		{
			return;
		}
		OpenFileDialog openFileDialog = new OpenFileDialog();
		if (openFileDialog.ShowDialog(this) == DialogResult.OK)
		{
			try
			{
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]").Attributes["Path"].Value = openFileDialog.FileName;
				this.txtPath.Text = openFileDialog.FileName;
				Publisher.smethod_1();
			}
			catch
			{
				XmlAttribute xmlAttribute = Publisher.xmlDocument_0.CreateAttribute("Path");
				xmlAttribute.Value = openFileDialog.FileName;
				Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]").Attributes.Append(xmlAttribute);
				this.txtPath.Text = openFileDialog.FileName;
				Publisher.smethod_1();
			}
		}
	}

	// Token: 0x06002B2C RID: 11052 RVA: 0x0012477C File Offset: 0x0012297C
	private void listViewServer_DragDrop(object sender, DragEventArgs e)
	{
		try
		{
			XmlNode xmlNode = Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Servers");
			xmlNode.RemoveAll();
			foreach (object obj in this.listViewServer.Items)
			{
				XmlElement newChild = (XmlElement)((ListViewItem)obj).Tag;
				xmlNode.AppendChild(newChild);
			}
			Publisher.smethod_1();
			this.method_1();
		}
		catch
		{
		}
	}

	// Token: 0x06002B2D RID: 11053 RVA: 0x00124838 File Offset: 0x00122A38
	private void listViewTail_DragDrop(object sender, DragEventArgs e)
	{
		try
		{
			XmlNode xmlNode = Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.listViewNPH.SelectedItems[0].Text + "\"]/Tails");
			xmlNode.RemoveAll();
			foreach (object obj in this.listViewTail.Items)
			{
				XmlElement newChild = (XmlElement)((ListViewItem)obj).Tag;
				xmlNode.AppendChild(newChild);
			}
			this.method_2();
		}
		catch
		{
		}
	}

	// Token: 0x06002B2E RID: 11054 RVA: 0x001248F0 File Offset: 0x00122AF0
	private void listViewNPH_DragDrop(object sender, DragEventArgs e)
	{
		try
		{
			XmlNode xmlNode = Publisher.xmlDocument_0.SelectSingleNode("//Publishers");
			xmlNode.RemoveAll();
			foreach (object obj in this.listViewNPH.Items)
			{
				XmlElement newChild = (XmlElement)((ListViewItem)obj).Tag;
				xmlNode.AppendChild(newChild);
			}
			this.method_0();
		}
		catch
		{
		}
	}

	// Token: 0x06002B2F RID: 11055 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06002B30 RID: 11056 RVA: 0x0001F4C1 File Offset: 0x0001D6C1
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06002B31 RID: 11057 RVA: 0x00124988 File Offset: 0x00122B88
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Publisher));
		this.listViewNPH = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.menuNPH = new ContextMenuStrip(this.icontainer_0);
		this.menuAddNPH = new ToolStripMenuItem();
		this.menuEditNPH = new ToolStripMenuItem();
		this.menuDeleteNPH = new ToolStripMenuItem();
		this.menu = new ContextMenuStrip(this.icontainer_0);
		this.menuAddServer = new ToolStripMenuItem();
		this.menuEditServer = new ToolStripMenuItem();
		this.menuDeleteServer = new ToolStripMenuItem();
		this.btnPath = new Button();
		this.txtPath = new TextBox();
		this.label6 = new Label();
		this.btnReset = new Button();
		this.menuNPH_1 = new ContextMenuStrip(this.icontainer_0);
		this.menuAddTail = new ToolStripMenuItem();
		this.menuEditTail = new ToolStripMenuItem();
		this.menuDeleteTail = new ToolStripMenuItem();
		this.listViewServer = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.listViewTail = new ListViewEx();
		this.columnHeader_3 = new ColumnHeader();
		this.columnHeader_4 = new ColumnHeader();
		this.splitContainer1 = new SplitContainer();
		this.groupBox1 = new GroupBox();
		this.panel1 = new Panel();
		this.button1 = new Button();
		this.menuNPH.SuspendLayout();
		this.menu.SuspendLayout();
		this.menuNPH_1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.groupBox1.SuspendLayout();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.listViewNPH.AllowColumnReorder = true;
		this.listViewNPH.AllowDrop = true;
		this.listViewNPH.AllowReorder = true;
		this.listViewNPH.AllowSort = true;
		this.listViewNPH.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewNPH.ContextMenuStrip = this.menuNPH;
		this.listViewNPH.Dock = DockStyle.Fill;
		this.listViewNPH.DoubleClickActivation = false;
		this.listViewNPH.FullRowSelect = true;
		this.listViewNPH.GridLines = true;
		this.listViewNPH.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewNPH.hideItems");
		this.listViewNPH.HideSelection = false;
		this.listViewNPH.LineColor = Color.Red;
		this.listViewNPH.Location = new Point(0, 0);
		this.listViewNPH.Name = "listViewNPH";
		this.listViewNPH.Size = new Size(144, 348);
		this.listViewNPH.TabIndex = 0;
		this.listViewNPH.UseCompatibleStateImageBehavior = false;
		this.listViewNPH.View = View.Details;
		this.listViewNPH.SelectedIndexChanged += this.listViewNPH_SelectedIndexChanged;
		this.listViewNPH.DragDrop += this.listViewNPH_DragDrop;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 119;
		this.menuNPH.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddNPH,
			this.menuEditNPH,
			this.menuDeleteNPH
		});
		this.menuNPH.Name = "menuNPH";
		this.menuNPH.Size = new Size(108, 70);
		this.menuAddNPH.Name = "menuAddNPH";
		this.menuAddNPH.Size = new Size(107, 22);
		this.menuAddNPH.Text = "Add";
		this.menuAddNPH.Click += this.menuAddNPH_Click;
		this.menuEditNPH.Name = "menuEditNPH";
		this.menuEditNPH.Size = new Size(107, 22);
		this.menuEditNPH.Text = "Edit";
		this.menuEditNPH.Click += this.menuEditNPH_Click;
		this.menuDeleteNPH.Name = "menuDeleteNPH";
		this.menuDeleteNPH.Size = new Size(107, 22);
		this.menuDeleteNPH.Text = "Delete";
		this.menuDeleteNPH.Click += this.menuDeleteNPH_Click;
		this.menu.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddServer,
			this.menuEditServer,
			this.menuDeleteServer
		});
		this.menu.Name = "menu";
		this.menu.Size = new Size(108, 70);
		this.menuAddServer.Name = "menuAddServer";
		this.menuAddServer.Size = new Size(107, 22);
		this.menuAddServer.Text = "Add";
		this.menuAddServer.Click += this.menuAddServer_Click;
		this.menuEditServer.Name = "menuEditServer";
		this.menuEditServer.Size = new Size(107, 22);
		this.menuEditServer.Text = "Edit";
		this.menuEditServer.Click += this.menuEditServer_Click;
		this.menuDeleteServer.Name = "menuDeleteServer";
		this.menuDeleteServer.Size = new Size(107, 22);
		this.menuDeleteServer.Text = "Delete";
		this.menuDeleteServer.Click += this.menuDeleteServer_Click;
		this.btnPath.Dock = DockStyle.Right;
		this.btnPath.Location = new Point(247, 0);
		this.btnPath.Name = "btnPath";
		this.btnPath.Size = new Size(33, 21);
		this.btnPath.TabIndex = 17;
		this.btnPath.Text = "...";
		this.btnPath.UseVisualStyleBackColor = true;
		this.btnPath.Click += this.btnPath_Click;
		this.txtPath.Dock = DockStyle.Fill;
		this.txtPath.Location = new Point(0, 0);
		this.txtPath.Name = "txtPath";
		this.txtPath.Size = new Size(247, 20);
		this.txtPath.TabIndex = 15;
		this.label6.Dock = DockStyle.Top;
		this.label6.Location = new Point(0, 0);
		this.label6.Name = "label6";
		this.label6.Size = new Size(434, 20);
		this.label6.TabIndex = 16;
		this.label6.Text = "Cài Đặt Server";
		this.label6.TextAlign = ContentAlignment.MiddleCenter;
		this.btnReset.Dock = DockStyle.Bottom;
		this.btnReset.Location = new Point(0, 325);
		this.btnReset.Name = "btnReset";
		this.btnReset.Size = new Size(286, 23);
		this.btnReset.TabIndex = 21;
		this.btnReset.Text = "Reset";
		this.btnReset.UseVisualStyleBackColor = true;
		this.btnReset.Click += this.btnReset_Click;
		this.menuNPH_1.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddTail,
			this.menuEditTail,
			this.menuDeleteTail
		});
		this.menuNPH_1.Name = "menuNPH";
		this.menuNPH_1.Size = new Size(108, 70);
		this.menuAddTail.Name = "menuAddTail";
		this.menuAddTail.Size = new Size(107, 22);
		this.menuAddTail.Text = "Add";
		this.menuAddTail.Click += this.menuAddTail_Click;
		this.menuEditTail.Name = "menuEditTail";
		this.menuEditTail.Size = new Size(107, 22);
		this.menuEditTail.Text = "Edit";
		this.menuEditTail.Click += this.menuEditTail_Click;
		this.menuDeleteTail.Name = "menuDeleteTail";
		this.menuDeleteTail.Size = new Size(107, 22);
		this.menuDeleteTail.Text = "Delete";
		this.menuDeleteTail.Click += this.menuDeleteTail_Click;
		this.listViewServer.AllowColumnReorder = true;
		this.listViewServer.AllowDrop = true;
		this.listViewServer.AllowReorder = true;
		this.listViewServer.AllowSort = true;
		this.listViewServer.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.listViewServer.ContextMenuStrip = this.menu;
		this.listViewServer.Dock = DockStyle.Fill;
		this.listViewServer.DoubleClickActivation = false;
		this.listViewServer.FullRowSelect = true;
		this.listViewServer.GridLines = true;
		this.listViewServer.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewServer.hideItems");
		this.listViewServer.HideSelection = false;
		this.listViewServer.LineColor = Color.Red;
		this.listViewServer.Location = new Point(0, 40);
		this.listViewServer.Name = "listViewServer";
		this.listViewServer.Size = new Size(286, 144);
		this.listViewServer.TabIndex = 18;
		this.listViewServer.UseCompatibleStateImageBehavior = false;
		this.listViewServer.View = View.Details;
		this.listViewServer.DragDrop += this.listViewServer_DragDrop;
		this.columnHeader_1.Text = "Index";
		this.columnHeader_1.Width = 40;
		this.columnHeader_2.Text = "Server";
		this.columnHeader_2.Width = 159;
		this.listViewTail.AllowColumnReorder = true;
		this.listViewTail.AllowDrop = true;
		this.listViewTail.AllowReorder = true;
		this.listViewTail.AllowSort = true;
		this.listViewTail.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_3,
			this.columnHeader_4
		});
		this.listViewTail.ContextMenuStrip = this.menuNPH_1;
		this.listViewTail.Dock = DockStyle.Bottom;
		this.listViewTail.DoubleClickActivation = false;
		this.listViewTail.FullRowSelect = true;
		this.listViewTail.GridLines = true;
		this.listViewTail.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewTail.hideItems");
		this.listViewTail.HideSelection = false;
		this.listViewTail.LineColor = Color.Red;
		this.listViewTail.Location = new Point(0, 184);
		this.listViewTail.Name = "listViewTail";
		this.listViewTail.Size = new Size(286, 141);
		this.listViewTail.TabIndex = 19;
		this.listViewTail.UseCompatibleStateImageBehavior = false;
		this.listViewTail.View = View.Details;
		this.listViewTail.DragDrop += this.listViewTail_DragDrop;
		this.columnHeader_3.Text = "Index";
		this.columnHeader_3.Width = 40;
		this.columnHeader_4.Text = "Tail";
		this.columnHeader_4.Width = 161;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 20);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.listViewNPH);
		this.splitContainer1.Panel2.Controls.Add(this.listViewServer);
		this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
		this.splitContainer1.Panel2.Controls.Add(this.listViewTail);
		this.splitContainer1.Panel2.Controls.Add(this.btnReset);
		this.splitContainer1.Size = new Size(434, 348);
		this.splitContainer1.SplitterDistance = 144;
		this.splitContainer1.TabIndex = 22;
		this.groupBox1.Controls.Add(this.panel1);
		this.groupBox1.Dock = DockStyle.Top;
		this.groupBox1.Location = new Point(0, 0);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new Size(286, 40);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Path";
		this.panel1.Controls.Add(this.txtPath);
		this.panel1.Controls.Add(this.btnPath);
		this.panel1.Dock = DockStyle.Fill;
		this.panel1.Location = new Point(3, 16);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(280, 21);
		this.panel1.TabIndex = 23;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 368);
		this.button1.Name = "button1";
		this.button1.Size = new Size(434, 23);
		this.button1.TabIndex = 23;
		this.button1.Text = "Ok";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.label6);
		base.Name = "Publisher";
		base.Size = new Size(434, 391);
		base.Load += this.Publisher_Load;
		this.menuNPH.ResumeLayout(false);
		this.menu.ResumeLayout(false);
		this.menuNPH_1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.groupBox1.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04001CAF RID: 7343
	public static XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x04001CB0 RID: 7344
	private IContainer icontainer_0;

	// Token: 0x04001CB1 RID: 7345
	private ListViewEx listViewNPH;

	// Token: 0x04001CB2 RID: 7346
	private Button btnPath;

	// Token: 0x04001CB3 RID: 7347
	private TextBox txtPath;

	// Token: 0x04001CB4 RID: 7348
	private Label label6;

	// Token: 0x04001CB5 RID: 7349
	private ListViewEx listViewServer;

	// Token: 0x04001CB6 RID: 7350
	private ListViewEx listViewTail;

	// Token: 0x04001CB7 RID: 7351
	private ColumnHeader columnHeader_0;

	// Token: 0x04001CB8 RID: 7352
	private ContextMenuStrip menu;

	// Token: 0x04001CB9 RID: 7353
	private ToolStripMenuItem menuAddServer;

	// Token: 0x04001CBA RID: 7354
	private ToolStripMenuItem menuEditServer;

	// Token: 0x04001CBB RID: 7355
	private ToolStripMenuItem menuDeleteServer;

	// Token: 0x04001CBC RID: 7356
	private Button btnReset;

	// Token: 0x04001CBD RID: 7357
	private ContextMenuStrip menuNPH;

	// Token: 0x04001CBE RID: 7358
	private ToolStripMenuItem menuAddNPH;

	// Token: 0x04001CBF RID: 7359
	private ToolStripMenuItem menuEditNPH;

	// Token: 0x04001CC0 RID: 7360
	private ToolStripMenuItem menuDeleteNPH;

	// Token: 0x04001CC1 RID: 7361
	private ContextMenuStrip menuNPH_1;

	// Token: 0x04001CC2 RID: 7362
	private ToolStripMenuItem menuAddTail;

	// Token: 0x04001CC3 RID: 7363
	private ToolStripMenuItem menuEditTail;

	// Token: 0x04001CC4 RID: 7364
	private ToolStripMenuItem menuDeleteTail;

	// Token: 0x04001CC5 RID: 7365
	private ColumnHeader columnHeader_1;

	// Token: 0x04001CC6 RID: 7366
	private ColumnHeader columnHeader_2;

	// Token: 0x04001CC7 RID: 7367
	private ColumnHeader columnHeader_3;

	// Token: 0x04001CC8 RID: 7368
	private ColumnHeader columnHeader_4;

	// Token: 0x04001CC9 RID: 7369
	private SplitContainer splitContainer1;

	// Token: 0x04001CCA RID: 7370
	private GroupBox groupBox1;

	// Token: 0x04001CCB RID: 7371
	private Panel panel1;

	// Token: 0x04001CCC RID: 7372
	private Button button1;
}
