﻿using System;

// Token: 0x0200009D RID: 157
public enum GEnum9
{
	// Token: 0x040003E6 RID: 998
	Continue = 100,
	// Token: 0x040003E7 RID: 999
	SwitchingProtocols,
	// Token: 0x040003E8 RID: 1000
	OK = 200,
	// Token: 0x040003E9 RID: 1001
	Created,
	// Token: 0x040003EA RID: 1002
	Accepted,
	// Token: 0x040003EB RID: 1003
	NonAuthoritativeInformation,
	// Token: 0x040003EC RID: 1004
	NoContent,
	// Token: 0x040003ED RID: 1005
	ResetContent,
	// Token: 0x040003EE RID: 1006
	PartialContent,
	// Token: 0x040003EF RID: 1007
	MultipleChoices = 300,
	// Token: 0x040003F0 RID: 1008
	Ambiguous = 300,
	// Token: 0x040003F1 RID: 1009
	MovedPermanently,
	// Token: 0x040003F2 RID: 1010
	Moved = 301,
	// Token: 0x040003F3 RID: 1011
	Found,
	// Token: 0x040003F4 RID: 1012
	Redirect = 302,
	// Token: 0x040003F5 RID: 1013
	SeeOther,
	// Token: 0x040003F6 RID: 1014
	RedirectMethod = 303,
	// Token: 0x040003F7 RID: 1015
	NotModified,
	// Token: 0x040003F8 RID: 1016
	UseProxy,
	// Token: 0x040003F9 RID: 1017
	Unused,
	// Token: 0x040003FA RID: 1018
	TemporaryRedirect,
	// Token: 0x040003FB RID: 1019
	RedirectKeepVerb = 307,
	// Token: 0x040003FC RID: 1020
	BadRequest = 400,
	// Token: 0x040003FD RID: 1021
	Unauthorized,
	// Token: 0x040003FE RID: 1022
	PaymentRequired,
	// Token: 0x040003FF RID: 1023
	Forbidden,
	// Token: 0x04000400 RID: 1024
	NotFound,
	// Token: 0x04000401 RID: 1025
	MethodNotAllowed,
	// Token: 0x04000402 RID: 1026
	NotAcceptable,
	// Token: 0x04000403 RID: 1027
	ProxyAuthenticationRequired,
	// Token: 0x04000404 RID: 1028
	RequestTimeout,
	// Token: 0x04000405 RID: 1029
	Conflict,
	// Token: 0x04000406 RID: 1030
	Gone,
	// Token: 0x04000407 RID: 1031
	LengthRequired,
	// Token: 0x04000408 RID: 1032
	PreconditionFailed,
	// Token: 0x04000409 RID: 1033
	RequestEntityTooLarge,
	// Token: 0x0400040A RID: 1034
	RequestUriTooLong,
	// Token: 0x0400040B RID: 1035
	UnsupportedMediaType,
	// Token: 0x0400040C RID: 1036
	RequestedRangeNotSatisfiable,
	// Token: 0x0400040D RID: 1037
	ExpectationFailed,
	// Token: 0x0400040E RID: 1038
	InternalServerError = 500,
	// Token: 0x0400040F RID: 1039
	NotImplemented,
	// Token: 0x04000410 RID: 1040
	BadGateway,
	// Token: 0x04000411 RID: 1041
	ServiceUnavailable,
	// Token: 0x04000412 RID: 1042
	GatewayTimeout,
	// Token: 0x04000413 RID: 1043
	HttpVersionNotSupported
}
