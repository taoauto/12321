﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020000FE RID: 254
public class GClass77 : IDisposable, IEnumerable, ICollection<GClass78>, IEnumerable<GClass78>
{
	// Token: 0x06000D0F RID: 3343 RVA: 0x0004EA5C File Offset: 0x0004CC5C
	public GClass77(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
		fastColoredTextBox_1.Event_2 += this.vmethod_1;
		fastColoredTextBox_1.KeyDown += this.vmethod_0;
		fastColoredTextBox_1.Event_7 += this.method_0;
	}

	// Token: 0x06000D10 RID: 3344 RVA: 0x0000B6B6 File Offset: 0x000098B6
	protected virtual void vmethod_0(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Escape && e.Modifiers == Keys.None)
		{
			this.Clear();
		}
	}

	// Token: 0x06000D11 RID: 3345 RVA: 0x0000B6D0 File Offset: 0x000098D0
	protected virtual void vmethod_1(object sender, GEventArgs11 e)
	{
		this.Clear();
	}

	// Token: 0x06000D12 RID: 3346 RVA: 0x0004EABC File Offset: 0x0004CCBC
	public void Dispose()
	{
		this.fastColoredTextBox_0.Event_2 -= this.vmethod_1;
		this.fastColoredTextBox_0.KeyDown -= this.vmethod_0;
		this.fastColoredTextBox_0.Event_7 -= this.method_0;
	}

	// Token: 0x06000D13 RID: 3347 RVA: 0x0004EB10 File Offset: 0x0004CD10
	private void method_0(object sender, EventArgs e)
	{
		if (this.list_0.Count == 0)
		{
			return;
		}
		this.fastColoredTextBox_0.method_11(true);
		foreach (GClass78 gclass in this.list_0)
		{
			this.method_1(gclass);
			gclass.GControl3_0.Invalidate();
		}
	}

	// Token: 0x06000D14 RID: 3348 RVA: 0x0004EB8C File Offset: 0x0004CD8C
	private void method_1(GClass78 gclass78_0)
	{
		if (gclass78_0.Boolean_0)
		{
			if (gclass78_0.GClass86_0.GStruct2_0.int_1 < this.fastColoredTextBox_0.list_0.Count - 1)
			{
				gclass78_0.GControl3_0.Top = this.fastColoredTextBox_0.list_0[gclass78_0.GClass86_0.GStruct2_0.int_1 + 1].int_0 - gclass78_0.Int32_2 - gclass78_0.GControl3_0.Height - this.fastColoredTextBox_0.VerticalScroll.Value;
			}
			else
			{
				gclass78_0.GControl3_0.Top = this.fastColoredTextBox_0.int_8 + this.fastColoredTextBox_0.Padding_0.Top - gclass78_0.GControl3_0.Height - this.fastColoredTextBox_0.VerticalScroll.Value;
			}
		}
		else
		{
			if (gclass78_0.GClass86_0.GStruct2_0.int_1 > this.fastColoredTextBox_0.Int32_14 - 1)
			{
				return;
			}
			if (gclass78_0.GClass86_0.GStruct2_0.int_1 == this.fastColoredTextBox_0.Int32_14 - 1)
			{
				int num = this.fastColoredTextBox_0.list_0[gclass78_0.GClass86_0.GStruct2_0.int_1].int_0 - this.fastColoredTextBox_0.VerticalScroll.Value + this.fastColoredTextBox_0.Int32_2;
				if (num + gclass78_0.GControl3_0.Height + 1 > this.fastColoredTextBox_0.ClientRectangle.Bottom)
				{
					gclass78_0.GControl3_0.Top = Math.Max(0, this.fastColoredTextBox_0.list_0[gclass78_0.GClass86_0.GStruct2_0.int_1].int_0 - this.fastColoredTextBox_0.VerticalScroll.Value - gclass78_0.GControl3_0.Height);
				}
				else
				{
					gclass78_0.GControl3_0.Top = num;
				}
			}
			else
			{
				gclass78_0.GControl3_0.Top = this.fastColoredTextBox_0.list_0[gclass78_0.GClass86_0.GStruct2_0.int_1 + 1].int_0 - this.fastColoredTextBox_0.VerticalScroll.Value;
				if (gclass78_0.GControl3_0.Bottom > this.fastColoredTextBox_0.ClientRectangle.Bottom)
				{
					gclass78_0.GControl3_0.Top = this.fastColoredTextBox_0.list_0[gclass78_0.GClass86_0.GStruct2_0.int_1 + 1].int_0 - this.fastColoredTextBox_0.Int32_2 - gclass78_0.Int32_2 - gclass78_0.GControl3_0.Height - this.fastColoredTextBox_0.VerticalScroll.Value;
				}
			}
		}
		if (gclass78_0.DockStyle_0 == DockStyle.Fill)
		{
			gclass78_0.Int32_0 = this.fastColoredTextBox_0.ClientSize.Width - this.fastColoredTextBox_0.Int32_7 - 2;
			gclass78_0.GControl3_0.Left = this.fastColoredTextBox_0.Int32_7;
			return;
		}
		Point point = this.fastColoredTextBox_0.method_95(gclass78_0.GClass86_0.GStruct2_0);
		Point point2 = this.fastColoredTextBox_0.method_95(gclass78_0.GClass86_0.GStruct2_1);
		int num2 = (point.X + point2.X) / 2 - gclass78_0.GControl3_0.Width / 2;
		gclass78_0.GControl3_0.Left = Math.Max(this.fastColoredTextBox_0.Int32_7, num2);
		if (gclass78_0.GControl3_0.Right > this.fastColoredTextBox_0.ClientSize.Width)
		{
			gclass78_0.GControl3_0.Left = Math.Max(this.fastColoredTextBox_0.Int32_7, num2 - (gclass78_0.GControl3_0.Right - this.fastColoredTextBox_0.ClientSize.Width));
		}
	}

	// Token: 0x06000D15 RID: 3349 RVA: 0x0000B6D8 File Offset: 0x000098D8
	public IEnumerator<GClass78> GetEnumerator()
	{
		GClass77.Class103 @class = new GClass77.Class103(0);
		@class.gclass77_0 = this;
		return @class;
	}

	// Token: 0x06000D16 RID: 3350 RVA: 0x0000B6E7 File Offset: 0x000098E7
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	// Token: 0x06000D17 RID: 3351 RVA: 0x0004EF58 File Offset: 0x0004D158
	public void Clear()
	{
		this.list_0.Clear();
		if (this.fastColoredTextBox_0.Controls.Count != 0)
		{
			List<Control> list = new List<Control>();
			foreach (object obj in this.fastColoredTextBox_0.Controls)
			{
				Control control = (Control)obj;
				if (control is GControl3)
				{
					list.Add(control);
				}
			}
			foreach (Control value in list)
			{
				this.fastColoredTextBox_0.Controls.Remove(value);
			}
			for (int i = 0; i < this.fastColoredTextBox_0.list_0.Count; i++)
			{
				GStruct1 value2 = this.fastColoredTextBox_0.list_0[i];
				value2.int_1 = 0;
				this.fastColoredTextBox_0.list_0[i] = value2;
			}
			this.fastColoredTextBox_0.method_10();
			this.fastColoredTextBox_0.method_4();
			this.fastColoredTextBox_0.Select();
			this.fastColoredTextBox_0.ActiveControl = null;
		}
	}

	// Token: 0x06000D18 RID: 3352 RVA: 0x0004F0AC File Offset: 0x0004D2AC
	public void Add(GClass78 hint)
	{
		this.list_0.Add(hint);
		if (hint.Boolean_0)
		{
			GStruct1 gstruct = this.fastColoredTextBox_0.list_0[hint.GClass86_0.GStruct2_0.int_1];
			hint.Int32_2 = gstruct.int_1;
			gstruct.int_1 += hint.GControl3_0.Height;
			this.fastColoredTextBox_0.list_0[hint.GClass86_0.GStruct2_0.int_1] = gstruct;
			this.fastColoredTextBox_0.method_11(true);
		}
		this.method_1(hint);
		this.fastColoredTextBox_0.vmethod_4();
		hint.GControl3_0.Parent = this.fastColoredTextBox_0;
		this.fastColoredTextBox_0.Select();
		this.fastColoredTextBox_0.ActiveControl = null;
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000D19 RID: 3353 RVA: 0x0000B6EF File Offset: 0x000098EF
	public bool Contains(GClass78 item)
	{
		return this.list_0.Contains(item);
	}

	// Token: 0x06000D1A RID: 3354 RVA: 0x0000B6FD File Offset: 0x000098FD
	public void CopyTo(GClass78[] array, int arrayIndex)
	{
		this.list_0.CopyTo(array, arrayIndex);
	}

	// Token: 0x17000376 RID: 886
	// (get) Token: 0x06000D1B RID: 3355 RVA: 0x0000B70C File Offset: 0x0000990C
	public int Count
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x17000377 RID: 887
	// (get) Token: 0x06000D1C RID: 3356 RVA: 0x00006FDC File Offset: 0x000051DC
	public bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000D1D RID: 3357 RVA: 0x000096BD File Offset: 0x000078BD
	public bool Remove(GClass78 item)
	{
		throw new NotImplementedException();
	}

	// Token: 0x0400062B RID: 1579
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x0400062C RID: 1580
	private List<GClass78> list_0 = new List<GClass78>();
}
