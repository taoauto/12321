﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;

// Token: 0x020000DA RID: 218
public class GClass74
{
	// Token: 0x170002BF RID: 703
	// (get) Token: 0x06000A1F RID: 2591 RVA: 0x00009A0E File Offset: 0x00007C0E
	// (set) Token: 0x06000A20 RID: 2592 RVA: 0x00009A16 File Offset: 0x00007C16
	public Color Color_0 { get; set; }

	// Token: 0x170002C0 RID: 704
	// (get) Token: 0x06000A21 RID: 2593 RVA: 0x00009A1F File Offset: 0x00007C1F
	// (set) Token: 0x06000A22 RID: 2594 RVA: 0x00009A27 File Offset: 0x00007C27
	public Color Color_1 { get; set; }

	// Token: 0x170002C1 RID: 705
	// (get) Token: 0x06000A23 RID: 2595 RVA: 0x00009A30 File Offset: 0x00007C30
	// (set) Token: 0x06000A24 RID: 2596 RVA: 0x00009A38 File Offset: 0x00007C38
	public string String_0 { get; set; }

	// Token: 0x040004EF RID: 1263
	[CompilerGenerated]
	private Color color_0;

	// Token: 0x040004F0 RID: 1264
	[CompilerGenerated]
	private Color color_1;

	// Token: 0x040004F1 RID: 1265
	[CompilerGenerated]
	private string string_0;
}
