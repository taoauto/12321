﻿using System;

// Token: 0x0200000F RID: 15
public enum GEnum1
{
	// Token: 0x04000018 RID: 24
	Accept,
	// Token: 0x04000019 RID: 25
	AcceptCharset,
	// Token: 0x0400001A RID: 26
	AcceptLanguage,
	// Token: 0x0400001B RID: 27
	AcceptDatetime,
	// Token: 0x0400001C RID: 28
	CacheControl,
	// Token: 0x0400001D RID: 29
	ContentType,
	// Token: 0x0400001E RID: 30
	Date,
	// Token: 0x0400001F RID: 31
	Expect,
	// Token: 0x04000020 RID: 32
	From,
	// Token: 0x04000021 RID: 33
	IfMatch,
	// Token: 0x04000022 RID: 34
	IfModifiedSince,
	// Token: 0x04000023 RID: 35
	IfNoneMatch,
	// Token: 0x04000024 RID: 36
	IfRange,
	// Token: 0x04000025 RID: 37
	IfUnmodifiedSince,
	// Token: 0x04000026 RID: 38
	MaxForwards,
	// Token: 0x04000027 RID: 39
	Pragma,
	// Token: 0x04000028 RID: 40
	Range,
	// Token: 0x04000029 RID: 41
	Referer,
	// Token: 0x0400002A RID: 42
	Upgrade,
	// Token: 0x0400002B RID: 43
	UserAgent,
	// Token: 0x0400002C RID: 44
	Via,
	// Token: 0x0400002D RID: 45
	Warning,
	// Token: 0x0400002E RID: 46
	DNT,
	// Token: 0x0400002F RID: 47
	AccessControlAllowOrigin,
	// Token: 0x04000030 RID: 48
	AcceptRanges,
	// Token: 0x04000031 RID: 49
	Age,
	// Token: 0x04000032 RID: 50
	Allow,
	// Token: 0x04000033 RID: 51
	ContentEncoding,
	// Token: 0x04000034 RID: 52
	ContentLanguage,
	// Token: 0x04000035 RID: 53
	ContentLength,
	// Token: 0x04000036 RID: 54
	ContentLocation,
	// Token: 0x04000037 RID: 55
	ContentMD5,
	// Token: 0x04000038 RID: 56
	ContentDisposition,
	// Token: 0x04000039 RID: 57
	ContentRange,
	// Token: 0x0400003A RID: 58
	ETag,
	// Token: 0x0400003B RID: 59
	Expires,
	// Token: 0x0400003C RID: 60
	LastModified,
	// Token: 0x0400003D RID: 61
	Link,
	// Token: 0x0400003E RID: 62
	Location,
	// Token: 0x0400003F RID: 63
	P3P,
	// Token: 0x04000040 RID: 64
	Refresh,
	// Token: 0x04000041 RID: 65
	RetryAfter,
	// Token: 0x04000042 RID: 66
	Server,
	// Token: 0x04000043 RID: 67
	TransferEncoding
}
