﻿using System;
using System.Security.Principal;
using WebSocketSharp.Net;

// Token: 0x02000093 RID: 147
public sealed class GClass38
{
	// Token: 0x060006D8 RID: 1752 RVA: 0x000076C0 File Offset: 0x000058C0
	internal GClass38(Class70 class70_1)
	{
		this.class70_0 = class70_1;
		this.int_0 = 400;
		this.gclass40_0 = new GClass40(this);
		this.gclass41_0 = new GClass41(this);
	}

	// Token: 0x170001CD RID: 461
	// (get) Token: 0x060006D9 RID: 1753 RVA: 0x000076F2 File Offset: 0x000058F2
	internal Class70 Class70_0
	{
		get
		{
			return this.class70_0;
		}
	}

	// Token: 0x170001CE RID: 462
	// (get) Token: 0x060006DA RID: 1754 RVA: 0x000076FA File Offset: 0x000058FA
	// (set) Token: 0x060006DB RID: 1755 RVA: 0x00007702 File Offset: 0x00005902
	internal string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
		}
	}

	// Token: 0x170001CF RID: 463
	// (get) Token: 0x060006DC RID: 1756 RVA: 0x0000770B File Offset: 0x0000590B
	// (set) Token: 0x060006DD RID: 1757 RVA: 0x00007713 File Offset: 0x00005913
	internal int Int32_0
	{
		get
		{
			return this.int_0;
		}
		set
		{
			this.int_0 = value;
		}
	}

	// Token: 0x170001D0 RID: 464
	// (get) Token: 0x060006DE RID: 1758 RVA: 0x0000771C File Offset: 0x0000591C
	internal bool Boolean_0
	{
		get
		{
			return this.string_0 != null;
		}
	}

	// Token: 0x170001D1 RID: 465
	// (get) Token: 0x060006DF RID: 1759 RVA: 0x00007727 File Offset: 0x00005927
	// (set) Token: 0x060006E0 RID: 1760 RVA: 0x0000772F File Offset: 0x0000592F
	internal GClass37 GClass37_0
	{
		get
		{
			return this.gclass37_0;
		}
		set
		{
			this.gclass37_0 = value;
		}
	}

	// Token: 0x170001D2 RID: 466
	// (get) Token: 0x060006E1 RID: 1761 RVA: 0x00007738 File Offset: 0x00005938
	public GClass40 GClass40_0
	{
		get
		{
			return this.gclass40_0;
		}
	}

	// Token: 0x170001D3 RID: 467
	// (get) Token: 0x060006E2 RID: 1762 RVA: 0x00007740 File Offset: 0x00005940
	public GClass41 GClass41_0
	{
		get
		{
			return this.gclass41_0;
		}
	}

	// Token: 0x170001D4 RID: 468
	// (get) Token: 0x060006E3 RID: 1763 RVA: 0x00007748 File Offset: 0x00005948
	public IPrincipal IPrincipal_0
	{
		get
		{
			return this.iprincipal_0;
		}
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x000374C4 File Offset: 0x000356C4
	internal bool method_0()
	{
		AuthenticationSchemes authenticationSchemes = this.gclass37_0.method_14(this.gclass40_0);
		if (authenticationSchemes == AuthenticationSchemes.Anonymous)
		{
			return true;
		}
		if (authenticationSchemes == AuthenticationSchemes.None)
		{
			this.gclass41_0.smethod_9(GEnum9.Forbidden);
			return false;
		}
		string string_ = this.gclass37_0.method_10();
		IPrincipal principal = Class78.smethod_16(this.gclass40_0.NameValueCollection_0["Authorization"], authenticationSchemes, string_, this.gclass40_0.String_2, this.gclass37_0.method_11());
		if (principal != null && principal.Identity.IsAuthenticated)
		{
			this.iprincipal_0 = principal;
			return true;
		}
		this.gclass41_0.smethod_10(new Class63(authenticationSchemes, string_).ToString());
		return false;
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x00007750 File Offset: 0x00005950
	internal bool method_1()
	{
		return this.gclass37_0.method_12(this);
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x0000775E File Offset: 0x0000595E
	internal void method_2()
	{
		this.gclass37_0.method_15(this);
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00037574 File Offset: 0x00035774
	public GClass47 method_3(string string_1)
	{
		if (this.gclass47_0 != null)
		{
			throw new InvalidOperationException("The accepting is already in progress.");
		}
		if (string_1 != null)
		{
			if (string_1.Length == 0)
			{
				throw new ArgumentException("An empty string.", "protocol");
			}
			if (!string_1.smethod_51())
			{
				throw new ArgumentException("Contains an invalid character.", "protocol");
			}
		}
		this.gclass47_0 = new GClass47(this, string_1);
		return this.gclass47_0;
	}

	// Token: 0x04000356 RID: 854
	private Class70 class70_0;

	// Token: 0x04000357 RID: 855
	private string string_0;

	// Token: 0x04000358 RID: 856
	private int int_0;

	// Token: 0x04000359 RID: 857
	private GClass37 gclass37_0;

	// Token: 0x0400035A RID: 858
	private GClass40 gclass40_0;

	// Token: 0x0400035B RID: 859
	private GClass41 gclass41_0;

	// Token: 0x0400035C RID: 860
	private IPrincipal iprincipal_0;

	// Token: 0x0400035D RID: 861
	private GClass47 gclass47_0;
}
