﻿using System;
using System.Text.RegularExpressions;

// Token: 0x0200012B RID: 299
public class GClass97
{
	// Token: 0x04000773 RID: 1907
	public string string_0;

	// Token: 0x04000774 RID: 1908
	public string string_1;

	// Token: 0x04000775 RID: 1909
	public RegexOptions regexOptions_0;
}
