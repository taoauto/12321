﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Timers;
using WebSocketSharp;

// Token: 0x02000078 RID: 120
public class GClass31
{
	// Token: 0x0600054D RID: 1357 RVA: 0x00031F08 File Offset: 0x00030108
	internal GClass31(GClass24 gclass24_1)
	{
		this.gclass24_0 = gclass24_1;
		this.bool_0 = true;
		this.object_0 = new object();
		this.dictionary_0 = new Dictionary<string, GInterface0>();
		this.enum5_0 = Enum5.Ready;
		this.object_1 = ((ICollection)this.dictionary_0).SyncRoot;
		this.timeSpan_0 = TimeSpan.FromSeconds(1.0);
		this.method_6(60000.0);
	}

	// Token: 0x1700015D RID: 349
	// (get) Token: 0x0600054E RID: 1358 RVA: 0x000066A3 File Offset: 0x000048A3
	internal Enum5 Enum5_0
	{
		get
		{
			return this.enum5_0;
		}
	}

	// Token: 0x1700015E RID: 350
	// (get) Token: 0x0600054F RID: 1359 RVA: 0x000066AD File Offset: 0x000048AD
	public IEnumerable<string> IEnumerable_0
	{
		get
		{
			GClass31.Class58 @class = new GClass31.Class58(-2);
			@class.gclass31_0 = this;
			return @class;
		}
	}

	// Token: 0x1700015F RID: 351
	// (get) Token: 0x06000550 RID: 1360 RVA: 0x00031F80 File Offset: 0x00030180
	public int Int32_0
	{
		get
		{
			object obj = this.object_1;
			int count;
			lock (obj)
			{
				count = this.dictionary_0.Count;
			}
			return count;
		}
	}

	// Token: 0x17000160 RID: 352
	// (get) Token: 0x06000551 RID: 1361 RVA: 0x00031FC8 File Offset: 0x000301C8
	public IEnumerable<string> IEnumerable_1
	{
		get
		{
			if (this.enum5_0 != Enum5.Start)
			{
				return Enumerable.Empty<string>();
			}
			object obj = this.object_1;
			IEnumerable<string> result;
			lock (obj)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					result = Enumerable.Empty<string>();
				}
				else
				{
					result = this.dictionary_0.Keys.smethod_64<string>();
				}
			}
			return result;
		}
	}

	// Token: 0x17000161 RID: 353
	// (get) Token: 0x06000552 RID: 1362 RVA: 0x000066BD File Offset: 0x000048BD
	public IEnumerable<string> IEnumerable_2
	{
		get
		{
			GClass31.Class59 @class = new GClass31.Class59(-2);
			@class.gclass31_0 = this;
			return @class;
		}
	}

	// Token: 0x17000162 RID: 354
	public GInterface0 this[string string_0]
	{
		get
		{
			if (string_0 == null)
			{
				throw new ArgumentNullException("id");
			}
			if (string_0.Length == 0)
			{
				throw new ArgumentException("An empty string.", "id");
			}
			GInterface0 result;
			this.method_8(string_0, out result);
			return result;
		}
	}

	// Token: 0x17000163 RID: 355
	// (get) Token: 0x06000554 RID: 1364 RVA: 0x000066CD File Offset: 0x000048CD
	// (set) Token: 0x06000555 RID: 1365 RVA: 0x00032078 File Offset: 0x00030278
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			string string_;
			if (!this.method_5(out string_))
			{
				this.gclass24_0.method_6(string_);
				return;
			}
			object obj = this.object_1;
			lock (obj)
			{
				if (!this.method_5(out string_))
				{
					this.gclass24_0.method_6(string_);
				}
				else
				{
					this.bool_0 = value;
				}
			}
		}
	}

	// Token: 0x17000164 RID: 356
	// (get) Token: 0x06000556 RID: 1366 RVA: 0x000320EC File Offset: 0x000302EC
	public IEnumerable<GInterface0> IEnumerable_3
	{
		get
		{
			if (this.enum5_0 != Enum5.Start)
			{
				return Enumerable.Empty<GInterface0>();
			}
			object obj = this.object_1;
			IEnumerable<GInterface0> result;
			lock (obj)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					result = Enumerable.Empty<GInterface0>();
				}
				else
				{
					result = this.dictionary_0.Values.smethod_64<GInterface0>();
				}
			}
			return result;
		}
	}

	// Token: 0x17000165 RID: 357
	// (get) Token: 0x06000557 RID: 1367 RVA: 0x000066D7 File Offset: 0x000048D7
	// (set) Token: 0x06000558 RID: 1368 RVA: 0x0003215C File Offset: 0x0003035C
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.timeSpan_0;
		}
		set
		{
			if (value <= TimeSpan.Zero)
			{
				throw new ArgumentOutOfRangeException("value", "Zero or less.");
			}
			string string_;
			if (!this.method_5(out string_))
			{
				this.gclass24_0.method_6(string_);
				return;
			}
			object obj = this.object_1;
			lock (obj)
			{
				if (!this.method_5(out string_))
				{
					this.gclass24_0.method_6(string_);
				}
				else
				{
					this.timeSpan_0 = value;
				}
			}
		}
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x000321EC File Offset: 0x000303EC
	private void method_0(Enum3 enum3_0, byte[] byte_0, Action action_0)
	{
		Dictionary<CompressionMethod, byte[]> dictionary = new Dictionary<CompressionMethod, byte[]>();
		try
		{
			foreach (GInterface0 ginterface in this.IEnumerable_3)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					this.gclass24_0.method_2("The service is shutting down.");
					break;
				}
				ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_68(enum3_0, byte_0, dictionary);
			}
			if (action_0 != null)
			{
				action_0();
			}
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
		finally
		{
			dictionary.Clear();
		}
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x000322BC File Offset: 0x000304BC
	private void method_1(Enum3 enum3_0, Stream stream_0, Action action_0)
	{
		Dictionary<CompressionMethod, Stream> dictionary = new Dictionary<CompressionMethod, Stream>();
		try
		{
			foreach (GInterface0 ginterface in this.IEnumerable_3)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					this.gclass24_0.method_2("The service is shutting down.");
					break;
				}
				ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_69(enum3_0, stream_0, dictionary);
			}
			if (action_0 != null)
			{
				action_0();
			}
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
		finally
		{
			foreach (Stream stream in dictionary.Values)
			{
				stream.Dispose();
			}
			dictionary.Clear();
		}
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x000066DF File Offset: 0x000048DF
	private void method_2(Enum3 enum3_0, byte[] byte_0, Action action_0)
	{
		GClass31.Class60 @class = new GClass31.Class60();
		@class.gclass31_0 = this;
		@class.enum3_0 = enum3_0;
		@class.byte_0 = byte_0;
		@class.action_0 = action_0;
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x00006713 File Offset: 0x00004913
	private void method_3(Enum3 enum3_0, Stream stream_0, Action action_0)
	{
		GClass31.Class61 @class = new GClass31.Class61();
		@class.gclass31_0 = this;
		@class.enum3_0 = enum3_0;
		@class.stream_0 = stream_0;
		@class.action_0 = action_0;
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x000323CC File Offset: 0x000305CC
	private Dictionary<string, bool> method_4(byte[] byte_0)
	{
		Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
		foreach (GInterface0 ginterface in this.IEnumerable_3)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				this.gclass24_0.method_2("The service is shutting down.");
				break;
			}
			bool value = ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_67(byte_0, this.timeSpan_0);
			dictionary.Add(ginterface.String_0, value);
		}
		return dictionary;
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x00006747 File Offset: 0x00004947
	private bool method_5(out string string_0)
	{
		string_0 = null;
		if (this.enum5_0 == Enum5.Start)
		{
			string_0 = "The service has already started.";
			return false;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			string_0 = "The service is shutting down.";
			return false;
		}
		return true;
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x00032460 File Offset: 0x00030660
	private static string smethod_0()
	{
		return Guid.NewGuid().ToString("N");
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x00006775 File Offset: 0x00004975
	private void method_6(double double_0)
	{
		this.timer_0 = new System.Timers.Timer(double_0);
		this.timer_0.Elapsed += this.timer_0_Elapsed;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x00032480 File Offset: 0x00030680
	private void method_7(Class30 class30_0, bool bool_2)
	{
		byte[] byte_ = bool_2 ? Class42.smethod_13(class30_0, false).method_3() : null;
		object obj = this.object_1;
		lock (obj)
		{
			this.enum5_0 = Enum5.ShuttingDown;
			this.timer_0.Enabled = false;
			foreach (GInterface0 ginterface in this.dictionary_0.Values.smethod_64<GInterface0>())
			{
				ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_65(class30_0, byte_);
			}
			this.enum5_0 = Enum5.Stop;
		}
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x00032544 File Offset: 0x00030744
	private bool method_8(string string_0, out GInterface0 ginterface0_0)
	{
		ginterface0_0 = null;
		if (this.enum5_0 != Enum5.Start)
		{
			return false;
		}
		object obj = this.object_1;
		bool result;
		lock (obj)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				result = false;
			}
			else
			{
				result = this.dictionary_0.TryGetValue(string_0, out ginterface0_0);
			}
		}
		return result;
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x000325AC File Offset: 0x000307AC
	internal string method_9(GInterface0 ginterface0_0)
	{
		object obj = this.object_1;
		string result;
		lock (obj)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				result = null;
			}
			else
			{
				string text = GClass31.smethod_0();
				this.dictionary_0.Add(text, ginterface0_0);
				result = text;
			}
		}
		return result;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x0003260C File Offset: 0x0003080C
	internal void method_10(Enum3 enum3_0, byte[] byte_0, Dictionary<CompressionMethod, byte[]> dictionary_1)
	{
		foreach (GInterface0 ginterface in this.IEnumerable_3)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				this.gclass24_0.method_2("The service is shutting down.");
				break;
			}
			ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_68(enum3_0, byte_0, dictionary_1);
		}
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x00032688 File Offset: 0x00030888
	internal void method_11(Enum3 enum3_0, Stream stream_0, Dictionary<CompressionMethod, Stream> dictionary_1)
	{
		foreach (GInterface0 ginterface in this.IEnumerable_3)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				this.gclass24_0.method_2("The service is shutting down.");
				break;
			}
			ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_69(enum3_0, stream_0, dictionary_1);
		}
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x00032704 File Offset: 0x00030904
	internal Dictionary<string, bool> method_12(byte[] byte_0, TimeSpan timeSpan_1)
	{
		Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
		foreach (GInterface0 ginterface in this.IEnumerable_3)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				this.gclass24_0.method_2("The service is shutting down.");
				break;
			}
			bool value = ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_67(byte_0, timeSpan_1);
			dictionary.Add(ginterface.String_0, value);
		}
		return dictionary;
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x00032794 File Offset: 0x00030994
	internal bool method_13(string string_0)
	{
		object obj = this.object_1;
		bool result;
		lock (obj)
		{
			result = this.dictionary_0.Remove(string_0);
		}
		return result;
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x000327DC File Offset: 0x000309DC
	internal void method_14()
	{
		object obj = this.object_1;
		lock (obj)
		{
			this.timer_0.Enabled = this.bool_0;
			this.enum5_0 = Enum5.Start;
		}
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x0000679A File Offset: 0x0000499A
	internal void method_15(ushort ushort_0, string string_0)
	{
		if (ushort_0 == 1005)
		{
			this.method_7(Class30.class30_0, true);
			return;
		}
		this.method_7(new Class30(ushort_0, string_0), !ushort_0.smethod_47());
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x00032834 File Offset: 0x00030A34
	public void method_16(byte[] byte_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		if ((long)byte_0.Length <= (long)GClass25.int_2)
		{
			this.method_0(Enum3.Binary, byte_0, null);
			return;
		}
		this.method_1(Enum3.Binary, new MemoryStream(byte_0), null);
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x00032888 File Offset: 0x00030A88
	public void method_17(string string_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		if ((long)array.Length <= (long)GClass25.int_2)
		{
			this.method_0(Enum3.Text, array, null);
			return;
		}
		this.method_1(Enum3.Text, new MemoryStream(array), null);
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x000328F8 File Offset: 0x00030AF8
	public void method_18(Stream stream_0, int int_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (stream_0 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream_0.CanRead)
		{
			throw new ArgumentException("It cannot be read.", "stream");
		}
		if (int_0 < 1)
		{
			throw new ArgumentException("Less than 1.", "length");
		}
		byte[] array = stream_0.smethod_54(int_0);
		int num = array.Length;
		if (num == 0)
		{
			throw new ArgumentException("No data could be read from it.", "stream");
		}
		if (num < int_0)
		{
			this.gclass24_0.method_6(string.Format("Only {0} byte(s) of data could be read from the stream.", num));
		}
		if (num <= GClass25.int_2)
		{
			this.method_0(Enum3.Binary, array, null);
			return;
		}
		this.method_1(Enum3.Binary, new MemoryStream(array), null);
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x000329B4 File Offset: 0x00030BB4
	public void method_19(byte[] byte_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		if ((long)byte_0.Length <= (long)GClass25.int_2)
		{
			this.method_2(Enum3.Binary, byte_0, action_0);
			return;
		}
		this.method_3(Enum3.Binary, new MemoryStream(byte_0), action_0);
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x00032A08 File Offset: 0x00030C08
	public void method_20(string string_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		if ((long)array.Length <= (long)GClass25.int_2)
		{
			this.method_2(Enum3.Text, array, action_0);
			return;
		}
		this.method_3(Enum3.Text, new MemoryStream(array), action_0);
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x00032A78 File Offset: 0x00030C78
	public void method_21(Stream stream_0, int int_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (stream_0 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream_0.CanRead)
		{
			throw new ArgumentException("It cannot be read.", "stream");
		}
		if (int_0 < 1)
		{
			throw new ArgumentException("Less than 1.", "length");
		}
		byte[] array = stream_0.smethod_54(int_0);
		int num = array.Length;
		if (num == 0)
		{
			throw new ArgumentException("No data could be read from it.", "stream");
		}
		if (num < int_0)
		{
			this.gclass24_0.method_6(string.Format("Only {0} byte(s) of data could be read from the stream.", num));
		}
		if (num <= GClass25.int_2)
		{
			this.method_2(Enum3.Binary, array, action_0);
			return;
		}
		this.method_3(Enum3.Binary, new MemoryStream(array), action_0);
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x000067C7 File Offset: 0x000049C7
	[Obsolete("This method will be removed.")]
	public Dictionary<string, bool> method_22()
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		return this.method_12(Class42.byte_3, this.timeSpan_0);
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x00032B34 File Offset: 0x00030D34
	[Obsolete("This method will be removed.")]
	public Dictionary<string, bool> method_23(string string_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0.smethod_88())
		{
			return this.method_12(Class42.byte_3, this.timeSpan_0);
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "message");
		}
		if (array.Length > 125)
		{
			string message = "Its size is greater than 125 bytes.";
			throw new ArgumentOutOfRangeException("message", message);
		}
		Class42 @class = Class42.smethod_15(array, false);
		return this.method_12(@class.method_3(), this.timeSpan_0);
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x00032BC0 File Offset: 0x00030DC0
	public void method_24(string string_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_72();
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x00032BF4 File Offset: 0x00030DF4
	public void method_25(string string_0, ushort ushort_0, string string_1)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_75(ushort_0, string_1);
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x00032C2C File Offset: 0x00030E2C
	public void method_26(string string_0, GEnum6 genum6_0, string string_1)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_76(genum6_0, string_1);
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x00032C64 File Offset: 0x00030E64
	public bool method_27(string string_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		return ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_84();
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x00032C98 File Offset: 0x00030E98
	public bool method_28(string string_0, string string_1)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_1, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		return ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_85(string_0);
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x00032CCC File Offset: 0x00030ECC
	public void method_29(byte[] byte_0, string string_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_86(byte_0);
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x00032D00 File Offset: 0x00030F00
	public void method_30(string string_0, string string_1)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_1, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_88(string_0);
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x00032D34 File Offset: 0x00030F34
	public void method_31(Stream stream_0, int int_0, string string_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_89(stream_0, int_0);
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x00032D6C File Offset: 0x00030F6C
	public void method_32(byte[] byte_0, string string_0, Action<bool> action_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_90(byte_0, action_0);
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x00032DA4 File Offset: 0x00030FA4
	public void method_33(string string_0, string string_1, Action<bool> action_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_1, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_92(string_0, action_0);
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x00032DDC File Offset: 0x00030FDC
	public void method_34(Stream stream_0, int int_0, string string_0, Action<bool> action_0)
	{
		GInterface0 ginterface;
		if (!this.method_36(string_0, out ginterface))
		{
			throw new InvalidOperationException("The session could not be found.");
		}
		ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_93(stream_0, int_0, action_0);
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x00032E14 File Offset: 0x00031014
	public void method_35()
	{
		if (this.bool_1)
		{
			this.gclass24_0.method_4("The sweeping is already in progress.");
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.bool_1)
			{
				this.gclass24_0.method_4("The sweeping is already in progress.");
				return;
			}
			this.bool_1 = true;
		}
		foreach (string key in this.IEnumerable_2)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				break;
			}
			obj = this.object_1;
			lock (obj)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					break;
				}
				GInterface0 ginterface;
				if (this.dictionary_0.TryGetValue(key, out ginterface))
				{
					GEnum8 genum8_ = ginterface.GEnum8_0;
					if (genum8_ == GEnum8.Open)
					{
						ginterface.GClass46_0.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_74(GEnum6.Abnormal);
					}
					else if (genum8_ != GEnum8.Closing)
					{
						this.dictionary_0.Remove(key);
					}
				}
			}
		}
		this.bool_1 = false;
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x000067F0 File Offset: 0x000049F0
	public bool method_36(string string_0, out GInterface0 ginterface0_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("id");
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("An empty string.", "id");
		}
		return this.method_8(string_0, out ginterface0_0);
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x00006820 File Offset: 0x00004A20
	[CompilerGenerated]
	private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
	{
		this.method_35();
	}

	// Token: 0x040002B8 RID: 696
	private volatile bool bool_0;

	// Token: 0x040002B9 RID: 697
	private object object_0;

	// Token: 0x040002BA RID: 698
	private GClass24 gclass24_0;

	// Token: 0x040002BB RID: 699
	private Dictionary<string, GInterface0> dictionary_0;

	// Token: 0x040002BC RID: 700
	private volatile Enum5 enum5_0;

	// Token: 0x040002BD RID: 701
	private volatile bool bool_1;

	// Token: 0x040002BE RID: 702
	private System.Timers.Timer timer_0;

	// Token: 0x040002BF RID: 703
	private object object_1;

	// Token: 0x040002C0 RID: 704
	private TimeSpan timeSpan_0;

	// Token: 0x0200007B RID: 123
	[CompilerGenerated]
	private sealed class Class60
	{
		// Token: 0x06000593 RID: 1427 RVA: 0x000068B0 File Offset: 0x00004AB0
		internal void method_0(object object_0)
		{
			this.gclass31_0.method_0(this.enum3_0, this.byte_0, this.action_0);
		}

		// Token: 0x040002CB RID: 715
		public GClass31 gclass31_0;

		// Token: 0x040002CC RID: 716
		public Enum3 enum3_0;

		// Token: 0x040002CD RID: 717
		public byte[] byte_0;

		// Token: 0x040002CE RID: 718
		public Action action_0;
	}

	// Token: 0x0200007C RID: 124
	[CompilerGenerated]
	private sealed class Class61
	{
		// Token: 0x06000595 RID: 1429 RVA: 0x000068CF File Offset: 0x00004ACF
		internal void method_0(object object_0)
		{
			this.gclass31_0.method_1(this.enum3_0, this.stream_0, this.action_0);
		}

		// Token: 0x040002CF RID: 719
		public GClass31 gclass31_0;

		// Token: 0x040002D0 RID: 720
		public Enum3 enum3_0;

		// Token: 0x040002D1 RID: 721
		public Stream stream_0;

		// Token: 0x040002D2 RID: 722
		public Action action_0;
	}
}
