﻿using System;
using System.Globalization;
using System.Text;

// Token: 0x02000086 RID: 134
[Serializable]
public sealed class GClass33
{
	// Token: 0x060005F3 RID: 1523 RVA: 0x00006D28 File Offset: 0x00004F28
	internal GClass33()
	{
		this.method_0(string.Empty, string.Empty, string.Empty, string.Empty);
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x00006D4A File Offset: 0x00004F4A
	public GClass33(string string_0, string string_1) : this(string_0, string_1, string.Empty, string.Empty)
	{
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x00006D5E File Offset: 0x00004F5E
	public GClass33(string string_0, string string_1, string string_2) : this(string_0, string_1, string_2, string.Empty)
	{
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x0003434C File Offset: 0x0003254C
	public GClass33(string string_0, string string_1, string string_2, string string_3)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("An empty string.", "name");
		}
		if (string_0[0] == '$')
		{
			throw new ArgumentException("It starts with a dollar sign.", "name");
		}
		if (!string_0.smethod_51())
		{
			throw new ArgumentException("It contains an invalid character.", "name");
		}
		if (string_1 == null)
		{
			string_1 = string.Empty;
		}
		if (string_1.smethod_14(GClass33._reservedCharsForValue) && !string_1.smethod_85('"'))
		{
			throw new ArgumentException("A string not enclosed in double quotes.", "value");
		}
		this.method_0(string_0, string_1, string_2 ?? string.Empty, string_3 ?? string.Empty);
	}

	// Token: 0x17000184 RID: 388
	// (get) Token: 0x060005F7 RID: 1527 RVA: 0x00006D6E File Offset: 0x00004F6E
	internal bool Boolean_0
	{
		get
		{
			return this._domain.Length == 0 || this._domain[0] != '.';
		}
	}

	// Token: 0x17000185 RID: 389
	// (get) Token: 0x060005F8 RID: 1528 RVA: 0x00034408 File Offset: 0x00032608
	// (set) Token: 0x060005F9 RID: 1529 RVA: 0x0003446C File Offset: 0x0003266C
	internal int Int32_0
	{
		get
		{
			if (this._expires == DateTime.MinValue)
			{
				return 0;
			}
			TimeSpan t = ((this._expires.Kind != DateTimeKind.Local) ? this._expires.ToLocalTime() : this._expires) - DateTime.Now;
			if (!(t > TimeSpan.Zero))
			{
				return 0;
			}
			return (int)t.TotalSeconds;
		}
		set
		{
			this._expires = ((value > 0) ? DateTime.Now.AddSeconds((double)value) : DateTime.Now);
		}
	}

	// Token: 0x17000186 RID: 390
	// (get) Token: 0x060005FA RID: 1530 RVA: 0x00006D92 File Offset: 0x00004F92
	internal int[] Int32_1
	{
		get
		{
			return this._ports ?? GClass33._emptyPorts;
		}
	}

	// Token: 0x17000187 RID: 391
	// (get) Token: 0x060005FB RID: 1531 RVA: 0x00006DA3 File Offset: 0x00004FA3
	// (set) Token: 0x060005FC RID: 1532 RVA: 0x00006DAB File Offset: 0x00004FAB
	internal string String_0
	{
		get
		{
			return this._sameSite;
		}
		set
		{
			this._sameSite = value;
		}
	}

	// Token: 0x17000188 RID: 392
	// (get) Token: 0x060005FD RID: 1533 RVA: 0x00006DB4 File Offset: 0x00004FB4
	// (set) Token: 0x060005FE RID: 1534 RVA: 0x00006DBC File Offset: 0x00004FBC
	public string String_1
	{
		get
		{
			return this._comment;
		}
		internal set
		{
			this._comment = value;
		}
	}

	// Token: 0x17000189 RID: 393
	// (get) Token: 0x060005FF RID: 1535 RVA: 0x00006DC5 File Offset: 0x00004FC5
	// (set) Token: 0x06000600 RID: 1536 RVA: 0x00006DCD File Offset: 0x00004FCD
	public Uri Uri_0
	{
		get
		{
			return this._commentUri;
		}
		internal set
		{
			this._commentUri = value;
		}
	}

	// Token: 0x1700018A RID: 394
	// (get) Token: 0x06000601 RID: 1537 RVA: 0x00006DD6 File Offset: 0x00004FD6
	// (set) Token: 0x06000602 RID: 1538 RVA: 0x00006DDE File Offset: 0x00004FDE
	public bool Boolean_1
	{
		get
		{
			return this._discard;
		}
		internal set
		{
			this._discard = value;
		}
	}

	// Token: 0x1700018B RID: 395
	// (get) Token: 0x06000603 RID: 1539 RVA: 0x00006DE7 File Offset: 0x00004FE7
	// (set) Token: 0x06000604 RID: 1540 RVA: 0x00006DEF File Offset: 0x00004FEF
	public string String_2
	{
		get
		{
			return this._domain;
		}
		set
		{
			this._domain = (value ?? string.Empty);
		}
	}

	// Token: 0x1700018C RID: 396
	// (get) Token: 0x06000605 RID: 1541 RVA: 0x00006E01 File Offset: 0x00005001
	// (set) Token: 0x06000606 RID: 1542 RVA: 0x00006E27 File Offset: 0x00005027
	public bool Boolean_2
	{
		get
		{
			return this._expires != DateTime.MinValue && this._expires <= DateTime.Now;
		}
		set
		{
			this._expires = (value ? DateTime.Now : DateTime.MinValue);
		}
	}

	// Token: 0x1700018D RID: 397
	// (get) Token: 0x06000607 RID: 1543 RVA: 0x00006E3E File Offset: 0x0000503E
	// (set) Token: 0x06000608 RID: 1544 RVA: 0x00006E46 File Offset: 0x00005046
	public DateTime DateTime_0
	{
		get
		{
			return this._expires;
		}
		set
		{
			this._expires = value;
		}
	}

	// Token: 0x1700018E RID: 398
	// (get) Token: 0x06000609 RID: 1545 RVA: 0x00006E4F File Offset: 0x0000504F
	// (set) Token: 0x0600060A RID: 1546 RVA: 0x00006E57 File Offset: 0x00005057
	public bool Boolean_3
	{
		get
		{
			return this._httpOnly;
		}
		set
		{
			this._httpOnly = value;
		}
	}

	// Token: 0x1700018F RID: 399
	// (get) Token: 0x0600060B RID: 1547 RVA: 0x00006E60 File Offset: 0x00005060
	// (set) Token: 0x0600060C RID: 1548 RVA: 0x0003449C File Offset: 0x0003269C
	public string String_3
	{
		get
		{
			return this._name;
		}
		set
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (value.Length == 0)
			{
				throw new ArgumentException("An empty string.", "value");
			}
			if (value[0] == '$')
			{
				throw new ArgumentException("It starts with a dollar sign.", "value");
			}
			if (!value.smethod_51())
			{
				throw new ArgumentException("It contains an invalid character.", "value");
			}
			this._name = value;
		}
	}

	// Token: 0x17000190 RID: 400
	// (get) Token: 0x0600060D RID: 1549 RVA: 0x00006E68 File Offset: 0x00005068
	// (set) Token: 0x0600060E RID: 1550 RVA: 0x00006E70 File Offset: 0x00005070
	public string String_4
	{
		get
		{
			return this._path;
		}
		set
		{
			this._path = (value ?? string.Empty);
		}
	}

	// Token: 0x17000191 RID: 401
	// (get) Token: 0x0600060F RID: 1551 RVA: 0x00006E82 File Offset: 0x00005082
	// (set) Token: 0x06000610 RID: 1552 RVA: 0x0003450C File Offset: 0x0003270C
	public string String_5
	{
		get
		{
			return this._port;
		}
		internal set
		{
			int[] ports;
			if (!GClass33.smethod_1(value, out ports))
			{
				return;
			}
			this._port = value;
			this._ports = ports;
		}
	}

	// Token: 0x17000192 RID: 402
	// (get) Token: 0x06000611 RID: 1553 RVA: 0x00006E8A File Offset: 0x0000508A
	// (set) Token: 0x06000612 RID: 1554 RVA: 0x00006E92 File Offset: 0x00005092
	public bool Boolean_4
	{
		get
		{
			return this._secure;
		}
		set
		{
			this._secure = value;
		}
	}

	// Token: 0x17000193 RID: 403
	// (get) Token: 0x06000613 RID: 1555 RVA: 0x00006E9B File Offset: 0x0000509B
	public DateTime DateTime_1
	{
		get
		{
			return this._timeStamp;
		}
	}

	// Token: 0x17000194 RID: 404
	// (get) Token: 0x06000614 RID: 1556 RVA: 0x00006EA3 File Offset: 0x000050A3
	// (set) Token: 0x06000615 RID: 1557 RVA: 0x00006EAB File Offset: 0x000050AB
	public string String_6
	{
		get
		{
			return this._value;
		}
		set
		{
			if (value == null)
			{
				value = string.Empty;
			}
			if (value.smethod_14(GClass33._reservedCharsForValue) && !value.smethod_85('"'))
			{
				throw new ArgumentException("A string not enclosed in double quotes.", "value");
			}
			this._value = value;
		}
	}

	// Token: 0x17000195 RID: 405
	// (get) Token: 0x06000616 RID: 1558 RVA: 0x00006EE5 File Offset: 0x000050E5
	// (set) Token: 0x06000617 RID: 1559 RVA: 0x00006EED File Offset: 0x000050ED
	public int Int32_2
	{
		get
		{
			return this._version;
		}
		internal set
		{
			if (value >= 0 && value <= 1)
			{
				this._version = value;
				return;
			}
		}
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x00006EFF File Offset: 0x000050FF
	private static int smethod_0(int int_0, int int_1, int int_2, int int_3, int int_4)
	{
		return int_0 ^ (int_1 << 13 | int_1 >> 19) ^ (int_2 << 26 | int_2 >> 6) ^ (int_3 << 7 | int_3 >> 25) ^ (int_4 << 20 | int_4 >> 12);
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x00006F2A File Offset: 0x0000512A
	private void method_0(string string_0, string string_1, string string_2, string string_3)
	{
		this._name = string_0;
		this._value = string_1;
		this._path = string_2;
		this._domain = string_3;
		this._expires = DateTime.MinValue;
		this._timeStamp = DateTime.Now;
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x00034534 File Offset: 0x00032734
	private string method_1()
	{
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("{0}={1}", this._name, this._value);
		if (this._expires != DateTime.MinValue)
		{
			stringBuilder.AppendFormat("; Expires={0}", this._expires.ToUniversalTime().ToString("ddd, dd'-'MMM'-'yyyy HH':'mm':'ss 'GMT'", CultureInfo.CreateSpecificCulture("en-US")));
		}
		if (!this._path.smethod_88())
		{
			stringBuilder.AppendFormat("; Path={0}", this._path);
		}
		if (!this._domain.smethod_88())
		{
			stringBuilder.AppendFormat("; Domain={0}", this._domain);
		}
		if (!this._sameSite.smethod_88())
		{
			stringBuilder.AppendFormat("; SameSite={0}", this._sameSite);
		}
		if (this._secure)
		{
			stringBuilder.Append("; Secure");
		}
		if (this._httpOnly)
		{
			stringBuilder.Append("; HttpOnly");
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x0003462C File Offset: 0x0003282C
	private string method_2()
	{
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("{0}={1}; Version={2}", this._name, this._value, this._version);
		if (this._expires != DateTime.MinValue)
		{
			stringBuilder.AppendFormat("; Max-Age={0}", this.Int32_0);
		}
		if (!this._path.smethod_88())
		{
			stringBuilder.AppendFormat("; Path={0}", this._path);
		}
		if (!this._domain.smethod_88())
		{
			stringBuilder.AppendFormat("; Domain={0}", this._domain);
		}
		if (this._port != null)
		{
			if (this._port != "\"\"")
			{
				stringBuilder.AppendFormat("; Port={0}", this._port);
			}
			else
			{
				stringBuilder.Append("; Port");
			}
		}
		if (this._comment != null)
		{
			stringBuilder.AppendFormat("; Comment={0}", Class78.smethod_33(this._comment));
		}
		if (this._commentUri != null)
		{
			string originalString = this._commentUri.OriginalString;
			stringBuilder.AppendFormat("; CommentURL={0}", (!originalString.smethod_51()) ? originalString.smethod_53() : originalString);
		}
		if (this._discard)
		{
			stringBuilder.Append("; Discard");
		}
		if (this._secure)
		{
			stringBuilder.Append("; Secure");
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x0003478C File Offset: 0x0003298C
	private static bool smethod_1(string string_0, out int[] int_0)
	{
		int_0 = null;
		string[] array = string_0.Trim(new char[]
		{
			'"'
		}).Split(new char[]
		{
			','
		});
		int num = array.Length;
		int[] array2 = new int[num];
		for (int i = 0; i < num; i++)
		{
			string text = array[i].Trim();
			if (text.Length == 0)
			{
				array2[i] = int.MinValue;
			}
			else if (!int.TryParse(text, out array2[i]))
			{
				return false;
			}
		}
		int_0 = array2;
		return true;
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x00034808 File Offset: 0x00032A08
	internal bool method_3(GClass33 gclass33_0)
	{
		StringComparison comparisonType = StringComparison.InvariantCulture;
		StringComparison comparisonType2 = StringComparison.InvariantCultureIgnoreCase;
		return this._name.Equals(gclass33_0._name, StringComparison.InvariantCultureIgnoreCase) && this._path.Equals(gclass33_0._path, comparisonType) && this._domain.Equals(gclass33_0._domain, comparisonType2) && this._version == gclass33_0._version;
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x00034868 File Offset: 0x00032A68
	internal bool method_4(GClass33 gclass33_0)
	{
		StringComparison comparisonType = StringComparison.InvariantCulture;
		StringComparison comparisonType2 = StringComparison.InvariantCultureIgnoreCase;
		return this._name.Equals(gclass33_0._name, StringComparison.InvariantCultureIgnoreCase) && this._path.Equals(gclass33_0._path, comparisonType) && this._domain.Equals(gclass33_0._domain, comparisonType2);
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x000348B8 File Offset: 0x00032AB8
	internal string method_5(Uri uri_0)
	{
		if (this._name.Length == 0)
		{
			return string.Empty;
		}
		if (this._version == 0)
		{
			return string.Format("{0}={1}", this._name, this._value);
		}
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("$Version={0}; {1}={2}", this._version, this._name, this._value);
		if (!this._path.smethod_88())
		{
			stringBuilder.AppendFormat("; $Path={0}", this._path);
		}
		else if (uri_0 != null)
		{
			stringBuilder.AppendFormat("; $Path={0}", uri_0.smethod_29());
		}
		else
		{
			stringBuilder.Append("; $Path=/");
		}
		if (!this._domain.smethod_88() && (uri_0 == null || uri_0.Host != this._domain))
		{
			stringBuilder.AppendFormat("; $Domain={0}", this._domain);
		}
		if (this._port != null)
		{
			if (this._port != "\"\"")
			{
				stringBuilder.AppendFormat("; $Port={0}", this._port);
			}
			else
			{
				stringBuilder.Append("; $Port");
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x00006F5F File Offset: 0x0000515F
	internal string method_6()
	{
		if (this._name.Length == 0)
		{
			return string.Empty;
		}
		if (this._version != 0)
		{
			return this.method_2();
		}
		return this.method_1();
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x000349E8 File Offset: 0x00032BE8
	internal static bool smethod_2(string string_0, string string_1, out GClass33 gclass33_0)
	{
		gclass33_0 = null;
		bool result;
		try
		{
			gclass33_0 = new GClass33(string_0, string_1);
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x00034A1C File Offset: 0x00032C1C
	public bool Equals(object obj)
	{
		GClass33 gclass = obj as GClass33;
		if (gclass == null)
		{
			return false;
		}
		StringComparison comparisonType = StringComparison.InvariantCulture;
		StringComparison comparisonType2 = StringComparison.InvariantCultureIgnoreCase;
		return this._name.Equals(gclass._name, StringComparison.InvariantCultureIgnoreCase) && this._value.Equals(gclass._value, comparisonType) && this._path.Equals(gclass._path, comparisonType) && this._domain.Equals(gclass._domain, comparisonType2) && this._version == gclass._version;
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x00034A9C File Offset: 0x00032C9C
	public int GetHashCode()
	{
		return GClass33.smethod_0(StringComparer.InvariantCultureIgnoreCase.GetHashCode(this._name), this._value.GetHashCode(), this._path.GetHashCode(), StringComparer.InvariantCultureIgnoreCase.GetHashCode(this._domain), this._version);
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x00006F89 File Offset: 0x00005189
	public string ToString()
	{
		return this.method_5(null);
	}

	// Token: 0x040002F3 RID: 755
	private string _comment;

	// Token: 0x040002F4 RID: 756
	private Uri _commentUri;

	// Token: 0x040002F5 RID: 757
	private bool _discard;

	// Token: 0x040002F6 RID: 758
	private string _domain;

	// Token: 0x040002F7 RID: 759
	private static readonly int[] _emptyPorts = new int[0];

	// Token: 0x040002F8 RID: 760
	private DateTime _expires;

	// Token: 0x040002F9 RID: 761
	private bool _httpOnly;

	// Token: 0x040002FA RID: 762
	private string _name;

	// Token: 0x040002FB RID: 763
	private string _path;

	// Token: 0x040002FC RID: 764
	private string _port;

	// Token: 0x040002FD RID: 765
	private int[] _ports;

	// Token: 0x040002FE RID: 766
	private static readonly char[] _reservedCharsForValue = new char[]
	{
		';',
		','
	};

	// Token: 0x040002FF RID: 767
	private string _sameSite;

	// Token: 0x04000300 RID: 768
	private bool _secure;

	// Token: 0x04000301 RID: 769
	private DateTime _timeStamp;

	// Token: 0x04000302 RID: 770
	private string _value;

	// Token: 0x04000303 RID: 771
	private int _version;
}
