﻿using System;

// Token: 0x020002A9 RID: 681
internal class Class367
{
	// Token: 0x17000841 RID: 2113
	// (get) Token: 0x0600262F RID: 9775 RVA: 0x0001C74E File Offset: 0x0001A94E
	public static string String_0
	{
		get
		{
			return "Đường Gia Bảo";
		}
	}

	// Token: 0x040019B3 RID: 6579
	public static int int_0 = 615;

	// Token: 0x040019B4 RID: 6580
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 170,
		Int32_1 = 32,
		Int32_2 = Class367.int_0,
		String_2 = "Đường Chử Cơ"
	};

	// Token: 0x040019B5 RID: 6581
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 78,
		Int32_1 = 35,
		Int32_2 = Class367.int_0,
		String_2 = "Đường Xích Phong"
	};

	// Token: 0x040019B6 RID: 6582
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 100,
		Int32_1 = 64,
		Int32_2 = Class367.int_0,
		String_2 = "Đường Thanh Thu"
	};

	// Token: 0x040019B7 RID: 6583
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 38,
		Int32_1 = 75,
		Int32_2 = Class367.int_0,
		String_2 = "Đường Nhạc Xung"
	};
}
