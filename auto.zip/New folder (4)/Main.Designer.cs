﻿// Token: 0x02000236 RID: 566
internal partial class Main : global::System.Windows.Forms.Form
{
	// Token: 0x060021FA RID: 8698 RVA: 0x000EF9F0 File Offset: 0x000EDBF0
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.Windows.Forms.ListViewItem listViewItem = new global::System.Windows.Forms.ListViewItem("Nhặt Đồ");
		global::System.Windows.Forms.ListViewItem listViewItem2 = new global::System.Windows.Forms.ListViewItem("Nhặt Hộp");
		global::System.Windows.Forms.ListViewItem listViewItem3 = new global::System.Windows.Forms.ListViewItem("Nhặt Tuyết");
		global::System.Windows.Forms.ListViewItem listViewItem4 = new global::System.Windows.Forms.ListViewItem("Tự Reset Time");
		global::System.Windows.Forms.ListViewItem listViewItem5 = new global::System.Windows.Forms.ListViewItem("Tự Dùng x4");
		global::System.Windows.Forms.ListViewItem listViewItem6 = new global::System.Windows.Forms.ListViewItem("x2, x3 Võ Ý");
		global::System.Windows.Forms.ListViewItem listViewItem7 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F1",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem8 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F2",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem9 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F3",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem10 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F4",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem11 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F5",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem12 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F6",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem13 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F7",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem14 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F8",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem15 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F9",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem16 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F10",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem17 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F11",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem18 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"F12",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem19 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt1",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem20 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt2",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem21 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt3",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem22 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt4",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem23 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt5",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem24 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt6",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem25 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt7",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem26 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt8",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem27 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt9",
			"1"
		}, -1);
		global::System.Windows.Forms.ListViewItem listViewItem28 = new global::System.Windows.Forms.ListViewItem(new string[]
		{
			"Alt0",
			"1"
		}, -1);
		this.notifyIcon_0 = new global::System.Windows.Forms.NotifyIcon(this.icontainer_0);
		this.menuIcon = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_26 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_34 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_17 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator15 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_10 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMute = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuExit = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuListView = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.menuHideGame = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuShowGame = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuExitGame = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_202 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator18 = new global::System.Windows.Forms.ToolStripSeparator();
		this.gomToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_146 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_147 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_148 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.treoShopChoTaToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_163 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDuaTangBaoDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_201 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_6 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuTrieuTapNhom = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuMoiDoi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuTrieuTap = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator58 = new global::System.Windows.Forms.ToolStripSeparator();
		this.menuSetNhom = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_18 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_49 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_54 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQuanLyNhom = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_50 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuAutoCreateTeam = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator3 = new global::System.Windows.Forms.ToolStripSeparator();
		this.menuCreateTeam = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muGiaiTan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_0 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_3 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_4 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_14 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator38 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_5 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_15 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_12 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_21 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator34 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_151 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_152 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_153 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_154 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_155 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_156 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_157 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_158 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_159 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_160 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_161 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_162 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_175 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_176 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_177 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_178 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_171 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_172 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_173 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_174 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_179 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_180 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_181 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_189 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_194 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muaX2ToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_195 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_200 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_196 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_197 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem52 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQThuCong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQBinhThanhThuCong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator33 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muCQYenTuO = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQTuTuyetTrang = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQSatTinh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQPhieuMieuPhong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQThieuThatSon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQBinhThanh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQBinhThanhKho = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQVuongLang = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQTamThan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQKhieuChienPMP = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQPhucDia = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCQPhucDiaKho = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_24 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem38 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_203 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQuayVeDaiLy = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator14 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_190 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_191 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator11 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_192 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.thuPetToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator6 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muDemBut = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muChucPhuc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator16 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muKetNghia = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muChucPhucTuBaoBon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator26 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muAutoMap = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_19 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator7 = new global::System.Windows.Forms.ToolStripSeparator();
		this.menuRefreshAuto = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuResetTime = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator9 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muNhapCode = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuDebug = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_38 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_39 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_40 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_41 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.bangToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_42 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_1 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.toolTip_0 = new global::System.Windows.Forms.ToolTip(this.icontainer_0);
		this.lbAcBa = new global::System.Windows.Forms.Label();
		this.lbExpSpeed = new global::System.Windows.Forms.Label();
		this.lblTimeInfo = new global::System.Windows.Forms.Label();
		this.lbHoaSpeed = new global::System.Windows.Forms.Label();
		this.button13 = new global::System.Windows.Forms.Button();
		this.label4 = new global::System.Windows.Forms.Label();
		this.checkChetLenBai = new global::System.Windows.Forms.CheckBox();
		this.checkChiNhat = new global::System.Windows.Forms.CheckBox();
		this.cboPlayer = new global::System.Windows.Forms.ComboBox();
		this.nudBuffPet = new global::System.Windows.Forms.NumericUpDown();
		this.checkTuyenChien = new global::System.Windows.Forms.CheckBox();
		this.checkQuyCoc = new global::System.Windows.Forms.CheckBox();
		this.numericUpDown2 = new global::System.Windows.Forms.NumericUpDown();
		this.lblTrain = new global::System.Windows.Forms.Label();
		this.checkChiDanh = new global::System.Windows.Forms.CheckBox();
		this.checkHP = new global::System.Windows.Forms.CheckBox();
		this.nudNM = new global::System.Windows.Forms.NumericUpDown();
		this.lblRadius = new global::System.Windows.Forms.Label();
		this.nudRadius = new global::System.Windows.Forms.NumericUpDown();
		this.checkLuaQuai = new global::System.Windows.Forms.CheckBox();
		this.checkTimQuai = new global::System.Windows.Forms.CheckBox();
		this.checkPet = new global::System.Windows.Forms.CheckBox();
		this.checkNM = new global::System.Windows.Forms.CheckBox();
		this.nudHP = new global::System.Windows.Forms.NumericUpDown();
		this.checkMP = new global::System.Windows.Forms.CheckBox();
		this.nudMP = new global::System.Windows.Forms.NumericUpDown();
		this.numberThuHoaX = new global::System.Windows.Forms.NumericUpDown();
		this.numberRadiusThuHoa = new global::System.Windows.Forms.NumericUpDown();
		this.nudTangTiemNang = new global::System.Windows.Forms.NumericUpDown();
		this.checkHaiDuoc = new global::System.Windows.Forms.CheckBox();
		this.checkTrongTrot = new global::System.Windows.Forms.CheckBox();
		this.checkThuHoach = new global::System.Windows.Forms.CheckBox();
		this.checkXuatPet = new global::System.Windows.Forms.CheckBox();
		this.checkKhaiKhoang = new global::System.Windows.Forms.CheckBox();
		this.chkRaoVat = new global::System.Windows.Forms.CheckBox();
		this.txtRao = new global::Class85();
		this.chkBanRac = new global::System.Windows.Forms.CheckBox();
		this.chkBinhThanh = new global::System.Windows.Forms.CheckBox();
		this.chkKho = new global::System.Windows.Forms.CheckBox();
		this.chkPhieuMieuPhong = new global::System.Windows.Forms.CheckBox();
		this.chkTamThan = new global::System.Windows.Forms.CheckBox();
		this.chkYenTuO = new global::System.Windows.Forms.CheckBox();
		this.chkQLauLan = new global::System.Windows.Forms.CheckBox();
		this.chkPhucDia = new global::System.Windows.Forms.CheckBox();
		this.chkSatTinh = new global::System.Windows.Forms.CheckBox();
		this.chkHuyetChien = new global::System.Windows.Forms.CheckBox();
		this.chkPDKho = new global::System.Windows.Forms.CheckBox();
		this.chkTuTuyetTrang = new global::System.Windows.Forms.CheckBox();
		this.chkQToChau = new global::System.Windows.Forms.CheckBox();
		this.chkVuongLang = new global::System.Windows.Forms.CheckBox();
		this.chkThieuThatSon = new global::System.Windows.Forms.CheckBox();
		this.chkAutoDropCraft = new global::System.Windows.Forms.CheckBox();
		this.nudStar = new global::System.Windows.Forms.NumericUpDown();
		this.nudLine = new global::System.Windows.Forms.NumericUpDown();
		this.nudPoint = new global::System.Windows.Forms.NumericUpDown();
		this.chkStartCraft = new global::System.Windows.Forms.CheckBox();
		this.chkMuaNguyenLieu = new global::System.Windows.Forms.CheckBox();
		this.chkGiamDinh = new global::System.Windows.Forms.CheckBox();
		this.timer_2 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_1 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_2 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_3 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_4 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_5 = new global::System.Windows.Forms.ColumnHeader();
		this.timer_3 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_4 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.backgroundWorker_0 = new global::System.ComponentModel.BackgroundWorker();
		this.mainMenu = new global::System.Windows.Forms.MenuStrip();
		this.playerToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTriLieu = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDiBanRac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThuongKho = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_145 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCatDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLayDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLayDoLayVang = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_25 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTriLieuBanRacCatDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muPhanGiaiTrangBijPet = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator17 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muNhanDoi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoShop = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoShopTrungDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoShopHungBa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoShopBachBaoCac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoShopQuyThi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMoTiemThuoc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuTuLuyen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuLuyenTheLuc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuLuyenNoiLuc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuLuyenThanPhap = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuLuyenCuongLuc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuLuyenTheNoiThan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_165 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_193 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_166 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_198 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_167 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_199 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_168 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_169 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_170 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanx2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDongx2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDiMuaNgua = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muHuyVatPhamQuy = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNopTuViHuyTinh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThanhLyNhiemVu = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muGiaoNguHanhPhapThiep = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTangCapTruongThanhLongVan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCheThanKhi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_47 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_182 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_183 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMua100KimSangDuoc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_46 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muSuaVoHon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muSuaThanKhi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muSuaTrangBi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_44 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoiHuyenSacCauThienThai = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoiKimTamTy = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoi999HoaHong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoiLoanPhiMatHam = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoiChanNguyenLinhPhach = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoiTiemNangTan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDaiLeHungVuong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_45 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanChienCongKiemChi = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanThuongQuanSonHai = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanThuongTyVo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanBuaBaoRuong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanLeBao = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanBong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanKeoHallowen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLinhLuong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muBHD = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTrongHoa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muBonHoa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThuHoach = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator4 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTuoiHoaHong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanQuaBuiHoa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanHoaHongLo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator44 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_36 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_43 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.leaderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muAcTac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_22 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator21 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muVoLuongSon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muKinhHo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muKiemCac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThaiHo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTungSon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDonHoang = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muAcBa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_131 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator24 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_136 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_137 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_134 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_140 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_133 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_132 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_141 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_142 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_143 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.ngamyToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_135 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_138 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_139 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTangKinhCac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_23 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator22 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTayHo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhiHai = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanNam = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator40 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTucCau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLauLanTamBao = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLauLanTamBaoNhanh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLauLanTamBaoCham = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muKyCuoc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muKyCuocNhanh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muKyCuocCham = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator39 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muDaTru = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muMongHeo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThienGiangKyThu = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muPhungHoangLangMo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator30 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muPrivate = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQ1ToChau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQ2ToChau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQ12ToChau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThuyLao = new global::System.Windows.Forms.ToolStripMenuItem();
		this.traderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.bossMapToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_53 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.configToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muBaoDoHiem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDoanBaoMaTac = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_13 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem18 = new global::System.Windows.Forms.ToolStripSeparator();
		this.mnuKetNghia = new global::System.Windows.Forms.ToolStripMenuItem();
		this.mnuKeBaiSudo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator23 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTyVo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muQuanSonHai = new global::System.Windows.Forms.ToolStripMenuItem();
		this.dailyToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muHangNgay = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muToanBoHangNgay = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLoLyHoa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanPhiThuy = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanMay = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTueHong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNguyenVong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLuyenKim = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLuyenKimNhanh = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muLuyenKimCham = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuBaoBon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muSuMon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator36 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muMoBaoTangDo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTrungAc = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator32 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muCotTruyen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muCotTruyenToanBo = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhiemVuExp = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhiemVuKNB = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNgoChanNguyen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muChinhTuyen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVoY = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVoTuPho = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muConCai = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTuDuong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muPhuMau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muNhanCon = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_20 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator35 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muThienKiepLau = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muSinhTieu = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator37 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTiemNangTan = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muBachHoaDuyen = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThanhSangNhatHa = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muThanKhi9Sao = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muDungDoatBaoRuong = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanTieu = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanTieu1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanTieu2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanTieu3 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muVanTieu4 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTrangSucCuuLe = new global::System.Windows.Forms.ToolStripMenuItem();
		this.muTamKy = new global::System.Windows.Forms.ToolStripMenuItem();
		this.allToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.selectCtrlAToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.refreshToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator42 = new global::System.Windows.Forms.ToolStripSeparator();
		this.thuPetToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_188 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_184 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_185 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_186 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator5 = new global::System.Windows.Forms.ToolStripSeparator();
		this.toolStripMenuItem_9 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_7 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_8 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_150 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_204 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_51 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_144 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_187 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuNier = new global::System.Windows.Forms.ToolStripMenuItem();
		this.openGameToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem3 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem4 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameToolStripMenuItem5 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_11 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.selectPathToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator8 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTopMost = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator27 = new global::System.Windows.Forms.ToolStripSeparator();
		this.menuPickItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuItemFillter = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator28 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muForceFollow = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuFollowKey = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuAtkFollowKey = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator25 = new global::System.Windows.Forms.ToolStripSeparator();
		this.menuPause = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuPausedSkill = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
		this.autoPKToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripSeparator2 = new global::System.Windows.Forms.ToolStripSeparator();
		this.muTrimRam = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_16 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem30 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuGoTrieuTap = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_164 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_55 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_56 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_57 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_58 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_59 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_27 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_149 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_29 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_28 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_30 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_31 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_32 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_33 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_35 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_37 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_48 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_52 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem19 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.bossToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.longQuy16936ToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_60 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_118 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_119 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_61 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_62 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_63 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_64 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_120 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_121 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_122 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_123 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_124 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_125 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_126 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem20 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_75 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_76 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_77 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_78 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_79 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_80 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_81 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_82 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_83 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_65 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_66 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_67 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_68 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_69 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_70 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_71 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_72 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_73 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_74 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_84 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem53 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_85 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_86 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_87 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem54 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_88 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_89 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem55 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem56 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.xToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_112 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_113 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_114 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_115 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_110 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_111 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_127 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_117 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_128 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_116 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_90 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_91 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_92 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_93 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_94 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_95 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_96 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_97 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_98 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_99 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_100 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_101 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_102 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_103 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_104 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_105 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_106 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_107 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_108 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_109 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_129 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.toolStripMenuItem_130 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.backgroundWorker_1 = new global::System.ComponentModel.BackgroundWorker();
		this.timer_5 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_6 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.timer_7 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.Container = new global::System.Windows.Forms.Panel();
		this.tab = new global::Control1();
		this.tabGame = new global::System.Windows.Forms.TabPage();
		this.panMain = new global::System.Windows.Forms.Panel();
		this.panTop = new global::System.Windows.Forms.Panel();
		this.panel3 = new global::System.Windows.Forms.Panel();
		this.Lv = new global::_i.ListViewEx();
		this.columnHeader_10 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_11 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_24 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_12 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_13 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_14 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_15 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_16 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_17 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_18 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_19 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_20 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_21 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_22 = new global::System.Windows.Forms.ColumnHeader();
		this.gameInfo = new global::GameInfo();
		this.txtMainSearch = new global::Class85();
		this.panBottom = new global::System.Windows.Forms.Panel();
		this.tabBottom = new global::Control1();
		this.tabBuff = new global::System.Windows.Forms.TabPage();
		this.flowLayoutPanel1 = new global::System.Windows.Forms.FlowLayoutPanel();
		this.btnAdd = new global::System.Windows.Forms.Button();
		this.btnPk = new global::System.Windows.Forms.Button();
		this.checkBanKinh = new global::System.Windows.Forms.CheckBox();
		this.cboBaseSkill = new global::System.Windows.Forms.ComboBox();
		this.btnOnlyAttack = new global::System.Windows.Forms.Button();
		this.btnNM = new global::System.Windows.Forms.Button();
		this.cboNM = new global::System.Windows.Forms.ComboBox();
		this.cboHP = new global::System.Windows.Forms.ComboBox();
		this.tabLife = new global::System.Windows.Forms.TabPage();
		this.checkMuaKNB = new global::System.Windows.Forms.CheckBox();
		this.groupBox23 = new global::System.Windows.Forms.GroupBox();
		this.label10 = new global::System.Windows.Forms.Label();
		this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
		this.button10 = new global::System.Windows.Forms.Button();
		this.cboNgoc = new global::System.Windows.Forms.ComboBox();
		this.button18 = new global::System.Windows.Forms.Button();
		this.comboBox2 = new global::System.Windows.Forms.ComboBox();
		this.numberGiaKNB = new global::System.Windows.Forms.NumericUpDown();
		this.button3 = new global::System.Windows.Forms.Button();
		this.cboThuHoach = new global::System.Windows.Forms.ComboBox();
		this.groupBox25 = new global::System.Windows.Forms.GroupBox();
		this.button15 = new global::System.Windows.Forms.Button();
		this.cboTiemNang = new global::System.Windows.Forms.ComboBox();
		this.cboTrongTrot = new global::System.Windows.Forms.ComboBox();
		this.cboXuatPet = new global::System.Windows.Forms.ComboBox();
		this.btnOpenPass2 = new global::System.Windows.Forms.Button();
		this.label3 = new global::System.Windows.Forms.Label();
		this.txtPass2 = new global::Class85();
		this.button4 = new global::System.Windows.Forms.Button();
		this.btnTalkChannel = new global::System.Windows.Forms.Button();
		this.tabKey = new global::System.Windows.Forms.TabPage();
		this.tableLayoutPanel1 = new global::System.Windows.Forms.TableLayoutPanel();
		this.lvConfig = new global::_i.ListViewEx();
		this.columnHeader_8 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_9 = new global::System.Windows.Forms.ColumnHeader();
		this.panel5 = new global::System.Windows.Forms.Panel();
		this.listViewSkill = new global::Class398();
		this.columnHeader_6 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_7 = new global::System.Windows.Forms.ColumnHeader();
		this.txtSearchName = new global::Class85();
		this.tabQuest = new global::System.Windows.Forms.TabPage();
		this.btnCanQuetThuCong = new global::System.Windows.Forms.Button();
		this.button17 = new global::System.Windows.Forms.Button();
		this.tabCraft = new global::System.Windows.Forms.TabPage();
		this.splitContainer7 = new global::System.Windows.Forms.SplitContainer();
		this.groupBox1 = new global::System.Windows.Forms.GroupBox();
		this.label24 = new global::System.Windows.Forms.Label();
		this.label23 = new global::System.Windows.Forms.Label();
		this.label22 = new global::System.Windows.Forms.Label();
		this.groupBox3 = new global::System.Windows.Forms.GroupBox();
		this.cboLoai = new global::System.Windows.Forms.ComboBox();
		this.groupBox2 = new global::System.Windows.Forms.GroupBox();
		this.radNgoai = new global::System.Windows.Forms.RadioButton();
		this.radNoiNgoai = new global::System.Windows.Forms.RadioButton();
		this.radNoi = new global::System.Windows.Forms.RadioButton();
		this.groupBox15 = new global::System.Windows.Forms.GroupBox();
		this.cboCap = new global::System.Windows.Forms.ComboBox();
		this.tabSwitch = new global::System.Windows.Forms.TabPage();
		this.tabCanQuet = new global::Control1();
		this.tabCloseXanQuet = new global::System.Windows.Forms.TabPage();
		this.tabLogin = new global::System.Windows.Forms.TabPage();
		this.tabSetting = new global::System.Windows.Forms.TabPage();
		this.tabChat = new global::System.Windows.Forms.TabPage();
		this.tabControlEx1 = new global::Control1();
		this.tabPage2 = new global::System.Windows.Forms.TabPage();
		this.ricChat = new global::System.Windows.Forms.RichTextBox();
		this.textBoxEx2 = new global::Class85();
		this.panel4 = new global::System.Windows.Forms.Panel();
		this.label7 = new global::System.Windows.Forms.Label();
		this.label5 = new global::System.Windows.Forms.Label();
		this.tabPage3 = new global::System.Windows.Forms.TabPage();
		this.panInbox = new global::System.Windows.Forms.Panel();
		this.tabUser = new global::System.Windows.Forms.TabPage();
		this.picBank = new global::System.Windows.Forms.PictureBox();
		this.button1 = new global::System.Windows.Forms.Button();
		this.lblBeli = new global::System.Windows.Forms.Label();
		this.tabLog = new global::System.Windows.Forms.TabPage();
		this.groupBox27 = new global::System.Windows.Forms.GroupBox();
		this.ricExit = new global::System.Windows.Forms.RichTextBox();
		this.groupBox29 = new global::System.Windows.Forms.GroupBox();
		this.ricXong = new global::System.Windows.Forms.RichTextBox();
		this.groupBox28 = new global::System.Windows.Forms.GroupBox();
		this.ricMaTac = new global::System.Windows.Forms.RichTextBox();
		this.groupBox26 = new global::System.Windows.Forms.GroupBox();
		this.ricAcBa = new global::System.Windows.Forms.RichTextBox();
		this.columnHeader_23 = new global::System.Windows.Forms.ColumnHeader();
		this.tabPage1 = new global::System.Windows.Forms.TabPage();
		this.menuIcon.SuspendLayout();
		this.menuListView.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.nudBuffPet).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudNM).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRadius).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudHP).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudMP).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.numberThuHoaX).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.numberRadiusThuHoa).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudTangTiemNang).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudStar).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudLine).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudPoint).BeginInit();
		this.mainMenu.SuspendLayout();
		this.Container.SuspendLayout();
		this.tab.SuspendLayout();
		this.tabGame.SuspendLayout();
		this.panMain.SuspendLayout();
		this.panTop.SuspendLayout();
		this.panel3.SuspendLayout();
		this.panBottom.SuspendLayout();
		this.tabBottom.SuspendLayout();
		this.tabBuff.SuspendLayout();
		this.flowLayoutPanel1.SuspendLayout();
		this.tabLife.SuspendLayout();
		this.groupBox23.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.numberGiaKNB).BeginInit();
		this.groupBox25.SuspendLayout();
		this.tabKey.SuspendLayout();
		this.tableLayoutPanel1.SuspendLayout();
		this.panel5.SuspendLayout();
		this.tabQuest.SuspendLayout();
		this.tabCraft.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.splitContainer7).BeginInit();
		this.splitContainer7.Panel1.SuspendLayout();
		this.splitContainer7.Panel2.SuspendLayout();
		this.splitContainer7.SuspendLayout();
		this.groupBox1.SuspendLayout();
		this.groupBox3.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.groupBox15.SuspendLayout();
		this.tabCanQuet.SuspendLayout();
		this.tabChat.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage2.SuspendLayout();
		this.panel4.SuspendLayout();
		this.tabPage3.SuspendLayout();
		this.tabUser.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.picBank).BeginInit();
		this.tabLog.SuspendLayout();
		this.groupBox27.SuspendLayout();
		this.groupBox29.SuspendLayout();
		this.groupBox28.SuspendLayout();
		this.groupBox26.SuspendLayout();
		base.SuspendLayout();
		this.notifyIcon_0.ContextMenuStrip = this.menuIcon;
		this.notifyIcon_0.Text = "MicroAuto";
		this.notifyIcon_0.Visible = true;
		this.notifyIcon_0.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.notifyIcon_0_MouseClick);
		this.menuIcon.ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.menuIcon.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_26,
			this.toolStripMenuItem_34,
			this.toolStripMenuItem_17,
			this.toolStripSeparator15,
			this.toolStripMenuItem_10,
			this.muMute,
			this.menuExit
		});
		this.menuIcon.Name = "menuIcon";
		this.menuIcon.Size = new global::System.Drawing.Size(161, 142);
		this.menuIcon.Opening += new global::System.ComponentModel.CancelEventHandler(this.menuIcon_Opening);
		this.toolStripMenuItem_26.Name = "hiệnĐộiTrưởngToolStripMenuItem";
		this.toolStripMenuItem_26.Size = new global::System.Drawing.Size(160, 22);
		this.toolStripMenuItem_26.Text = "Hiện Đội Trưởng";
		this.toolStripMenuItem_26.Click += new global::System.EventHandler(this.toolStripMenuItem_26_Click);
		this.toolStripMenuItem_34.Name = "hủyBiếnThânToolStripMenuItem";
		this.toolStripMenuItem_34.Size = new global::System.Drawing.Size(160, 22);
		this.toolStripMenuItem_34.Text = "Hủy Biến Thân";
		this.toolStripMenuItem_34.Click += new global::System.EventHandler(this.toolStripMenuItem_34_Click);
		this.toolStripMenuItem_17.Name = "dọnRácToolStripMenuItem";
		this.toolStripMenuItem_17.Size = new global::System.Drawing.Size(160, 22);
		this.toolStripMenuItem_17.Text = "Dọn Rác";
		this.toolStripMenuItem_17.Click += new global::System.EventHandler(this.toolStripMenuItem_17_Click);
		this.toolStripSeparator15.Name = "toolStripSeparator15";
		this.toolStripSeparator15.Size = new global::System.Drawing.Size(157, 6);
		this.toolStripSeparator15.Visible = false;
		this.toolStripMenuItem_10.Name = "showPageUơToolStripMenuItem";
		this.toolStripMenuItem_10.Size = new global::System.Drawing.Size(160, 22);
		this.toolStripMenuItem_10.Text = "Show [PageUp]";
		this.toolStripMenuItem_10.Click += new global::System.EventHandler(this.toolStripMenuItem_10_Click);
		this.muMute.Name = "muMute";
		this.muMute.Size = new global::System.Drawing.Size(160, 22);
		this.muMute.Text = "Im Lặng";
		this.muMute.Click += new global::System.EventHandler(this.muMute_Click);
		this.menuExit.Name = "menuExit";
		this.menuExit.Size = new global::System.Drawing.Size(160, 22);
		this.menuExit.Text = "Exit";
		this.menuExit.Click += new global::System.EventHandler(this.menuExit_Click);
		this.menuListView.ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.menuListView.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.menuHideGame,
			this.menuShowGame,
			this.menuExitGame,
			this.toolStripMenuItem_202,
			this.toolStripSeparator18,
			this.gomToolStripMenuItem,
			this.toolStripMenuItem_6,
			this.toolStripMenuItem_0,
			this.toolStripMenuItem_21,
			this.toolStripSeparator34,
			this.toolStripMenuItem_151,
			this.toolStripMenuItem52,
			this.toolStripMenuItem38,
			this.toolStripSeparator7,
			this.menuRefreshAuto,
			this.menuResetTime,
			this.toolStripSeparator9,
			this.muNhapCode,
			this.menuDebug,
			this.toolStripMenuItem_38
		});
		this.menuListView.Name = "menuListView";
		this.menuListView.Size = new global::System.Drawing.Size(190, 380);
		this.menuListView.Opening += new global::System.ComponentModel.CancelEventHandler(this.menuListView_Opening);
		this.menuHideGame.Name = "menuHideGame";
		this.menuHideGame.Size = new global::System.Drawing.Size(189, 22);
		this.menuHideGame.Text = "Ẩn [Page Down[";
		this.menuHideGame.Click += new global::System.EventHandler(this.menuHideGame_Click);
		this.menuShowGame.Name = "menuShowGame";
		this.menuShowGame.Size = new global::System.Drawing.Size(189, 22);
		this.menuShowGame.Text = "Hiện [Double Click]";
		this.menuShowGame.Click += new global::System.EventHandler(this.menuShowGame_Click);
		this.menuExitGame.Name = "menuExitGame";
		this.menuExitGame.Size = new global::System.Drawing.Size(189, 22);
		this.menuExitGame.Text = "Thoát [Delete]";
		this.menuExitGame.Click += new global::System.EventHandler(this.menuExitGame_Click);
		this.toolStripMenuItem_202.Name = "chọnMáyChủToolStripMenuItem1";
		this.toolStripMenuItem_202.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_202.Text = "Chọn Máy Chủ";
		this.toolStripMenuItem_202.Click += new global::System.EventHandler(this.toolStripMenuItem_202_Click);
		this.toolStripSeparator18.Name = "toolStripSeparator18";
		this.toolStripSeparator18.Size = new global::System.Drawing.Size(186, 6);
		this.gomToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_146,
			this.toolStripMenuItem_147,
			this.toolStripMenuItem_148,
			this.treoShopChoTaToolStripMenuItem1,
			this.toolStripMenuItem_163,
			this.muDuaTangBaoDo,
			this.toolStripMenuItem_201
		});
		this.gomToolStripMenuItem.Name = "gomToolStripMenuItem";
		this.gomToolStripMenuItem.Size = new global::System.Drawing.Size(189, 22);
		this.gomToolStripMenuItem.Text = "Gom";
		this.toolStripMenuItem_146.Name = "taLàNgườiGomĐồToolStripMenuItem1";
		this.toolStripMenuItem_146.Size = new global::System.Drawing.Size(207, 22);
		this.toolStripMenuItem_146.Text = "Ta Là Người Gom Đồ";
		this.toolStripMenuItem_146.Click += new global::System.EventHandler(this.toolStripMenuItem_146_Click);
		this.toolStripMenuItem_147.Name = "đưaĐồChoTaToolStripMenuItem";
		this.toolStripMenuItem_147.Size = new global::System.Drawing.Size(207, 22);
		this.toolStripMenuItem_147.Text = "Đưa Đồ Cho Ta";
		this.toolStripMenuItem_147.Click += new global::System.EventHandler(this.toolStripMenuItem_147_Click);
		this.toolStripMenuItem_148.Name = "đưaĐồVàngChoTaToolStripMenuItem";
		this.toolStripMenuItem_148.Size = new global::System.Drawing.Size(207, 22);
		this.toolStripMenuItem_148.Text = "Đưa Đồ + Vàng Cho Ta";
		this.toolStripMenuItem_148.Click += new global::System.EventHandler(this.toolStripMenuItem_148_Click);
		this.treoShopChoTaToolStripMenuItem1.Name = "treoShopChoTaToolStripMenuItem1";
		this.treoShopChoTaToolStripMenuItem1.Size = new global::System.Drawing.Size(207, 22);
		this.treoShopChoTaToolStripMenuItem1.Text = "Treo Shop KNB Cho Ta";
		this.treoShopChoTaToolStripMenuItem1.Click += new global::System.EventHandler(this.treoShopChoTaToolStripMenuItem1_Click);
		this.toolStripMenuItem_163.Name = "đưaBảoĐồHiếmChoTaToolStripMenuItem";
		this.toolStripMenuItem_163.Size = new global::System.Drawing.Size(207, 22);
		this.toolStripMenuItem_163.Text = "Đưa Bảo Đồ Hiếm Cho Ta";
		this.toolStripMenuItem_163.Click += new global::System.EventHandler(this.toolStripMenuItem_163_Click);
		this.muDuaTangBaoDo.Name = "muDuaTangBaoDo";
		this.muDuaTangBaoDo.Size = new global::System.Drawing.Size(207, 22);
		this.muDuaTangBaoDo.Text = "Đưa Tàng Bảo Đồ Cho Ta";
		this.muDuaTangBaoDo.Click += new global::System.EventHandler(this.muDuaTangBaoDo_Click);
		this.toolStripMenuItem_201.Name = "đưaKNBChoTaToolStripMenuItem";
		this.toolStripMenuItem_201.Size = new global::System.Drawing.Size(207, 22);
		this.toolStripMenuItem_201.Text = "Đưa KNB Cho Ta";
		this.toolStripMenuItem_201.Click += new global::System.EventHandler(this.toolStripMenuItem_201_Click);
		this.toolStripMenuItem_6.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.menuTrieuTapNhom,
			this.menuMoiDoi,
			this.menuTrieuTap,
			this.toolStripSeparator58,
			this.menuSetNhom,
			this.toolStripMenuItem_18,
			this.toolStripMenuItem_49,
			this.toolStripMenuItem_54,
			this.muQuanLyNhom,
			this.toolStripMenuItem_50,
			this.menuAutoCreateTeam,
			this.toolStripSeparator3,
			this.menuCreateTeam,
			this.muGiaiTan
		});
		this.toolStripMenuItem_6.Name = "tổĐộiToolStripMenuItem";
		this.toolStripMenuItem_6.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_6.Text = "Tổ Đội";
		this.menuTrieuTapNhom.Name = "menuTrieuTapNhom";
		this.menuTrieuTapNhom.Size = new global::System.Drawing.Size(231, 22);
		this.menuTrieuTapNhom.Text = "Triệu Tập Nhóm [Alt + F3]";
		this.menuTrieuTapNhom.Click += new global::System.EventHandler(this.menuTrieuTapNhom_Click);
		this.menuMoiDoi.Name = "menuMoiDoi";
		this.menuMoiDoi.Size = new global::System.Drawing.Size(231, 22);
		this.menuMoiDoi.Text = "Mời Đội [Ctrl + End]";
		this.menuMoiDoi.Click += new global::System.EventHandler(this.menuMoiDoi_Click);
		this.menuTrieuTap.Name = "menuTrieuTap";
		this.menuTrieuTap.Size = new global::System.Drawing.Size(231, 22);
		this.menuTrieuTap.Text = "Triệu Tập [Alt + F2]";
		this.menuTrieuTap.Click += new global::System.EventHandler(this.menuTrieuTap_Click);
		this.toolStripSeparator58.Name = "toolStripSeparator58";
		this.toolStripSeparator58.Size = new global::System.Drawing.Size(228, 6);
		this.menuSetNhom.Name = "menuSetNhom";
		this.menuSetNhom.Size = new global::System.Drawing.Size(231, 22);
		this.menuSetNhom.Text = "Set Nhóm";
		this.menuSetNhom.Click += new global::System.EventHandler(this.menuSetNhom_Click);
		this.toolStripMenuItem_18.Name = "setNhómNhậnBóngToolStripMenuItem";
		this.toolStripMenuItem_18.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_18.Text = "Set Nhóm Nhận Bóng";
		this.toolStripMenuItem_18.Visible = false;
		this.toolStripMenuItem_18.Click += new global::System.EventHandler(this.toolStripMenuItem_18_Click);
		this.toolStripMenuItem_49.Name = "setNhómTỷVõToolStripMenuItem";
		this.toolStripMenuItem_49.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_49.Text = "Set Nhóm Tỷ Võ";
		this.toolStripMenuItem_49.Click += new global::System.EventHandler(this.toolStripMenuItem_49_Click);
		this.toolStripMenuItem_54.Name = "setQuânĐoànToolStripMenuItem";
		this.toolStripMenuItem_54.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_54.Text = "Set Quân Đoàn";
		this.toolStripMenuItem_54.Click += new global::System.EventHandler(this.toolStripMenuItem_54_Click);
		this.muQuanLyNhom.Name = "muQuanLyNhom";
		this.muQuanLyNhom.Size = new global::System.Drawing.Size(231, 22);
		this.muQuanLyNhom.Text = "Quản Lý Nhóm";
		this.muQuanLyNhom.Click += new global::System.EventHandler(this.muQuanLyNhom_Click);
		this.toolStripMenuItem_50.Name = "tựTổĐộiTheoNhómTỷVõToolStripMenuItem";
		this.toolStripMenuItem_50.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_50.Text = "Tự Tổ Đội Theo Nhóm Tỷ Võ";
		this.toolStripMenuItem_50.Click += new global::System.EventHandler(this.toolStripMenuItem_50_Click);
		this.menuAutoCreateTeam.Name = "menuAutoCreateTeam";
		this.menuAutoCreateTeam.Size = new global::System.Drawing.Size(231, 22);
		this.menuAutoCreateTeam.Text = "Tự Tổ Đội Theo Nhóm Đã Set";
		this.menuAutoCreateTeam.Click += new global::System.EventHandler(this.menuAutoCreateTeam_Click);
		this.toolStripSeparator3.Name = "toolStripSeparator3";
		this.toolStripSeparator3.Size = new global::System.Drawing.Size(228, 6);
		this.menuCreateTeam.Name = "menuCreateTeam";
		this.menuCreateTeam.Size = new global::System.Drawing.Size(231, 22);
		this.menuCreateTeam.Text = "Tổ Đội Những Game Đã Chọn";
		this.menuCreateTeam.Click += new global::System.EventHandler(this.menuCreateTeam_Click);
		this.muGiaiTan.Name = "muGiaiTan";
		this.muGiaiTan.Size = new global::System.Drawing.Size(231, 22);
		this.muGiaiTan.Text = "Giải Tán Mọi Đội Ngũ";
		this.muGiaiTan.Click += new global::System.EventHandler(this.muGiaiTan_Click);
		this.toolStripMenuItem_0.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_3,
			this.toolStripMenuItem_4,
			this.toolStripMenuItem_1,
			this.toolStripMenuItem_14,
			this.toolStripSeparator38,
			this.toolStripMenuItem_5,
			this.toolStripMenuItem_15,
			this.toolStripMenuItem_2,
			this.toolStripMenuItem_12
		});
		this.toolStripMenuItem_0.Name = "diChuyểnToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_0.Text = "Di Chuyển";
		this.toolStripMenuItem_3.Name = "lênBãiTrainToolStripMenuItem";
		this.toolStripMenuItem_3.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_3.Text = "Lên Bãi Train";
		this.toolStripMenuItem_3.Click += new global::System.EventHandler(this.toolStripMenuItem_3_Click);
		this.toolStripMenuItem_4.Name = "lưuTọaĐộTrainToolStripMenuItem";
		this.toolStripMenuItem_4.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_4.Text = "Lưu Tọa Độ Train";
		this.toolStripMenuItem_4.Click += new global::System.EventHandler(this.toolStripMenuItem_4_Click);
		this.toolStripMenuItem_1.Name = "địnhVịThổLinhChâuToolStripMenuItem";
		this.toolStripMenuItem_1.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_1.Text = "Định Vị Thổ Linh Châu Đầu Tiên";
		this.toolStripMenuItem_1.Click += new global::System.EventHandler(this.toolStripMenuItem_1_Click);
		this.toolStripMenuItem_14.Name = "địnhVịThổLinhChâuALLToolStripMenuItem";
		this.toolStripMenuItem_14.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_14.Text = "Định Vị Toàn Bộ Thổ Linh Châu";
		this.toolStripMenuItem_14.Click += new global::System.EventHandler(this.toolStripMenuItem_14_Click);
		this.toolStripSeparator38.Name = "toolStripSeparator38";
		this.toolStripSeparator38.Size = new global::System.Drawing.Size(238, 6);
		this.toolStripMenuItem_5.Name = "dùngThổLinhChâuToolStripMenuItem";
		this.toolStripMenuItem_5.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_5.Text = "Dùng Thổ Linh Châu";
		this.toolStripMenuItem_5.Click += new global::System.EventHandler(this.toolStripMenuItem_5_Click);
		this.toolStripMenuItem_15.Name = "dùngĐịnhVịPhùToolStripMenuItem";
		this.toolStripMenuItem_15.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_15.Text = "Dùng Định Vị Phù";
		this.toolStripMenuItem_15.Click += new global::System.EventHandler(this.toolStripMenuItem_15_Click);
		this.toolStripMenuItem_2.Name = "thêmTọaĐộToolStripMenuItem";
		this.toolStripMenuItem_2.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_2.Text = "Thêm Tọa Độ";
		this.toolStripMenuItem_2.Click += new global::System.EventHandler(this.toolStripMenuItem_2_Click);
		this.toolStripMenuItem_12.Name = "đạiThếGiớiToolStripMenuItem";
		this.toolStripMenuItem_12.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_12.Text = "Đại Thế Giới";
		this.toolStripMenuItem_12.Click += new global::System.EventHandler(this.toolStripMenuItem_12_Click);
		this.toolStripMenuItem_21.Name = "xinVàoNhómToolStripMenuItem";
		this.toolStripMenuItem_21.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_21.Text = "Xin Vào Nhóm";
		this.toolStripSeparator34.Name = "toolStripSeparator34";
		this.toolStripSeparator34.Size = new global::System.Drawing.Size(186, 6);
		this.toolStripMenuItem_151.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_152,
			this.toolStripMenuItem_156,
			this.toolStripMenuItem_175,
			this.toolStripMenuItem_171,
			this.toolStripMenuItem_172,
			this.toolStripMenuItem_173,
			this.toolStripMenuItem_174,
			this.toolStripMenuItem_179,
			this.toolStripMenuItem_180,
			this.toolStripMenuItem_181,
			this.toolStripMenuItem_189,
			this.toolStripMenuItem_194,
			this.muaX2ToolStripMenuItem
		});
		this.toolStripMenuItem_151.Name = "hợpToolStripMenuItem";
		this.toolStripMenuItem_151.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_151.Text = "Tiện ích";
		this.toolStripMenuItem_152.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_153,
			this.toolStripMenuItem_154,
			this.toolStripMenuItem_155
		});
		this.toolStripMenuItem_152.Name = "điểnTịchToolStripMenuItem";
		this.toolStripMenuItem_152.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_152.Text = "Hợp Điển Tịch";
		this.toolStripMenuItem_153.Name = "hợpLênMàuXanhCấp2ToolStripMenuItem1";
		this.toolStripMenuItem_153.Size = new global::System.Drawing.Size(191, 22);
		this.toolStripMenuItem_153.Text = "Lên Màu Xanh (Cấp 2)";
		this.toolStripMenuItem_153.Click += new global::System.EventHandler(this.toolStripMenuItem_153_Click);
		this.toolStripMenuItem_154.Name = "hợpLênMàuXanhCấp2ToolStripMenuItem2";
		this.toolStripMenuItem_154.Size = new global::System.Drawing.Size(191, 22);
		this.toolStripMenuItem_154.Text = "Lên Màu Tím (Cấp 3)";
		this.toolStripMenuItem_154.Click += new global::System.EventHandler(this.toolStripMenuItem_154_Click);
		this.toolStripMenuItem_155.Name = "hợpLênMàuXanhCấp2ToolStripMenuItem3";
		this.toolStripMenuItem_155.Size = new global::System.Drawing.Size(191, 22);
		this.toolStripMenuItem_155.Text = "Lên Màu Cam (Cấp 4)";
		this.toolStripMenuItem_155.Click += new global::System.EventHandler(this.toolStripMenuItem_155_Click);
		this.toolStripMenuItem_156.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_157,
			this.toolStripMenuItem_158,
			this.toolStripMenuItem_159,
			this.toolStripMenuItem_160,
			this.toolStripMenuItem_161,
			this.toolStripMenuItem_162
		});
		this.toolStripMenuItem_156.Name = "võHồnToolStripMenuItem1";
		this.toolStripMenuItem_156.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_156.Text = "Hợp Võ Hồn";
		this.toolStripMenuItem_157.Name = "lênCấp2ToolStripMenuItem";
		this.toolStripMenuItem_157.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_157.Text = "Lên Cấp 2";
		this.toolStripMenuItem_157.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_158.Name = "lênCấp3ToolStripMenuItem";
		this.toolStripMenuItem_158.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_158.Text = "Lên Cấp 3";
		this.toolStripMenuItem_158.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_159.Name = "lênCấp4ToolStripMenuItem";
		this.toolStripMenuItem_159.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_159.Text = "Lên Cấp 4";
		this.toolStripMenuItem_159.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_160.Name = "lênCấp5ToolStripMenuItem";
		this.toolStripMenuItem_160.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_160.Text = "Lên Cấp 5";
		this.toolStripMenuItem_160.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_161.Name = "lênCấp6ToolStripMenuItem";
		this.toolStripMenuItem_161.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_161.Text = "Lên Cấp 6";
		this.toolStripMenuItem_161.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_162.Name = "lênCấp7ToolStripMenuItem";
		this.toolStripMenuItem_162.Size = new global::System.Drawing.Size(126, 22);
		this.toolStripMenuItem_162.Text = "Lên Cấp 7";
		this.toolStripMenuItem_162.Click += new global::System.EventHandler(this.toolStripMenuItem_162_Click);
		this.toolStripMenuItem_175.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_176,
			this.toolStripMenuItem_177,
			this.toolStripMenuItem_178
		});
		this.toolStripMenuItem_175.Name = "mởQuàVũƯớcToolStripMenuItem1";
		this.toolStripMenuItem_175.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_175.Text = "Mở Quà Vũ Ước";
		this.toolStripMenuItem_176.Name = "kimTinhThạchToolStripMenuItem";
		this.toolStripMenuItem_176.Size = new global::System.Drawing.Size(184, 22);
		this.toolStripMenuItem_176.Text = "Kim Tinh Thạch";
		this.toolStripMenuItem_176.Click += new global::System.EventHandler(this.toolStripMenuItem_176_Click);
		this.toolStripMenuItem_177.Name = "câuThiênTháiToolStripMenuItem";
		this.toolStripMenuItem_177.Size = new global::System.Drawing.Size(184, 22);
		this.toolStripMenuItem_177.Text = "Câu Thiên Thái";
		this.toolStripMenuItem_177.Click += new global::System.EventHandler(this.toolStripMenuItem_177_Click);
		this.toolStripMenuItem_178.Name = "cửuThiênNgọcToáiToolStripMenuItem";
		this.toolStripMenuItem_178.Size = new global::System.Drawing.Size(184, 22);
		this.toolStripMenuItem_178.Text = "Cửu Thiên Ngọc Toái";
		this.toolStripMenuItem_178.Click += new global::System.EventHandler(this.toolStripMenuItem_178_Click);
		this.toolStripMenuItem_171.Name = "nhậnLạiNộiTứcToolStripMenuItem1";
		this.toolStripMenuItem_171.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_171.Text = "Nhận Lại Nội Tức";
		this.toolStripMenuItem_171.Click += new global::System.EventHandler(this.toolStripMenuItem_171_Click);
		this.toolStripMenuItem_172.Name = "đổiVàngSangGiaoTửToolStripMenuItem";
		this.toolStripMenuItem_172.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_172.Text = "Đổi Vàng Sang Giao Tử";
		this.toolStripMenuItem_172.Click += new global::System.EventHandler(this.toolStripMenuItem_172_Click);
		this.toolStripMenuItem_173.Name = "thăngCấpHàoHiệpẤnToolStripMenuItem1";
		this.toolStripMenuItem_173.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_173.Text = "Thăng Cấp Hào Hiệp Ấn";
		this.toolStripMenuItem_173.Click += new global::System.EventHandler(this.toolStripMenuItem_173_Click);
		this.toolStripMenuItem_174.Name = "lấyĐồTúiThiênCơToolStripMenuItem";
		this.toolStripMenuItem_174.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_174.Text = "Lấy Đồ Túi Thiên Cơ";
		this.toolStripMenuItem_174.Click += new global::System.EventHandler(this.toolStripMenuItem_174_Click);
		this.toolStripMenuItem_179.Name = "phúcLợiĐiểmDanhToolStripMenuItem1";
		this.toolStripMenuItem_179.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_179.Text = "Phúc Lợi Điểm Danh";
		this.toolStripMenuItem_179.Click += new global::System.EventHandler(this.toolStripMenuItem_179_Click);
		this.toolStripMenuItem_180.Name = "nhậnQuàThăngCấpToolStripMenuItem1";
		this.toolStripMenuItem_180.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_180.Text = "Nhận Quà Thăng Cấp";
		this.toolStripMenuItem_180.Click += new global::System.EventHandler(this.toolStripMenuItem_180_Click);
		this.toolStripMenuItem_181.Name = "muaTưBổĐanToolStripMenuItem";
		this.toolStripMenuItem_181.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_181.Text = "Mua Tư Bổ Đan";
		this.toolStripMenuItem_181.Click += new global::System.EventHandler(this.toolStripMenuItem_181_Click);
		this.toolStripMenuItem_189.Name = "muaThổLinhChâuToolStripMenuItem";
		this.toolStripMenuItem_189.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_189.Text = "Mua Thổ Linh Châu";
		this.toolStripMenuItem_189.Click += new global::System.EventHandler(this.toolStripMenuItem_189_Click);
		this.toolStripMenuItem_194.Name = "giámĐịnhĐồToolStripMenuItem";
		this.toolStripMenuItem_194.Size = new global::System.Drawing.Size(202, 22);
		this.toolStripMenuItem_194.Text = "Giám Định Đồ";
		this.toolStripMenuItem_194.Click += new global::System.EventHandler(this.toolStripMenuItem_194_Click);
		this.muaX2ToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_195,
			this.toolStripMenuItem_200,
			this.toolStripMenuItem_196,
			this.toolStripMenuItem_197
		});
		this.muaX2ToolStripMenuItem.Name = "muaX2ToolStripMenuItem";
		this.muaX2ToolStripMenuItem.Size = new global::System.Drawing.Size(202, 22);
		this.muaX2ToolStripMenuItem.Text = "Mua x2";
		this.toolStripMenuItem_195.Name = "viênToolStripMenuItem";
		this.toolStripMenuItem_195.Size = new global::System.Drawing.Size(112, 22);
		this.toolStripMenuItem_195.Text = "1 Viên";
		this.toolStripMenuItem_195.Click += new global::System.EventHandler(this.toolStripMenuItem_195_Click);
		this.toolStripMenuItem_200.Name = "viênToolStripMenuItem3";
		this.toolStripMenuItem_200.Size = new global::System.Drawing.Size(112, 22);
		this.toolStripMenuItem_200.Text = "2 Viên";
		this.toolStripMenuItem_200.Click += new global::System.EventHandler(this.toolStripMenuItem_200_Click);
		this.toolStripMenuItem_196.Name = "viênToolStripMenuItem1";
		this.toolStripMenuItem_196.Size = new global::System.Drawing.Size(112, 22);
		this.toolStripMenuItem_196.Text = "4 Viên";
		this.toolStripMenuItem_196.Click += new global::System.EventHandler(this.toolStripMenuItem_196_Click);
		this.toolStripMenuItem_197.Name = "viênToolStripMenuItem2";
		this.toolStripMenuItem_197.Size = new global::System.Drawing.Size(112, 22);
		this.toolStripMenuItem_197.Text = "10 Viên";
		this.toolStripMenuItem_197.Click += new global::System.EventHandler(this.toolStripMenuItem_197_Click);
		this.toolStripMenuItem52.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muCQThuCong,
			this.muCQBinhThanhThuCong,
			this.toolStripSeparator33,
			this.muCQYenTuO,
			this.muCQTuTuyetTrang,
			this.muCQSatTinh,
			this.muCQPhieuMieuPhong,
			this.muCQThieuThatSon,
			this.muCQBinhThanh,
			this.muCQBinhThanhKho,
			this.muCQVuongLang,
			this.muCQTamThan,
			this.muCQKhieuChienPMP,
			this.muCQPhucDia,
			this.muCQPhucDiaKho,
			this.toolStripMenuItem_24
		});
		this.toolStripMenuItem52.Name = "toolStripMenuItem52";
		this.toolStripMenuItem52.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem52.Text = "Càn Quét";
		this.muCQThuCong.Name = "muCQThuCong";
		this.muCQThuCong.Size = new global::System.Drawing.Size(239, 22);
		this.muCQThuCong.Text = "Thủ Công";
		this.muCQThuCong.Click += new global::System.EventHandler(this.muCQThuCong_Click);
		this.muCQBinhThanhThuCong.Name = "muCQBinhThanhThuCong";
		this.muCQBinhThanhThuCong.Size = new global::System.Drawing.Size(239, 22);
		this.muCQBinhThanhThuCong.Text = "Binh Thánh Kỳ Trận";
		this.muCQBinhThanhThuCong.Click += new global::System.EventHandler(this.muCQBinhThanhThuCong_Click);
		this.toolStripSeparator33.Name = "toolStripSeparator33";
		this.toolStripSeparator33.Size = new global::System.Drawing.Size(236, 6);
		this.muCQYenTuO.Name = "muCQYenTuO";
		this.muCQYenTuO.Size = new global::System.Drawing.Size(239, 22);
		this.muCQYenTuO.Tag = "0";
		this.muCQYenTuO.Text = "Yến Tử Ô";
		this.muCQYenTuO.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQTuTuyetTrang.Name = "muCQTuTuyetTrang";
		this.muCQTuTuyetTrang.Size = new global::System.Drawing.Size(239, 22);
		this.muCQTuTuyetTrang.Tag = "1";
		this.muCQTuTuyetTrang.Text = "Tứ Tuyệt Trang";
		this.muCQTuTuyetTrang.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQSatTinh.Name = "muCQSatTinh";
		this.muCQSatTinh.Size = new global::System.Drawing.Size(239, 22);
		this.muCQSatTinh.Tag = "2";
		this.muCQSatTinh.Text = "Sát Tinh";
		this.muCQSatTinh.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQPhieuMieuPhong.Name = "muCQPhieuMieuPhong";
		this.muCQPhieuMieuPhong.Size = new global::System.Drawing.Size(239, 22);
		this.muCQPhieuMieuPhong.Tag = "3";
		this.muCQPhieuMieuPhong.Text = "Phiêu Miễu Phong";
		this.muCQPhieuMieuPhong.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQThieuThatSon.Name = "muCQThieuThatSon";
		this.muCQThieuThatSon.Size = new global::System.Drawing.Size(239, 22);
		this.muCQThieuThatSon.Tag = "4";
		this.muCQThieuThatSon.Text = "Thiếu Thất Sơn";
		this.muCQThieuThatSon.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQBinhThanh.Name = "muCQBinhThanh";
		this.muCQBinhThanh.Size = new global::System.Drawing.Size(239, 22);
		this.muCQBinhThanh.Tag = "5";
		this.muCQBinhThanh.Text = "Binh Thánh";
		this.muCQBinhThanh.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQBinhThanhKho.Name = "muCQBinhThanhKho";
		this.muCQBinhThanhKho.Size = new global::System.Drawing.Size(239, 22);
		this.muCQBinhThanhKho.Tag = "6";
		this.muCQBinhThanhKho.Text = "Binh Thánh Khó";
		this.muCQBinhThanhKho.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQVuongLang.Name = "muCQVuongLang";
		this.muCQVuongLang.Size = new global::System.Drawing.Size(239, 22);
		this.muCQVuongLang.Tag = "7";
		this.muCQVuongLang.Text = "Vương Lăng";
		this.muCQVuongLang.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQTamThan.Name = "muCQTamThan";
		this.muCQTamThan.Size = new global::System.Drawing.Size(239, 22);
		this.muCQTamThan.Tag = "9";
		this.muCQTamThan.Text = "Tam Thần";
		this.muCQTamThan.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQKhieuChienPMP.Name = "muCQKhieuChienPMP";
		this.muCQKhieuChienPMP.Size = new global::System.Drawing.Size(239, 22);
		this.muCQKhieuChienPMP.Tag = "8";
		this.muCQKhieuChienPMP.Text = "Khiêu Chiến Phiêu Miễu Phong";
		this.muCQKhieuChienPMP.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQPhucDia.Name = "muCQPhucDia";
		this.muCQPhucDia.Size = new global::System.Drawing.Size(239, 22);
		this.muCQPhucDia.Tag = "10";
		this.muCQPhucDia.Text = "Phúc Địa";
		this.muCQPhucDia.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.muCQPhucDiaKho.Name = "muCQPhucDiaKho";
		this.muCQPhucDiaKho.Size = new global::System.Drawing.Size(239, 22);
		this.muCQPhucDiaKho.Tag = "11";
		this.muCQPhucDiaKho.Text = "Phúc Địa Khó";
		this.muCQPhucDiaKho.Click += new global::System.EventHandler(this.muCQPhucDiaKho_Click);
		this.toolStripMenuItem_24.Name = "toànBộPhụBảnToolStripMenuItem";
		this.toolStripMenuItem_24.Size = new global::System.Drawing.Size(239, 22);
		this.toolStripMenuItem_24.Text = "Toàn Bộ Phụ Bản";
		this.toolStripMenuItem_24.Click += new global::System.EventHandler(this.toolStripMenuItem_24_Click);
		this.toolStripMenuItem38.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_203,
			this.muQuayVeDaiLy,
			this.toolStripSeparator14,
			this.toolStripMenuItem_190,
			this.toolStripMenuItem_191,
			this.toolStripSeparator11,
			this.toolStripMenuItem_192,
			this.thuPetToolStripMenuItem1,
			this.toolStripSeparator6,
			this.muDemBut,
			this.muChucPhuc,
			this.toolStripSeparator16,
			this.muKetNghia,
			this.muChucPhucTuBaoBon,
			this.toolStripSeparator26,
			this.muAutoMap,
			this.toolStripMenuItem_19
		});
		this.toolStripMenuItem38.Name = "toolStripMenuItem38";
		this.toolStripMenuItem38.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem38.Text = "Chức năng";
		this.toolStripMenuItem_203.Name = "ẩnĐộnToolStripMenuItem";
		this.toolStripMenuItem_203.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_203.Text = "Ẩn Độn";
		this.toolStripMenuItem_203.Click += new global::System.EventHandler(this.toolStripMenuItem_203_Click);
		this.muQuayVeDaiLy.Name = "muQuayVeDaiLy";
		this.muQuayVeDaiLy.Size = new global::System.Drawing.Size(180, 22);
		this.muQuayVeDaiLy.Text = "Quay về đại lý";
		this.muQuayVeDaiLy.Click += new global::System.EventHandler(this.muQuayVeDaiLy_Click);
		this.toolStripSeparator14.Name = "toolStripSeparator14";
		this.toolStripSeparator14.Size = new global::System.Drawing.Size(177, 6);
		this.toolStripMenuItem_190.Name = "lênNgựaToolStripMenuItem";
		this.toolStripMenuItem_190.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_190.Text = "Lên Ngựa";
		this.toolStripMenuItem_190.Click += new global::System.EventHandler(this.toolStripMenuItem_190_Click);
		this.toolStripMenuItem_191.Name = "xuốngNgựaToolStripMenuItem";
		this.toolStripMenuItem_191.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_191.Text = "Xuống Ngựa";
		this.toolStripMenuItem_191.Click += new global::System.EventHandler(this.toolStripMenuItem_191_Click);
		this.toolStripSeparator11.Name = "toolStripSeparator11";
		this.toolStripSeparator11.Size = new global::System.Drawing.Size(177, 6);
		this.toolStripMenuItem_192.Name = "xuấtPetToolStripMenuItem1";
		this.toolStripMenuItem_192.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_192.Text = "Xuất Pet";
		this.toolStripMenuItem_192.Click += new global::System.EventHandler(this.toolStripMenuItem_192_Click);
		this.thuPetToolStripMenuItem1.Name = "thuPetToolStripMenuItem1";
		this.thuPetToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
		this.thuPetToolStripMenuItem1.Text = "Thu Pet";
		this.thuPetToolStripMenuItem1.Click += new global::System.EventHandler(this.thuPetToolStripMenuItem1_Click);
		this.toolStripSeparator6.Name = "toolStripSeparator6";
		this.toolStripSeparator6.Size = new global::System.Drawing.Size(177, 6);
		this.muDemBut.Name = "muDemBut";
		this.muDemBut.Size = new global::System.Drawing.Size(180, 22);
		this.muDemBut.Text = "Đếm Bút";
		this.muDemBut.Click += new global::System.EventHandler(this.muDemBut_Click);
		this.muChucPhuc.Name = "muChucPhuc";
		this.muChucPhuc.Size = new global::System.Drawing.Size(180, 22);
		this.muChucPhuc.Text = "Chúc Phúc Mao Bút";
		this.muChucPhuc.Click += new global::System.EventHandler(this.muChucPhuc_Click);
		this.toolStripSeparator16.Name = "toolStripSeparator16";
		this.toolStripSeparator16.Size = new global::System.Drawing.Size(177, 6);
		this.muKetNghia.Name = "muKetNghia";
		this.muKetNghia.Size = new global::System.Drawing.Size(180, 22);
		this.muKetNghia.Text = "Hảo Hữu Nhau";
		this.muKetNghia.Click += new global::System.EventHandler(this.muKetNghia_Click);
		this.muChucPhucTuBaoBon.Name = "muChucPhucTuBaoBon";
		this.muChucPhucTuBaoBon.Size = new global::System.Drawing.Size(180, 22);
		this.muChucPhucTuBaoBon.Text = "Chúc Phúc Bạn Bè";
		this.muChucPhucTuBaoBon.Click += new global::System.EventHandler(this.muChucPhucTuBaoBon_Click);
		this.toolStripSeparator26.Name = "toolStripSeparator26";
		this.toolStripSeparator26.Size = new global::System.Drawing.Size(177, 6);
		this.muAutoMap.Name = "muAutoMap";
		this.muAutoMap.Size = new global::System.Drawing.Size(180, 22);
		this.muAutoMap.Text = "AutoMap";
		this.muAutoMap.Click += new global::System.EventHandler(this.muAutoMap_Click);
		this.toolStripMenuItem_19.Name = "tuyệtGiaoToolStripMenuItem";
		this.toolStripMenuItem_19.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_19.Text = "Tuyệt Giao";
		this.toolStripMenuItem_19.Click += new global::System.EventHandler(this.toolStripMenuItem_19_Click);
		this.toolStripSeparator7.Name = "toolStripSeparator7";
		this.toolStripSeparator7.Size = new global::System.Drawing.Size(186, 6);
		this.menuRefreshAuto.Name = "menuRefreshAuto";
		this.menuRefreshAuto.Size = new global::System.Drawing.Size(189, 22);
		this.menuRefreshAuto.Text = "Refresh";
		this.menuRefreshAuto.Click += new global::System.EventHandler(this.menuRefreshAuto_Click);
		this.menuResetTime.Name = "menuResetTime";
		this.menuResetTime.Size = new global::System.Drawing.Size(189, 22);
		this.menuResetTime.Text = "Reset time";
		this.menuResetTime.Click += new global::System.EventHandler(this.menuResetTime_Click);
		this.toolStripSeparator9.Name = "toolStripSeparator9";
		this.toolStripSeparator9.Size = new global::System.Drawing.Size(186, 6);
		this.toolStripSeparator9.Visible = false;
		this.muNhapCode.Name = "muNhapCode";
		this.muNhapCode.Size = new global::System.Drawing.Size(189, 22);
		this.muNhapCode.Text = "Nhập Code";
		this.muNhapCode.Click += new global::System.EventHandler(this.muNhapCode_Click);
		this.menuDebug.Name = "menuDebug";
		this.menuDebug.Size = new global::System.Drawing.Size(189, 22);
		this.menuDebug.Text = "Debug";
		this.menuDebug.Visible = false;
		this.menuDebug.Click += new global::System.EventHandler(this.menuDebug_Click);
		this.toolStripMenuItem_38.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_39,
			this.toolStripMenuItem_40,
			this.toolStripMenuItem_41,
			this.bangToolStripMenuItem,
			this.toolStripMenuItem_42
		});
		this.toolStripMenuItem_38.Name = "trạngTháiPKToolStripMenuItem";
		this.toolStripMenuItem_38.Size = new global::System.Drawing.Size(189, 22);
		this.toolStripMenuItem_38.Text = "Chuyển Trạng Thái PK";
		this.toolStripMenuItem_39.Name = "hòaBìnhToolStripMenuItem";
		this.toolStripMenuItem_39.Size = new global::System.Drawing.Size(134, 22);
		this.toolStripMenuItem_39.Text = "Hòa Bình";
		this.toolStripMenuItem_39.Click += new global::System.EventHandler(this.toolStripMenuItem_39_Click);
		this.toolStripMenuItem_40.Name = "thiệnÁcToolStripMenuItem";
		this.toolStripMenuItem_40.Size = new global::System.Drawing.Size(134, 22);
		this.toolStripMenuItem_40.Text = "Thiện Ác";
		this.toolStripMenuItem_40.Click += new global::System.EventHandler(this.toolStripMenuItem_40_Click);
		this.toolStripMenuItem_41.Name = "nhómToolStripMenuItem";
		this.toolStripMenuItem_41.Size = new global::System.Drawing.Size(134, 22);
		this.toolStripMenuItem_41.Text = "Nhóm";
		this.toolStripMenuItem_41.Click += new global::System.EventHandler(this.toolStripMenuItem_41_Click);
		this.bangToolStripMenuItem.Name = "bangToolStripMenuItem";
		this.bangToolStripMenuItem.Size = new global::System.Drawing.Size(134, 22);
		this.bangToolStripMenuItem.Text = "Bang";
		this.bangToolStripMenuItem.Click += new global::System.EventHandler(this.bangToolStripMenuItem_Click);
		this.toolStripMenuItem_42.Name = "quânĐoànToolStripMenuItem";
		this.toolStripMenuItem_42.Size = new global::System.Drawing.Size(134, 22);
		this.toolStripMenuItem_42.Text = "Quân Đoàn";
		this.toolStripMenuItem_42.Click += new global::System.EventHandler(this.toolStripMenuItem_42_Click);
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.timer_1.Enabled = true;
		this.timer_1.Interval = 600000;
		this.timer_1.Tick += new global::System.EventHandler(this.timer_1_Tick);
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.IsBalloon = true;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.lbAcBa.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbAcBa.Location = new global::System.Drawing.Point(249, 172);
		this.lbAcBa.Name = "lbAcBa";
		this.lbAcBa.Size = new global::System.Drawing.Size(110, 20);
		this.lbAcBa.TabIndex = 280;
		this.lbAcBa.Text = "LGBT";
		this.lbAcBa.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.toolTip_0.SetToolTip(this.lbAcBa, "Ác Bá Hiện Tại");
		this.lbExpSpeed.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.lbExpSpeed.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbExpSpeed.Location = new global::System.Drawing.Point(3, 0);
		this.lbExpSpeed.Name = "lbExpSpeed";
		this.lbExpSpeed.Size = new global::System.Drawing.Size(106, 22);
		this.lbExpSpeed.TabIndex = 0;
		this.lbExpSpeed.Text = "19.21M | 234.56%";
		this.lbExpSpeed.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.toolTip_0.SetToolTip(this.lbExpSpeed, "Tốc Độ và % Kinh Nghiệm 1 Giờ");
		this.lblTimeInfo.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.lblTimeInfo.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lblTimeInfo.Location = new global::System.Drawing.Point(3, 22);
		this.lblTimeInfo.Name = "lblTimeInfo";
		this.lblTimeInfo.Size = new global::System.Drawing.Size(106, 22);
		this.lblTimeInfo.TabIndex = 1;
		this.lblTimeInfo.Text = "23D 6H";
		this.lblTimeInfo.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.toolTip_0.SetToolTip(this.lblTimeInfo, "Thăng Cấp Sau");
		this.lbHoaSpeed.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.lbHoaSpeed.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lbHoaSpeed.Location = new global::System.Drawing.Point(3, 44);
		this.lbHoaSpeed.Name = "lbHoaSpeed";
		this.lbHoaSpeed.Size = new global::System.Drawing.Size(106, 22);
		this.lbHoaSpeed.TabIndex = 2;
		this.lbHoaSpeed.Text = "423 KTT | 256 Hoa";
		this.lbHoaSpeed.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.toolTip_0.SetToolTip(this.lbHoaSpeed, "Tốc Độ kiếm Hoa và Kim Tằm Ty 1 Giờ");
		this.button13.Location = new global::System.Drawing.Point(3, 69);
		this.button13.Name = "button13";
		this.button13.Size = new global::System.Drawing.Size(106, 23);
		this.button13.TabIndex = 3;
		this.button13.Text = "ResetSpeed";
		this.toolTip_0.SetToolTip(this.button13, "Tính Lại Tốc Độ");
		this.button13.UseVisualStyleBackColor = true;
		this.button13.Click += new global::System.EventHandler(this.button13_Click);
		this.label4.AutoSize = true;
		this.label4.Location = new global::System.Drawing.Point(214, 56);
		this.label4.Name = "label4";
		this.label4.Size = new global::System.Drawing.Size(25, 13);
		this.label4.TabIndex = 278;
		this.label4.Text = "Key";
		this.toolTip_0.SetToolTip(this.label4, "Cài đặt đội trưởng để đánh theo và theo sau");
		this.checkChetLenBai.AutoSize = true;
		this.checkChetLenBai.Location = new global::System.Drawing.Point(248, 32);
		this.checkChetLenBai.Name = "checkChetLenBai";
		this.checkChetLenBai.Size = new global::System.Drawing.Size(87, 17);
		this.checkChetLenBai.TabIndex = 267;
		this.checkChetLenBai.Text = "Chết Lên Bãi";
		this.toolTip_0.SetToolTip(this.checkChetLenBai, "Tự động quay lại bãi sau khi tử vong");
		this.checkChetLenBai.UseVisualStyleBackColor = true;
		this.checkChetLenBai.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkChiNhat.AutoSize = true;
		this.checkChiNhat.Location = new global::System.Drawing.Point(141, 33);
		this.checkChiNhat.Name = "checkChiNhat";
		this.checkChiNhat.Size = new global::System.Drawing.Size(67, 17);
		this.checkChiNhat.TabIndex = 268;
		this.checkChiNhat.Text = "Chỉ Nhặt";
		this.toolTip_0.SetToolTip(this.checkChiNhat, "Chỉ Nhặt Vật Phẩm Có Tên Trong Danh Sách");
		this.checkChiNhat.UseVisualStyleBackColor = true;
		this.checkChiNhat.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Location = new global::System.Drawing.Point(141, 54);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new global::System.Drawing.Size(67, 21);
		this.cboPlayer.TabIndex = 277;
		this.toolTip_0.SetToolTip(this.cboPlayer, "Cài đặt đội trưởng để đánh theo và theo sau");
		this.cboPlayer.DrawItem += new global::System.Windows.Forms.DrawItemEventHandler(this.cboPlayer_DrawItem);
		this.cboPlayer.DropDown += new global::System.EventHandler(this.cboPlayer_DropDown);
		this.cboPlayer.SelectedIndexChanged += new global::System.EventHandler(this.cboPlayer_SelectedIndexChanged);
		this.nudBuffPet.Location = new global::System.Drawing.Point(90, 54);
		global::System.Windows.Forms.NumericUpDown numericUpDown = this.nudBuffPet;
		int[] array = new int[4];
		array[0] = 99;
		numericUpDown.Maximum = new decimal(array);
		this.nudBuffPet.Name = "nudBuffPet";
		this.nudBuffPet.Size = new global::System.Drawing.Size(45, 20);
		this.nudBuffPet.TabIndex = 276;
		this.toolTip_0.SetToolTip(this.nudBuffPet, "hồi phục khi huyết <\r\nđể 0 nếu muốn Auto");
		global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.nudBuffPet;
		int[] array2 = new int[4];
		array2[0] = 50;
		numericUpDown2.Value = new decimal(array2);
		this.nudBuffPet.ValueChanged += new global::System.EventHandler(this.nudBuffPet_ValueChanged);
		this.checkTuyenChien.AutoSize = true;
		this.checkTuyenChien.Location = new global::System.Drawing.Point(248, 10);
		this.checkTuyenChien.Name = "checkTuyenChien";
		this.checkTuyenChien.Size = new global::System.Drawing.Size(86, 17);
		this.checkTuyenChien.TabIndex = 257;
		this.checkTuyenChien.Text = "Tuyên Chiến";
		this.toolTip_0.SetToolTip(this.checkTuyenChien, "Tự Động Tuyên Chiến");
		this.checkTuyenChien.UseVisualStyleBackColor = true;
		this.checkTuyenChien.CheckedChanged += new global::System.EventHandler(this.checkTuyenChien_CheckedChanged);
		this.checkQuyCoc.AutoSize = true;
		this.checkQuyCoc.ForeColor = global::System.Drawing.Color.Black;
		this.checkQuyCoc.Location = new global::System.Drawing.Point(9, 151);
		this.checkQuyCoc.Name = "checkQuyCoc";
		this.checkQuyCoc.Size = new global::System.Drawing.Size(67, 17);
		this.checkQuyCoc.TabIndex = 246;
		this.checkQuyCoc.Text = "Quỷ Cốc";
		this.toolTip_0.SetToolTip(this.checkQuyCoc, "Sử dụng Quỷ Cốc Trường Sinh Trận khi\r\nHP tổ đội <");
		this.checkQuyCoc.UseVisualStyleBackColor = true;
		this.checkQuyCoc.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.numericUpDown2.Location = new global::System.Drawing.Point(90, 150);
		global::System.Windows.Forms.NumericUpDown numericUpDown3 = this.numericUpDown2;
		int[] array3 = new int[4];
		array3[0] = 99;
		numericUpDown3.Maximum = new decimal(array3);
		global::System.Windows.Forms.NumericUpDown numericUpDown4 = this.numericUpDown2;
		int[] array4 = new int[4];
		array4[0] = 1;
		numericUpDown4.Minimum = new decimal(array4);
		this.numericUpDown2.Name = "numericUpDown2";
		this.numericUpDown2.Size = new global::System.Drawing.Size(45, 20);
		this.numericUpDown2.TabIndex = 245;
		this.toolTip_0.SetToolTip(this.numericUpDown2, "buff khi % hyết <");
		global::System.Windows.Forms.NumericUpDown numericUpDown5 = this.numericUpDown2;
		int[] array5 = new int[4];
		array5[0] = 75;
		numericUpDown5.Value = new decimal(array5);
		this.numericUpDown2.ValueChanged += new global::System.EventHandler(this.numericUpDown2_ValueChanged);
		this.lblTrain.AutoSize = true;
		this.lblTrain.Location = new global::System.Drawing.Point(141, 155);
		this.lblTrain.Name = "lblTrain";
		this.lblTrain.Size = new global::System.Drawing.Size(16, 13);
		this.lblTrain.TabIndex = 244;
		this.lblTrain.Text = "...";
		this.toolTip_0.SetToolTip(this.lblTrain, "Tọa Độ Luyện Cấp");
		this.checkChiDanh.AutoSize = true;
		this.checkChiDanh.Location = new global::System.Drawing.Point(141, 10);
		this.checkChiDanh.Name = "checkChiDanh";
		this.checkChiDanh.Size = new global::System.Drawing.Size(69, 17);
		this.checkChiDanh.TabIndex = 183;
		this.checkChiDanh.Text = "Chỉ đánh";
		this.toolTip_0.SetToolTip(this.checkChiDanh, "Chỉ đánh những quái sau");
		this.checkChiDanh.UseVisualStyleBackColor = true;
		this.checkChiDanh.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkHP.AutoSize = true;
		this.checkHP.ForeColor = global::System.Drawing.Color.Black;
		this.checkHP.Location = new global::System.Drawing.Point(9, 79);
		this.checkHP.Name = "checkHP";
		this.checkHP.Size = new global::System.Drawing.Size(41, 17);
		this.checkHP.TabIndex = 166;
		this.checkHP.Text = "HP";
		this.toolTip_0.SetToolTip(this.checkHP, "tự động phục hồi huyết");
		this.checkHP.UseVisualStyleBackColor = true;
		this.checkHP.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.nudNM.Location = new global::System.Drawing.Point(90, 103);
		global::System.Windows.Forms.NumericUpDown numericUpDown6 = this.nudNM;
		int[] array6 = new int[4];
		array6[0] = 99;
		numericUpDown6.Maximum = new decimal(array6);
		global::System.Windows.Forms.NumericUpDown numericUpDown7 = this.nudNM;
		int[] array7 = new int[4];
		array7[0] = 1;
		numericUpDown7.Minimum = new decimal(array7);
		this.nudNM.Name = "nudNM";
		this.nudNM.Size = new global::System.Drawing.Size(45, 20);
		this.nudNM.TabIndex = 164;
		this.toolTip_0.SetToolTip(this.nudNM, "buff khi % hyết <");
		global::System.Windows.Forms.NumericUpDown numericUpDown8 = this.nudNM;
		int[] array8 = new int[4];
		array8[0] = 75;
		numericUpDown8.Value = new decimal(array8);
		this.nudNM.ValueChanged += new global::System.EventHandler(this.nudNM_ValueChanged);
		this.lblRadius.AutoSize = true;
		this.lblRadius.Location = new global::System.Drawing.Point(141, 176);
		this.lblRadius.Name = "lblRadius";
		this.lblRadius.Size = new global::System.Drawing.Size(16, 13);
		this.lblRadius.TabIndex = 172;
		this.lblRadius.Text = "...";
		this.toolTip_0.SetToolTip(this.lblRadius, "Tọa Độ Bán Kính");
		this.nudRadius.Location = new global::System.Drawing.Point(90, 174);
		global::System.Windows.Forms.NumericUpDown numericUpDown9 = this.nudRadius;
		int[] array9 = new int[4];
		array9[0] = 300;
		numericUpDown9.Maximum = new decimal(array9);
		global::System.Windows.Forms.NumericUpDown numericUpDown10 = this.nudRadius;
		int[] array10 = new int[4];
		array10[0] = 1;
		numericUpDown10.Minimum = new decimal(array10);
		this.nudRadius.Name = "nudRadius";
		this.nudRadius.Size = new global::System.Drawing.Size(45, 20);
		this.nudRadius.TabIndex = 171;
		this.toolTip_0.SetToolTip(this.nudRadius, "bán kính trong khoảng");
		global::System.Windows.Forms.NumericUpDown numericUpDown11 = this.nudRadius;
		int[] array11 = new int[4];
		array11[0] = 20;
		numericUpDown11.Value = new decimal(array11);
		this.nudRadius.ValueChanged += new global::System.EventHandler(this.nudRadius_ValueChanged);
		this.checkLuaQuai.AutoSize = true;
		this.checkLuaQuai.Location = new global::System.Drawing.Point(9, 33);
		this.checkLuaQuai.Name = "checkLuaQuai";
		this.checkLuaQuai.Size = new global::System.Drawing.Size(69, 17);
		this.checkLuaQuai.TabIndex = 5;
		this.checkLuaQuai.Text = "Lùa Quái";
		this.toolTip_0.SetToolTip(this.checkLuaQuai, "Có thể chọn nhiều Player đồng thời");
		this.checkLuaQuai.UseVisualStyleBackColor = true;
		this.checkLuaQuai.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkTimQuai.AutoSize = true;
		this.checkTimQuai.Location = new global::System.Drawing.Point(9, 10);
		this.checkTimQuai.Name = "checkTimQuai";
		this.checkTimQuai.Size = new global::System.Drawing.Size(68, 17);
		this.checkTimQuai.TabIndex = 4;
		this.checkTimQuai.Text = "Tìm Quái";
		this.toolTip_0.SetToolTip(this.checkTimQuai, "tự động đánh quái");
		this.checkTimQuai.UseVisualStyleBackColor = true;
		this.checkTimQuai.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkPet.AutoSize = true;
		this.checkPet.ForeColor = global::System.Drawing.Color.Black;
		this.checkPet.Location = new global::System.Drawing.Point(9, 56);
		this.checkPet.Name = "checkPet";
		this.checkPet.Size = new global::System.Drawing.Size(42, 17);
		this.checkPet.TabIndex = 165;
		this.checkPet.Text = "Pet";
		this.toolTip_0.SetToolTip(this.checkPet, "tự động phục hồi pet");
		this.checkPet.UseVisualStyleBackColor = true;
		this.checkPet.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkNM.AutoSize = true;
		this.checkNM.ForeColor = global::System.Drawing.Color.Black;
		this.checkNM.Location = new global::System.Drawing.Point(9, 103);
		this.checkNM.Name = "checkNM";
		this.checkNM.Size = new global::System.Drawing.Size(43, 17);
		this.checkNM.TabIndex = 168;
		this.checkNM.Text = "NM";
		this.toolTip_0.SetToolTip(this.checkNM, "tự buff máu dành cho ngamy\r\nnếu lỗi không buff máu vào phần cài đặt chọn phím buff máu");
		this.checkNM.UseVisualStyleBackColor = true;
		this.checkNM.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.nudHP.Location = new global::System.Drawing.Point(90, 78);
		global::System.Windows.Forms.NumericUpDown numericUpDown12 = this.nudHP;
		int[] array12 = new int[4];
		array12[0] = 99;
		numericUpDown12.Maximum = new decimal(array12);
		global::System.Windows.Forms.NumericUpDown numericUpDown13 = this.nudHP;
		int[] array13 = new int[4];
		array13[0] = 1;
		numericUpDown13.Minimum = new decimal(array13);
		this.nudHP.Name = "nudHP";
		this.nudHP.Size = new global::System.Drawing.Size(45, 20);
		this.nudHP.TabIndex = 161;
		this.toolTip_0.SetToolTip(this.nudHP, "hồi phục khi huyết <");
		global::System.Windows.Forms.NumericUpDown numericUpDown14 = this.nudHP;
		int[] array14 = new int[4];
		array14[0] = 50;
		numericUpDown14.Value = new decimal(array14);
		this.nudHP.ValueChanged += new global::System.EventHandler(this.nudHP_ValueChanged);
		this.checkMP.AutoSize = true;
		this.checkMP.ForeColor = global::System.Drawing.Color.Black;
		this.checkMP.Location = new global::System.Drawing.Point(9, 128);
		this.checkMP.Name = "checkMP";
		this.checkMP.Size = new global::System.Drawing.Size(42, 17);
		this.checkMP.TabIndex = 167;
		this.checkMP.Text = "MP";
		this.toolTip_0.SetToolTip(this.checkMP, "tự động hồi phục khí");
		this.checkMP.UseVisualStyleBackColor = true;
		this.checkMP.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.nudMP.Location = new global::System.Drawing.Point(90, 126);
		global::System.Windows.Forms.NumericUpDown numericUpDown15 = this.nudMP;
		int[] array15 = new int[4];
		array15[0] = 99;
		numericUpDown15.Maximum = new decimal(array15);
		global::System.Windows.Forms.NumericUpDown numericUpDown16 = this.nudMP;
		int[] array16 = new int[4];
		array16[0] = 1;
		numericUpDown16.Minimum = new decimal(array16);
		this.nudMP.Name = "nudMP";
		this.nudMP.Size = new global::System.Drawing.Size(45, 20);
		this.nudMP.TabIndex = 162;
		this.toolTip_0.SetToolTip(this.nudMP, "hồi phục khi khí <");
		global::System.Windows.Forms.NumericUpDown numericUpDown17 = this.nudMP;
		int[] array17 = new int[4];
		array17[0] = 50;
		numericUpDown17.Value = new decimal(array17);
		this.nudMP.ValueChanged += new global::System.EventHandler(this.nudMP_ValueChanged);
		this.numberThuHoaX.Location = new global::System.Drawing.Point(6, 16);
		global::System.Windows.Forms.NumericUpDown numericUpDown18 = this.numberThuHoaX;
		int[] array18 = new int[4];
		array18[0] = 999;
		numericUpDown18.Maximum = new decimal(array18);
		this.numberThuHoaX.Name = "numberThuHoaX";
		this.numberThuHoaX.Size = new global::System.Drawing.Size(45, 20);
		this.numberThuHoaX.TabIndex = 277;
		this.toolTip_0.SetToolTip(this.numberThuHoaX, "Chỉ thu hoạch bách hoa duyên trong tọa độ X +");
		this.numberThuHoaX.ValueChanged += new global::System.EventHandler(this.numberThuHoaX_ValueChanged);
		this.numberRadiusThuHoa.Location = new global::System.Drawing.Point(73, 16);
		global::System.Windows.Forms.NumericUpDown numericUpDown19 = this.numberRadiusThuHoa;
		int[] array19 = new int[4];
		array19[0] = 999;
		numericUpDown19.Maximum = new decimal(array19);
		global::System.Windows.Forms.NumericUpDown numericUpDown20 = this.numberRadiusThuHoa;
		int[] array20 = new int[4];
		array20[0] = 1;
		numericUpDown20.Minimum = new decimal(array20);
		this.numberRadiusThuHoa.Name = "numberRadiusThuHoa";
		this.numberRadiusThuHoa.Size = new global::System.Drawing.Size(45, 20);
		this.numberRadiusThuHoa.TabIndex = 279;
		this.toolTip_0.SetToolTip(this.numberRadiusThuHoa, "Chỉ thu hoạch bách hoa duyên trong tọa độ X +");
		global::System.Windows.Forms.NumericUpDown numericUpDown21 = this.numberRadiusThuHoa;
		int[] array21 = new int[4];
		array21[0] = 999;
		numericUpDown21.Value = new decimal(array21);
		this.numberRadiusThuHoa.ValueChanged += new global::System.EventHandler(this.numberRadiusThuHoa_ValueChanged);
		this.nudTangTiemNang.Dock = global::System.Windows.Forms.DockStyle.Left;
		this.nudTangTiemNang.Location = new global::System.Drawing.Point(3, 16);
		global::System.Windows.Forms.NumericUpDown numericUpDown22 = this.nudTangTiemNang;
		int[] array22 = new int[4];
		array22[0] = 999999;
		numericUpDown22.Maximum = new decimal(array22);
		this.nudTangTiemNang.Name = "nudTangTiemNang";
		this.nudTangTiemNang.Size = new global::System.Drawing.Size(44, 20);
		this.nudTangTiemNang.TabIndex = 246;
		this.toolTip_0.SetToolTip(this.nudTangTiemNang, "Điểm Tăng");
		global::System.Windows.Forms.NumericUpDown numericUpDown23 = this.nudTangTiemNang;
		int[] array23 = new int[4];
		array23[0] = 75;
		numericUpDown23.Value = new decimal(array23);
		this.checkHaiDuoc.AutoSize = true;
		this.checkHaiDuoc.Location = new global::System.Drawing.Point(101, 59);
		this.checkHaiDuoc.Name = "checkHaiDuoc";
		this.checkHaiDuoc.Size = new global::System.Drawing.Size(69, 17);
		this.checkHaiDuoc.TabIndex = 225;
		this.checkHaiDuoc.Text = "Hái dược";
		this.toolTip_0.SetToolTip(this.checkHaiDuoc, "di chuyển nhân vật đếm bản đồ cần hái dược để sử dụng chức năng này\r\nbấm vào < để loại bỏ những thứ không muốn hái dược\r\n");
		this.checkHaiDuoc.UseVisualStyleBackColor = true;
		this.checkHaiDuoc.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkTrongTrot.AutoSize = true;
		this.checkTrongTrot.Location = new global::System.Drawing.Point(10, 82);
		this.checkTrongTrot.Name = "checkTrongTrot";
		this.checkTrongTrot.Size = new global::System.Drawing.Size(72, 17);
		this.checkTrongTrot.TabIndex = 226;
		this.checkTrongTrot.Text = "Trồng trọt";
		this.toolTip_0.SetToolTip(this.checkTrongTrot, "di chuyển đến gần nơi trồng cây để sử dụng chức năng này\r\nchọn cây thứ mấy để trồng theo cấp cần trồng");
		this.checkTrongTrot.UseVisualStyleBackColor = true;
		this.checkTrongTrot.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkThuHoach.AutoSize = true;
		this.checkThuHoach.Location = new global::System.Drawing.Point(101, 82);
		this.checkThuHoach.Name = "checkThuHoach";
		this.checkThuHoach.Size = new global::System.Drawing.Size(78, 17);
		this.checkThuHoach.TabIndex = 227;
		this.checkThuHoach.Text = "Thu hoạch";
		this.toolTip_0.SetToolTip(this.checkThuHoach, "tick vào đây để thu hoạc cây trồng");
		this.checkThuHoach.UseVisualStyleBackColor = true;
		this.checkThuHoach.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.checkXuatPet.AutoSize = true;
		this.checkXuatPet.Location = new global::System.Drawing.Point(9, 36);
		this.checkXuatPet.Name = "checkXuatPet";
		this.checkXuatPet.Size = new global::System.Drawing.Size(67, 17);
		this.checkXuatPet.TabIndex = 3;
		this.checkXuatPet.Text = "Xuất Pet";
		this.checkXuatPet.TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.toolTip_0.SetToolTip(this.checkXuatPet, "không xuất pet (bỏ tick để auto tự xuất)");
		this.checkXuatPet.UseVisualStyleBackColor = true;
		this.checkXuatPet.CheckedChanged += new global::System.EventHandler(this.checkXuatPet_CheckedChanged);
		this.checkKhaiKhoang.AutoSize = true;
		this.checkKhaiKhoang.Location = new global::System.Drawing.Point(9, 59);
		this.checkKhaiKhoang.Name = "checkKhaiKhoang";
		this.checkKhaiKhoang.Size = new global::System.Drawing.Size(86, 17);
		this.checkKhaiKhoang.TabIndex = 224;
		this.checkKhaiKhoang.Text = "Khai khoáng";
		this.toolTip_0.SetToolTip(this.checkKhaiKhoang, "di chuyển nhân vật đếm bản đồ cần khai khoáng để sử dụng chức năng này\r\nbấm vào < để loại bỏ những thứ không muốn khai khoáng");
		this.checkKhaiKhoang.UseVisualStyleBackColor = true;
		this.checkKhaiKhoang.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.chkRaoVat.AutoSize = true;
		this.chkRaoVat.ForeColor = global::System.Drawing.Color.Black;
		this.chkRaoVat.Location = new global::System.Drawing.Point(9, 9);
		this.chkRaoVat.Name = "chkRaoVat";
		this.chkRaoVat.Size = new global::System.Drawing.Size(64, 17);
		this.chkRaoVat.TabIndex = 175;
		this.chkRaoVat.Text = "Rao vặt";
		this.toolTip_0.SetToolTip(this.chkRaoVat, "rao vặt mỗi 3 phút kênh thế giới và kênh gần");
		this.chkRaoVat.UseVisualStyleBackColor = true;
		this.chkRaoVat.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.txtRao.Location = new global::System.Drawing.Point(79, 7);
		this.txtRao.Name = "txtRao";
		this.txtRao.Size = new global::System.Drawing.Size(183, 20);
		this.txtRao.TabIndex = 177;
		this.toolTip_0.SetToolTip(this.txtRao, "nội dung rao vặt");
		this.txtRao.String_0 = "Lặp lại";
		this.txtRao.Color_0 = global::System.Drawing.Color.Gray;
		this.txtRao.Font_0 = new global::System.Drawing.Font("Arial", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtRao.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtRao.TextChanged += new global::System.EventHandler(this.txtRao_TextChanged);
		this.chkBanRac.AutoSize = true;
		this.chkBanRac.Location = new global::System.Drawing.Point(189, 125);
		this.chkBanRac.Name = "chkBanRac";
		this.chkBanRac.Size = new global::System.Drawing.Size(84, 17);
		this.chkBanRac.TabIndex = 248;
		this.chkBanRac.Text = "Tự Bán Rác";
		this.toolTip_0.SetToolTip(this.chkBanRac, "Tự Bán Rác + Cất Đồ + Trị Liệu + Phân Giải\r\nSau Mỗi Phụ Bản");
		this.chkBanRac.UseVisualStyleBackColor = true;
		this.chkBanRac.CheckedChanged += new global::System.EventHandler(this.chkBanRac_CheckedChanged);
		this.chkBinhThanh.AutoSize = true;
		this.chkBinhThanh.Location = new global::System.Drawing.Point(13, 10);
		this.chkBinhThanh.Name = "chkBinhThanh";
		this.chkBinhThanh.Size = new global::System.Drawing.Size(81, 17);
		this.chkBinhThanh.TabIndex = 23;
		this.chkBinhThanh.Text = "Binh Thánh";
		this.toolTip_0.SetToolTip(this.chkBinhThanh, "Binh Thánh Kỳ Trận");
		this.chkBinhThanh.UseVisualStyleBackColor = true;
		this.chkBinhThanh.CheckedChanged += new global::System.EventHandler(this.chkBinhThanh_CheckedChanged);
		this.chkKho.AutoSize = true;
		this.chkKho.Location = new global::System.Drawing.Point(100, 10);
		this.chkKho.Name = "chkKho";
		this.chkKho.Size = new global::System.Drawing.Size(45, 17);
		this.chkKho.TabIndex = 24;
		this.chkKho.Text = "Khó";
		this.toolTip_0.SetToolTip(this.chkKho, "Kỳ Binh - Khó");
		this.chkKho.UseVisualStyleBackColor = true;
		this.chkKho.CheckedChanged += new global::System.EventHandler(this.chkKho_CheckedChanged);
		this.chkPhieuMieuPhong.AutoSize = true;
		this.chkPhieuMieuPhong.Location = new global::System.Drawing.Point(13, 33);
		this.chkPhieuMieuPhong.Name = "chkPhieuMieuPhong";
		this.chkPhieuMieuPhong.Size = new global::System.Drawing.Size(49, 17);
		this.chkPhieuMieuPhong.TabIndex = 10;
		this.chkPhieuMieuPhong.Text = "PMP";
		this.toolTip_0.SetToolTip(this.chkPhieuMieuPhong, "Phiêu Miễu Phong");
		this.chkPhieuMieuPhong.UseVisualStyleBackColor = true;
		this.chkPhieuMieuPhong.CheckedChanged += new global::System.EventHandler(this.chkPhieuMieuPhong_CheckedChanged);
		this.chkTamThan.AutoSize = true;
		this.chkTamThan.Location = new global::System.Drawing.Point(189, 102);
		this.chkTamThan.Name = "chkTamThan";
		this.chkTamThan.Size = new global::System.Drawing.Size(75, 17);
		this.chkTamThan.TabIndex = 19;
		this.chkTamThan.Text = "Tam Thần";
		this.toolTip_0.SetToolTip(this.chkTamThan, "Tam Thần");
		this.chkTamThan.UseVisualStyleBackColor = true;
		this.chkTamThan.CheckedChanged += new global::System.EventHandler(this.chkTamThan_CheckedChanged);
		this.chkYenTuO.AutoSize = true;
		this.chkYenTuO.Location = new global::System.Drawing.Point(13, 79);
		this.chkYenTuO.Name = "chkYenTuO";
		this.chkYenTuO.Size = new global::System.Drawing.Size(72, 17);
		this.chkYenTuO.TabIndex = 14;
		this.chkYenTuO.Text = "Yến Tử Ô";
		this.toolTip_0.SetToolTip(this.chkYenTuO, "Yến Tử Ô");
		this.chkYenTuO.UseVisualStyleBackColor = true;
		this.chkYenTuO.CheckedChanged += new global::System.EventHandler(this.chkYenTuO_CheckedChanged);
		this.chkQLauLan.AutoSize = true;
		this.chkQLauLan.Location = new global::System.Drawing.Point(189, 10);
		this.chkQLauLan.Name = "chkQLauLan";
		this.chkQLauLan.Size = new global::System.Drawing.Size(76, 17);
		this.chkQLauLan.TabIndex = 13;
		this.chkQLauLan.Text = "Q Lâu Lan";
		this.toolTip_0.SetToolTip(this.chkQLauLan, "Q Lâu Lan");
		this.chkQLauLan.UseVisualStyleBackColor = true;
		this.chkQLauLan.CheckedChanged += new global::System.EventHandler(this.chkQLauLan_CheckedChanged);
		this.chkPhucDia.AutoSize = true;
		this.chkPhucDia.Location = new global::System.Drawing.Point(189, 56);
		this.chkPhucDia.Name = "chkPhucDia";
		this.chkPhucDia.Size = new global::System.Drawing.Size(70, 17);
		this.chkPhucDia.TabIndex = 20;
		this.chkPhucDia.Text = "Phúc Địa";
		this.toolTip_0.SetToolTip(this.chkPhucDia, "Phúc Địa");
		this.chkPhucDia.UseVisualStyleBackColor = true;
		this.chkPhucDia.CheckedChanged += new global::System.EventHandler(this.chkPhucDia_CheckedChanged);
		this.chkSatTinh.AutoSize = true;
		this.chkSatTinh.Location = new global::System.Drawing.Point(13, 148);
		this.chkSatTinh.Name = "chkSatTinh";
		this.chkSatTinh.Size = new global::System.Drawing.Size(66, 17);
		this.chkSatTinh.TabIndex = 15;
		this.chkSatTinh.Text = "Sát Tinh";
		this.toolTip_0.SetToolTip(this.chkSatTinh, "Sát Tinh");
		this.chkSatTinh.UseVisualStyleBackColor = true;
		this.chkSatTinh.CheckedChanged += new global::System.EventHandler(this.chkSatTinh_CheckedChanged);
		this.chkHuyetChien.AutoSize = true;
		this.chkHuyetChien.Location = new global::System.Drawing.Point(13, 56);
		this.chkHuyetChien.Name = "chkHuyetChien";
		this.chkHuyetChien.Size = new global::System.Drawing.Size(116, 17);
		this.chkHuyetChien.TabIndex = 11;
		this.chkHuyetChien.Text = "PMP - Huyết Chiến";
		this.toolTip_0.SetToolTip(this.chkHuyetChien, "Huyết Chiến - Phiêu Miễu Phong");
		this.chkHuyetChien.UseVisualStyleBackColor = true;
		this.chkHuyetChien.CheckedChanged += new global::System.EventHandler(this.chkHuyetChien_CheckedChanged);
		this.chkPDKho.AutoSize = true;
		this.chkPDKho.Location = new global::System.Drawing.Point(276, 56);
		this.chkPDKho.Name = "chkPDKho";
		this.chkPDKho.Size = new global::System.Drawing.Size(45, 17);
		this.chkPDKho.TabIndex = 21;
		this.chkPDKho.Text = "Khó";
		this.toolTip_0.SetToolTip(this.chkPDKho, "Phúc Địa - Khó");
		this.chkPDKho.UseVisualStyleBackColor = true;
		this.chkPDKho.CheckedChanged += new global::System.EventHandler(this.chkPDKho_CheckedChanged);
		this.chkTuTuyetTrang.AutoSize = true;
		this.chkTuTuyetTrang.Location = new global::System.Drawing.Point(13, 102);
		this.chkTuTuyetTrang.Name = "chkTuTuyetTrang";
		this.chkTuTuyetTrang.Size = new global::System.Drawing.Size(100, 17);
		this.chkTuTuyetTrang.TabIndex = 16;
		this.chkTuTuyetTrang.Text = "Tứ Tuyệt Trang";
		this.toolTip_0.SetToolTip(this.chkTuTuyetTrang, "Tứ Tuyệt Trang");
		this.chkTuTuyetTrang.UseVisualStyleBackColor = true;
		this.chkTuTuyetTrang.CheckedChanged += new global::System.EventHandler(this.chkTuTuyetTrang_CheckedChanged);
		this.chkQToChau.AutoSize = true;
		this.chkQToChau.Location = new global::System.Drawing.Point(189, 33);
		this.chkQToChau.Name = "chkQToChau";
		this.chkQToChau.Size = new global::System.Drawing.Size(78, 17);
		this.chkQToChau.TabIndex = 12;
		this.chkQToChau.Text = "Q Tô Châu";
		this.toolTip_0.SetToolTip(this.chkQToChau, "Q Tô Châu");
		this.chkQToChau.UseVisualStyleBackColor = true;
		this.chkQToChau.CheckedChanged += new global::System.EventHandler(this.chkQToChau_CheckedChanged);
		this.chkVuongLang.AutoSize = true;
		this.chkVuongLang.Location = new global::System.Drawing.Point(189, 79);
		this.chkVuongLang.Name = "chkVuongLang";
		this.chkVuongLang.Size = new global::System.Drawing.Size(84, 17);
		this.chkVuongLang.TabIndex = 17;
		this.chkVuongLang.Text = "Vương Lăng";
		this.toolTip_0.SetToolTip(this.chkVuongLang, "Vương Lăng");
		this.chkVuongLang.UseVisualStyleBackColor = true;
		this.chkVuongLang.CheckedChanged += new global::System.EventHandler(this.chkVuongLang_CheckedChanged);
		this.chkThieuThatSon.AutoSize = true;
		this.chkThieuThatSon.Location = new global::System.Drawing.Point(13, 125);
		this.chkThieuThatSon.Name = "chkThieuThatSon";
		this.chkThieuThatSon.Size = new global::System.Drawing.Size(100, 17);
		this.chkThieuThatSon.TabIndex = 18;
		this.chkThieuThatSon.Text = "Thiếu Thất Sơn";
		this.toolTip_0.SetToolTip(this.chkThieuThatSon, "Thiếu Thất Sơn");
		this.chkThieuThatSon.UseVisualStyleBackColor = true;
		this.chkThieuThatSon.CheckedChanged += new global::System.EventHandler(this.chkThieuThatSon_CheckedChanged);
		this.chkAutoDropCraft.AutoSize = true;
		this.chkAutoDropCraft.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.chkAutoDropCraft.Location = new global::System.Drawing.Point(8, 38);
		this.chkAutoDropCraft.Name = "chkAutoDropCraft";
		this.chkAutoDropCraft.Size = new global::System.Drawing.Size(83, 17);
		this.chkAutoDropCraft.TabIndex = 15;
		this.chkAutoDropCraft.Text = "Auto Drop <";
		this.toolTip_0.SetToolTip(this.chkAutoDropCraft, "Tự động hủy trang bị dưới thông số");
		this.chkAutoDropCraft.UseVisualStyleBackColor = true;
		this.chkAutoDropCraft.CheckedChanged += new global::System.EventHandler(this.chkAutoDropCraft_CheckedChanged);
		this.nudStar.Location = new global::System.Drawing.Point(99, 11);
		global::System.Windows.Forms.NumericUpDown numericUpDown24 = this.nudStar;
		int[] array24 = new int[4];
		array24[0] = 9;
		numericUpDown24.Maximum = new decimal(array24);
		global::System.Windows.Forms.NumericUpDown numericUpDown25 = this.nudStar;
		int[] array25 = new int[4];
		array25[0] = 1;
		numericUpDown25.Minimum = new decimal(array25);
		this.nudStar.Name = "nudStar";
		this.nudStar.Size = new global::System.Drawing.Size(40, 20);
		this.nudStar.TabIndex = 8;
		this.toolTip_0.SetToolTip(this.nudStar, "Num Star");
		global::System.Windows.Forms.NumericUpDown numericUpDown26 = this.nudStar;
		int[] array26 = new int[4];
		array26[0] = 6;
		numericUpDown26.Value = new decimal(array26);
		this.nudStar.ValueChanged += new global::System.EventHandler(this.nudStar_ValueChanged);
		this.nudLine.Location = new global::System.Drawing.Point(99, 37);
		global::System.Windows.Forms.NumericUpDown numericUpDown27 = this.nudLine;
		int[] array27 = new int[4];
		array27[0] = 99;
		numericUpDown27.Maximum = new decimal(array27);
		global::System.Windows.Forms.NumericUpDown numericUpDown28 = this.nudLine;
		int[] array28 = new int[4];
		array28[0] = 1;
		numericUpDown28.Minimum = new decimal(array28);
		this.nudLine.Name = "nudLine";
		this.nudLine.Size = new global::System.Drawing.Size(40, 20);
		this.nudLine.TabIndex = 10;
		this.toolTip_0.SetToolTip(this.nudLine, "Num Line");
		global::System.Windows.Forms.NumericUpDown numericUpDown29 = this.nudLine;
		int[] array29 = new int[4];
		array29[0] = 5;
		numericUpDown29.Value = new decimal(array29);
		this.nudLine.ValueChanged += new global::System.EventHandler(this.nudLine_ValueChanged);
		this.nudPoint.Location = new global::System.Drawing.Point(99, 63);
		global::System.Windows.Forms.NumericUpDown numericUpDown30 = this.nudPoint;
		int[] array30 = new int[4];
		array30[0] = 999;
		numericUpDown30.Maximum = new decimal(array30);
		this.nudPoint.Name = "nudPoint";
		this.nudPoint.Size = new global::System.Drawing.Size(40, 20);
		this.nudPoint.TabIndex = 12;
		this.toolTip_0.SetToolTip(this.nudPoint, "Num Life-Blood");
		this.nudPoint.ValueChanged += new global::System.EventHandler(this.nudPoint_ValueChanged);
		this.chkStartCraft.AutoSize = true;
		this.chkStartCraft.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.chkStartCraft.Location = new global::System.Drawing.Point(162, 180);
		this.chkStartCraft.Name = "chkStartCraft";
		this.chkStartCraft.Size = new global::System.Drawing.Size(48, 17);
		this.chkStartCraft.TabIndex = 19;
		this.chkStartCraft.Text = "Start";
		this.toolTip_0.SetToolTip(this.chkStartCraft, "Bắt đầu chế đồ");
		this.chkStartCraft.UseVisualStyleBackColor = true;
		this.chkStartCraft.CheckedChanged += new global::System.EventHandler(this.chkStartCraft_CheckedChanged);
		this.chkMuaNguyenLieu.AutoSize = true;
		this.chkMuaNguyenLieu.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.chkMuaNguyenLieu.Location = new global::System.Drawing.Point(87, 180);
		this.chkMuaNguyenLieu.Name = "chkMuaNguyenLieu";
		this.chkMuaNguyenLieu.Size = new global::System.Drawing.Size(69, 17);
		this.chkMuaNguyenLieu.TabIndex = 18;
		this.chkMuaNguyenLieu.Text = "Auto Buy";
		this.toolTip_0.SetToolTip(this.chkMuaNguyenLieu, "Tự mua nguyên liệu");
		this.chkMuaNguyenLieu.UseVisualStyleBackColor = true;
		this.chkMuaNguyenLieu.CheckedChanged += new global::System.EventHandler(this.chkMuaNguyenLieu_CheckedChanged);
		this.chkGiamDinh.AutoSize = true;
		this.chkGiamDinh.Location = new global::System.Drawing.Point(7, 180);
		this.chkGiamDinh.Name = "chkGiamDinh";
		this.chkGiamDinh.Size = new global::System.Drawing.Size(74, 17);
		this.chkGiamDinh.TabIndex = 16;
		this.chkGiamDinh.Text = "Kiểm Định";
		this.toolTip_0.SetToolTip(this.chkGiamDinh, "Auto Check Point");
		this.chkGiamDinh.UseVisualStyleBackColor = true;
		this.chkGiamDinh.CheckedChanged += new global::System.EventHandler(this.chkGiamDinh_CheckedChanged);
		this.timer_2.Enabled = true;
		this.timer_2.Interval = 3600000;
		this.timer_2.Tick += new global::System.EventHandler(this.timer_2_Tick);
		this.columnHeader_0.Text = "User";
		this.columnHeader_0.Width = 76;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 76;
		this.columnHeader_2.Text = "Status";
		this.columnHeader_2.Width = 79;
		this.columnHeader_3.Text = "User";
		this.columnHeader_3.Width = 83;
		this.columnHeader_4.Text = "Name";
		this.columnHeader_4.Width = 85;
		this.columnHeader_5.Text = "Status";
		this.columnHeader_5.Width = 76;
		this.timer_3.Interval = 1000;
		this.timer_3.Tick += new global::System.EventHandler(this.timer_3_Tick);
		this.timer_4.Enabled = true;
		this.timer_4.Interval = 600000;
		this.timer_4.Tick += new global::System.EventHandler(this.timer_4_Tick);
		this.backgroundWorker_0.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_0_DoWork);
		this.mainMenu.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.playerToolStripMenuItem,
			this.leaderToolStripMenuItem,
			this.dailyToolStripMenuItem,
			this.allToolStripMenuItem1,
			this.menuNier,
			this.toolStripMenuItem30,
			this.toolStripMenuItem19
		});
		this.mainMenu.Location = new global::System.Drawing.Point(0, 0);
		this.mainMenu.Name = "mainMenu";
		this.mainMenu.Size = new global::System.Drawing.Size(384, 24);
		this.mainMenu.TabIndex = 10;
		this.mainMenu.Text = "MainMenu";
		this.playerToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muTriLieu,
			this.muDiBanRac,
			this.muThuongKho,
			this.toolStripMenuItem_25,
			this.muTriLieuBanRacCatDo,
			this.muPhanGiaiTrangBijPet,
			this.toolStripSeparator17,
			this.muNhanDoi,
			this.toolStripMenuItem_46,
			this.toolStripMenuItem_44,
			this.toolStripMenuItem_45,
			this.muBHD,
			this.toolStripSeparator44,
			this.toolStripMenuItem_36,
			this.toolStripMenuItem_43
		});
		this.playerToolStripMenuItem.Name = "playerToolStripMenuItem";
		this.playerToolStripMenuItem.Size = new global::System.Drawing.Size(51, 20);
		this.playerToolStripMenuItem.Text = "Player";
		this.playerToolStripMenuItem.DropDownOpening += new global::System.EventHandler(this.playerToolStripMenuItem_DropDownOpening);
		this.playerToolStripMenuItem.Click += new global::System.EventHandler(this.playerToolStripMenuItem_Click);
		this.muTriLieu.Name = "muTriLieu";
		this.muTriLieu.Size = new global::System.Drawing.Size(231, 22);
		this.muTriLieu.Text = "Trị Liệu";
		this.muTriLieu.Click += new global::System.EventHandler(this.muTriLieu_Click);
		this.muDiBanRac.Name = "muDiBanRac";
		this.muDiBanRac.Size = new global::System.Drawing.Size(231, 22);
		this.muDiBanRac.Text = "Đi Bán Rác";
		this.muDiBanRac.Click += new global::System.EventHandler(this.muDiBanRac_Click);
		this.muThuongKho.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_145,
			this.muCatDo,
			this.muLayDo,
			this.muLayDoLayVang
		});
		this.muThuongKho.Name = "muThuongKho";
		this.muThuongKho.Size = new global::System.Drawing.Size(231, 22);
		this.muThuongKho.Text = "Thương Khố";
		this.toolStripMenuItem_145.Name = "mởTừXaCtrlBToolStripMenuItem";
		this.toolStripMenuItem_145.Size = new global::System.Drawing.Size(175, 22);
		this.toolStripMenuItem_145.Text = "Mở Từ Xa [Ctrl + B]";
		this.toolStripMenuItem_145.Click += new global::System.EventHandler(this.toolStripMenuItem_145_Click);
		this.muCatDo.Name = "muCatDo";
		this.muCatDo.Size = new global::System.Drawing.Size(175, 22);
		this.muCatDo.Text = "Cất Đồ";
		this.muCatDo.Click += new global::System.EventHandler(this.muCatDo_Click);
		this.muLayDo.Name = "muLayDo";
		this.muLayDo.Size = new global::System.Drawing.Size(175, 22);
		this.muLayDo.Text = "Lấy Đồ";
		this.muLayDo.Click += new global::System.EventHandler(this.muLayDo_Click);
		this.muLayDoLayVang.Name = "muLayDoLayVang";
		this.muLayDoLayVang.Size = new global::System.Drawing.Size(175, 22);
		this.muLayDoLayVang.Text = "Lấy Đồ + Vàng";
		this.muLayDoLayVang.Click += new global::System.EventHandler(this.muLayDoLayVang_Click);
		this.toolStripMenuItem_25.Name = "bánRácCấtĐồToolStripMenuItem";
		this.toolStripMenuItem_25.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_25.Text = "Bán Rác + Cất Đồ";
		this.toolStripMenuItem_25.Click += new global::System.EventHandler(this.toolStripMenuItem_25_Click);
		this.muTriLieuBanRacCatDo.Name = "muTriLieuBanRacCatDo";
		this.muTriLieuBanRacCatDo.Size = new global::System.Drawing.Size(231, 22);
		this.muTriLieuBanRacCatDo.Text = "Trị Liệu + Đi Bán Rác + Cất Đồ";
		this.muTriLieuBanRacCatDo.Click += new global::System.EventHandler(this.muTriLieuBanRacCatDo_Click);
		this.muPhanGiaiTrangBijPet.Name = "muPhanGiaiTrangBijPet";
		this.muPhanGiaiTrangBijPet.Size = new global::System.Drawing.Size(231, 22);
		this.muPhanGiaiTrangBijPet.Text = "Phân Giải Trang Bị Pet";
		this.muPhanGiaiTrangBijPet.Click += new global::System.EventHandler(this.muPhanGiaiTrangBijPet_Click);
		this.toolStripSeparator17.Name = "toolStripSeparator17";
		this.toolStripSeparator17.Size = new global::System.Drawing.Size(228, 6);
		this.muNhanDoi.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muMoShop,
			this.menuTuLuyen,
			this.toolStripMenuItem_165,
			this.muNhanx2,
			this.muDongx2,
			this.muDiMuaNgua,
			this.muHuyVatPhamQuy,
			this.muNopTuViHuyTinh,
			this.muThanhLyNhiemVu,
			this.muGiaoNguHanhPhapThiep,
			this.muTangCapTruongThanhLongVan,
			this.muCheThanKhi,
			this.toolStripMenuItem_47,
			this.toolStripMenuItem_182,
			this.toolStripMenuItem_183,
			this.muMua100KimSangDuoc
		});
		this.muNhanDoi.Name = "muNhanDoi";
		this.muNhanDoi.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanDoi.Text = "Đi";
		this.muMoShop.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muMoShopTrungDo,
			this.muMoShopHungBa,
			this.muMoShopBachBaoCac,
			this.muMoShopQuyThi,
			this.muMoTiemThuoc
		});
		this.muMoShop.Name = "muMoShop";
		this.muMoShop.Size = new global::System.Drawing.Size(251, 22);
		this.muMoShop.Text = "Đi Mở Shop";
		this.muMoShopTrungDo.Name = "muMoShopTrungDo";
		this.muMoShopTrungDo.Size = new global::System.Drawing.Size(167, 22);
		this.muMoShopTrungDo.Text = "Shop Trung Đô";
		this.muMoShopTrungDo.Click += new global::System.EventHandler(this.muMoShopTrungDo_Click);
		this.muMoShopHungBa.Name = "muMoShopHungBa";
		this.muMoShopHungBa.Size = new global::System.Drawing.Size(167, 22);
		this.muMoShopHungBa.Text = "Shop Chiến Công";
		this.muMoShopHungBa.Click += new global::System.EventHandler(this.muMoShopHungBa_Click);
		this.muMoShopBachBaoCac.Name = "muMoShopBachBaoCac";
		this.muMoShopBachBaoCac.Size = new global::System.Drawing.Size(167, 22);
		this.muMoShopBachBaoCac.Text = "Bách Bảo Các";
		this.muMoShopBachBaoCac.Click += new global::System.EventHandler(this.muMoShopBachBaoCac_Click);
		this.muMoShopQuyThi.Name = "muMoShopQuyThi";
		this.muMoShopQuyThi.Size = new global::System.Drawing.Size(167, 22);
		this.muMoShopQuyThi.Text = "Shop Quỷ Thị";
		this.muMoShopQuyThi.Click += new global::System.EventHandler(this.muMoShopQuyThi_Click);
		this.muMoTiemThuoc.Name = "muMoTiemThuoc";
		this.muMoTiemThuoc.Size = new global::System.Drawing.Size(167, 22);
		this.muMoTiemThuoc.Text = "Tiệm Thuốc";
		this.muMoTiemThuoc.Click += new global::System.EventHandler(this.muMoTiemThuoc_Click);
		this.menuTuLuyen.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muTuLuyenTheLuc,
			this.muTuLuyenNoiLuc,
			this.muTuLuyenThanPhap,
			this.muTuLuyenCuongLuc,
			this.muTuLuyenTheNoiThan
		});
		this.menuTuLuyen.Name = "menuTuLuyen";
		this.menuTuLuyen.Size = new global::System.Drawing.Size(251, 22);
		this.menuTuLuyen.Text = "Đi Tu Luyện";
		this.muTuLuyenTheLuc.Name = "muTuLuyenTheLuc";
		this.muTuLuyenTheLuc.Size = new global::System.Drawing.Size(166, 22);
		this.muTuLuyenTheLuc.Text = "Thể Lực";
		this.muTuLuyenTheLuc.Click += new global::System.EventHandler(this.muTuLuyenTheLuc_Click);
		this.muTuLuyenNoiLuc.Name = "muTuLuyenNoiLuc";
		this.muTuLuyenNoiLuc.Size = new global::System.Drawing.Size(166, 22);
		this.muTuLuyenNoiLuc.Text = "Nội Lực";
		this.muTuLuyenNoiLuc.Click += new global::System.EventHandler(this.muTuLuyenNoiLuc_Click);
		this.muTuLuyenThanPhap.Name = "muTuLuyenThanPhap";
		this.muTuLuyenThanPhap.Size = new global::System.Drawing.Size(166, 22);
		this.muTuLuyenThanPhap.Text = "Thân Pháp";
		this.muTuLuyenThanPhap.Click += new global::System.EventHandler(this.muTuLuyenThanPhap_Click);
		this.muTuLuyenCuongLuc.Name = "muTuLuyenCuongLuc";
		this.muTuLuyenCuongLuc.Size = new global::System.Drawing.Size(166, 22);
		this.muTuLuyenCuongLuc.Text = "Cường Lực";
		this.muTuLuyenCuongLuc.Click += new global::System.EventHandler(this.muTuLuyenCuongLuc_Click);
		this.muTuLuyenTheNoiThan.Name = "muTuLuyenTheNoiThan";
		this.muTuLuyenTheNoiThan.Size = new global::System.Drawing.Size(166, 22);
		this.muTuLuyenTheNoiThan.Text = "Thể + Nội + Thân";
		this.muTuLuyenTheNoiThan.Click += new global::System.EventHandler(this.muTuLuyenTheNoiThan_Click);
		this.toolStripMenuItem_165.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_193,
			this.toolStripMenuItem_166,
			this.toolStripMenuItem_198,
			this.toolStripMenuItem_167,
			this.toolStripMenuItem_199,
			this.toolStripMenuItem_168,
			this.toolStripMenuItem_169,
			this.toolStripMenuItem_170
		});
		this.toolStripMenuItem_165.Name = "nângTâmPhápToolStripMenuItem1";
		this.toolStripMenuItem_165.Size = new global::System.Drawing.Size(251, 22);
		this.toolStripMenuItem_165.Text = "Nâng Tâm Pháp";
		this.toolStripMenuItem_193.Name = "quyển3Lên30ToolStripMenuItem";
		this.toolStripMenuItem_193.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_193.Text = "Quyển 3 Lên 30";
		this.toolStripMenuItem_193.Click += new global::System.EventHandler(this.toolStripMenuItem_193_Click);
		this.toolStripMenuItem_166.Name = "lên30ToolStripMenuItem";
		this.toolStripMenuItem_166.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_166.Text = "Lên 30";
		this.toolStripMenuItem_166.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_198.Name = "lên40ToolStripMenuItem";
		this.toolStripMenuItem_198.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_198.Text = "Lên 40";
		this.toolStripMenuItem_198.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_167.Name = "lên45ToolStripMenuItem";
		this.toolStripMenuItem_167.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_167.Text = "Lên 45";
		this.toolStripMenuItem_167.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_199.Name = "lên50ToolStripMenuItem";
		this.toolStripMenuItem_199.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_199.Text = "Lên 50";
		this.toolStripMenuItem_199.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_168.Name = "lên60ToolStripMenuItem";
		this.toolStripMenuItem_168.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_168.Text = "Lên 60";
		this.toolStripMenuItem_168.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_169.Name = "lên80ToolStripMenuItem";
		this.toolStripMenuItem_169.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_169.Text = "Lên 80";
		this.toolStripMenuItem_169.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.toolStripMenuItem_170.Name = "lên100ToolStripMenuItem";
		this.toolStripMenuItem_170.Size = new global::System.Drawing.Size(155, 22);
		this.toolStripMenuItem_170.Text = "Lên 100";
		this.toolStripMenuItem_170.Click += new global::System.EventHandler(this.toolStripMenuItem_170_Click);
		this.muNhanx2.Name = "muNhanx2";
		this.muNhanx2.Size = new global::System.Drawing.Size(251, 22);
		this.muNhanx2.Text = "Đi Nhận x2";
		this.muNhanx2.Click += new global::System.EventHandler(this.muNhanx2_Click);
		this.muDongx2.Name = "muDongx2";
		this.muDongx2.Size = new global::System.Drawing.Size(251, 22);
		this.muDongx2.Text = "Đi Đông x2";
		this.muDongx2.Click += new global::System.EventHandler(this.muDongx2_Click);
		this.muDiMuaNgua.Name = "muDiMuaNgua";
		this.muDiMuaNgua.Size = new global::System.Drawing.Size(251, 22);
		this.muDiMuaNgua.Text = "Đi Mua Ngựa";
		this.muDiMuaNgua.Click += new global::System.EventHandler(this.muDiMuaNgua_Click);
		this.muHuyVatPhamQuy.Name = "muHuyVatPhamQuy";
		this.muHuyVatPhamQuy.Size = new global::System.Drawing.Size(251, 22);
		this.muHuyVatPhamQuy.Text = "Đi Hủy Vật Phẩm Quý";
		this.muHuyVatPhamQuy.Click += new global::System.EventHandler(this.muHuyVatPhamQuy_Click);
		this.muNopTuViHuyTinh.Name = "muNopTuViHuyTinh";
		this.muNopTuViHuyTinh.Size = new global::System.Drawing.Size(251, 22);
		this.muNopTuViHuyTinh.Text = "Đi Nộp Tử Vi Huy Tinh";
		this.muNopTuViHuyTinh.Click += new global::System.EventHandler(this.muNopTuViHuyTinh_Click);
		this.muThanhLyNhiemVu.Name = "muThanhLyNhiemVu";
		this.muThanhLyNhiemVu.Size = new global::System.Drawing.Size(251, 22);
		this.muThanhLyNhiemVu.Text = "Đi Thanh Lý Nhiệm Vụ";
		this.muThanhLyNhiemVu.Click += new global::System.EventHandler(this.muThanhLyNhiemVu_Click);
		this.muGiaoNguHanhPhapThiep.Name = "muGiaoNguHanhPhapThiep";
		this.muGiaoNguHanhPhapThiep.Size = new global::System.Drawing.Size(251, 22);
		this.muGiaoNguHanhPhapThiep.Text = "Giao Ngũ Hành Thiệp";
		this.muGiaoNguHanhPhapThiep.Click += new global::System.EventHandler(this.muGiaoNguHanhPhapThiep_Click);
		this.muTangCapTruongThanhLongVan.Name = "muTangCapTruongThanhLongVan";
		this.muTangCapTruongThanhLongVan.Size = new global::System.Drawing.Size(251, 22);
		this.muTangCapTruongThanhLongVan.Text = "Tăng Cấp Trưởng Thành Long Văn";
		this.muTangCapTruongThanhLongVan.Click += new global::System.EventHandler(this.muTangCapTruongThanhLongVan_Click);
		this.muCheThanKhi.Name = "muCheThanKhi";
		this.muCheThanKhi.Size = new global::System.Drawing.Size(251, 22);
		this.muCheThanKhi.Text = "Chế Thần Khí";
		this.muCheThanKhi.Click += new global::System.EventHandler(this.muCheThanKhi_Click);
		this.toolStripMenuItem_47.Name = "điNémKẹoToolStripMenuItem";
		this.toolStripMenuItem_47.Size = new global::System.Drawing.Size(251, 22);
		this.toolStripMenuItem_47.Text = "Đi Ném Kẹo";
		this.toolStripMenuItem_47.Visible = false;
		this.toolStripMenuItem_47.Click += new global::System.EventHandler(this.toolStripMenuItem_47_Click);
		this.toolStripMenuItem_182.Name = "cườngHóa2MónLên7ToolStripMenuItem1";
		this.toolStripMenuItem_182.Size = new global::System.Drawing.Size(251, 22);
		this.toolStripMenuItem_182.Text = "Cường Hóa 2 Món Lên 7";
		this.toolStripMenuItem_182.Click += new global::System.EventHandler(this.toolStripMenuItem_182_Click);
		this.toolStripMenuItem_183.Name = "cườngHóa7MónLên7ToolStripMenuItem";
		this.toolStripMenuItem_183.Size = new global::System.Drawing.Size(251, 22);
		this.toolStripMenuItem_183.Text = "Cường Hóa 7 Món Lên 7";
		this.toolStripMenuItem_183.Click += new global::System.EventHandler(this.toolStripMenuItem_183_Click);
		this.muMua100KimSangDuoc.Name = "muMua100KimSangDuoc";
		this.muMua100KimSangDuoc.Size = new global::System.Drawing.Size(251, 22);
		this.muMua100KimSangDuoc.Text = "Đi Mua 100 Kim Sang Dược";
		this.muMua100KimSangDuoc.Click += new global::System.EventHandler(this.muMua100KimSangDuoc_Click);
		this.toolStripMenuItem_46.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muSuaVoHon,
			this.muSuaThanKhi,
			this.muSuaTrangBi
		});
		this.toolStripMenuItem_46.Name = "sửaToolStripMenuItem";
		this.toolStripMenuItem_46.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_46.Text = "Đi Sửa";
		this.muSuaVoHon.Name = "muSuaVoHon";
		this.muSuaVoHon.Size = new global::System.Drawing.Size(120, 22);
		this.muSuaVoHon.Text = "Võ Hồn";
		this.muSuaVoHon.Click += new global::System.EventHandler(this.muSuaVoHon_Click);
		this.muSuaThanKhi.Name = "muSuaThanKhi";
		this.muSuaThanKhi.Size = new global::System.Drawing.Size(120, 22);
		this.muSuaThanKhi.Text = "Thần Khí";
		this.muSuaThanKhi.Click += new global::System.EventHandler(this.muSuaThanKhi_Click);
		this.muSuaTrangBi.Name = "muSuaTrangBi";
		this.muSuaTrangBi.Size = new global::System.Drawing.Size(120, 22);
		this.muSuaTrangBi.Text = "Trang Bị";
		this.muSuaTrangBi.Click += new global::System.EventHandler(this.muSuaTrangBi_Click);
		this.toolStripMenuItem_44.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muDoiHuyenSacCauThienThai,
			this.muDoiKimTamTy,
			this.muDoi999HoaHong,
			this.muDoiLoanPhiMatHam,
			this.muDoiChanNguyenLinhPhach,
			this.muDoiTiemNangTan,
			this.muDaiLeHungVuong
		});
		this.toolStripMenuItem_44.Name = "đổiToolStripMenuItem";
		this.toolStripMenuItem_44.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_44.Text = "Đi Đổi";
		this.muDoiHuyenSacCauThienThai.Name = "muDoiHuyenSacCauThienThai";
		this.muDoiHuyenSacCauThienThai.Size = new global::System.Drawing.Size(232, 22);
		this.muDoiHuyenSacCauThienThai.Text = "Đổi Huyễn Sắc Câu Thiên Thái";
		this.muDoiHuyenSacCauThienThai.Click += new global::System.EventHandler(this.muDoiHuyenSacCauThienThai_Click);
		this.muDoiKimTamTy.Name = "muDoiKimTamTy";
		this.muDoiKimTamTy.Size = new global::System.Drawing.Size(232, 22);
		this.muDoiKimTamTy.Text = "Đổi Kim Tằm Ty";
		this.muDoiKimTamTy.Visible = false;
		this.muDoiKimTamTy.Click += new global::System.EventHandler(this.muDoiKimTamTy_Click);
		this.muDoi999HoaHong.Name = "muDoi999HoaHong";
		this.muDoi999HoaHong.Size = new global::System.Drawing.Size(232, 22);
		this.muDoi999HoaHong.Text = "Đổi 999 Hoa Hồng";
		this.muDoi999HoaHong.Visible = false;
		this.muDoi999HoaHong.Click += new global::System.EventHandler(this.muDoi999HoaHong_Click);
		this.muDoiLoanPhiMatHam.Name = "muDoiLoanPhiMatHam";
		this.muDoiLoanPhiMatHam.Size = new global::System.Drawing.Size(232, 22);
		this.muDoiLoanPhiMatHam.Text = "Đổi Loạn Phỉ Mật Hàm";
		this.muDoiLoanPhiMatHam.Click += new global::System.EventHandler(this.muDoiLoanPhiMatHam_Click);
		this.muDoiChanNguyenLinhPhach.Name = "muDoiChanNguyenLinhPhach";
		this.muDoiChanNguyenLinhPhach.Size = new global::System.Drawing.Size(232, 22);
		this.muDoiChanNguyenLinhPhach.Text = "Đổi Chân Nguyên Linh Phách";
		this.muDoiChanNguyenLinhPhach.Click += new global::System.EventHandler(this.muDoiChanNguyenLinhPhach_Click);
		this.muDoiTiemNangTan.Name = "muDoiTiemNangTan";
		this.muDoiTiemNangTan.Size = new global::System.Drawing.Size(232, 22);
		this.muDoiTiemNangTan.Text = "Đổi Tiềm Năng Tán";
		this.muDoiTiemNangTan.Visible = false;
		this.muDoiTiemNangTan.Click += new global::System.EventHandler(this.muDoiTiemNangTan_Click);
		this.muDaiLeHungVuong.Name = "muDaiLeHungVuong";
		this.muDaiLeHungVuong.Size = new global::System.Drawing.Size(232, 22);
		this.muDaiLeHungVuong.Text = "Đại Lễ Hùng Vương";
		this.muDaiLeHungVuong.Click += new global::System.EventHandler(this.muDaiLeHungVuong_Click);
		this.toolStripMenuItem_45.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muNhanChienCongKiemChi,
			this.muNhanThuongQuanSonHai,
			this.muNhanThuongTyVo,
			this.muNhanBuaBaoRuong,
			this.muNhanLeBao,
			this.muNhanBong,
			this.muNhanKeoHallowen,
			this.muLinhLuong
		});
		this.toolStripMenuItem_45.Name = "điToolStripMenuItem";
		this.toolStripMenuItem_45.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_45.Text = "Đi Nhận";
		this.muNhanChienCongKiemChi.Name = "muNhanChienCongKiemChi";
		this.muNhanChienCongKiemChi.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanChienCongKiemChi.Text = "Nhận Chiến Công + Kiếm Chỉ";
		this.muNhanChienCongKiemChi.Click += new global::System.EventHandler(this.muNhanChienCongKiemChi_Click);
		this.muNhanThuongQuanSonHai.Name = "muNhanThuongQuanSonHai";
		this.muNhanThuongQuanSonHai.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanThuongQuanSonHai.Text = "Nhận Thưởng Quan Sơn Hải";
		this.muNhanThuongQuanSonHai.Click += new global::System.EventHandler(this.muNhanThuongQuanSonHai_Click);
		this.muNhanThuongTyVo.Name = "muNhanThuongTyVo";
		this.muNhanThuongTyVo.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanThuongTyVo.Text = "Nhận Thưởng Tỷ Võ";
		this.muNhanThuongTyVo.Click += new global::System.EventHandler(this.muNhanThuongTyVo_Click);
		this.muNhanBuaBaoRuong.Name = "muNhanBuaBaoRuong";
		this.muNhanBuaBaoRuong.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanBuaBaoRuong.Text = "Nhận Bùa Bảo Rương";
		this.muNhanBuaBaoRuong.Click += new global::System.EventHandler(this.muNhanBuaBaoRuong_Click);
		this.muNhanLeBao.Name = "muNhanLeBao";
		this.muNhanLeBao.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanLeBao.Text = "Nhận Lễ Bao";
		this.muNhanLeBao.Click += new global::System.EventHandler(this.muNhanLeBao_Click);
		this.muNhanBong.Name = "muNhanBong";
		this.muNhanBong.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanBong.Text = "Nhận Bóng";
		this.muNhanBong.Visible = false;
		this.muNhanBong.Click += new global::System.EventHandler(this.muNhanBong_Click);
		this.muNhanKeoHallowen.Name = "muNhanKeoHallowen";
		this.muNhanKeoHallowen.Size = new global::System.Drawing.Size(231, 22);
		this.muNhanKeoHallowen.Text = "Nhận Kẹo Hallowen";
		this.muNhanKeoHallowen.Visible = false;
		this.muNhanKeoHallowen.Click += new global::System.EventHandler(this.muNhanKeoHallowen_Click);
		this.muLinhLuong.Name = "muLinhLuong";
		this.muLinhLuong.Size = new global::System.Drawing.Size(231, 22);
		this.muLinhLuong.Text = "Lĩnh Lương";
		this.muLinhLuong.Click += new global::System.EventHandler(this.muLinhLuong_Click);
		this.muBHD.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muTrongHoa,
			this.muBonHoa,
			this.muThuHoach,
			this.toolStripSeparator4,
			this.muTuoiHoaHong,
			this.muNhanQuaBuiHoa,
			this.muNhanHoaHongLo
		});
		this.muBHD.Name = "muBHD";
		this.muBHD.Size = new global::System.Drawing.Size(231, 22);
		this.muBHD.Text = "Bách Hoa Duyên";
		this.muBHD.Visible = false;
		this.muTrongHoa.Name = "muTrongHoa";
		this.muTrongHoa.Size = new global::System.Drawing.Size(206, 22);
		this.muTrongHoa.Text = "Trồng Hoa";
		this.muTrongHoa.Click += new global::System.EventHandler(this.muTrongHoa_Click);
		this.muBonHoa.Name = "muBonHoa";
		this.muBonHoa.Size = new global::System.Drawing.Size(206, 22);
		this.muBonHoa.Text = "Bón Hoa";
		this.muBonHoa.Click += new global::System.EventHandler(this.muBonHoa_Click);
		this.muThuHoach.Name = "muThuHoach";
		this.muThuHoach.Size = new global::System.Drawing.Size(206, 22);
		this.muThuHoach.Text = "Thu Hoạch";
		this.muThuHoach.Click += new global::System.EventHandler(this.muThuHoach_Click);
		this.toolStripSeparator4.Name = "toolStripSeparator4";
		this.toolStripSeparator4.Size = new global::System.Drawing.Size(203, 6);
		this.muTuoiHoaHong.Name = "muTuoiHoaHong";
		this.muTuoiHoaHong.Size = new global::System.Drawing.Size(206, 22);
		this.muTuoiHoaHong.Text = "Tưới Hoa Hồng";
		this.muTuoiHoaHong.Click += new global::System.EventHandler(this.muTuoiHoaHong_Click);
		this.muNhanQuaBuiHoa.Name = "muNhanQuaBuiHoa";
		this.muNhanQuaBuiHoa.Size = new global::System.Drawing.Size(206, 22);
		this.muNhanQuaBuiHoa.Text = "Nhận Quà Bụi Hoa Hồng";
		this.muNhanQuaBuiHoa.Click += new global::System.EventHandler(this.muNhanQuaBuiHoa_Click);
		this.muNhanHoaHongLo.Name = "muNhanHoaHongLo";
		this.muNhanHoaHongLo.Size = new global::System.Drawing.Size(206, 22);
		this.muNhanHoaHongLo.Text = "Nhận Hoa Hồng Lộ";
		this.muNhanHoaHongLo.Click += new global::System.EventHandler(this.muNhanHoaHongLo_Click);
		this.toolStripSeparator44.Name = "toolStripSeparator44";
		this.toolStripSeparator44.Size = new global::System.Drawing.Size(228, 6);
		this.toolStripMenuItem_36.Name = "treoĐồThươngHộiToolStripMenuItem";
		this.toolStripMenuItem_36.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_36.Text = "Treo Đồ Thương Hội";
		this.toolStripMenuItem_36.Click += new global::System.EventHandler(this.toolStripMenuItem_36_Click);
		this.toolStripMenuItem_43.Name = "treoShopTạpHóaToolStripMenuItem";
		this.toolStripMenuItem_43.Size = new global::System.Drawing.Size(231, 22);
		this.toolStripMenuItem_43.Text = "Treo Shop Tạp Hóa";
		this.toolStripMenuItem_43.Click += new global::System.EventHandler(this.toolStripMenuItem_43_Click);
		this.leaderToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muAcTac,
			this.muAcBa,
			this.muTangKinhCac,
			this.toolStripSeparator40,
			this.muTucCau,
			this.muLauLanTamBao,
			this.muKyCuoc,
			this.toolStripSeparator39,
			this.muDaTru,
			this.muMongHeo,
			this.muThienGiangKyThu,
			this.muPhungHoangLangMo,
			this.toolStripSeparator30,
			this.muPrivate,
			this.bossMapToolStripMenuItem,
			this.muBaoDoHiem,
			this.muDoanBaoMaTac,
			this.toolStripMenuItem_13,
			this.toolStripMenuItem18,
			this.mnuKetNghia,
			this.mnuKeBaiSudo,
			this.toolStripSeparator23,
			this.muTyVo,
			this.muQuanSonHai
		});
		this.leaderToolStripMenuItem.Name = "leaderToolStripMenuItem";
		this.leaderToolStripMenuItem.Size = new global::System.Drawing.Size(55, 20);
		this.leaderToolStripMenuItem.Text = "InTime";
		this.leaderToolStripMenuItem.DropDownOpening += new global::System.EventHandler(this.leaderToolStripMenuItem_DropDownOpening);
		this.leaderToolStripMenuItem.EnabledChanged += new global::System.EventHandler(this.leaderToolStripMenuItem_EnabledChanged);
		this.muAcTac.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_22,
			this.toolStripSeparator21,
			this.muVoLuongSon,
			this.muKinhHo,
			this.muKiemCac,
			this.muThaiHo,
			this.muTungSon,
			this.muDonHoang
		});
		this.muAcTac.Name = "muAcTac";
		this.muAcTac.Size = new global::System.Drawing.Size(198, 22);
		this.muAcTac.Text = "Ác Tặc";
		this.toolStripMenuItem_22.Name = "tựĐộngToolStripMenuItem";
		this.toolStripMenuItem_22.Size = new global::System.Drawing.Size(147, 22);
		this.toolStripMenuItem_22.Text = "Tự Động";
		this.toolStripMenuItem_22.Click += new global::System.EventHandler(this.toolStripMenuItem_22_Click);
		this.toolStripSeparator21.Name = "toolStripSeparator21";
		this.toolStripSeparator21.Size = new global::System.Drawing.Size(144, 6);
		this.muVoLuongSon.Name = "muVoLuongSon";
		this.muVoLuongSon.Size = new global::System.Drawing.Size(147, 22);
		this.muVoLuongSon.Text = "Vô Lượng Sơn";
		this.muVoLuongSon.Click += new global::System.EventHandler(this.muVoLuongSon_Click);
		this.muKinhHo.Name = "muKinhHo";
		this.muKinhHo.Size = new global::System.Drawing.Size(147, 22);
		this.muKinhHo.Text = "Kính Hồ";
		this.muKinhHo.Click += new global::System.EventHandler(this.muKinhHo_Click);
		this.muKiemCac.Name = "muKiemCac";
		this.muKiemCac.Size = new global::System.Drawing.Size(147, 22);
		this.muKiemCac.Text = "Kiếm Các";
		this.muKiemCac.Click += new global::System.EventHandler(this.muKiemCac_Click);
		this.muThaiHo.Name = "muThaiHo";
		this.muThaiHo.Size = new global::System.Drawing.Size(147, 22);
		this.muThaiHo.Text = "Thái Hồ";
		this.muThaiHo.Click += new global::System.EventHandler(this.muThaiHo_Click);
		this.muTungSon.Name = "muTungSon";
		this.muTungSon.Size = new global::System.Drawing.Size(147, 22);
		this.muTungSon.Text = "Tung Sơn";
		this.muTungSon.Click += new global::System.EventHandler(this.muTungSon_Click);
		this.muDonHoang.Name = "muDonHoang";
		this.muDonHoang.Size = new global::System.Drawing.Size(147, 22);
		this.muDonHoang.Text = "Đôn Hoàng";
		this.muDonHoang.Click += new global::System.EventHandler(this.muDonHoang_Click);
		this.muAcBa.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_131,
			this.toolStripSeparator24,
			this.toolStripMenuItem_136,
			this.toolStripMenuItem_137,
			this.toolStripMenuItem_134,
			this.toolStripMenuItem_140,
			this.toolStripMenuItem_133,
			this.toolStripMenuItem_132,
			this.toolStripMenuItem_141,
			this.toolStripMenuItem_142,
			this.toolStripMenuItem_143,
			this.ngamyToolStripMenuItem,
			this.toolStripMenuItem_135,
			this.toolStripMenuItem_138,
			this.toolStripMenuItem_139
		});
		this.muAcBa.Name = "muAcBa";
		this.muAcBa.Size = new global::System.Drawing.Size(198, 22);
		this.muAcBa.Text = "Ác Bá";
		this.muAcBa.Click += new global::System.EventHandler(this.muAcBa_Click);
		this.toolStripMenuItem_131.Name = "tựĐộngToolStripMenuItem2";
		this.toolStripMenuItem_131.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_131.Text = "Tự Động";
		this.toolStripMenuItem_131.Click += new global::System.EventHandler(this.toolStripMenuItem_131_Click);
		this.toolStripSeparator24.Name = "toolStripSeparator24";
		this.toolStripSeparator24.Size = new global::System.Drawing.Size(135, 6);
		this.toolStripMenuItem_136.Name = "đàoHoaToolStripMenuItem";
		this.toolStripMenuItem_136.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_136.Text = "Đào Hoa";
		this.toolStripMenuItem_136.Click += new global::System.EventHandler(this.toolStripMenuItem_136_Click);
		this.toolStripMenuItem_137.Name = "quỷCốcToolStripMenuItem";
		this.toolStripMenuItem_137.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_137.Text = "Quỷ Cốc";
		this.toolStripMenuItem_137.Click += new global::System.EventHandler(this.toolStripMenuItem_137_Click);
		this.toolStripMenuItem_134.Name = "đườngMônToolStripMenuItem";
		this.toolStripMenuItem_134.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_134.Text = "Đường Môn";
		this.toolStripMenuItem_134.Click += new global::System.EventHandler(this.toolStripMenuItem_134_Click);
		this.toolStripMenuItem_140.Name = "mộDungToolStripMenuItem";
		this.toolStripMenuItem_140.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_140.Text = "Mộ Dung";
		this.toolStripMenuItem_140.Click += new global::System.EventHandler(this.toolStripMenuItem_140_Click);
		this.toolStripMenuItem_133.Name = "tinhTúcToolStripMenuItem";
		this.toolStripMenuItem_133.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_133.Text = "Tinh Túc";
		this.toolStripMenuItem_133.Click += new global::System.EventHandler(this.toolStripMenuItem_133_Click);
		this.toolStripMenuItem_132.Name = "tiêuDaoToolStripMenuItem";
		this.toolStripMenuItem_132.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_132.Text = "Tiêu Dao";
		this.toolStripMenuItem_132.Click += new global::System.EventHandler(this.toolStripMenuItem_132_Click);
		this.toolStripMenuItem_141.Name = "thiếuLâmToolStripMenuItem";
		this.toolStripMenuItem_141.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_141.Text = "Thiếu Lâm";
		this.toolStripMenuItem_141.Click += new global::System.EventHandler(this.toolStripMenuItem_141_Click);
		this.toolStripMenuItem_142.Name = "thiênSơnToolStripMenuItem";
		this.toolStripMenuItem_142.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_142.Text = "Thiên Sơn";
		this.toolStripMenuItem_142.Click += new global::System.EventHandler(this.toolStripMenuItem_142_Click);
		this.toolStripMenuItem_143.Name = "thiênLongToolStripMenuItem";
		this.toolStripMenuItem_143.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_143.Text = "Thiên Long";
		this.toolStripMenuItem_143.Click += new global::System.EventHandler(this.toolStripMenuItem_143_Click);
		this.ngamyToolStripMenuItem.Name = "ngamyToolStripMenuItem";
		this.ngamyToolStripMenuItem.Size = new global::System.Drawing.Size(138, 22);
		this.ngamyToolStripMenuItem.Text = "Ngamy";
		this.ngamyToolStripMenuItem.Click += new global::System.EventHandler(this.ngamyToolStripMenuItem_Click);
		this.toolStripMenuItem_135.Name = "võĐangToolStripMenuItem";
		this.toolStripMenuItem_135.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_135.Text = "Võ Đang";
		this.toolStripMenuItem_135.Click += new global::System.EventHandler(this.toolStripMenuItem_135_Click);
		this.toolStripMenuItem_138.Name = "minhGiáoToolStripMenuItem";
		this.toolStripMenuItem_138.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_138.Text = "Minh Giáo";
		this.toolStripMenuItem_138.Click += new global::System.EventHandler(this.toolStripMenuItem_138_Click);
		this.toolStripMenuItem_139.Name = "cáiBangToolStripMenuItem";
		this.toolStripMenuItem_139.Size = new global::System.Drawing.Size(138, 22);
		this.toolStripMenuItem_139.Text = "Cái Bang";
		this.toolStripMenuItem_139.Click += new global::System.EventHandler(this.toolStripMenuItem_139_Click);
		this.muTangKinhCac.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_23,
			this.toolStripSeparator22,
			this.muTayHo,
			this.muNhiHai,
			this.muNhanNam
		});
		this.muTangKinhCac.Name = "muTangKinhCac";
		this.muTangKinhCac.Size = new global::System.Drawing.Size(198, 22);
		this.muTangKinhCac.Text = "Tàng Kinh Các";
		this.toolStripMenuItem_23.Name = "tựĐộngToolStripMenuItem1";
		this.toolStripMenuItem_23.Size = new global::System.Drawing.Size(132, 22);
		this.toolStripMenuItem_23.Text = "Tự Động";
		this.toolStripMenuItem_23.Click += new global::System.EventHandler(this.toolStripMenuItem_23_Click);
		this.toolStripSeparator22.Name = "toolStripSeparator22";
		this.toolStripSeparator22.Size = new global::System.Drawing.Size(129, 6);
		this.muTayHo.Name = "muTayHo";
		this.muTayHo.Size = new global::System.Drawing.Size(132, 22);
		this.muTayHo.Text = "Tây Hồ";
		this.muTayHo.Click += new global::System.EventHandler(this.muTayHo_Click);
		this.muNhiHai.Name = "muNhiHai";
		this.muNhiHai.Size = new global::System.Drawing.Size(132, 22);
		this.muNhiHai.Text = "Nhĩ Hải";
		this.muNhiHai.Click += new global::System.EventHandler(this.muNhiHai_Click);
		this.muNhanNam.Name = "muNhanNam";
		this.muNhanNam.Size = new global::System.Drawing.Size(132, 22);
		this.muNhanNam.Text = "Nhạn Nam";
		this.muNhanNam.Click += new global::System.EventHandler(this.muNhanNam_Click);
		this.toolStripSeparator40.Name = "toolStripSeparator40";
		this.toolStripSeparator40.Size = new global::System.Drawing.Size(195, 6);
		this.muTucCau.Name = "muTucCau";
		this.muTucCau.Size = new global::System.Drawing.Size(198, 22);
		this.muTucCau.Text = "Túc Cầu";
		this.muTucCau.Click += new global::System.EventHandler(this.muTucCau_Click);
		this.muLauLanTamBao.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muLauLanTamBaoNhanh,
			this.muLauLanTamBaoCham
		});
		this.muLauLanTamBao.Name = "muLauLanTamBao";
		this.muLauLanTamBao.Size = new global::System.Drawing.Size(198, 22);
		this.muLauLanTamBao.Text = "Lâu Lan Tầm Bảo";
		this.muLauLanTamBaoNhanh.Name = "muLauLanTamBaoNhanh";
		this.muLauLanTamBaoNhanh.Size = new global::System.Drawing.Size(110, 22);
		this.muLauLanTamBaoNhanh.Text = "Nhanh";
		this.muLauLanTamBaoNhanh.Click += new global::System.EventHandler(this.muLauLanTamBaoNhanh_Click);
		this.muLauLanTamBaoCham.Name = "muLauLanTamBaoCham";
		this.muLauLanTamBaoCham.Size = new global::System.Drawing.Size(110, 22);
		this.muLauLanTamBaoCham.Text = "Chậm";
		this.muLauLanTamBaoCham.Click += new global::System.EventHandler(this.muLauLanTamBaoCham_Click);
		this.muKyCuoc.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muKyCuocNhanh,
			this.muKyCuocCham
		});
		this.muKyCuoc.Name = "muKyCuoc";
		this.muKyCuoc.Size = new global::System.Drawing.Size(198, 22);
		this.muKyCuoc.Text = "Kỳ Cuộc";
		this.muKyCuocNhanh.Name = "muKyCuocNhanh";
		this.muKyCuocNhanh.Size = new global::System.Drawing.Size(110, 22);
		this.muKyCuocNhanh.Text = "Nhanh";
		this.muKyCuocNhanh.Click += new global::System.EventHandler(this.muKyCuocNhanh_Click);
		this.muKyCuocCham.Name = "muKyCuocCham";
		this.muKyCuocCham.Size = new global::System.Drawing.Size(110, 22);
		this.muKyCuocCham.Text = "Chậm";
		this.muKyCuocCham.Click += new global::System.EventHandler(this.muKyCuocCham_Click);
		this.toolStripSeparator39.Name = "toolStripSeparator39";
		this.toolStripSeparator39.Size = new global::System.Drawing.Size(195, 6);
		this.muDaTru.Name = "muDaTru";
		this.muDaTru.Size = new global::System.Drawing.Size(198, 22);
		this.muDaTru.Text = "Dã Trư";
		this.muDaTru.Click += new global::System.EventHandler(this.muDaTru_Click);
		this.muMongHeo.Name = "muMongHeo";
		this.muMongHeo.Size = new global::System.Drawing.Size(198, 22);
		this.muMongHeo.Text = "Móng Heo";
		this.muMongHeo.Click += new global::System.EventHandler(this.muMongHeo_Click);
		this.muThienGiangKyThu.Name = "muThienGiangKyThu";
		this.muThienGiangKyThu.Size = new global::System.Drawing.Size(198, 22);
		this.muThienGiangKyThu.Text = "Thiên Giáng Kỳ Thú";
		this.muThienGiangKyThu.Click += new global::System.EventHandler(this.muThienGiangKyThu_Click);
		this.muPhungHoangLangMo.Name = "muPhungHoangLangMo";
		this.muPhungHoangLangMo.Size = new global::System.Drawing.Size(198, 22);
		this.muPhungHoangLangMo.Text = "Phụng Hoàng Lăng Mộ";
		this.muPhungHoangLangMo.Click += new global::System.EventHandler(this.muPhungHoangLangMo_Click);
		this.toolStripSeparator30.Name = "toolStripSeparator30";
		this.toolStripSeparator30.Size = new global::System.Drawing.Size(195, 6);
		this.muPrivate.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muQ1ToChau,
			this.muQ2ToChau,
			this.muQ12ToChau,
			this.muThuyLao,
			this.traderToolStripMenuItem
		});
		this.muPrivate.Name = "muPrivate";
		this.muPrivate.Size = new global::System.Drawing.Size(198, 22);
		this.muPrivate.Text = "Private";
		this.muQ1ToChau.Name = "muQ1ToChau";
		this.muQ1ToChau.Size = new global::System.Drawing.Size(141, 22);
		this.muQ1ToChau.Text = "Q1 Tô Châu";
		this.muQ1ToChau.Click += new global::System.EventHandler(this.muQ1ToChau_Click);
		this.muQ2ToChau.Name = "muQ2ToChau";
		this.muQ2ToChau.Size = new global::System.Drawing.Size(141, 22);
		this.muQ2ToChau.Text = "Q2 Tô Châu";
		this.muQ2ToChau.Click += new global::System.EventHandler(this.muQ2ToChau_Click);
		this.muQ12ToChau.Name = "muQ12ToChau";
		this.muQ12ToChau.Size = new global::System.Drawing.Size(141, 22);
		this.muQ12ToChau.Text = "Q12 Tô Châu";
		this.muQ12ToChau.Click += new global::System.EventHandler(this.muQ12ToChau_Click);
		this.muThuyLao.Name = "muThuyLao";
		this.muThuyLao.Size = new global::System.Drawing.Size(141, 22);
		this.muThuyLao.Text = "Thủy Lao";
		this.muThuyLao.Click += new global::System.EventHandler(this.muThuyLao_Click);
		this.traderToolStripMenuItem.Name = "traderToolStripMenuItem";
		this.traderToolStripMenuItem.Size = new global::System.Drawing.Size(141, 22);
		this.traderToolStripMenuItem.Text = "Trader";
		this.traderToolStripMenuItem.Click += new global::System.EventHandler(this.traderToolStripMenuItem_Click);
		this.bossMapToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_53,
			this.configToolStripMenuItem
		});
		this.bossMapToolStripMenuItem.Name = "bossMapToolStripMenuItem";
		this.bossMapToolStripMenuItem.Size = new global::System.Drawing.Size(198, 22);
		this.bossMapToolStripMenuItem.Text = "Boss Map";
		this.bossMapToolStripMenuItem.DropDownOpening += new global::System.EventHandler(this.bossMapToolStripMenuItem_DropDownOpening);
		this.toolStripMenuItem_53.Name = "tảiThiếtLậpMớiNhấtToolStripMenuItem";
		this.toolStripMenuItem_53.Size = new global::System.Drawing.Size(193, 22);
		this.toolStripMenuItem_53.Text = "Tải Thiết Lập Mới Nhất";
		this.toolStripMenuItem_53.Click += new global::System.EventHandler(this.toolStripMenuItem_53_Click);
		this.configToolStripMenuItem.Name = "configToolStripMenuItem";
		this.configToolStripMenuItem.Size = new global::System.Drawing.Size(193, 22);
		this.configToolStripMenuItem.Text = "Config";
		this.configToolStripMenuItem.Click += new global::System.EventHandler(this.configToolStripMenuItem_Click);
		this.muBaoDoHiem.Name = "muBaoDoHiem";
		this.muBaoDoHiem.Size = new global::System.Drawing.Size(198, 22);
		this.muBaoDoHiem.Text = "Mở Bảo Đồ Hiếm";
		this.muBaoDoHiem.Click += new global::System.EventHandler(this.muBaoDoHiem_Click);
		this.muDoanBaoMaTac.Name = "muDoanBaoMaTac";
		this.muDoanBaoMaTac.Size = new global::System.Drawing.Size(198, 22);
		this.muDoanBaoMaTac.Text = "Đoạn Bảo Mã Tặc";
		this.muDoanBaoMaTac.Click += new global::System.EventHandler(this.muDoanBaoMaTac_Click);
		this.toolStripMenuItem_13.Name = "kếtNghĩaToolStripMenuItem";
		this.toolStripMenuItem_13.Size = new global::System.Drawing.Size(198, 22);
		this.toolStripMenuItem_13.Text = "Kết Nghĩa";
		this.toolStripMenuItem_13.Visible = false;
		this.toolStripMenuItem_13.Click += new global::System.EventHandler(this.toolStripMenuItem_13_Click);
		this.toolStripMenuItem18.Name = "toolStripMenuItem18";
		this.toolStripMenuItem18.Size = new global::System.Drawing.Size(195, 6);
		this.toolStripMenuItem18.Visible = false;
		this.mnuKetNghia.Name = "mnuKetNghia";
		this.mnuKetNghia.Size = new global::System.Drawing.Size(198, 22);
		this.mnuKetNghia.Text = "Auto Kết Nghĩa";
		this.mnuKetNghia.Visible = false;
		this.mnuKetNghia.Click += new global::System.EventHandler(this.mnuKetNghia_Click);
		this.mnuKeBaiSudo.Name = "mnuKeBaiSudo";
		this.mnuKeBaiSudo.Size = new global::System.Drawing.Size(198, 22);
		this.mnuKeBaiSudo.Text = "Auto Sư Đồ";
		this.mnuKeBaiSudo.Visible = false;
		this.mnuKeBaiSudo.Click += new global::System.EventHandler(this.mnuKeBaiSudo_Click);
		this.toolStripSeparator23.Name = "toolStripSeparator23";
		this.toolStripSeparator23.Size = new global::System.Drawing.Size(195, 6);
		this.muTyVo.Name = "muTyVo";
		this.muTyVo.Size = new global::System.Drawing.Size(198, 22);
		this.muTyVo.Text = "Tỷ Võ";
		this.muTyVo.Click += new global::System.EventHandler(this.muTyVo_Click);
		this.muQuanSonHai.Name = "muQuanSonHai";
		this.muQuanSonHai.Size = new global::System.Drawing.Size(198, 22);
		this.muQuanSonHai.Text = "Quan Sơn Hải";
		this.muQuanSonHai.Click += new global::System.EventHandler(this.muQuanSonHai_Click);
		this.dailyToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muHangNgay,
			this.muLuyenKim,
			this.muTuBaoBon,
			this.muSuMon,
			this.toolStripSeparator36,
			this.muMoBaoTangDo,
			this.muTrungAc,
			this.toolStripSeparator32,
			this.muCotTruyen,
			this.muConCai,
			this.toolStripSeparator35,
			this.muThienKiepLau,
			this.muSinhTieu,
			this.toolStripSeparator37,
			this.muTiemNangTan,
			this.muBachHoaDuyen,
			this.muThanhSangNhatHa,
			this.muThanKhi9Sao,
			this.muDungDoatBaoRuong,
			this.muVanTieu,
			this.muTrangSucCuuLe,
			this.muTamKy
		});
		this.dailyToolStripMenuItem.Name = "dailyToolStripMenuItem";
		this.dailyToolStripMenuItem.Size = new global::System.Drawing.Size(45, 20);
		this.dailyToolStripMenuItem.Text = "Daily";
		this.dailyToolStripMenuItem.DropDownOpening += new global::System.EventHandler(this.dailyToolStripMenuItem_DropDownOpening);
		this.muHangNgay.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muToanBoHangNgay,
			this.muLoLyHoa,
			this.muNhanPhiThuy,
			this.muVanMay,
			this.muTueHong,
			this.muNguyenVong
		});
		this.muHangNgay.Name = "muHangNgay";
		this.muHangNgay.Size = new global::System.Drawing.Size(215, 22);
		this.muHangNgay.Text = "Hàng Ngày";
		this.muToanBoHangNgay.Name = "muToanBoHangNgay";
		this.muToanBoHangNgay.Size = new global::System.Drawing.Size(205, 22);
		this.muToanBoHangNgay.Text = "Toàn Bộ";
		this.muToanBoHangNgay.Click += new global::System.EventHandler(this.muToanBoHangNgay_Click);
		this.muLoLyHoa.Name = "muLoLyHoa";
		this.muLoLyHoa.Size = new global::System.Drawing.Size(205, 22);
		this.muLoLyHoa.Text = "Lò Ly Hỏa";
		this.muLoLyHoa.Click += new global::System.EventHandler(this.muLoLyHoa_Click);
		this.muNhanPhiThuy.Name = "muNhanPhiThuy";
		this.muNhanPhiThuy.Size = new global::System.Drawing.Size(205, 22);
		this.muNhanPhiThuy.Text = "Nhận Phỉ Thúy";
		this.muNhanPhiThuy.Click += new global::System.EventHandler(this.muNhanPhiThuy_Click);
		this.muVanMay.Name = "muVanMay";
		this.muVanMay.Size = new global::System.Drawing.Size(205, 22);
		this.muVanMay.Text = "Thử Tài Vận May";
		this.muVanMay.Click += new global::System.EventHandler(this.muVanMay_Click);
		this.muTueHong.Name = "muTueHong";
		this.muTueHong.Size = new global::System.Drawing.Size(205, 22);
		this.muTueHong.Text = "Thiên Long Tuế Hồng";
		this.muTueHong.Visible = false;
		this.muTueHong.Click += new global::System.EventHandler(this.muTueHong_Click);
		this.muNguyenVong.Name = "muNguyenVong";
		this.muNguyenVong.Size = new global::System.Drawing.Size(205, 22);
		this.muNguyenVong.Text = "Nguyện Vọng Thiên Linh";
		this.muNguyenVong.Click += new global::System.EventHandler(this.muNguyenVong_Click);
		this.muLuyenKim.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muLuyenKimNhanh,
			this.muLuyenKimCham
		});
		this.muLuyenKim.Name = "muLuyenKim";
		this.muLuyenKim.Size = new global::System.Drawing.Size(215, 22);
		this.muLuyenKim.Text = "Luyện Kim";
		this.muLuyenKim.Click += new global::System.EventHandler(this.muLuyenKim_Click);
		this.muLuyenKimNhanh.Name = "muLuyenKimNhanh";
		this.muLuyenKimNhanh.Size = new global::System.Drawing.Size(156, 22);
		this.muLuyenKimNhanh.Text = "Nhanh";
		this.muLuyenKimNhanh.Click += new global::System.EventHandler(this.muLuyenKimNhanh_Click);
		this.muLuyenKimCham.Name = "muLuyenKimCham";
		this.muLuyenKimCham.Size = new global::System.Drawing.Size(156, 22);
		this.muLuyenKimCham.Text = "Chậm [Ctrl + L]";
		this.muLuyenKimCham.Click += new global::System.EventHandler(this.muLuyenKimCham_Click);
		this.muTuBaoBon.Name = "muTuBaoBon";
		this.muTuBaoBon.Size = new global::System.Drawing.Size(215, 22);
		this.muTuBaoBon.Text = "Tụ Bảo Bồn";
		this.muTuBaoBon.Click += new global::System.EventHandler(this.muTuBaoBon_Click);
		this.muSuMon.Name = "muSuMon";
		this.muSuMon.Size = new global::System.Drawing.Size(215, 22);
		this.muSuMon.Text = "Sư Môn [Ctrl + M]";
		this.muSuMon.Click += new global::System.EventHandler(this.muSuMon_Click);
		this.toolStripSeparator36.Name = "toolStripSeparator36";
		this.toolStripSeparator36.Size = new global::System.Drawing.Size(212, 6);
		this.muMoBaoTangDo.Name = "muMoBaoTangDo";
		this.muMoBaoTangDo.Size = new global::System.Drawing.Size(215, 22);
		this.muMoBaoTangDo.Text = "Mở Bảo Tàng Đồ";
		this.muMoBaoTangDo.Click += new global::System.EventHandler(this.muMoBaoTangDo_Click);
		this.muTrungAc.Name = "muTrungAc";
		this.muTrungAc.Size = new global::System.Drawing.Size(215, 22);
		this.muTrungAc.Text = "Trừng Ác";
		this.muTrungAc.Click += new global::System.EventHandler(this.muTrungAc_Click);
		this.toolStripSeparator32.Name = "toolStripSeparator32";
		this.toolStripSeparator32.Size = new global::System.Drawing.Size(212, 6);
		this.muCotTruyen.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muCotTruyenToanBo,
			this.muNhiemVuExp,
			this.muNhiemVuKNB,
			this.muNgoChanNguyen,
			this.muChinhTuyen,
			this.muVoY,
			this.muVoTuPho
		});
		this.muCotTruyen.Name = "muCotTruyen";
		this.muCotTruyen.Size = new global::System.Drawing.Size(215, 22);
		this.muCotTruyen.Text = "Cốt Truyện";
		this.muCotTruyenToanBo.Name = "muCotTruyenToanBo";
		this.muCotTruyenToanBo.Size = new global::System.Drawing.Size(189, 22);
		this.muCotTruyenToanBo.Text = "Thăng Cấp [Ctrl + Y]";
		this.muCotTruyenToanBo.Click += new global::System.EventHandler(this.muCotTruyenToanBo_Click);
		this.muNhiemVuExp.Name = "muNhiemVuExp";
		this.muNhiemVuExp.Size = new global::System.Drawing.Size(189, 22);
		this.muNhiemVuExp.Text = "Nhiệm Vụ Exp 28->38";
		this.muNhiemVuExp.Click += new global::System.EventHandler(this.muNhiemVuExp_Click);
		this.muNhiemVuKNB.Name = "muNhiemVuKNB";
		this.muNhiemVuKNB.Size = new global::System.Drawing.Size(189, 22);
		this.muNhiemVuKNB.Text = "Nhiệm Vụ KNB Khóa";
		this.muNhiemVuKNB.Click += new global::System.EventHandler(this.muNhiemVuKNB_Click);
		this.muNgoChanNguyen.Name = "muNgoChanNguyen";
		this.muNgoChanNguyen.Size = new global::System.Drawing.Size(189, 22);
		this.muNgoChanNguyen.Text = "Ngộ Chân Nguyên";
		this.muNgoChanNguyen.Click += new global::System.EventHandler(this.muNgoChanNguyen_Click);
		this.muChinhTuyen.Name = "muChinhTuyen";
		this.muChinhTuyen.Size = new global::System.Drawing.Size(189, 22);
		this.muChinhTuyen.Text = "Chính Tuyến";
		this.muChinhTuyen.Click += new global::System.EventHandler(this.muChinhTuyen_Click);
		this.muVoY.Name = "muVoY";
		this.muVoY.Size = new global::System.Drawing.Size(189, 22);
		this.muVoY.Text = "Võ Ý";
		this.muVoY.Click += new global::System.EventHandler(this.muVoY_Click);
		this.muVoTuPho.Name = "muVoTuPho";
		this.muVoTuPho.Size = new global::System.Drawing.Size(189, 22);
		this.muVoTuPho.Text = "Vô Tự Phổ";
		this.muVoTuPho.Click += new global::System.EventHandler(this.muVoTuPho_Click);
		this.muConCai.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muTuDuong,
			this.muPhuMau,
			this.muNhanCon,
			this.toolStripMenuItem_20
		});
		this.muConCai.Name = "muConCai";
		this.muConCai.Size = new global::System.Drawing.Size(215, 22);
		this.muConCai.Text = "Con Cái";
		this.muTuDuong.Name = "muTuDuong";
		this.muTuDuong.Size = new global::System.Drawing.Size(162, 22);
		this.muTuDuong.Text = "Tu Dưỡng";
		this.muTuDuong.Click += new global::System.EventHandler(this.muTuDuong_Click);
		this.muPhuMau.Name = "muPhuMau";
		this.muPhuMau.Size = new global::System.Drawing.Size(162, 22);
		this.muPhuMau.Text = "Phụ Mẫu";
		this.muPhuMau.Click += new global::System.EventHandler(this.muPhuMau_Click);
		this.muNhanCon.Name = "muNhanCon";
		this.muNhanCon.Size = new global::System.Drawing.Size(162, 22);
		this.muNhanCon.Text = "Nhận Con";
		this.muNhanCon.Click += new global::System.EventHandler(this.muNhanCon_Click);
		this.toolStripMenuItem_20.Name = "dùngTànQuyểnToolStripMenuItem";
		this.toolStripMenuItem_20.Size = new global::System.Drawing.Size(162, 22);
		this.toolStripMenuItem_20.Text = "Dùng Tàn Quyển";
		this.toolStripMenuItem_20.Click += new global::System.EventHandler(this.toolStripMenuItem_20_Click);
		this.toolStripSeparator35.Name = "toolStripSeparator35";
		this.toolStripSeparator35.Size = new global::System.Drawing.Size(212, 6);
		this.muThienKiepLau.Name = "muThienKiepLau";
		this.muThienKiepLau.Size = new global::System.Drawing.Size(215, 22);
		this.muThienKiepLau.Text = "Thiên Kiếp Lâu";
		this.muThienKiepLau.Click += new global::System.EventHandler(this.muThienKiepLau_Click);
		this.muSinhTieu.Name = "muSinhTieu";
		this.muSinhTieu.Size = new global::System.Drawing.Size(215, 22);
		this.muSinhTieu.Text = "Sinh Tiêu";
		this.muSinhTieu.Click += new global::System.EventHandler(this.muSinhTieu_Click);
		this.toolStripSeparator37.Name = "toolStripSeparator37";
		this.toolStripSeparator37.Size = new global::System.Drawing.Size(212, 6);
		this.muTiemNangTan.Name = "muTiemNangTan";
		this.muTiemNangTan.Size = new global::System.Drawing.Size(215, 22);
		this.muTiemNangTan.Text = "Tiềm Năng Tán";
		this.muTiemNangTan.Visible = false;
		this.muTiemNangTan.Click += new global::System.EventHandler(this.muTiemNangTan_Click);
		this.muBachHoaDuyen.Name = "muBachHoaDuyen";
		this.muBachHoaDuyen.Size = new global::System.Drawing.Size(215, 22);
		this.muBachHoaDuyen.Text = "Bách Hoa Duyên [Ctrl + H]";
		this.muBachHoaDuyen.Visible = false;
		this.muBachHoaDuyen.Click += new global::System.EventHandler(this.muBachHoaDuyen_Click);
		this.muThanhSangNhatHa.Name = "muThanhSangNhatHa";
		this.muThanhSangNhatHa.Size = new global::System.Drawing.Size(215, 22);
		this.muThanhSangNhatHa.Text = "Dưa Hấu";
		this.muThanhSangNhatHa.Visible = false;
		this.muThanhSangNhatHa.Click += new global::System.EventHandler(this.muThanhSangNhatHa_Click);
		this.muThanKhi9Sao.Name = "muThanKhi9Sao";
		this.muThanKhi9Sao.Size = new global::System.Drawing.Size(215, 22);
		this.muThanKhi9Sao.Text = "Thần Khí 9*";
		this.muThanKhi9Sao.Click += new global::System.EventHandler(this.muThanKhi9Sao_Click);
		this.muDungDoatBaoRuong.Name = "muDungDoatBaoRuong";
		this.muDungDoatBaoRuong.Size = new global::System.Drawing.Size(215, 22);
		this.muDungDoatBaoRuong.Text = "Dũng Đoạt Bảo Rương";
		this.muDungDoatBaoRuong.Click += new global::System.EventHandler(this.muDungDoatBaoRuong_Click);
		this.muVanTieu.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.muVanTieu1,
			this.muVanTieu2,
			this.muVanTieu3,
			this.muVanTieu4
		});
		this.muVanTieu.Name = "muVanTieu";
		this.muVanTieu.Size = new global::System.Drawing.Size(215, 22);
		this.muVanTieu.Text = "Vận Tiêu";
		this.muVanTieu.Click += new global::System.EventHandler(this.muVanTieu_Click);
		this.muVanTieu1.Name = "muVanTieu1";
		this.muVanTieu1.Size = new global::System.Drawing.Size(131, 22);
		this.muVanTieu1.Text = "Lộ Tuyến 1";
		this.muVanTieu1.Click += new global::System.EventHandler(this.muVanTieu1_Click);
		this.muVanTieu2.Name = "muVanTieu2";
		this.muVanTieu2.Size = new global::System.Drawing.Size(131, 22);
		this.muVanTieu2.Text = "Lộ Tuyến 2";
		this.muVanTieu2.Click += new global::System.EventHandler(this.muVanTieu2_Click);
		this.muVanTieu3.Name = "muVanTieu3";
		this.muVanTieu3.Size = new global::System.Drawing.Size(131, 22);
		this.muVanTieu3.Text = "Lộ Tuyến 3";
		this.muVanTieu3.Click += new global::System.EventHandler(this.muVanTieu3_Click);
		this.muVanTieu4.Name = "muVanTieu4";
		this.muVanTieu4.Size = new global::System.Drawing.Size(131, 22);
		this.muVanTieu4.Text = "Lộ Tuyến 4";
		this.muVanTieu4.Click += new global::System.EventHandler(this.muVanTieu4_Click);
		this.muTrangSucCuuLe.Name = "muTrangSucCuuLe";
		this.muTrangSucCuuLe.Size = new global::System.Drawing.Size(215, 22);
		this.muTrangSucCuuLe.Text = "Trang Sức Cửu Lê";
		this.muTrangSucCuuLe.Click += new global::System.EventHandler(this.muTrangSucCuuLe_Click);
		this.muTamKy.Name = "muTamKy";
		this.muTamKy.Size = new global::System.Drawing.Size(215, 22);
		this.muTamKy.Text = "Tầm Kỳ";
		this.muTamKy.Click += new global::System.EventHandler(this.muTamKy_Click);
		this.allToolStripMenuItem1.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.selectCtrlAToolStripMenuItem,
			this.refreshToolStripMenuItem1,
			this.toolStripSeparator42,
			this.thuPetToolStripMenuItem,
			this.toolStripMenuItem_188,
			this.toolStripMenuItem_184,
			this.toolStripMenuItem_185,
			this.toolStripMenuItem_186,
			this.toolStripSeparator5,
			this.toolStripMenuItem_9,
			this.toolStripMenuItem_7,
			this.toolStripMenuItem_8,
			this.toolStripMenuItem_150,
			this.toolStripMenuItem_204,
			this.toolStripMenuItem_51,
			this.toolStripMenuItem_144,
			this.toolStripMenuItem_187
		});
		this.allToolStripMenuItem1.Name = "allToolStripMenuItem1";
		this.allToolStripMenuItem1.Size = new global::System.Drawing.Size(33, 20);
		this.allToolStripMenuItem1.Text = "All";
		this.selectCtrlAToolStripMenuItem.Name = "selectCtrlAToolStripMenuItem";
		this.selectCtrlAToolStripMenuItem.Size = new global::System.Drawing.Size(267, 22);
		this.selectCtrlAToolStripMenuItem.Text = "Select [Ctrl + A]";
		this.selectCtrlAToolStripMenuItem.Click += new global::System.EventHandler(this.selectCtrlAToolStripMenuItem_Click);
		this.refreshToolStripMenuItem1.Name = "refreshToolStripMenuItem1";
		this.refreshToolStripMenuItem1.Size = new global::System.Drawing.Size(267, 22);
		this.refreshToolStripMenuItem1.Text = "Refresh [Alt + W]";
		this.refreshToolStripMenuItem1.Click += new global::System.EventHandler(this.refreshToolStripMenuItem1_Click);
		this.toolStripSeparator42.Name = "toolStripSeparator42";
		this.toolStripSeparator42.Size = new global::System.Drawing.Size(264, 6);
		this.thuPetToolStripMenuItem.Name = "thuPetToolStripMenuItem";
		this.thuPetToolStripMenuItem.Size = new global::System.Drawing.Size(267, 22);
		this.thuPetToolStripMenuItem.Text = "Thu Pet";
		this.thuPetToolStripMenuItem.Click += new global::System.EventHandler(this.thuPetToolStripMenuItem_Click);
		this.toolStripMenuItem_188.Name = "xuấtPetToolStripMenuItem";
		this.toolStripMenuItem_188.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_188.Text = "Xuất Pet";
		this.toolStripMenuItem_188.Click += new global::System.EventHandler(this.toolStripMenuItem_188_Click);
		this.toolStripMenuItem_184.Name = "lênNgựaCtrlUToolStripMenuItem";
		this.toolStripMenuItem_184.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_184.Text = "Lên Ngựa [Ctrl + U]";
		this.toolStripMenuItem_184.Click += new global::System.EventHandler(this.toolStripMenuItem_184_Click);
		this.toolStripMenuItem_185.Name = "xuốngNgựaCtrlDToolStripMenuItem";
		this.toolStripMenuItem_185.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_185.Text = "Xuống Ngựa [Ctrl + D]";
		this.toolStripMenuItem_185.Click += new global::System.EventHandler(this.toolStripMenuItem_185_Click);
		this.toolStripMenuItem_186.Name = "sắpXếpTayNảiAltZToolStripMenuItem";
		this.toolStripMenuItem_186.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_186.Text = "Sắp Xếp Tay Nải [Alt + Z]";
		this.toolStripMenuItem_186.Click += new global::System.EventHandler(this.toolStripMenuItem_186_Click);
		this.toolStripSeparator5.Name = "toolStripSeparator5";
		this.toolStripSeparator5.Size = new global::System.Drawing.Size(264, 6);
		this.toolStripMenuItem_9.Name = "đầuThaiToolStripMenuItem";
		this.toolStripMenuItem_9.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_9.Text = "Đầu Thai";
		this.toolStripMenuItem_9.Click += new global::System.EventHandler(this.toolStripMenuItem_9_Click);
		this.toolStripMenuItem_7.Name = "ẩnDanhHiệuToolStripMenuItem1";
		this.toolStripMenuItem_7.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_7.Text = "Ẩn Danh Hiệu";
		this.toolStripMenuItem_7.Click += new global::System.EventHandler(this.toolStripMenuItem_7_Click);
		this.toolStripMenuItem_8.Name = "hủyNhiệmVụThấtBạiToolStripMenuItem1";
		this.toolStripMenuItem_8.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_8.Text = "Hủy Nhiệm Vụ Thất Bại";
		this.toolStripMenuItem_8.Click += new global::System.EventHandler(this.toolStripMenuItem_8_Click);
		this.toolStripMenuItem_150.Name = "lấyChânNguyênKhóaTúiThiênCơToolStripMenuItem";
		this.toolStripMenuItem_150.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_150.Text = "Lấy Chân Nguyên Khóa Túi Thiên Cơ";
		this.toolStripMenuItem_150.Click += new global::System.EventHandler(this.toolStripMenuItem_150_Click);
		this.toolStripMenuItem_204.Name = "bánManhMốiDịchLễQuỷThịToolStripMenuItem1";
		this.toolStripMenuItem_204.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_204.Text = "Bán Manh Mối Dịch Lễ Quỷ Thị";
		this.toolStripMenuItem_204.Click += new global::System.EventHandler(this.toolStripMenuItem_204_Click);
		this.toolStripMenuItem_51.Name = "chọnMáyChủToolStripMenuItem";
		this.toolStripMenuItem_51.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_51.Text = "Chọn Máy Chủ";
		this.toolStripMenuItem_51.Click += new global::System.EventHandler(this.toolStripMenuItem_51_Click);
		this.toolStripMenuItem_144.Name = "chuyểnKênhChatBangToolStripMenuItem";
		this.toolStripMenuItem_144.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_144.Text = "Chuyển Kênh Chat Bang";
		this.toolStripMenuItem_144.Click += new global::System.EventHandler(this.toolStripMenuItem_144_Click);
		this.toolStripMenuItem_187.Name = "điểmDanhCtrlPToolStripMenuItem";
		this.toolStripMenuItem_187.Size = new global::System.Drawing.Size(267, 22);
		this.toolStripMenuItem_187.Text = "Điểm Danh [Ctrl + P]";
		this.toolStripMenuItem_187.Click += new global::System.EventHandler(this.toolStripMenuItem_187_Click);
		this.menuNier.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.openGameToolStripMenuItem1,
			this.toolStripSeparator8,
			this.muTopMost,
			this.toolStripSeparator27,
			this.menuPickItem,
			this.menuItemFillter,
			this.toolStripSeparator28,
			this.muForceFollow,
			this.menuFollowKey,
			this.menuAtkFollowKey,
			this.toolStripSeparator25,
			this.menuPause,
			this.menuPausedSkill,
			this.toolStripSeparator1,
			this.autoPKToolStripMenuItem,
			this.toolStripSeparator2,
			this.muTrimRam,
			this.toolStripMenuItem_16
		});
		this.menuNier.Name = "menuNier";
		this.menuNier.Size = new global::System.Drawing.Size(41, 20);
		this.menuNier.Text = "Nier";
		this.menuNier.DropDownOpening += new global::System.EventHandler(this.menuNier_DropDownOpening);
		this.openGameToolStripMenuItem1.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.gameToolStripMenuItem,
			this.gameToolStripMenuItem1,
			this.gameToolStripMenuItem2,
			this.gameToolStripMenuItem3,
			this.gameToolStripMenuItem4,
			this.gameToolStripMenuItem5,
			this.toolStripMenuItem_11,
			this.selectPathToolStripMenuItem
		});
		this.openGameToolStripMenuItem1.Name = "openGameToolStripMenuItem1";
		this.openGameToolStripMenuItem1.Size = new global::System.Drawing.Size(206, 22);
		this.openGameToolStripMenuItem1.Text = "Open Game [Ctrl + O]";
		this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
		this.gameToolStripMenuItem.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem.Text = "1 Game";
		this.gameToolStripMenuItem.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.gameToolStripMenuItem1.Name = "gameToolStripMenuItem1";
		this.gameToolStripMenuItem1.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem1.Text = "2 Game";
		this.gameToolStripMenuItem1.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.gameToolStripMenuItem2.Name = "gameToolStripMenuItem2";
		this.gameToolStripMenuItem2.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem2.Text = "6 Game";
		this.gameToolStripMenuItem2.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.gameToolStripMenuItem3.Name = "gameToolStripMenuItem3";
		this.gameToolStripMenuItem3.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem3.Text = "12 Game";
		this.gameToolStripMenuItem3.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.gameToolStripMenuItem4.Name = "gameToolStripMenuItem4";
		this.gameToolStripMenuItem4.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem4.Text = "24 Game";
		this.gameToolStripMenuItem4.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.gameToolStripMenuItem5.Name = "gameToolStripMenuItem5";
		this.gameToolStripMenuItem5.Size = new global::System.Drawing.Size(132, 22);
		this.gameToolStripMenuItem5.Text = "48 Game";
		this.gameToolStripMenuItem5.Click += new global::System.EventHandler(this.gameToolStripMenuItem5_Click);
		this.toolStripMenuItem_11.Name = "đủ12ToolStripMenuItem";
		this.toolStripMenuItem_11.Size = new global::System.Drawing.Size(132, 22);
		this.toolStripMenuItem_11.Text = "Đủ 12";
		this.toolStripMenuItem_11.Click += new global::System.EventHandler(this.toolStripMenuItem_11_Click);
		this.selectPathToolStripMenuItem.Name = "selectPathToolStripMenuItem";
		this.selectPathToolStripMenuItem.Size = new global::System.Drawing.Size(132, 22);
		this.selectPathToolStripMenuItem.Text = "Select Path";
		this.selectPathToolStripMenuItem.Click += new global::System.EventHandler(this.selectPathToolStripMenuItem_Click);
		this.toolStripSeparator8.Name = "toolStripSeparator8";
		this.toolStripSeparator8.Size = new global::System.Drawing.Size(203, 6);
		this.muTopMost.Name = "muTopMost";
		this.muTopMost.Size = new global::System.Drawing.Size(206, 22);
		this.muTopMost.Text = "Luôn Ở Trên";
		this.muTopMost.Click += new global::System.EventHandler(this.muTopMost_Click);
		this.toolStripSeparator27.Name = "toolStripSeparator27";
		this.toolStripSeparator27.Size = new global::System.Drawing.Size(203, 6);
		this.menuPickItem.Name = "menuPickItem";
		this.menuPickItem.Size = new global::System.Drawing.Size(206, 22);
		this.menuPickItem.Text = "Nhặt Đồ";
		this.menuPickItem.Click += new global::System.EventHandler(this.menuPickItem_Click);
		this.menuItemFillter.Name = "menuItemFillter";
		this.menuItemFillter.Size = new global::System.Drawing.Size(206, 22);
		this.menuItemFillter.Text = "Lọc Đồ";
		this.menuItemFillter.Click += new global::System.EventHandler(this.menuItemFillter_Click);
		this.toolStripSeparator28.Name = "toolStripSeparator28";
		this.toolStripSeparator28.Size = new global::System.Drawing.Size(203, 6);
		this.muForceFollow.Name = "muForceFollow";
		this.muForceFollow.Size = new global::System.Drawing.Size(206, 22);
		this.muForceFollow.Text = "Buộc Theo Sau Key";
		this.muForceFollow.Click += new global::System.EventHandler(this.muForceFollow_Click);
		this.menuFollowKey.Name = "menuFollowKey";
		this.menuFollowKey.Size = new global::System.Drawing.Size(206, 22);
		this.menuFollowKey.Text = "Theo Sau Key";
		this.menuFollowKey.Click += new global::System.EventHandler(this.menuFollowKey_Click);
		this.menuAtkFollowKey.Name = "menuAtkFollowKey";
		this.menuAtkFollowKey.Size = new global::System.Drawing.Size(206, 22);
		this.menuAtkFollowKey.Text = "Đánh Theo Key [Ctrl + Q]";
		this.menuAtkFollowKey.Click += new global::System.EventHandler(this.menuAtkFollowKey_Click);
		this.toolStripSeparator25.Name = "toolStripSeparator25";
		this.toolStripSeparator25.Size = new global::System.Drawing.Size(203, 6);
		this.menuPause.Name = "menuPause";
		this.menuPause.Size = new global::System.Drawing.Size(206, 22);
		this.menuPause.Text = "Tạm Dừng [Pause]";
		this.menuPause.Click += new global::System.EventHandler(this.menuPause_Click);
		this.menuPausedSkill.Name = "menuPausedSkill";
		this.menuPausedSkill.Size = new global::System.Drawing.Size(206, 22);
		this.menuPausedSkill.Text = "Tắt Skill [Ctrl + K]";
		this.menuPausedSkill.Click += new global::System.EventHandler(this.menuPausedSkill_Click);
		this.toolStripSeparator1.Name = "toolStripSeparator1";
		this.toolStripSeparator1.Size = new global::System.Drawing.Size(203, 6);
		this.autoPKToolStripMenuItem.Name = "autoPKToolStripMenuItem";
		this.autoPKToolStripMenuItem.Size = new global::System.Drawing.Size(206, 22);
		this.autoPKToolStripMenuItem.Text = "Auto PK [Ctrl + i]";
		this.autoPKToolStripMenuItem.Click += new global::System.EventHandler(this.autoPKToolStripMenuItem_Click);
		this.toolStripSeparator2.Name = "toolStripSeparator2";
		this.toolStripSeparator2.Size = new global::System.Drawing.Size(203, 6);
		this.muTrimRam.Name = "muTrimRam";
		this.muTrimRam.Size = new global::System.Drawing.Size(206, 22);
		this.muTrimRam.Text = "Giảm Ram Sử Dụng";
		this.muTrimRam.DropDownOpening += new global::System.EventHandler(this.muTrimRam_DropDownOpening);
		this.muTrimRam.Click += new global::System.EventHandler(this.muTrimRam_Click);
		this.toolStripMenuItem_16.Name = "chỉĐánhNgườiToolStripMenuItem";
		this.toolStripMenuItem_16.Size = new global::System.Drawing.Size(206, 22);
		this.toolStripMenuItem_16.Text = "Chỉ Đánh Người";
		this.toolStripMenuItem_16.Click += new global::System.EventHandler(this.toolStripMenuItem_16_Click);
		this.toolStripMenuItem30.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.menuGoTrieuTap,
			this.toolStripMenuItem_164,
			this.toolStripMenuItem_55,
			this.toolStripMenuItem_27,
			this.toolStripMenuItem_149,
			this.toolStripMenuItem_29,
			this.toolStripMenuItem_28,
			this.toolStripMenuItem_30,
			this.toolStripMenuItem_31,
			this.toolStripMenuItem_32,
			this.toolStripMenuItem_33,
			this.toolStripMenuItem_35,
			this.toolStripMenuItem_37,
			this.toolStripMenuItem_48,
			this.toolStripMenuItem_52
		});
		this.toolStripMenuItem30.Name = "toolStripMenuItem30";
		this.toolStripMenuItem30.Size = new global::System.Drawing.Size(34, 20);
		this.toolStripMenuItem30.Text = "Go";
		this.menuGoTrieuTap.Name = "menuGoTrieuTap";
		this.menuGoTrieuTap.Size = new global::System.Drawing.Size(241, 22);
		this.menuGoTrieuTap.Text = "Triệu Tập";
		this.menuGoTrieuTap.DropDownOpening += new global::System.EventHandler(this.menuGoTrieuTap_DropDownOpening);
		this.toolStripMenuItem_164.Name = "kimLăngDịchToolStripMenuItem";
		this.toolStripMenuItem_164.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_164.Tag = "383,531,762";
		this.toolStripMenuItem_164.Text = "Kim Lăng [Dịch]";
		this.toolStripMenuItem_164.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_55.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_56,
			this.toolStripMenuItem_57,
			this.toolStripMenuItem_58,
			this.toolStripMenuItem_59
		});
		this.toolStripMenuItem_55.Name = "kimLăngToolStripMenuItem";
		this.toolStripMenuItem_55.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_55.Text = "Kim Lăng";
		this.toolStripMenuItem_56.Name = "tiếnCấpThăngLinhToolStripMenuItem";
		this.toolStripMenuItem_56.Size = new global::System.Drawing.Size(269, 22);
		this.toolStripMenuItem_56.Tag = "277,220,762";
		this.toolStripMenuItem_56.Text = "[Tiến Cấp] -> Thăng Linh ";
		this.toolStripMenuItem_56.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_57.Name = "longVănTiêuƯngToolStripMenuItem";
		this.toolStripMenuItem_57.Size = new global::System.Drawing.Size(269, 22);
		this.toolStripMenuItem_57.Tag = "368,421,762";
		this.toolStripMenuItem_57.Text = "Long Văn [Tiêu Ưng]";
		this.toolStripMenuItem_57.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_58.Name = "thầnBinhTiêuDaoTửToolStripMenuItem";
		this.toolStripMenuItem_58.Size = new global::System.Drawing.Size(269, 22);
		this.toolStripMenuItem_58.Tag = "298,363,762";
		this.toolStripMenuItem_58.Text = "Thần Binh [Tiêu Dao Tử]";
		this.toolStripMenuItem_58.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_59.Name = "bảoGiámToolStripMenuItem";
		this.toolStripMenuItem_59.Size = new global::System.Drawing.Size(269, 22);
		this.toolStripMenuItem_59.Tag = "356,436,762";
		this.toolStripMenuItem_59.Text = "Ngưng Tụ Bảo Giám [Đỗ Xuyến Linh]";
		this.toolStripMenuItem_59.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_27.Name = "vàoBangTrịnhVôDanhToolStripMenuItem";
		this.toolStripMenuItem_27.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_27.Tag = "100,55,501";
		this.toolStripMenuItem_27.Text = "[Bang Hội] -> Trịnh Vô Danh";
		this.toolStripMenuItem_27.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_149.Name = "bangHộLệnhBàiToolStripMenuItem";
		this.toolStripMenuItem_149.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_149.Tag = "46,48,501";
		this.toolStripMenuItem_149.Text = "[Bang Hội] -> Lệnh Bài";
		this.toolStripMenuItem_149.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_29.Name = "tiềnTrangTônTiếnBảoToolStripMenuItem1";
		this.toolStripMenuItem_29.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_29.Tag = "65,42,224";
		this.toolStripMenuItem_29.Text = "[Tiền Trang] -> Tiếp Tục Lên Giá";
		this.toolStripMenuItem_29.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_28.Name = "thươngHộiKiềuPhúcThịnhToolStripMenuItem1";
		this.toolStripMenuItem_28.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_28.Tag = "329,296,0";
		this.toolStripMenuItem_28.Text = "Thương Hội [Kiều Phúc Thịnh]";
		this.toolStripMenuItem_28.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_30.Name = "chânNguyênTrươngSĩTâmToolStripMenuItem";
		this.toolStripMenuItem_30.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_30.Tag = "350,231,1";
		this.toolStripMenuItem_30.Text = "Chân Nguyên [Trương Sĩ Tâm]";
		this.toolStripMenuItem_30.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_31.Name = "conCáiTửLộTiênSinhToolStripMenuItem";
		this.toolStripMenuItem_31.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_31.Tag = "151,178,0";
		this.toolStripMenuItem_31.Text = "Con Cái [Tử Lộ Tiên Sinh]";
		this.toolStripMenuItem_31.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_32.Name = "kiểmĐịnhLiêuTâyToolStripMenuItem";
		this.toolStripMenuItem_32.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_32.Tag = "176,186,21";
		this.toolStripMenuItem_32.Text = "Kiểm Định [Liêu Tây]";
		this.toolStripMenuItem_32.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_33.Name = "bóngCầuPhúcToolStripMenuItem";
		this.toolStripMenuItem_33.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_33.Tag = "182,197,2";
		this.toolStripMenuItem_33.Text = "Bóng [Cầu Phúc]";
		this.toolStripMenuItem_33.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_35.Name = "trânThúSinhSảnToolStripMenuItem";
		this.toolStripMenuItem_35.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_35.Tag = "171,238,1";
		this.toolStripMenuItem_35.Text = "[Trân Thú] -> Sinh Sản";
		this.toolStripMenuItem_35.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_37.Name = "ápTiêuToolStripMenuItem";
		this.toolStripMenuItem_37.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_37.Tag = "393,345,762";
		this.toolStripMenuItem_37.Text = "Áp Tiêu";
		this.toolStripMenuItem_37.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_48.Name = "quanSơnHảiToolStripMenuItem";
		this.toolStripMenuItem_48.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_48.Tag = "211,51,2";
		this.toolStripMenuItem_48.Text = "Quan Sơn Hải";
		this.toolStripMenuItem_48.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_52.Name = "cửuLêChiếnSĩToolStripMenuItem";
		this.toolStripMenuItem_52.Size = new global::System.Drawing.Size(241, 22);
		this.toolStripMenuItem_52.Tag = "232,224,770";
		this.toolStripMenuItem_52.Text = "Cửu Lê Chiến Sĩ";
		this.toolStripMenuItem_52.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem19.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.bossToolStripMenuItem,
			this.toolStripMenuItem_60,
			this.toolStripMenuItem_75,
			this.toolStripMenuItem_65,
			this.toolStripMenuItem_84,
			this.xToolStripMenuItem,
			this.toolStripMenuItem_90,
			this.toolStripMenuItem_102
		});
		this.toolStripMenuItem19.Name = "toolStripMenuItem19";
		this.toolStripMenuItem19.Size = new global::System.Drawing.Size(44, 20);
		this.toolStripMenuItem19.Text = "Train";
		this.bossToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.longQuy16936ToolStripMenuItem
		});
		this.bossToolStripMenuItem.Name = "bossToolStripMenuItem";
		this.bossToolStripMenuItem.Size = new global::System.Drawing.Size(232, 22);
		this.bossToolStripMenuItem.Text = "Boss";
		this.longQuy16936ToolStripMenuItem.Name = "longQuy16936ToolStripMenuItem";
		this.longQuy16936ToolStripMenuItem.Size = new global::System.Drawing.Size(170, 22);
		this.longQuy16936ToolStripMenuItem.Tag = "169,36,201";
		this.longQuy16936ToolStripMenuItem.Text = "Long Quy [169,36]";
		this.longQuy16936ToolStripMenuItem.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_60.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_118,
			this.toolStripMenuItem_119,
			this.toolStripMenuItem_61,
			this.toolStripMenuItem_62,
			this.toolStripMenuItem_63,
			this.toolStripMenuItem_64,
			this.toolStripMenuItem_120,
			this.toolStripMenuItem_121,
			this.toolStripMenuItem_122,
			this.toolStripMenuItem_123,
			this.toolStripMenuItem_124,
			this.toolStripMenuItem_125,
			this.toolStripMenuItem_126,
			this.toolStripMenuItem20
		});
		this.toolStripMenuItem_60.Name = "maNhaiĐộngToolStripMenuItem";
		this.toolStripMenuItem_60.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_60.Text = "(3x -> 4x)";
		this.toolStripMenuItem_118.Name = "bãi110QuáiToolStripMenuItem";
		this.toolStripMenuItem_118.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_118.Tag = "52,192,18";
		this.toolStripMenuItem_118.Text = "Nhạn Nam 1 (~9 Quái) [52,192]";
		this.toolStripMenuItem_118.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_119.Name = "bãi28QuáiToolStripMenuItem";
		this.toolStripMenuItem_119.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_119.Tag = "129,207,18";
		this.toolStripMenuItem_119.Text = "Nhạn Nam 2 (~8 Quái) [129,207]";
		this.toolStripMenuItem_119.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_61.Name = "tầnGiaTrạiÁcBáToolStripMenuItem";
		this.toolStripMenuItem_61.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_61.Tag = "37,202,213";
		this.toolStripMenuItem_61.Text = "Ma Nhai Động 1 (~10 Quái) [37,202]";
		this.toolStripMenuItem_61.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_62.Name = "tầnGiaTrạiVệBinhToolStripMenuItem";
		this.toolStripMenuItem_62.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_62.Tag = "58,234,213";
		this.toolStripMenuItem_62.Text = "Ma Nhai Động 2 (~14 Quái) [58,234]";
		this.toolStripMenuItem_62.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_63.Name = "tầnGiaTrạiThổPhỉToolStripMenuItem";
		this.toolStripMenuItem_63.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_63.Tag = "87,228,213";
		this.toolStripMenuItem_63.Text = "Ma Nhai Động 3 (~15 Quái) [87,228]";
		this.toolStripMenuItem_63.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_64.Name = "bãi1314QuáiToolStripMenuItem";
		this.toolStripMenuItem_64.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_64.Tag = "215,99,213";
		this.toolStripMenuItem_64.Text = "Ma Nhai Động 4 (~14 Quái) [215,99]";
		this.toolStripMenuItem_64.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_120.Name = "bãi19QuáiToolStripMenuItem";
		this.toolStripMenuItem_120.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_120.Tag = "87,87,212";
		this.toolStripMenuItem_120.Text = "Kiếm Gia 1 (~9 Quái) [87,87]";
		this.toolStripMenuItem_120.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_121.Name = "bãi210Quái8787ToolStripMenuItem";
		this.toolStripMenuItem_121.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_121.Tag = "78,207,212";
		this.toolStripMenuItem_121.Text = "Kiếm Gia 2 (~9 Quái) [78,207]";
		this.toolStripMenuItem_121.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_122.Name = "bãi38QuáiToolStripMenuItem";
		this.toolStripMenuItem_122.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_122.Tag = "209,34,212";
		this.toolStripMenuItem_122.Text = "Kiếm Gia 3 (~8 Quái) [209,34]";
		this.toolStripMenuItem_122.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_123.Name = "bãi115QuáiToolStripMenuItem";
		this.toolStripMenuItem_123.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_123.Tag = "35,175,214";
		this.toolStripMenuItem_123.Text = "Dã Nhân Cốc 1 (~ 15 Quái) [35.175]";
		this.toolStripMenuItem_123.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_124.Name = "bãi29QuáiToolStripMenuItem";
		this.toolStripMenuItem_124.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_124.Tag = "143,55,214";
		this.toolStripMenuItem_124.Text = "Dã Nhân Cốc 2 (~12 Quái) [143,55]";
		this.toolStripMenuItem_124.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_125.Name = "bãi310QuáiToolStripMenuItem";
		this.toolStripMenuItem_125.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_125.Tag = "223,213,214";
		this.toolStripMenuItem_125.Text = "Dã Nhân Cốc 3 (~10 Quái) [223,213]";
		this.toolStripMenuItem_125.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_126.Name = "thảoLiệuTrường12QuáiToolStripMenuItem";
		this.toolStripMenuItem_126.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem_126.Tag = "112,205,199";
		this.toolStripMenuItem_126.Text = "Thảo Liệu Trường 1 (~13 Quái) [112,205]";
		this.toolStripMenuItem_126.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem20.Name = "toolStripMenuItem20";
		this.toolStripMenuItem20.Size = new global::System.Drawing.Size(283, 22);
		this.toolStripMenuItem20.Tag = "192,81,199";
		this.toolStripMenuItem20.Text = "Thảo Liệu Trường 2 (~13 Quái) [192,81]";
		this.toolStripMenuItem20.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_75.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_76,
			this.toolStripMenuItem_77,
			this.toolStripMenuItem_78,
			this.toolStripMenuItem_79,
			this.toolStripMenuItem_80,
			this.toolStripMenuItem_81,
			this.toolStripMenuItem_82,
			this.toolStripMenuItem_83
		});
		this.toolStripMenuItem_75.Name = "xHoàngLongĐộngToolStripMenuItem";
		this.toolStripMenuItem_75.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_75.Text = "(5x) Hoàng Long Động";
		this.toolStripMenuItem_76.Name = "bãi1ToolStripMenuItem4";
		this.toolStripMenuItem_76.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_76.Tag = "144,223,216";
		this.toolStripMenuItem_76.Text = "Bãi 1 (~ 20 Quái) [144,223]";
		this.toolStripMenuItem_76.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_77.Name = "bãi211QuáiToolStripMenuItem";
		this.toolStripMenuItem_77.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_77.Tag = "185,216,216";
		this.toolStripMenuItem_77.Text = "Bãi 2 (~ 11 Quái) [185,216]";
		this.toolStripMenuItem_77.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_78.Name = "bãi340QuáiToolStripMenuItem";
		this.toolStripMenuItem_78.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_78.Tag = "127,97,216";
		this.toolStripMenuItem_78.Text = "Bãi 3 (~ 40 Quái) [127,97]";
		this.toolStripMenuItem_78.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_79.Name = "bãi425QuáiToolStripMenuItem";
		this.toolStripMenuItem_79.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_79.Tag = "49,211,216";
		this.toolStripMenuItem_79.Text = "Bãi 4 (~28 Quái) [49,211]";
		this.toolStripMenuItem_79.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_80.Name = "bãi515QuáiToolStripMenuItem";
		this.toolStripMenuItem_80.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_80.Tag = "43,48,216";
		this.toolStripMenuItem_80.Text = "Bãi 5 (~15 Quái) [43,48]";
		this.toolStripMenuItem_80.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_81.Name = "bãi6ToolStripMenuItem";
		this.toolStripMenuItem_81.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_81.Tag = "93,33,216";
		this.toolStripMenuItem_81.Text = "Bãi 6 (~15 Quái) [93,33]";
		this.toolStripMenuItem_81.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_82.Name = "bãi715QuáiToolStripMenuItem";
		this.toolStripMenuItem_82.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_82.Tag = "154,33,216";
		this.toolStripMenuItem_82.Text = "Bãi 7 (~11 Quái) [154,33]";
		this.toolStripMenuItem_82.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_83.Name = "bãi810QuáiToolStripMenuItem";
		this.toolStripMenuItem_83.Size = new global::System.Drawing.Size(211, 22);
		this.toolStripMenuItem_83.Tag = "192,40,216";
		this.toolStripMenuItem_83.Text = "Bãi 8 (~10 Quái) [192,40]";
		this.toolStripMenuItem_83.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_65.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_66,
			this.toolStripMenuItem_67,
			this.toolStripMenuItem_68,
			this.toolStripMenuItem_69,
			this.toolStripMenuItem_70,
			this.toolStripMenuItem_71,
			this.toolStripMenuItem_72,
			this.toolStripMenuItem_73,
			this.toolStripMenuItem_74
		});
		this.toolStripMenuItem_65.Name = "x8xCổMộToolStripMenuItem";
		this.toolStripMenuItem_65.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_65.Text = "(5x->7x) Cổ Mộ";
		this.toolStripMenuItem_66.Name = "yếnVương1ToolStripMenuItem";
		this.toolStripMenuItem_66.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_66.Tag = "43,42,202";
		this.toolStripMenuItem_66.Text = "Yến Vương 1 [43,42]";
		this.toolStripMenuItem_66.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_67.Name = "yếnVương2ToolStripMenuItem";
		this.toolStripMenuItem_67.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_67.Tag = "77,46,203";
		this.toolStripMenuItem_67.Text = "Yến Vương 2 [77,46]";
		this.toolStripMenuItem_67.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_68.Name = "yếnVương3ToolStripMenuItem";
		this.toolStripMenuItem_68.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_68.Tag = "41,51,204";
		this.toolStripMenuItem_68.Text = "Yến Vương 3 [41,51]";
		this.toolStripMenuItem_68.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_69.Name = "yếnVương43496ToolStripMenuItem";
		this.toolStripMenuItem_69.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_69.Tag = "36,96,205";
		this.toolStripMenuItem_69.Text = "Yến Vương 4 [34,96]";
		this.toolStripMenuItem_69.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_70.Name = "yếnVương55064ToolStripMenuItem";
		this.toolStripMenuItem_70.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_70.Tag = "50,64,206";
		this.toolStripMenuItem_70.Text = "Yến Vương 5 [50,64]";
		this.toolStripMenuItem_70.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_71.Name = "yếnVương66464ToolStripMenuItem";
		this.toolStripMenuItem_71.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_71.Tag = "64,64,207";
		this.toolStripMenuItem_71.Text = "Yến Vương 6 [64,64]";
		this.toolStripMenuItem_71.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_72.Name = "yếnVương72362ToolStripMenuItem";
		this.toolStripMenuItem_72.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_72.Tag = "56,61,208";
		this.toolStripMenuItem_72.Text = "Yến Vương 7 [56,61]";
		this.toolStripMenuItem_72.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_73.Name = "yếnVương82046ToolStripMenuItem";
		this.toolStripMenuItem_73.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_73.Tag = "20,46,209";
		this.toolStripMenuItem_73.Text = "Yến Vương 8 [20,46]";
		this.toolStripMenuItem_73.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_74.Name = "yếnVương9ToolStripMenuItem";
		this.toolStripMenuItem_74.Size = new global::System.Drawing.Size(179, 22);
		this.toolStripMenuItem_74.Tag = "56,73,210";
		this.toolStripMenuItem_74.Text = "Yến Vương 9 [56,73]";
		this.toolStripMenuItem_74.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_84.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem53,
			this.toolStripMenuItem54,
			this.toolStripMenuItem55,
			this.toolStripMenuItem56
		});
		this.toolStripMenuItem_84.Name = "tầnHoàngĐịaCungToolStripMenuItem";
		this.toolStripMenuItem_84.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_84.Text = "(6x->8x) Tần Hoàng Địa Cung";
		this.toolStripMenuItem53.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_85,
			this.toolStripMenuItem_86,
			this.toolStripMenuItem_87
		});
		this.toolStripMenuItem53.Name = "toolStripMenuItem53";
		this.toolStripMenuItem53.Size = new global::System.Drawing.Size(109, 22);
		this.toolStripMenuItem53.Text = "Tầng 1";
		this.toolStripMenuItem_85.Name = "bãi1ToolStripMenuItem";
		this.toolStripMenuItem_85.Size = new global::System.Drawing.Size(99, 22);
		this.toolStripMenuItem_85.Tag = "169,140,262";
		this.toolStripMenuItem_85.Text = "Bãi 1";
		this.toolStripMenuItem_85.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_86.Name = "bãi1ToolStripMenuItem1";
		this.toolStripMenuItem_86.Size = new global::System.Drawing.Size(99, 22);
		this.toolStripMenuItem_86.Tag = "108,170,262";
		this.toolStripMenuItem_86.Text = "Bãi 2";
		this.toolStripMenuItem_86.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_87.Name = "bãi1ToolStripMenuItem2";
		this.toolStripMenuItem_87.Size = new global::System.Drawing.Size(99, 22);
		this.toolStripMenuItem_87.Tag = "66,85,262";
		this.toolStripMenuItem_87.Text = "Bãi 3";
		this.toolStripMenuItem_87.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem54.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_88,
			this.toolStripMenuItem_89
		});
		this.toolStripMenuItem54.Name = "toolStripMenuItem54";
		this.toolStripMenuItem54.Size = new global::System.Drawing.Size(109, 22);
		this.toolStripMenuItem54.Text = "Tầng 2";
		this.toolStripMenuItem_88.Name = "bãi1ToolStripMenuItem3";
		this.toolStripMenuItem_88.Size = new global::System.Drawing.Size(99, 22);
		this.toolStripMenuItem_88.Tag = "37,218,263";
		this.toolStripMenuItem_88.Text = "Bãi 1";
		this.toolStripMenuItem_88.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_89.Name = "bãi2ToolStripMenuItem";
		this.toolStripMenuItem_89.Size = new global::System.Drawing.Size(99, 22);
		this.toolStripMenuItem_89.Tag = "220,34,263";
		this.toolStripMenuItem_89.Text = "Bãi 2";
		this.toolStripMenuItem_89.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem55.Name = "toolStripMenuItem55";
		this.toolStripMenuItem55.Size = new global::System.Drawing.Size(109, 22);
		this.toolStripMenuItem55.Tag = "224,216,264";
		this.toolStripMenuItem55.Text = "Tầng 3";
		this.toolStripMenuItem55.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem56.Name = "toolStripMenuItem56";
		this.toolStripMenuItem56.Size = new global::System.Drawing.Size(109, 22);
		this.toolStripMenuItem56.Tag = "31,33,292";
		this.toolStripMenuItem56.Text = "Tầng 4";
		this.toolStripMenuItem56.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.xToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_112,
			this.toolStripMenuItem_113,
			this.toolStripMenuItem_114,
			this.toolStripMenuItem_115,
			this.toolStripMenuItem_110,
			this.toolStripMenuItem_111,
			this.toolStripMenuItem_127,
			this.toolStripMenuItem_117,
			this.toolStripMenuItem_128,
			this.toolStripMenuItem_116
		});
		this.xToolStripMenuItem.Name = "xToolStripMenuItem";
		this.xToolStripMenuItem.Size = new global::System.Drawing.Size(232, 22);
		this.xToolStripMenuItem.Text = "(6x + 7x + 8x)";
		this.xToolStripMenuItem.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_112.Name = "bãi115QuáiToolStripMenuItem1";
		this.toolStripMenuItem_112.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_112.Tag = "84,96,283";
		this.toolStripMenuItem_112.Text = "6x Thanh Nguyên 1 (~15 Quái) [84,96]";
		this.toolStripMenuItem_112.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_113.Name = "bãi215QuáiToolStripMenuItem";
		this.toolStripMenuItem_113.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_113.Tag = "195,77,283";
		this.toolStripMenuItem_113.Text = "6x Thanh Nguyên 2 (~14 Quái) [195,77]";
		this.toolStripMenuItem_113.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_114.Name = "bãi314QuáiToolStripMenuItem";
		this.toolStripMenuItem_114.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_114.Tag = "179,119,283";
		this.toolStripMenuItem_114.Text = "6x Thanh Nguyên 3 (~14 Quái) [179,119]";
		this.toolStripMenuItem_114.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_115.Name = "thủyTinhHồToolStripMenuItem";
		this.toolStripMenuItem_115.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_115.Tag = "38,185,217";
		this.toolStripMenuItem_115.Text = "6x Thủy Kính Hồ (~12 Quái) [38,185]";
		this.toolStripMenuItem_115.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_110.Name = "miêuNhânĐộngToolStripMenuItem";
		this.toolStripMenuItem_110.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_110.Tag = "173,153,200";
		this.toolStripMenuItem_110.Text = "6x Miêu Nhân Động (~23 Quái) [173,153] ";
		this.toolStripMenuItem_110.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_111.Name = "đàoHoaNguyên12QuáiToolStripMenuItem";
		this.toolStripMenuItem_111.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_111.Tag = "26,194,220";
		this.toolStripMenuItem_111.Text = "7x Đào Hoa Nguyên (~12 Quái) [26,194]";
		this.toolStripMenuItem_111.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_127.Name = "xTiênVươngPhần14QuáiToolStripMenuItem";
		this.toolStripMenuItem_127.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_127.Tag = "127,85,218";
		this.toolStripMenuItem_127.Text = "7x Tiên Vương Phần (~14 Quái) [127,85]";
		this.toolStripMenuItem_127.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_117.Name = "tuyếtNguyên10QuáiToolStripMenuItem";
		this.toolStripMenuItem_117.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_117.Tag = "169,185,229";
		this.toolStripMenuItem_117.Text = "7x Tuyết Nguyên (~11 Quái) [169,185]";
		this.toolStripMenuItem_117.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_128.Name = "xHảiTặcĐộng15QuáiToolStripMenuItem";
		this.toolStripMenuItem_128.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_128.Tag = "64,199,221";
		this.toolStripMenuItem_128.Text = "8x Hải Tặc Động (~15 Quái) [64,199]";
		this.toolStripMenuItem_128.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_116.Name = "diêmKhanh21QuáiToolStripMenuItem";
		this.toolStripMenuItem_116.Size = new global::System.Drawing.Size(292, 22);
		this.toolStripMenuItem_116.Tag = "40,78,237";
		this.toolStripMenuItem_116.Text = "8x Diêm Khanh (~21 Quái) [40,78]";
		this.toolStripMenuItem_116.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_90.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_91,
			this.toolStripMenuItem_92,
			this.toolStripMenuItem_93,
			this.toolStripMenuItem_94,
			this.toolStripMenuItem_95,
			this.toolStripMenuItem_96,
			this.toolStripMenuItem_97,
			this.toolStripMenuItem_98,
			this.toolStripMenuItem_99,
			this.toolStripMenuItem_100,
			this.toolStripMenuItem_101
		});
		this.toolStripMenuItem_90.Name = "xThếGiớiToolStripMenuItem";
		this.toolStripMenuItem_90.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_90.Text = "(9x+) Thế Giới";
		this.toolStripMenuItem_91.Name = "caoXương1ToolStripMenuItem";
		this.toolStripMenuItem_91.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_91.Tag = "41,51,252";
		this.toolStripMenuItem_91.Text = "Cao Xương 1 (~22 Quái) [41,51]";
		this.toolStripMenuItem_91.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_92.Name = "caoXương2ToolStripMenuItem";
		this.toolStripMenuItem_92.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_92.Tag = "80,36,252";
		this.toolStripMenuItem_92.Text = "Cao Xương 2 (~22 Quái) [80,36]";
		this.toolStripMenuItem_92.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_93.Name = "hỏaDiệm124QuáiToolStripMenuItem";
		this.toolStripMenuItem_93.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_93.Tag = "48,87,251";
		this.toolStripMenuItem_93.Text = "Hỏa Diệm 1 (~24 Quái) [48,87]";
		this.toolStripMenuItem_93.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_94.Name = "hỏaDiệm2ToolStripMenuItem";
		this.toolStripMenuItem_94.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_94.Tag = "85,86,251";
		this.toolStripMenuItem_94.Text = "Hỏa Diệm 2 (~24 Quái) [85,86]";
		this.toolStripMenuItem_94.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_95.Name = "thápKhắc120QuáiToolStripMenuItem";
		this.toolStripMenuItem_95.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_95.Tag = "97,83,253";
		this.toolStripMenuItem_95.Text = "Tháp Khắc (~20 Quái) [97,83]";
		this.toolStripMenuItem_95.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_96.Name = "thánhHỏaCung25QuáiToolStripMenuItem";
		this.toolStripMenuItem_96.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_96.Tag = "71,55,256";
		this.toolStripMenuItem_96.Text = "Thánh Hỏa Cung (~25 Quái) [71,55]";
		this.toolStripMenuItem_96.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_97.Name = "hãnHuyếtLĩnh116QuáiToolStripMenuItem";
		this.toolStripMenuItem_97.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_97.Tag = "44,76,255";
		this.toolStripMenuItem_97.Text = "Hãn Huyết Lĩnh 1 (~20 Quái) [44,76]";
		this.toolStripMenuItem_97.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_98.Name = "hãnHuyếtLĩnh2ToolStripMenuItem";
		this.toolStripMenuItem_98.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_98.Tag = "81,55,255";
		this.toolStripMenuItem_98.Text = "Hãn Huyết Lĩnh 2 (~22 Quái) [81,55]";
		this.toolStripMenuItem_98.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_99.Name = "cônLônSơn16QuáiToolStripMenuItem";
		this.toolStripMenuItem_99.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_99.Tag = "222,104,248";
		this.toolStripMenuItem_99.Text = "Côn Lôn Sơn (~16 Quái) [222,104]";
		this.toolStripMenuItem_99.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_100.Name = "cônLônPhúcĐịa21QuáiToolStripMenuItem";
		this.toolStripMenuItem_100.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_100.Tag = "68,98,254";
		this.toolStripMenuItem_100.Text = "Côn Lôn Phúc Địa 1 (~22 Quái) [68,98]";
		this.toolStripMenuItem_100.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_101.Name = "cônLônPhúcĐịa2ToolStripMenuItem";
		this.toolStripMenuItem_101.Size = new global::System.Drawing.Size(275, 22);
		this.toolStripMenuItem_101.Tag = "40,83,254";
		this.toolStripMenuItem_101.Text = "Côn Lôn Phúc Địa 2 (~22 Quái) [40,83]";
		this.toolStripMenuItem_101.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_102.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_103,
			this.toolStripMenuItem_104,
			this.toolStripMenuItem_105,
			this.toolStripMenuItem_106,
			this.toolStripMenuItem_107,
			this.toolStripMenuItem_108,
			this.toolStripMenuItem_109,
			this.toolStripMenuItem_129,
			this.toolStripMenuItem_130
		});
		this.toolStripMenuItem_102.Name = "xKimLăngToolStripMenuItem";
		this.toolStripMenuItem_102.Size = new global::System.Drawing.Size(232, 22);
		this.toolStripMenuItem_102.Text = "(9x+) Kim Lăng";
		this.toolStripMenuItem_103.Name = "cổKimĐình142QuáiToolStripMenuItem";
		this.toolStripMenuItem_103.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_103.Tag = "194,163,758";
		this.toolStripMenuItem_103.Text = "Cổ Kim Đình 1 (~42 Quái) [194,163]";
		this.toolStripMenuItem_103.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_104.Name = "cổKimĐình239QuáiToolStripMenuItem";
		this.toolStripMenuItem_104.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_104.Tag = "99,192,758";
		this.toolStripMenuItem_104.Text = "Cổ Kim Đình 2 (~39 Quái) [99,192]";
		this.toolStripMenuItem_104.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_105.Name = "cổKimĐình344QuáiToolStripMenuItem";
		this.toolStripMenuItem_105.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_105.Tag = "171,331,758";
		this.toolStripMenuItem_105.Text = "Cổ Kim Đình 3 (~44 Quái) [171,331]";
		this.toolStripMenuItem_105.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_106.Name = "bíchDuẩnXuânLâm134QuáiToolStripMenuItem";
		this.toolStripMenuItem_106.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_106.Tag = "144,139,769";
		this.toolStripMenuItem_106.Text = "Bích Duẩn Xuân Lâm 1 (~34 Quái) [144,139]";
		this.toolStripMenuItem_106.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_107.Name = "bíchDuẩnXuânLâm238QuáiToolStripMenuItem";
		this.toolStripMenuItem_107.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_107.Tag = "147,305,769";
		this.toolStripMenuItem_107.Text = "Bích Duẩn Xuân Lâm 2 (~38 Quái) [147,305]";
		this.toolStripMenuItem_107.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_108.Name = "bíchDuẩnXuânLâm331QuáiToolStripMenuItem";
		this.toolStripMenuItem_108.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_108.Tag = "206,421,769";
		this.toolStripMenuItem_108.Text = "Bích Duẩn Xuân Lâm 3 (~31 Quái) [206,421]";
		this.toolStripMenuItem_108.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_109.Name = "vũTrúcCương132QuáiToolStripMenuItem";
		this.toolStripMenuItem_109.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_109.Tag = "241,151,770";
		this.toolStripMenuItem_109.Text = "Vũ Trúc Cương 1 (~32 Quái) [241,151]";
		this.toolStripMenuItem_109.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_129.Name = "vũTrúcCương232Quái241151ToolStripMenuItem";
		this.toolStripMenuItem_129.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_129.Tag = "168,377,770";
		this.toolStripMenuItem_129.Text = "Vũ Trúc Cương 2 (~28 Quái) [168,377]";
		this.toolStripMenuItem_129.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.toolStripMenuItem_130.Name = "vũTrúcCương333Quái168377ToolStripMenuItem";
		this.toolStripMenuItem_130.Size = new global::System.Drawing.Size(302, 22);
		this.toolStripMenuItem_130.Tag = "434,235,770";
		this.toolStripMenuItem_130.Text = "Vũ Trúc Cương 3 (~33 Quái) [434,235]";
		this.toolStripMenuItem_130.Click += new global::System.EventHandler(this.toolStripMenuItem_130_Click);
		this.backgroundWorker_1.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_1_DoWork);
		this.timer_5.Interval = 50;
		this.timer_5.Tick += new global::System.EventHandler(this.timer_5_Tick);
		this.timer_6.Enabled = true;
		this.timer_6.Interval = 5000;
		this.timer_6.Tick += new global::System.EventHandler(this.timer_6_Tick);
		this.timer_7.Enabled = true;
		this.timer_7.Interval = 1000;
		this.timer_7.Tick += new global::System.EventHandler(this.timer_7_Tick);
		this.Container.Controls.Add(this.tab);
		this.Container.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.Container.Location = new global::System.Drawing.Point(0, 24);
		this.Container.Name = "Container";
		this.Container.Size = new global::System.Drawing.Size(384, 497);
		this.Container.TabIndex = 12;
		this.tab.TabAlignment_0 = global::System.Windows.Forms.TabAlignment.Top;
		this.tab.Controls.Add(this.tabGame);
		this.tab.Controls.Add(this.tabLogin);
		this.tab.Controls.Add(this.tabSetting);
		this.tab.Controls.Add(this.tabChat);
		this.tab.Controls.Add(this.tabUser);
		this.tab.Controls.Add(this.tabLog);
		this.tab.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tab.Location = new global::System.Drawing.Point(0, 0);
		this.tab.Name = "tab";
		this.tab.SelectedIndex = 0;
		this.tab.Size = new global::System.Drawing.Size(384, 497);
		this.tab.TabIndex = 11;
		this.tabGame.Controls.Add(this.panMain);
		this.tabGame.Location = new global::System.Drawing.Point(4, 22);
		this.tabGame.Name = "tabGame";
		this.tabGame.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabGame.Size = new global::System.Drawing.Size(376, 471);
		this.tabGame.TabIndex = 0;
		this.tabGame.Text = "Game";
		this.tabGame.UseVisualStyleBackColor = true;
		this.panMain.Controls.Add(this.panTop);
		this.panMain.Controls.Add(this.panBottom);
		this.panMain.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panMain.Location = new global::System.Drawing.Point(3, 3);
		this.panMain.Name = "panMain";
		this.panMain.Size = new global::System.Drawing.Size(370, 465);
		this.panMain.TabIndex = 10;
		this.panTop.Controls.Add(this.panel3);
		this.panTop.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panTop.Location = new global::System.Drawing.Point(0, 0);
		this.panTop.Name = "panTop";
		this.panTop.Size = new global::System.Drawing.Size(370, 236);
		this.panTop.TabIndex = 9;
		this.panel3.Controls.Add(this.Lv);
		this.panel3.Controls.Add(this.gameInfo);
		this.panel3.Controls.Add(this.txtMainSearch);
		this.panel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panel3.Location = new global::System.Drawing.Point(0, 0);
		this.panel3.Name = "panel3";
		this.panel3.Size = new global::System.Drawing.Size(370, 236);
		this.panel3.TabIndex = 1;
		this.Lv.AllowColumnReorder = true;
		this.Lv.AllowDrop = true;
		this.Lv.AllowReorder = true;
		this.Lv.AllowSort = true;
		this.Lv.CheckBoxes = true;
		this.Lv.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_10,
			this.columnHeader_11,
			this.columnHeader_24,
			this.columnHeader_12,
			this.columnHeader_13,
			this.columnHeader_14,
			this.columnHeader_15,
			this.columnHeader_16,
			this.columnHeader_17,
			this.columnHeader_18,
			this.columnHeader_19,
			this.columnHeader_20,
			this.columnHeader_21,
			this.columnHeader_22
		});
		this.Lv.ContextMenuStrip = this.menuListView;
		this.Lv.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.Lv.DoubleClickActivation = false;
		this.Lv.FullRowSelect = true;
		this.Lv.GridLines = true;
		this.Lv.hideItems = null;
		this.Lv.HideSelection = false;
		this.Lv.LineColor = global::System.Drawing.Color.Red;
		this.Lv.Location = new global::System.Drawing.Point(0, 20);
		this.Lv.Name = "Lv";
		this.Lv.OwnerDraw = true;
		this.Lv.Size = new global::System.Drawing.Size(370, 198);
		this.Lv.TabIndex = 8;
		this.Lv.UseCompatibleStateImageBehavior = false;
		this.Lv.View = global::System.Windows.Forms.View.Details;
		this.Lv.ColumnWidthChanging += new global::System.Windows.Forms.ColumnWidthChangingEventHandler(this.Lv_ColumnWidthChanging);
		this.Lv.ItemCheck += new global::System.Windows.Forms.ItemCheckEventHandler(this.Lv_ItemCheck);
		this.Lv.ItemChecked += new global::System.Windows.Forms.ItemCheckedEventHandler(this.Lv_ItemChecked);
		this.Lv.SelectedIndexChanged += new global::System.EventHandler(this.Lv_SelectedIndexChanged);
		this.Lv.DoubleClick += new global::System.EventHandler(this.Lv_DoubleClick);
		this.Lv.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.Lv_KeyDown);
		this.Lv.KeyPress += new global::System.Windows.Forms.KeyPressEventHandler(this.Lv_KeyPress);
		this.Lv.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.Lv_MouseUp);
		this.columnHeader_10.Tag = "Name";
		this.columnHeader_10.Text = "Name";
		this.columnHeader_10.Width = 80;
		this.columnHeader_11.Tag = "Lvl";
		this.columnHeader_11.Text = "Lvl";
		this.columnHeader_11.Width = 32;
		this.columnHeader_24.Tag = "Menpai";
		this.columnHeader_24.Text = "Phái";
		this.columnHeader_24.Width = 55;
		this.columnHeader_12.Tag = "Status";
		this.columnHeader_12.Text = "Status";
		this.columnHeader_12.Width = 43;
		this.columnHeader_13.Tag = "HP";
		this.columnHeader_13.Text = "HP";
		this.columnHeader_13.Width = 32;
		this.columnHeader_14.Tag = "MP";
		this.columnHeader_14.Text = "MP";
		this.columnHeader_14.Width = 32;
		this.columnHeader_15.Tag = "Pet";
		this.columnHeader_15.Text = "Pet";
		this.columnHeader_15.Width = 32;
		this.columnHeader_16.Tag = "Online";
		this.columnHeader_16.Text = "Online";
		this.columnHeader_16.Width = 45;
		this.columnHeader_17.Tag = "Exp";
		this.columnHeader_17.Text = "Exp";
		this.columnHeader_17.Width = 54;
		this.columnHeader_18.Tag = "ExpSpeed";
		this.columnHeader_18.Text = "Exp/H";
		this.columnHeader_18.Width = 44;
		this.columnHeader_19.Tag = "Map";
		this.columnHeader_19.Text = "Vị trí";
		this.columnHeader_19.Width = 70;
		this.columnHeader_20.Tag = "Team";
		this.columnHeader_20.Text = "Đội ngũ";
		this.columnHeader_20.Width = 65;
		this.columnHeader_21.Tag = "HĐ";
		this.columnHeader_21.Text = "HĐ";
		this.columnHeader_21.Width = 32;
		this.columnHeader_22.Tag = "Vàng";
		this.columnHeader_22.Text = "Vàng";
		this.columnHeader_22.Width = 40;
		this.gameInfo.BackColor = global::System.Drawing.Color.Black;
		this.gameInfo.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.gameInfo.Location = new global::System.Drawing.Point(0, 218);
		this.gameInfo.Name = "gameInfo";
		this.gameInfo.Size = new global::System.Drawing.Size(370, 18);
		this.gameInfo.TabIndex = 10;
		this.txtMainSearch.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.txtMainSearch.Location = new global::System.Drawing.Point(0, 0);
		this.txtMainSearch.Name = "txtMainSearch";
		this.txtMainSearch.Size = new global::System.Drawing.Size(370, 20);
		this.txtMainSearch.TabIndex = 9;
		this.txtMainSearch.String_0 = "Search...";
		this.txtMainSearch.Color_0 = global::System.Drawing.Color.Gray;
		this.txtMainSearch.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtMainSearch.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtMainSearch.TextChanged += new global::System.EventHandler(this.txtMainSearch_TextChanged);
		this.panBottom.Controls.Add(this.tabBottom);
		this.panBottom.Controls.Add(this.tabCanQuet);
		this.panBottom.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.panBottom.Location = new global::System.Drawing.Point(0, 236);
		this.panBottom.Name = "panBottom";
		this.panBottom.Size = new global::System.Drawing.Size(370, 229);
		this.panBottom.TabIndex = 0;
		this.tabBottom.Controls.Add(this.tabBuff);
		this.tabBottom.Controls.Add(this.tabLife);
		this.tabBottom.Controls.Add(this.tabKey);
		this.tabBottom.Controls.Add(this.tabQuest);
		this.tabBottom.Controls.Add(this.tabCraft);
		this.tabBottom.Controls.Add(this.tabSwitch);
		this.tabBottom.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tabBottom.Location = new global::System.Drawing.Point(0, 0);
		this.tabBottom.Name = "tabBottom";
		this.tabBottom.Padding = new global::System.Drawing.Point(5, 3);
		this.tabBottom.SelectedIndex = 0;
		this.tabBottom.Size = new global::System.Drawing.Size(370, 229);
		this.tabBottom.TabIndex = 6;
		this.tabBottom.SelectedIndexChanged += new global::System.EventHandler(this.tabBottom_SelectedIndexChanged);
		this.tabBottom.Selecting += new global::System.Windows.Forms.TabControlCancelEventHandler(this.tabBottom_Selecting);
		this.tabBottom.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.tabBottom_MouseClick);
		this.tabBuff.Controls.Add(this.lbAcBa);
		this.tabBuff.Controls.Add(this.flowLayoutPanel1);
		this.tabBuff.Controls.Add(this.label4);
		this.tabBuff.Controls.Add(this.checkChetLenBai);
		this.tabBuff.Controls.Add(this.checkChiNhat);
		this.tabBuff.Controls.Add(this.btnAdd);
		this.tabBuff.Controls.Add(this.cboPlayer);
		this.tabBuff.Controls.Add(this.nudBuffPet);
		this.tabBuff.Controls.Add(this.checkTuyenChien);
		this.tabBuff.Controls.Add(this.btnPk);
		this.tabBuff.Controls.Add(this.checkBanKinh);
		this.tabBuff.Controls.Add(this.cboBaseSkill);
		this.tabBuff.Controls.Add(this.checkQuyCoc);
		this.tabBuff.Controls.Add(this.btnOnlyAttack);
		this.tabBuff.Controls.Add(this.numericUpDown2);
		this.tabBuff.Controls.Add(this.lblTrain);
		this.tabBuff.Controls.Add(this.checkChiDanh);
		this.tabBuff.Controls.Add(this.checkHP);
		this.tabBuff.Controls.Add(this.nudNM);
		this.tabBuff.Controls.Add(this.lblRadius);
		this.tabBuff.Controls.Add(this.nudRadius);
		this.tabBuff.Controls.Add(this.checkLuaQuai);
		this.tabBuff.Controls.Add(this.btnNM);
		this.tabBuff.Controls.Add(this.checkTimQuai);
		this.tabBuff.Controls.Add(this.cboNM);
		this.tabBuff.Controls.Add(this.cboHP);
		this.tabBuff.Controls.Add(this.checkPet);
		this.tabBuff.Controls.Add(this.checkNM);
		this.tabBuff.Controls.Add(this.nudHP);
		this.tabBuff.Controls.Add(this.checkMP);
		this.tabBuff.Controls.Add(this.nudMP);
		this.tabBuff.Location = new global::System.Drawing.Point(4, 4);
		this.tabBuff.Name = "tabBuff";
		this.tabBuff.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabBuff.Size = new global::System.Drawing.Size(362, 203);
		this.tabBuff.TabIndex = 9;
		this.tabBuff.Text = "Buff";
		this.tabBuff.UseVisualStyleBackColor = true;
		this.flowLayoutPanel1.Controls.Add(this.lbExpSpeed);
		this.flowLayoutPanel1.Controls.Add(this.lblTimeInfo);
		this.flowLayoutPanel1.Controls.Add(this.lbHoaSpeed);
		this.flowLayoutPanel1.Controls.Add(this.button13);
		this.flowLayoutPanel1.Location = new global::System.Drawing.Point(247, 54);
		this.flowLayoutPanel1.Name = "flowLayoutPanel1";
		this.flowLayoutPanel1.Size = new global::System.Drawing.Size(110, 95);
		this.flowLayoutPanel1.TabIndex = 279;
		this.btnAdd.Location = new global::System.Drawing.Point(216, 30);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new global::System.Drawing.Size(23, 20);
		this.btnAdd.TabIndex = 248;
		this.btnAdd.Text = "+";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += new global::System.EventHandler(this.btnAdd_Click);
		this.btnPk.Location = new global::System.Drawing.Point(334, 6);
		this.btnPk.Name = "btnPk";
		this.btnPk.Size = new global::System.Drawing.Size(23, 23);
		this.btnPk.TabIndex = 256;
		this.btnPk.Text = "+";
		this.btnPk.UseVisualStyleBackColor = true;
		this.btnPk.Click += new global::System.EventHandler(this.btnPk_Click);
		this.checkBanKinh.AutoSize = true;
		this.checkBanKinh.Location = new global::System.Drawing.Point(9, 175);
		this.checkBanKinh.Name = "checkBanKinh";
		this.checkBanKinh.Size = new global::System.Drawing.Size(71, 17);
		this.checkBanKinh.TabIndex = 275;
		this.checkBanKinh.Text = "Bán Kính";
		this.checkBanKinh.UseVisualStyleBackColor = true;
		this.checkBanKinh.CheckedChanged += new global::System.EventHandler(this.checkBanKinh_CheckedChanged);
		this.cboBaseSkill.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboBaseSkill.FormattingEnabled = true;
		this.cboBaseSkill.Items.AddRange(new object[]
		{
			"F1",
			"F2",
			"F3",
			"F4",
			"F5",
			"F6",
			"F7",
			"F8",
			"F9",
			"F10",
			"F11",
			"F12",
			"Alt 1",
			"Alt 2",
			"Alt 3",
			"Alt 4",
			"Alt 5",
			"Alt 6",
			"Alt 7",
			"Alt 8",
			"Alt 9",
			"Alt 0"
		});
		this.cboBaseSkill.Location = new global::System.Drawing.Point(90, 8);
		this.cboBaseSkill.Name = "cboBaseSkill";
		this.cboBaseSkill.Size = new global::System.Drawing.Size(45, 21);
		this.cboBaseSkill.TabIndex = 240;
		this.cboBaseSkill.SelectedIndexChanged += new global::System.EventHandler(this.cboBaseSkill_SelectedIndexChanged);
		this.btnOnlyAttack.Location = new global::System.Drawing.Point(216, 6);
		this.btnOnlyAttack.Name = "btnOnlyAttack";
		this.btnOnlyAttack.Size = new global::System.Drawing.Size(23, 23);
		this.btnOnlyAttack.TabIndex = 184;
		this.btnOnlyAttack.Text = "+";
		this.btnOnlyAttack.UseVisualStyleBackColor = true;
		this.btnOnlyAttack.Click += new global::System.EventHandler(this.btnOnlyAttack_Click);
		this.btnNM.Location = new global::System.Drawing.Point(215, 99);
		this.btnNM.Name = "btnNM";
		this.btnNM.Size = new global::System.Drawing.Size(23, 23);
		this.btnNM.TabIndex = 169;
		this.btnNM.Text = "+";
		this.btnNM.UseVisualStyleBackColor = true;
		this.btnNM.Click += new global::System.EventHandler(this.btnNM_Click);
		this.cboNM.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboNM.FormattingEnabled = true;
		this.cboNM.Items.AddRange(new object[]
		{
			"F1",
			"F2",
			"F3",
			"F4",
			"F5",
			"F6",
			"F7",
			"F8",
			"F9",
			"F10",
			"F11",
			"F12",
			"Alt 1",
			"Alt 2",
			"Alt 3",
			"Alt 4",
			"Alt 5",
			"Alt 6",
			"Alt 7",
			"Alt 8",
			"Alt 9",
			"Alt 0",
			"Auto"
		});
		this.cboNM.Location = new global::System.Drawing.Point(141, 101);
		this.cboNM.Name = "cboNM";
		this.cboNM.Size = new global::System.Drawing.Size(68, 21);
		this.cboNM.TabIndex = 242;
		this.cboNM.SelectedIndexChanged += new global::System.EventHandler(this.cboNM_SelectedIndexChanged);
		this.cboHP.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboHP.FormattingEnabled = true;
		this.cboHP.Items.AddRange(new object[]
		{
			"F1",
			"F2",
			"F3",
			"F4",
			"F5",
			"F6",
			"F7",
			"F8",
			"F9",
			"F10",
			"F11",
			"F12",
			"Alt 1",
			"Alt 2",
			"Alt 3",
			"Alt 4",
			"Alt 5",
			"Alt 6",
			"Alt 7",
			"Alt 8",
			"Alt 9",
			"Alt 0",
			"Auto"
		});
		this.cboHP.Location = new global::System.Drawing.Point(141, 76);
		this.cboHP.Name = "cboHP";
		this.cboHP.Size = new global::System.Drawing.Size(68, 21);
		this.cboHP.TabIndex = 180;
		this.cboHP.SelectedIndexChanged += new global::System.EventHandler(this.cboHP_SelectedIndexChanged);
		this.tabLife.Controls.Add(this.checkMuaKNB);
		this.tabLife.Controls.Add(this.groupBox23);
		this.tabLife.Controls.Add(this.splitContainer1);
		this.tabLife.Controls.Add(this.numberGiaKNB);
		this.tabLife.Controls.Add(this.button3);
		this.tabLife.Controls.Add(this.cboThuHoach);
		this.tabLife.Controls.Add(this.groupBox25);
		this.tabLife.Controls.Add(this.checkHaiDuoc);
		this.tabLife.Controls.Add(this.checkTrongTrot);
		this.tabLife.Controls.Add(this.cboTrongTrot);
		this.tabLife.Controls.Add(this.checkThuHoach);
		this.tabLife.Controls.Add(this.checkXuatPet);
		this.tabLife.Controls.Add(this.cboXuatPet);
		this.tabLife.Controls.Add(this.btnOpenPass2);
		this.tabLife.Controls.Add(this.checkKhaiKhoang);
		this.tabLife.Controls.Add(this.label3);
		this.tabLife.Controls.Add(this.txtPass2);
		this.tabLife.Controls.Add(this.chkRaoVat);
		this.tabLife.Controls.Add(this.button4);
		this.tabLife.Controls.Add(this.txtRao);
		this.tabLife.Controls.Add(this.btnTalkChannel);
		this.tabLife.Location = new global::System.Drawing.Point(4, 4);
		this.tabLife.Name = "tabLife";
		this.tabLife.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabLife.Size = new global::System.Drawing.Size(362, 203);
		this.tabLife.TabIndex = 4;
		this.tabLife.Text = "Life";
		this.tabLife.UseVisualStyleBackColor = true;
		this.tabLife.Click += new global::System.EventHandler(this.tabLife_Click);
		this.checkMuaKNB.AutoSize = true;
		this.checkMuaKNB.Location = new global::System.Drawing.Point(9, 132);
		this.checkMuaKNB.Name = "checkMuaKNB";
		this.checkMuaKNB.Size = new global::System.Drawing.Size(72, 17);
		this.checkMuaKNB.TabIndex = 14;
		this.checkMuaKNB.Text = "Mua KNB";
		this.checkMuaKNB.UseVisualStyleBackColor = true;
		this.checkMuaKNB.CheckedChanged += new global::System.EventHandler(this.checkMuaKNB_CheckedChanged);
		this.groupBox23.Controls.Add(this.numberThuHoaX);
		this.groupBox23.Controls.Add(this.label10);
		this.groupBox23.Controls.Add(this.numberRadiusThuHoa);
		this.groupBox23.Location = new global::System.Drawing.Point(205, 98);
		this.groupBox23.Name = "groupBox23";
		this.groupBox23.Size = new global::System.Drawing.Size(151, 44);
		this.groupBox23.TabIndex = 281;
		this.groupBox23.TabStop = false;
		this.groupBox23.Text = "Thu Hoạch Hoa";
		this.label10.AutoSize = true;
		this.label10.Location = new global::System.Drawing.Point(57, 18);
		this.label10.Name = "label10";
		this.label10.Size = new global::System.Drawing.Size(13, 13);
		this.label10.TabIndex = 278;
		this.label10.Text = "+";
		this.splitContainer1.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.splitContainer1.Location = new global::System.Drawing.Point(3, 156);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.button10);
		this.splitContainer1.Panel1.Controls.Add(this.cboNgoc);
		this.splitContainer1.Panel2.Controls.Add(this.button18);
		this.splitContainer1.Panel2.Controls.Add(this.comboBox2);
		this.splitContainer1.Size = new global::System.Drawing.Size(356, 44);
		this.splitContainer1.SplitterDistance = 173;
		this.splitContainer1.TabIndex = 247;
		this.button10.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.button10.Location = new global::System.Drawing.Point(0, 21);
		this.button10.Name = "button10";
		this.button10.Size = new global::System.Drawing.Size(173, 23);
		this.button10.TabIndex = 5;
		this.button10.Text = "Hợp";
		this.button10.UseVisualStyleBackColor = true;
		this.button10.Click += new global::System.EventHandler(this.button10_Click);
		this.cboNgoc.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.cboNgoc.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboNgoc.FormattingEnabled = true;
		this.cboNgoc.Items.AddRange(new object[]
		{
			"Độc Công 3",
			"Băng Công 3",
			"Huyền Công 3",
			"Hỏa Công 3",
			"Kháng Độc 3",
			"Kháng Băng 3",
			"Kháng Huyền 3",
			"Kháng Hỏa 3"
		});
		this.cboNgoc.Location = new global::System.Drawing.Point(0, 0);
		this.cboNgoc.Name = "cboNgoc";
		this.cboNgoc.Size = new global::System.Drawing.Size(173, 21);
		this.cboNgoc.TabIndex = 4;
		this.cboNgoc.DropDown += new global::System.EventHandler(this.cboNgoc_DropDown);
		this.button18.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.button18.Location = new global::System.Drawing.Point(0, 21);
		this.button18.Name = "button18";
		this.button18.Size = new global::System.Drawing.Size(179, 23);
		this.button18.TabIndex = 4;
		this.button18.Text = "Điêu Trác";
		this.button18.UseVisualStyleBackColor = true;
		this.button18.Click += new global::System.EventHandler(this.button18_Click);
		this.comboBox2.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.comboBox2.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.comboBox2.FormattingEnabled = true;
		this.comboBox2.Items.AddRange(new object[]
		{
			"Độc Công 3",
			"Băng Công 3",
			"Huyền Công 3",
			"Hỏa Công 3",
			"Kháng Độc 3",
			"Kháng Băng 3",
			"Kháng Huyền 3",
			"Kháng Hỏa 3"
		});
		this.comboBox2.Location = new global::System.Drawing.Point(0, 0);
		this.comboBox2.Name = "comboBox2";
		this.comboBox2.Size = new global::System.Drawing.Size(179, 21);
		this.comboBox2.TabIndex = 3;
		this.comboBox2.DropDown += new global::System.EventHandler(this.comboBox2_DropDown);
		this.numberGiaKNB.Location = new global::System.Drawing.Point(101, 130);
		global::System.Windows.Forms.NumericUpDown numericUpDown31 = this.numberGiaKNB;
		int[] array31 = new int[4];
		array31[0] = 50;
		numericUpDown31.Maximum = new decimal(array31);
		global::System.Windows.Forms.NumericUpDown numericUpDown32 = this.numberGiaKNB;
		int[] array32 = new int[4];
		array32[0] = 1;
		numericUpDown32.Minimum = new decimal(array32);
		this.numberGiaKNB.Name = "numberGiaKNB";
		this.numberGiaKNB.Size = new global::System.Drawing.Size(42, 20);
		this.numberGiaKNB.TabIndex = 10;
		global::System.Windows.Forms.NumericUpDown numericUpDown33 = this.numberGiaKNB;
		int[] array33 = new int[4];
		array33[0] = 50;
		numericUpDown33.Value = new decimal(array33);
		this.numberGiaKNB.ValueChanged += new global::System.EventHandler(this.numberGiaKNB_ValueChanged);
		this.button3.Location = new global::System.Drawing.Point(176, 55);
		this.button3.Name = "button3";
		this.button3.Size = new global::System.Drawing.Size(23, 23);
		this.button3.TabIndex = 280;
		this.button3.Text = "+";
		this.button3.UseVisualStyleBackColor = true;
		this.button3.Click += new global::System.EventHandler(this.button3_Click);
		this.cboThuHoach.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboThuHoach.FormattingEnabled = true;
		this.cboThuHoach.Items.AddRange(new object[]
		{
			"Cây Thứ 1",
			"Cây Thứ 2",
			"Cây Thứ 3",
			"Cây Thứ 4",
			"Cây Thứ 5",
			"Cây Thứ 6",
			"Cây Thứ 7",
			"Cây Thứ 8",
			"Cây Thứ 9",
			"Cây Thứ 10",
			"Cây Thứ 11"
		});
		this.cboThuHoach.Location = new global::System.Drawing.Point(101, 105);
		this.cboThuHoach.Name = "cboThuHoach";
		this.cboThuHoach.Size = new global::System.Drawing.Size(77, 21);
		this.cboThuHoach.TabIndex = 229;
		this.cboThuHoach.SelectedIndexChanged += new global::System.EventHandler(this.cboThuHoach_SelectedIndexChanged);
		this.groupBox25.Controls.Add(this.button15);
		this.groupBox25.Controls.Add(this.cboTiemNang);
		this.groupBox25.Controls.Add(this.nudTangTiemNang);
		this.groupBox25.Location = new global::System.Drawing.Point(205, 55);
		this.groupBox25.Name = "groupBox25";
		this.groupBox25.Size = new global::System.Drawing.Size(151, 40);
		this.groupBox25.TabIndex = 249;
		this.groupBox25.TabStop = false;
		this.groupBox25.Text = "+ Điểm Tiềm Năng";
		this.button15.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.button15.Location = new global::System.Drawing.Point(122, 16);
		this.button15.Name = "button15";
		this.button15.Size = new global::System.Drawing.Size(26, 21);
		this.button15.TabIndex = 0;
		this.button15.Text = "+";
		this.button15.UseVisualStyleBackColor = true;
		this.button15.Click += new global::System.EventHandler(this.button15_Click);
		this.cboTiemNang.Dock = global::System.Windows.Forms.DockStyle.Left;
		this.cboTiemNang.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboTiemNang.FormattingEnabled = true;
		this.cboTiemNang.Items.AddRange(new object[]
		{
			"Thể Lực",
			"Thân Pháp",
			"Nội Lực",
			"Cường Lực",
			"Trí Lực"
		});
		this.cboTiemNang.Location = new global::System.Drawing.Point(47, 16);
		this.cboTiemNang.Name = "cboTiemNang";
		this.cboTiemNang.Size = new global::System.Drawing.Size(75, 21);
		this.cboTiemNang.TabIndex = 243;
		this.cboTrongTrot.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboTrongTrot.FormattingEnabled = true;
		this.cboTrongTrot.Items.AddRange(new object[]
		{
			"Sớm",
			"Muộn"
		});
		this.cboTrongTrot.Location = new global::System.Drawing.Point(10, 105);
		this.cboTrongTrot.Name = "cboTrongTrot";
		this.cboTrongTrot.Size = new global::System.Drawing.Size(77, 21);
		this.cboTrongTrot.TabIndex = 228;
		this.cboTrongTrot.SelectedIndexChanged += new global::System.EventHandler(this.cboTrongTrot_SelectedIndexChanged);
		this.cboXuatPet.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboXuatPet.FormattingEnabled = true;
		this.cboXuatPet.Location = new global::System.Drawing.Point(79, 33);
		this.cboXuatPet.Name = "cboXuatPet";
		this.cboXuatPet.Size = new global::System.Drawing.Size(113, 21);
		this.cboXuatPet.TabIndex = 0;
		this.cboXuatPet.SelectedIndexChanged += new global::System.EventHandler(this.cboXuatPet_SelectedIndexChanged);
		this.btnOpenPass2.Location = new global::System.Drawing.Point(296, 31);
		this.btnOpenPass2.Name = "btnOpenPass2";
		this.btnOpenPass2.Size = new global::System.Drawing.Size(60, 23);
		this.btnOpenPass2.TabIndex = 215;
		this.btnOpenPass2.Text = "Lưu";
		this.btnOpenPass2.UseVisualStyleBackColor = true;
		this.btnOpenPass2.Click += new global::System.EventHandler(this.btnOpenPass2_Click);
		this.label3.AutoSize = true;
		this.label3.Location = new global::System.Drawing.Point(7, 247);
		this.label3.Name = "label3";
		this.label3.Size = new global::System.Drawing.Size(0, 13);
		this.label3.TabIndex = 213;
		this.txtPass2.Location = new global::System.Drawing.Point(198, 33);
		this.txtPass2.Name = "txtPass2";
		this.txtPass2.Size = new global::System.Drawing.Size(92, 20);
		this.txtPass2.TabIndex = 214;
		this.txtPass2.String_0 = "Pass2";
		this.txtPass2.Color_0 = global::System.Drawing.Color.Gray;
		this.txtPass2.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtPass2.Color_1 = global::System.Drawing.Color.LightGray;
		this.button4.Location = new global::System.Drawing.Point(268, 5);
		this.button4.Name = "button4";
		this.button4.Size = new global::System.Drawing.Size(59, 23);
		this.button4.TabIndex = 243;
		this.button4.Text = "Get";
		this.button4.UseVisualStyleBackColor = true;
		this.button4.Click += new global::System.EventHandler(this.button4_Click);
		this.btnTalkChannel.Location = new global::System.Drawing.Point(333, 5);
		this.btnTalkChannel.Name = "btnTalkChannel";
		this.btnTalkChannel.Size = new global::System.Drawing.Size(23, 23);
		this.btnTalkChannel.TabIndex = 182;
		this.btnTalkChannel.Text = "+";
		this.btnTalkChannel.UseVisualStyleBackColor = true;
		this.btnTalkChannel.Click += new global::System.EventHandler(this.btnTalkChannel_Click);
		this.tabKey.Controls.Add(this.tableLayoutPanel1);
		this.tabKey.Location = new global::System.Drawing.Point(4, 4);
		this.tabKey.Name = "tabKey";
		this.tabKey.Size = new global::System.Drawing.Size(362, 203);
		this.tabKey.TabIndex = 2;
		this.tabKey.Text = "Key";
		this.tabKey.UseVisualStyleBackColor = true;
		this.tableLayoutPanel1.ColumnCount = 2;
		this.tableLayoutPanel1.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 53f));
		this.tableLayoutPanel1.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 47f));
		this.tableLayoutPanel1.Controls.Add(this.lvConfig, 1, 0);
		this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 0);
		this.tableLayoutPanel1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tableLayoutPanel1.Location = new global::System.Drawing.Point(0, 0);
		this.tableLayoutPanel1.Name = "tableLayoutPanel1";
		this.tableLayoutPanel1.RowCount = 1;
		this.tableLayoutPanel1.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
		this.tableLayoutPanel1.Size = new global::System.Drawing.Size(362, 203);
		this.tableLayoutPanel1.TabIndex = 10;
		this.lvConfig.AllowColumnReorder = true;
		this.lvConfig.AllowDrop = true;
		this.lvConfig.AllowReorder = true;
		this.lvConfig.AllowSort = false;
		this.lvConfig.CheckBoxes = true;
		this.lvConfig.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_8,
			this.columnHeader_9
		});
		this.lvConfig.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.lvConfig.DoubleClickActivation = false;
		this.lvConfig.FullRowSelect = true;
		this.lvConfig.GridLines = true;
		this.lvConfig.hideItems = null;
		this.lvConfig.HideSelection = false;
		listViewItem.StateImageIndex = 0;
		listViewItem2.StateImageIndex = 0;
		listViewItem3.StateImageIndex = 0;
		listViewItem4.StateImageIndex = 0;
		listViewItem5.StateImageIndex = 0;
		listViewItem6.StateImageIndex = 0;
		listViewItem7.StateImageIndex = 0;
		listViewItem8.StateImageIndex = 0;
		listViewItem9.StateImageIndex = 0;
		listViewItem10.StateImageIndex = 0;
		listViewItem11.StateImageIndex = 0;
		listViewItem12.StateImageIndex = 0;
		listViewItem13.StateImageIndex = 0;
		listViewItem14.StateImageIndex = 0;
		listViewItem15.StateImageIndex = 0;
		listViewItem16.StateImageIndex = 0;
		listViewItem17.StateImageIndex = 0;
		listViewItem18.StateImageIndex = 0;
		listViewItem19.StateImageIndex = 0;
		listViewItem20.StateImageIndex = 0;
		listViewItem21.StateImageIndex = 0;
		listViewItem22.StateImageIndex = 0;
		listViewItem23.StateImageIndex = 0;
		listViewItem24.StateImageIndex = 0;
		listViewItem25.StateImageIndex = 0;
		listViewItem26.StateImageIndex = 0;
		listViewItem27.StateImageIndex = 0;
		listViewItem28.StateImageIndex = 0;
		this.lvConfig.Items.AddRange(new global::System.Windows.Forms.ListViewItem[]
		{
			listViewItem,
			listViewItem2,
			listViewItem3,
			listViewItem4,
			listViewItem5,
			listViewItem6,
			listViewItem7,
			listViewItem8,
			listViewItem9,
			listViewItem10,
			listViewItem11,
			listViewItem12,
			listViewItem13,
			listViewItem14,
			listViewItem15,
			listViewItem16,
			listViewItem17,
			listViewItem18,
			listViewItem19,
			listViewItem20,
			listViewItem21,
			listViewItem22,
			listViewItem23,
			listViewItem24,
			listViewItem25,
			listViewItem26,
			listViewItem27,
			listViewItem28
		});
		this.lvConfig.LineColor = global::System.Drawing.Color.Red;
		this.lvConfig.Location = new global::System.Drawing.Point(194, 3);
		this.lvConfig.Name = "lvConfig";
		this.lvConfig.Size = new global::System.Drawing.Size(165, 197);
		this.lvConfig.TabIndex = 0;
		this.lvConfig.UseCompatibleStateImageBehavior = false;
		this.lvConfig.View = global::System.Windows.Forms.View.Details;
		this.lvConfig.ItemChecked += new global::System.Windows.Forms.ItemCheckedEventHandler(this.lvConfig_ItemChecked);
		this.columnHeader_8.Text = "Name";
		this.columnHeader_8.Width = 100;
		this.columnHeader_9.Text = "Value";
		this.columnHeader_9.Width = 40;
		this.panel5.Controls.Add(this.listViewSkill);
		this.panel5.Controls.Add(this.txtSearchName);
		this.panel5.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panel5.Location = new global::System.Drawing.Point(3, 3);
		this.panel5.Name = "panel5";
		this.panel5.Size = new global::System.Drawing.Size(185, 197);
		this.panel5.TabIndex = 0;
		this.listViewSkill.CheckBoxes = true;
		this.listViewSkill.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_6,
			this.columnHeader_7
		});
		this.listViewSkill.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewSkill.FullRowSelect = true;
		this.listViewSkill.GridLines = true;
		this.listViewSkill.HideSelection = false;
		this.listViewSkill.Location = new global::System.Drawing.Point(0, 20);
		this.listViewSkill.Name = "listViewSkill";
		this.listViewSkill.Size = new global::System.Drawing.Size(185, 177);
		this.listViewSkill.TabIndex = 1;
		this.listViewSkill.UseCompatibleStateImageBehavior = false;
		this.listViewSkill.View = global::System.Windows.Forms.View.Details;
		this.listViewSkill.ItemChecked += new global::System.Windows.Forms.ItemCheckedEventHandler(this.listViewSkill_ItemChecked);
		this.listViewSkill.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.listViewSkill_MouseDown);
		this.columnHeader_6.Text = "Name";
		this.columnHeader_6.Width = 120;
		this.columnHeader_7.Text = "PK";
		this.columnHeader_7.Width = 40;
		this.txtSearchName.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.txtSearchName.Location = new global::System.Drawing.Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new global::System.Drawing.Size(185, 20);
		this.txtSearchName.TabIndex = 9;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = global::System.Drawing.Color.Gray;
		this.txtSearchName.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtSearchName.TextChanged += new global::System.EventHandler(this.txtSearchName_TextChanged);
		this.tabQuest.Controls.Add(this.btnCanQuetThuCong);
		this.tabQuest.Controls.Add(this.chkBanRac);
		this.tabQuest.Controls.Add(this.button17);
		this.tabQuest.Controls.Add(this.chkBinhThanh);
		this.tabQuest.Controls.Add(this.chkKho);
		this.tabQuest.Controls.Add(this.chkPhieuMieuPhong);
		this.tabQuest.Controls.Add(this.chkTamThan);
		this.tabQuest.Controls.Add(this.chkYenTuO);
		this.tabQuest.Controls.Add(this.chkQLauLan);
		this.tabQuest.Controls.Add(this.chkPhucDia);
		this.tabQuest.Controls.Add(this.chkSatTinh);
		this.tabQuest.Controls.Add(this.chkHuyetChien);
		this.tabQuest.Controls.Add(this.chkPDKho);
		this.tabQuest.Controls.Add(this.chkTuTuyetTrang);
		this.tabQuest.Controls.Add(this.chkQToChau);
		this.tabQuest.Controls.Add(this.chkVuongLang);
		this.tabQuest.Controls.Add(this.chkThieuThatSon);
		this.tabQuest.Location = new global::System.Drawing.Point(4, 4);
		this.tabQuest.Name = "tabQuest";
		this.tabQuest.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabQuest.Size = new global::System.Drawing.Size(362, 203);
		this.tabQuest.TabIndex = 11;
		this.tabQuest.Text = "Quest";
		this.tabQuest.UseVisualStyleBackColor = true;
		this.btnCanQuetThuCong.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.btnCanQuetThuCong.Location = new global::System.Drawing.Point(3, 177);
		this.btnCanQuetThuCong.Name = "btnCanQuetThuCong";
		this.btnCanQuetThuCong.Size = new global::System.Drawing.Size(356, 23);
		this.btnCanQuetThuCong.TabIndex = 277;
		this.btnCanQuetThuCong.Text = "Càn Quét [00:00]";
		this.btnCanQuetThuCong.UseVisualStyleBackColor = true;
		this.btnCanQuetThuCong.Click += new global::System.EventHandler(this.btnCanQuetThuCong_Click);
		this.button17.Location = new global::System.Drawing.Point(151, 6);
		this.button17.Name = "button17";
		this.button17.Size = new global::System.Drawing.Size(23, 23);
		this.button17.TabIndex = 247;
		this.button17.Text = "+";
		this.button17.UseVisualStyleBackColor = true;
		this.button17.Click += new global::System.EventHandler(this.button17_Click);
		this.tabCraft.Controls.Add(this.splitContainer7);
		this.tabCraft.Controls.Add(this.chkStartCraft);
		this.tabCraft.Controls.Add(this.chkMuaNguyenLieu);
		this.tabCraft.Controls.Add(this.chkGiamDinh);
		this.tabCraft.Location = new global::System.Drawing.Point(4, 4);
		this.tabCraft.Name = "tabCraft";
		this.tabCraft.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabCraft.Size = new global::System.Drawing.Size(362, 203);
		this.tabCraft.TabIndex = 13;
		this.tabCraft.Text = "Craft";
		this.tabCraft.UseVisualStyleBackColor = true;
		this.splitContainer7.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.splitContainer7.Location = new global::System.Drawing.Point(3, 3);
		this.splitContainer7.Name = "splitContainer7";
		this.splitContainer7.Panel1.Controls.Add(this.groupBox1);
		this.splitContainer7.Panel1.Controls.Add(this.groupBox3);
		this.splitContainer7.Panel2.Controls.Add(this.groupBox2);
		this.splitContainer7.Panel2.Controls.Add(this.groupBox15);
		this.splitContainer7.Size = new global::System.Drawing.Size(356, 153);
		this.splitContainer7.SplitterDistance = 187;
		this.splitContainer7.TabIndex = 23;
		this.groupBox1.Controls.Add(this.chkAutoDropCraft);
		this.groupBox1.Controls.Add(this.nudStar);
		this.groupBox1.Controls.Add(this.label24);
		this.groupBox1.Controls.Add(this.nudLine);
		this.groupBox1.Controls.Add(this.label23);
		this.groupBox1.Controls.Add(this.nudPoint);
		this.groupBox1.Controls.Add(this.label22);
		this.groupBox1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.groupBox1.Location = new global::System.Drawing.Point(0, 40);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new global::System.Drawing.Size(187, 113);
		this.groupBox1.TabIndex = 20;
		this.groupBox1.TabStop = false;
		this.label24.AutoSize = true;
		this.label24.Location = new global::System.Drawing.Point(145, 13);
		this.label24.Name = "label24";
		this.label24.Size = new global::System.Drawing.Size(26, 13);
		this.label24.TabIndex = 9;
		this.label24.Text = "Sao";
		this.label23.AutoSize = true;
		this.label23.Location = new global::System.Drawing.Point(145, 39);
		this.label23.Name = "label23";
		this.label23.Size = new global::System.Drawing.Size(33, 13);
		this.label23.TabIndex = 11;
		this.label23.Text = "Dòng";
		this.label22.AutoSize = true;
		this.label22.Location = new global::System.Drawing.Point(145, 65);
		this.label22.Name = "label22";
		this.label22.Size = new global::System.Drawing.Size(43, 13);
		this.label22.TabIndex = 13;
		this.label22.Text = "Thể lực";
		this.groupBox3.Controls.Add(this.cboLoai);
		this.groupBox3.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.groupBox3.Location = new global::System.Drawing.Point(0, 0);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new global::System.Drawing.Size(187, 40);
		this.groupBox3.TabIndex = 21;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "Loại";
		this.cboLoai.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.cboLoai.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboLoai.FormattingEnabled = true;
		this.cboLoai.Items.AddRange(new object[]
		{
			"Đao phủ",
			"Thương bổng",
			"Đơn đoản",
			"Song đoản",
			"Phiến",
			"Hoàn",
			"Mão",
			"Y phục",
			"Hộ thủ",
			"Hài",
			"Hộ uyển",
			"Hộ kiên",
			"Yêu đái",
			"Hạng liên",
			"Giới chỉ",
			"Hộ phù"
		});
		this.cboLoai.Location = new global::System.Drawing.Point(3, 16);
		this.cboLoai.Name = "cboLoai";
		this.cboLoai.Size = new global::System.Drawing.Size(181, 21);
		this.cboLoai.TabIndex = 4;
		this.cboLoai.SelectedIndexChanged += new global::System.EventHandler(this.cboLoai_SelectedIndexChanged);
		this.groupBox2.Controls.Add(this.radNgoai);
		this.groupBox2.Controls.Add(this.radNoiNgoai);
		this.groupBox2.Controls.Add(this.radNoi);
		this.groupBox2.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.groupBox2.Location = new global::System.Drawing.Point(0, 40);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new global::System.Drawing.Size(165, 113);
		this.groupBox2.TabIndex = 14;
		this.groupBox2.TabStop = false;
		this.radNgoai.AutoSize = true;
		this.radNgoai.Location = new global::System.Drawing.Point(8, 61);
		this.radNgoai.Name = "radNgoai";
		this.radNgoai.Size = new global::System.Drawing.Size(53, 17);
		this.radNgoai.TabIndex = 5;
		this.radNgoai.Text = "Ngoại";
		this.radNgoai.UseVisualStyleBackColor = true;
		this.radNgoai.CheckedChanged += new global::System.EventHandler(this.radNgoai_CheckedChanged);
		this.radNoiNgoai.AutoSize = true;
		this.radNoiNgoai.Location = new global::System.Drawing.Point(8, 38);
		this.radNoiNgoai.Name = "radNoiNgoai";
		this.radNoiNgoai.Size = new global::System.Drawing.Size(81, 17);
		this.radNoiNgoai.TabIndex = 4;
		this.radNoiNgoai.Text = "Nội + Ngoại";
		this.radNoiNgoai.UseVisualStyleBackColor = true;
		this.radNoiNgoai.CheckedChanged += new global::System.EventHandler(this.radNoiNgoai_CheckedChanged);
		this.radNoi.AutoSize = true;
		this.radNoi.Checked = true;
		this.radNoi.Location = new global::System.Drawing.Point(8, 15);
		this.radNoi.Name = "radNoi";
		this.radNoi.Size = new global::System.Drawing.Size(41, 17);
		this.radNoi.TabIndex = 3;
		this.radNoi.TabStop = true;
		this.radNoi.Text = "Nội";
		this.radNoi.UseVisualStyleBackColor = true;
		this.radNoi.CheckedChanged += new global::System.EventHandler(this.radNoi_CheckedChanged);
		this.groupBox15.Controls.Add(this.cboCap);
		this.groupBox15.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.groupBox15.Location = new global::System.Drawing.Point(0, 0);
		this.groupBox15.Name = "groupBox15";
		this.groupBox15.Size = new global::System.Drawing.Size(165, 40);
		this.groupBox15.TabIndex = 22;
		this.groupBox15.TabStop = false;
		this.groupBox15.Text = "Cấp";
		this.cboCap.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.cboCap.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboCap.FormattingEnabled = true;
		this.cboCap.Items.AddRange(new object[]
		{
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"10",
			"11"
		});
		this.cboCap.Location = new global::System.Drawing.Point(3, 16);
		this.cboCap.Name = "cboCap";
		this.cboCap.Size = new global::System.Drawing.Size(159, 21);
		this.cboCap.TabIndex = 6;
		this.cboCap.SelectedIndexChanged += new global::System.EventHandler(this.cboCap_SelectedIndexChanged);
		this.tabSwitch.Location = new global::System.Drawing.Point(4, 4);
		this.tabSwitch.Name = "tabSwitch";
		this.tabSwitch.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabSwitch.Size = new global::System.Drawing.Size(362, 203);
		this.tabSwitch.TabIndex = 15;
		this.tabSwitch.Text = "<>";
		this.tabSwitch.UseVisualStyleBackColor = true;
		this.tabCanQuet.Controls.Add(this.tabCloseXanQuet);
		this.tabCanQuet.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tabCanQuet.Location = new global::System.Drawing.Point(0, 0);
		this.tabCanQuet.Name = "tabCanQuet";
		this.tabCanQuet.SelectedIndex = 0;
		this.tabCanQuet.Size = new global::System.Drawing.Size(370, 229);
		this.tabCanQuet.TabIndex = 278;
		this.tabCanQuet.Visible = false;
		this.tabCanQuet.Selecting += new global::System.Windows.Forms.TabControlCancelEventHandler(this.tabCanQuet_Selecting);
		this.tabCanQuet.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.tabCanQuet_MouseClick);
		this.tabCloseXanQuet.Location = new global::System.Drawing.Point(4, 4);
		this.tabCloseXanQuet.Margin = new global::System.Windows.Forms.Padding(0);
		this.tabCloseXanQuet.Name = "tabCloseXanQuet";
		this.tabCloseXanQuet.Size = new global::System.Drawing.Size(362, 203);
		this.tabCloseXanQuet.TabIndex = 0;
		this.tabCloseXanQuet.Text = "x";
		this.tabCloseXanQuet.UseVisualStyleBackColor = true;
		this.tabLogin.Location = new global::System.Drawing.Point(4, 22);
		this.tabLogin.Name = "tabLogin";
		this.tabLogin.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabLogin.Size = new global::System.Drawing.Size(376, 471);
		this.tabLogin.TabIndex = 4;
		this.tabLogin.Text = "Login";
		this.tabLogin.UseVisualStyleBackColor = true;
		this.tabSetting.Location = new global::System.Drawing.Point(4, 22);
		this.tabSetting.Name = "tabSetting";
		this.tabSetting.Size = new global::System.Drawing.Size(376, 471);
		this.tabSetting.TabIndex = 5;
		this.tabSetting.Text = "Setting";
		this.tabSetting.UseVisualStyleBackColor = true;
		this.tabChat.Controls.Add(this.tabControlEx1);
		this.tabChat.Location = new global::System.Drawing.Point(4, 22);
		this.tabChat.Name = "tabChat";
		this.tabChat.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabChat.Size = new global::System.Drawing.Size(376, 471);
		this.tabChat.TabIndex = 1;
		this.tabChat.Text = "Inbox";
		this.tabChat.UseVisualStyleBackColor = true;
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Controls.Add(this.tabPage3);
		this.tabControlEx1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tabControlEx1.Location = new global::System.Drawing.Point(3, 3);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new global::System.Drawing.Size(370, 465);
		this.tabControlEx1.TabIndex = 1;
		this.tabPage2.Controls.Add(this.ricChat);
		this.tabPage2.Controls.Add(this.textBoxEx2);
		this.tabPage2.Controls.Add(this.panel4);
		this.tabPage2.Location = new global::System.Drawing.Point(4, 4);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage2.Size = new global::System.Drawing.Size(362, 439);
		this.tabPage2.TabIndex = 0;
		this.tabPage2.Text = "Auto";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.ricChat.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.ricChat.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.ricChat.Location = new global::System.Drawing.Point(3, 21);
		this.ricChat.Name = "ricChat";
		this.ricChat.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
		this.ricChat.Size = new global::System.Drawing.Size(356, 395);
		this.ricChat.TabIndex = 2;
		this.ricChat.Text = "";
		this.textBoxEx2.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.textBoxEx2.Location = new global::System.Drawing.Point(3, 416);
		this.textBoxEx2.Name = "textBoxEx2";
		this.textBoxEx2.Size = new global::System.Drawing.Size(356, 20);
		this.textBoxEx2.TabIndex = 1;
		this.textBoxEx2.String_0 = "Chat...";
		this.textBoxEx2.Color_0 = global::System.Drawing.Color.Gray;
		this.textBoxEx2.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.textBoxEx2.Color_1 = global::System.Drawing.Color.LightGray;
		this.textBoxEx2.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.textBoxEx2_KeyDown);
		this.panel4.Controls.Add(this.label7);
		this.panel4.Controls.Add(this.label5);
		this.panel4.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.panel4.Location = new global::System.Drawing.Point(3, 3);
		this.panel4.Name = "panel4";
		this.panel4.Size = new global::System.Drawing.Size(356, 18);
		this.panel4.TabIndex = 7;
		this.label7.BackColor = global::System.Drawing.Color.Gainsboro;
		this.label7.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.label7.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label7.Location = new global::System.Drawing.Point(0, 0);
		this.label7.Name = "label7";
		this.label7.Size = new global::System.Drawing.Size(310, 18);
		this.label7.TabIndex = 4;
		this.label7.Text = "^";
		this.label7.TextAlign = global::System.Drawing.ContentAlignment.BottomCenter;
		this.label7.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.label7_MouseClick);
		this.label5.BackColor = global::System.Drawing.Color.Green;
		this.label5.Dock = global::System.Windows.Forms.DockStyle.Right;
		this.label5.Location = new global::System.Drawing.Point(310, 0);
		this.label5.Name = "label5";
		this.label5.Size = new global::System.Drawing.Size(46, 18);
		this.label5.TabIndex = 6;
		this.label5.Text = "Ting";
		this.label5.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.label5.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.label5_MouseClick);
		this.tabPage3.Controls.Add(this.panInbox);
		this.tabPage3.Location = new global::System.Drawing.Point(4, 4);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage3.Size = new global::System.Drawing.Size(362, 439);
		this.tabPage3.TabIndex = 1;
		this.tabPage3.Text = "Game";
		this.tabPage3.UseVisualStyleBackColor = true;
		this.panInbox.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panInbox.Location = new global::System.Drawing.Point(3, 3);
		this.panInbox.Name = "panInbox";
		this.panInbox.Size = new global::System.Drawing.Size(356, 433);
		this.panInbox.TabIndex = 0;
		this.tabUser.Controls.Add(this.picBank);
		this.tabUser.Controls.Add(this.button1);
		this.tabUser.Controls.Add(this.lblBeli);
		this.tabUser.Location = new global::System.Drawing.Point(4, 22);
		this.tabUser.Name = "tabUser";
		this.tabUser.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabUser.Size = new global::System.Drawing.Size(376, 471);
		this.tabUser.TabIndex = 3;
		this.tabUser.Text = "User";
		this.tabUser.UseVisualStyleBackColor = true;
		this.picBank.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.picBank.Location = new global::System.Drawing.Point(3, 49);
		this.picBank.Name = "picBank";
		this.picBank.Size = new global::System.Drawing.Size(370, 419);
		this.picBank.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.picBank.TabIndex = 2;
		this.picBank.TabStop = false;
		this.button1.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.button1.Location = new global::System.Drawing.Point(3, 26);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(370, 23);
		this.button1.TabIndex = 1;
		this.button1.Text = "Cập Nhập Số Dư";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.lblBeli.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.lblBeli.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 163);
		this.lblBeli.Location = new global::System.Drawing.Point(3, 3);
		this.lblBeli.Name = "lblBeli";
		this.lblBeli.Size = new global::System.Drawing.Size(370, 23);
		this.lblBeli.TabIndex = 0;
		this.lblBeli.Text = "100.000 Beli";
		this.lblBeli.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.tabLog.Controls.Add(this.groupBox27);
		this.tabLog.Controls.Add(this.groupBox29);
		this.tabLog.Controls.Add(this.groupBox28);
		this.tabLog.Controls.Add(this.groupBox26);
		this.tabLog.Location = new global::System.Drawing.Point(4, 22);
		this.tabLog.Name = "tabLog";
		this.tabLog.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabLog.Size = new global::System.Drawing.Size(376, 471);
		this.tabLog.TabIndex = 2;
		this.tabLog.Text = "Log";
		this.tabLog.UseVisualStyleBackColor = true;
		this.tabLog.Click += new global::System.EventHandler(this.tabLog_Click);
		this.groupBox27.Controls.Add(this.ricExit);
		this.groupBox27.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.groupBox27.Location = new global::System.Drawing.Point(3, 3);
		this.groupBox27.Name = "groupBox27";
		this.groupBox27.Size = new global::System.Drawing.Size(370, 201);
		this.groupBox27.TabIndex = 5;
		this.groupBox27.TabStop = false;
		this.groupBox27.Text = "Thoát";
		this.ricExit.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.ricExit.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.ricExit.Location = new global::System.Drawing.Point(3, 16);
		this.ricExit.Name = "ricExit";
		this.ricExit.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
		this.ricExit.Size = new global::System.Drawing.Size(364, 182);
		this.ricExit.TabIndex = 4;
		this.ricExit.Text = "";
		this.groupBox29.Controls.Add(this.ricXong);
		this.groupBox29.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.groupBox29.Location = new global::System.Drawing.Point(3, 204);
		this.groupBox29.Name = "groupBox29";
		this.groupBox29.Size = new global::System.Drawing.Size(370, 88);
		this.groupBox29.TabIndex = 6;
		this.groupBox29.TabStop = false;
		this.groupBox29.Text = "Xong";
		this.ricXong.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.ricXong.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.ricXong.Location = new global::System.Drawing.Point(3, 16);
		this.ricXong.Name = "ricXong";
		this.ricXong.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
		this.ricXong.Size = new global::System.Drawing.Size(364, 69);
		this.ricXong.TabIndex = 4;
		this.ricXong.Text = "";
		this.groupBox28.Controls.Add(this.ricMaTac);
		this.groupBox28.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.groupBox28.Location = new global::System.Drawing.Point(3, 292);
		this.groupBox28.Name = "groupBox28";
		this.groupBox28.Size = new global::System.Drawing.Size(370, 88);
		this.groupBox28.TabIndex = 5;
		this.groupBox28.TabStop = false;
		this.groupBox28.Text = "Mã Tặc";
		this.ricMaTac.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.ricMaTac.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.ricMaTac.Location = new global::System.Drawing.Point(3, 16);
		this.ricMaTac.Name = "ricMaTac";
		this.ricMaTac.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
		this.ricMaTac.Size = new global::System.Drawing.Size(364, 69);
		this.ricMaTac.TabIndex = 4;
		this.ricMaTac.Text = "";
		this.groupBox26.Controls.Add(this.ricAcBa);
		this.groupBox26.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.groupBox26.Location = new global::System.Drawing.Point(3, 380);
		this.groupBox26.Name = "groupBox26";
		this.groupBox26.Size = new global::System.Drawing.Size(370, 88);
		this.groupBox26.TabIndex = 4;
		this.groupBox26.TabStop = false;
		this.groupBox26.Text = "Ác Bá";
		this.ricAcBa.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.ricAcBa.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.ricAcBa.Location = new global::System.Drawing.Point(3, 16);
		this.ricAcBa.Name = "ricAcBa";
		this.ricAcBa.ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
		this.ricAcBa.Size = new global::System.Drawing.Size(364, 69);
		this.ricAcBa.TabIndex = 4;
		this.ricAcBa.Text = "";
		this.columnHeader_23.Tag = "Phái";
		this.columnHeader_23.Text = "Phái";
		this.tabPage1.Location = new global::System.Drawing.Point(0, 0);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage1.Size = new global::System.Drawing.Size(200, 100);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "tabPage1";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(384, 521);
		base.Controls.Add(this.Container);
		base.Controls.Add(this.mainMenu);
		base.Name = "Main";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "MicroAuto 40.5.0";
		base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
		base.Load += new global::System.EventHandler(this.Main_Load);
		base.Move += new global::System.EventHandler(this.Main_Move);
		base.Resize += new global::System.EventHandler(this.Main_Resize);
		this.menuIcon.ResumeLayout(false);
		this.menuListView.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.nudBuffPet).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudNM).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRadius).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudHP).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudMP).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.numberThuHoaX).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.numberRadiusThuHoa).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudTangTiemNang).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudStar).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudLine).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudPoint).EndInit();
		this.mainMenu.ResumeLayout(false);
		this.mainMenu.PerformLayout();
		this.Container.ResumeLayout(false);
		this.tab.ResumeLayout(false);
		this.tabGame.ResumeLayout(false);
		this.panMain.ResumeLayout(false);
		this.panTop.ResumeLayout(false);
		this.panel3.ResumeLayout(false);
		this.panel3.PerformLayout();
		this.panBottom.ResumeLayout(false);
		this.tabBottom.ResumeLayout(false);
		this.tabBuff.ResumeLayout(false);
		this.tabBuff.PerformLayout();
		this.flowLayoutPanel1.ResumeLayout(false);
		this.tabLife.ResumeLayout(false);
		this.tabLife.PerformLayout();
		this.groupBox23.ResumeLayout(false);
		this.groupBox23.PerformLayout();
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
		this.splitContainer1.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.numberGiaKNB).EndInit();
		this.groupBox25.ResumeLayout(false);
		this.tabKey.ResumeLayout(false);
		this.tableLayoutPanel1.ResumeLayout(false);
		this.panel5.ResumeLayout(false);
		this.panel5.PerformLayout();
		this.tabQuest.ResumeLayout(false);
		this.tabQuest.PerformLayout();
		this.tabCraft.ResumeLayout(false);
		this.tabCraft.PerformLayout();
		this.splitContainer7.Panel1.ResumeLayout(false);
		this.splitContainer7.Panel2.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.splitContainer7).EndInit();
		this.splitContainer7.ResumeLayout(false);
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		this.groupBox3.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		this.groupBox15.ResumeLayout(false);
		this.tabCanQuet.ResumeLayout(false);
		this.tabChat.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage2.ResumeLayout(false);
		this.tabPage2.PerformLayout();
		this.panel4.ResumeLayout(false);
		this.tabPage3.ResumeLayout(false);
		this.tabUser.ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.picBank).EndInit();
		this.tabLog.ResumeLayout(false);
		this.groupBox27.ResumeLayout(false);
		this.groupBox29.ResumeLayout(false);
		this.groupBox28.ResumeLayout(false);
		this.groupBox26.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040013FB RID: 5115
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x040013FC RID: 5116
	private global::Control1 tabBottom;

	// Token: 0x040013FD RID: 5117
	private global::System.Windows.Forms.TabPage tabKey;

	// Token: 0x040013FE RID: 5118
	private global::System.Windows.Forms.CheckBox checkLuaQuai;

	// Token: 0x040013FF RID: 5119
	private global::System.Windows.Forms.CheckBox checkTimQuai;

	// Token: 0x04001400 RID: 5120
	private global::System.Windows.Forms.NotifyIcon notifyIcon_0;

	// Token: 0x04001401 RID: 5121
	private global::System.Windows.Forms.ContextMenuStrip menuIcon;

	// Token: 0x04001402 RID: 5122
	private global::System.Windows.Forms.ToolStripMenuItem menuExit;

	// Token: 0x04001403 RID: 5123
	private global::System.Windows.Forms.ContextMenuStrip menuListView;

	// Token: 0x04001404 RID: 5124
	private global::System.Windows.Forms.ToolStripMenuItem menuHideGame;

	// Token: 0x04001405 RID: 5125
	private global::System.Windows.Forms.ToolStripMenuItem menuShowGame;

	// Token: 0x04001406 RID: 5126
	private global::System.Windows.Forms.ToolStripMenuItem menuExitGame;

	// Token: 0x04001407 RID: 5127
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04001408 RID: 5128
	private global::System.Windows.Forms.Timer timer_1;

	// Token: 0x04001409 RID: 5129
	private global::System.Windows.Forms.ToolStripMenuItem menuDebug;

	// Token: 0x0400140A RID: 5130
	private global::System.Windows.Forms.ComboBox cboThuHoach;

	// Token: 0x0400140B RID: 5131
	private global::System.Windows.Forms.ComboBox cboTrongTrot;

	// Token: 0x0400140C RID: 5132
	private global::System.Windows.Forms.CheckBox checkKhaiKhoang;

	// Token: 0x0400140D RID: 5133
	private global::System.Windows.Forms.CheckBox checkHaiDuoc;

	// Token: 0x0400140E RID: 5134
	private global::System.Windows.Forms.CheckBox checkTrongTrot;

	// Token: 0x0400140F RID: 5135
	private global::System.Windows.Forms.CheckBox checkThuHoach;

	// Token: 0x04001410 RID: 5136
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator7;

	// Token: 0x04001411 RID: 5137
	private global::System.Windows.Forms.ToolStripMenuItem menuRefreshAuto;

	// Token: 0x04001412 RID: 5138
	private global::System.Windows.Forms.ToolStripMenuItem menuResetTime;

	// Token: 0x04001413 RID: 5139
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator9;

	// Token: 0x04001414 RID: 5140
	private global::System.Windows.Forms.ToolTip toolTip_0;

	// Token: 0x04001415 RID: 5141
	private global::System.Windows.Forms.Timer timer_2;

	// Token: 0x04001416 RID: 5142
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x04001417 RID: 5143
	private global::System.Windows.Forms.ColumnHeader columnHeader_1;

	// Token: 0x04001418 RID: 5144
	private global::System.Windows.Forms.ColumnHeader columnHeader_2;

	// Token: 0x04001419 RID: 5145
	private global::System.Windows.Forms.ComboBox cboBaseSkill;

	// Token: 0x0400141A RID: 5146
	private global::System.Windows.Forms.ColumnHeader columnHeader_3;

	// Token: 0x0400141B RID: 5147
	private global::System.Windows.Forms.ColumnHeader columnHeader_4;

	// Token: 0x0400141C RID: 5148
	private global::System.Windows.Forms.ColumnHeader columnHeader_5;

	// Token: 0x0400141D RID: 5149
	private global::System.Windows.Forms.Button btnAdd;

	// Token: 0x0400141E RID: 5150
	public global::System.Windows.Forms.Timer timer_3;

	// Token: 0x0400141F RID: 5151
	private global::System.Windows.Forms.Timer timer_4;

	// Token: 0x04001420 RID: 5152
	private global::System.Windows.Forms.Button btnOnlyAttack;

	// Token: 0x04001421 RID: 5153
	private global::System.Windows.Forms.CheckBox checkChiDanh;

	// Token: 0x04001422 RID: 5154
	private global::System.ComponentModel.BackgroundWorker backgroundWorker_0;

	// Token: 0x04001423 RID: 5155
	private global::System.Windows.Forms.Panel panTop;

	// Token: 0x04001424 RID: 5156
	private global::System.Windows.Forms.Panel panBottom;

	// Token: 0x04001425 RID: 5157
	private global::System.Windows.Forms.Panel panMain;

	// Token: 0x04001426 RID: 5158
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04001427 RID: 5159
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x04001428 RID: 5160
	private global::System.Windows.Forms.GroupBox groupBox1;

	// Token: 0x04001429 RID: 5161
	private global::System.Windows.Forms.CheckBox chkAutoDropCraft;

	// Token: 0x0400142A RID: 5162
	private global::System.Windows.Forms.NumericUpDown nudStar;

	// Token: 0x0400142B RID: 5163
	private global::System.Windows.Forms.Label label24;

	// Token: 0x0400142C RID: 5164
	private global::System.Windows.Forms.NumericUpDown nudLine;

	// Token: 0x0400142D RID: 5165
	private global::System.Windows.Forms.Label label23;

	// Token: 0x0400142E RID: 5166
	private global::System.Windows.Forms.NumericUpDown nudPoint;

	// Token: 0x0400142F RID: 5167
	private global::System.Windows.Forms.Label label22;

	// Token: 0x04001430 RID: 5168
	private global::System.Windows.Forms.CheckBox chkStartCraft;

	// Token: 0x04001431 RID: 5169
	private global::System.Windows.Forms.CheckBox chkMuaNguyenLieu;

	// Token: 0x04001432 RID: 5170
	private global::System.Windows.Forms.CheckBox chkGiamDinh;

	// Token: 0x04001433 RID: 5171
	private global::System.Windows.Forms.GroupBox groupBox2;

	// Token: 0x04001434 RID: 5172
	private global::System.Windows.Forms.RadioButton radNgoai;

	// Token: 0x04001435 RID: 5173
	private global::System.Windows.Forms.RadioButton radNoiNgoai;

	// Token: 0x04001436 RID: 5174
	private global::System.Windows.Forms.RadioButton radNoi;

	// Token: 0x04001437 RID: 5175
	private global::System.Windows.Forms.ComboBox cboCap;

	// Token: 0x04001438 RID: 5176
	private global::System.Windows.Forms.ComboBox cboLoai;

	// Token: 0x04001439 RID: 5177
	private global::System.Windows.Forms.CheckBox checkMuaKNB;

	// Token: 0x0400143A RID: 5178
	private global::System.Windows.Forms.NumericUpDown numberGiaKNB;

	// Token: 0x0400143B RID: 5179
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator38;

	// Token: 0x0400143C RID: 5180
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400143D RID: 5181
	private global::System.ComponentModel.BackgroundWorker backgroundWorker_1;

	// Token: 0x0400143E RID: 5182
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x0400143F RID: 5183
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04001440 RID: 5184
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04001441 RID: 5185
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x04001442 RID: 5186
	private global::System.Windows.Forms.ToolStripMenuItem menuTrieuTapNhom;

	// Token: 0x04001443 RID: 5187
	private global::System.Windows.Forms.ToolStripMenuItem menuMoiDoi;

	// Token: 0x04001444 RID: 5188
	private global::System.Windows.Forms.ToolStripMenuItem menuTrieuTap;

	// Token: 0x04001445 RID: 5189
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator58;

	// Token: 0x04001446 RID: 5190
	private global::System.Windows.Forms.ToolStripMenuItem menuAutoCreateTeam;

	// Token: 0x04001447 RID: 5191
	private global::System.Windows.Forms.ToolStripMenuItem muQuanLyNhom;

	// Token: 0x04001448 RID: 5192
	private global::System.Windows.Forms.ToolStripMenuItem menuCreateTeam;

	// Token: 0x04001449 RID: 5193
	private global::System.Windows.Forms.ToolStripMenuItem menuSetNhom;

	// Token: 0x0400144A RID: 5194
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator3;

	// Token: 0x0400144B RID: 5195
	private global::System.Windows.Forms.ToolStripMenuItem muGiaiTan;

	// Token: 0x0400144C RID: 5196
	private global::System.Windows.Forms.MenuStrip mainMenu;

	// Token: 0x0400144D RID: 5197
	private global::System.Windows.Forms.ToolStripMenuItem playerToolStripMenuItem;

	// Token: 0x0400144E RID: 5198
	private global::System.Windows.Forms.ToolStripMenuItem muTriLieu;

	// Token: 0x0400144F RID: 5199
	private global::System.Windows.Forms.ToolStripMenuItem muDiBanRac;

	// Token: 0x04001450 RID: 5200
	private global::System.Windows.Forms.ToolStripMenuItem muTriLieuBanRacCatDo;

	// Token: 0x04001451 RID: 5201
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator44;

	// Token: 0x04001452 RID: 5202
	private global::System.Windows.Forms.ToolStripMenuItem muPhanGiaiTrangBijPet;

	// Token: 0x04001453 RID: 5203
	private global::System.Windows.Forms.ToolStripMenuItem muNhanDoi;

	// Token: 0x04001454 RID: 5204
	private global::System.Windows.Forms.ToolStripMenuItem leaderToolStripMenuItem;

	// Token: 0x04001455 RID: 5205
	private global::System.Windows.Forms.ToolStripMenuItem muAcTac;

	// Token: 0x04001456 RID: 5206
	private global::System.Windows.Forms.ToolStripMenuItem muVoLuongSon;

	// Token: 0x04001457 RID: 5207
	private global::System.Windows.Forms.ToolStripMenuItem muKinhHo;

	// Token: 0x04001458 RID: 5208
	private global::System.Windows.Forms.ToolStripMenuItem muKiemCac;

	// Token: 0x04001459 RID: 5209
	private global::System.Windows.Forms.ToolStripMenuItem muThaiHo;

	// Token: 0x0400145A RID: 5210
	private global::System.Windows.Forms.ToolStripMenuItem muTungSon;

	// Token: 0x0400145B RID: 5211
	private global::System.Windows.Forms.ToolStripMenuItem muDonHoang;

	// Token: 0x0400145C RID: 5212
	private global::System.Windows.Forms.ToolStripMenuItem muAcBa;

	// Token: 0x0400145D RID: 5213
	private global::System.Windows.Forms.ToolStripMenuItem muTangKinhCac;

	// Token: 0x0400145E RID: 5214
	private global::System.Windows.Forms.ToolStripMenuItem muTayHo;

	// Token: 0x0400145F RID: 5215
	private global::System.Windows.Forms.ToolStripMenuItem muNhiHai;

	// Token: 0x04001460 RID: 5216
	private global::System.Windows.Forms.ToolStripMenuItem muNhanNam;

	// Token: 0x04001461 RID: 5217
	private global::System.Windows.Forms.ToolStripMenuItem muDaTru;

	// Token: 0x04001462 RID: 5218
	private global::System.Windows.Forms.ToolStripMenuItem muKyCuoc;

	// Token: 0x04001463 RID: 5219
	private global::System.Windows.Forms.ToolStripMenuItem muKyCuocNhanh;

	// Token: 0x04001464 RID: 5220
	private global::System.Windows.Forms.ToolStripMenuItem muKyCuocCham;

	// Token: 0x04001465 RID: 5221
	private global::System.Windows.Forms.ToolStripMenuItem muLauLanTamBao;

	// Token: 0x04001466 RID: 5222
	private global::System.Windows.Forms.ToolStripMenuItem muLauLanTamBaoNhanh;

	// Token: 0x04001467 RID: 5223
	private global::System.Windows.Forms.ToolStripMenuItem muLauLanTamBaoCham;

	// Token: 0x04001468 RID: 5224
	private global::System.Windows.Forms.ToolStripMenuItem muMongHeo;

	// Token: 0x04001469 RID: 5225
	private global::System.Windows.Forms.ToolStripMenuItem muThienGiangKyThu;

	// Token: 0x0400146A RID: 5226
	private global::System.Windows.Forms.ToolStripMenuItem muPhungHoangLangMo;

	// Token: 0x0400146B RID: 5227
	private global::System.Windows.Forms.ToolStripMenuItem dailyToolStripMenuItem;

	// Token: 0x0400146C RID: 5228
	private global::System.Windows.Forms.ToolStripMenuItem muHangNgay;

	// Token: 0x0400146D RID: 5229
	private global::System.Windows.Forms.ToolStripMenuItem muToanBoHangNgay;

	// Token: 0x0400146E RID: 5230
	private global::System.Windows.Forms.ToolStripMenuItem muLoLyHoa;

	// Token: 0x0400146F RID: 5231
	private global::System.Windows.Forms.ToolStripMenuItem muNhanPhiThuy;

	// Token: 0x04001470 RID: 5232
	private global::System.Windows.Forms.ToolStripMenuItem muLuyenKim;

	// Token: 0x04001471 RID: 5233
	private global::System.Windows.Forms.ToolStripMenuItem muLuyenKimNhanh;

	// Token: 0x04001472 RID: 5234
	private global::System.Windows.Forms.ToolStripMenuItem muLuyenKimCham;

	// Token: 0x04001473 RID: 5235
	private global::System.Windows.Forms.ToolStripMenuItem muTrungAc;

	// Token: 0x04001474 RID: 5236
	private global::System.Windows.Forms.ToolStripMenuItem muCotTruyen;

	// Token: 0x04001475 RID: 5237
	private global::System.Windows.Forms.ToolStripMenuItem muCotTruyenToanBo;

	// Token: 0x04001476 RID: 5238
	private global::System.Windows.Forms.ToolStripMenuItem muNhiemVuExp;

	// Token: 0x04001477 RID: 5239
	private global::System.Windows.Forms.ToolStripMenuItem muNhiemVuKNB;

	// Token: 0x04001478 RID: 5240
	private global::System.Windows.Forms.ToolStripMenuItem muNgoChanNguyen;

	// Token: 0x04001479 RID: 5241
	private global::System.Windows.Forms.ToolStripMenuItem muChinhTuyen;

	// Token: 0x0400147A RID: 5242
	private global::System.Windows.Forms.ToolStripMenuItem muSuMon;

	// Token: 0x0400147B RID: 5243
	private global::System.Windows.Forms.ToolStripMenuItem muMoBaoTangDo;

	// Token: 0x0400147C RID: 5244
	private global::System.Windows.Forms.ToolStripMenuItem muConCai;

	// Token: 0x0400147D RID: 5245
	private global::System.Windows.Forms.ToolStripMenuItem muTuDuong;

	// Token: 0x0400147E RID: 5246
	private global::System.Windows.Forms.ToolStripMenuItem muPhuMau;

	// Token: 0x0400147F RID: 5247
	private global::System.Windows.Forms.ToolStripMenuItem muNhanCon;

	// Token: 0x04001480 RID: 5248
	private global::System.Windows.Forms.ToolStripMenuItem muTuBaoBon;

	// Token: 0x04001481 RID: 5249
	private global::System.Windows.Forms.ToolStripMenuItem muThienKiepLau;

	// Token: 0x04001482 RID: 5250
	private global::System.Windows.Forms.ToolStripMenuItem muTiemNangTan;

	// Token: 0x04001483 RID: 5251
	private global::System.Windows.Forms.ToolStripMenuItem muBachHoaDuyen;

	// Token: 0x04001484 RID: 5252
	private global::System.Windows.Forms.ToolStripMenuItem muThanhSangNhatHa;

	// Token: 0x04001485 RID: 5253
	private global::System.Windows.Forms.ToolStripMenuItem muSinhTieu;

	// Token: 0x04001486 RID: 5254
	private global::System.Windows.Forms.ToolStripMenuItem menuNier;

	// Token: 0x04001487 RID: 5255
	private global::System.Windows.Forms.ToolStripMenuItem muTopMost;

	// Token: 0x04001488 RID: 5256
	private global::System.Windows.Forms.ToolStripMenuItem openGameToolStripMenuItem1;

	// Token: 0x04001489 RID: 5257
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;

	// Token: 0x0400148A RID: 5258
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem1;

	// Token: 0x0400148B RID: 5259
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem2;

	// Token: 0x0400148C RID: 5260
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem3;

	// Token: 0x0400148D RID: 5261
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem4;

	// Token: 0x0400148E RID: 5262
	private global::System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem5;

	// Token: 0x0400148F RID: 5263
	private global::System.Windows.Forms.ToolStripMenuItem muVanMay;

	// Token: 0x04001490 RID: 5264
	private global::System.Windows.Forms.ToolStripMenuItem muTueHong;

	// Token: 0x04001491 RID: 5265
	private global::System.Windows.Forms.ToolStripMenuItem muNguyenVong;

	// Token: 0x04001492 RID: 5266
	private global::System.Windows.Forms.ToolStripMenuItem muPrivate;

	// Token: 0x04001493 RID: 5267
	private global::System.Windows.Forms.ToolStripMenuItem muQ1ToChau;

	// Token: 0x04001494 RID: 5268
	private global::System.Windows.Forms.ToolStripMenuItem muQ2ToChau;

	// Token: 0x04001495 RID: 5269
	private global::System.Windows.Forms.ToolStripMenuItem muQ12ToChau;

	// Token: 0x04001496 RID: 5270
	private global::System.Windows.Forms.ToolStripMenuItem muThuyLao;

	// Token: 0x04001497 RID: 5271
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator8;

	// Token: 0x04001498 RID: 5272
	private global::System.Windows.Forms.ToolStripMenuItem muNhanx2;

	// Token: 0x04001499 RID: 5273
	private global::System.Windows.Forms.ToolStripMenuItem muDongx2;

	// Token: 0x0400149A RID: 5274
	private global::System.Windows.Forms.ToolStripMenuItem muDiMuaNgua;

	// Token: 0x0400149B RID: 5275
	private global::System.Windows.Forms.ToolStripMenuItem muHuyVatPhamQuy;

	// Token: 0x0400149C RID: 5276
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator18;

	// Token: 0x0400149D RID: 5277
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator34;

	// Token: 0x0400149E RID: 5278
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;

	// Token: 0x0400149F RID: 5279
	private global::System.Windows.Forms.ToolStripMenuItem muCQThuCong;

	// Token: 0x040014A0 RID: 5280
	private global::System.Windows.Forms.ToolStripMenuItem muCQBinhThanhThuCong;

	// Token: 0x040014A1 RID: 5281
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator33;

	// Token: 0x040014A2 RID: 5282
	private global::System.Windows.Forms.ToolStripMenuItem muCQYenTuO;

	// Token: 0x040014A3 RID: 5283
	private global::System.Windows.Forms.ToolStripMenuItem muCQTuTuyetTrang;

	// Token: 0x040014A4 RID: 5284
	private global::System.Windows.Forms.ToolStripMenuItem muCQSatTinh;

	// Token: 0x040014A5 RID: 5285
	private global::System.Windows.Forms.ToolStripMenuItem muCQPhieuMieuPhong;

	// Token: 0x040014A6 RID: 5286
	private global::System.Windows.Forms.ToolStripMenuItem muCQThieuThatSon;

	// Token: 0x040014A7 RID: 5287
	private global::System.Windows.Forms.ToolStripMenuItem muCQBinhThanh;

	// Token: 0x040014A8 RID: 5288
	private global::System.Windows.Forms.ToolStripMenuItem muCQBinhThanhKho;

	// Token: 0x040014A9 RID: 5289
	private global::System.Windows.Forms.ToolStripMenuItem muCQVuongLang;

	// Token: 0x040014AA RID: 5290
	private global::System.Windows.Forms.ToolStripMenuItem muCQTamThan;

	// Token: 0x040014AB RID: 5291
	private global::System.Windows.Forms.ToolStripMenuItem muCQKhieuChienPMP;

	// Token: 0x040014AC RID: 5292
	private global::System.Windows.Forms.ToolStripMenuItem muCQPhucDia;

	// Token: 0x040014AD RID: 5293
	private global::System.Windows.Forms.ToolStripMenuItem muCQPhucDiaKho;

	// Token: 0x040014AE RID: 5294
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;

	// Token: 0x040014AF RID: 5295
	private global::System.Windows.Forms.ToolStripMenuItem muQuayVeDaiLy;

	// Token: 0x040014B0 RID: 5296
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator6;

	// Token: 0x040014B1 RID: 5297
	private global::System.Windows.Forms.ToolStripMenuItem muDemBut;

	// Token: 0x040014B2 RID: 5298
	private global::System.Windows.Forms.ToolStripMenuItem muChucPhuc;

	// Token: 0x040014B3 RID: 5299
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator16;

	// Token: 0x040014B4 RID: 5300
	private global::System.Windows.Forms.ToolStripMenuItem muKetNghia;

	// Token: 0x040014B5 RID: 5301
	private global::System.Windows.Forms.ToolStripMenuItem muChucPhucTuBaoBon;

	// Token: 0x040014B6 RID: 5302
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator26;

	// Token: 0x040014B7 RID: 5303
	private global::System.Windows.Forms.ToolStripMenuItem muAutoMap;

	// Token: 0x040014B8 RID: 5304
	private global::System.Windows.Forms.ToolStripMenuItem muNhapCode;

	// Token: 0x040014B9 RID: 5305
	private global::System.Windows.Forms.Button btnPk;

	// Token: 0x040014BA RID: 5306
	private global::System.Windows.Forms.CheckBox checkTuyenChien;

	// Token: 0x040014BB RID: 5307
	private global::System.Windows.Forms.TabPage tabLife;

	// Token: 0x040014BC RID: 5308
	private global::System.Windows.Forms.CheckBox checkQuyCoc;

	// Token: 0x040014BD RID: 5309
	private global::System.Windows.Forms.CheckBox checkXuatPet;

	// Token: 0x040014BE RID: 5310
	private global::System.Windows.Forms.ComboBox cboXuatPet;

	// Token: 0x040014BF RID: 5311
	private global::System.Windows.Forms.NumericUpDown numericUpDown2;

	// Token: 0x040014C0 RID: 5312
	private global::System.Windows.Forms.Button btnOpenPass2;

	// Token: 0x040014C1 RID: 5313
	private global::System.Windows.Forms.CheckBox checkPet;

	// Token: 0x040014C2 RID: 5314
	private global::System.Windows.Forms.Label label3;

	// Token: 0x040014C3 RID: 5315
	private global::Class85 txtPass2;

	// Token: 0x040014C4 RID: 5316
	private global::System.Windows.Forms.Label lblTrain;

	// Token: 0x040014C5 RID: 5317
	private global::System.Windows.Forms.CheckBox checkHP;

	// Token: 0x040014C6 RID: 5318
	private global::System.Windows.Forms.CheckBox chkRaoVat;

	// Token: 0x040014C7 RID: 5319
	private global::System.Windows.Forms.Button button4;

	// Token: 0x040014C8 RID: 5320
	private global::System.Windows.Forms.NumericUpDown nudNM;

	// Token: 0x040014C9 RID: 5321
	private global::System.Windows.Forms.ComboBox cboNM;

	// Token: 0x040014CA RID: 5322
	private global::Class85 txtRao;

	// Token: 0x040014CB RID: 5323
	private global::System.Windows.Forms.NumericUpDown nudHP;

	// Token: 0x040014CC RID: 5324
	private global::System.Windows.Forms.NumericUpDown nudMP;

	// Token: 0x040014CD RID: 5325
	private global::System.Windows.Forms.CheckBox checkMP;

	// Token: 0x040014CE RID: 5326
	private global::System.Windows.Forms.Label lblRadius;

	// Token: 0x040014CF RID: 5327
	private global::System.Windows.Forms.CheckBox checkNM;

	// Token: 0x040014D0 RID: 5328
	private global::System.Windows.Forms.NumericUpDown nudRadius;

	// Token: 0x040014D1 RID: 5329
	private global::System.Windows.Forms.Button btnTalkChannel;

	// Token: 0x040014D2 RID: 5330
	private global::System.Windows.Forms.ComboBox cboHP;

	// Token: 0x040014D3 RID: 5331
	private global::System.Windows.Forms.Button btnNM;

	// Token: 0x040014D4 RID: 5332
	private global::System.Windows.Forms.TabPage tabBuff;

	// Token: 0x040014D5 RID: 5333
	private global::System.Windows.Forms.CheckBox checkChetLenBai;

	// Token: 0x040014D6 RID: 5334
	private global::System.Windows.Forms.ToolStripMenuItem muBHD;

	// Token: 0x040014D7 RID: 5335
	private global::System.Windows.Forms.ToolStripMenuItem muTrongHoa;

	// Token: 0x040014D8 RID: 5336
	private global::System.Windows.Forms.ToolStripMenuItem muBonHoa;

	// Token: 0x040014D9 RID: 5337
	private global::System.Windows.Forms.ToolStripMenuItem muThuHoach;

	// Token: 0x040014DA RID: 5338
	private global::System.Windows.Forms.ToolStripMenuItem muTuoiHoaHong;

	// Token: 0x040014DB RID: 5339
	private global::System.Windows.Forms.ToolStripMenuItem muNhanQuaBuiHoa;

	// Token: 0x040014DC RID: 5340
	private global::System.Windows.Forms.ToolStripMenuItem muNhanHoaHongLo;

	// Token: 0x040014DD RID: 5341
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator4;

	// Token: 0x040014DE RID: 5342
	private global::System.Windows.Forms.ToolStripMenuItem allToolStripMenuItem1;

	// Token: 0x040014DF RID: 5343
	private global::System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem1;

	// Token: 0x040014E0 RID: 5344
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040014E1 RID: 5345
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x040014E2 RID: 5346
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator25;

	// Token: 0x040014E3 RID: 5347
	private global::System.Windows.Forms.ToolStripMenuItem menuPause;

	// Token: 0x040014E4 RID: 5348
	private global::System.Windows.Forms.ToolStripMenuItem menuPausedSkill;

	// Token: 0x040014E5 RID: 5349
	private global::System.Windows.Forms.CheckBox checkChiNhat;

	// Token: 0x040014E6 RID: 5350
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

	// Token: 0x040014E7 RID: 5351
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator27;

	// Token: 0x040014E8 RID: 5352
	private global::System.Windows.Forms.ToolStripMenuItem menuPickItem;

	// Token: 0x040014E9 RID: 5353
	private global::System.Windows.Forms.ToolStripMenuItem menuItemFillter;

	// Token: 0x040014EA RID: 5354
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator28;

	// Token: 0x040014EB RID: 5355
	private global::System.Windows.Forms.ToolStripMenuItem menuFollowKey;

	// Token: 0x040014EC RID: 5356
	private global::System.Windows.Forms.ToolStripMenuItem menuAtkFollowKey;

	// Token: 0x040014ED RID: 5357
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator2;

	// Token: 0x040014EE RID: 5358
	private global::System.Windows.Forms.ToolStripMenuItem autoPKToolStripMenuItem;

	// Token: 0x040014EF RID: 5359
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x040014F0 RID: 5360
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator30;

	// Token: 0x040014F1 RID: 5361
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator32;

	// Token: 0x040014F2 RID: 5362
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator35;

	// Token: 0x040014F3 RID: 5363
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator36;

	// Token: 0x040014F4 RID: 5364
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator37;

	// Token: 0x040014F5 RID: 5365
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator40;

	// Token: 0x040014F6 RID: 5366
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator39;

	// Token: 0x040014F7 RID: 5367
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator42;

	// Token: 0x040014F8 RID: 5368
	private global::Class85 txtSearchName;

	// Token: 0x040014F9 RID: 5369
	private global::System.Windows.Forms.ToolStripMenuItem muTrimRam;

	// Token: 0x040014FA RID: 5370
	private global::System.Windows.Forms.Timer timer_5;

	// Token: 0x040014FB RID: 5371
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x040014FC RID: 5372
	private global::System.Windows.Forms.CheckBox chkThieuThatSon;

	// Token: 0x040014FD RID: 5373
	private global::System.Windows.Forms.CheckBox chkVuongLang;

	// Token: 0x040014FE RID: 5374
	private global::System.Windows.Forms.CheckBox chkTuTuyetTrang;

	// Token: 0x040014FF RID: 5375
	private global::System.Windows.Forms.CheckBox chkSatTinh;

	// Token: 0x04001500 RID: 5376
	private global::System.Windows.Forms.CheckBox chkYenTuO;

	// Token: 0x04001501 RID: 5377
	private global::System.Windows.Forms.CheckBox chkQLauLan;

	// Token: 0x04001502 RID: 5378
	private global::System.Windows.Forms.CheckBox chkPhieuMieuPhong;

	// Token: 0x04001503 RID: 5379
	private global::System.Windows.Forms.CheckBox chkHuyetChien;

	// Token: 0x04001504 RID: 5380
	private global::System.Windows.Forms.CheckBox chkQToChau;

	// Token: 0x04001505 RID: 5381
	private global::System.Windows.Forms.CheckBox chkTamThan;

	// Token: 0x04001506 RID: 5382
	private global::System.Windows.Forms.CheckBox chkPhucDia;

	// Token: 0x04001507 RID: 5383
	private global::System.Windows.Forms.CheckBox chkPDKho;

	// Token: 0x04001508 RID: 5384
	private global::System.Windows.Forms.Timer timer_6;

	// Token: 0x04001509 RID: 5385
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x0400150A RID: 5386
	private global::System.Windows.Forms.ToolStripMenuItem muForceFollow;

	// Token: 0x0400150B RID: 5387
	private global::System.Windows.Forms.ToolStripMenuItem traderToolStripMenuItem;

	// Token: 0x0400150C RID: 5388
	private global::System.Windows.Forms.ToolStripMenuItem muDoanBaoMaTac;

	// Token: 0x0400150D RID: 5389
	private global::System.Windows.Forms.ToolStripMenuItem muMute;

	// Token: 0x0400150E RID: 5390
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x0400150F RID: 5391
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x04001510 RID: 5392
	private global::Class398 listViewSkill;

	// Token: 0x04001511 RID: 5393
	private global::System.Windows.Forms.ColumnHeader columnHeader_6;

	// Token: 0x04001512 RID: 5394
	private global::System.Windows.Forms.ColumnHeader columnHeader_7;

	// Token: 0x04001513 RID: 5395
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x04001514 RID: 5396
	private global::System.Windows.Forms.ToolStripSeparator toolStripMenuItem18;

	// Token: 0x04001515 RID: 5397
	private global::System.Windows.Forms.ToolStripMenuItem mnuKetNghia;

	// Token: 0x04001516 RID: 5398
	private global::System.Windows.Forms.ToolStripMenuItem mnuKeBaiSudo;

	// Token: 0x04001517 RID: 5399
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x04001518 RID: 5400
	private global::System.Windows.Forms.ToolStripMenuItem bossMapToolStripMenuItem;

	// Token: 0x04001519 RID: 5401
	private global::System.Windows.Forms.ToolStripMenuItem configToolStripMenuItem;

	// Token: 0x0400151A RID: 5402
	private global::System.Windows.Forms.ToolStripMenuItem muThanKhi9Sao;

	// Token: 0x0400151B RID: 5403
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x0400151C RID: 5404
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x0400151D RID: 5405
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x0400151E RID: 5406
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x0400151F RID: 5407
	private global::System.Windows.Forms.Timer timer_7;

	// Token: 0x04001520 RID: 5408
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x04001521 RID: 5409
	private global::System.Windows.Forms.ToolStripMenuItem menuTuLuyen;

	// Token: 0x04001522 RID: 5410
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x04001523 RID: 5411
	private global::Control1 tab;

	// Token: 0x04001524 RID: 5412
	private global::System.Windows.Forms.TabPage tabGame;

	// Token: 0x04001525 RID: 5413
	private global::System.Windows.Forms.TabPage tabChat;

	// Token: 0x04001526 RID: 5414
	private global::System.Windows.Forms.TabPage tabLog;

	// Token: 0x04001527 RID: 5415
	private global::Class85 textBoxEx2;

	// Token: 0x04001528 RID: 5416
	private global::System.Windows.Forms.TabPage tabUser;

	// Token: 0x04001529 RID: 5417
	private global::System.Windows.Forms.RichTextBox ricChat;

	// Token: 0x0400152A RID: 5418
	private global::System.Windows.Forms.Label label7;

	// Token: 0x0400152B RID: 5419
	private global::System.Windows.Forms.TabPage tabLogin;

	// Token: 0x0400152C RID: 5420
	private global::_i.ListViewEx lvConfig;

	// Token: 0x0400152D RID: 5421
	private global::System.Windows.Forms.ColumnHeader columnHeader_8;

	// Token: 0x0400152E RID: 5422
	private global::System.Windows.Forms.ColumnHeader columnHeader_9;

	// Token: 0x0400152F RID: 5423
	private global::System.Windows.Forms.TabPage tabQuest;

	// Token: 0x04001530 RID: 5424
	private global::System.Windows.Forms.TabPage tabCraft;

	// Token: 0x04001531 RID: 5425
	private global::System.Windows.Forms.Label label5;

	// Token: 0x04001532 RID: 5426
	private global::System.Windows.Forms.Panel panel3;

	// Token: 0x04001533 RID: 5427
	private global::System.Windows.Forms.CheckBox checkBanKinh;

	// Token: 0x04001534 RID: 5428
	private global::System.Windows.Forms.NumericUpDown numberRadiusThuHoa;

	// Token: 0x04001535 RID: 5429
	private global::System.Windows.Forms.Label label10;

	// Token: 0x04001536 RID: 5430
	private global::System.Windows.Forms.NumericUpDown numberThuHoaX;

	// Token: 0x04001537 RID: 5431
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x04001538 RID: 5432
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator21;

	// Token: 0x04001539 RID: 5433
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x0400153A RID: 5434
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator22;

	// Token: 0x0400153B RID: 5435
	private global::Class85 txtMainSearch;

	// Token: 0x0400153C RID: 5436
	private global::System.Windows.Forms.ToolStripMenuItem muThanhLyNhiemVu;

	// Token: 0x0400153D RID: 5437
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x0400153E RID: 5438
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x0400153F RID: 5439
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_26;

	// Token: 0x04001540 RID: 5440
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;

	// Token: 0x04001541 RID: 5441
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_27;

	// Token: 0x04001542 RID: 5442
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_28;

	// Token: 0x04001543 RID: 5443
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_29;

	// Token: 0x04001544 RID: 5444
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_30;

	// Token: 0x04001545 RID: 5445
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_31;

	// Token: 0x04001546 RID: 5446
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_32;

	// Token: 0x04001547 RID: 5447
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_33;

	// Token: 0x04001548 RID: 5448
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_34;

	// Token: 0x04001549 RID: 5449
	private global::System.Windows.Forms.ToolStripMenuItem muTucCau;

	// Token: 0x0400154A RID: 5450
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_35;

	// Token: 0x0400154B RID: 5451
	private global::System.Windows.Forms.ToolStripMenuItem selectPathToolStripMenuItem;

	// Token: 0x0400154C RID: 5452
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator15;

	// Token: 0x0400154D RID: 5453
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_36;

	// Token: 0x0400154E RID: 5454
	private global::System.Windows.Forms.ToolStripMenuItem menuGoTrieuTap;

	// Token: 0x0400154F RID: 5455
	private global::System.Windows.Forms.ToolStripMenuItem muNopTuViHuyTinh;

	// Token: 0x04001550 RID: 5456
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_37;

	// Token: 0x04001551 RID: 5457
	private global::System.Windows.Forms.ToolStripMenuItem muMoShop;

	// Token: 0x04001552 RID: 5458
	private global::System.Windows.Forms.ToolStripMenuItem muMoShopTrungDo;

	// Token: 0x04001553 RID: 5459
	private global::System.Windows.Forms.ToolStripMenuItem muMoShopHungBa;

	// Token: 0x04001554 RID: 5460
	private global::System.Windows.Forms.ToolStripMenuItem muMoShopBachBaoCac;

	// Token: 0x04001555 RID: 5461
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_38;

	// Token: 0x04001556 RID: 5462
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_39;

	// Token: 0x04001557 RID: 5463
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_40;

	// Token: 0x04001558 RID: 5464
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_41;

	// Token: 0x04001559 RID: 5465
	private global::System.Windows.Forms.ToolStripMenuItem bangToolStripMenuItem;

	// Token: 0x0400155A RID: 5466
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_42;

	// Token: 0x0400155B RID: 5467
	private global::System.Windows.Forms.NumericUpDown nudBuffPet;

	// Token: 0x0400155C RID: 5468
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_43;

	// Token: 0x0400155D RID: 5469
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_44;

	// Token: 0x0400155E RID: 5470
	private global::System.Windows.Forms.ToolStripMenuItem muDoiKimTamTy;

	// Token: 0x0400155F RID: 5471
	private global::System.Windows.Forms.ToolStripMenuItem muDoi999HoaHong;

	// Token: 0x04001560 RID: 5472
	private global::System.Windows.Forms.ToolStripMenuItem muDoiLoanPhiMatHam;

	// Token: 0x04001561 RID: 5473
	private global::System.Windows.Forms.ToolStripMenuItem muDoiHuyenSacCauThienThai;

	// Token: 0x04001562 RID: 5474
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_45;

	// Token: 0x04001563 RID: 5475
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator17;

	// Token: 0x04001564 RID: 5476
	private global::System.Windows.Forms.ToolStripMenuItem muNhanBong;

	// Token: 0x04001565 RID: 5477
	private global::System.Windows.Forms.ToolStripMenuItem muNhanLeBao;

	// Token: 0x04001566 RID: 5478
	private global::System.Windows.Forms.ToolStripMenuItem muDoiTiemNangTan;

	// Token: 0x04001567 RID: 5479
	private global::System.Windows.Forms.ToolStripMenuItem muNhanThuongTyVo;

	// Token: 0x04001568 RID: 5480
	private global::System.Windows.Forms.ToolStripMenuItem muNhanChienCongKiemChi;

	// Token: 0x04001569 RID: 5481
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_46;

	// Token: 0x0400156A RID: 5482
	private global::System.Windows.Forms.ToolStripMenuItem muSuaVoHon;

	// Token: 0x0400156B RID: 5483
	private global::System.Windows.Forms.ToolStripMenuItem muSuaThanKhi;

	// Token: 0x0400156C RID: 5484
	private global::System.Windows.Forms.ToolStripMenuItem muSuaTrangBi;

	// Token: 0x0400156D RID: 5485
	private global::System.Windows.Forms.NumericUpDown nudTangTiemNang;

	// Token: 0x0400156E RID: 5486
	private global::System.Windows.Forms.ComboBox cboTiemNang;

	// Token: 0x0400156F RID: 5487
	private global::System.Windows.Forms.Button button15;

	// Token: 0x04001570 RID: 5488
	private global::System.Windows.Forms.ToolStripMenuItem muNhanThuongQuanSonHai;

	// Token: 0x04001571 RID: 5489
	private global::System.Windows.Forms.ToolStripMenuItem muDoiChanNguyenLinhPhach;

	// Token: 0x04001572 RID: 5490
	private global::System.Windows.Forms.ToolStripMenuItem muNhanKeoHallowen;

	// Token: 0x04001573 RID: 5491
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_47;

	// Token: 0x04001574 RID: 5492
	private global::System.Windows.Forms.ToolStripMenuItem muGiaoNguHanhPhapThiep;

	// Token: 0x04001575 RID: 5493
	private global::System.Windows.Forms.ToolStripMenuItem muNhanBuaBaoRuong;

	// Token: 0x04001576 RID: 5494
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_48;

	// Token: 0x04001577 RID: 5495
	private global::System.Windows.Forms.ToolStripMenuItem muTuLuyenTheLuc;

	// Token: 0x04001578 RID: 5496
	private global::System.Windows.Forms.ToolStripMenuItem muTuLuyenNoiLuc;

	// Token: 0x04001579 RID: 5497
	private global::System.Windows.Forms.ToolStripMenuItem muTuLuyenThanPhap;

	// Token: 0x0400157A RID: 5498
	private global::System.Windows.Forms.ToolStripMenuItem muTuLuyenCuongLuc;

	// Token: 0x0400157B RID: 5499
	private global::System.Windows.Forms.CheckBox chkBinhThanh;

	// Token: 0x0400157C RID: 5500
	private global::System.Windows.Forms.CheckBox chkKho;

	// Token: 0x0400157D RID: 5501
	private global::System.Windows.Forms.Button button17;

	// Token: 0x0400157E RID: 5502
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_49;

	// Token: 0x0400157F RID: 5503
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_50;

	// Token: 0x04001580 RID: 5504
	private global::System.Windows.Forms.ToolStripMenuItem muTyVo;

	// Token: 0x04001581 RID: 5505
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_51;

	// Token: 0x04001582 RID: 5506
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_52;

	// Token: 0x04001583 RID: 5507
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_53;

	// Token: 0x04001584 RID: 5508
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_54;

	// Token: 0x04001585 RID: 5509
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_55;

	// Token: 0x04001586 RID: 5510
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_56;

	// Token: 0x04001587 RID: 5511
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_57;

	// Token: 0x04001588 RID: 5512
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_58;

	// Token: 0x04001589 RID: 5513
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_59;

	// Token: 0x0400158A RID: 5514
	private global::System.Windows.Forms.ToolStripMenuItem muTuLuyenTheNoiThan;

	// Token: 0x0400158B RID: 5515
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;

	// Token: 0x0400158C RID: 5516
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_60;

	// Token: 0x0400158D RID: 5517
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_61;

	// Token: 0x0400158E RID: 5518
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_62;

	// Token: 0x0400158F RID: 5519
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_63;

	// Token: 0x04001590 RID: 5520
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_64;

	// Token: 0x04001591 RID: 5521
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_65;

	// Token: 0x04001592 RID: 5522
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_66;

	// Token: 0x04001593 RID: 5523
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_67;

	// Token: 0x04001594 RID: 5524
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_68;

	// Token: 0x04001595 RID: 5525
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_69;

	// Token: 0x04001596 RID: 5526
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_70;

	// Token: 0x04001597 RID: 5527
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_71;

	// Token: 0x04001598 RID: 5528
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_72;

	// Token: 0x04001599 RID: 5529
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_73;

	// Token: 0x0400159A RID: 5530
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_74;

	// Token: 0x0400159B RID: 5531
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_75;

	// Token: 0x0400159C RID: 5532
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_76;

	// Token: 0x0400159D RID: 5533
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_77;

	// Token: 0x0400159E RID: 5534
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_78;

	// Token: 0x0400159F RID: 5535
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_79;

	// Token: 0x040015A0 RID: 5536
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_80;

	// Token: 0x040015A1 RID: 5537
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_81;

	// Token: 0x040015A2 RID: 5538
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_82;

	// Token: 0x040015A3 RID: 5539
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_83;

	// Token: 0x040015A4 RID: 5540
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_84;

	// Token: 0x040015A5 RID: 5541
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;

	// Token: 0x040015A6 RID: 5542
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_85;

	// Token: 0x040015A7 RID: 5543
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_86;

	// Token: 0x040015A8 RID: 5544
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_87;

	// Token: 0x040015A9 RID: 5545
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;

	// Token: 0x040015AA RID: 5546
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_88;

	// Token: 0x040015AB RID: 5547
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_89;

	// Token: 0x040015AC RID: 5548
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;

	// Token: 0x040015AD RID: 5549
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;

	// Token: 0x040015AE RID: 5550
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_90;

	// Token: 0x040015AF RID: 5551
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_91;

	// Token: 0x040015B0 RID: 5552
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_92;

	// Token: 0x040015B1 RID: 5553
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_93;

	// Token: 0x040015B2 RID: 5554
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_94;

	// Token: 0x040015B3 RID: 5555
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_95;

	// Token: 0x040015B4 RID: 5556
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_96;

	// Token: 0x040015B5 RID: 5557
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_97;

	// Token: 0x040015B6 RID: 5558
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_98;

	// Token: 0x040015B7 RID: 5559
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_99;

	// Token: 0x040015B8 RID: 5560
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_100;

	// Token: 0x040015B9 RID: 5561
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_101;

	// Token: 0x040015BA RID: 5562
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_102;

	// Token: 0x040015BB RID: 5563
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_103;

	// Token: 0x040015BC RID: 5564
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_104;

	// Token: 0x040015BD RID: 5565
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_105;

	// Token: 0x040015BE RID: 5566
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_106;

	// Token: 0x040015BF RID: 5567
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_107;

	// Token: 0x040015C0 RID: 5568
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_108;

	// Token: 0x040015C1 RID: 5569
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_109;

	// Token: 0x040015C2 RID: 5570
	private global::System.Windows.Forms.ToolStripMenuItem xToolStripMenuItem;

	// Token: 0x040015C3 RID: 5571
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_110;

	// Token: 0x040015C4 RID: 5572
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_111;

	// Token: 0x040015C5 RID: 5573
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_112;

	// Token: 0x040015C6 RID: 5574
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_113;

	// Token: 0x040015C7 RID: 5575
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_114;

	// Token: 0x040015C8 RID: 5576
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_115;

	// Token: 0x040015C9 RID: 5577
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_116;

	// Token: 0x040015CA RID: 5578
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_117;

	// Token: 0x040015CB RID: 5579
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_118;

	// Token: 0x040015CC RID: 5580
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_119;

	// Token: 0x040015CD RID: 5581
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_120;

	// Token: 0x040015CE RID: 5582
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_121;

	// Token: 0x040015CF RID: 5583
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_122;

	// Token: 0x040015D0 RID: 5584
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_123;

	// Token: 0x040015D1 RID: 5585
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_124;

	// Token: 0x040015D2 RID: 5586
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_125;

	// Token: 0x040015D3 RID: 5587
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_126;

	// Token: 0x040015D4 RID: 5588
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;

	// Token: 0x040015D5 RID: 5589
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_127;

	// Token: 0x040015D6 RID: 5590
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_128;

	// Token: 0x040015D7 RID: 5591
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_129;

	// Token: 0x040015D8 RID: 5592
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_130;

	// Token: 0x040015D9 RID: 5593
	private global::System.Windows.Forms.ToolStripMenuItem muVoY;

	// Token: 0x040015DA RID: 5594
	private global::System.Windows.Forms.ToolStripMenuItem bossToolStripMenuItem;

	// Token: 0x040015DB RID: 5595
	private global::System.Windows.Forms.ToolStripMenuItem longQuy16936ToolStripMenuItem;

	// Token: 0x040015DC RID: 5596
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator23;

	// Token: 0x040015DD RID: 5597
	private global::System.Windows.Forms.ToolStripMenuItem muQuanSonHai;

	// Token: 0x040015DE RID: 5598
	private global::System.Windows.Forms.ToolStripMenuItem muVoTuPho;

	// Token: 0x040015DF RID: 5599
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_131;

	// Token: 0x040015E0 RID: 5600
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator24;

	// Token: 0x040015E1 RID: 5601
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_132;

	// Token: 0x040015E2 RID: 5602
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_133;

	// Token: 0x040015E3 RID: 5603
	private global::System.Windows.Forms.ToolStripMenuItem ngamyToolStripMenuItem;

	// Token: 0x040015E4 RID: 5604
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_134;

	// Token: 0x040015E5 RID: 5605
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_135;

	// Token: 0x040015E6 RID: 5606
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_136;

	// Token: 0x040015E7 RID: 5607
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_137;

	// Token: 0x040015E8 RID: 5608
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_138;

	// Token: 0x040015E9 RID: 5609
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_139;

	// Token: 0x040015EA RID: 5610
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_140;

	// Token: 0x040015EB RID: 5611
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_141;

	// Token: 0x040015EC RID: 5612
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_142;

	// Token: 0x040015ED RID: 5613
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_143;

	// Token: 0x040015EE RID: 5614
	private global::System.Windows.Forms.ToolStripMenuItem muMoShopQuyThi;

	// Token: 0x040015EF RID: 5615
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_144;

	// Token: 0x040015F0 RID: 5616
	private global::System.Windows.Forms.ToolStripMenuItem muThuongKho;

	// Token: 0x040015F1 RID: 5617
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_145;

	// Token: 0x040015F2 RID: 5618
	private global::System.Windows.Forms.ToolStripMenuItem muCatDo;

	// Token: 0x040015F3 RID: 5619
	private global::System.Windows.Forms.ToolStripMenuItem muLayDo;

	// Token: 0x040015F4 RID: 5620
	private global::System.Windows.Forms.ToolStripMenuItem muTangCapTruongThanhLongVan;

	// Token: 0x040015F5 RID: 5621
	private global::System.Windows.Forms.ToolStripMenuItem gomToolStripMenuItem;

	// Token: 0x040015F6 RID: 5622
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_146;

	// Token: 0x040015F7 RID: 5623
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_147;

	// Token: 0x040015F8 RID: 5624
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_148;

	// Token: 0x040015F9 RID: 5625
	private global::System.Windows.Forms.ToolStripMenuItem treoShopChoTaToolStripMenuItem1;

	// Token: 0x040015FA RID: 5626
	private global::System.Windows.Forms.ToolStripMenuItem muLayDoLayVang;

	// Token: 0x040015FB RID: 5627
	private global::System.Windows.Forms.CheckBox chkBanRac;

	// Token: 0x040015FC RID: 5628
	private global::System.Windows.Forms.ToolStripMenuItem muDaiLeHungVuong;

	// Token: 0x040015FD RID: 5629
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_149;

	// Token: 0x040015FE RID: 5630
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_150;

	// Token: 0x040015FF RID: 5631
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_151;

	// Token: 0x04001600 RID: 5632
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_152;

	// Token: 0x04001601 RID: 5633
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_153;

	// Token: 0x04001602 RID: 5634
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_154;

	// Token: 0x04001603 RID: 5635
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_155;

	// Token: 0x04001604 RID: 5636
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_156;

	// Token: 0x04001605 RID: 5637
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_157;

	// Token: 0x04001606 RID: 5638
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_158;

	// Token: 0x04001607 RID: 5639
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_159;

	// Token: 0x04001608 RID: 5640
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_160;

	// Token: 0x04001609 RID: 5641
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_161;

	// Token: 0x0400160A RID: 5642
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_162;

	// Token: 0x0400160B RID: 5643
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_163;

	// Token: 0x0400160C RID: 5644
	private global::System.Windows.Forms.ToolStripMenuItem muBaoDoHiem;

	// Token: 0x0400160D RID: 5645
	private global::System.Windows.Forms.ToolStripMenuItem muDungDoatBaoRuong;

	// Token: 0x0400160E RID: 5646
	private global::System.Windows.Forms.ToolStripMenuItem muCheThanKhi;

	// Token: 0x0400160F RID: 5647
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_164;

	// Token: 0x04001610 RID: 5648
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_165;

	// Token: 0x04001611 RID: 5649
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_166;

	// Token: 0x04001612 RID: 5650
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_167;

	// Token: 0x04001613 RID: 5651
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_168;

	// Token: 0x04001614 RID: 5652
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_169;

	// Token: 0x04001615 RID: 5653
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_170;

	// Token: 0x04001616 RID: 5654
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_171;

	// Token: 0x04001617 RID: 5655
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_172;

	// Token: 0x04001618 RID: 5656
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_173;

	// Token: 0x04001619 RID: 5657
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_174;

	// Token: 0x0400161A RID: 5658
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_175;

	// Token: 0x0400161B RID: 5659
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_176;

	// Token: 0x0400161C RID: 5660
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_177;

	// Token: 0x0400161D RID: 5661
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_178;

	// Token: 0x0400161E RID: 5662
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_179;

	// Token: 0x0400161F RID: 5663
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_180;

	// Token: 0x04001620 RID: 5664
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_181;

	// Token: 0x04001621 RID: 5665
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_182;

	// Token: 0x04001622 RID: 5666
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_183;

	// Token: 0x04001623 RID: 5667
	private global::System.Windows.Forms.ToolStripMenuItem muVanTieu;

	// Token: 0x04001624 RID: 5668
	private global::System.Windows.Forms.ToolStripMenuItem thuPetToolStripMenuItem;

	// Token: 0x04001625 RID: 5669
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_184;

	// Token: 0x04001626 RID: 5670
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_185;

	// Token: 0x04001627 RID: 5671
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator5;

	// Token: 0x04001628 RID: 5672
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_186;

	// Token: 0x04001629 RID: 5673
	private global::System.Windows.Forms.ToolStripMenuItem selectCtrlAToolStripMenuItem;

	// Token: 0x0400162A RID: 5674
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_187;

	// Token: 0x0400162B RID: 5675
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_188;

	// Token: 0x0400162C RID: 5676
	private global::System.Windows.Forms.ToolStripMenuItem muMoTiemThuoc;

	// Token: 0x0400162D RID: 5677
	private global::System.Windows.Forms.ToolStripMenuItem muVanTieu1;

	// Token: 0x0400162E RID: 5678
	private global::System.Windows.Forms.ToolStripMenuItem muVanTieu2;

	// Token: 0x0400162F RID: 5679
	private global::System.Windows.Forms.ToolStripMenuItem muVanTieu3;

	// Token: 0x04001630 RID: 5680
	private global::System.Windows.Forms.ToolStripMenuItem muVanTieu4;

	// Token: 0x04001631 RID: 5681
	private global::System.Windows.Forms.Button button3;

	// Token: 0x04001632 RID: 5682
	private global::System.Windows.Forms.ToolStripMenuItem muLinhLuong;

	// Token: 0x04001633 RID: 5683
	private global::System.Windows.Forms.ToolStripMenuItem muMua100KimSangDuoc;

	// Token: 0x04001634 RID: 5684
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_189;

	// Token: 0x04001635 RID: 5685
	private global::System.Windows.Forms.ToolStripMenuItem muTrangSucCuuLe;

	// Token: 0x04001636 RID: 5686
	private global::System.Windows.Forms.ToolStripMenuItem muTamKy;

	// Token: 0x04001637 RID: 5687
	private global::System.Windows.Forms.ToolStripMenuItem muDuaTangBaoDo;

	// Token: 0x04001638 RID: 5688
	private global::System.Windows.Forms.Button btnCanQuetThuCong;

	// Token: 0x04001639 RID: 5689
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_190;

	// Token: 0x0400163A RID: 5690
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_191;

	// Token: 0x0400163B RID: 5691
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator14;

	// Token: 0x0400163C RID: 5692
	private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator11;

	// Token: 0x0400163D RID: 5693
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_192;

	// Token: 0x0400163E RID: 5694
	private global::System.Windows.Forms.ToolStripMenuItem thuPetToolStripMenuItem1;

	// Token: 0x0400163F RID: 5695
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_193;

	// Token: 0x04001640 RID: 5696
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_194;

	// Token: 0x04001641 RID: 5697
	private global::System.Windows.Forms.ToolStripMenuItem muaX2ToolStripMenuItem;

	// Token: 0x04001642 RID: 5698
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_195;

	// Token: 0x04001643 RID: 5699
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_196;

	// Token: 0x04001644 RID: 5700
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_197;

	// Token: 0x04001645 RID: 5701
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_198;

	// Token: 0x04001646 RID: 5702
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_199;

	// Token: 0x04001647 RID: 5703
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_200;

	// Token: 0x04001648 RID: 5704
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_201;

	// Token: 0x04001649 RID: 5705
	private global::System.Windows.Forms.Panel panel4;

	// Token: 0x0400164A RID: 5706
	public new global::System.Windows.Forms.Panel Container;

	// Token: 0x0400164B RID: 5707
	private global::System.Windows.Forms.GroupBox groupBox3;

	// Token: 0x0400164C RID: 5708
	private global::System.Windows.Forms.GroupBox groupBox15;

	// Token: 0x0400164D RID: 5709
	private global::System.Windows.Forms.SplitContainer splitContainer7;

	// Token: 0x0400164E RID: 5710
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_202;

	// Token: 0x0400164F RID: 5711
	private global::Control1 tabCanQuet;

	// Token: 0x04001650 RID: 5712
	private global::System.Windows.Forms.TabPage tabCloseXanQuet;

	// Token: 0x04001651 RID: 5713
	private global::System.Windows.Forms.TabPage tabSwitch;

	// Token: 0x04001652 RID: 5714
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_203;

	// Token: 0x04001653 RID: 5715
	private global::System.Windows.Forms.ComboBox cboPlayer;

	// Token: 0x04001654 RID: 5716
	private global::System.Windows.Forms.Label label4;

	// Token: 0x04001655 RID: 5717
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_204;

	// Token: 0x04001656 RID: 5718
	private global::System.Windows.Forms.GroupBox groupBox23;

	// Token: 0x04001657 RID: 5719
	private global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;

	// Token: 0x04001658 RID: 5720
	private global::System.Windows.Forms.Panel panel5;

	// Token: 0x04001659 RID: 5721
	private global::System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;

	// Token: 0x0400165A RID: 5722
	private global::System.Windows.Forms.Label lbExpSpeed;

	// Token: 0x0400165B RID: 5723
	private global::System.Windows.Forms.Label lblTimeInfo;

	// Token: 0x0400165C RID: 5724
	private global::System.Windows.Forms.Label lbHoaSpeed;

	// Token: 0x0400165D RID: 5725
	private global::System.Windows.Forms.GroupBox groupBox25;

	// Token: 0x0400165E RID: 5726
	private global::System.Windows.Forms.Button button13;

	// Token: 0x0400165F RID: 5727
	private global::System.Windows.Forms.Label lbAcBa;

	// Token: 0x04001660 RID: 5728
	private global::System.Windows.Forms.GroupBox groupBox28;

	// Token: 0x04001661 RID: 5729
	public global::System.Windows.Forms.RichTextBox ricMaTac;

	// Token: 0x04001662 RID: 5730
	private global::System.Windows.Forms.GroupBox groupBox27;

	// Token: 0x04001663 RID: 5731
	public global::System.Windows.Forms.RichTextBox ricExit;

	// Token: 0x04001664 RID: 5732
	private global::System.Windows.Forms.GroupBox groupBox26;

	// Token: 0x04001665 RID: 5733
	public global::System.Windows.Forms.RichTextBox ricAcBa;

	// Token: 0x04001666 RID: 5734
	private global::System.Windows.Forms.GroupBox groupBox29;

	// Token: 0x04001667 RID: 5735
	public global::System.Windows.Forms.RichTextBox ricXong;

	// Token: 0x04001668 RID: 5736
	private global::System.Windows.Forms.Panel panInbox;

	// Token: 0x04001669 RID: 5737
	public global::_i.ListViewEx Lv;

	// Token: 0x0400166A RID: 5738
	private global::System.Windows.Forms.ColumnHeader columnHeader_10;

	// Token: 0x0400166B RID: 5739
	private global::System.Windows.Forms.ColumnHeader columnHeader_11;

	// Token: 0x0400166C RID: 5740
	private global::System.Windows.Forms.ColumnHeader columnHeader_12;

	// Token: 0x0400166D RID: 5741
	private global::System.Windows.Forms.ColumnHeader columnHeader_13;

	// Token: 0x0400166E RID: 5742
	private global::System.Windows.Forms.ColumnHeader columnHeader_14;

	// Token: 0x0400166F RID: 5743
	private global::System.Windows.Forms.ColumnHeader columnHeader_15;

	// Token: 0x04001670 RID: 5744
	private global::System.Windows.Forms.ColumnHeader columnHeader_16;

	// Token: 0x04001671 RID: 5745
	private global::System.Windows.Forms.ColumnHeader columnHeader_17;

	// Token: 0x04001672 RID: 5746
	private global::System.Windows.Forms.ColumnHeader columnHeader_18;

	// Token: 0x04001673 RID: 5747
	private global::System.Windows.Forms.ColumnHeader columnHeader_19;

	// Token: 0x04001674 RID: 5748
	private global::System.Windows.Forms.ColumnHeader columnHeader_20;

	// Token: 0x04001675 RID: 5749
	private global::System.Windows.Forms.ColumnHeader columnHeader_21;

	// Token: 0x04001676 RID: 5750
	private global::System.Windows.Forms.ColumnHeader columnHeader_22;

	// Token: 0x04001677 RID: 5751
	private global::System.Windows.Forms.ColumnHeader columnHeader_23;

	// Token: 0x04001678 RID: 5752
	private global::System.Windows.Forms.TabPage tabSetting;

	// Token: 0x04001679 RID: 5753
	private global::System.Windows.Forms.TabPage tabPage1;

	// Token: 0x0400167A RID: 5754
	private global::Control1 tabControlEx1;

	// Token: 0x0400167B RID: 5755
	private global::System.Windows.Forms.TabPage tabPage2;

	// Token: 0x0400167C RID: 5756
	private global::System.Windows.Forms.TabPage tabPage3;

	// Token: 0x0400167D RID: 5757
	private global::GameInfo gameInfo;

	// Token: 0x0400167E RID: 5758
	private global::System.Windows.Forms.ColumnHeader columnHeader_24;

	// Token: 0x0400167F RID: 5759
	private global::System.Windows.Forms.SplitContainer splitContainer1;

	// Token: 0x04001680 RID: 5760
	private global::System.Windows.Forms.Button button10;

	// Token: 0x04001681 RID: 5761
	private global::System.Windows.Forms.ComboBox cboNgoc;

	// Token: 0x04001682 RID: 5762
	private global::System.Windows.Forms.Button button18;

	// Token: 0x04001683 RID: 5763
	private global::System.Windows.Forms.ComboBox comboBox2;

	// Token: 0x04001684 RID: 5764
	private global::System.Windows.Forms.PictureBox picBank;

	// Token: 0x04001685 RID: 5765
	private global::System.Windows.Forms.Button button1;

	// Token: 0x04001686 RID: 5766
	private global::System.Windows.Forms.Label lblBeli;
}
