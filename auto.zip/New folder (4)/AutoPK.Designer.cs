﻿// Token: 0x02000168 RID: 360
public partial class AutoPK : global::System.Windows.Forms.Form
{
	// Token: 0x0600117F RID: 4479 RVA: 0x0005EEA0 File Offset: 0x0005D0A0
	private void InitializeComponent()
	{
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::AutoPK));
		this.listViewName = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.button2 = new global::System.Windows.Forms.Button();
		this.txtSearch = new global::Class85();
		this.checkBox1 = new global::System.Windows.Forms.CheckBox();
		this.label1 = new global::System.Windows.Forms.Label();
		base.SuspendLayout();
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (global::System.Collections.Generic.List<global::System.Windows.Forms.ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = global::System.Drawing.Color.Red;
		this.listViewName.Location = new global::System.Drawing.Point(0, 20);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new global::System.Drawing.Size(273, 269);
		this.listViewName.TabIndex = 8;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = global::System.Windows.Forms.View.Details;
		this.listViewName.SelectedIndexChanged += new global::System.EventHandler(this.listViewName_SelectedIndexChanged);
		this.columnHeader_0.Text = "Tên người chơi";
		this.columnHeader_0.Width = 189;
		this.button2.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.button2.Location = new global::System.Drawing.Point(0, 289);
		this.button2.Name = "button2";
		this.button2.Size = new global::System.Drawing.Size(273, 23);
		this.button2.TabIndex = 10;
		this.button2.Text = "Refresh";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += new global::System.EventHandler(this.button2_Click);
		this.txtSearch.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.txtSearch.Location = new global::System.Drawing.Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new global::System.Drawing.Size(273, 20);
		this.txtSearch.TabIndex = 11;
		this.txtSearch.String_0 = "Search";
		this.txtSearch.Color_0 = global::System.Drawing.Color.Gray;
		this.txtSearch.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtSearch.TextChanged += new global::System.EventHandler(this.txtSearch_TextChanged);
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.checkBox1.Location = new global::System.Drawing.Point(0, 312);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new global::System.Drawing.Size(273, 17);
		this.checkBox1.TabIndex = 12;
		this.checkBox1.Text = "Tuyên Chiến Và Tấn Công";
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += new global::System.EventHandler(this.checkBox1_CheckedChanged);
		this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.label1.AutoSize = true;
		this.label1.Location = new global::System.Drawing.Point(193, 314);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(80, 13);
		this.label1.TabIndex = 14;
		this.label1.Text = "Chọn Nhân Vật";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(273, 329);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.listViewName);
		base.Controls.Add(this.txtSearch);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.checkBox1);
		base.MaximizeBox = false;
		base.Name = "AutoPK";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Tuyên Chiến";
		base.Load += new global::System.EventHandler(this.AutoPK_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040008EC RID: 2284
	private global::_i.ListViewEx listViewName;

	// Token: 0x040008ED RID: 2285
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x040008EE RID: 2286
	private global::System.Windows.Forms.Button button2;

	// Token: 0x040008EF RID: 2287
	private global::Class85 txtSearch;

	// Token: 0x040008F0 RID: 2288
	private global::System.Windows.Forms.CheckBox checkBox1;

	// Token: 0x040008F1 RID: 2289
	private global::System.Windows.Forms.Label label1;
}
