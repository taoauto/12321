﻿using System;
using System.Collections.Generic;
using System.Linq;

// Token: 0x020001C2 RID: 450
internal class Class196
{
	// Token: 0x170005F6 RID: 1526
	// (get) Token: 0x06001880 RID: 6272 RVA: 0x00011F38 File Offset: 0x00010138
	// (set) Token: 0x06001881 RID: 6273 RVA: 0x000B20FC File Offset: 0x000B02FC
	public uint UInt32_0
	{
		get
		{
			return this.class159_0.Class405_0.method_17(this.class159_0.Class392_0.UInt32_54[0], 885532U);
		}
		set
		{
			this.class159_0.Class405_0.method_37(this.class159_0.Class405_0.method_43(this.class159_0.Class392_0.UInt32_54[0], 885528U), 2);
			this.class159_0.Class405_0.method_37(this.class159_0.Class405_0.method_43(this.class159_0.Class392_0.UInt32_54[0], 885532U), (int)value);
		}
	}

	// Token: 0x06001882 RID: 6274 RVA: 0x00011F61 File Offset: 0x00010161
	public Class196(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x170005F7 RID: 1527
	// (get) Token: 0x06001883 RID: 6275 RVA: 0x00011F70 File Offset: 0x00010170
	public IEnumerable<Class209> IEnumerable_0
	{
		get
		{
			return this.IEnumerable_1.Concat(this.IEnumerable_2).Concat(this.IEnumerable_3);
		}
	}

	// Token: 0x170005F8 RID: 1528
	public Class209 this[uint uint_0]
	{
		get
		{
			uint num = this.class159_0.Class405_0.method_20(this.class159_0.Class392_0.UInt32_54);
			if (this.class159_0.Class405_0.method_11(num + uint_0 * 4U) != 0U)
			{
				return new Class209(this.class159_0, num + uint_0 * 4U);
			}
			return null;
		}
	}

	// Token: 0x170005F9 RID: 1529
	// (get) Token: 0x06001885 RID: 6277 RVA: 0x00011F8E File Offset: 0x0001018E
	public IEnumerable<Class209> IEnumerable_1
	{
		get
		{
			Class196.Class197 @class = new Class196.Class197(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x170005FA RID: 1530
	// (get) Token: 0x06001886 RID: 6278 RVA: 0x00011F9E File Offset: 0x0001019E
	public IEnumerable<Class209> IEnumerable_2
	{
		get
		{
			Class196.Class198 @class = new Class196.Class198(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x170005FB RID: 1531
	// (get) Token: 0x06001887 RID: 6279 RVA: 0x00011FAE File Offset: 0x000101AE
	public IEnumerable<Class209> IEnumerable_3
	{
		get
		{
			Class196.Class199 @class = new Class196.Class199(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x170005FC RID: 1532
	// (get) Token: 0x06001888 RID: 6280 RVA: 0x00011FBE File Offset: 0x000101BE
	public IEnumerable<Class209> IEnumerable_4
	{
		get
		{
			Class196.Class200 @class = new Class196.Class200(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x170005FD RID: 1533
	// (get) Token: 0x06001889 RID: 6281 RVA: 0x00011FCE File Offset: 0x000101CE
	public IEnumerable<uint> IEnumerable_5
	{
		get
		{
			Class196.Class201 @class = new Class196.Class201(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x170005FE RID: 1534
	// (get) Token: 0x0600188A RID: 6282 RVA: 0x000B21D4 File Offset: 0x000B03D4
	public Class209 Class209_0
	{
		get
		{
			uint num = this.class159_0.Class405_0.method_20(new uint[]
			{
				this.class159_0.Class392_0.UInt32_142[0],
				this.class159_0.Class392_0.UInt32_142[1]
			});
			if (this.class159_0.Class405_0.method_11(num) != 0U)
			{
				return new Class209(this.class159_0, num);
			}
			return null;
		}
	}

	// Token: 0x170005FF RID: 1535
	// (get) Token: 0x0600188B RID: 6283 RVA: 0x00011FDE File Offset: 0x000101DE
	public IEnumerable<Class209> IEnumerable_6
	{
		get
		{
			Class196.Class202 @class = new Class196.Class202(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000600 RID: 1536
	// (get) Token: 0x0600188C RID: 6284 RVA: 0x00011FEE File Offset: 0x000101EE
	public IEnumerable<Class209> IEnumerable_7
	{
		get
		{
			Class196.Class203 @class = new Class196.Class203(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000601 RID: 1537
	// (get) Token: 0x0600188D RID: 6285 RVA: 0x00011FFE File Offset: 0x000101FE
	public IEnumerable<Class209> IEnumerable_8
	{
		get
		{
			Class196.Class204 @class = new Class196.Class204(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000602 RID: 1538
	// (get) Token: 0x0600188E RID: 6286 RVA: 0x0001200E File Offset: 0x0001020E
	public IEnumerable<Class209> IEnumerable_9
	{
		get
		{
			Class196.Class205 @class = new Class196.Class205(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000603 RID: 1539
	// (get) Token: 0x0600188F RID: 6287 RVA: 0x0001201E File Offset: 0x0001021E
	public IEnumerable<Class209> IEnumerable_10
	{
		get
		{
			Class196.Class206 @class = new Class196.Class206(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000604 RID: 1540
	// (get) Token: 0x06001890 RID: 6288 RVA: 0x0001202E File Offset: 0x0001022E
	public IEnumerable<Class209> IEnumerable_11
	{
		get
		{
			Class196.Class207 @class = new Class196.Class207(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x17000605 RID: 1541
	// (get) Token: 0x06001891 RID: 6289 RVA: 0x0001203E File Offset: 0x0001023E
	public IEnumerable<Class209> IEnumerable_12
	{
		get
		{
			Class196.Class208 @class = new Class196.Class208(-2);
			@class.class196_0 = this;
			return @class;
		}
	}

	// Token: 0x04000E5C RID: 3676
	public Class159 class159_0;
}
