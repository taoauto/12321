﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

// Token: 0x02000034 RID: 52
public class GClass19 : GClass16
{
	// Token: 0x06000249 RID: 585 RVA: 0x000048A1 File Offset: 0x00002AA1
	public GClass19() : this(null)
	{
	}

	// Token: 0x0600024A RID: 586 RVA: 0x000048AA File Offset: 0x00002AAA
	public GClass19(string string_3) : this(string_3, 1080)
	{
	}

	// Token: 0x0600024B RID: 587 RVA: 0x000048B8 File Offset: 0x00002AB8
	public GClass19(string string_3, int int_4) : this(string_3, int_4, string.Empty)
	{
	}

	// Token: 0x0600024C RID: 588 RVA: 0x000048C7 File Offset: 0x00002AC7
	public GClass19(string string_3, int int_4, string string_4) : base(GEnum4.Socks4, string_3, int_4, string_4, null)
	{
	}

	// Token: 0x0600024D RID: 589 RVA: 0x000048D4 File Offset: 0x00002AD4
	public static GClass19 smethod_2(string string_3)
	{
		return GClass16.smethod_0(GEnum4.Socks4, string_3) as GClass19;
	}

	// Token: 0x0600024E RID: 590 RVA: 0x0002748C File Offset: 0x0002568C
	public static bool smethod_3(string string_3, out GClass19 gclass19_0)
	{
		GClass16 gclass;
		if (GClass16.smethod_1(GEnum4.Socks4, string_3, out gclass))
		{
			gclass19_0 = (gclass as GClass19);
			return true;
		}
		gclass19_0 = null;
		return false;
	}

	// Token: 0x0600024F RID: 591 RVA: 0x000274B4 File Offset: 0x000256B4
	public override TcpClient \u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string string_3, int int_4, TcpClient tcpClient_0 = null)
	{
		base.method_1();
		if (string_3 == null)
		{
			throw new ArgumentNullException("destinationHost");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("destinationHost");
		}
		if (!Class13.smethod_5(int_4))
		{
			throw Class13.smethod_4("destinationPort");
		}
		TcpClient tcpClient = tcpClient_0;
		if (tcpClient == null)
		{
			tcpClient = base.method_0();
		}
		try
		{
			this.GClass19.\u206A\u200C\u206D\u202B\u206F\u206D\u202D\u206F\u200E\u206A\u200D\u206D\u202C\u202E\u202A\u202C\u206F\u206D\u200D\u202C\u206A\u202D\u206C\u206E\u202E\u202A\u202B\u206A\u200B\u206D\u206A\u206B\u202D\u206B\u206D\u200D\u206E\u206B\u206E\u206C\u202E(tcpClient.GetStream(), 1, string_3, int_4);
		}
		catch (Exception ex)
		{
			tcpClient.Close();
			if (!(ex is IOException) && !(ex is SocketException))
			{
				throw;
			}
			throw base.method_2(Class2.String_41, ex);
		}
		return tcpClient;
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00027550 File Offset: 0x00025750
	protected internal virtual void \u206A\u200C\u206D\u202B\u206F\u206D\u202D\u206F\u200E\u206A\u200D\u206D\u202C\u202E\u202A\u202C\u206F\u206D\u200D\u202C\u206A\u202D\u206C\u206E\u202E\u202A\u202B\u206A\u200B\u206D\u206A\u206B\u202D\u206B\u206D\u200D\u206E\u206B\u206E\u206C\u202E(NetworkStream networkStream_0, byte byte_7, string string_3, int int_4)
	{
		Array array = this.method_3(string_3);
		Array array2 = this.method_4(int_4);
		byte[] array3 = string.IsNullOrEmpty(this.string_1) ? new byte[0] : Encoding.ASCII.GetBytes(this.string_1);
		byte[] array4 = new byte[9 + array3.Length];
		array4[0] = 4;
		array4[1] = byte_7;
		array2.CopyTo(array4, 2);
		array.CopyTo(array4, 4);
		array3.CopyTo(array4, 8);
		array4[8 + array3.Length] = 0;
		networkStream_0.Write(array4, 0, array4.Length);
		byte[] array5 = new byte[8];
		networkStream_0.Read(array5, 0, array5.Length);
		byte b = array5[1];
		if (b != 90)
		{
			this.method_5(b);
		}
	}

	// Token: 0x06000251 RID: 593 RVA: 0x000275F4 File Offset: 0x000257F4
	protected internal byte[] method_3(string string_3)
	{
		IPAddress ipaddress = null;
		if (!IPAddress.TryParse(string_3, out ipaddress))
		{
			try
			{
				IPAddress[] hostAddresses = Dns.GetHostAddresses(string_3);
				if (hostAddresses.Length != 0)
				{
					ipaddress = hostAddresses[0];
				}
			}
			catch (Exception ex)
			{
				if (!(ex is SocketException) && !(ex is ArgumentException))
				{
					throw;
				}
				throw new GException2(string.Format(Class2.String_43, string_3), this, ex);
			}
		}
		return ipaddress.GetAddressBytes();
	}

	// Token: 0x06000252 RID: 594 RVA: 0x000048E2 File Offset: 0x00002AE2
	protected internal byte[] method_4(int int_4)
	{
		return new byte[]
		{
			(byte)(int_4 / 256),
			(byte)(int_4 % 256)
		};
	}

	// Token: 0x06000253 RID: 595 RVA: 0x0002765C File Offset: 0x0002585C
	protected internal void method_5(byte byte_7)
	{
		string arg;
		switch (byte_7)
		{
		case 91:
			arg = Class2.String_53;
			break;
		case 92:
			arg = Class2.String_51;
			break;
		case 93:
			arg = Class2.String_52;
			break;
		default:
			arg = Class2.String_50;
			break;
		}
		throw new GException2(string.Format(Class2.String_38, arg, this.ToString()), this, null);
	}

	// Token: 0x04000142 RID: 322
	protected internal const int int_3 = 1080;

	// Token: 0x04000143 RID: 323
	protected internal const byte byte_0 = 4;

	// Token: 0x04000144 RID: 324
	protected internal const byte byte_1 = 1;

	// Token: 0x04000145 RID: 325
	protected internal const byte byte_2 = 2;

	// Token: 0x04000146 RID: 326
	protected internal const byte byte_3 = 90;

	// Token: 0x04000147 RID: 327
	protected internal const byte byte_4 = 91;

	// Token: 0x04000148 RID: 328
	protected internal const byte byte_5 = 92;

	// Token: 0x04000149 RID: 329
	protected internal const byte byte_6 = 93;
}
