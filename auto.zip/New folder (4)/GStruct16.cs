﻿using System;

// Token: 0x02000187 RID: 391
[Serializable]
public struct GStruct16
{
	// Token: 0x04000A09 RID: 2569
	public GStruct17 u1;
}
