﻿using System;

// Token: 0x020000EB RID: 235
public enum GEnum11
{
	// Token: 0x040005C4 RID: 1476
	WordWrapControlWidth,
	// Token: 0x040005C5 RID: 1477
	WordWrapPreferredWidth,
	// Token: 0x040005C6 RID: 1478
	CharWrapControlWidth,
	// Token: 0x040005C7 RID: 1479
	CharWrapPreferredWidth,
	// Token: 0x040005C8 RID: 1480
	Custom
}
