﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

// Token: 0x02000218 RID: 536
internal class Class246
{
	// Token: 0x06001BFF RID: 7167 RVA: 0x000143EC File Offset: 0x000125EC
	public Class246(int int_1)
	{
		this.int_0 = int_1;
		this.intptr_0 = Class246.OpenProcess(2035711, false, int_1);
	}

	// Token: 0x06001C00 RID: 7168 RVA: 0x000D4420 File Offset: 0x000D2620
	public int method_0()
	{
		this.string_0 += "33C0C20400";
		this.byte_0 = new byte[this.string_0.Length / 2];
		for (int i = 0; i < this.string_0.Length / 2; i++)
		{
			this.byte_0[i] = this.method_2(this.string_0.Substring(i * 2, 2));
		}
		int num = Class246.VirtualAllocEx(this.intptr_0, 0, this.byte_0.Length, 4096U, 64U);
		Class246.WriteProcessMemory(this.intptr_0, num, this.byte_0, this.byte_0.Length, 0);
		Class246.CloseHandle(Class246.CreateRemoteThread(this.intptr_0, 0, 0, num, 0, 0, 0));
		return num;
	}

	// Token: 0x06001C01 RID: 7169 RVA: 0x000D44E0 File Offset: 0x000D26E0
	public string method_1(uint uint_0, int int_1)
	{
		string text = uint_0.ToString("X8");
		text = text.Substring(8 - int_1);
		string text2 = "";
		for (int i = 0; i < text.Length / 2; i++)
		{
			text2 += text.Substring(text.Length - i * 2 - 2, 2);
		}
		return text2;
	}

	// Token: 0x06001C02 RID: 7170 RVA: 0x000D4538 File Offset: 0x000D2738
	public byte method_2(string string_1)
	{
		byte result = 0;
		byte.TryParse(string_1, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x06001C03 RID: 7171 RVA: 0x00014418 File Offset: 0x00012618
	public void method_3()
	{
		this.string_0 += "C9";
	}

	// Token: 0x06001C04 RID: 7172 RVA: 0x00014430 File Offset: 0x00012630
	public void method_4()
	{
		this.string_0 += "60";
	}

	// Token: 0x06001C05 RID: 7173 RVA: 0x00014448 File Offset: 0x00012648
	public void method_5()
	{
		this.string_0 += "61";
	}

	// Token: 0x06001C06 RID: 7174 RVA: 0x00014460 File Offset: 0x00012660
	public void method_6()
	{
		this.string_0 += "90";
	}

	// Token: 0x06001C07 RID: 7175 RVA: 0x00014478 File Offset: 0x00012678
	public void method_7()
	{
		this.string_0 += "C3";
	}

	// Token: 0x06001C08 RID: 7176 RVA: 0x00014490 File Offset: 0x00012690
	public void method_8(uint uint_0)
	{
		this.string_0 += this.method_1(uint_0, 4);
	}

	// Token: 0x06001C09 RID: 7177 RVA: 0x000144AB File Offset: 0x000126AB
	public void method_9()
	{
		this.string_0 += "EC";
	}

	// Token: 0x06001C0A RID: 7178 RVA: 0x000144C3 File Offset: 0x000126C3
	public void method_10()
	{
		this.string_0 += "85C0";
	}

	// Token: 0x06001C0B RID: 7179 RVA: 0x000144DB File Offset: 0x000126DB
	public void method_11()
	{
		this.string_0 += "03C2";
	}

	// Token: 0x06001C0C RID: 7180 RVA: 0x000144F3 File Offset: 0x000126F3
	public void method_12()
	{
		this.string_0 += "03D8";
	}

	// Token: 0x06001C0D RID: 7181 RVA: 0x0001450B File Offset: 0x0001270B
	public void method_13(uint uint_0)
	{
		this.string_0 = this.string_0 + "0305" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C0E RID: 7182 RVA: 0x0001452B File Offset: 0x0001272B
	public void method_14(uint uint_0)
	{
		this.string_0 = this.string_0 + "031D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C0F RID: 7183 RVA: 0x0001454B File Offset: 0x0001274B
	public void method_15(uint uint_0)
	{
		this.string_0 = this.string_0 + "032D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C10 RID: 7184 RVA: 0x0001456B File Offset: 0x0001276B
	public void method_16(uint uint_0)
	{
		this.string_0 = this.string_0 + "05" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C11 RID: 7185 RVA: 0x0001458B File Offset: 0x0001278B
	public void method_17(uint uint_0)
	{
		this.string_0 = this.string_0 + "83C3" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C12 RID: 7186 RVA: 0x000145AB File Offset: 0x000127AB
	public void method_18(uint uint_0)
	{
		this.string_0 = this.string_0 + "83C1" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C13 RID: 7187 RVA: 0x000145CB File Offset: 0x000127CB
	public void method_19(uint uint_0)
	{
		this.string_0 = this.string_0 + "83C2" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C14 RID: 7188 RVA: 0x000145EB File Offset: 0x000127EB
	public void method_20(uint uint_0)
	{
		this.string_0 = this.string_0 + "83C6" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C15 RID: 7189 RVA: 0x0001460B File Offset: 0x0001280B
	public void method_21(uint uint_0)
	{
		this.string_0 = this.string_0 + "83C4" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C16 RID: 7190 RVA: 0x0001462B File Offset: 0x0001282B
	public void method_22()
	{
		this.string_0 += "FFD0";
	}

	// Token: 0x06001C17 RID: 7191 RVA: 0x00014643 File Offset: 0x00012843
	public void method_23()
	{
		this.string_0 += "FFD3";
	}

	// Token: 0x06001C18 RID: 7192 RVA: 0x0001465B File Offset: 0x0001285B
	public void method_24()
	{
		this.string_0 += "FFD1";
	}

	// Token: 0x06001C19 RID: 7193 RVA: 0x00014673 File Offset: 0x00012873
	public void method_25()
	{
		this.string_0 += "FFD2";
	}

	// Token: 0x06001C1A RID: 7194 RVA: 0x00014673 File Offset: 0x00012873
	public void method_26()
	{
		this.string_0 += "FFD2";
	}

	// Token: 0x06001C1B RID: 7195 RVA: 0x0001468B File Offset: 0x0001288B
	public void method_27()
	{
		this.string_0 += "FFD4";
	}

	// Token: 0x06001C1C RID: 7196 RVA: 0x000146A3 File Offset: 0x000128A3
	public void method_28()
	{
		this.string_0 += "FFD5";
	}

	// Token: 0x06001C1D RID: 7197 RVA: 0x000146BB File Offset: 0x000128BB
	public void method_29()
	{
		this.string_0 += "FFD7";
	}

	// Token: 0x06001C1E RID: 7198 RVA: 0x000146D3 File Offset: 0x000128D3
	public void method_30(uint uint_0)
	{
		this.string_0 = this.string_0 + "FF15" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C1F RID: 7199 RVA: 0x000146F3 File Offset: 0x000128F3
	public void method_31()
	{
		this.string_0 += "FF10";
	}

	// Token: 0x06001C20 RID: 7200 RVA: 0x0001470B File Offset: 0x0001290B
	public void method_32()
	{
		this.string_0 += "FF13";
	}

	// Token: 0x06001C21 RID: 7201 RVA: 0x00014723 File Offset: 0x00012923
	public void method_33(uint uint_0)
	{
		this.string_0 = this.string_0 + "FF52" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C22 RID: 7202 RVA: 0x000D455C File Offset: 0x000D275C
	public void method_34(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "83F8" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "3D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C23 RID: 7203 RVA: 0x00014743 File Offset: 0x00012943
	public void method_35()
	{
		this.string_0 += "3BC2";
	}

	// Token: 0x06001C24 RID: 7204 RVA: 0x0001475B File Offset: 0x0001295B
	public void method_36(uint uint_0)
	{
		this.string_0 = this.string_0 + "3B05" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C25 RID: 7205 RVA: 0x0001477B File Offset: 0x0001297B
	public void method_37(uint uint_0)
	{
		this.string_0 = this.string_0 + "3905" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C26 RID: 7206 RVA: 0x0001479B File Offset: 0x0001299B
	public void method_38()
	{
		this.string_0 += "48";
	}

	// Token: 0x06001C27 RID: 7207 RVA: 0x000147B3 File Offset: 0x000129B3
	public void method_39()
	{
		this.string_0 += "4B";
	}

	// Token: 0x06001C28 RID: 7208 RVA: 0x000147CB File Offset: 0x000129CB
	public void method_40()
	{
		this.string_0 += "49";
	}

	// Token: 0x06001C29 RID: 7209 RVA: 0x000147E3 File Offset: 0x000129E3
	public void method_41()
	{
		this.string_0 += "4A";
	}

	// Token: 0x06001C2A RID: 7210 RVA: 0x000147FB File Offset: 0x000129FB
	public void method_42()
	{
		this.string_0 += "F7F8";
	}

	// Token: 0x06001C2B RID: 7211 RVA: 0x00014813 File Offset: 0x00012A13
	public void method_43()
	{
		this.string_0 += "F7FB";
	}

	// Token: 0x06001C2C RID: 7212 RVA: 0x0001482B File Offset: 0x00012A2B
	public void method_44()
	{
		this.string_0 += "F7F9";
	}

	// Token: 0x06001C2D RID: 7213 RVA: 0x00014843 File Offset: 0x00012A43
	public void method_45()
	{
		this.string_0 += "F7FA";
	}

	// Token: 0x06001C2E RID: 7214 RVA: 0x0001485B File Offset: 0x00012A5B
	public void method_46()
	{
		this.string_0 += "0FAFC2";
	}

	// Token: 0x06001C2F RID: 7215 RVA: 0x00014873 File Offset: 0x00012A73
	public void method_47(uint uint_0)
	{
		this.string_0 = this.string_0 + "6BC0" + this.method_1(uint_0, 2);
	}

	// Token: 0x06001C30 RID: 7216 RVA: 0x00014893 File Offset: 0x00012A93
	public void method_48(uint uint_0)
	{
		this.string_0 = this.string_0 + "69C0" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C31 RID: 7217 RVA: 0x000148B3 File Offset: 0x00012AB3
	public void method_49()
	{
		this.string_0 += "40";
	}

	// Token: 0x06001C32 RID: 7218 RVA: 0x000148CB File Offset: 0x00012ACB
	public void method_50()
	{
		this.string_0 += "43";
	}

	// Token: 0x06001C33 RID: 7219 RVA: 0x000148E3 File Offset: 0x00012AE3
	public void method_51()
	{
		this.string_0 += "41";
	}

	// Token: 0x06001C34 RID: 7220 RVA: 0x000148FB File Offset: 0x00012AFB
	public void method_52()
	{
		this.string_0 += "42";
	}

	// Token: 0x06001C35 RID: 7221 RVA: 0x00014913 File Offset: 0x00012B13
	public void method_53()
	{
		this.string_0 += "47";
	}

	// Token: 0x06001C36 RID: 7222 RVA: 0x0001492B File Offset: 0x00012B2B
	public void method_54()
	{
		this.string_0 += "46";
	}

	// Token: 0x06001C37 RID: 7223 RVA: 0x00014943 File Offset: 0x00012B43
	public void method_55()
	{
		this.string_0 += "FF00";
	}

	// Token: 0x06001C38 RID: 7224 RVA: 0x0001495B File Offset: 0x00012B5B
	public void method_56()
	{
		this.string_0 += "FF03";
	}

	// Token: 0x06001C39 RID: 7225 RVA: 0x00014973 File Offset: 0x00012B73
	public void method_57()
	{
		this.string_0 += "FF01";
	}

	// Token: 0x06001C3A RID: 7226 RVA: 0x0001498B File Offset: 0x00012B8B
	public void method_58()
	{
		this.string_0 += "FF02";
	}

	// Token: 0x06001C3B RID: 7227 RVA: 0x000149A3 File Offset: 0x00012BA3
	public void method_59()
	{
		this.string_0 += "FFE0";
	}

	// Token: 0x06001C3C RID: 7228 RVA: 0x000149BB File Offset: 0x00012BBB
	public void method_60(uint uint_0)
	{
		this.string_0 = this.string_0 + "A3" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C3D RID: 7229 RVA: 0x000149DB File Offset: 0x00012BDB
	public void method_61(uint uint_0)
	{
		this.string_0 = this.string_0 + "B8" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C3E RID: 7230 RVA: 0x000149FB File Offset: 0x00012BFB
	public void method_62(uint uint_0)
	{
		this.string_0 = this.string_0 + "BB" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C3F RID: 7231 RVA: 0x00014A1B File Offset: 0x00012C1B
	public void method_63(uint uint_0)
	{
		this.string_0 = this.string_0 + "B9" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C40 RID: 7232 RVA: 0x00014A3B File Offset: 0x00012C3B
	public void method_64(uint uint_0)
	{
		this.string_0 = this.string_0 + "BA" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C41 RID: 7233 RVA: 0x00014A5B File Offset: 0x00012C5B
	public void method_65(uint uint_0)
	{
		this.string_0 = this.string_0 + "BE" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C42 RID: 7234 RVA: 0x00014A7B File Offset: 0x00012C7B
	public void method_66(uint uint_0)
	{
		this.string_0 = this.string_0 + "BC" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C43 RID: 7235 RVA: 0x00014A9B File Offset: 0x00012C9B
	public void method_67(uint uint_0)
	{
		this.string_0 = this.string_0 + "BD" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C44 RID: 7236 RVA: 0x00014ABB File Offset: 0x00012CBB
	public void method_68(uint uint_0)
	{
		this.string_0 = this.string_0 + "BF" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C45 RID: 7237 RVA: 0x00014ADB File Offset: 0x00012CDB
	public void method_69(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B1D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C46 RID: 7238 RVA: 0x00014AFB File Offset: 0x00012CFB
	public void method_70(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B0D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C47 RID: 7239 RVA: 0x00014B1B File Offset: 0x00012D1B
	public void method_71(uint uint_0)
	{
		this.string_0 = this.string_0 + "A1" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C48 RID: 7240 RVA: 0x00014B3B File Offset: 0x00012D3B
	public void method_72(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B15" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C49 RID: 7241 RVA: 0x00014B5B File Offset: 0x00012D5B
	public void method_73(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B35" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C4A RID: 7242 RVA: 0x00014B7B File Offset: 0x00012D7B
	public void method_74(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B25" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C4B RID: 7243 RVA: 0x00014B9B File Offset: 0x00012D9B
	public void method_75(uint uint_0)
	{
		this.string_0 = this.string_0 + "8B2D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C4C RID: 7244 RVA: 0x00014BBB File Offset: 0x00012DBB
	public void method_76()
	{
		this.string_0 += "8B00";
	}

	// Token: 0x06001C4D RID: 7245 RVA: 0x00014BD3 File Offset: 0x00012DD3
	public void method_77()
	{
		this.string_0 += "8B4500";
	}

	// Token: 0x06001C4E RID: 7246 RVA: 0x00014BEB File Offset: 0x00012DEB
	public void method_78()
	{
		this.string_0 += "8B03";
	}

	// Token: 0x06001C4F RID: 7247 RVA: 0x00014C03 File Offset: 0x00012E03
	public void method_79()
	{
		this.string_0 += "8B01";
	}

	// Token: 0x06001C50 RID: 7248 RVA: 0x00014C1B File Offset: 0x00012E1B
	public void method_80()
	{
		this.string_0 += "8B02";
	}

	// Token: 0x06001C51 RID: 7249 RVA: 0x00014C33 File Offset: 0x00012E33
	public void method_81()
	{
		this.string_0 += "8B07";
	}

	// Token: 0x06001C52 RID: 7250 RVA: 0x00014C4B File Offset: 0x00012E4B
	public void method_82()
	{
		this.string_0 += "8B0424";
	}

	// Token: 0x06001C53 RID: 7251 RVA: 0x00014C63 File Offset: 0x00012E63
	public void method_83()
	{
		this.string_0 += "8B06";
	}

	// Token: 0x06001C54 RID: 7252 RVA: 0x000D45B0 File Offset: 0x000D27B0
	public void method_84(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B40" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B80" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C55 RID: 7253 RVA: 0x000D4604 File Offset: 0x000D2804
	public void method_85(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4424" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8424" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C56 RID: 7254 RVA: 0x000D4658 File Offset: 0x000D2858
	public void method_86(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B43" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B83" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C57 RID: 7255 RVA: 0x000D46AC File Offset: 0x000D28AC
	public void method_87(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B41" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B81" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C58 RID: 7256 RVA: 0x000D4700 File Offset: 0x000D2900
	public void method_88(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B42" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B82" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C59 RID: 7257 RVA: 0x000D4754 File Offset: 0x000D2954
	public void method_89(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B47" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B87" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5A RID: 7258 RVA: 0x000D47A8 File Offset: 0x000D29A8
	public void method_90(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B45" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B85" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5B RID: 7259 RVA: 0x000D47FC File Offset: 0x000D29FC
	public void method_91(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B46" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B86" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5C RID: 7260 RVA: 0x000D4850 File Offset: 0x000D2A50
	public void method_92(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B58" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B98" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5D RID: 7261 RVA: 0x000D48A4 File Offset: 0x000D2AA4
	public void method_93(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5C24" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9C24" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5E RID: 7262 RVA: 0x000D48F8 File Offset: 0x000D2AF8
	public void method_94(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5B" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9B" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C5F RID: 7263 RVA: 0x000D494C File Offset: 0x000D2B4C
	public void method_95(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B59" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B99" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C60 RID: 7264 RVA: 0x000D49A0 File Offset: 0x000D2BA0
	public void method_96(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5A" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9A" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C61 RID: 7265 RVA: 0x000D49F4 File Offset: 0x000D2BF4
	public void method_97(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5F" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9F" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C62 RID: 7266 RVA: 0x000D4A48 File Offset: 0x000D2C48
	public void method_98(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5D" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C63 RID: 7267 RVA: 0x000D4A9C File Offset: 0x000D2C9C
	public void method_99(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5E" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9E" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C64 RID: 7268 RVA: 0x000D4AF0 File Offset: 0x000D2CF0
	public void method_100(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B48" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B88" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C65 RID: 7269 RVA: 0x000D4B44 File Offset: 0x000D2D44
	public void method_101(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4C24" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8C24" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C66 RID: 7270 RVA: 0x000D4B98 File Offset: 0x000D2D98
	public void method_102(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4B" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8B" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C67 RID: 7271 RVA: 0x000D4BEC File Offset: 0x000D2DEC
	public void method_103(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B49" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B89" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C68 RID: 7272 RVA: 0x000D4C40 File Offset: 0x000D2E40
	public void method_104(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4A" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8A" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C69 RID: 7273 RVA: 0x000D4C94 File Offset: 0x000D2E94
	public void method_105(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4F" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8F" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6A RID: 7274 RVA: 0x000D4CE8 File Offset: 0x000D2EE8
	public void method_106(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4D" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6B RID: 7275 RVA: 0x000D4D3C File Offset: 0x000D2F3C
	public void method_107(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B4E" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B8E" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6C RID: 7276 RVA: 0x000D4D90 File Offset: 0x000D2F90
	public void method_108(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B50" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B90" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6D RID: 7277 RVA: 0x000D4DE4 File Offset: 0x000D2FE4
	public void method_109(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B5424" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B9424" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6E RID: 7278 RVA: 0x000D4E38 File Offset: 0x000D3038
	public void method_110(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B53" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B93" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C6F RID: 7279 RVA: 0x000D4E8C File Offset: 0x000D308C
	public void method_111(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B51" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B91" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C70 RID: 7280 RVA: 0x000D4EE0 File Offset: 0x000D30E0
	public void method_112(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B52" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B92" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C71 RID: 7281 RVA: 0x000D4F34 File Offset: 0x000D3134
	public void method_113(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B57" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B97" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C72 RID: 7282 RVA: 0x000D4F88 File Offset: 0x000D3188
	public void method_114(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B55" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B95" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C73 RID: 7283 RVA: 0x000D4FDC File Offset: 0x000D31DC
	public void method_115(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8B56" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8B96" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001C74 RID: 7284 RVA: 0x00014C7B File Offset: 0x00012E7B
	public void method_116()
	{
		this.string_0 += "8B18";
	}

	// Token: 0x06001C75 RID: 7285 RVA: 0x00014C93 File Offset: 0x00012E93
	public void method_117()
	{
		this.string_0 += "8B5D00";
	}

	// Token: 0x06001C76 RID: 7286 RVA: 0x00014CAB File Offset: 0x00012EAB
	public void method_118()
	{
		this.string_0 += "8B1B";
	}

	// Token: 0x06001C77 RID: 7287 RVA: 0x00014CC3 File Offset: 0x00012EC3
	public void method_119()
	{
		this.string_0 += "8B19";
	}

	// Token: 0x06001C78 RID: 7288 RVA: 0x00014CDB File Offset: 0x00012EDB
	public void method_120()
	{
		this.string_0 += "8B1A";
	}

	// Token: 0x06001C79 RID: 7289 RVA: 0x00014CF3 File Offset: 0x00012EF3
	public void method_121()
	{
		this.string_0 += "8B1F";
	}

	// Token: 0x06001C7A RID: 7290 RVA: 0x00014D0B File Offset: 0x00012F0B
	public void method_122()
	{
		this.string_0 += "8B1C24";
	}

	// Token: 0x06001C7B RID: 7291 RVA: 0x00014D23 File Offset: 0x00012F23
	public void method_123()
	{
		this.string_0 += "8B1E";
	}

	// Token: 0x06001C7C RID: 7292 RVA: 0x00014D3B File Offset: 0x00012F3B
	public void method_124()
	{
		this.string_0 += "8B08";
	}

	// Token: 0x06001C7D RID: 7293 RVA: 0x00014D53 File Offset: 0x00012F53
	public void method_125()
	{
		this.string_0 += "8B4D00";
	}

	// Token: 0x06001C7E RID: 7294 RVA: 0x00014D6B File Offset: 0x00012F6B
	public void method_126()
	{
		this.string_0 += "8B0B";
	}

	// Token: 0x06001C7F RID: 7295 RVA: 0x00014D83 File Offset: 0x00012F83
	public void method_127()
	{
		this.string_0 += "8B09";
	}

	// Token: 0x06001C80 RID: 7296 RVA: 0x00014D9B File Offset: 0x00012F9B
	public void method_128()
	{
		this.string_0 += "8B0A";
	}

	// Token: 0x06001C81 RID: 7297 RVA: 0x00014DB3 File Offset: 0x00012FB3
	public void method_129()
	{
		this.string_0 += "8B0F";
	}

	// Token: 0x06001C82 RID: 7298 RVA: 0x00014DCB File Offset: 0x00012FCB
	public void method_130()
	{
		this.string_0 += "8B0C24";
	}

	// Token: 0x06001C83 RID: 7299 RVA: 0x00014DE3 File Offset: 0x00012FE3
	public void method_131()
	{
		this.string_0 += "8B0E";
	}

	// Token: 0x06001C84 RID: 7300 RVA: 0x00014DFB File Offset: 0x00012FFB
	public void method_132()
	{
		this.string_0 += "8B10";
	}

	// Token: 0x06001C85 RID: 7301 RVA: 0x00014E13 File Offset: 0x00013013
	public void method_133()
	{
		this.string_0 += "8B5500";
	}

	// Token: 0x06001C86 RID: 7302 RVA: 0x00014E2B File Offset: 0x0001302B
	public void method_134()
	{
		this.string_0 += "8B13";
	}

	// Token: 0x06001C87 RID: 7303 RVA: 0x00014E43 File Offset: 0x00013043
	public void method_135()
	{
		this.string_0 += "8B11";
	}

	// Token: 0x06001C88 RID: 7304 RVA: 0x00014E5B File Offset: 0x0001305B
	public void method_136()
	{
		this.string_0 += "8B12";
	}

	// Token: 0x06001C89 RID: 7305 RVA: 0x00014E73 File Offset: 0x00013073
	public void method_137()
	{
		this.string_0 += "8B17";
	}

	// Token: 0x06001C8A RID: 7306 RVA: 0x00014E8B File Offset: 0x0001308B
	public void method_138()
	{
		this.string_0 += "8B16";
	}

	// Token: 0x06001C8B RID: 7307 RVA: 0x00014EA3 File Offset: 0x000130A3
	public void method_139()
	{
		this.string_0 += "8B1424";
	}

	// Token: 0x06001C8C RID: 7308 RVA: 0x00014EBB File Offset: 0x000130BB
	public void method_140()
	{
		this.string_0 += "8BC5";
	}

	// Token: 0x06001C8D RID: 7309 RVA: 0x00014ED3 File Offset: 0x000130D3
	public void method_141()
	{
		this.string_0 += "8BC3";
	}

	// Token: 0x06001C8E RID: 7310 RVA: 0x00014EEB File Offset: 0x000130EB
	public void method_142()
	{
		this.string_0 += "8BC1";
	}

	// Token: 0x06001C8F RID: 7311 RVA: 0x00014F03 File Offset: 0x00013103
	public void method_143()
	{
		this.string_0 += "8BC7";
	}

	// Token: 0x06001C90 RID: 7312 RVA: 0x00014F1B File Offset: 0x0001311B
	public void method_144()
	{
		this.string_0 += "8BC2";
	}

	// Token: 0x06001C91 RID: 7313 RVA: 0x00014F33 File Offset: 0x00013133
	public void method_145()
	{
		this.string_0 += "8BC6";
	}

	// Token: 0x06001C92 RID: 7314 RVA: 0x00014F4B File Offset: 0x0001314B
	public void method_146()
	{
		this.string_0 += "8BC4";
	}

	// Token: 0x06001C93 RID: 7315 RVA: 0x00014F63 File Offset: 0x00013163
	public void method_147()
	{
		this.string_0 += "8BDD";
	}

	// Token: 0x06001C94 RID: 7316 RVA: 0x00014F7B File Offset: 0x0001317B
	public void method_148()
	{
		this.string_0 += "8BD8";
	}

	// Token: 0x06001C95 RID: 7317 RVA: 0x00014F93 File Offset: 0x00013193
	public void method_149()
	{
		this.string_0 += "8BD9";
	}

	// Token: 0x06001C96 RID: 7318 RVA: 0x00014FAB File Offset: 0x000131AB
	public void method_150()
	{
		this.string_0 += "8BDF";
	}

	// Token: 0x06001C97 RID: 7319 RVA: 0x00014FC3 File Offset: 0x000131C3
	public void method_151()
	{
		this.string_0 += "8BDA";
	}

	// Token: 0x06001C98 RID: 7320 RVA: 0x00014FDB File Offset: 0x000131DB
	public void method_152()
	{
		this.string_0 += "8BDE";
	}

	// Token: 0x06001C99 RID: 7321 RVA: 0x00014FF3 File Offset: 0x000131F3
	public void method_153()
	{
		this.string_0 += "8BDC";
	}

	// Token: 0x06001C9A RID: 7322 RVA: 0x0001500B File Offset: 0x0001320B
	public void method_154()
	{
		this.string_0 += "8BCD";
	}

	// Token: 0x06001C9B RID: 7323 RVA: 0x00015023 File Offset: 0x00013223
	public void method_155()
	{
		this.string_0 += "8BC8";
	}

	// Token: 0x06001C9C RID: 7324 RVA: 0x0001503B File Offset: 0x0001323B
	public void method_156()
	{
		this.string_0 += "8BCB";
	}

	// Token: 0x06001C9D RID: 7325 RVA: 0x00015053 File Offset: 0x00013253
	public void method_157()
	{
		this.string_0 += "8BCF";
	}

	// Token: 0x06001C9E RID: 7326 RVA: 0x0001506B File Offset: 0x0001326B
	public void method_158()
	{
		this.string_0 += "8BCA";
	}

	// Token: 0x06001C9F RID: 7327 RVA: 0x00015083 File Offset: 0x00013283
	public void method_159()
	{
		this.string_0 += "8BCE";
	}

	// Token: 0x06001CA0 RID: 7328 RVA: 0x0001509B File Offset: 0x0001329B
	public void method_160()
	{
		this.string_0 += "8BCC";
	}

	// Token: 0x06001CA1 RID: 7329 RVA: 0x000150B3 File Offset: 0x000132B3
	public void method_161()
	{
		this.string_0 += "8BD5";
	}

	// Token: 0x06001CA2 RID: 7330 RVA: 0x000150CB File Offset: 0x000132CB
	public void method_162()
	{
		this.string_0 += "8BD3";
	}

	// Token: 0x06001CA3 RID: 7331 RVA: 0x000150E3 File Offset: 0x000132E3
	public void method_163()
	{
		this.string_0 += "8BD1";
	}

	// Token: 0x06001CA4 RID: 7332 RVA: 0x000150FB File Offset: 0x000132FB
	public void method_164()
	{
		this.string_0 += "8BD7";
	}

	// Token: 0x06001CA5 RID: 7333 RVA: 0x00015113 File Offset: 0x00013313
	public void method_165()
	{
		this.string_0 += "8BD0";
	}

	// Token: 0x06001CA6 RID: 7334 RVA: 0x0001512B File Offset: 0x0001332B
	public void method_166()
	{
		this.string_0 += "8BD6";
	}

	// Token: 0x06001CA7 RID: 7335 RVA: 0x00015143 File Offset: 0x00013343
	public void method_167()
	{
		this.string_0 += "8BD4";
	}

	// Token: 0x06001CA8 RID: 7336 RVA: 0x0001515B File Offset: 0x0001335B
	public void method_168()
	{
		this.string_0 += "8BF5";
	}

	// Token: 0x06001CA9 RID: 7337 RVA: 0x00015173 File Offset: 0x00013373
	public void method_169()
	{
		this.string_0 += "8BF3";
	}

	// Token: 0x06001CAA RID: 7338 RVA: 0x0001518B File Offset: 0x0001338B
	public void method_170()
	{
		this.string_0 += "8BF1";
	}

	// Token: 0x06001CAB RID: 7339 RVA: 0x000151A3 File Offset: 0x000133A3
	public void method_171()
	{
		this.string_0 += "8BF7";
	}

	// Token: 0x06001CAC RID: 7340 RVA: 0x000151BB File Offset: 0x000133BB
	public void method_172()
	{
		this.string_0 += "8BF0";
	}

	// Token: 0x06001CAD RID: 7341 RVA: 0x000151D3 File Offset: 0x000133D3
	public void method_173()
	{
		this.string_0 += "8BF2";
	}

	// Token: 0x06001CAE RID: 7342 RVA: 0x000151EB File Offset: 0x000133EB
	public void method_174()
	{
		this.string_0 += "8BF4";
	}

	// Token: 0x06001CAF RID: 7343 RVA: 0x00015203 File Offset: 0x00013403
	public void method_175()
	{
		this.string_0 += "8BE5";
	}

	// Token: 0x06001CB0 RID: 7344 RVA: 0x0001521B File Offset: 0x0001341B
	public void method_176()
	{
		this.string_0 += "8BE3";
	}

	// Token: 0x06001CB1 RID: 7345 RVA: 0x00015233 File Offset: 0x00013433
	public void method_177()
	{
		this.string_0 += "8BE1";
	}

	// Token: 0x06001CB2 RID: 7346 RVA: 0x0001524B File Offset: 0x0001344B
	public void method_178()
	{
		this.string_0 += "8BE7";
	}

	// Token: 0x06001CB3 RID: 7347 RVA: 0x00015263 File Offset: 0x00013463
	public void method_179()
	{
		this.string_0 += "8BE0";
	}

	// Token: 0x06001CB4 RID: 7348 RVA: 0x0001527B File Offset: 0x0001347B
	public void method_180()
	{
		this.string_0 += "8BE2";
	}

	// Token: 0x06001CB5 RID: 7349 RVA: 0x00015293 File Offset: 0x00013493
	public void method_181()
	{
		this.string_0 += "8BE6";
	}

	// Token: 0x06001CB6 RID: 7350 RVA: 0x000152AB File Offset: 0x000134AB
	public void method_182()
	{
		this.string_0 += "8BFD";
	}

	// Token: 0x06001CB7 RID: 7351 RVA: 0x000152C3 File Offset: 0x000134C3
	public void method_183()
	{
		this.string_0 += "8BF8";
	}

	// Token: 0x06001CB8 RID: 7352 RVA: 0x000152DB File Offset: 0x000134DB
	public void method_184()
	{
		this.string_0 += "8BFB";
	}

	// Token: 0x06001CB9 RID: 7353 RVA: 0x000152F3 File Offset: 0x000134F3
	public void method_185()
	{
		this.string_0 += "8BF9";
	}

	// Token: 0x06001CBA RID: 7354 RVA: 0x0001530B File Offset: 0x0001350B
	public void method_186()
	{
		this.string_0 += "8BFA";
	}

	// Token: 0x06001CBB RID: 7355 RVA: 0x00015323 File Offset: 0x00013523
	public void method_187()
	{
		this.string_0 += "8BFE";
	}

	// Token: 0x06001CBC RID: 7356 RVA: 0x0001533B File Offset: 0x0001353B
	public void method_188()
	{
		this.string_0 += "8BFC";
	}

	// Token: 0x06001CBD RID: 7357 RVA: 0x00014FAB File Offset: 0x000131AB
	public void method_189()
	{
		this.string_0 += "8BDF";
	}

	// Token: 0x06001CBE RID: 7358 RVA: 0x00015353 File Offset: 0x00013553
	public void method_190()
	{
		this.string_0 += "8BE8";
	}

	// Token: 0x06001CBF RID: 7359 RVA: 0x0001536B File Offset: 0x0001356B
	public void method_191()
	{
		this.string_0 += "8BEB";
	}

	// Token: 0x06001CC0 RID: 7360 RVA: 0x00015383 File Offset: 0x00013583
	public void method_192()
	{
		this.string_0 += "8BE9";
	}

	// Token: 0x06001CC1 RID: 7361 RVA: 0x0001539B File Offset: 0x0001359B
	public void method_193()
	{
		this.string_0 += "8BEA";
	}

	// Token: 0x06001CC2 RID: 7362 RVA: 0x000153B3 File Offset: 0x000135B3
	public void method_194()
	{
		this.string_0 += "8BEE";
	}

	// Token: 0x06001CC3 RID: 7363 RVA: 0x000153CB File Offset: 0x000135CB
	public void method_195()
	{
		this.string_0 += "8BEC";
	}

	// Token: 0x06001CC4 RID: 7364 RVA: 0x000153E3 File Offset: 0x000135E3
	public void method_196(uint uint_0)
	{
		this.string_0 = this.string_0 + "68" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CC5 RID: 7365 RVA: 0x00015403 File Offset: 0x00013603
	public void method_197(uint uint_0)
	{
		this.string_0 = this.string_0 + "FF35" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CC6 RID: 7366 RVA: 0x00015423 File Offset: 0x00013623
	public void method_198()
	{
		this.string_0 += "50";
	}

	// Token: 0x06001CC7 RID: 7367 RVA: 0x0001543B File Offset: 0x0001363B
	public void method_199()
	{
		this.string_0 += "51";
	}

	// Token: 0x06001CC8 RID: 7368 RVA: 0x00015453 File Offset: 0x00013653
	public void method_200()
	{
		this.string_0 += "52";
	}

	// Token: 0x06001CC9 RID: 7369 RVA: 0x0001546B File Offset: 0x0001366B
	public void method_201()
	{
		this.string_0 += "53";
	}

	// Token: 0x06001CCA RID: 7370 RVA: 0x00015483 File Offset: 0x00013683
	public void method_202()
	{
		this.string_0 += "54";
	}

	// Token: 0x06001CCB RID: 7371 RVA: 0x0001549B File Offset: 0x0001369B
	public void method_203()
	{
		this.string_0 += "55";
	}

	// Token: 0x06001CCC RID: 7372 RVA: 0x000154B3 File Offset: 0x000136B3
	public void method_204()
	{
		this.string_0 += "56";
	}

	// Token: 0x06001CCD RID: 7373 RVA: 0x000154CB File Offset: 0x000136CB
	public void method_205()
	{
		this.string_0 += "57";
	}

	// Token: 0x06001CCE RID: 7374 RVA: 0x000D5030 File Offset: 0x000D3230
	public void method_206(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D40" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D80" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CCF RID: 7375 RVA: 0x000D5084 File Offset: 0x000D3284
	public void method_207(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D43" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D83" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD0 RID: 7376 RVA: 0x000D50D8 File Offset: 0x000D32D8
	public void method_208(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D41" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D81" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD1 RID: 7377 RVA: 0x000D512C File Offset: 0x000D332C
	public void method_209(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D42" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D82" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD2 RID: 7378 RVA: 0x000D5180 File Offset: 0x000D3380
	public void method_210(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D46" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D86" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD3 RID: 7379 RVA: 0x000D5030 File Offset: 0x000D3230
	public void method_211(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D40" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D80" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD4 RID: 7380 RVA: 0x000D51D4 File Offset: 0x000D33D4
	public void method_212(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4424" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8424" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD5 RID: 7381 RVA: 0x000D5228 File Offset: 0x000D3428
	public void method_213(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D47" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D87" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD6 RID: 7382 RVA: 0x000D527C File Offset: 0x000D347C
	public void method_214(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D58" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D98" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD7 RID: 7383 RVA: 0x000D52D0 File Offset: 0x000D34D0
	public void method_215(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5C24" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9C24" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD8 RID: 7384 RVA: 0x000D5324 File Offset: 0x000D3524
	public void method_216(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5B" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9B" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CD9 RID: 7385 RVA: 0x000D5378 File Offset: 0x000D3578
	public void method_217(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D59" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D99" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDA RID: 7386 RVA: 0x000D53CC File Offset: 0x000D35CC
	public void method_218(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5A" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9A" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDB RID: 7387 RVA: 0x000D5420 File Offset: 0x000D3620
	public void method_219(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5F" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9F" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDC RID: 7388 RVA: 0x000D5474 File Offset: 0x000D3674
	public void method_220(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5D" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDD RID: 7389 RVA: 0x000D54C8 File Offset: 0x000D36C8
	public void method_221(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5E" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9E" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDE RID: 7390 RVA: 0x000D551C File Offset: 0x000D371C
	public void method_222(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D48" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D88" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CDF RID: 7391 RVA: 0x000D5570 File Offset: 0x000D3770
	public void method_223(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4C24" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8C24" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE0 RID: 7392 RVA: 0x000D55C4 File Offset: 0x000D37C4
	public void method_224(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4B" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8B" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE1 RID: 7393 RVA: 0x000D5618 File Offset: 0x000D3818
	public void method_225(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D49" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D89" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE2 RID: 7394 RVA: 0x000D566C File Offset: 0x000D386C
	public void method_226(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4A" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8A" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE3 RID: 7395 RVA: 0x000D56C0 File Offset: 0x000D38C0
	public void method_227(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4F" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8F" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE4 RID: 7396 RVA: 0x000D5714 File Offset: 0x000D3914
	public void method_228(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4D" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8D" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE5 RID: 7397 RVA: 0x000D5768 File Offset: 0x000D3968
	public void method_229(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D4E" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D8E" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE6 RID: 7398 RVA: 0x000D57BC File Offset: 0x000D39BC
	public void method_230(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D50" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D90" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE7 RID: 7399 RVA: 0x000D5810 File Offset: 0x000D3A10
	public void method_231(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D5424" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D9424" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE8 RID: 7400 RVA: 0x000D5864 File Offset: 0x000D3A64
	public void method_232(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D53" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D93" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CE9 RID: 7401 RVA: 0x000D58B8 File Offset: 0x000D3AB8
	public void method_233(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D51" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D91" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CEA RID: 7402 RVA: 0x000D590C File Offset: 0x000D3B0C
	public void method_234(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D52" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D92" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CEB RID: 7403 RVA: 0x000D5960 File Offset: 0x000D3B60
	public void method_235(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D57" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D97" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CEC RID: 7404 RVA: 0x000D59B4 File Offset: 0x000D3BB4
	public void method_236(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D55" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D95" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CED RID: 7405 RVA: 0x000D5A08 File Offset: 0x000D3C08
	public void method_237(uint uint_0)
	{
		if (uint_0 <= 255U)
		{
			this.string_0 = this.string_0 + "8D56" + this.method_1(uint_0, 2);
			return;
		}
		this.string_0 = this.string_0 + "8D96" + this.method_1(uint_0, 8);
	}

	// Token: 0x06001CEE RID: 7406 RVA: 0x000154E3 File Offset: 0x000136E3
	public void method_238()
	{
		this.string_0 += "58";
	}

	// Token: 0x06001CEF RID: 7407 RVA: 0x000154FB File Offset: 0x000136FB
	public void method_239()
	{
		this.string_0 += "5B";
	}

	// Token: 0x06001CF0 RID: 7408 RVA: 0x00015513 File Offset: 0x00013713
	public void method_240()
	{
		this.string_0 += "59";
	}

	// Token: 0x06001CF1 RID: 7409 RVA: 0x0001552B File Offset: 0x0001372B
	public void method_241()
	{
		this.string_0 += "5A";
	}

	// Token: 0x06001CF2 RID: 7410 RVA: 0x00015543 File Offset: 0x00013743
	public void method_242()
	{
		this.string_0 += "5E";
	}

	// Token: 0x06001CF3 RID: 7411 RVA: 0x0001555B File Offset: 0x0001375B
	public void method_243()
	{
		this.string_0 += "5C";
	}

	// Token: 0x06001CF4 RID: 7412 RVA: 0x00015573 File Offset: 0x00013773
	public void method_244()
	{
		this.string_0 += "5F";
	}

	// Token: 0x06001CF5 RID: 7413 RVA: 0x0001558B File Offset: 0x0001378B
	public void method_245()
	{
		this.string_0 += "5D";
	}

	// Token: 0x06001CF6 RID: 7414
	[DllImport("kernel32.dll")]
	public static extern IntPtr CreateRemoteThread(IntPtr intptr_1, int int_1, int int_2, int int_3, int int_4, int int_5, int int_6);

	// Token: 0x06001CF7 RID: 7415
	[DllImport("kernel32.dll")]
	public static extern IntPtr OpenProcess(int int_1, bool bool_0, int int_2);

	// Token: 0x06001CF8 RID: 7416
	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr intptr_1);

	// Token: 0x06001CF9 RID: 7417
	[DllImport("kernel32.dll")]
	public static extern bool WriteProcessMemory(IntPtr intptr_1, int int_1, byte[] byte_1, int int_2, int int_3);

	// Token: 0x06001CFA RID: 7418
	[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
	public static extern int VirtualAllocEx(IntPtr intptr_1, int int_1, int int_2, uint uint_0, uint uint_1);

	// Token: 0x06001CFB RID: 7419
	[DllImport("kernel32.dll")]
	public static extern bool VirtualFreeEx(IntPtr intptr_1, int int_1, int int_2, int int_3);

	// Token: 0x040011A9 RID: 4521
	public int int_0;

	// Token: 0x040011AA RID: 4522
	public IntPtr intptr_0;

	// Token: 0x040011AB RID: 4523
	public string string_0 = "";

	// Token: 0x040011AC RID: 4524
	public byte[] byte_0;
}
