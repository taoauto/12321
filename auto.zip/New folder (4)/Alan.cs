﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020001FF RID: 511
internal partial class Alan : Form
{
	// Token: 0x06001A9A RID: 6810 RVA: 0x000134AC File Offset: 0x000116AC
	public Alan()
	{
		this.InitializeComponent();
		if (Main.Boolean_16)
		{
			base.Opacity = 0.0;
			return;
		}
		base.Opacity = 75.0;
	}

	// Token: 0x06001A9B RID: 6811 RVA: 0x000C89D0 File Offset: 0x000C6BD0
	public static void smethod_0(Alam alam_0)
	{
		Alan.Class238 @class = new Alan.Class238();
		@class.alam_0 = alam_0;
		Alan.Alan_0.Invoke(new Action(@class.method_0));
	}

	// Token: 0x1700066E RID: 1646
	// (get) Token: 0x06001A9C RID: 6812 RVA: 0x000134E0 File Offset: 0x000116E0
	public static Alan Alan_0
	{
		get
		{
			if (Alan.alan_0 == null)
			{
				Alan.alan_0 = new Alan();
			}
			return Alan.alan_0;
		}
	}

	// Token: 0x06001A9D RID: 6813 RVA: 0x00013421 File Offset: 0x00011621
	private void method_0(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			base.Dispose();
		}
	}

	// Token: 0x06001A9E RID: 6814 RVA: 0x000134F8 File Offset: 0x000116F8
	public void method_1()
	{
		base.Height = 25;
		Class438.smethod_14(this, Class438.Enum22.BottomLeft);
	}

	// Token: 0x06001A9F RID: 6815 RVA: 0x00013509 File Offset: 0x00011709
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (Alan.Alan_0.Controls.Count == 0)
		{
			Class407.smethod_7();
			base.Hide();
		}
	}

	// Token: 0x06001AA0 RID: 6816 RVA: 0x00013527 File Offset: 0x00011727
	private void Alan_Load(object sender, EventArgs e)
	{
		if (!Class268.bool_79)
		{
			Class407.smethod_4();
		}
		base.Height = 25;
		Class438.smethod_14(this, Class438.Enum22.BottomCenter);
	}

	// Token: 0x06001AA1 RID: 6817 RVA: 0x00013544 File Offset: 0x00011744
	private void method_2(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
	}

	// Token: 0x06001AA2 RID: 6818 RVA: 0x0001354D File Offset: 0x0001174D
	private void timer_1_Tick(object sender, EventArgs e)
	{
		if (Main.Boolean_16)
		{
			base.Opacity = 0.0;
			return;
		}
		base.Opacity = 75.0;
	}

	// Token: 0x06001AA3 RID: 6819 RVA: 0x00013575 File Offset: 0x00011775
	private void method_3(object sender, MouseEventArgs e)
	{
		Class268.bool_79 = !Class268.bool_79;
		if (Class268.bool_79)
		{
			Class407.smethod_7();
			return;
		}
		Class407.smethod_4();
	}

	// Token: 0x06001AA4 RID: 6820 RVA: 0x00013596 File Offset: 0x00011796
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x040010A6 RID: 4262
	private static Alan alan_0;

	// Token: 0x02000200 RID: 512
	[CompilerGenerated]
	private sealed class Class238
	{
		// Token: 0x06001AA7 RID: 6823 RVA: 0x000135B5 File Offset: 0x000117B5
		internal void method_0()
		{
			Alan.Alan_0.Controls.Add(this.alam_0);
		}

		// Token: 0x040010AA RID: 4266
		public Alam alam_0;
	}
}
