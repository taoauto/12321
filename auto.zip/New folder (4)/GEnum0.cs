﻿using System;

// Token: 0x0200000E RID: 14
public enum GEnum0
{
	// Token: 0x04000012 RID: 18
	Other,
	// Token: 0x04000013 RID: 19
	ProtocolError,
	// Token: 0x04000014 RID: 20
	ConnectFailure,
	// Token: 0x04000015 RID: 21
	SendFailure,
	// Token: 0x04000016 RID: 22
	ReceiveFailure
}
