﻿using System;

// Token: 0x0200015A RID: 346
internal interface Interface7
{
	// Token: 0x17000431 RID: 1073
	// (get) Token: 0x06001065 RID: 4197
	// (set) Token: 0x06001066 RID: 4198
	string String_0 { get; set; }

	// Token: 0x17000432 RID: 1074
	// (get) Token: 0x06001067 RID: 4199
	// (set) Token: 0x06001068 RID: 4200
	string String_1 { get; set; }

	// Token: 0x17000433 RID: 1075
	// (get) Token: 0x06001069 RID: 4201
	// (set) Token: 0x0600106A RID: 4202
	string String_2 { get; set; }

	// Token: 0x17000434 RID: 1076
	// (get) Token: 0x0600106B RID: 4203
	// (set) Token: 0x0600106C RID: 4204
	string String_3 { get; set; }

	// Token: 0x17000435 RID: 1077
	// (get) Token: 0x0600106D RID: 4205
	// (set) Token: 0x0600106E RID: 4206
	bool Boolean_0 { get; set; }

	// Token: 0x17000436 RID: 1078
	// (get) Token: 0x0600106F RID: 4207
	// (set) Token: 0x06001070 RID: 4208
	bool Boolean_1 { get; set; }

	// Token: 0x17000437 RID: 1079
	// (get) Token: 0x06001071 RID: 4209
	// (set) Token: 0x06001072 RID: 4210
	int Int32_0 { get; set; }
}
