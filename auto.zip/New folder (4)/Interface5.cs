﻿using System;
using System.IO;

// Token: 0x02000150 RID: 336
internal interface Interface5
{
	// Token: 0x0600102F RID: 4143
	void imethod_0(Class130 class130_0);

	// Token: 0x06001030 RID: 4144
	Stream imethod_1(Class141 class141_0, long long_0, long long_1);

	// Token: 0x06001031 RID: 4145
	Class140 imethod_2(Class141 class141_0, out Stream stream_0);
}
