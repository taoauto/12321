﻿using System;

// Token: 0x02000183 RID: 387
[Serializable]
public struct GStruct12
{
	// Token: 0x040009F1 RID: 2545
	public uint OffsetToData;

	// Token: 0x040009F2 RID: 2546
	public uint Size;

	// Token: 0x040009F3 RID: 2547
	public uint CodePage;

	// Token: 0x040009F4 RID: 2548
	public uint Reserved;
}
