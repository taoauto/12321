﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001EE RID: 494
public class LayDo : UserControl
{
	// Token: 0x060019F2 RID: 6642 RVA: 0x00012D18 File Offset: 0x00010F18
	public LayDo()
	{
		this.InitializeComponent();
	}

	// Token: 0x060019F3 RID: 6643 RVA: 0x000BC6DC File Offset: 0x000BA8DC
	private void LayDo_Load(object sender, EventArgs e)
	{
		this.txtDropName.Text = Class415.String_14;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(LayDo.Class229.<>9.method_0)).ToArray<ListViewItem>());
		this.checkBox1.Checked = Setting.smethod_0("checkKhongLayCoDinh");
		this.tabPage2.Controls.Add(new LayDoThienCo
		{
			Dock = DockStyle.Fill
		});
	}

	// Token: 0x060019F4 RID: 6644 RVA: 0x00012D26 File Offset: 0x00010F26
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060019F5 RID: 6645 RVA: 0x000BC774 File Offset: 0x000BA974
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtDropName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtDropName.Text = this.txtDropName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtDropName.method_1();
	}

	// Token: 0x060019F6 RID: 6646 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x060019F7 RID: 6647 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_2(object sender, EventArgs e)
	{
	}

	// Token: 0x060019F8 RID: 6648 RVA: 0x00012D2E File Offset: 0x00010F2E
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x060019F9 RID: 6649 RVA: 0x000BC874 File Offset: 0x000BAA74
	private void txtDropName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_14 = this.txtDropName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x060019FA RID: 6650 RVA: 0x00012D47 File Offset: 0x00010F47
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		Setting.Dictionary_2["checkKhongLayCoDinh"] = this.checkBox1.Checked;
	}

	// Token: 0x060019FB RID: 6651 RVA: 0x00012D63 File Offset: 0x00010F63
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060019FC RID: 6652 RVA: 0x000BC8DC File Offset: 0x000BAADC
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(LayDo));
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtDropName = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.checkBox1 = new CheckBox();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		base.SuspendLayout();
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(227, 318);
		this.lvName.TabIndex = 20;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 180;
		this.txtDropName.Dock = DockStyle.Fill;
		this.txtDropName.Location = new Point(0, 0);
		this.txtDropName.Multiline = true;
		this.txtDropName.Name = "txtDropName";
		this.txtDropName.ScrollBars = ScrollBars.Vertical;
		this.txtDropName.Size = new Size(215, 355);
		this.txtDropName.TabIndex = 18;
		this.txtDropName.String_0 = "";
		this.txtDropName.Color_0 = Color.Gray;
		this.txtDropName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtDropName.Color_1 = Color.LightGray;
		this.txtDropName.TextChanged += this.txtDropName_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtDropName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.checkBox1);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(446, 355);
		this.splitContainer1.SplitterDistance = 215;
		this.splitContainer1.TabIndex = 0;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(227, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = DockStyle.Bottom;
		this.checkBox1.Location = new Point(0, 338);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new Size(227, 17);
		this.checkBox1.TabIndex = 0;
		this.checkBox1.Text = "Không Lấy Đồ Cố Định";
		this.toolTip_0.SetToolTip(this.checkBox1, "Không Lấy Đồ Cố Định");
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.IsBalloon = true;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(460, 387);
		this.tabControlEx1.TabIndex = 1;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(452, 361);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Thương Khố";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(452, 361);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Thiên Cơ";
		this.tabPage2.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Name = "LayDo";
		base.Size = new Size(460, 387);
		base.Tag = "Lấy Đồ Từ Thương Khố";
		base.Load += this.LayDo_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000F5B RID: 3931
	private IContainer icontainer_0;

	// Token: 0x04000F5C RID: 3932
	private ListViewEx lvName;

	// Token: 0x04000F5D RID: 3933
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F5E RID: 3934
	private Class85 txtDropName;

	// Token: 0x04000F5F RID: 3935
	private SplitContainer splitContainer1;

	// Token: 0x04000F60 RID: 3936
	private Class85 txtSearchName;

	// Token: 0x04000F61 RID: 3937
	private ToolTip toolTip_0;

	// Token: 0x04000F62 RID: 3938
	private CheckBox checkBox1;

	// Token: 0x04000F63 RID: 3939
	private Control1 tabControlEx1;

	// Token: 0x04000F64 RID: 3940
	private TabPage tabPage1;

	// Token: 0x04000F65 RID: 3941
	private TabPage tabPage2;

	// Token: 0x020001EF RID: 495
	[CompilerGenerated]
	[Serializable]
	private sealed class Class229
	{
		// Token: 0x060019FF RID: 6655 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000F66 RID: 3942
		public static readonly LayDo.Class229 <>9 = new LayDo.Class229();

		// Token: 0x04000F67 RID: 3943
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
