﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001E6 RID: 486
public class GameItemForm : UserControl
{
	// Token: 0x060019C6 RID: 6598 RVA: 0x00012B8C File Offset: 0x00010D8C
	public GameItemForm()
	{
		this.InitializeComponent();
	}

	// Token: 0x060019C7 RID: 6599 RVA: 0x000BAF88 File Offset: 0x000B9188
	private void btnRefresh_Click(object sender, EventArgs e)
	{
		this.lvName.Items.Clear();
		this.lvName.hideItems.Clear();
		this.lvName.dicHides.Clear();
		List<string> first = new List<string>
		{
			"Điển Tịch",
			"Trang Bị 1,2,3,4 Sao",
			"Trang Bị 5 Sao",
			"Trang Bị 10x,11x"
		};
		this.lvName.Items.AddRange(new HashSet<string>(first.Concat(Class209.IEnumerable_0).Concat(Class209.IEnumerable_1)).Select(new Func<string, ListViewItem>(GameItemForm.Class225.<>9.method_0)).ToArray<ListViewItem>());
	}

	// Token: 0x060019C8 RID: 6600 RVA: 0x00012B9A File Offset: 0x00010D9A
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearch.Text);
	}

	// Token: 0x060019C9 RID: 6601 RVA: 0x000BB04C File Offset: 0x000B924C
	private void menuXemAiDangCam_Click(object sender, EventArgs e)
	{
		if (this.lvName.SelectedItems.Count > 0)
		{
			GameItemForm.Class226 @class = new GameItemForm.Class226();
			@class.string_0 = this.lvName.SelectedItems[0].Text;
			List<Class159> list = Main.Main_0.IEnumerable_5.Where(new Func<Class159, bool>(@class.method_0)).ToList<Class159>();
			if (list.Count > 0)
			{
				string str = string.Join(",", list.Select(new Func<Class159, string>(GameItemForm.Class225.<>9.method_2)).ToArray<string>());
				if (MessageBox.Show(this, str + "\r\nBạn có muốn hiện những Nhân Vật Này", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					list.ForEach(new Action<Class159>(GameItemForm.Class225.<>9.method_3));
				}
			}
		}
	}

	// Token: 0x060019CA RID: 6602 RVA: 0x00012BB3 File Offset: 0x00010DB3
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060019CB RID: 6603 RVA: 0x000BB130 File Offset: 0x000B9330
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(GameItemForm));
		this.btnRefresh = new Button();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuThem = new ToolStripMenuItem();
		this.menuThemCoDinh = new ToolStripMenuItem();
		this.menuXemAiDangCam = new ToolStripMenuItem();
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtSearch = new Class85();
		this.number = new TextBox();
		this.menuName.SuspendLayout();
		base.SuspendLayout();
		this.btnRefresh.Dock = DockStyle.Bottom;
		this.btnRefresh.Location = new Point(0, 471);
		this.btnRefresh.Name = "btnRefresh";
		this.btnRefresh.Size = new Size(554, 23);
		this.btnRefresh.TabIndex = 12;
		this.btnRefresh.Text = "Refresh";
		this.btnRefresh.UseVisualStyleBackColor = true;
		this.btnRefresh.Click += this.btnRefresh_Click;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuThem,
			this.menuThemCoDinh,
			this.menuXemAiDangCam
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(183, 70);
		this.menuThem.Name = "menuThem";
		this.menuThem.Size = new Size(182, 22);
		this.menuThem.Text = "Thêm [Double Click]";
		this.menuThemCoDinh.Name = "menuThemCoDinh";
		this.menuThemCoDinh.Size = new Size(182, 22);
		this.menuThemCoDinh.Text = "Thêm Cố Định";
		this.menuXemAiDangCam.Name = "menuXemAiDangCam";
		this.menuXemAiDangCam.Size = new Size(182, 22);
		this.menuXemAiDangCam.Text = "Xem Ai Đang Cầm";
		this.menuXemAiDangCam.Click += this.menuXemAiDangCam_Click;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(554, 431);
		this.lvName.TabIndex = 10;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 155;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(554, 20);
		this.txtSearch.TabIndex = 11;
		this.txtSearch.String_0 = "Search...";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		this.number.Dock = DockStyle.Bottom;
		this.number.Location = new Point(0, 451);
		this.number.Name = "number";
		this.number.Size = new Size(554, 20);
		this.number.TabIndex = 13;
		this.number.Visible = false;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lvName);
		base.Controls.Add(this.number);
		base.Controls.Add(this.btnRefresh);
		base.Controls.Add(this.txtSearch);
		base.Name = "GameItemForm";
		base.Size = new Size(554, 494);
		this.menuName.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000F35 RID: 3893
	private IContainer icontainer_0;

	// Token: 0x04000F36 RID: 3894
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F37 RID: 3895
	private Button btnRefresh;

	// Token: 0x04000F38 RID: 3896
	private Class85 txtSearch;

	// Token: 0x04000F39 RID: 3897
	private ContextMenuStrip menuName;

	// Token: 0x04000F3A RID: 3898
	private ToolStripMenuItem menuXemAiDangCam;

	// Token: 0x04000F3B RID: 3899
	internal ListViewEx lvName;

	// Token: 0x04000F3C RID: 3900
	public ToolStripMenuItem menuThem;

	// Token: 0x04000F3D RID: 3901
	public ToolStripMenuItem menuThemCoDinh;

	// Token: 0x04000F3E RID: 3902
	public TextBox number;

	// Token: 0x020001E7 RID: 487
	[CompilerGenerated]
	[Serializable]
	private sealed class Class225
	{
		// Token: 0x060019CE RID: 6606 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x060019CF RID: 6607 RVA: 0x00012BDE File Offset: 0x00010DDE
		internal IEnumerable<string> method_1(Class209 class209_0)
		{
			return new string[]
			{
				class209_0.String_0,
				class209_0.String_1
			};
		}

		// Token: 0x060019D0 RID: 6608 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_2(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x060019D1 RID: 6609 RVA: 0x00012BF8 File Offset: 0x00010DF8
		internal void method_3(Class159 class159_0)
		{
			class159_0.method_223();
		}

		// Token: 0x04000F3F RID: 3903
		public static readonly GameItemForm.Class225 <>9 = new GameItemForm.Class225();

		// Token: 0x04000F40 RID: 3904
		public static Func<string, ListViewItem> <>9__1_0;

		// Token: 0x04000F41 RID: 3905
		public static Func<Class209, IEnumerable<string>> <>9__3_1;

		// Token: 0x04000F42 RID: 3906
		public static Func<Class159, string> <>9__3_2;

		// Token: 0x04000F43 RID: 3907
		public static Action<Class159> <>9__3_3;
	}

	// Token: 0x020001E8 RID: 488
	[CompilerGenerated]
	private sealed class Class226
	{
		// Token: 0x060019D3 RID: 6611 RVA: 0x000BB658 File Offset: 0x000B9858
		internal bool method_0(Class159 class159_0)
		{
			return class159_0.Class196_0.IEnumerable_0.Concat(class159_0.Class196_0.IEnumerable_4).SelectMany(new Func<Class209, IEnumerable<string>>(GameItemForm.Class225.<>9.method_1)).Contains(this.string_0);
		}

		// Token: 0x04000F44 RID: 3908
		public string string_0;
	}
}
