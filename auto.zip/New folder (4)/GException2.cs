﻿using System;
using System.Runtime.Serialization;

// Token: 0x02000031 RID: 49
[Serializable]
public sealed class GException2 : GException0
{
	// Token: 0x170000BB RID: 187
	// (get) Token: 0x0600023C RID: 572 RVA: 0x00004821 File Offset: 0x00002A21
	// (set) Token: 0x0600023D RID: 573 RVA: 0x00004829 File Offset: 0x00002A29
	public GClass16 GClass16_0 { get; private set; }

	// Token: 0x0600023E RID: 574 RVA: 0x00004832 File Offset: 0x00002A32
	public GException2() : this(Class2.String_40, null)
	{
	}

	// Token: 0x0600023F RID: 575 RVA: 0x000035A5 File Offset: 0x000017A5
	public GException2(string string_0, Exception exception_0 = null) : base(string_0, exception_0)
	{
	}

	// Token: 0x06000240 RID: 576 RVA: 0x00004840 File Offset: 0x00002A40
	public GException2(string string_0, GClass16 gclass16_0, Exception exception_0 = null) : base(string_0, exception_0)
	{
		this.GClass16_0 = gclass16_0;
	}

	// Token: 0x06000241 RID: 577 RVA: 0x00004851 File Offset: 0x00002A51
	private GException2(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0) : base(serializationInfo_0, streamingContext_0)
	{
	}
}
