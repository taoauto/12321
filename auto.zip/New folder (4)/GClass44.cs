﻿using System;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

// Token: 0x020000A9 RID: 169
public class GClass44
{
	// Token: 0x060007F0 RID: 2032 RVA: 0x000083AE File Offset: 0x000065AE
	public GClass44()
	{
		this.sslProtocols_0 = SslProtocols.Default;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x000083C1 File Offset: 0x000065C1
	public GClass44(X509Certificate2 x509Certificate2_1)
	{
		this.x509Certificate2_0 = x509Certificate2_1;
		this.sslProtocols_0 = SslProtocols.Default;
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x0003B290 File Offset: 0x00039490
	public GClass44(GClass44 gclass44_0)
	{
		if (gclass44_0 == null)
		{
			throw new ArgumentNullException("configuration");
		}
		this.bool_0 = gclass44_0.bool_0;
		this.bool_1 = gclass44_0.bool_1;
		this.remoteCertificateValidationCallback_0 = gclass44_0.remoteCertificateValidationCallback_0;
		this.sslProtocols_0 = gclass44_0.sslProtocols_0;
		this.x509Certificate2_0 = gclass44_0.x509Certificate2_0;
	}

	// Token: 0x17000229 RID: 553
	// (get) Token: 0x060007F3 RID: 2035 RVA: 0x000083DB File Offset: 0x000065DB
	// (set) Token: 0x060007F4 RID: 2036 RVA: 0x000083E3 File Offset: 0x000065E3
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x1700022A RID: 554
	// (get) Token: 0x060007F5 RID: 2037 RVA: 0x000083EC File Offset: 0x000065EC
	// (set) Token: 0x060007F6 RID: 2038 RVA: 0x000083F4 File Offset: 0x000065F4
	public bool Boolean_1
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
		}
	}

	// Token: 0x1700022B RID: 555
	// (get) Token: 0x060007F7 RID: 2039 RVA: 0x000083FD File Offset: 0x000065FD
	// (set) Token: 0x060007F8 RID: 2040 RVA: 0x0000841F File Offset: 0x0000661F
	public RemoteCertificateValidationCallback RemoteCertificateValidationCallback_0
	{
		get
		{
			if (this.remoteCertificateValidationCallback_0 == null)
			{
				this.remoteCertificateValidationCallback_0 = new RemoteCertificateValidationCallback(GClass44.smethod_0);
			}
			return this.remoteCertificateValidationCallback_0;
		}
		set
		{
			this.remoteCertificateValidationCallback_0 = value;
		}
	}

	// Token: 0x1700022C RID: 556
	// (get) Token: 0x060007F9 RID: 2041 RVA: 0x00008428 File Offset: 0x00006628
	// (set) Token: 0x060007FA RID: 2042 RVA: 0x00008430 File Offset: 0x00006630
	public SslProtocols SslProtocols_0
	{
		get
		{
			return this.sslProtocols_0;
		}
		set
		{
			this.sslProtocols_0 = value;
		}
	}

	// Token: 0x1700022D RID: 557
	// (get) Token: 0x060007FB RID: 2043 RVA: 0x00008439 File Offset: 0x00006639
	// (set) Token: 0x060007FC RID: 2044 RVA: 0x00008441 File Offset: 0x00006641
	public X509Certificate2 X509Certificate2_0
	{
		get
		{
			return this.x509Certificate2_0;
		}
		set
		{
			this.x509Certificate2_0 = value;
		}
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_0(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x0400044B RID: 1099
	private bool bool_0;

	// Token: 0x0400044C RID: 1100
	private bool bool_1;

	// Token: 0x0400044D RID: 1101
	private RemoteCertificateValidationCallback remoteCertificateValidationCallback_0;

	// Token: 0x0400044E RID: 1102
	private SslProtocols sslProtocols_0;

	// Token: 0x0400044F RID: 1103
	private X509Certificate2 x509Certificate2_0;
}
