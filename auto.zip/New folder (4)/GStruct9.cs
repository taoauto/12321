﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000180 RID: 384
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct9
{
	// Token: 0x040009CA RID: 2506
	public uint OriginalFirstThunk;

	// Token: 0x040009CB RID: 2507
	public uint TimeDateStamp;

	// Token: 0x040009CC RID: 2508
	public uint ForwarderChain;

	// Token: 0x040009CD RID: 2509
	public uint Name;

	// Token: 0x040009CE RID: 2510
	public uint FirstThunkPtr;
}
