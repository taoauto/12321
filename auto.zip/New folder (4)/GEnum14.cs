﻿using System;

// Token: 0x020000F0 RID: 240
public enum GEnum14
{
	// Token: 0x040005DF RID: 1503
	Strategy1,
	// Token: 0x040005E0 RID: 1504
	Strategy2
}
