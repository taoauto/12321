﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000121 RID: 289
public abstract class GClass87 : IDisposable
{
	// Token: 0x170003D3 RID: 979
	// (get) Token: 0x06000EAE RID: 3758 RVA: 0x0000C731 File Offset: 0x0000A931
	// (set) Token: 0x06000EAF RID: 3759 RVA: 0x0000C739 File Offset: 0x0000A939
	public virtual bool \u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E { get; set; }

	// Token: 0x14000030 RID: 48
	// (add) Token: 0x06000EB0 RID: 3760 RVA: 0x000559DC File Offset: 0x00053BDC
	// (remove) Token: 0x06000EB1 RID: 3761 RVA: 0x00055A14 File Offset: 0x00053C14
	public event EventHandler<GEventArgs21> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs21> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs21> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs21> value2 = (EventHandler<GEventArgs21>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs21>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs21> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs21> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs21> value2 = (EventHandler<GEventArgs21>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs21>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000EB2 RID: 3762 RVA: 0x0000C742 File Offset: 0x0000A942
	public GClass87()
	{
		this.GClass87.\u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E = true;
	}

	// Token: 0x06000EB3 RID: 3763
	public abstract void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0);

	// Token: 0x06000EB4 RID: 3764 RVA: 0x0000C751 File Offset: 0x0000A951
	public virtual void vmethod_0(FastColoredTextBox fastColoredTextBox_0, GEventArgs21 geventArgs21_0)
	{
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(fastColoredTextBox_0, geventArgs21_0);
		}
	}

	// Token: 0x06000EB5 RID: 3765 RVA: 0x0000C768 File Offset: 0x0000A968
	protected virtual void vmethod_1(FastColoredTextBox fastColoredTextBox_0, GClass105 gclass105_0)
	{
		fastColoredTextBox_0.method_19(gclass105_0);
	}

	// Token: 0x06000EB6 RID: 3766 RVA: 0x0000C771 File Offset: 0x0000A971
	public static Size smethod_0(GClass86 gclass86_0)
	{
		return new Size((gclass86_0.GStruct2_1.int_0 - gclass86_0.GStruct2_0.int_0) * gclass86_0.fastColoredTextBox_0.Int32_4, gclass86_0.fastColoredTextBox_0.Int32_2);
	}

	// Token: 0x06000EB7 RID: 3767 RVA: 0x00055A4C File Offset: 0x00053C4C
	public static GraphicsPath smethod_1(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		graphicsPath.AddArc(rectangle_0.X, rectangle_0.Y, int_0, int_0, 180f, 90f);
		graphicsPath.AddArc(rectangle_0.X + rectangle_0.Width - int_0, rectangle_0.Y, int_0, int_0, 270f, 90f);
		graphicsPath.AddArc(rectangle_0.X + rectangle_0.Width - int_0, rectangle_0.Y + rectangle_0.Height - int_0, int_0, int_0, 0f, 90f);
		graphicsPath.AddArc(rectangle_0.X, rectangle_0.Y + rectangle_0.Height - int_0, int_0, int_0, 90f, 90f);
		graphicsPath.AddLine(rectangle_0.X, rectangle_0.Y + rectangle_0.Height - int_0, rectangle_0.X, rectangle_0.Y + int_0 / 2);
		return graphicsPath;
	}

	// Token: 0x06000EB8 RID: 3768 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void Dispose()
	{
	}

	// Token: 0x06000EB9 RID: 3769 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	public virtual string \u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E()
	{
		return "";
	}

	// Token: 0x06000EBA RID: 3770 RVA: 0x0000C7AD File Offset: 0x0000A9AD
	public virtual GClass74 \u202E\u206A\u206D\u200D\u206D\u206D\u200E\u200E\u202A\u200D\u200E\u200C\u202E\u200D\u202A\u200B\u202E\u206E\u200D\u200B\u200B\u206D\u200B\u206A\u206D\u202C\u202B\u200E\u202D\u206A\u202C\u206C\u202B\u200B\u200C\u206A\u202C\u206E\u202E\u206D\u202E()
	{
		return new GClass74();
	}

	// Token: 0x0400075C RID: 1884
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x0400075D RID: 1885
	[CompilerGenerated]
	private EventHandler<GEventArgs21> eventHandler_0;
}
