﻿using System;

// Token: 0x020000A1 RID: 161
internal enum Enum7
{
	// Token: 0x04000424 RID: 1060
	None,
	// Token: 0x04000425 RID: 1061
	Data,
	// Token: 0x04000426 RID: 1062
	DataEnded,
	// Token: 0x04000427 RID: 1063
	Trailer,
	// Token: 0x04000428 RID: 1064
	End
}
