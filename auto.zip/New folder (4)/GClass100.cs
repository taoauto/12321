﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020000F8 RID: 248
public class GClass100 : GClass99, IDisposable
{
	// Token: 0x1400002D RID: 45
	// (add) Token: 0x06000CCB RID: 3275 RVA: 0x0004D734 File Offset: 0x0004B934
	// (remove) Token: 0x06000CCC RID: 3276 RVA: 0x0004D76C File Offset: 0x0004B96C
	public event EventHandler<GEventArgs18> Event_7
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs18> eventHandler = this.eventHandler_7;
			EventHandler<GEventArgs18> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs18> value2 = (EventHandler<GEventArgs18>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs18>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs18> eventHandler = this.eventHandler_7;
			EventHandler<GEventArgs18> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs18> value2 = (EventHandler<GEventArgs18>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs18>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400002E RID: 46
	// (add) Token: 0x06000CCD RID: 3277 RVA: 0x0004D7A4 File Offset: 0x0004B9A4
	// (remove) Token: 0x06000CCE RID: 3278 RVA: 0x0004D7DC File Offset: 0x0004B9DC
	public event EventHandler<GEventArgs19> Event_8
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs19> eventHandler = this.eventHandler_8;
			EventHandler<GEventArgs19> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs19> value2 = (EventHandler<GEventArgs19>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs19>>(ref this.eventHandler_8, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs19> eventHandler = this.eventHandler_8;
			EventHandler<GEventArgs19> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs19> value2 = (EventHandler<GEventArgs19>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs19>>(ref this.eventHandler_8, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x0004D814 File Offset: 0x0004BA14
	public GClass100(FastColoredTextBox fastColoredTextBox_1) : base(fastColoredTextBox_1)
	{
		this.timer_0.Interval = 10000;
		this.timer_0.Tick += this.timer_0_Tick;
		this.timer_0.Enabled = true;
		this.String_0 = Environment.NewLine;
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x0004D87C File Offset: 0x0004BA7C
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.timer_0.Enabled = false;
		try
		{
			this.method_1();
		}
		finally
		{
			this.timer_0.Enabled = true;
		}
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x0004D8BC File Offset: 0x0004BABC
	private void method_1()
	{
		GStruct2 gstruct2_ = base.FastColoredTextBox_0.GClass86_4.GStruct2_0;
		int int_ = base.FastColoredTextBox_0.GClass86_4.GStruct2_1.int_1;
		int num = 0;
		for (int i = 0; i < this.Count; i++)
		{
			if (this.list_0[i] != null && !this.list_0[i].Boolean_0 && Math.Abs(i - int_) > 2000)
			{
				this.list_0[i] = null;
				num++;
			}
		}
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x0004D944 File Offset: 0x0004BB44
	public void method_2(string string_1, Encoding encoding_1)
	{
		this.Clear();
		if (this.fileStream_0 != null)
		{
			this.fileStream_0.Dispose();
		}
		this.String_0 = Environment.NewLine;
		this.fileStream_0 = new FileStream(string_1, FileMode.Open);
		long length = this.fileStream_0.Length;
		encoding_1 = GClass100.smethod_0(encoding_1, this.fileStream_0);
		this.method_3(encoding_1);
		this.list_1.Add((int)this.fileStream_0.Position);
		this.list_0.Add(null);
		this.list_1.Capacity = (int)(length / 7L + 1000L);
		int num = 0;
		int item = 0;
		BinaryReader binaryReader = new BinaryReader(this.fileStream_0, encoding_1);
		while (this.fileStream_0.Position < length)
		{
			item = (int)this.fileStream_0.Position;
			char c = binaryReader.ReadChar();
			if (c == '\n')
			{
				this.list_1.Add((int)this.fileStream_0.Position);
				this.list_0.Add(null);
			}
			else if (num == 13)
			{
				this.list_1.Add(item);
				this.list_0.Add(null);
				this.String_0 = "\r";
			}
			num = (int)c;
		}
		if (num == 13)
		{
			this.list_1.Add(item);
			this.list_0.Add(null);
		}
		if (length > 2000000L)
		{
			GC.Collect();
		}
		GClass81[] array = new GClass81[100];
		int count = this.list_0.Count;
		this.list_0.AddRange(array);
		this.list_0.TrimExcess();
		this.list_0.RemoveRange(count, array.Length);
		int[] collection = new int[100];
		count = this.list_0.Count;
		this.list_1.AddRange(collection);
		this.list_1.TrimExcess();
		this.list_1.RemoveRange(count, array.Length);
		this.encoding_0 = encoding_1;
		this.vmethod_7(0, this.Count);
		int num2 = Math.Min(this.list_0.Count, base.FastColoredTextBox_0.ClientRectangle.Height / base.FastColoredTextBox_0.Int32_2);
		for (int i = 0; i < num2; i++)
		{
			this.method_6(i);
		}
		this.vmethod_11(new GClass99.GEventArgs20(0, num2 - 1));
		if (base.FastColoredTextBox_0.Boolean_23)
		{
			this.vmethod_12(new GClass99.GEventArgs20(0, num2 - 1));
		}
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x0004DB9C File Offset: 0x0004BD9C
	private int method_3(Encoding encoding_1)
	{
		if (encoding_1.IsSingleByte)
		{
			return 0;
		}
		if (encoding_1.HeaderName == "unicodeFFFE")
		{
			return 0;
		}
		if (encoding_1.HeaderName == "utf-16")
		{
			return 1;
		}
		if (encoding_1.HeaderName == "utf-32BE")
		{
			return 0;
		}
		if (encoding_1.HeaderName == "utf-32")
		{
			return 3;
		}
		return 0;
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x0004DC04 File Offset: 0x0004BE04
	private static Encoding smethod_0(Encoding encoding_1, FileStream fileStream_1)
	{
		int num = 0;
		byte[] array = new byte[4];
		int num2 = fileStream_1.Read(array, 0, 4);
		if (array[0] == 255 && array[1] == 254 && array[2] == 0 && array[3] == 0 && num2 >= 4)
		{
			encoding_1 = Encoding.UTF32;
			num = 4;
		}
		else if (array[0] == 0 && array[1] == 0 && array[2] == 254 && array[3] == 255)
		{
			encoding_1 = new UTF32Encoding(true, true);
			num = 4;
		}
		else if (array[0] == 239 && array[1] == 187 && array[2] == 191)
		{
			encoding_1 = Encoding.UTF8;
			num = 3;
		}
		else if (array[0] == 254 && array[1] == 255)
		{
			encoding_1 = Encoding.BigEndianUnicode;
			num = 2;
		}
		else if (array[0] == 255 && array[1] == 254)
		{
			encoding_1 = Encoding.Unicode;
			num = 2;
		}
		fileStream_1.Seek((long)num, SeekOrigin.Begin);
		return encoding_1;
	}

	// Token: 0x06000CD5 RID: 3285 RVA: 0x0004DCF0 File Offset: 0x0004BEF0
	public void method_4()
	{
		if (this.fileStream_0 != null)
		{
			try
			{
				this.fileStream_0.Dispose();
			}
			catch
			{
			}
		}
		this.fileStream_0 = null;
	}

	// Token: 0x1700036B RID: 875
	// (get) Token: 0x06000CD6 RID: 3286 RVA: 0x0000B34E File Offset: 0x0000954E
	// (set) Token: 0x06000CD7 RID: 3287 RVA: 0x0000B356 File Offset: 0x00009556
	public string String_0 { get; set; }

	// Token: 0x06000CD8 RID: 3288 RVA: 0x0004DD2C File Offset: 0x0004BF2C
	public override void \u202E\u206E\u202C\u200B\u206C\u200B\u200E\u202B\u206F\u200D\u206D\u206A\u202C\u206F\u206D\u206C\u202C\u200E\u200F\u202E\u202B\u206F\u202D\u202E\u202B\u200F\u206C\u200D\u206E\u202A\u202B\u206E\u200E\u206E\u200C\u206D\u206A\u202B\u206E\u206F\u202E(string string_1, Encoding encoding_1)
	{
		List<int> list = new List<int>(this.Count);
		string text = Path.Combine(Path.GetDirectoryName(string_1), Path.GetFileNameWithoutExtension(string_1) + ".tmp");
		StreamReader streamReader = new StreamReader(this.fileStream_0, this.encoding_0);
		using (FileStream fileStream = new FileStream(text, FileMode.Create))
		{
			using (StreamWriter streamWriter = new StreamWriter(fileStream, encoding_1))
			{
				streamWriter.Flush();
				for (int i = 0; i < this.Count; i++)
				{
					list.Add((int)fileStream.Length);
					string text2 = this.method_5(streamReader, i);
					bool flag;
					string text3;
					if (flag = (this.list_0[i] != null && this.list_0[i].Boolean_0))
					{
						text3 = this.list_0[i].String_2;
					}
					else
					{
						text3 = text2;
					}
					if (this.eventHandler_8 != null)
					{
						GEventArgs19 geventArgs = new GEventArgs19(text2, i, flag ? text3 : null);
						this.eventHandler_8(this, geventArgs);
						if (geventArgs.String_2 != null)
						{
							text3 = geventArgs.String_2;
						}
					}
					streamWriter.Write(text3);
					if (i < this.Count - 1)
					{
						streamWriter.Write(this.String_0);
					}
					streamWriter.Flush();
				}
			}
		}
		for (int j = 0; j < this.Count; j++)
		{
			this.list_0[j] = null;
		}
		streamReader.Dispose();
		this.fileStream_0.Dispose();
		if (File.Exists(string_1))
		{
			File.Delete(string_1);
		}
		File.Move(text, string_1);
		this.list_1 = list;
		this.fileStream_0 = new FileStream(string_1, FileMode.Open);
		this.encoding_0 = encoding_1;
	}

	// Token: 0x06000CD9 RID: 3289 RVA: 0x0004DF00 File Offset: 0x0004C100
	private string method_5(StreamReader streamReader_0, int int_1)
	{
		int num = this.list_1[int_1];
		if (num < 0)
		{
			return "";
		}
		this.fileStream_0.Seek((long)num, SeekOrigin.Begin);
		streamReader_0.DiscardBufferedData();
		return streamReader_0.ReadLine();
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x0004DF40 File Offset: 0x0004C140
	public override void \u202B\u206A\u206B\u200D\u200E\u200C\u200C\u206C\u200D\u206C\u206D\u202D\u206E\u206C\u200C\u206E\u206D\u200C\u202B\u200B\u200F\u206C\u200E\u206A\u202E\u200F\u206F\u200C\u206B\u206D\u202D\u200E\u206A\u206D\u206F\u206E\u202E\u202D\u206C\u200D\u202E()
	{
		foreach (GClass81 gclass in this.list_0)
		{
			if (gclass != null)
			{
				gclass.Boolean_0 = false;
			}
		}
	}

	// Token: 0x1700036C RID: 876
	public virtual GClass81 this[int i]
	{
		get
		{
			if (this.list_0[i] != null)
			{
				return this.list_0[i];
			}
			this.method_6(i);
			return this.list_0[i];
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x06000CDD RID: 3293 RVA: 0x0004DF98 File Offset: 0x0004C198
	private void method_6(int int_1)
	{
		GClass81 gclass = this.vmethod_0();
		this.fileStream_0.Seek((long)this.list_1[int_1], SeekOrigin.Begin);
		string text = new StreamReader(this.fileStream_0, this.encoding_0).ReadLine();
		if (text == null)
		{
			text = "";
		}
		if (this.eventHandler_7 != null)
		{
			GEventArgs18 geventArgs = new GEventArgs18(text, int_1);
			this.eventHandler_7(this, geventArgs);
			text = geventArgs.String_1;
			if (text == null)
			{
				return;
			}
		}
		foreach (char char_ in text)
		{
			gclass.Add(new GStruct0(char_));
		}
		this.list_0[int_1] = gclass;
		if (base.FastColoredTextBox_0.Boolean_23)
		{
			this.vmethod_12(new GClass99.GEventArgs20(int_1, int_1));
		}
	}

	// Token: 0x06000CDE RID: 3294 RVA: 0x0000B38F File Offset: 0x0000958F
	public override void \u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(int int_1, GClass81 gclass81_0)
	{
		this.list_1.Insert(int_1, -1);
		base.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(int_1, gclass81_0);
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x0000B3A6 File Offset: 0x000095A6
	public override void \u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(int int_1, int int_2)
	{
		this.list_1.RemoveRange(int_1, int_2);
		base.GClass99.\u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(int_1, int_2);
	}

	// Token: 0x06000CE0 RID: 3296 RVA: 0x0000B3BD File Offset: 0x000095BD
	public virtual void Clear()
	{
		base.Clear();
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x0000B3C5 File Offset: 0x000095C5
	public override int \u200B\u206A\u206E\u200C\u202B\u202C\u206B\u202C\u202E\u202A\u200E\u200D\u202D\u206F\u206C\u206D\u200C\u206B\u200D\u202C\u202A\u200F\u202B\u206B\u200E\u206E\u200F\u202D\u200F\u200E\u200C\u206A\u206C\u200D\u202E\u206F\u206B\u202D\u206B\u206F\u202E(int int_1)
	{
		if (this.list_0[int_1] == null)
		{
			return 0;
		}
		return this.list_0[int_1].Count;
	}

	// Token: 0x06000CE2 RID: 3298 RVA: 0x0000B3E8 File Offset: 0x000095E8
	public override bool \u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(int int_1)
	{
		return this.list_0[int_1] != null && !string.IsNullOrEmpty(this.list_0[int_1].String_0);
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x0000B413 File Offset: 0x00009613
	public override bool \u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(int int_1)
	{
		return this.list_0[int_1] != null && !string.IsNullOrEmpty(this.list_0[int_1].String_1);
	}

	// Token: 0x06000CE4 RID: 3300 RVA: 0x0000B43E File Offset: 0x0000963E
	public virtual void Dispose()
	{
		if (this.fileStream_0 != null)
		{
			this.fileStream_0.Dispose();
		}
		this.timer_0.Dispose();
	}

	// Token: 0x06000CE5 RID: 3301 RVA: 0x0000B45E File Offset: 0x0000965E
	internal void method_7(int int_1)
	{
		if (this.list_0[int_1] != null && !this.list_0[int_1].Boolean_0)
		{
			this.list_0[int_1] = null;
		}
	}

	// Token: 0x0400060B RID: 1547
	private List<int> list_1 = new List<int>();

	// Token: 0x0400060C RID: 1548
	private FileStream fileStream_0;

	// Token: 0x0400060D RID: 1549
	private Encoding encoding_0;

	// Token: 0x0400060E RID: 1550
	private System.Windows.Forms.Timer timer_0 = new System.Windows.Forms.Timer();

	// Token: 0x0400060F RID: 1551
	[CompilerGenerated]
	private EventHandler<GEventArgs18> eventHandler_7;

	// Token: 0x04000610 RID: 1552
	[CompilerGenerated]
	private EventHandler<GEventArgs19> eventHandler_8;

	// Token: 0x04000611 RID: 1553
	[CompilerGenerated]
	private string string_0;
}
