﻿using System;
using System.Linq;
using System.Text;

// Token: 0x020000B2 RID: 178
public class GClass49 : Decoder
{
	// Token: 0x06000896 RID: 2198 RVA: 0x0003C670 File Offset: 0x0003A870
	public virtual int GetCharCount(byte[] bytes, int index, int count)
	{
		if (bytes == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (index < 0 || index > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("index");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		if (index + count > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("bytes");
		}
		return count;
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x0003C6C4 File Offset: 0x0003A8C4
	public virtual int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
	{
		if (bytes == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (byteIndex < 0 || byteIndex > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("byteIndex");
		}
		if (byteCount < 0)
		{
			throw new ArgumentOutOfRangeException("byteCount");
		}
		if (byteIndex + byteCount > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("bytes");
		}
		if (chars == null)
		{
			throw new ArgumentNullException("chars");
		}
		if (charIndex >= 0 && charIndex <= chars.Length)
		{
			int num = byteCount + byteIndex;
			int num2 = charIndex;
			while (byteIndex < num)
			{
				byte b = bytes[byteIndex];
				if (num2 == chars.Length)
				{
					throw new ArgumentException("chars");
				}
				chars[num2] = ((b < 31 || b > 127) ? GClass49.char_0[(int)b] : ((char)b));
				num2++;
				byteIndex++;
			}
			return num2 - charIndex;
		}
		throw new ArgumentOutOfRangeException("charIndex");
	}

	// Token: 0x04000476 RID: 1142
	private static readonly char[] char_0 = GClass48.readOnlyCollection_0.ToArray<char>();
}
