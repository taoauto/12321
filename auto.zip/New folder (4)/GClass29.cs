﻿using System;

// Token: 0x02000071 RID: 113
public abstract class GClass29
{
	// Token: 0x06000512 RID: 1298 RVA: 0x00006491 File Offset: 0x00004691
	protected GClass29(string string_1, GClass24 gclass24_1)
	{
		this.string_0 = string_1;
		this.gclass24_0 = gclass24_1;
		this.gclass31_0 = new GClass31(gclass24_1);
	}

	// Token: 0x1700014E RID: 334
	// (get) Token: 0x06000513 RID: 1299 RVA: 0x000064B3 File Offset: 0x000046B3
	internal Enum5 Enum5_0
	{
		get
		{
			return this.gclass31_0.Enum5_0;
		}
	}

	// Token: 0x1700014F RID: 335
	// (get) Token: 0x06000514 RID: 1300 RVA: 0x000064C0 File Offset: 0x000046C0
	protected GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
	}

	// Token: 0x17000150 RID: 336
	// (get) Token: 0x06000515 RID: 1301 RVA: 0x000064C8 File Offset: 0x000046C8
	// (set) Token: 0x06000516 RID: 1302 RVA: 0x000064D5 File Offset: 0x000046D5
	public bool Boolean_0
	{
		get
		{
			return this.gclass31_0.Boolean_0;
		}
		set
		{
			this.gclass31_0.Boolean_0 = value;
		}
	}

	// Token: 0x17000151 RID: 337
	// (get) Token: 0x06000517 RID: 1303 RVA: 0x000064E3 File Offset: 0x000046E3
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x17000152 RID: 338
	// (get) Token: 0x06000518 RID: 1304 RVA: 0x000064EB File Offset: 0x000046EB
	public GClass31 GClass31_0
	{
		get
		{
			return this.gclass31_0;
		}
	}

	// Token: 0x17000153 RID: 339
	// (get) Token: 0x06000519 RID: 1305
	public abstract Type \u200B\u206C\u200D\u206D\u206C\u202D\u202E\u206E\u202C\u206E\u206B\u206B\u202D\u200B\u200E\u206E\u200E\u200E\u206C\u200C\u206A\u202B\u202B\u202C\u202D\u200E\u202B\u206B\u206D\u200F\u200C\u202D\u206F\u202B\u206F\u200D\u200C\u200B\u202C\u200E\u202E { get; }

	// Token: 0x17000154 RID: 340
	// (get) Token: 0x0600051A RID: 1306 RVA: 0x000064F3 File Offset: 0x000046F3
	// (set) Token: 0x0600051B RID: 1307 RVA: 0x00006500 File Offset: 0x00004700
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.gclass31_0.TimeSpan_0;
		}
		set
		{
			this.gclass31_0.TimeSpan_0 = value;
		}
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x0000650E File Offset: 0x0000470E
	internal void method_0()
	{
		this.gclass31_0.method_14();
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0000651B File Offset: 0x0000471B
	internal void method_1(GClass46 gclass46_0)
	{
		this.GClass29.\u202A\u200C\u206D\u200B\u206E\u202A\u202C\u206D\u202B\u206F\u206D\u206E\u200F\u206A\u200D\u202C\u200B\u200E\u200E\u200B\u202B\u202E\u200D\u200D\u202C\u206D\u200E\u200B\u206E\u200D\u202D\u206D\u206C\u200D\u206E\u202D\u202C\u202E\u206C\u202A\u202E().method_6(gclass46_0, this.gclass31_0);
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0000652F File Offset: 0x0000472F
	internal void method_2(ushort ushort_0, string string_1)
	{
		this.gclass31_0.method_15(ushort_0, string_1);
	}

	// Token: 0x0600051F RID: 1311
	protected abstract GClass27 \u202A\u200C\u206D\u200B\u206E\u202A\u202C\u206D\u202B\u206F\u206D\u206E\u200F\u206A\u200D\u202C\u200B\u200E\u200E\u200B\u202B\u202E\u200D\u200D\u202C\u206D\u200E\u200B\u206E\u200D\u202D\u206D\u206C\u200D\u206E\u202D\u202C\u202E\u206C\u202A\u202E();

	// Token: 0x040002A2 RID: 674
	private GClass24 gclass24_0;

	// Token: 0x040002A3 RID: 675
	private string string_0;

	// Token: 0x040002A4 RID: 676
	private GClass31 gclass31_0;
}
