﻿using System;

// Token: 0x02000095 RID: 149
internal sealed class Class74
{
	// Token: 0x060006ED RID: 1773 RVA: 0x00007799 File Offset: 0x00005999
	internal Class74(string string_5, GClass37 gclass37_1)
	{
		this.string_1 = string_5;
		this.gclass37_0 = gclass37_1;
		this.method_0(string_5);
	}

	// Token: 0x170001D6 RID: 470
	// (get) Token: 0x060006EE RID: 1774 RVA: 0x000077B6 File Offset: 0x000059B6
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x170001D7 RID: 471
	// (get) Token: 0x060006EF RID: 1775 RVA: 0x000077BE File Offset: 0x000059BE
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x170001D8 RID: 472
	// (get) Token: 0x060006F0 RID: 1776 RVA: 0x000077C6 File Offset: 0x000059C6
	public GClass37 GClass37_0
	{
		get
		{
			return this.gclass37_0;
		}
	}

	// Token: 0x170001D9 RID: 473
	// (get) Token: 0x060006F1 RID: 1777 RVA: 0x000077CE File Offset: 0x000059CE
	public string String_1
	{
		get
		{
			return this.string_1;
		}
	}

	// Token: 0x170001DA RID: 474
	// (get) Token: 0x060006F2 RID: 1778 RVA: 0x000077D6 File Offset: 0x000059D6
	public string String_2
	{
		get
		{
			return this.string_2;
		}
	}

	// Token: 0x170001DB RID: 475
	// (get) Token: 0x060006F3 RID: 1779 RVA: 0x000077DE File Offset: 0x000059DE
	public string String_3
	{
		get
		{
			return this.string_3;
		}
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x000375DC File Offset: 0x000357DC
	private void method_0(string string_5)
	{
		if (string_5.StartsWith("https"))
		{
			this.bool_0 = true;
		}
		int length = string_5.Length;
		int num = string_5.IndexOf(':') + 3;
		int num2 = string_5.IndexOf('/', num + 1, length - num - 1);
		int num3 = string_5.LastIndexOf(':', num2 - 1, num2 - num - 1);
		if (string_5[num2 - 1] != ']' && num3 > num)
		{
			this.string_0 = string_5.Substring(num, num3 - num);
			this.string_3 = string_5.Substring(num3 + 1, num2 - num3 - 1);
		}
		else
		{
			this.string_0 = string_5.Substring(num, num2 - num);
			this.string_3 = (this.bool_0 ? "443" : "80");
		}
		this.string_2 = string_5.Substring(num2);
		this.string_4 = string.Format("{0}://{1}:{2}{3}", new object[]
		{
			this.bool_0 ? "https" : "http",
			this.string_0,
			this.string_3,
			this.string_2
		});
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x000376E8 File Offset: 0x000358E8
	public static void smethod_0(string string_5)
	{
		if (string_5 == null)
		{
			throw new ArgumentNullException("uriPrefix");
		}
		int length = string_5.Length;
		if (length == 0)
		{
			throw new ArgumentException("An empty string.", "uriPrefix");
		}
		if (!string_5.StartsWith("http://") && !string_5.StartsWith("https://"))
		{
			throw new ArgumentException("The scheme is not 'http' or 'https'.", "uriPrefix");
		}
		int num = length - 1;
		if (string_5[num] != '/')
		{
			throw new ArgumentException("It ends without '/'.", "uriPrefix");
		}
		int num2 = string_5.IndexOf(':') + 3;
		if (num2 >= num)
		{
			throw new ArgumentException("No host is specified.", "uriPrefix");
		}
		if (string_5[num2] == ':')
		{
			throw new ArgumentException("No host is specified.", "uriPrefix");
		}
		int num3 = string_5.IndexOf('/', num2, length - num2);
		if (num3 == num2)
		{
			throw new ArgumentException("No host is specified.", "uriPrefix");
		}
		if (string_5[num3 - 1] == ':')
		{
			throw new ArgumentException("No port is specified.", "uriPrefix");
		}
		if (num3 == num - 1)
		{
			throw new ArgumentException("No path is specified.", "uriPrefix");
		}
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x000377F8 File Offset: 0x000359F8
	public bool Equals(object obj)
	{
		Class74 @class = obj as Class74;
		return @class != null && this.string_4.Equals(@class.string_4);
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x000077E6 File Offset: 0x000059E6
	public int GetHashCode()
	{
		return this.string_4.GetHashCode();
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x000077F3 File Offset: 0x000059F3
	public string ToString()
	{
		return this.string_4;
	}

	// Token: 0x0400035E RID: 862
	private string string_0;

	// Token: 0x0400035F RID: 863
	private GClass37 gclass37_0;

	// Token: 0x04000360 RID: 864
	private string string_1;

	// Token: 0x04000361 RID: 865
	private string string_2;

	// Token: 0x04000362 RID: 866
	private string string_3;

	// Token: 0x04000363 RID: 867
	private string string_4;

	// Token: 0x04000364 RID: 868
	private bool bool_0;
}
