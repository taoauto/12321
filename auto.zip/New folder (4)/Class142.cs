﻿using System;
using System.IO;

// Token: 0x0200015E RID: 350
internal class Class142
{
	// Token: 0x17000448 RID: 1096
	// (get) Token: 0x060010A3 RID: 4259 RVA: 0x0000D7EA File Offset: 0x0000B9EA
	// (set) Token: 0x060010A4 RID: 4260 RVA: 0x0000D7F2 File Offset: 0x0000B9F2
	public int Int32_0
	{
		get
		{
			return this.int_1;
		}
		set
		{
			this.int_1 = value;
		}
	}

	// Token: 0x17000449 RID: 1097
	// (get) Token: 0x060010A5 RID: 4261 RVA: 0x0000D7FB File Offset: 0x0000B9FB
	// (set) Token: 0x060010A6 RID: 4262 RVA: 0x0005BB40 File Offset: 0x00059D40
	public Enum10 Enum10_0
	{
		get
		{
			return this.enum10_0;
		}
		set
		{
			this.enum10_0 = value;
			switch (this.enum10_0)
			{
			case Enum10.Connecting:
			case Enum10.Paused:
			case Enum10.Finished:
			case Enum10.Error:
				this.double_0 = 0.0;
				this.timeSpan_0 = TimeSpan.Zero;
				return;
			case Enum10.Downloading:
				this.method_0();
				return;
			default:
				return;
			}
		}
	}

	// Token: 0x1700044A RID: 1098
	// (get) Token: 0x060010A7 RID: 4263 RVA: 0x0000D803 File Offset: 0x0000BA03
	public DateTime DateTime_0
	{
		get
		{
			return this.dateTime_1;
		}
	}

	// Token: 0x1700044B RID: 1099
	// (get) Token: 0x060010A8 RID: 4264 RVA: 0x0000D80B File Offset: 0x0000BA0B
	// (set) Token: 0x060010A9 RID: 4265 RVA: 0x0000D813 File Offset: 0x0000BA13
	public Exception Exception_0
	{
		get
		{
			return this.exception_0;
		}
		set
		{
			if (value != null)
			{
				this.dateTime_1 = DateTime.Now;
			}
			else
			{
				this.dateTime_1 = DateTime.MinValue;
			}
			this.exception_0 = value;
		}
	}

	// Token: 0x1700044C RID: 1100
	// (get) Token: 0x060010AA RID: 4266 RVA: 0x0000D837 File Offset: 0x0000BA37
	// (set) Token: 0x060010AB RID: 4267 RVA: 0x0000D83F File Offset: 0x0000BA3F
	public int Int32_1
	{
		get
		{
			return this.int_0;
		}
		set
		{
			this.int_0 = value;
		}
	}

	// Token: 0x1700044D RID: 1101
	// (get) Token: 0x060010AC RID: 4268 RVA: 0x0000D848 File Offset: 0x0000BA48
	// (set) Token: 0x060010AD RID: 4269 RVA: 0x0000D850 File Offset: 0x0000BA50
	public long Int64_0
	{
		get
		{
			return this.long_1;
		}
		set
		{
			this.long_1 = value;
		}
	}

	// Token: 0x1700044E RID: 1102
	// (get) Token: 0x060010AE RID: 4270 RVA: 0x0000D859 File Offset: 0x0000BA59
	// (set) Token: 0x060010AF RID: 4271 RVA: 0x0000D861 File Offset: 0x0000BA61
	public long Int64_1
	{
		get
		{
			return this.long_0;
		}
		set
		{
			this.long_0 = value;
		}
	}

	// Token: 0x1700044F RID: 1103
	// (get) Token: 0x060010B0 RID: 4272 RVA: 0x0000D86A File Offset: 0x0000BA6A
	public long Int64_2
	{
		get
		{
			return this.Int64_1 - this.Int64_0;
		}
	}

	// Token: 0x17000450 RID: 1104
	// (get) Token: 0x060010B1 RID: 4273 RVA: 0x0000D879 File Offset: 0x0000BA79
	public long Int64_3
	{
		get
		{
			if (this.Int64_5 > 0L)
			{
				return this.Int64_5 - this.Int64_0;
			}
			return 0L;
		}
	}

	// Token: 0x17000451 RID: 1105
	// (get) Token: 0x060010B2 RID: 4274 RVA: 0x0000D895 File Offset: 0x0000BA95
	public long Int64_4
	{
		get
		{
			if (this.Int64_5 > 0L)
			{
				return this.Int64_5 - this.Int64_1;
			}
			return 0L;
		}
	}

	// Token: 0x17000452 RID: 1106
	// (get) Token: 0x060010B3 RID: 4275 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
	public double Double_0
	{
		get
		{
			if (this.Int64_5 > 0L)
			{
				return (double)this.Int64_2 / (double)this.Int64_3 * 100.0;
			}
			return 0.0;
		}
	}

	// Token: 0x17000453 RID: 1107
	// (get) Token: 0x060010B4 RID: 4276 RVA: 0x0000D8E0 File Offset: 0x0000BAE0
	// (set) Token: 0x060010B5 RID: 4277 RVA: 0x0000D8E8 File Offset: 0x0000BAE8
	public long Int64_5
	{
		get
		{
			return this.long_2;
		}
		set
		{
			this.long_2 = value;
		}
	}

	// Token: 0x17000454 RID: 1108
	// (get) Token: 0x060010B6 RID: 4278 RVA: 0x0000D8F1 File Offset: 0x0000BAF1
	// (set) Token: 0x060010B7 RID: 4279 RVA: 0x0000D8F9 File Offset: 0x0000BAF9
	public Stream Stream_0
	{
		get
		{
			return this.stream_0;
		}
		set
		{
			this.stream_0 = value;
		}
	}

	// Token: 0x17000455 RID: 1109
	// (get) Token: 0x060010B8 RID: 4280 RVA: 0x0000D902 File Offset: 0x0000BB02
	// (set) Token: 0x060010B9 RID: 4281 RVA: 0x0000D90A File Offset: 0x0000BB0A
	public Stream Stream_1
	{
		get
		{
			return this.stream_1;
		}
		set
		{
			this.stream_1 = value;
		}
	}

	// Token: 0x17000456 RID: 1110
	// (get) Token: 0x060010BA RID: 4282 RVA: 0x0000D913 File Offset: 0x0000BB13
	// (set) Token: 0x060010BB RID: 4283 RVA: 0x0000D91B File Offset: 0x0000BB1B
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
		}
	}

	// Token: 0x17000457 RID: 1111
	// (get) Token: 0x060010BC RID: 4284 RVA: 0x0000D924 File Offset: 0x0000BB24
	public double Double_1
	{
		get
		{
			if (this.Enum10_0 == Enum10.Downloading)
			{
				this.method_1(0L);
				return this.double_0;
			}
			return 0.0;
		}
	}

	// Token: 0x17000458 RID: 1112
	// (get) Token: 0x060010BD RID: 4285 RVA: 0x0000D947 File Offset: 0x0000BB47
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.timeSpan_0;
		}
	}

	// Token: 0x060010BE RID: 4286 RVA: 0x0000D94F File Offset: 0x0000BB4F
	public void method_0()
	{
		this.long_3 = this.long_0;
		this.dateTime_0 = DateTime.Now;
		this.bool_0 = true;
	}

	// Token: 0x060010BF RID: 4287 RVA: 0x0005BB9C File Offset: 0x00059D9C
	public void method_1(long long_4)
	{
		lock (this)
		{
			DateTime now = DateTime.Now;
			this.long_0 += long_4;
			if (this.bool_0)
			{
				TimeSpan timeSpan = now - this.dateTime_0;
				if (timeSpan.TotalSeconds != 0.0)
				{
					this.double_0 = (double)(this.long_0 - this.long_3) / timeSpan.TotalSeconds;
					if (this.double_0 > 0.0)
					{
						this.timeSpan_0 = TimeSpan.FromSeconds((double)this.Int64_4 / this.double_0);
					}
					else
					{
						this.timeSpan_0 = TimeSpan.MaxValue;
					}
				}
			}
			else
			{
				this.long_3 = this.long_0;
				this.dateTime_0 = now;
				this.bool_0 = true;
			}
		}
	}

	// Token: 0x04000867 RID: 2151
	private long long_0;

	// Token: 0x04000868 RID: 2152
	private int int_0;

	// Token: 0x04000869 RID: 2153
	private string string_0;

	// Token: 0x0400086A RID: 2154
	private long long_1;

	// Token: 0x0400086B RID: 2155
	private long long_2;

	// Token: 0x0400086C RID: 2156
	private Stream stream_0;

	// Token: 0x0400086D RID: 2157
	private Stream stream_1;

	// Token: 0x0400086E RID: 2158
	private Exception exception_0;

	// Token: 0x0400086F RID: 2159
	private Enum10 enum10_0;

	// Token: 0x04000870 RID: 2160
	private bool bool_0;

	// Token: 0x04000871 RID: 2161
	private DateTime dateTime_0 = DateTime.MinValue;

	// Token: 0x04000872 RID: 2162
	private DateTime dateTime_1 = DateTime.MinValue;

	// Token: 0x04000873 RID: 2163
	private double double_0;

	// Token: 0x04000874 RID: 2164
	private long long_3;

	// Token: 0x04000875 RID: 2165
	private TimeSpan timeSpan_0 = TimeSpan.Zero;

	// Token: 0x04000876 RID: 2166
	private int int_1;
}
