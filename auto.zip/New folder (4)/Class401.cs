﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020002D1 RID: 721
internal class Class401
{
	// Token: 0x06002994 RID: 10644
	[DllImport("User32.dll")]
	private static extern bool GetLastInputInfo(ref Struct5 struct5_0);

	// Token: 0x06002995 RID: 10645
	[DllImport("Kernel32.dll")]
	private static extern uint GetLastError();

	// Token: 0x06002996 RID: 10646 RVA: 0x0011D1A0 File Offset: 0x0011B3A0
	public static uint smethod_0()
	{
		Struct5 @struct = default(Struct5);
		@struct.uint_0 = (uint)Marshal.SizeOf(@struct);
		Class401.GetLastInputInfo(ref @struct);
		return (uint)((Environment.TickCount - (int)@struct.uint_1) / 1000);
	}

	// Token: 0x06002997 RID: 10647 RVA: 0x0011D1E4 File Offset: 0x0011B3E4
	public static long smethod_1()
	{
		Struct5 @struct = default(Struct5);
		@struct.uint_0 = (uint)Marshal.SizeOf(@struct);
		if (!Class401.GetLastInputInfo(ref @struct))
		{
			throw new Exception(Class401.GetLastError().ToString());
		}
		return (long)((ulong)@struct.uint_1);
	}
}
