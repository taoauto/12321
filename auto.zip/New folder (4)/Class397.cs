﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020002CA RID: 714
internal class Class397
{
	// Token: 0x1400004F RID: 79
	// (add) Token: 0x0600296D RID: 10605 RVA: 0x0011CA38 File Offset: 0x0011AC38
	// (remove) Token: 0x0600296E RID: 10606 RVA: 0x0011CA70 File Offset: 0x0011AC70
	public event KeyEventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			KeyEventHandler keyEventHandler = this.keyEventHandler_0;
			KeyEventHandler keyEventHandler2;
			do
			{
				keyEventHandler2 = keyEventHandler;
				KeyEventHandler value2 = (KeyEventHandler)Delegate.Combine(keyEventHandler2, value);
				keyEventHandler = Interlocked.CompareExchange<KeyEventHandler>(ref this.keyEventHandler_0, value2, keyEventHandler2);
			}
			while (keyEventHandler != keyEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			KeyEventHandler keyEventHandler = this.keyEventHandler_0;
			KeyEventHandler keyEventHandler2;
			do
			{
				keyEventHandler2 = keyEventHandler;
				KeyEventHandler value2 = (KeyEventHandler)Delegate.Remove(keyEventHandler2, value);
				keyEventHandler = Interlocked.CompareExchange<KeyEventHandler>(ref this.keyEventHandler_0, value2, keyEventHandler2);
			}
			while (keyEventHandler != keyEventHandler2);
		}
	}

	// Token: 0x14000050 RID: 80
	// (add) Token: 0x0600296F RID: 10607 RVA: 0x0011CAA8 File Offset: 0x0011ACA8
	// (remove) Token: 0x06002970 RID: 10608 RVA: 0x0011CAE0 File Offset: 0x0011ACE0
	public event KeyEventHandler Event_1
	{
		[CompilerGenerated]
		add
		{
			KeyEventHandler keyEventHandler = this.keyEventHandler_1;
			KeyEventHandler keyEventHandler2;
			do
			{
				keyEventHandler2 = keyEventHandler;
				KeyEventHandler value2 = (KeyEventHandler)Delegate.Combine(keyEventHandler2, value);
				keyEventHandler = Interlocked.CompareExchange<KeyEventHandler>(ref this.keyEventHandler_1, value2, keyEventHandler2);
			}
			while (keyEventHandler != keyEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			KeyEventHandler keyEventHandler = this.keyEventHandler_1;
			KeyEventHandler keyEventHandler2;
			do
			{
				keyEventHandler2 = keyEventHandler;
				KeyEventHandler value2 = (KeyEventHandler)Delegate.Remove(keyEventHandler2, value);
				keyEventHandler = Interlocked.CompareExchange<KeyEventHandler>(ref this.keyEventHandler_1, value2, keyEventHandler2);
			}
			while (keyEventHandler != keyEventHandler2);
		}
	}

	// Token: 0x06002971 RID: 10609 RVA: 0x0001E726 File Offset: 0x0001C926
	public Class397()
	{
		this.method_0();
	}

	// Token: 0x14000051 RID: 81
	// (add) Token: 0x06002972 RID: 10610 RVA: 0x0011CB18 File Offset: 0x0011AD18
	// (remove) Token: 0x06002973 RID: 10611 RVA: 0x0011CB50 File Offset: 0x0011AD50
	public event EventHandler Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06002974 RID: 10612 RVA: 0x0011CB88 File Offset: 0x0011AD88
	virtual ~Class397()
	{
		this.method_1();
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(null, null);
		}
	}

	// Token: 0x06002975 RID: 10613 RVA: 0x0011CBCC File Offset: 0x0011ADCC
	public void method_0()
	{
		IntPtr intptr_ = Class397.LoadLibrary("User32");
		Class397.delegate7_0 = new Class397.Delegate7(this.method_2);
		this.intptr_0 = Class397.SetWindowsHookEx(13, Class397.delegate7_0, intptr_, 0U);
	}

	// Token: 0x06002976 RID: 10614 RVA: 0x0001E74A File Offset: 0x0001C94A
	public void method_1()
	{
		Class397.UnhookWindowsHookEx(this.intptr_0);
	}

	// Token: 0x06002977 RID: 10615 RVA: 0x0011CC0C File Offset: 0x0011AE0C
	public int method_2(int int_5, int int_6, ref Class397.Struct4 struct4_0)
	{
		if (int_5 >= 0)
		{
			Keys keys = (Keys)struct4_0.int_0;
			if (this.list_0.Contains(keys))
			{
				KeyEventArgs keyEventArgs = new KeyEventArgs(keys);
				if ((int_6 == 256 || int_6 == 260) && this.keyEventHandler_0 != null)
				{
					this.keyEventHandler_0(this, keyEventArgs);
				}
				else if ((int_6 == 257 || int_6 == 261) && this.keyEventHandler_1 != null)
				{
					this.keyEventHandler_1(this, keyEventArgs);
				}
				if (keyEventArgs.Handled)
				{
					return 1;
				}
			}
		}
		return Class397.CallNextHookEx(this.intptr_0, int_5, int_6, ref struct4_0);
	}

	// Token: 0x06002978 RID: 10616
	[DllImport("user32.dll")]
	private static extern IntPtr SetWindowsHookEx(int int_5, Class397.Delegate7 delegate7_1, IntPtr intptr_1, uint uint_0);

	// Token: 0x06002979 RID: 10617
	[DllImport("user32.dll")]
	private static extern bool UnhookWindowsHookEx(IntPtr intptr_1);

	// Token: 0x0600297A RID: 10618
	[DllImport("user32.dll")]
	private static extern int CallNextHookEx(IntPtr intptr_1, int int_5, int int_6, ref Class397.Struct4 struct4_0);

	// Token: 0x0600297B RID: 10619
	[DllImport("kernel32.dll")]
	private static extern IntPtr LoadLibrary(string string_0);

	// Token: 0x04001BBF RID: 7103
	public static Class397.Delegate7 delegate7_0;

	// Token: 0x04001BC0 RID: 7104
	private const int int_0 = 13;

	// Token: 0x04001BC1 RID: 7105
	private const int int_1 = 256;

	// Token: 0x04001BC2 RID: 7106
	private const int int_2 = 257;

	// Token: 0x04001BC3 RID: 7107
	private const int int_3 = 260;

	// Token: 0x04001BC4 RID: 7108
	private const int int_4 = 261;

	// Token: 0x04001BC5 RID: 7109
	public List<Keys> list_0 = new List<Keys>();

	// Token: 0x04001BC6 RID: 7110
	private IntPtr intptr_0 = IntPtr.Zero;

	// Token: 0x04001BC7 RID: 7111
	[CompilerGenerated]
	private KeyEventHandler keyEventHandler_0;

	// Token: 0x04001BC8 RID: 7112
	[CompilerGenerated]
	private KeyEventHandler keyEventHandler_1;

	// Token: 0x04001BC9 RID: 7113
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x020002CB RID: 715
	// (Invoke) Token: 0x0600297D RID: 10621
	public delegate int Delegate7(int code, int wParam, ref Class397.Struct4 lParam);

	// Token: 0x020002CC RID: 716
	public struct Struct4
	{
		// Token: 0x04001BCA RID: 7114
		public int int_0;

		// Token: 0x04001BCB RID: 7115
		public int int_1;

		// Token: 0x04001BCC RID: 7116
		public int int_2;

		// Token: 0x04001BCD RID: 7117
		public int int_3;

		// Token: 0x04001BCE RID: 7118
		public int int_4;
	}
}
