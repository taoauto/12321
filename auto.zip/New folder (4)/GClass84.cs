﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

// Token: 0x0200010E RID: 270
public class GClass84
{
	// Token: 0x06000DB7 RID: 3511 RVA: 0x0000BCE7 File Offset: 0x00009EE7
	internal GClass84(FastColoredTextBox fastColoredTextBox_1)
	{
		this.FastColoredTextBox_0 = fastColoredTextBox_1;
		this.Boolean_0 = true;
	}

	// Token: 0x170003A4 RID: 932
	// (get) Token: 0x06000DB8 RID: 3512 RVA: 0x0000BD08 File Offset: 0x00009F08
	// (set) Token: 0x06000DB9 RID: 3513 RVA: 0x0000BD10 File Offset: 0x00009F10
	public bool Boolean_0 { get; set; }

	// Token: 0x170003A5 RID: 933
	// (get) Token: 0x06000DBA RID: 3514 RVA: 0x0000BD19 File Offset: 0x00009F19
	// (set) Token: 0x06000DBB RID: 3515 RVA: 0x0000BD21 File Offset: 0x00009F21
	public bool Boolean_1
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
			this.FastColoredTextBox_0.method_4();
		}
	}

	// Token: 0x170003A6 RID: 934
	// (get) Token: 0x06000DBC RID: 3516 RVA: 0x0000BD35 File Offset: 0x00009F35
	// (set) Token: 0x06000DBD RID: 3517 RVA: 0x0000BD3D File Offset: 0x00009F3D
	public FastColoredTextBox FastColoredTextBox_0 { get; private set; }

	// Token: 0x06000DBE RID: 3518 RVA: 0x00050AB4 File Offset: 0x0004ECB4
	public void method_0()
	{
		this.Boolean_1 = false;
		this.FastColoredTextBox_0.method_87();
		this.FastColoredTextBox_0.GClass86_5.method_38();
		this.FastColoredTextBox_0.method_108();
		foreach (object obj in this.list_0)
		{
			if (obj is Keys)
			{
				this.FastColoredTextBox_0.vmethod_30((Keys)obj);
			}
			if (obj is KeyValuePair<char, Keys>)
			{
				KeyValuePair<char, Keys> keyValuePair = (KeyValuePair<char, Keys>)obj;
				this.FastColoredTextBox_0.vmethod_41(keyValuePair.Key, keyValuePair.Value);
			}
		}
		this.FastColoredTextBox_0.method_109();
		this.FastColoredTextBox_0.GClass86_5.method_39();
		this.FastColoredTextBox_0.method_88();
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0000BD46 File Offset: 0x00009F46
	public void method_1(char char_0, Keys keys_0)
	{
		this.list_0.Add(new KeyValuePair<char, Keys>(char_0, keys_0));
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x0000BD5F File Offset: 0x00009F5F
	public void method_2(Keys keys_0)
	{
		this.list_0.Add(keys_0);
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0000BD72 File Offset: 0x00009F72
	public void method_3()
	{
		this.list_0.Clear();
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x0000BD7F File Offset: 0x00009F7F
	internal void method_4(Keys keys_0)
	{
		if (this.Boolean_1)
		{
			this.method_2(keys_0);
		}
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x0000BD90 File Offset: 0x00009F90
	internal void method_5(char char_0, Keys keys_0)
	{
		if (this.Boolean_1)
		{
			this.method_1(char_0, keys_0);
		}
	}

	// Token: 0x170003A7 RID: 935
	// (get) Token: 0x06000DC4 RID: 3524 RVA: 0x0000BDA2 File Offset: 0x00009FA2
	public bool Boolean_2
	{
		get
		{
			return this.list_0.Count == 0;
		}
	}

	// Token: 0x170003A8 RID: 936
	// (get) Token: 0x06000DC5 RID: 3525 RVA: 0x00050B98 File Offset: 0x0004ED98
	// (set) Token: 0x06000DC6 RID: 3526 RVA: 0x00050C9C File Offset: 0x0004EE9C
	public string String_0
	{
		get
		{
			CultureInfo currentUICulture = Thread.CurrentThread.CurrentUICulture;
			Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
			KeysConverter keysConverter = new KeysConverter();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("<macros>");
			foreach (object obj in this.list_0)
			{
				if (obj is Keys)
				{
					stringBuilder.AppendFormat("<item key='{0}' />\r\n", keysConverter.ConvertToString((Keys)obj));
				}
				else if (obj is KeyValuePair<char, Keys>)
				{
					KeyValuePair<char, Keys> keyValuePair = (KeyValuePair<char, Keys>)obj;
					stringBuilder.AppendFormat("<item char='{0}' key='{1}' />\r\n", (int)keyValuePair.Key, keysConverter.ConvertToString(keyValuePair.Value));
				}
			}
			stringBuilder.AppendLine("</macros>");
			Thread.CurrentThread.CurrentUICulture = currentUICulture;
			return stringBuilder.ToString();
		}
		set
		{
			this.bool_1 = false;
			this.method_3();
			if (string.IsNullOrEmpty(value))
			{
				return;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(value);
			XmlNodeList xmlNodeList = xmlDocument.SelectNodes("./macros/item");
			CultureInfo currentUICulture = Thread.CurrentThread.CurrentUICulture;
			Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
			KeysConverter keysConverter = new KeysConverter();
			if (xmlNodeList != null)
			{
				foreach (object obj in xmlNodeList)
				{
					XmlElement xmlElement = (XmlElement)obj;
					XmlAttribute attributeNode = xmlElement.GetAttributeNode("char");
					XmlAttribute attributeNode2 = xmlElement.GetAttributeNode("key");
					if (attributeNode != null)
					{
						if (attributeNode2 != null)
						{
							this.method_1((char)int.Parse(attributeNode.Value), (Keys)keysConverter.ConvertFromString(attributeNode2.Value));
						}
						else
						{
							this.method_1((char)int.Parse(attributeNode.Value), Keys.None);
						}
					}
					else if (attributeNode2 != null)
					{
						this.method_2((Keys)keysConverter.ConvertFromString(attributeNode2.Value));
					}
				}
			}
			Thread.CurrentThread.CurrentUICulture = currentUICulture;
		}
	}

	// Token: 0x040006BE RID: 1726
	private readonly List<object> list_0 = new List<object>();

	// Token: 0x040006BF RID: 1727
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040006C0 RID: 1728
	private bool bool_1;

	// Token: 0x040006C1 RID: 1729
	[CompilerGenerated]
	private FastColoredTextBox fastColoredTextBox_0;
}
