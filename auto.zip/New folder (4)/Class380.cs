﻿using System;

// Token: 0x020002B6 RID: 694
internal class Class380
{
	// Token: 0x040019EB RID: 6635
	public static int int_0 = -1;

	// Token: 0x040019EC RID: 6636
	public static int int_1 = 0;

	// Token: 0x040019ED RID: 6637
	public static int int_2 = 1;

	// Token: 0x040019EE RID: 6638
	public static int int_3 = 2;

	// Token: 0x040019EF RID: 6639
	public static int int_4 = 3;

	// Token: 0x040019F0 RID: 6640
	public static int int_5 = 4;

	// Token: 0x040019F1 RID: 6641
	public static int int_6 = 5;

	// Token: 0x040019F2 RID: 6642
	public static int int_7 = 6;

	// Token: 0x040019F3 RID: 6643
	public static int int_8 = 7;

	// Token: 0x040019F4 RID: 6644
	public static int int_9 = 8;

	// Token: 0x040019F5 RID: 6645
	public static int int_10 = 9;

	// Token: 0x040019F6 RID: 6646
	public static int int_11 = 10;

	// Token: 0x040019F7 RID: 6647
	public static int int_12 = 11;

	// Token: 0x040019F8 RID: 6648
	public static int int_13 = 12;

	// Token: 0x040019F9 RID: 6649
	public static int int_14 = 13;

	// Token: 0x040019FA RID: 6650
	public static int int_15 = 15;

	// Token: 0x040019FB RID: 6651
	public static int int_16 = 16;

	// Token: 0x040019FC RID: 6652
	public static int int_17 = 17;

	// Token: 0x040019FD RID: 6653
	public static int int_18 = 18;

	// Token: 0x040019FE RID: 6654
	public static int int_19 = 19;

	// Token: 0x040019FF RID: 6655
	public static int int_20 = 20;

	// Token: 0x04001A00 RID: 6656
	public static int int_21 = 21;

	// Token: 0x04001A01 RID: 6657
	public static int int_22 = 22;

	// Token: 0x04001A02 RID: 6658
	public static int int_23 = 23;

	// Token: 0x04001A03 RID: 6659
	public static int int_24 = 24;

	// Token: 0x04001A04 RID: 6660
	public static int int_25 = 25;

	// Token: 0x04001A05 RID: 6661
	public static int int_26 = 26;

	// Token: 0x04001A06 RID: 6662
	public static int int_27 = 27;

	// Token: 0x04001A07 RID: 6663
	public static int int_28 = 28;

	// Token: 0x04001A08 RID: 6664
	public static int int_29 = 31;

	// Token: 0x04001A09 RID: 6665
	public static int int_30 = 32;

	// Token: 0x04001A0A RID: 6666
	public static int int_31 = 33;

	// Token: 0x04001A0B RID: 6667
	public static int int_32 = 34;

	// Token: 0x04001A0C RID: 6668
	public static int int_33 = 35;

	// Token: 0x04001A0D RID: 6669
	public static int int_34 = 36;

	// Token: 0x04001A0E RID: 6670
	public static int int_35 = 37;

	// Token: 0x04001A0F RID: 6671
	public static int int_36 = 38;

	// Token: 0x04001A10 RID: 6672
	public static int int_37 = 39;

	// Token: 0x04001A11 RID: 6673
	public static int int_38 = 40;

	// Token: 0x04001A12 RID: 6674
	public static int int_39 = 41;

	// Token: 0x04001A13 RID: 6675
	public static int int_40 = 42;

	// Token: 0x04001A14 RID: 6676
	public static int int_41 = 43;

	// Token: 0x04001A15 RID: 6677
	public static int int_42 = 44;

	// Token: 0x04001A16 RID: 6678
	public static int int_43 = 45;

	// Token: 0x04001A17 RID: 6679
	public static int int_44 = 46;

	// Token: 0x04001A18 RID: 6680
	public static int int_45 = 47;

	// Token: 0x04001A19 RID: 6681
	public static int int_46 = 48;

	// Token: 0x04001A1A RID: 6682
	public static int int_47 = 49;

	// Token: 0x04001A1B RID: 6683
	public static int int_48 = 50;

	// Token: 0x04001A1C RID: 6684
	public static int int_49 = 51;

	// Token: 0x04001A1D RID: 6685
	public static int int_50 = 52;

	// Token: 0x04001A1E RID: 6686
	public static int int_51 = 53;

	// Token: 0x04001A1F RID: 6687
	public static int int_52 = 54;

	// Token: 0x04001A20 RID: 6688
	public static int int_53 = 55;

	// Token: 0x04001A21 RID: 6689
	public static int int_54 = 56;

	// Token: 0x04001A22 RID: 6690
	public static int int_55 = 57;

	// Token: 0x04001A23 RID: 6691
	public static int int_56 = 58;

	// Token: 0x04001A24 RID: 6692
	public static int int_57 = 29;

	// Token: 0x04001A25 RID: 6693
	public static int int_58 = 30;

	// Token: 0x04001A26 RID: 6694
	public static int int_59 = 59;
}
