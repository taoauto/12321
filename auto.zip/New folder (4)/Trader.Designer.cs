﻿// Token: 0x02000311 RID: 785
internal partial class Trader : global::System.Windows.Forms.Form
{
	// Token: 0x06002D79 RID: 11641 RVA: 0x00130F34 File Offset: 0x0012F134
	private void InitializeComponent()
	{
		this.btnSaveWay = new global::System.Windows.Forms.Button();
		this.txtCodeTN = new global::System.Windows.Forms.TextBox();
		this.groupBox3 = new global::System.Windows.Forms.GroupBox();
		this.btnGetThanhTT = new global::System.Windows.Forms.Button();
		this.btnGetTTCityID = new global::System.Windows.Forms.Button();
		this.label17 = new global::System.Windows.Forms.Label();
		this.cboRefCity = new global::System.Windows.Forms.ComboBox();
		this.nudRefCityClick2 = new global::System.Windows.Forms.NumericUpDown();
		this.label19 = new global::System.Windows.Forms.Label();
		this.cboIdxRefCity = new global::System.Windows.Forms.ComboBox();
		this.label20 = new global::System.Windows.Forms.Label();
		this.nudRefCityClick1 = new global::System.Windows.Forms.NumericUpDown();
		this.nudRefCityId = new global::System.Windows.Forms.NumericUpDown();
		this.label21 = new global::System.Windows.Forms.Label();
		this.groupBox4 = new global::System.Windows.Forms.GroupBox();
		this.btnGetThanh = new global::System.Windows.Forms.Button();
		this.btnGetMyCityID = new global::System.Windows.Forms.Button();
		this.label22 = new global::System.Windows.Forms.Label();
		this.cboCity = new global::System.Windows.Forms.ComboBox();
		this.nudCityClick2 = new global::System.Windows.Forms.NumericUpDown();
		this.label23 = new global::System.Windows.Forms.Label();
		this.cboIdxCity = new global::System.Windows.Forms.ComboBox();
		this.label24 = new global::System.Windows.Forms.Label();
		this.nudCityClick1 = new global::System.Windows.Forms.NumericUpDown();
		this.nudCityId = new global::System.Windows.Forms.NumericUpDown();
		this.label25 = new global::System.Windows.Forms.Label();
		this.btnBack = new global::System.Windows.Forms.Button();
		this.btnGo = new global::System.Windows.Forms.Button();
		this.btnStop = new global::System.Windows.Forms.Button();
		this.groupBox3.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityClick2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityClick1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityId).BeginInit();
		this.groupBox4.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityClick2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityClick1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityId).BeginInit();
		base.SuspendLayout();
		this.btnSaveWay.Location = new global::System.Drawing.Point(12, 330);
		this.btnSaveWay.Name = "btnSaveWay";
		this.btnSaveWay.Size = new global::System.Drawing.Size(247, 23);
		this.btnSaveWay.TabIndex = 49;
		this.btnSaveWay.Text = "Save";
		this.btnSaveWay.UseVisualStyleBackColor = true;
		this.btnSaveWay.Click += new global::System.EventHandler(this.btnSaveWay_Click);
		this.txtCodeTN.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.txtCodeTN.Location = new global::System.Drawing.Point(13, 304);
		this.txtCodeTN.Name = "txtCodeTN";
		this.txtCodeTN.Size = new global::System.Drawing.Size(246, 20);
		this.txtCodeTN.TabIndex = 48;
		this.groupBox3.Controls.Add(this.btnGetThanhTT);
		this.groupBox3.Controls.Add(this.btnGetTTCityID);
		this.groupBox3.Controls.Add(this.label17);
		this.groupBox3.Controls.Add(this.cboRefCity);
		this.groupBox3.Controls.Add(this.nudRefCityClick2);
		this.groupBox3.Controls.Add(this.label19);
		this.groupBox3.Controls.Add(this.cboIdxRefCity);
		this.groupBox3.Controls.Add(this.label20);
		this.groupBox3.Controls.Add(this.nudRefCityClick1);
		this.groupBox3.Controls.Add(this.nudRefCityId);
		this.groupBox3.Controls.Add(this.label21);
		this.groupBox3.Location = new global::System.Drawing.Point(12, 158);
		this.groupBox3.Name = "groupBox3";
		this.groupBox3.Size = new global::System.Drawing.Size(247, 140);
		this.groupBox3.TabIndex = 47;
		this.groupBox3.TabStop = false;
		this.groupBox3.Text = "Thành thông thương";
		this.btnGetThanhTT.Location = new global::System.Drawing.Point(189, 23);
		this.btnGetThanhTT.Name = "btnGetThanhTT";
		this.btnGetThanhTT.Size = new global::System.Drawing.Size(36, 23);
		this.btnGetThanhTT.TabIndex = 42;
		this.btnGetThanhTT.Text = "Get";
		this.btnGetThanhTT.UseVisualStyleBackColor = true;
		this.btnGetThanhTT.Click += new global::System.EventHandler(this.btnGetThanhTT_Click);
		this.btnGetTTCityID.Location = new global::System.Drawing.Point(147, 102);
		this.btnGetTTCityID.Name = "btnGetTTCityID";
		this.btnGetTTCityID.Size = new global::System.Drawing.Size(36, 23);
		this.btnGetTTCityID.TabIndex = 41;
		this.btnGetTTCityID.Text = "Get";
		this.btnGetTTCityID.UseVisualStyleBackColor = true;
		this.btnGetTTCityID.Click += new global::System.EventHandler(this.btnGetTTCityID_Click);
		this.label17.AutoSize = true;
		this.label17.Location = new global::System.Drawing.Point(27, 27);
		this.label17.Name = "label17";
		this.label17.Size = new global::System.Drawing.Size(16, 13);
		this.label17.TabIndex = 23;
		this.label17.Text = "In";
		this.cboRefCity.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboRefCity.FormattingEnabled = true;
		this.cboRefCity.Items.AddRange(new object[]
		{
			"tungson",
			"thaiho",
			"kiemcac",
			"donhoang",
			"nhannam",
			"nhanbac",
			"thaonguyen",
			"lieutay",
			"truongbachson",
			"hoanglongphu",
			"nhihai",
			"thuongson",
			"thachlam",
			"ngockhue",
			"namchieu",
			"mieucuong",
			"tayho",
			"longtuyen",
			"vodi",
			"mailinh",
			"namhai",
			"quynhchau"
		});
		this.cboRefCity.Location = new global::System.Drawing.Point(85, 24);
		this.cboRefCity.Name = "cboRefCity";
		this.cboRefCity.Size = new global::System.Drawing.Size(98, 21);
		this.cboRefCity.TabIndex = 24;
		this.cboRefCity.SelectedIndexChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.nudRefCityClick2.Location = new global::System.Drawing.Point(149, 78);
		global::System.Windows.Forms.NumericUpDown numericUpDown = this.nudRefCityClick2;
		int[] array = new int[4];
		array[0] = 999999999;
		numericUpDown.Maximum = new decimal(array);
		this.nudRefCityClick2.Name = "nudRefCityClick2";
		this.nudRefCityClick2.Size = new global::System.Drawing.Size(34, 20);
		this.nudRefCityClick2.TabIndex = 39;
		this.nudRefCityClick2.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label19.AutoSize = true;
		this.label19.Location = new global::System.Drawing.Point(27, 54);
		this.label19.Name = "label19";
		this.label19.Size = new global::System.Drawing.Size(33, 13);
		this.label19.TabIndex = 27;
		this.label19.Text = "Index";
		this.cboIdxRefCity.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboIdxRefCity.FormattingEnabled = true;
		this.cboIdxRefCity.Items.AddRange(new object[]
		{
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"10",
			"11",
			"12",
			"13",
			"14",
			"15",
			"16",
			"17",
			"18",
			"19",
			"20"
		});
		this.cboIdxRefCity.Location = new global::System.Drawing.Point(85, 51);
		this.cboIdxRefCity.Name = "cboIdxRefCity";
		this.cboIdxRefCity.Size = new global::System.Drawing.Size(98, 21);
		this.cboIdxRefCity.TabIndex = 28;
		this.cboIdxRefCity.SelectedIndexChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label20.AutoSize = true;
		this.label20.Location = new global::System.Drawing.Point(27, 80);
		this.label20.Name = "label20";
		this.label20.Size = new global::System.Drawing.Size(30, 13);
		this.label20.TabIndex = 35;
		this.label20.Text = "Click";
		this.nudRefCityClick1.Location = new global::System.Drawing.Point(85, 78);
		global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.nudRefCityClick1;
		int[] array2 = new int[4];
		array2[0] = 999999999;
		numericUpDown2.Maximum = new decimal(array2);
		this.nudRefCityClick1.Name = "nudRefCityClick1";
		this.nudRefCityClick1.Size = new global::System.Drawing.Size(58, 20);
		this.nudRefCityClick1.TabIndex = 36;
		this.nudRefCityClick1.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.nudRefCityId.Location = new global::System.Drawing.Point(85, 104);
		global::System.Windows.Forms.NumericUpDown numericUpDown3 = this.nudRefCityId;
		int[] array3 = new int[4];
		array3[0] = 1000;
		numericUpDown3.Maximum = new decimal(array3);
		this.nudRefCityId.Name = "nudRefCityId";
		this.nudRefCityId.Size = new global::System.Drawing.Size(58, 20);
		this.nudRefCityId.TabIndex = 32;
		global::System.Windows.Forms.NumericUpDown numericUpDown4 = this.nudRefCityId;
		int[] array4 = new int[4];
		array4[0] = 500;
		numericUpDown4.Value = new decimal(array4);
		this.nudRefCityId.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label21.AutoSize = true;
		this.label21.Location = new global::System.Drawing.Point(27, 106);
		this.label21.Name = "label21";
		this.label21.Size = new global::System.Drawing.Size(16, 13);
		this.label21.TabIndex = 31;
		this.label21.Text = "Id";
		this.groupBox4.Controls.Add(this.btnGetThanh);
		this.groupBox4.Controls.Add(this.btnGetMyCityID);
		this.groupBox4.Controls.Add(this.label22);
		this.groupBox4.Controls.Add(this.cboCity);
		this.groupBox4.Controls.Add(this.nudCityClick2);
		this.groupBox4.Controls.Add(this.label23);
		this.groupBox4.Controls.Add(this.cboIdxCity);
		this.groupBox4.Controls.Add(this.label24);
		this.groupBox4.Controls.Add(this.nudCityClick1);
		this.groupBox4.Controls.Add(this.nudCityId);
		this.groupBox4.Controls.Add(this.label25);
		this.groupBox4.Location = new global::System.Drawing.Point(12, 12);
		this.groupBox4.Name = "groupBox4";
		this.groupBox4.Size = new global::System.Drawing.Size(247, 140);
		this.groupBox4.TabIndex = 46;
		this.groupBox4.TabStop = false;
		this.groupBox4.Text = "Thành của bang";
		this.btnGetThanh.Location = new global::System.Drawing.Point(189, 23);
		this.btnGetThanh.Name = "btnGetThanh";
		this.btnGetThanh.Size = new global::System.Drawing.Size(36, 23);
		this.btnGetThanh.TabIndex = 41;
		this.btnGetThanh.Text = "Get";
		this.btnGetThanh.UseVisualStyleBackColor = true;
		this.btnGetThanh.Click += new global::System.EventHandler(this.btnGetThanh_Click);
		this.btnGetMyCityID.Location = new global::System.Drawing.Point(147, 102);
		this.btnGetMyCityID.Name = "btnGetMyCityID";
		this.btnGetMyCityID.Size = new global::System.Drawing.Size(36, 23);
		this.btnGetMyCityID.TabIndex = 40;
		this.btnGetMyCityID.Text = "Get";
		this.btnGetMyCityID.UseVisualStyleBackColor = true;
		this.btnGetMyCityID.Click += new global::System.EventHandler(this.btnGetMyCityID_Click);
		this.label22.AutoSize = true;
		this.label22.Location = new global::System.Drawing.Point(27, 27);
		this.label22.Name = "label22";
		this.label22.Size = new global::System.Drawing.Size(16, 13);
		this.label22.TabIndex = 23;
		this.label22.Text = "In";
		this.cboCity.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboCity.FormattingEnabled = true;
		this.cboCity.Items.AddRange(new object[]
		{
			"tungson",
			"thaiho",
			"kiemcac",
			"donhoang",
			"nhannam",
			"nhanbac",
			"thaonguyen",
			"lieutay",
			"truongbachson",
			"hoanglongphu",
			"nhihai",
			"thuongson",
			"thachlam",
			"ngockhue",
			"namchieu",
			"mieucuong",
			"tayho",
			"longtuyen",
			"vodi",
			"mailinh",
			"namhai",
			"quynhchau"
		});
		this.cboCity.Location = new global::System.Drawing.Point(85, 24);
		this.cboCity.Name = "cboCity";
		this.cboCity.Size = new global::System.Drawing.Size(98, 21);
		this.cboCity.TabIndex = 24;
		this.cboCity.SelectedIndexChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.nudCityClick2.Location = new global::System.Drawing.Point(149, 78);
		global::System.Windows.Forms.NumericUpDown numericUpDown5 = this.nudCityClick2;
		int[] array5 = new int[4];
		array5[0] = 999999999;
		numericUpDown5.Maximum = new decimal(array5);
		this.nudCityClick2.Name = "nudCityClick2";
		this.nudCityClick2.Size = new global::System.Drawing.Size(34, 20);
		this.nudCityClick2.TabIndex = 39;
		this.nudCityClick2.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label23.AutoSize = true;
		this.label23.Location = new global::System.Drawing.Point(27, 54);
		this.label23.Name = "label23";
		this.label23.Size = new global::System.Drawing.Size(33, 13);
		this.label23.TabIndex = 27;
		this.label23.Text = "Index";
		this.cboIdxCity.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cboIdxCity.FormattingEnabled = true;
		this.cboIdxCity.Items.AddRange(new object[]
		{
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"10",
			"11",
			"12",
			"13",
			"14",
			"15",
			"16",
			"17",
			"18",
			"19",
			"20"
		});
		this.cboIdxCity.Location = new global::System.Drawing.Point(85, 51);
		this.cboIdxCity.Name = "cboIdxCity";
		this.cboIdxCity.Size = new global::System.Drawing.Size(98, 21);
		this.cboIdxCity.TabIndex = 28;
		this.cboIdxCity.SelectedIndexChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label24.AutoSize = true;
		this.label24.Location = new global::System.Drawing.Point(27, 80);
		this.label24.Name = "label24";
		this.label24.Size = new global::System.Drawing.Size(30, 13);
		this.label24.TabIndex = 35;
		this.label24.Text = "Click";
		this.nudCityClick1.Location = new global::System.Drawing.Point(85, 78);
		global::System.Windows.Forms.NumericUpDown numericUpDown6 = this.nudCityClick1;
		int[] array6 = new int[4];
		array6[0] = 999999999;
		numericUpDown6.Maximum = new decimal(array6);
		this.nudCityClick1.Name = "nudCityClick1";
		this.nudCityClick1.Size = new global::System.Drawing.Size(58, 20);
		this.nudCityClick1.TabIndex = 36;
		this.nudCityClick1.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.nudCityId.Location = new global::System.Drawing.Point(85, 104);
		global::System.Windows.Forms.NumericUpDown numericUpDown7 = this.nudCityId;
		int[] array7 = new int[4];
		array7[0] = 1000;
		numericUpDown7.Maximum = new decimal(array7);
		this.nudCityId.Name = "nudCityId";
		this.nudCityId.Size = new global::System.Drawing.Size(58, 20);
		this.nudCityId.TabIndex = 32;
		global::System.Windows.Forms.NumericUpDown numericUpDown8 = this.nudCityId;
		int[] array8 = new int[4];
		array8[0] = 500;
		numericUpDown8.Value = new decimal(array8);
		this.nudCityId.ValueChanged += new global::System.EventHandler(this.nudCityId_ValueChanged);
		this.label25.AutoSize = true;
		this.label25.Location = new global::System.Drawing.Point(27, 106);
		this.label25.Name = "label25";
		this.label25.Size = new global::System.Drawing.Size(16, 13);
		this.label25.TabIndex = 31;
		this.label25.Text = "Id";
		this.btnBack.Location = new global::System.Drawing.Point(13, 359);
		this.btnBack.Name = "btnBack";
		this.btnBack.Size = new global::System.Drawing.Size(75, 23);
		this.btnBack.TabIndex = 50;
		this.btnBack.Text = "Ctrl + <-";
		this.btnBack.UseVisualStyleBackColor = true;
		this.btnBack.Click += new global::System.EventHandler(this.btnBack_Click);
		this.btnGo.Location = new global::System.Drawing.Point(185, 359);
		this.btnGo.Name = "btnGo";
		this.btnGo.Size = new global::System.Drawing.Size(75, 23);
		this.btnGo.TabIndex = 51;
		this.btnGo.Text = "Ctrl + ->";
		this.btnGo.UseVisualStyleBackColor = true;
		this.btnGo.Click += new global::System.EventHandler(this.btnGo_Click);
		this.btnStop.Location = new global::System.Drawing.Point(99, 359);
		this.btnStop.Name = "btnStop";
		this.btnStop.Size = new global::System.Drawing.Size(75, 23);
		this.btnStop.TabIndex = 52;
		this.btnStop.Text = "Ctrl + |";
		this.btnStop.UseVisualStyleBackColor = true;
		this.btnStop.Click += new global::System.EventHandler(this.btnStop_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.White;
		base.ClientSize = new global::System.Drawing.Size(272, 389);
		base.Controls.Add(this.btnStop);
		base.Controls.Add(this.btnGo);
		base.Controls.Add(this.btnBack);
		base.Controls.Add(this.btnSaveWay);
		base.Controls.Add(this.txtCodeTN);
		base.Controls.Add(this.groupBox3);
		base.Controls.Add(this.groupBox4);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Fixed3D;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Trader";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Trader";
		base.Load += new global::System.EventHandler(this.Trader_Load);
		this.groupBox3.ResumeLayout(false);
		this.groupBox3.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityClick2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityClick1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudRefCityId).EndInit();
		this.groupBox4.ResumeLayout(false);
		this.groupBox4.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityClick2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityClick1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudCityId).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04001EC0 RID: 7872
	private global::System.Windows.Forms.Button btnSaveWay;

	// Token: 0x04001EC1 RID: 7873
	private global::System.Windows.Forms.TextBox txtCodeTN;

	// Token: 0x04001EC2 RID: 7874
	private global::System.Windows.Forms.GroupBox groupBox3;

	// Token: 0x04001EC3 RID: 7875
	private global::System.Windows.Forms.Button btnGetTTCityID;

	// Token: 0x04001EC4 RID: 7876
	private global::System.Windows.Forms.Label label17;

	// Token: 0x04001EC5 RID: 7877
	private global::System.Windows.Forms.ComboBox cboRefCity;

	// Token: 0x04001EC6 RID: 7878
	private global::System.Windows.Forms.NumericUpDown nudRefCityClick2;

	// Token: 0x04001EC7 RID: 7879
	private global::System.Windows.Forms.Label label19;

	// Token: 0x04001EC8 RID: 7880
	private global::System.Windows.Forms.ComboBox cboIdxRefCity;

	// Token: 0x04001EC9 RID: 7881
	private global::System.Windows.Forms.Label label20;

	// Token: 0x04001ECA RID: 7882
	private global::System.Windows.Forms.NumericUpDown nudRefCityClick1;

	// Token: 0x04001ECB RID: 7883
	private global::System.Windows.Forms.NumericUpDown nudRefCityId;

	// Token: 0x04001ECC RID: 7884
	private global::System.Windows.Forms.Label label21;

	// Token: 0x04001ECD RID: 7885
	private global::System.Windows.Forms.GroupBox groupBox4;

	// Token: 0x04001ECE RID: 7886
	private global::System.Windows.Forms.Button btnGetMyCityID;

	// Token: 0x04001ECF RID: 7887
	private global::System.Windows.Forms.Label label22;

	// Token: 0x04001ED0 RID: 7888
	private global::System.Windows.Forms.ComboBox cboCity;

	// Token: 0x04001ED1 RID: 7889
	private global::System.Windows.Forms.NumericUpDown nudCityClick2;

	// Token: 0x04001ED2 RID: 7890
	private global::System.Windows.Forms.Label label23;

	// Token: 0x04001ED3 RID: 7891
	private global::System.Windows.Forms.ComboBox cboIdxCity;

	// Token: 0x04001ED4 RID: 7892
	private global::System.Windows.Forms.Label label24;

	// Token: 0x04001ED5 RID: 7893
	private global::System.Windows.Forms.NumericUpDown nudCityClick1;

	// Token: 0x04001ED6 RID: 7894
	private global::System.Windows.Forms.NumericUpDown nudCityId;

	// Token: 0x04001ED7 RID: 7895
	private global::System.Windows.Forms.Label label25;

	// Token: 0x04001ED8 RID: 7896
	private global::System.Windows.Forms.Button btnGetThanhTT;

	// Token: 0x04001ED9 RID: 7897
	private global::System.Windows.Forms.Button btnGetThanh;

	// Token: 0x04001EDA RID: 7898
	private global::System.Windows.Forms.Button btnBack;

	// Token: 0x04001EDB RID: 7899
	private global::System.Windows.Forms.Button btnGo;

	// Token: 0x04001EDC RID: 7900
	private global::System.Windows.Forms.Button btnStop;
}
