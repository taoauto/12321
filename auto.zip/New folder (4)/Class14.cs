﻿using System;

// Token: 0x0200002A RID: 42
internal static class Class14
{
	// Token: 0x060001F9 RID: 505 RVA: 0x00026A24 File Offset: 0x00024C24
	public static GClass16 smethod_0(GEnum4 genum4_0, string string_0 = null, int int_0 = 0, string string_1 = null, string string_2 = null)
	{
		switch (genum4_0)
		{
		case GEnum4.Http:
			if (int_0 != 0)
			{
				return new GClass18(string_0, int_0, string_1, string_2);
			}
			return new GClass18(string_0);
		case GEnum4.Socks4:
			if (int_0 != 0)
			{
				return new GClass19(string_0, int_0, string_1);
			}
			return new GClass19(string_0);
		case GEnum4.Socks4a:
			if (int_0 != 0)
			{
				return new GClass20(string_0, int_0, string_1);
			}
			return new GClass20(string_0);
		case GEnum4.Socks5:
			if (int_0 != 0)
			{
				return new GClass21(string_0, int_0, string_1, string_2);
			}
			return new GClass21(string_0);
		default:
			throw new InvalidOperationException();
		}
	}
}
