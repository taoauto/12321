﻿using System;

// Token: 0x020002AC RID: 684
internal class Class370
{
	// Token: 0x17000844 RID: 2116
	// (get) Token: 0x06002665 RID: 9829 RVA: 0x0001CB35 File Offset: 0x0001AD35
	public static string String_0
	{
		get
		{
			return "Mộ Dung Sơn Trang";
		}
	}

	// Token: 0x040019BF RID: 6591
	public static int int_0 = 284;

	// Token: 0x040019C0 RID: 6592
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 15U,
		Int32_0 = 25,
		Int32_1 = 167,
		Int32_2 = Class370.int_0,
		String_2 = "Phong Thiên Lý"
	};

	// Token: 0x040019C1 RID: 6593
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 48,
		Int32_1 = 144,
		Int32_2 = Class370.int_0,
		String_2 = "Mộ Dung Kiệt"
	};

	// Token: 0x040019C2 RID: 6594
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 69,
		Int32_1 = 126,
		Int32_2 = Class370.int_0,
		String_2 = "Mộ Dung Thắng"
	};

	// Token: 0x040019C3 RID: 6595
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 14U,
		Int32_0 = 48,
		Int32_1 = 135,
		Int32_2 = Class370.int_0,
		String_2 = "Mộ Dung Thanh Sơn"
	};
}
