﻿using System;
using System.Collections.Generic;

// Token: 0x020000D3 RID: 211
public class GClass67 : GClass61
{
	// Token: 0x060009D5 RID: 2517 RVA: 0x0003FE98 File Offset: 0x0003E098
	public GClass67(GClass99 gclass99_1, List<int> list_2) : base(gclass99_1)
	{
		list_2.Sort();
		this.list_0 = list_2;
		this.class90_1 = (this.class90_0 = new Class90(gclass99_1.FastColoredTextBox_0.GClass86_5));
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x0003FEE4 File Offset: 0x0003E0E4
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		FastColoredTextBox fastColoredTextBox_ = this.gclass99_0.FastColoredTextBox_0;
		this.gclass99_0.vmethod_13();
		fastColoredTextBox_.GClass86_5.method_38();
		for (int i = 0; i < this.list_0.Count; i++)
		{
			int num = this.list_0[i];
			if (num < this.gclass99_0.Count)
			{
				fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(0, num);
			}
			else
			{
				fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(this.gclass99_0[this.gclass99_0.Count - 1].Count, this.gclass99_0.Count - 1);
			}
			GClass62.smethod_1(this.gclass99_0);
			fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(0, num);
			string text = this.list_1[this.list_1.Count - i - 1];
			GClass63.smethod_0(text, this.gclass99_0);
			this.gclass99_0[num].Boolean_0 = true;
			if (num < this.gclass99_0.Count - 1)
			{
				this.gclass99_0[num + 1].Boolean_0 = true;
			}
			else
			{
				this.gclass99_0[num - 1].Boolean_0 = true;
			}
			if (text.Trim() != string.Empty)
			{
				this.gclass99_0.vmethod_10(num, num);
			}
		}
		fastColoredTextBox_.GClass86_5.method_39();
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(0, 1));
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x00040064 File Offset: 0x0003E264
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		FastColoredTextBox fastColoredTextBox_ = this.gclass99_0.FastColoredTextBox_0;
		this.list_1.Clear();
		this.gclass99_0.vmethod_13();
		fastColoredTextBox_.GClass86_5.method_38();
		for (int i = this.list_0.Count - 1; i >= 0; i--)
		{
			int num = this.list_0[i];
			this.list_1.Add(this.gclass99_0[num].String_2);
			this.gclass99_0.vmethod_8(num);
		}
		fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
		fastColoredTextBox_.GClass86_5.method_39();
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(0, 1));
		this.class90_1 = new Class90(fastColoredTextBox_.GClass86_5);
	}

	// Token: 0x060009D8 RID: 2520 RVA: 0x0000966A File Offset: 0x0000786A
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		return new GClass67(this.gclass99_0, new List<int>(this.list_0));
	}

	// Token: 0x040004D7 RID: 1239
	private List<int> list_0;

	// Token: 0x040004D8 RID: 1240
	private List<string> list_1 = new List<string>();
}
