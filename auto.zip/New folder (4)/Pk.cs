﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x020002ED RID: 749
internal partial class Pk : Form
{
	// Token: 0x06002ACD RID: 10957 RVA: 0x0001F29A File Offset: 0x0001D49A
	public Pk()
	{
		this.InitializeComponent();
		base.Icon = GClass130.Icon_1;
	}

	// Token: 0x06002ACE RID: 10958 RVA: 0x00122354 File Offset: 0x00120554
	private void Pk_Load(object sender, EventArgs e)
	{
		this.txtBoQua.Text = Class415.String_31;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_7 && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
	}

	// Token: 0x06002ACF RID: 10959 RVA: 0x00122458 File Offset: 0x00120658
	private void method_0()
	{
		foreach (object obj in this.listViewName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtBoQua.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtBoQua.Text = this.txtBoQua.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtBoQua.method_1();
	}

	// Token: 0x06002AD0 RID: 10960 RVA: 0x0001F2BE File Offset: 0x0001D4BE
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06002AD1 RID: 10961 RVA: 0x0001F2BE File Offset: 0x0001D4BE
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06002AD2 RID: 10962 RVA: 0x0001F2C6 File Offset: 0x0001D4C6
	private void txtBoQua_TextChanged(object sender, EventArgs e)
	{
		Class415.String_31 = this.txtBoQua.Text;
	}

	// Token: 0x06002AD3 RID: 10963 RVA: 0x0001F2D8 File Offset: 0x0001D4D8
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001C80 RID: 7296
	private HashSet<string> hashSet_0 = new HashSet<string>();
}
