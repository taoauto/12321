﻿using System;
using System.IO;

// Token: 0x0200001F RID: 31
public class GClass15 : GClass14
{
	// Token: 0x060001C4 RID: 452 RVA: 0x00026328 File Offset: 0x00024528
	public GClass15(string string_1, int int_1 = 32768)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("pathToContent");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("pathToContent");
		}
		if (int_1 < 1)
		{
			throw Class13.smethod_1<int>("bufferSize", 1);
		}
		this.stream_0 = new FileStream(string_1, FileMode.Open, FileAccess.Read);
		this.int_0 = int_1;
		this.long_0 = 0L;
		this.string_0 = GClass6.smethod_3(Path.GetExtension(string_1));
	}
}
