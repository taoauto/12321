﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200017F RID: 383
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct8
{
	// Token: 0x040009C3 RID: 2499
	public ushort Machine;

	// Token: 0x040009C4 RID: 2500
	public ushort NumberOfSections;

	// Token: 0x040009C5 RID: 2501
	public uint TimeDateStamp;

	// Token: 0x040009C6 RID: 2502
	public uint PointerToSymbolTable;

	// Token: 0x040009C7 RID: 2503
	public uint NumberOfSymbols;

	// Token: 0x040009C8 RID: 2504
	public ushort SizeOfOptionalHeader;

	// Token: 0x040009C9 RID: 2505
	public ushort Characteristics;
}
