﻿using System;

// Token: 0x0200004F RID: 79
internal enum Enum3 : byte
{
	// Token: 0x040001D9 RID: 473
	Cont,
	// Token: 0x040001DA RID: 474
	Text,
	// Token: 0x040001DB RID: 475
	Binary,
	// Token: 0x040001DC RID: 476
	Close = 8,
	// Token: 0x040001DD RID: 477
	Ping,
	// Token: 0x040001DE RID: 478
	Pong
}
