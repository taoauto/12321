﻿using System;

// Token: 0x0200008E RID: 142
internal class Class71
{
	// Token: 0x0600068E RID: 1678 RVA: 0x0000739E File Offset: 0x0000559E
	internal Class71(string string_1, Enum6 enum6_1)
	{
		this.string_0 = string_1;
		this.enum6_0 = enum6_1;
	}

	// Token: 0x170001B3 RID: 435
	// (get) Token: 0x0600068F RID: 1679 RVA: 0x000073B4 File Offset: 0x000055B4
	internal bool Boolean_0
	{
		get
		{
			return (this.enum6_0 & Enum6.MultiValueInRequest) == Enum6.MultiValueInRequest;
		}
	}

	// Token: 0x170001B4 RID: 436
	// (get) Token: 0x06000690 RID: 1680 RVA: 0x000073C3 File Offset: 0x000055C3
	internal bool Boolean_1
	{
		get
		{
			return (this.enum6_0 & Enum6.MultiValueInResponse) == Enum6.MultiValueInResponse;
		}
	}

	// Token: 0x170001B5 RID: 437
	// (get) Token: 0x06000691 RID: 1681 RVA: 0x000073D2 File Offset: 0x000055D2
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x170001B6 RID: 438
	// (get) Token: 0x06000692 RID: 1682 RVA: 0x000073DA File Offset: 0x000055DA
	public Enum6 Enum6_0
	{
		get
		{
			return this.enum6_0;
		}
	}

	// Token: 0x170001B7 RID: 439
	// (get) Token: 0x06000693 RID: 1683 RVA: 0x000073E2 File Offset: 0x000055E2
	public bool Boolean_2
	{
		get
		{
			return (this.enum6_0 & Enum6.Request) == Enum6.Request;
		}
	}

	// Token: 0x170001B8 RID: 440
	// (get) Token: 0x06000694 RID: 1684 RVA: 0x000073EF File Offset: 0x000055EF
	public bool Boolean_3
	{
		get
		{
			return (this.enum6_0 & Enum6.Response) == Enum6.Response;
		}
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x000073FC File Offset: 0x000055FC
	public bool method_0(bool bool_0)
	{
		if ((this.enum6_0 & Enum6.MultiValue) != Enum6.MultiValue)
		{
			if (!bool_0)
			{
				return this.Boolean_0;
			}
			return this.Boolean_1;
		}
		else
		{
			if (!bool_0)
			{
				return this.Boolean_2;
			}
			return this.Boolean_3;
		}
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x0000742A File Offset: 0x0000562A
	public bool method_1(bool bool_0)
	{
		if ((this.enum6_0 & Enum6.Restricted) != Enum6.Restricted)
		{
			return false;
		}
		if (!bool_0)
		{
			return this.Boolean_2;
		}
		return this.Boolean_3;
	}

	// Token: 0x0400032B RID: 811
	private string string_0;

	// Token: 0x0400032C RID: 812
	private Enum6 enum6_0;
}
