﻿using System;

// Token: 0x020000B9 RID: 185
public enum GEnum10
{
	// Token: 0x04000489 RID: 1161
	Hidden,
	// Token: 0x0400048A RID: 1162
	Visible,
	// Token: 0x0400048B RID: 1163
	VisibleAndSelected
}
