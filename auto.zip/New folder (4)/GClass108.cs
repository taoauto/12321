﻿using System;

// Token: 0x0200017A RID: 378
public static class GClass108
{
	// Token: 0x04000987 RID: 2439
	public const uint uint_0 = 1U;

	// Token: 0x04000988 RID: 2440
	public const ushort ushort_0 = 23117;

	// Token: 0x04000989 RID: 2441
	public const uint uint_1 = 2U;

	// Token: 0x0400098A RID: 2442
	public const uint uint_2 = 3U;

	// Token: 0x0400098B RID: 2443
	public const uint uint_3 = 17744U;

	// Token: 0x0400098C RID: 2444
	public const ushort ushort_1 = 267;

	// Token: 0x0400098D RID: 2445
	public const ushort ushort_2 = 523;

	// Token: 0x0400098E RID: 2446
	public const uint uint_4 = 24U;
}
