﻿using System;

// Token: 0x020000D5 RID: 213
public class GClass69 : GClass61
{
	// Token: 0x060009DF RID: 2527 RVA: 0x0000960E File Offset: 0x0000780E
	public GClass69(GClass99 gclass99_1) : base(gclass99_1)
	{
	}

	// Token: 0x060009E0 RID: 2528 RVA: 0x000096C4 File Offset: 0x000078C4
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		this.class90_1 = new Class90(this.gclass99_0.FastColoredTextBox_0.GClass86_5);
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x00002E18 File Offset: 0x00001018
	protected override void \u206B\u206F\u206F\u206C\u200C\u206F\u206C\u206E\u202D\u206D\u206A\u206D\u200D\u206C\u202D\u206B\u200F\u206F\u200B\u202A\u206F\u202C\u202C\u202C\u202B\u202E\u206E\u202A\u202A\u206D\u200E\u202B\u202D\u200F\u206F\u206C\u206F\u206B\u206D\u206A\u202E(bool bool_1)
	{
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x000096E1 File Offset: 0x000078E1
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.gclass99_0.FastColoredTextBox_0.GClass86_5 = new GClass86(this.gclass99_0.FastColoredTextBox_0, this.class90_1.GStruct2_0, this.class90_1.GStruct2_1);
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x0004062C File Offset: 0x0003E82C
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		GClass69 gclass = new GClass69(this.gclass99_0);
		if (this.class90_1 != null)
		{
			gclass.class90_1 = new Class90(new GClass86(this.gclass99_0.FastColoredTextBox_0, this.class90_1.GStruct2_0, this.class90_1.GStruct2_1));
		}
		return gclass;
	}
}
