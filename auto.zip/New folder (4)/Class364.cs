﻿using System;

// Token: 0x020002A6 RID: 678
internal class Class364
{
}
