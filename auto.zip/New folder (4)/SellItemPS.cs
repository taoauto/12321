﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001F0 RID: 496
internal class SellItemPS : UserControl
{
	// Token: 0x06001A00 RID: 6656 RVA: 0x00012D8E File Offset: 0x00010F8E
	public SellItemPS()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001A01 RID: 6657 RVA: 0x000BD0C4 File Offset: 0x000BB2C4
	private void SellItemPS_Load(object sender, EventArgs e)
	{
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Select(new Func<string, ListViewItem>(SellItemPS.Class230.<>9.method_0)).ToArray<ListViewItem>());
		foreach (string text in Class415.String_2.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length > 3 && text.Trim().Split(new char[]
			{
				'|'
			}).Length == 2)
			{
				ListViewItem listViewItem = new ListViewItem(text.Trim().Split(new char[]
				{
					'|'
				})[0]);
				listViewItem.SubItems.Add(text.Trim().Split(new char[]
				{
					'|'
				})[1]);
				this.lvPrice.Items.Add(listViewItem);
			}
		}
	}

	// Token: 0x06001A02 RID: 6658 RVA: 0x000BD1BC File Offset: 0x000BB3BC
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		if (this.lvName.SelectedItems.Count > 0 && Class426.smethod_41(this.txtPrice.Text) > 0)
		{
			string text = this.lvName.SelectedItems[0].Text;
			foreach (object obj in this.lvPrice.Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (listViewItem.Text == text)
				{
					listViewItem.SubItems[1].Text = this.txtPrice.Text;
					return;
				}
			}
			ListViewItem listViewItem2 = new ListViewItem(text);
			listViewItem2.SubItems.Add(this.txtPrice.Text);
			this.lvPrice.Items.Add(listViewItem2);
		}
	}

	// Token: 0x06001A03 RID: 6659 RVA: 0x00012D9C File Offset: 0x00010F9C
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x06001A04 RID: 6660 RVA: 0x000BD2B8 File Offset: 0x000BB4B8
	private void method_0(object sender, FormClosingEventArgs e)
	{
		string text = "";
		foreach (object obj in this.lvPrice.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = string.Concat(new string[]
			{
				text,
				listViewItem.Text,
				"|",
				listViewItem.SubItems[1].Text,
				"\n"
			});
		}
		Class415.String_2 = text;
	}

	// Token: 0x06001A05 RID: 6661 RVA: 0x00012DB5 File Offset: 0x00010FB5
	private void lvPrice_DoubleClick(object sender, EventArgs e)
	{
		while (this.lvPrice.SelectedItems.Count > 0)
		{
			this.lvPrice.SelectedItems[0].Remove();
		}
	}

	// Token: 0x06001A06 RID: 6662 RVA: 0x00012DE3 File Offset: 0x00010FE3
	private void button1_Click(object sender, EventArgs e)
	{
		this.lvName_DoubleClick(null, null);
	}

	// Token: 0x06001A07 RID: 6663 RVA: 0x00012DED File Offset: 0x00010FED
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A08 RID: 6664 RVA: 0x000BD35C File Offset: 0x000BB55C
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(SellItemPS));
		this.txtSearchName = new Class85();
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.splitContainer1 = new SplitContainer();
		this.lvPrice = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.txtPrice = new Class85();
		this.button1 = new Button();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(255, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(255, 305);
		this.lvName.TabIndex = 11;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.SelectedIndexChanged += this.lvPrice_DoubleClick;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 200;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.lvPrice);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtPrice);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Panel2.Controls.Add(this.button1);
		this.splitContainer1.Size = new Size(505, 368);
		this.splitContainer1.SplitterDistance = 246;
		this.splitContainer1.TabIndex = 0;
		this.lvPrice.AllowColumnReorder = true;
		this.lvPrice.AllowDrop = true;
		this.lvPrice.AllowReorder = true;
		this.lvPrice.AllowSort = true;
		this.lvPrice.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.lvPrice.Dock = DockStyle.Fill;
		this.lvPrice.DoubleClickActivation = false;
		this.lvPrice.FullRowSelect = true;
		this.lvPrice.GridLines = true;
		this.lvPrice.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvPrice.hideItems");
		this.lvPrice.HideSelection = false;
		this.lvPrice.LineColor = Color.Red;
		this.lvPrice.Location = new Point(0, 0);
		this.lvPrice.Name = "lvPrice";
		this.lvPrice.Size = new Size(246, 368);
		this.lvPrice.TabIndex = 12;
		this.lvPrice.UseCompatibleStateImageBehavior = false;
		this.lvPrice.View = View.Details;
		this.lvPrice.DoubleClick += this.lvPrice_DoubleClick;
		this.columnHeader_1.Text = "Tên Vật Phẩm";
		this.columnHeader_1.Width = 151;
		this.columnHeader_2.Text = "Giá";
		this.txtPrice.Dock = DockStyle.Bottom;
		this.txtPrice.Location = new Point(0, 325);
		this.txtPrice.Name = "txtPrice";
		this.txtPrice.Size = new Size(255, 20);
		this.txtPrice.TabIndex = 12;
		this.txtPrice.String_0 = "Price... 300";
		this.txtPrice.Color_0 = Color.Gray;
		this.txtPrice.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtPrice.Color_1 = Color.LightGray;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 345);
		this.button1.Name = "button1";
		this.button1.Size = new Size(255, 23);
		this.button1.TabIndex = 13;
		this.button1.Text = "Add";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Name = "SellItemPS";
		base.Size = new Size(505, 368);
		base.Load += this.SellItemPS_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000F68 RID: 3944
	private IContainer icontainer_0;

	// Token: 0x04000F69 RID: 3945
	private Class85 txtSearchName;

	// Token: 0x04000F6A RID: 3946
	private ListViewEx lvName;

	// Token: 0x04000F6B RID: 3947
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F6C RID: 3948
	private SplitContainer splitContainer1;

	// Token: 0x04000F6D RID: 3949
	private Class85 txtPrice;

	// Token: 0x04000F6E RID: 3950
	private ListViewEx lvPrice;

	// Token: 0x04000F6F RID: 3951
	private ColumnHeader columnHeader_1;

	// Token: 0x04000F70 RID: 3952
	private ColumnHeader columnHeader_2;

	// Token: 0x04000F71 RID: 3953
	private Button button1;

	// Token: 0x020001F1 RID: 497
	[CompilerGenerated]
	[Serializable]
	private sealed class Class230
	{
		// Token: 0x06001A0B RID: 6667 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000F72 RID: 3954
		public static readonly SellItemPS.Class230 <>9 = new SellItemPS.Class230();

		// Token: 0x04000F73 RID: 3955
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
