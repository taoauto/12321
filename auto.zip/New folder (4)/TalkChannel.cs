﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020002A2 RID: 674
internal class TalkChannel : UserControl
{
	// Token: 0x060024B7 RID: 9399 RVA: 0x0001BCD7 File Offset: 0x00019ED7
	public TalkChannel()
	{
		this.InitializeComponent();
	}

	// Token: 0x17000798 RID: 1944
	// (get) Token: 0x060024B8 RID: 9400 RVA: 0x0001BCE5 File Offset: 0x00019EE5
	// (set) Token: 0x060024B9 RID: 9401 RVA: 0x0001BCEC File Offset: 0x00019EEC
	public static bool Boolean_0 { get; set; }

	// Token: 0x17000799 RID: 1945
	// (get) Token: 0x060024BA RID: 9402 RVA: 0x0001BCF4 File Offset: 0x00019EF4
	// (set) Token: 0x060024BB RID: 9403 RVA: 0x0001BCFB File Offset: 0x00019EFB
	public static bool Boolean_1 { get; set; }

	// Token: 0x1700079A RID: 1946
	// (get) Token: 0x060024BC RID: 9404 RVA: 0x0001BD03 File Offset: 0x00019F03
	// (set) Token: 0x060024BD RID: 9405 RVA: 0x0001BD0A File Offset: 0x00019F0A
	public static bool Boolean_2 { get; set; }

	// Token: 0x1700079B RID: 1947
	// (get) Token: 0x060024BE RID: 9406 RVA: 0x0001BD12 File Offset: 0x00019F12
	// (set) Token: 0x060024BF RID: 9407 RVA: 0x0001BD19 File Offset: 0x00019F19
	public static bool Boolean_3 { get; set; }

	// Token: 0x1700079C RID: 1948
	// (get) Token: 0x060024C0 RID: 9408 RVA: 0x0001BD21 File Offset: 0x00019F21
	// (set) Token: 0x060024C1 RID: 9409 RVA: 0x0001BD28 File Offset: 0x00019F28
	public static bool Boolean_4 { get; set; }

	// Token: 0x1700079D RID: 1949
	// (get) Token: 0x060024C2 RID: 9410 RVA: 0x0001BD30 File Offset: 0x00019F30
	// (set) Token: 0x060024C3 RID: 9411 RVA: 0x0001BD37 File Offset: 0x00019F37
	public static bool Boolean_5 { get; set; }

	// Token: 0x1700079E RID: 1950
	// (get) Token: 0x060024C4 RID: 9412 RVA: 0x0001BD3F File Offset: 0x00019F3F
	// (set) Token: 0x060024C5 RID: 9413 RVA: 0x0001BD46 File Offset: 0x00019F46
	public static bool Boolean_6 { get; set; }

	// Token: 0x1700079F RID: 1951
	// (get) Token: 0x060024C6 RID: 9414 RVA: 0x0001BD4E File Offset: 0x00019F4E
	// (set) Token: 0x060024C7 RID: 9415 RVA: 0x0001BD55 File Offset: 0x00019F55
	public static bool Boolean_7 { get; set; }

	// Token: 0x170007A0 RID: 1952
	// (get) Token: 0x060024C8 RID: 9416 RVA: 0x0001BD5D File Offset: 0x00019F5D
	// (set) Token: 0x060024C9 RID: 9417 RVA: 0x0001BD64 File Offset: 0x00019F64
	public static int Int32_0 { get; set; }

	// Token: 0x060024CA RID: 9418 RVA: 0x0010A36C File Offset: 0x0010856C
	public static void smethod_0()
	{
		TalkChannel.Boolean_0 = (Class159.Class220_0.method_0("TalkChanel", "Near") == "True");
		TalkChannel.Boolean_1 = (Class159.Class220_0.method_0("TalkChanel", "Scene") != "False");
		TalkChannel.Boolean_2 = (Class159.Class220_0.method_0("TalkChanel", "IPRegion") == "True");
		TalkChannel.Boolean_3 = (Class159.Class220_0.method_0("TalkChanel", "GuildLeague") == "True");
		TalkChannel.Boolean_4 = (Class159.Class220_0.method_0("TalkChanel", "Guild") == "True");
		TalkChannel.Boolean_5 = (Class159.Class220_0.method_0("TalkChanel", "Menpai") == "True");
		TalkChannel.Boolean_6 = (Class159.Class220_0.method_0("TalkChanel", "Team") == "True");
		TalkChannel.Boolean_7 = (Class159.Class220_0.method_0("TalkChanel", "BigWorld") == "True");
		TalkChannel.Int32_0 = Class426.smethod_43(Class159.Class220_0.method_0("TalkChanel", "Time"));
		TalkChannel.Boolean_8 = (Class159.Class220_0.method_0("TalkChanel", "R") == "True");
		if (TalkChannel.Int32_0 == 0)
		{
			TalkChannel.Int32_0 = 180;
		}
	}

	// Token: 0x060024CB RID: 9419 RVA: 0x0010A4E4 File Offset: 0x001086E4
	private void btnOk_Click(object sender, EventArgs e)
	{
		Class159.Class220_0.method_1("TalkChanel", "Near", this.chk_near.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "Scene", this.chk_scene.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "IPRegion", this.chk_ipregion.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "GuildLeague", this.chk_guild_league.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "Guild", this.chk_guild.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "Menpai", this.chk_menpai.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "Team", this.chk_team.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "BigWorld", this.chk_bigworld.Checked.ToString());
		Class159.Class220_0.method_1("TalkChanel", "Time", this.numTime.Text);
		Class159.Class220_0.method_1("TalkChanel", "R", this.chk_r.Checked.ToString());
		TalkChannel.Boolean_0 = (Class159.Class220_0.method_0("TalkChanel", "Near") == "True");
		TalkChannel.Boolean_1 = (Class159.Class220_0.method_0("TalkChanel", "Scene") != "False");
		TalkChannel.Boolean_2 = (Class159.Class220_0.method_0("TalkChanel", "IPRegion") == "True");
		TalkChannel.Boolean_3 = (Class159.Class220_0.method_0("TalkChanel", "GuildLeague") == "True");
		TalkChannel.Boolean_4 = (Class159.Class220_0.method_0("TalkChanel", "Guild") == "True");
		TalkChannel.Boolean_5 = (Class159.Class220_0.method_0("TalkChanel", "Menpai") == "True");
		TalkChannel.Boolean_6 = (Class159.Class220_0.method_0("TalkChanel", "Team") == "True");
		TalkChannel.Boolean_7 = (Class159.Class220_0.method_0("TalkChanel", "BigWorld") == "True");
		TalkChannel.Int32_0 = Class426.smethod_43(Class159.Class220_0.method_0("TalkChanel", "Time"));
		TalkChannel.Boolean_8 = (Class159.Class220_0.method_0("TalkChanel", "R") == "True");
		if (TalkChannel.Int32_0 == 0)
		{
			TalkChannel.Int32_0 = 180;
		}
		this.method_0();
		base.Dispose();
	}

	// Token: 0x060024CC RID: 9420 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0()
	{
	}

	// Token: 0x060024CD RID: 9421 RVA: 0x0010A7E8 File Offset: 0x001089E8
	private void TalkChannel_Load(object sender, EventArgs e)
	{
		this.chk_near.Checked = (Class159.Class220_0.method_0("TalkChanel", "Near") == "True");
		this.chk_scene.Checked = (Class159.Class220_0.method_0("TalkChanel", "Scene") != "False");
		this.chk_ipregion.Checked = (Class159.Class220_0.method_0("TalkChanel", "IPRegion") == "True");
		this.chk_guild_league.Checked = (Class159.Class220_0.method_0("TalkChanel", "GuildLeague") == "True");
		this.chk_guild.Checked = (Class159.Class220_0.method_0("TalkChanel", "Guild") == "True");
		this.chk_menpai.Checked = (Class159.Class220_0.method_0("TalkChanel", "Menpai") == "True");
		this.chk_team.Checked = (Class159.Class220_0.method_0("TalkChanel", "Team") == "True");
		this.chk_bigworld.Checked = (Class159.Class220_0.method_0("TalkChanel", "BigWorld") == "True");
		this.numTime.Text = Class159.Class220_0.method_0("TalkChanel", "Time");
		this.chk_r.Checked = (Class159.Class220_0.method_0("TalkChanel", "R") == "True");
	}

	// Token: 0x170007A1 RID: 1953
	// (get) Token: 0x060024CE RID: 9422 RVA: 0x0001BD6C File Offset: 0x00019F6C
	// (set) Token: 0x060024CF RID: 9423 RVA: 0x0001BD73 File Offset: 0x00019F73
	public static bool Boolean_8 { get; set; }

	// Token: 0x060024D0 RID: 9424 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_bigworld_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D1 RID: 9425 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_r_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D2 RID: 9426 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_near_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D3 RID: 9427 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_scene_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D4 RID: 9428 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_ipregion_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D5 RID: 9429 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_guild_league_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D6 RID: 9430 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_guild_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D7 RID: 9431 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_menpai_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D8 RID: 9432 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void chk_team_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024D9 RID: 9433 RVA: 0x0001BD7B File Offset: 0x00019F7B
	private void numTime_TextChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024DA RID: 9434 RVA: 0x0001BD83 File Offset: 0x00019F83
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060024DB RID: 9435 RVA: 0x0010A988 File Offset: 0x00108B88
	private void InitializeComponent()
	{
		this.chk_bigworld = new CheckBox();
		this.chk_team = new CheckBox();
		this.chk_menpai = new CheckBox();
		this.chk_guild = new CheckBox();
		this.chk_ipregion = new CheckBox();
		this.chk_guild_league = new CheckBox();
		this.chk_near = new CheckBox();
		this.chk_scene = new CheckBox();
		this.btnOk = new Button();
		this.chk_r = new CheckBox();
		this.numTime = new GClass124();
		this.tableLayoutPanel1 = new TableLayoutPanel();
		this.panel1 = new Panel();
		this.tableLayoutPanel1.SuspendLayout();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.chk_bigworld.AutoSize = true;
		this.chk_bigworld.Location = new Point(26, 195);
		this.chk_bigworld.Name = "chk_bigworld";
		this.chk_bigworld.Size = new Size(67, 17);
		this.chk_bigworld.TabIndex = 15;
		this.chk_bigworld.Text = "Cổ Cảnh";
		this.chk_bigworld.UseVisualStyleBackColor = true;
		this.chk_bigworld.CheckedChanged += this.chk_bigworld_CheckedChanged;
		this.chk_team.AutoSize = true;
		this.chk_team.Location = new Point(26, 172);
		this.chk_team.Name = "chk_team";
		this.chk_team.Size = new Size(42, 17);
		this.chk_team.TabIndex = 14;
		this.chk_team.Text = "Đội";
		this.chk_team.UseVisualStyleBackColor = true;
		this.chk_team.CheckedChanged += this.chk_team_CheckedChanged;
		this.chk_menpai.AutoSize = true;
		this.chk_menpai.Location = new Point(26, 149);
		this.chk_menpai.Name = "chk_menpai";
		this.chk_menpai.Size = new Size(47, 17);
		this.chk_menpai.TabIndex = 13;
		this.chk_menpai.Text = "Phái";
		this.chk_menpai.UseVisualStyleBackColor = true;
		this.chk_menpai.CheckedChanged += this.chk_menpai_CheckedChanged;
		this.chk_guild.AutoSize = true;
		this.chk_guild.Location = new Point(26, 126);
		this.chk_guild.Name = "chk_guild";
		this.chk_guild.Size = new Size(75, 17);
		this.chk_guild.TabIndex = 12;
		this.chk_guild.Text = "Bang Phái";
		this.chk_guild.UseVisualStyleBackColor = true;
		this.chk_guild.CheckedChanged += this.chk_guild_CheckedChanged;
		this.chk_ipregion.AutoSize = true;
		this.chk_ipregion.Location = new Point(26, 80);
		this.chk_ipregion.Name = "chk_ipregion";
		this.chk_ipregion.Size = new Size(75, 17);
		this.chk_ipregion.TabIndex = 11;
		this.chk_ipregion.Text = "Thành Thị";
		this.chk_ipregion.UseVisualStyleBackColor = true;
		this.chk_ipregion.CheckedChanged += this.chk_ipregion_CheckedChanged;
		this.chk_guild_league.AutoSize = true;
		this.chk_guild_league.Location = new Point(26, 103);
		this.chk_guild_league.Name = "chk_guild_league";
		this.chk_guild_league.Size = new Size(78, 17);
		this.chk_guild_league.TabIndex = 10;
		this.chk_guild_league.Text = "Đồng Minh";
		this.chk_guild_league.UseVisualStyleBackColor = true;
		this.chk_guild_league.CheckedChanged += this.chk_guild_league_CheckedChanged;
		this.chk_near.AutoSize = true;
		this.chk_near.Location = new Point(26, 34);
		this.chk_near.Name = "chk_near";
		this.chk_near.Size = new Size(46, 17);
		this.chk_near.TabIndex = 9;
		this.chk_near.Text = "Gần";
		this.chk_near.UseVisualStyleBackColor = true;
		this.chk_near.CheckedChanged += this.chk_near_CheckedChanged;
		this.chk_scene.AutoSize = true;
		this.chk_scene.Location = new Point(26, 57);
		this.chk_scene.Name = "chk_scene";
		this.chk_scene.Size = new Size(66, 17);
		this.chk_scene.TabIndex = 8;
		this.chk_scene.Text = "Thế Giới";
		this.chk_scene.UseVisualStyleBackColor = true;
		this.chk_scene.CheckedChanged += this.chk_scene_CheckedChanged;
		this.btnOk.Dock = DockStyle.Bottom;
		this.btnOk.Location = new Point(0, 397);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new Size(420, 23);
		this.btnOk.TabIndex = 16;
		this.btnOk.Text = "Save";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += this.btnOk_Click;
		this.chk_r.AutoSize = true;
		this.chk_r.Location = new Point(26, 218);
		this.chk_r.Name = "chk_r";
		this.chk_r.Size = new Size(36, 17);
		this.chk_r.TabIndex = 19;
		this.chk_r.Text = "#r";
		this.chk_r.UseVisualStyleBackColor = true;
		this.chk_r.CheckedChanged += this.chk_r_CheckedChanged;
		this.numTime.Location = new Point(26, 241);
		this.numTime.Name = "numTime";
		this.numTime.Size = new Size(75, 20);
		this.numTime.TabIndex = 18;
		this.numTime.String_0 = "180 s";
		this.numTime.Color_0 = Color.Gray;
		this.numTime.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.numTime.Color_1 = Color.LightGray;
		this.numTime.TextChanged += this.numTime_TextChanged;
		this.tableLayoutPanel1.BackColor = Color.White;
		this.tableLayoutPanel1.ColumnCount = 3;
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.03883f));
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.00971f));
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.95146f));
		this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
		this.tableLayoutPanel1.Dock = DockStyle.Fill;
		this.tableLayoutPanel1.Location = new Point(0, 0);
		this.tableLayoutPanel1.Name = "tableLayoutPanel1";
		this.tableLayoutPanel1.RowCount = 1;
		this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		this.tableLayoutPanel1.Size = new Size(420, 397);
		this.tableLayoutPanel1.TabIndex = 20;
		this.panel1.Controls.Add(this.chk_near);
		this.panel1.Controls.Add(this.chk_r);
		this.panel1.Controls.Add(this.chk_scene);
		this.panel1.Controls.Add(this.numTime);
		this.panel1.Controls.Add(this.chk_guild_league);
		this.panel1.Controls.Add(this.chk_ipregion);
		this.panel1.Controls.Add(this.chk_bigworld);
		this.panel1.Controls.Add(this.chk_guild);
		this.panel1.Controls.Add(this.chk_team);
		this.panel1.Controls.Add(this.chk_menpai);
		this.panel1.Dock = DockStyle.Fill;
		this.panel1.Location = new Point(137, 3);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(132, 391);
		this.panel1.TabIndex = 0;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tableLayoutPanel1);
		base.Controls.Add(this.btnOk);
		base.Name = "TalkChannel";
		base.Size = new Size(420, 420);
		base.Tag = "Rao Vặt - Talk";
		base.Load += this.TalkChannel_Load;
		this.tableLayoutPanel1.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x040018B4 RID: 6324
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x040018B5 RID: 6325
	[CompilerGenerated]
	private static bool bool_1;

	// Token: 0x040018B6 RID: 6326
	[CompilerGenerated]
	private static bool bool_2;

	// Token: 0x040018B7 RID: 6327
	[CompilerGenerated]
	private static bool bool_3;

	// Token: 0x040018B8 RID: 6328
	[CompilerGenerated]
	private static bool bool_4;

	// Token: 0x040018B9 RID: 6329
	[CompilerGenerated]
	private static bool bool_5;

	// Token: 0x040018BA RID: 6330
	[CompilerGenerated]
	private static bool bool_6;

	// Token: 0x040018BB RID: 6331
	[CompilerGenerated]
	private static bool bool_7;

	// Token: 0x040018BC RID: 6332
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x040018BD RID: 6333
	[CompilerGenerated]
	private static bool bool_8;

	// Token: 0x040018BE RID: 6334
	private IContainer icontainer_0;

	// Token: 0x040018BF RID: 6335
	private CheckBox chk_bigworld;

	// Token: 0x040018C0 RID: 6336
	private CheckBox chk_team;

	// Token: 0x040018C1 RID: 6337
	private CheckBox chk_menpai;

	// Token: 0x040018C2 RID: 6338
	private CheckBox chk_guild;

	// Token: 0x040018C3 RID: 6339
	private CheckBox chk_ipregion;

	// Token: 0x040018C4 RID: 6340
	private CheckBox chk_guild_league;

	// Token: 0x040018C5 RID: 6341
	private CheckBox chk_near;

	// Token: 0x040018C6 RID: 6342
	private CheckBox chk_scene;

	// Token: 0x040018C7 RID: 6343
	private Button btnOk;

	// Token: 0x040018C8 RID: 6344
	private GClass124 numTime;

	// Token: 0x040018C9 RID: 6345
	private CheckBox chk_r;

	// Token: 0x040018CA RID: 6346
	private TableLayoutPanel tableLayoutPanel1;

	// Token: 0x040018CB RID: 6347
	private Panel panel1;
}
