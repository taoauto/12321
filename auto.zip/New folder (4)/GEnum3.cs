﻿using System;

// Token: 0x0200001D RID: 29
public enum GEnum3
{
	// Token: 0x040000DF RID: 223
	None,
	// Token: 0x040000E0 RID: 224
	Continue = 100,
	// Token: 0x040000E1 RID: 225
	SwitchingProtocols,
	// Token: 0x040000E2 RID: 226
	OK = 200,
	// Token: 0x040000E3 RID: 227
	Created,
	// Token: 0x040000E4 RID: 228
	Accepted,
	// Token: 0x040000E5 RID: 229
	NonAuthoritativeInformation,
	// Token: 0x040000E6 RID: 230
	NoContent,
	// Token: 0x040000E7 RID: 231
	ResetContent,
	// Token: 0x040000E8 RID: 232
	PartialContent,
	// Token: 0x040000E9 RID: 233
	MultipleChoices = 300,
	// Token: 0x040000EA RID: 234
	Ambiguous = 300,
	// Token: 0x040000EB RID: 235
	MovedPermanently,
	// Token: 0x040000EC RID: 236
	Moved = 301,
	// Token: 0x040000ED RID: 237
	Found,
	// Token: 0x040000EE RID: 238
	Redirect = 302,
	// Token: 0x040000EF RID: 239
	SeeOther,
	// Token: 0x040000F0 RID: 240
	RedirectMethod = 303,
	// Token: 0x040000F1 RID: 241
	NotModified,
	// Token: 0x040000F2 RID: 242
	UseProxy,
	// Token: 0x040000F3 RID: 243
	Unused,
	// Token: 0x040000F4 RID: 244
	TemporaryRedirect,
	// Token: 0x040000F5 RID: 245
	RedirectKeepVerb = 307,
	// Token: 0x040000F6 RID: 246
	BadRequest = 400,
	// Token: 0x040000F7 RID: 247
	Unauthorized,
	// Token: 0x040000F8 RID: 248
	PaymentRequired,
	// Token: 0x040000F9 RID: 249
	Forbidden,
	// Token: 0x040000FA RID: 250
	NotFound,
	// Token: 0x040000FB RID: 251
	MethodNotAllowed,
	// Token: 0x040000FC RID: 252
	NotAcceptable,
	// Token: 0x040000FD RID: 253
	ProxyAuthenticationRequired,
	// Token: 0x040000FE RID: 254
	RequestTimeout,
	// Token: 0x040000FF RID: 255
	Conflict,
	// Token: 0x04000100 RID: 256
	Gone,
	// Token: 0x04000101 RID: 257
	LengthRequired,
	// Token: 0x04000102 RID: 258
	PreconditionFailed,
	// Token: 0x04000103 RID: 259
	RequestEntityTooLarge,
	// Token: 0x04000104 RID: 260
	RequestUriTooLong,
	// Token: 0x04000105 RID: 261
	UnsupportedMediaType,
	// Token: 0x04000106 RID: 262
	RequestedRangeNotSatisfiable,
	// Token: 0x04000107 RID: 263
	ExpectationFailed,
	// Token: 0x04000108 RID: 264
	InternalServerError = 500,
	// Token: 0x04000109 RID: 265
	NotImplemented,
	// Token: 0x0400010A RID: 266
	BadGateway,
	// Token: 0x0400010B RID: 267
	ServiceUnavailable,
	// Token: 0x0400010C RID: 268
	GatewayTimeout,
	// Token: 0x0400010D RID: 269
	HttpVersionNotSupported
}
