﻿using System;

// Token: 0x02000299 RID: 665
internal class Class353
{
	// Token: 0x1700078F RID: 1935
	// (get) Token: 0x0600249C RID: 9372 RVA: 0x0001BC98 File Offset: 0x00019E98
	public static string String_0
	{
		get
		{
			return "Lâu Lan";
		}
	}

	// Token: 0x04001878 RID: 6264
	public static int int_0 = 246;

	// Token: 0x04001879 RID: 6265
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 88U,
		Int32_0 = 171,
		Int32_1 = 120,
		Int32_2 = Class353.int_0,
		String_2 = "Phù Sinh"
	};

	// Token: 0x0400187A RID: 6266
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 14U,
		Int32_0 = 211,
		Int32_1 = 176,
		Int32_2 = Class353.int_0,
		String_2 = "Cao Dương"
	};

	// Token: 0x0400187B RID: 6267
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 89U,
		Int32_0 = 191,
		Int32_1 = 130,
		Int32_2 = Class353.int_0,
		String_2 = "Phạm Thuần Hựu"
	};

	// Token: 0x0400187C RID: 6268
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 70U,
		Int32_0 = 162,
		Int32_1 = 75,
		Int32_2 = Class353.int_0,
		String_2 = "Kim Cửu Linh"
	};

	// Token: 0x0400187D RID: 6269
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 7U,
		Int32_0 = 207,
		Int32_1 = 122,
		Int32_2 = Class353.int_0,
		String_2 = "Hầu bàn Tống"
	};

	// Token: 0x0400187E RID: 6270
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 71U,
		Int32_0 = 295,
		Int32_1 = 68,
		Int32_2 = Class353.int_0,
		String_2 = "Hà Duyệt"
	};

	// Token: 0x0400187F RID: 6271
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 56U,
		Int32_0 = 193,
		Int32_1 = 224,
		Int32_2 = Class353.int_0,
		String_2 = "Trình Thanh Sương"
	};
}
