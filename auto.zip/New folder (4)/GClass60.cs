﻿using System;

// Token: 0x020000C8 RID: 200
public abstract class GClass60
{
	// Token: 0x060009A2 RID: 2466
	public abstract void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();

	// Token: 0x040004C2 RID: 1218
	public GClass99 gclass99_0;
}
