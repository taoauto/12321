﻿using System;

// Token: 0x0200011E RID: 286
public struct GStruct3
{
	// Token: 0x06000E8B RID: 3723 RVA: 0x0000C529 File Offset: 0x0000A729
	public GStruct3(int int_4, int int_5, int int_6, int int_7)
	{
		this.int_0 = int_4;
		this.int_1 = int_5;
		this.int_2 = int_6;
		this.int_3 = int_7;
	}

	// Token: 0x04000743 RID: 1859
	public int int_0;

	// Token: 0x04000744 RID: 1860
	public int int_1;

	// Token: 0x04000745 RID: 1861
	public int int_2;

	// Token: 0x04000746 RID: 1862
	public int int_3;
}
