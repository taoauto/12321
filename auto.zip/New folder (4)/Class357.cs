﻿using System;

// Token: 0x0200029D RID: 669
internal class Class357
{
	// Token: 0x17000793 RID: 1939
	// (get) Token: 0x060024A8 RID: 9384 RVA: 0x0001BCB4 File Offset: 0x00019EB4
	public static string String_0
	{
		get
		{
			return "Thái Hồ";
		}
	}

	// Token: 0x0400188B RID: 6283
	public static int int_0 = 4;

	// Token: 0x0400188C RID: 6284
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 67,
		Int32_1 = 77,
		Int32_2 = Class357.int_0,
		String_2 = "Hô Diên Khánh "
	};

	// Token: 0x0400188D RID: 6285
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 70,
		Int32_1 = 119,
		Int32_2 = Class357.int_0,
		String_2 = "Lý Cương"
	};
}
