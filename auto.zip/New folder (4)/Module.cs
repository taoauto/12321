﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x020001F7 RID: 503
public partial class Module : Form
{
	// Token: 0x06001A45 RID: 6725 RVA: 0x000130B9 File Offset: 0x000112B9
	public Module(Process process_1)
	{
		this.InitializeComponent();
		this.process_0 = process_1;
	}

	// Token: 0x06001A46 RID: 6726 RVA: 0x00002E18 File Offset: 0x00001018
	private void Module_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A47 RID: 6727 RVA: 0x000C65C0 File Offset: 0x000C47C0
	private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
	{
		try
		{
			this.listViewEx1.Items.Clear();
			foreach (object obj in this.process_0.Modules)
			{
				ProcessModule processModule = (ProcessModule)obj;
				try
				{
					this.listViewEx1.Items.Add(new ListViewItem(processModule.FileName));
				}
				catch
				{
				}
			}
			this.Text = "Module => " + this.listViewEx1.Items.Count.ToString();
		}
		catch
		{
		}
	}

	// Token: 0x06001A48 RID: 6728 RVA: 0x000130CE File Offset: 0x000112CE
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001064 RID: 4196
	private Process process_0;
}
