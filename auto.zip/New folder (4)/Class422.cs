﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x02000300 RID: 768
internal class Class422
{
	// Token: 0x06002C0E RID: 11278 RVA: 0x0002039F File Offset: 0x0001E59F
	public Class422(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x170009FE RID: 2558
	// (get) Token: 0x06002C0F RID: 11279 RVA: 0x000203AE File Offset: 0x0001E5AE
	// (set) Token: 0x06002C10 RID: 11280 RVA: 0x000203B6 File Offset: 0x0001E5B6
	public uint UInt32_0 { get; set; }

	// Token: 0x06002C11 RID: 11281 RVA: 0x000203BF File Offset: 0x0001E5BF
	public void method_0(int int_0)
	{
		this.class159_0.Class405_0.method_37(this.uint_0 + 8U, int_0);
	}

	// Token: 0x06002C12 RID: 11282 RVA: 0x001278B0 File Offset: 0x00125AB0
	public static List<Class422> smethod_0(Class159 class159_1)
	{
		List<Class422> list = new List<Class422>();
		uint num = class159_1.Class405_0.method_20(class159_1.Class392_0.UInt32_1);
		for (uint num2 = 0U; num2 < 80U; num2 += 1U)
		{
			if (class159_1.Class405_0.method_11(num + 5U + num2 * 41U) != 0U)
			{
				Class422 @class = new Class422(class159_1);
				@class.uint_0 = num + 5U + num2 * 41U;
				@class.uint_1 = class159_1.Class405_0.method_11(@class.uint_0);
				@class.uint_2 = class159_1.Class405_0.method_11(@class.uint_0 + 4U);
				@class.UInt32_0 = class159_1.Class405_0.method_11(@class.uint_0 + 8U);
				if (@class.uint_2 > 0U)
				{
					list.Add(@class);
				}
			}
		}
		return list;
	}

	// Token: 0x04001D45 RID: 7493
	public uint uint_0;

	// Token: 0x04001D46 RID: 7494
	public uint uint_1;

	// Token: 0x04001D47 RID: 7495
	public uint uint_2;

	// Token: 0x04001D48 RID: 7496
	private Class159 class159_0;

	// Token: 0x04001D49 RID: 7497
	[CompilerGenerated]
	private uint uint_3;
}
