﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000BF RID: 191
public class GEventArgs6 : EventArgs
{
	// Token: 0x1700029B RID: 667
	// (get) Token: 0x0600094B RID: 2379 RVA: 0x00009156 File Offset: 0x00007356
	// (set) Token: 0x0600094C RID: 2380 RVA: 0x0000915E File Offset: 0x0000735E
	public GClass51 GClass51_0 { get; internal set; }

	// Token: 0x1700029C RID: 668
	// (get) Token: 0x0600094D RID: 2381 RVA: 0x00009167 File Offset: 0x00007367
	// (set) Token: 0x0600094E RID: 2382 RVA: 0x0000916F File Offset: 0x0000736F
	public bool Boolean_0 { get; set; }

	// Token: 0x1700029D RID: 669
	// (get) Token: 0x0600094F RID: 2383 RVA: 0x00009178 File Offset: 0x00007378
	// (set) Token: 0x06000950 RID: 2384 RVA: 0x00009180 File Offset: 0x00007380
	public int Int32_0 { get; set; }

	// Token: 0x1700029E RID: 670
	// (get) Token: 0x06000951 RID: 2385 RVA: 0x00009189 File Offset: 0x00007389
	// (set) Token: 0x06000952 RID: 2386 RVA: 0x00009191 File Offset: 0x00007391
	public bool Boolean_1 { get; set; }

	// Token: 0x040004A5 RID: 1189
	[CompilerGenerated]
	private GClass51 gclass51_0;

	// Token: 0x040004A6 RID: 1190
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040004A7 RID: 1191
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040004A8 RID: 1192
	[CompilerGenerated]
	private bool bool_1;
}
