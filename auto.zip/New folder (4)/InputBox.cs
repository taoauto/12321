﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020001EB RID: 491
public partial class InputBox : Form
{
	// Token: 0x060019E0 RID: 6624 RVA: 0x00012C5A File Offset: 0x00010E5A
	public InputBox()
	{
		this.InitializeComponent();
	}

	// Token: 0x17000647 RID: 1607
	// (get) Token: 0x060019E1 RID: 6625 RVA: 0x00012C68 File Offset: 0x00010E68
	// (set) Token: 0x060019E2 RID: 6626 RVA: 0x00012C70 File Offset: 0x00010E70
	public string String_0 { get; set; }

	// Token: 0x060019E3 RID: 6627 RVA: 0x00012C79 File Offset: 0x00010E79
	private void button1_Click(object sender, EventArgs e)
	{
		this.String_0 = this.textBoxEx1.Text;
		base.Dispose();
	}

	// Token: 0x060019E4 RID: 6628 RVA: 0x00012C92 File Offset: 0x00010E92
	private void InputBox_Load(object sender, EventArgs e)
	{
		base.Icon = GClass130.Icon_1;
	}

	// Token: 0x060019E5 RID: 6629 RVA: 0x00012C9F File Offset: 0x00010E9F
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000F4F RID: 3919
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000F50 RID: 3920
	private IContainer icontainer_0;
}
