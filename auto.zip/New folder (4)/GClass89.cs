﻿using System;
using System.Drawing;

// Token: 0x02000123 RID: 291
public class GClass89 : GClass88
{
	// Token: 0x06000EC5 RID: 3781 RVA: 0x0000C814 File Offset: 0x0000AA14
	public GClass89(Brush brush_2, Brush brush_3, FontStyle fontStyle_1) : base(brush_2, brush_3, fontStyle_1)
	{
	}

	// Token: 0x06000EC6 RID: 3782 RVA: 0x00055F6C File Offset: 0x0005416C
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		if (gclass86_0.GStruct2_1.int_0 > gclass86_0.GStruct2_0.int_0)
		{
			base.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, point_0, gclass86_0);
			int num = point_0.X;
			int num2 = gclass86_0.GStruct2_0.int_0;
			while (num2 < gclass86_0.GStruct2_1.int_0 && gclass86_0.fastColoredTextBox_0[gclass86_0.GStruct2_0.int_1][num2].char_0 == ' ')
			{
				num += gclass86_0.fastColoredTextBox_0.Int32_4;
				num2++;
			}
			gclass86_0.fastColoredTextBox_0.method_19(new GClass104(gclass86_0.GStruct2_0.int_1, new Rectangle(num, point_0.Y, point_0.X + (gclass86_0.GStruct2_1.int_0 - gclass86_0.GStruct2_0.int_0) * gclass86_0.fastColoredTextBox_0.Int32_4 - num, gclass86_0.fastColoredTextBox_0.Int32_2)));
			return;
		}
		using (Font font = new Font(gclass86_0.fastColoredTextBox_0.Font, base.FontStyle_0))
		{
			graphics_0.DrawString("...", font, base.Brush_0, (float)gclass86_0.fastColoredTextBox_0.Int32_7, (float)(point_0.Y - 2));
		}
		gclass86_0.fastColoredTextBox_0.method_19(new GClass104(gclass86_0.GStruct2_0.int_1, new Rectangle(gclass86_0.fastColoredTextBox_0.Int32_7 + 2, point_0.Y, 2 * gclass86_0.fastColoredTextBox_0.Int32_2, gclass86_0.fastColoredTextBox_0.Int32_2)));
	}
}
