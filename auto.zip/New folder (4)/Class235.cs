﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020001F9 RID: 505
internal class Class235
{
	// Token: 0x1700065A RID: 1626
	// (get) Token: 0x06001A4F RID: 6735 RVA: 0x0001312D File Offset: 0x0001132D
	// (set) Token: 0x06001A50 RID: 6736 RVA: 0x00013134 File Offset: 0x00011334
	public static int Int32_0 { get; set; } = 3;

	// Token: 0x1700065B RID: 1627
	// (get) Token: 0x06001A51 RID: 6737 RVA: 0x0001313C File Offset: 0x0001133C
	// (set) Token: 0x06001A52 RID: 6738 RVA: 0x00013143 File Offset: 0x00011343
	public static int Int32_1 { get; set; } = 30;

	// Token: 0x0400106C RID: 4204
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x0400106D RID: 4205
	public static bool bool_0 = true;

	// Token: 0x0400106E RID: 4206
	[CompilerGenerated]
	private static int int_1;
}
