﻿using System;

// Token: 0x020002B1 RID: 689
internal class Class375
{
	// Token: 0x17000849 RID: 2121
	// (get) Token: 0x06002674 RID: 9844 RVA: 0x0001CB58 File Offset: 0x0001AD58
	public static string String_0
	{
		get
		{
			return "Lăng Ba Động";
		}
	}

	// Token: 0x040019D8 RID: 6616
	public static int int_0 = 14;

	// Token: 0x040019D9 RID: 6617
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 16U,
		Int32_0 = 65,
		Int32_1 = 55,
		Int32_2 = Class375.int_0,
		String_2 = "Cẩu Độc"
	};

	// Token: 0x040019DA RID: 6618
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 126,
		Int32_1 = 145,
		Int32_2 = Class375.int_0,
		String_2 = "Tô Tinh Hà"
	};

	// Token: 0x040019DB RID: 6619
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 119,
		Int32_1 = 152,
		Int32_2 = Class375.int_0,
		String_2 = "Tần Quán"
	};

	// Token: 0x040019DC RID: 6620
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 125,
		Int32_1 = 142,
		Int32_2 = Class375.int_0,
		String_2 = "Khang Quảng Lăng"
	};
}
