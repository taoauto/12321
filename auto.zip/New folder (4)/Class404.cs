﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x020002DF RID: 735
internal class Class404
{
	// Token: 0x06002A16 RID: 10774
	[DllImport("user32.dll")]
	private static extern IntPtr SendMessage(IntPtr intptr_0, uint uint_0, IntPtr intptr_1, IntPtr intptr_2);

	// Token: 0x06002A17 RID: 10775
	[DllImport("user32.dll", EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_1(IntPtr intptr_0, int int_29, IntPtr intptr_1, ref Class404.Struct6 struct6_0);

	// Token: 0x06002A18 RID: 10776 RVA: 0x0011F658 File Offset: 0x0011D858
	public static void smethod_0(ListView listView_0, int int_29, SortOrder sortOrder_0)
	{
		IntPtr intptr_ = Class404.SendMessage(listView_0.Handle, 4127U, IntPtr.Zero, IntPtr.Zero);
		for (int i = 0; i <= listView_0.Columns.Count - 1; i++)
		{
			IntPtr intptr_2 = new IntPtr(i);
			Class404.Struct6 @struct = default(Class404.Struct6);
			@struct.int_0 = 4;
			Class404.SendMessage_1(intptr_, 4619, intptr_2, ref @struct);
			if (sortOrder_0 != SortOrder.None && i == int_29)
			{
				if (sortOrder_0 != SortOrder.Ascending)
				{
					if (sortOrder_0 == SortOrder.Descending)
					{
						@struct.int_3 &= -1025;
						@struct.int_3 |= 512;
					}
				}
				else
				{
					@struct.int_3 &= -513;
					@struct.int_3 |= 1024;
				}
				@struct.int_3 |= 4096;
			}
			else
			{
				@struct.int_3 &= -5633;
			}
			Class404.SendMessage_1(intptr_, 4620, intptr_2, ref @struct);
		}
	}

	// Token: 0x04001C17 RID: 7191
	private const int int_0 = 1;

	// Token: 0x04001C18 RID: 7192
	private const int int_1 = 1;

	// Token: 0x04001C19 RID: 7193
	private const int int_2 = 2;

	// Token: 0x04001C1A RID: 7194
	private const int int_3 = 4;

	// Token: 0x04001C1B RID: 7195
	private const int int_4 = 8;

	// Token: 0x04001C1C RID: 7196
	private const int int_5 = 16;

	// Token: 0x04001C1D RID: 7197
	private const int int_6 = 32;

	// Token: 0x04001C1E RID: 7198
	private const int int_7 = 64;

	// Token: 0x04001C1F RID: 7199
	private const int int_8 = 128;

	// Token: 0x04001C20 RID: 7200
	private const int int_9 = 256;

	// Token: 0x04001C21 RID: 7201
	private const int int_10 = 0;

	// Token: 0x04001C22 RID: 7202
	private const int int_11 = 1;

	// Token: 0x04001C23 RID: 7203
	private const int int_12 = 2;

	// Token: 0x04001C24 RID: 7204
	private const int int_13 = 3;

	// Token: 0x04001C25 RID: 7205
	private const int int_14 = 4;

	// Token: 0x04001C26 RID: 7206
	private const int int_15 = 32768;

	// Token: 0x04001C27 RID: 7207
	private const int int_16 = 16384;

	// Token: 0x04001C28 RID: 7208
	private const int int_17 = 8192;

	// Token: 0x04001C29 RID: 7209
	private const int int_18 = 4096;

	// Token: 0x04001C2A RID: 7210
	private const int int_19 = 2048;

	// Token: 0x04001C2B RID: 7211
	private const int int_20 = 1024;

	// Token: 0x04001C2C RID: 7212
	private const int int_21 = 512;

	// Token: 0x04001C2D RID: 7213
	private const int int_22 = 4096;

	// Token: 0x04001C2E RID: 7214
	private const int int_23 = 4127;

	// Token: 0x04001C2F RID: 7215
	private const int int_24 = 4608;

	// Token: 0x04001C30 RID: 7216
	private const int int_25 = 4616;

	// Token: 0x04001C31 RID: 7217
	private const int int_26 = 4617;

	// Token: 0x04001C32 RID: 7218
	private const int int_27 = 4619;

	// Token: 0x04001C33 RID: 7219
	private const int int_28 = 4620;

	// Token: 0x020002E0 RID: 736
	public struct Struct6
	{
		// Token: 0x04001C34 RID: 7220
		public int int_0;

		// Token: 0x04001C35 RID: 7221
		public int int_1;

		// Token: 0x04001C36 RID: 7222
		[MarshalAs(UnmanagedType.LPTStr)]
		public string string_0;

		// Token: 0x04001C37 RID: 7223
		public IntPtr intptr_0;

		// Token: 0x04001C38 RID: 7224
		public int int_2;

		// Token: 0x04001C39 RID: 7225
		public int int_3;

		// Token: 0x04001C3A RID: 7226
		public int int_4;

		// Token: 0x04001C3B RID: 7227
		public int int_5;

		// Token: 0x04001C3C RID: 7228
		public int int_6;
	}
}
