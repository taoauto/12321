﻿using System;
using System.Runtime.Serialization;
using System.Security.Permissions;

// Token: 0x0200000D RID: 13
[Serializable]
public sealed class GException1 : GException0
{
	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000084 RID: 132 RVA: 0x00003564 File Offset: 0x00001764
	// (set) Token: 0x06000085 RID: 133 RVA: 0x0000356C File Offset: 0x0000176C
	public GEnum0 GEnum0_0 { get; internal set; }

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000086 RID: 134 RVA: 0x00003575 File Offset: 0x00001775
	// (set) Token: 0x06000087 RID: 135 RVA: 0x0000357D File Offset: 0x0000177D
	public GEnum3 GEnum3_0 { get; private set; }

	// Token: 0x1700004D RID: 77
	// (get) Token: 0x06000088 RID: 136 RVA: 0x00003586 File Offset: 0x00001786
	// (set) Token: 0x06000089 RID: 137 RVA: 0x0000358E File Offset: 0x0000178E
	internal bool Boolean_0 { get; set; }

	// Token: 0x0600008A RID: 138 RVA: 0x00003597 File Offset: 0x00001797
	public GException1() : this(Class2.String_15, null)
	{
	}

	// Token: 0x0600008B RID: 139 RVA: 0x000035A5 File Offset: 0x000017A5
	public GException1(string string_0, Exception exception_0 = null) : base(string_0, exception_0)
	{
	}

	// Token: 0x0600008C RID: 140 RVA: 0x000035AF File Offset: 0x000017AF
	public GException1(string string_0, GEnum0 genum0_0, GEnum3 genum3_0 = GEnum3.None, Exception exception_0 = null) : base(string_0, exception_0)
	{
		this.GEnum0_0 = genum0_0;
		this.GEnum3_0 = genum3_0;
	}

	// Token: 0x0600008D RID: 141 RVA: 0x000035C8 File Offset: 0x000017C8
	private GException1(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0) : base(serializationInfo_0, streamingContext_0)
	{
		if (serializationInfo_0 != null)
		{
			this.GEnum0_0 = (GEnum0)serializationInfo_0.GetInt32("Status");
			this.GEnum3_0 = (GEnum3)serializationInfo_0.GetInt32("HttpStatusCode");
		}
	}

	// Token: 0x0600008E RID: 142 RVA: 0x000035F7 File Offset: 0x000017F7
	[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
	public void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		base.GetObjectData(info, context);
		if (info != null)
		{
			info.AddValue("Status", (int)this.GEnum0_0);
			info.AddValue("HttpStatusCode", (int)this.GEnum3_0);
		}
	}
}
