﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020002A3 RID: 675
internal class SellItem : UserControl
{
	// Token: 0x060024DC RID: 9436 RVA: 0x0001BDA2 File Offset: 0x00019FA2
	public SellItem()
	{
		this.InitializeComponent();
	}

	// Token: 0x060024DD RID: 9437 RVA: 0x0010B304 File Offset: 0x00109504
	private void SellItem_Load(object sender, EventArgs e)
	{
		this.txtSellName.Text = Class415.String_24;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(SellItem.Class362.<>9.method_0)).ToArray<ListViewItem>());
		foreach (object obj in this.lvDinhSan.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (Class415.String_26.Contains(listViewItem.Text))
			{
				listViewItem.Checked = true;
			}
		}
		this.tabPage2.Controls.Add(new SellItemPS
		{
			Dock = DockStyle.Fill
		});
	}

	// Token: 0x060024DE RID: 9438 RVA: 0x0010B3EC File Offset: 0x001095EC
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtSellName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtSellName.Text = this.txtSellName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtSellName.method_1();
	}

	// Token: 0x060024DF RID: 9439 RVA: 0x0001BDB0 File Offset: 0x00019FB0
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024E0 RID: 9440 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuAddType_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060024E1 RID: 9441 RVA: 0x0001BDB0 File Offset: 0x00019FB0
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060024E2 RID: 9442 RVA: 0x0010B4EC File Offset: 0x001096EC
	private void btnOk_Click(object sender, EventArgs e)
	{
		Class415.String_24 = this.txtSellName.Text;
		string text = "";
		foreach (object obj in this.lvDinhSan.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Checked)
			{
				text = text + "[" + listViewItem.Text.Trim() + "]";
			}
		}
		Class415.String_26 = text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x060024E3 RID: 9443 RVA: 0x0001BDB8 File Offset: 0x00019FB8
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x060024E4 RID: 9444 RVA: 0x00002E18 File Offset: 0x00001018
	private void lvDinhSan_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060024E5 RID: 9445 RVA: 0x0001BDD1 File Offset: 0x00019FD1
	private void textBoxEx1_TextChanged(object sender, EventArgs e)
	{
		this.txtSellName.method_0(this.textBoxEx1.Text);
	}

	// Token: 0x060024E6 RID: 9446 RVA: 0x00002E18 File Offset: 0x00001018
	private void txtSellName_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060024E7 RID: 9447 RVA: 0x0001BDE9 File Offset: 0x00019FE9
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060024E8 RID: 9448 RVA: 0x0010B5D0 File Offset: 0x001097D0
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(SellItem));
		ListViewItem listViewItem = new ListViewItem("Ngọc Thời Trang Cấp 1 [Cố Định]");
		ListViewItem listViewItem2 = new ListViewItem("Huyền Binh Thạch [Nếu Đã Có Thần Khí 8 Sao]");
		ListViewItem listViewItem3 = new ListViewItem("Long Văn, Chú Văn Cố Định [Nếu Long Văn 100]");
		ListViewItem listViewItem4 = new ListViewItem("Võ Hồn Cố Định [Nếu Võ Hồn Cấp 7]");
		ListViewItem listViewItem5 = new ListViewItem(new string[]
		{
			"Vũ Khí Đả Tạo Đồ",
			"Khuyên Dùng"
		}, -1);
		ListViewItem listViewItem6 = new ListViewItem(new string[]
		{
			"Đả Tạo Đồ 1,2,3,4",
			"Khuyên Dùng"
		}, -1);
		ListViewItem listViewItem7 = new ListViewItem("Đục Lỗ 1,2,3,4,5,6,7");
		ListViewItem listViewItem8 = new ListViewItem(new string[]
		{
			"Thức Ăn, Đạo Cụ Rác",
			"Khuyên Dùng"
		}, -1);
		ListViewItem listViewItem9 = new ListViewItem("Trang Bị 1,2,3,4 Sao");
		ListViewItem listViewItem10 = new ListViewItem("Trang Bị 5 Sao");
		ListViewItem listViewItem11 = new ListViewItem("Trang Bị Chưa Giám Định");
		ListViewItem listViewItem12 = new ListViewItem(new string[]
		{
			"Nguyên Liệu Đúc, May, Công Nghệ, Dược",
			"Khuyên Dùng"
		}, -1);
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.menuName_1 = new ContextMenuStrip(this.icontainer_0);
		this.menuAddType = new ToolStripMenuItem();
		this.btnOk = new Button();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.splitContainer1 = new SplitContainer();
		this.txtSellName = new Class85();
		this.textBoxEx1 = new Class85();
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtSearchName = new Class85();
		this.tabPage3 = new TabPage();
		this.lvDinhSan = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.tabPage2 = new TabPage();
		this.menuName.SuspendLayout();
		this.menuName_1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabPage3.SuspendLayout();
		base.SuspendLayout();
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.menuName_1.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddType
		});
		this.menuName_1.Name = "menuName";
		this.menuName_1.Size = new Size(105, 26);
		this.menuAddType.Name = "menuAddType";
		this.menuAddType.Size = new Size(104, 22);
		this.menuAddType.Text = "Thêm";
		this.menuAddType.Click += this.menuAddType_Click;
		this.btnOk.Dock = DockStyle.Bottom;
		this.btnOk.Location = new Point(0, 457);
		this.btnOk.Name = "btnOk";
		this.btnOk.Size = new Size(568, 23);
		this.btnOk.TabIndex = 13;
		this.btnOk.Text = "Save";
		this.btnOk.UseVisualStyleBackColor = true;
		this.btnOk.Click += this.btnOk_Click;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage3);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(568, 457);
		this.tabControlEx1.TabIndex = 15;
		this.tabControlEx1.Tag = "Bán Đồ - Sell Item";
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(560, 431);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Theo Tên";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtSellName);
		this.splitContainer1.Panel1.Controls.Add(this.textBoxEx1);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(554, 425);
		this.splitContainer1.SplitterDistance = 270;
		this.splitContainer1.TabIndex = 0;
		this.txtSellName.Dock = DockStyle.Fill;
		this.txtSellName.Location = new Point(0, 20);
		this.txtSellName.Multiline = true;
		this.txtSellName.Name = "txtSellName";
		this.txtSellName.ScrollBars = ScrollBars.Vertical;
		this.txtSellName.Size = new Size(270, 405);
		this.txtSellName.TabIndex = 9;
		this.txtSellName.String_0 = "";
		this.txtSellName.Color_0 = Color.Gray;
		this.txtSellName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSellName.Color_1 = Color.LightGray;
		this.txtSellName.TextChanged += this.txtSellName_TextChanged;
		this.textBoxEx1.Dock = DockStyle.Top;
		this.textBoxEx1.Location = new Point(0, 0);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new Size(270, 20);
		this.textBoxEx1.TabIndex = 10;
		this.textBoxEx1.String_0 = "Search";
		this.textBoxEx1.Color_0 = Color.Gray;
		this.textBoxEx1.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = Color.LightGray;
		this.textBoxEx1.TextChanged += this.textBoxEx1_TextChanged;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(280, 405);
		this.lvName.TabIndex = 11;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 200;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(280, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		this.tabPage3.Controls.Add(this.lvDinhSan);
		this.tabPage3.Location = new Point(4, 22);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new Padding(3);
		this.tabPage3.Size = new Size(560, 431);
		this.tabPage3.TabIndex = 2;
		this.tabPage3.Text = "Định Sẵn";
		this.tabPage3.UseVisualStyleBackColor = true;
		this.lvDinhSan.AllowColumnReorder = true;
		this.lvDinhSan.AllowDrop = true;
		this.lvDinhSan.AllowReorder = true;
		this.lvDinhSan.AllowSort = false;
		this.lvDinhSan.CheckBoxes = true;
		this.lvDinhSan.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.lvDinhSan.Dock = DockStyle.Fill;
		this.lvDinhSan.DoubleClickActivation = false;
		this.lvDinhSan.FullRowSelect = true;
		this.lvDinhSan.GridLines = true;
		this.lvDinhSan.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvDinhSan.hideItems");
		this.lvDinhSan.HideSelection = false;
		listViewItem.StateImageIndex = 0;
		listViewItem2.StateImageIndex = 0;
		listViewItem3.StateImageIndex = 0;
		listViewItem4.StateImageIndex = 0;
		listViewItem5.StateImageIndex = 0;
		listViewItem6.StateImageIndex = 0;
		listViewItem7.StateImageIndex = 0;
		listViewItem8.StateImageIndex = 0;
		listViewItem9.StateImageIndex = 0;
		listViewItem10.StateImageIndex = 0;
		listViewItem11.StateImageIndex = 0;
		listViewItem12.StateImageIndex = 0;
		this.lvDinhSan.Items.AddRange(new ListViewItem[]
		{
			listViewItem,
			listViewItem2,
			listViewItem3,
			listViewItem4,
			listViewItem5,
			listViewItem6,
			listViewItem7,
			listViewItem8,
			listViewItem9,
			listViewItem10,
			listViewItem11,
			listViewItem12
		});
		this.lvDinhSan.LineColor = Color.Red;
		this.lvDinhSan.Location = new Point(3, 3);
		this.lvDinhSan.Name = "lvDinhSan";
		this.lvDinhSan.Size = new Size(554, 425);
		this.lvDinhSan.TabIndex = 0;
		this.lvDinhSan.UseCompatibleStateImageBehavior = false;
		this.lvDinhSan.View = View.Details;
		this.lvDinhSan.SelectedIndexChanged += this.lvDinhSan_SelectedIndexChanged;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 294;
		this.columnHeader_2.Text = "Note";
		this.columnHeader_2.Width = 122;
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(560, 431);
		this.tabPage2.TabIndex = 3;
		this.tabPage2.Text = "Treo Shop";
		this.tabPage2.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Controls.Add(this.btnOk);
		base.Name = "SellItem";
		base.Size = new Size(568, 480);
		base.Tag = "Bán Đồ - Sell Item";
		base.Load += this.SellItem_Load;
		this.menuName.ResumeLayout(false);
		this.menuName_1.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		this.tabPage3.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040018CC RID: 6348
	private IContainer icontainer_0;

	// Token: 0x040018CD RID: 6349
	private ContextMenuStrip menuName;

	// Token: 0x040018CE RID: 6350
	private ToolStripMenuItem menuAddName;

	// Token: 0x040018CF RID: 6351
	private ContextMenuStrip menuName_1;

	// Token: 0x040018D0 RID: 6352
	private ToolStripMenuItem menuAddType;

	// Token: 0x040018D1 RID: 6353
	private Button btnOk;

	// Token: 0x040018D2 RID: 6354
	private ListViewEx lvName;

	// Token: 0x040018D3 RID: 6355
	private ColumnHeader columnHeader_0;

	// Token: 0x040018D4 RID: 6356
	private Class85 txtSellName;

	// Token: 0x040018D5 RID: 6357
	private Control1 tabControlEx1;

	// Token: 0x040018D6 RID: 6358
	private TabPage tabPage1;

	// Token: 0x040018D7 RID: 6359
	private SplitContainer splitContainer1;

	// Token: 0x040018D8 RID: 6360
	private Class85 txtSearchName;

	// Token: 0x040018D9 RID: 6361
	private TabPage tabPage3;

	// Token: 0x040018DA RID: 6362
	private ListViewEx lvDinhSan;

	// Token: 0x040018DB RID: 6363
	private ColumnHeader columnHeader_1;

	// Token: 0x040018DC RID: 6364
	private ColumnHeader columnHeader_2;

	// Token: 0x040018DD RID: 6365
	private Class85 textBoxEx1;

	// Token: 0x040018DE RID: 6366
	private TabPage tabPage2;

	// Token: 0x020002A4 RID: 676
	[CompilerGenerated]
	[Serializable]
	private sealed class Class362
	{
		// Token: 0x060024EB RID: 9451 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x040018DF RID: 6367
		public static readonly SellItem.Class362 <>9 = new SellItem.Class362();

		// Token: 0x040018E0 RID: 6368
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
