﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;

// Token: 0x0200028A RID: 650
public static class GClass127
{
	// Token: 0x06002429 RID: 9257 RVA: 0x0001B91C File Offset: 0x00019B1C
	public static string smethod_0(this string string_2)
	{
		return Class426.smethod_57(string_2);
	}

	// Token: 0x0600242A RID: 9258 RVA: 0x00106B94 File Offset: 0x00104D94
	public static string smethod_1(this string string_2)
	{
		for (int i = 1; i < GClass127.string_1.Length; i++)
		{
			for (int j = 0; j < GClass127.string_1[i].Length; j++)
			{
				string_2 = string_2.Replace(GClass127.string_1[i][j], GClass127.string_1[0][i - 1]);
			}
		}
		return string_2;
	}

	// Token: 0x0600242B RID: 9259 RVA: 0x0001B924 File Offset: 0x00019B24
	public static void smethod_2(this RichTextBox richTextBox_0, string string_2, Color color_0, bool bool_0 = false)
	{
		richTextBox_0.Text = richTextBox_0.Text.Insert(0, string_2);
		GClass127.smethod_5(richTextBox_0, 0, string_2.Length, color_0, bool_0);
	}

	// Token: 0x0600242C RID: 9260 RVA: 0x00106BF0 File Offset: 0x00104DF0
	public static RichTextBox smethod_3(ref RichTextBox richTextBox_0, string string_2, string string_3, Color color_0)
	{
		richTextBox_0.SuspendLayout();
		Point autoScrollOffset = richTextBox_0.AutoScrollOffset;
		int selectionIndent = richTextBox_0.SelectionIndent;
		int selectionStart = richTextBox_0.SelectionStart;
		foreach (Point point in GClass127.smethod_4(richTextBox_0.Text, string_2, string_3, true))
		{
			richTextBox_0.SelectionStart = point.X;
			richTextBox_0.SelectionLength = point.Y - point.X;
			richTextBox_0.SelectionColor = color_0;
		}
		richTextBox_0.SelectionStart = selectionStart;
		richTextBox_0.SelectionIndent = selectionIndent;
		richTextBox_0.AutoScrollOffset = autoScrollOffset;
		richTextBox_0.ResumeLayout(true);
		return richTextBox_0;
	}

	// Token: 0x0600242D RID: 9261 RVA: 0x00106CB4 File Offset: 0x00104EB4
	public static List<Point> smethod_4(string string_2, string string_3, string string_4, bool bool_0 = true)
	{
		List<Point> list = new List<Point>();
		Stack<int> stack = new Stack<int>();
		bool flag = false;
		for (int i = 0; i < string_2.Length; i++)
		{
			string text = string_2.Substring(i);
			if (text.StartsWith(string_3) && ((string_3 == string_4 && !flag) || !text.StartsWith(string_4)))
			{
				if (!bool_0)
				{
					i += string_3.Length;
				}
				flag = true;
				stack.Push(i);
			}
			else if (text.StartsWith(string_4))
			{
				if (bool_0)
				{
					i += string_4.Length;
				}
				flag = false;
				if (stack.Count > 0)
				{
					int x = stack.Pop();
					list.Add(new Point(x, i));
				}
			}
		}
		return list;
	}

	// Token: 0x0600242E RID: 9262 RVA: 0x0001B949 File Offset: 0x00019B49
	public static RichTextBox smethod_5(RichTextBox richTextBox_0, int int_2, int int_3, Color color_0, bool bool_0 = false)
	{
		richTextBox_0.SuspendLayout();
		richTextBox_0.SelectionStart = 0;
		richTextBox_0.SelectionLength = int_3;
		richTextBox_0.SelectionColor = color_0;
		richTextBox_0.ResumeLayout(true);
		return richTextBox_0;
	}

	// Token: 0x0600242F RID: 9263 RVA: 0x0001B96E File Offset: 0x00019B6E
	public static void smethod_6(this RichTextBox richTextBox_0, string string_2, Color color_0)
	{
		richTextBox_0.SelectionStart = richTextBox_0.TextLength;
		richTextBox_0.SelectionLength = 0;
		richTextBox_0.SelectionColor = color_0;
		richTextBox_0.AppendText(string_2);
		richTextBox_0.SelectionColor = richTextBox_0.ForeColor;
	}

	// Token: 0x06002430 RID: 9264 RVA: 0x0001B99D File Offset: 0x00019B9D
	public static void smethod_7(this RichTextBox richTextBox_0)
	{
		richTextBox_0.SelectionStart = richTextBox_0.Text.Length;
		richTextBox_0.ScrollToCaret();
	}

	// Token: 0x06002431 RID: 9265 RVA: 0x0001B9B6 File Offset: 0x00019BB6
	public static int smethod_8(this object object_0)
	{
		return Class426.smethod_43(object_0.ToString());
	}

	// Token: 0x06002432 RID: 9266 RVA: 0x00069638 File Offset: 0x00067838
	public static T smethod_9<T>(this T gparam_0)
	{
		T result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(memoryStream, gparam_0);
			memoryStream.Position = 0L;
			result = (T)((object)binaryFormatter.Deserialize(memoryStream));
		}
		return result;
	}

	// Token: 0x06002433 RID: 9267 RVA: 0x00106D5C File Offset: 0x00104F5C
	public static void smethod_10(string string_2, string string_3, string string_4, string string_5, NameValueCollection nameValueCollection_0)
	{
		string str = "---------------------------" + DateTime.Now.Ticks.ToString("x");
		byte[] bytes = Encoding.ASCII.GetBytes("\r\n--" + str + "\r\n");
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_2);
		httpWebRequest.ContentType = "multipart/form-data; boundary=" + str;
		httpWebRequest.Method = "POST";
		httpWebRequest.KeepAlive = true;
		httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
		Stream requestStream = httpWebRequest.GetRequestStream();
		string format = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";
		foreach (object obj in nameValueCollection_0.Keys)
		{
			string text = (string)obj;
			requestStream.Write(bytes, 0, bytes.Length);
			string s = string.Format(format, text, nameValueCollection_0[text]);
			byte[] bytes2 = Encoding.UTF8.GetBytes(s);
			requestStream.Write(bytes2, 0, bytes2.Length);
		}
		requestStream.Write(bytes, 0, bytes.Length);
		string s2 = string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n", string_4, string_3, string_5);
		byte[] bytes3 = Encoding.UTF8.GetBytes(s2);
		requestStream.Write(bytes3, 0, bytes3.Length);
		FileStream fileStream = new FileStream(string_3, FileMode.Open, FileAccess.Read);
		byte[] array = new byte[4096];
		int count;
		while ((count = fileStream.Read(array, 0, array.Length)) != 0)
		{
			requestStream.Write(array, 0, count);
		}
		fileStream.Close();
		byte[] bytes4 = Encoding.ASCII.GetBytes("\r\n--" + str + "--\r\n");
		requestStream.Write(bytes4, 0, bytes4.Length);
		requestStream.Close();
		WebResponse webResponse = null;
		try
		{
			webResponse = httpWebRequest.GetResponse();
			new StreamReader(webResponse.GetResponseStream());
		}
		catch
		{
			if (webResponse != null)
			{
				webResponse.Close();
				webResponse = null;
			}
		}
		finally
		{
			httpWebRequest = null;
		}
	}

	// Token: 0x06002434 RID: 9268 RVA: 0x00106F68 File Offset: 0x00105168
	public static void smethod_11(this FastColoredTextBox fastColoredTextBox_0, string string_2)
	{
		string_2 = string_2.smethod_0();
		GClass86 gclass;
		if (string_2.Length == 0)
		{
			gclass = fastColoredTextBox_0.GClass86_5.method_6();
			gclass.GStruct2_0 = new GStruct2(0, 0);
			gclass.GStruct2_1 = new GStruct2(0, 0);
			gclass.method_40();
			fastColoredTextBox_0.GClass86_5 = gclass;
			fastColoredTextBox_0.method_51();
			fastColoredTextBox_0.method_4();
			return;
		}
		if (string_2.Length > 0)
		{
			for (int i = 0; i < fastColoredTextBox_0.IList_0.Count; i++)
			{
				if (Class426.smethod_57(fastColoredTextBox_0.IList_0[i]).Contains(string_2))
				{
					gclass = fastColoredTextBox_0.GClass86_5.method_6();
					gclass.GStruct2_0 = new GStruct2(0, i);
					gclass.GStruct2_1 = new GStruct2(fastColoredTextBox_0.IList_0[i].Length, i);
					gclass.method_40();
					fastColoredTextBox_0.GClass86_5 = gclass;
					fastColoredTextBox_0.method_51();
					fastColoredTextBox_0.method_4();
					return;
				}
			}
		}
		gclass = fastColoredTextBox_0.GClass86_5.method_6();
		gclass.GStruct2_0 = new GStruct2(0, 0);
		gclass.GStruct2_1 = new GStruct2(0, 0);
		gclass.method_40();
		fastColoredTextBox_0.GClass86_5 = gclass;
		fastColoredTextBox_0.method_51();
		fastColoredTextBox_0.method_4();
	}

	// Token: 0x06002435 RID: 9269
	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	public static extern IntPtr SendMessage(HandleRef handleRef_0, int int_2, int int_3, ref GClass127.GStruct21 gstruct21_0);

	// Token: 0x06002436 RID: 9270 RVA: 0x0001B9C3 File Offset: 0x00019BC3
	public static void smethod_12(this ListView listView_0)
	{
		GClass127.smethod_16(listView_0, -1, 2, 2);
	}

	// Token: 0x06002437 RID: 9271 RVA: 0x00107094 File Offset: 0x00105294
	public static void smethod_13<T>(this IEnumerable<T> ienumerable_0, Action<T> action_0)
	{
		foreach (T obj in ienumerable_0)
		{
			action_0(obj);
		}
	}

	// Token: 0x06002438 RID: 9272 RVA: 0x0001B9CE File Offset: 0x00019BCE
	public static IEnumerable<T> smethod_14<T, U>(this IEnumerable<T> ienumerable_0, Func<T, U> func_0)
	{
		GClass127.Class340<T, U> @class = new GClass127.Class340<T, U>(-2);
		@class.ienumerable_1 = ienumerable_0;
		@class.func_1 = func_0;
		return @class;
	}

	// Token: 0x06002439 RID: 9273 RVA: 0x0001B9E5 File Offset: 0x00019BE5
	public static void smethod_15(this Control control_0, Action action_0)
	{
		control_0.Invoke(action_0);
	}

	// Token: 0x0600243A RID: 9274 RVA: 0x001070E0 File Offset: 0x001052E0
	public static void smethod_16(ListView listView_0, int int_2, int int_3, int int_4)
	{
		GClass127.GStruct21 gstruct = default(GClass127.GStruct21);
		gstruct.int_4 = int_3;
		gstruct.int_3 = int_4;
		GClass127.SendMessage(new HandleRef(listView_0, listView_0.Handle), 4139, int_2, ref gstruct);
	}

	// Token: 0x0600243B RID: 9275 RVA: 0x0001B9EF File Offset: 0x00019BEF
	public static int smethod_17(this bool bool_0)
	{
		return Class426.smethod_22(bool_0);
	}

	// Token: 0x0600243C RID: 9276 RVA: 0x0001B9F7 File Offset: 0x00019BF7
	public static int smethod_18(this string string_2)
	{
		return Class426.smethod_41(string_2);
	}

	// Token: 0x0600243D RID: 9277 RVA: 0x0001B9FF File Offset: 0x00019BFF
	public static int smethod_19(this string string_2)
	{
		return Class426.smethod_43(string_2);
	}

	// Token: 0x0600243E RID: 9278 RVA: 0x0001BA07 File Offset: 0x00019C07
	public static void smethod_20(this Form form_0, Action action_0)
	{
		form_0.Invoke(new Action(action_0.Invoke));
	}

	// Token: 0x0600243F RID: 9279 RVA: 0x00107120 File Offset: 0x00105320
	public static double smethod_21(this Point point_0, Point point_1, Point point_2)
	{
		int num = point_1.Y - point_2.Y;
		int num2 = point_2.X - point_1.X;
		int num3 = num * (0 - point_1.X) + num2 * (0 - point_1.Y);
		return (double)Math.Abs(num * point_0.X + num2 * point_0.Y + num3) / Math.Sqrt((double)(num * num + num2 * num2));
	}

	// Token: 0x06002440 RID: 9280 RVA: 0x00107190 File Offset: 0x00105390
	public static bool smethod_22(this Point point_0, Point point_1, Point point_2)
	{
		int num = point_1.Y - point_2.Y;
		int num2 = point_2.X - point_1.X;
		int num3 = num * (0 - point_1.X) + num2 * (0 - point_1.Y);
		return num * point_0.X + num2 * point_0.Y + num3 == 0;
	}

	// Token: 0x06002441 RID: 9281 RVA: 0x001071EC File Offset: 0x001053EC
	public static bool smethod_23(this GClass126 gclass126_0, Point point_0, Point point_1)
	{
		int num = point_0.Y - point_1.Y;
		int num2 = point_1.X - point_0.X;
		int num3 = num * (0 - point_0.X) + num2 * (0 - point_0.Y);
		return (double)num * gclass126_0.Double_0 + (double)num2 * gclass126_0.Double_1 + (double)num3 == 0.0;
	}

	// Token: 0x06002442 RID: 9282 RVA: 0x00107250 File Offset: 0x00105450
	public static bool smethod_24(this Point point_0, Point point_1, Point point_2)
	{
		point_0.X -= point_2.X;
		point_1.X -= point_2.X;
		point_0.Y = point_2.Y - point_0.Y;
		point_1.Y = point_2.Y - point_1.Y;
		return (point_1.X - point_0.X) * (point_1.Y + point_0.Y) > 0;
	}

	// Token: 0x06002443 RID: 9283 RVA: 0x001072D8 File Offset: 0x001054D8
	public static int smethod_25(Point point_0, Point point_1, Point point_2, float float_0)
	{
		int num = point_0.Y - point_1.Y;
		int num2 = point_1.X - point_0.X;
		int num3 = num * (0 - point_0.X) + num2 * (0 - point_0.Y);
		num = -num / num2;
		num2 = -num3 / num2;
		int x = point_2.X;
		int y = point_2.Y;
		return (int)((double)((float)(4 * (num * (num2 - y) - x) * (num * (num2 - y) - x)) - (float)(4 * (num * num + 1)) * ((float)(x * x + (num2 - y) * (num2 - y)) - float_0 * float_0)));
	}

	// Token: 0x06002444 RID: 9284 RVA: 0x00107364 File Offset: 0x00105564
	public static List<GClass126> smethod_26(Point point_0, Point point_1, Point point_2, float float_0)
	{
		List<GClass126> list = new List<GClass126>();
		double num = (double)(point_0.Y - point_1.Y);
		double num2 = (double)(point_1.X - point_0.X);
		double num3 = num * (double)(0 - point_0.X) + num2 * (double)(0 - point_0.Y);
		if (num2 == 0.0)
		{
			double num4 = (double)point_0.X;
			double num5 = (double)(4 * point_2.Y * point_2.Y) - 4.0 * ((double)(point_2.Y * point_2.Y) + (num4 - (double)point_2.X) * (num4 - (double)point_2.X) - (double)(float_0 * float_0));
			if (num5 == 0.0)
			{
				double double_ = (double)(2 * point_2.Y / 2);
				list.Add(new GClass126(num4, double_));
				return list;
			}
			if (num5 > 0.0)
			{
				double double_2 = ((double)(2 * point_2.Y) + Math.Sqrt(num5)) / 2.0;
				double double_3 = ((double)(2 * point_2.Y) - Math.Sqrt(num5)) / 2.0;
				list.Add(new GClass126(num4, double_2));
				list.Add(new GClass126(num4, double_3));
				return list;
			}
		}
		else if (num == 0.0)
		{
			double num6 = (double)point_0.Y;
			double num5 = (double)(4 * point_2.X * point_2.X) - 4.0 * ((double)(point_2.X * point_2.X) + (num6 - (double)point_2.Y) * (num6 - (double)point_2.Y) - (double)(float_0 * float_0));
			if (num5 == 0.0)
			{
				double double_4 = (double)(2 * point_2.X / 2);
				list.Add(new GClass126(double_4, num6));
				return list;
			}
			if (num5 > 0.0)
			{
				double double_5 = ((double)(2 * point_2.X) + Math.Sqrt(num5)) / 2.0;
				double double_6 = ((double)(2 * point_2.X) - Math.Sqrt(num5)) / 2.0;
				list.Add(new GClass126(double_5, num6));
				list.Add(new GClass126(double_6, num6));
				return list;
			}
		}
		else
		{
			num = -num / num2;
			num2 = -num3 / num2;
			double num5 = 4.0 * (num * (num2 - (double)point_2.Y) - (double)point_2.X) * (num * (num2 - (double)point_2.Y) - (double)point_2.X) - 4.0 * (num * num + 1.0) * ((double)point_2.X + (num2 - (double)point_2.Y) * (num2 - (double)point_2.Y) - (double)(float_0 * float_0));
			if (num5 == 0.0)
			{
				double num7 = -2.0 * (num * (num2 - (double)point_2.Y) - (double)point_2.X) / (2.0 * (num * num + 1.0));
				list.Add(new GClass126(num7, num * num7 + num2));
				return list;
			}
			if (num5 > 0.0)
			{
				double num8 = (-2.0 * (num * (num2 - (double)point_2.Y) - (double)point_2.X) + Math.Sqrt(num5)) / (2.0 * (num * num + 1.0));
				double num9 = (-2.0 * (num * (num2 - (double)point_2.Y) - (double)point_2.X) - Math.Sqrt(num5)) / (2.0 * (num * num + 1.0));
				list.Add(new GClass126(num8, num * num8 + num2));
				list.Add(new GClass126(num9, num * num9 + num2));
				return list;
			}
		}
		return list;
	}

	// Token: 0x06002445 RID: 9285 RVA: 0x0001BA1C File Offset: 0x00019C1C
	public static IEnumerable<IEnumerable<T>> smethod_27<T>(this T[] gparam_0, int int_2)
	{
		GClass127.Class341<T> @class = new GClass127.Class341<T>(-2);
		@class.gparam_1 = gparam_0;
		@class.int_3 = int_2;
		return @class;
	}

	// Token: 0x06002446 RID: 9286 RVA: 0x00107740 File Offset: 0x00105940
	public static void smethod_28(this string string_2, string string_3)
	{
		Class426.smethod_69(string_3 + ".new", string_2);
		Class426.smethod_68(string_3 + ".old");
		Class426.smethod_67(string_3, string_3 + ".old");
		Class426.smethod_68(string_3);
		Class426.smethod_67(string_3 + ".new", string_3);
		Class426.smethod_68(string_3 + ".old");
	}

	// Token: 0x06002447 RID: 9287 RVA: 0x0001BA33 File Offset: 0x00019C33
	public static IEnumerable<T> smethod_29<T>(this Control control_0) where T : Control
	{
		GClass127.Class342<T> @class = new GClass127.Class342<T>(-2);
		@class.control_1 = control_0;
		return @class;
	}

	// Token: 0x06002448 RID: 9288 RVA: 0x0001BA43 File Offset: 0x00019C43
	public static IEnumerable<Control> smethod_30(this Control control_0)
	{
		GClass127.Class343 @class = new GClass127.Class343(-2);
		@class.control_2 = control_0;
		return @class;
	}

	// Token: 0x06002449 RID: 9289 RVA: 0x0001BA53 File Offset: 0x00019C53
	public static IEnumerable<Control> smethod_31(this Control control_0)
	{
		GClass127.Class344 @class = new GClass127.Class344(-2);
		@class.control_2 = control_0;
		return @class;
	}

	// Token: 0x0600244A RID: 9290 RVA: 0x0001BA63 File Offset: 0x00019C63
	public static IEnumerable<Control> smethod_32(this Control control_0)
	{
		IEnumerable<Control> enumerable = control_0.Controls.Cast<Control>();
		return enumerable.Concat(enumerable.SelectMany(new Func<Control, IEnumerable<Control>>(GClass127.Class345.<>9.method_0)));
	}

	// Token: 0x0600244B RID: 9291 RVA: 0x001077A8 File Offset: 0x001059A8
	public static IEnumerable<ToolStripMenuItem> smethod_33(this ToolStripMenuItem toolStripMenuItem_0)
	{
		IEnumerable<ToolStripMenuItem> enumerable = toolStripMenuItem_0.DropDownItems.Cast<ToolStripItem>().Where(new Func<ToolStripItem, bool>(GClass127.Class345.<>9.method_1)).Cast<ToolStripMenuItem>();
		return enumerable.Concat(enumerable.SelectMany(new Func<ToolStripMenuItem, IEnumerable<ToolStripMenuItem>>(GClass127.Class345.<>9.method_2)));
	}

	// Token: 0x0600244C RID: 9292 RVA: 0x00107814 File Offset: 0x00105A14
	public static string smethod_34(this string string_2, string string_3 = "-")
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (string_2 == null)
		{
			return string.Empty;
		}
		using (StringReader stringReader = new StringReader(string_2))
		{
			string value;
			while ((value = stringReader.ReadLine()) != null)
			{
				stringBuilder.Append(value).Append(string_3);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600244D RID: 9293 RVA: 0x0001BA9A File Offset: 0x00019C9A
	public static string smethod_35(this object object_0)
	{
		if (object_0 == null)
		{
			return "";
		}
		return object_0.ToString();
	}

	// Token: 0x0600244E RID: 9294 RVA: 0x0001BAAB File Offset: 0x00019CAB
	public static IEnumerable<string> smethod_36(this string string_2)
	{
		GClass127.Class346 @class = new GClass127.Class346(-2);
		@class.string_2 = string_2;
		return @class;
	}

	// Token: 0x0600244F RID: 9295 RVA: 0x00107874 File Offset: 0x00105A74
	public static int smethod_37(this string string_2)
	{
		if (string.IsNullOrEmpty(string_2))
		{
			return -1;
		}
		int num = 0;
		string text = string.Empty;
		for (int i = 0; i < string_2.Length; i++)
		{
			if (char.IsDigit(string_2[i]))
			{
				text += string_2[i].ToString();
			}
			else if (text.Length > 0)
			{
				break;
			}
		}
		if (text.Length > 0)
		{
			num = int.Parse(text);
		}
		if (string_2.StartsWith("-"))
		{
			return -num;
		}
		return num;
	}

	// Token: 0x040017E0 RID: 6112
	private static readonly string[] string_0 = new string[]
	{
		"aaeeoouuiiddyy",
		"áàạảãâấầậẩẫăắằặẳẵ",
		"ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
		"éèẹẻẽêếềệểễ",
		"ÉÈẸẺẼÊẾỀỆỂỄ",
		"óòọỏõôốồộổỗơớờợởỡ",
		"ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
		"úùụủũưứừựửữ",
		"ÚÙỤỦŨƯỨỪỰỬỮ",
		"íìịỉĩ",
		"ÍÌỊỈĨ",
		"đ",
		"Đ",
		"ýỳỵỷỹ",
		"ÝỲỴỶỸ"
	};

	// Token: 0x040017E1 RID: 6113
	private static readonly string[] string_1 = new string[]
	{
		"aAeEoOuUiIdDyY",
		"áàạảãâấầậẩẫăắằặẳẵ",
		"ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
		"éèẹẻẽêếềệểễ",
		"ÉÈẸẺẼÊẾỀỆỂỄ",
		"óòọỏõôốồộổỗơớờợởỡ",
		"ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
		"úùụủũưứừựửữ",
		"ÚÙỤỦŨƯỨỪỰỬỮ",
		"íìịỉĩ",
		"ÍÌỊỈĨ",
		"đ",
		"Đ",
		"ýỳỵỷỹ",
		"ÝỲỴỶỸ"
	};

	// Token: 0x040017E2 RID: 6114
	internal const int int_0 = 4096;

	// Token: 0x040017E3 RID: 6115
	private const int int_1 = 4139;

	// Token: 0x0200028B RID: 651
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	public struct GStruct21
	{
		// Token: 0x040017E4 RID: 6116
		public int int_0;

		// Token: 0x040017E5 RID: 6117
		public int int_1;

		// Token: 0x040017E6 RID: 6118
		public int int_2;

		// Token: 0x040017E7 RID: 6119
		public int int_3;

		// Token: 0x040017E8 RID: 6120
		public int int_4;

		// Token: 0x040017E9 RID: 6121
		[MarshalAs(UnmanagedType.LPTStr)]
		public string string_0;

		// Token: 0x040017EA RID: 6122
		public int int_5;

		// Token: 0x040017EB RID: 6123
		public int int_6;

		// Token: 0x040017EC RID: 6124
		public IntPtr intptr_0;

		// Token: 0x040017ED RID: 6125
		public int int_7;

		// Token: 0x040017EE RID: 6126
		public int int_8;

		// Token: 0x040017EF RID: 6127
		public int int_9;

		// Token: 0x040017F0 RID: 6128
		public IntPtr intptr_1;
	}

	// Token: 0x02000291 RID: 657
	[CompilerGenerated]
	[Serializable]
	private sealed class Class345
	{
		// Token: 0x0600247E RID: 9342 RVA: 0x0001BC08 File Offset: 0x00019E08
		internal IEnumerable<Control> method_0(Control control_0)
		{
			return control_0.smethod_32();
		}

		// Token: 0x0600247F RID: 9343 RVA: 0x0001BC10 File Offset: 0x00019E10
		internal bool method_1(ToolStripItem toolStripItem_0)
		{
			return toolStripItem_0.GetType() == typeof(ToolStripMenuItem);
		}

		// Token: 0x06002480 RID: 9344 RVA: 0x0001BC27 File Offset: 0x00019E27
		internal IEnumerable<ToolStripMenuItem> method_2(ToolStripMenuItem toolStripMenuItem_0)
		{
			return toolStripMenuItem_0.smethod_33();
		}

		// Token: 0x04001816 RID: 6166
		public static readonly GClass127.Class345 <>9 = new GClass127.Class345();

		// Token: 0x04001817 RID: 6167
		public static Func<Control, IEnumerable<Control>> <>9__38_0;

		// Token: 0x04001818 RID: 6168
		public static Func<ToolStripItem, bool> <>9__39_0;

		// Token: 0x04001819 RID: 6169
		public static Func<ToolStripMenuItem, IEnumerable<ToolStripMenuItem>> <>9__39_1;
	}
}
