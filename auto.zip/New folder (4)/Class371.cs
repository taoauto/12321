﻿using System;

// Token: 0x020002AD RID: 685
internal class Class371
{
	// Token: 0x17000845 RID: 2117
	// (get) Token: 0x06002668 RID: 9832 RVA: 0x0001CB3C File Offset: 0x0001AD3C
	public static string String_0
	{
		get
		{
			return "Nga Mi Sơn";
		}
	}

	// Token: 0x040019C4 RID: 6596
	public static int int_0 = 15;

	// Token: 0x040019C5 RID: 6597
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 146,
		Int32_1 = 54,
		Int32_2 = Class371.int_0,
		String_2 = "Tiêu Tương Ngọc"
	};

	// Token: 0x040019C6 RID: 6598
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 96,
		Int32_1 = 52,
		Int32_2 = Class371.int_0,
		String_2 = "Lý Thập Nhị Nương"
	};

	// Token: 0x040019C7 RID: 6599
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 7U,
		Int32_0 = 96,
		Int32_1 = 87,
		Int32_2 = Class371.int_0,
		String_2 = "Mãnh Long"
	};

	// Token: 0x040019C8 RID: 6600
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 98,
		Int32_1 = 52,
		Int32_2 = Class371.int_0,
		String_2 = "Thôi Lục Hoa"
	};
}
