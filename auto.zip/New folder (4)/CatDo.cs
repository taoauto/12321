﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001DA RID: 474
public class CatDo : UserControl
{
	// Token: 0x06001964 RID: 6500 RVA: 0x00012758 File Offset: 0x00010958
	public CatDo()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001965 RID: 6501 RVA: 0x000B612C File Offset: 0x000B432C
	private void CatDo_Load(object sender, EventArgs e)
	{
		this.txtDropName.Text = Class415.String_12;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(CatDo.Class216.<>9.method_0)).ToArray<ListViewItem>());
		this.checkBox1.Checked = Setting.smethod_0("checkChiCatCoDinh");
		this.tabPage2.Controls.Add(new CatDoThienCo
		{
			Dock = DockStyle.Fill
		});
	}

	// Token: 0x06001966 RID: 6502 RVA: 0x000B61C4 File Offset: 0x000B43C4
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtDropName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtDropName.Text = this.txtDropName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtDropName.method_1();
	}

	// Token: 0x06001967 RID: 6503 RVA: 0x00012766 File Offset: 0x00010966
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001968 RID: 6504 RVA: 0x00012766 File Offset: 0x00010966
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001969 RID: 6505 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x0600196A RID: 6506 RVA: 0x0001276E File Offset: 0x0001096E
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x0600196B RID: 6507 RVA: 0x000B62C4 File Offset: 0x000B44C4
	private void txtDropName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_12 = this.txtDropName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x0600196C RID: 6508 RVA: 0x00012787 File Offset: 0x00010987
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		Setting.Dictionary_2["checkChiCatCoDinh"] = this.checkBox1.Checked;
	}

	// Token: 0x0600196D RID: 6509 RVA: 0x000127A3 File Offset: 0x000109A3
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600196E RID: 6510 RVA: 0x000B632C File Offset: 0x000B452C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(CatDo));
		this.columnHeader_0 = new ColumnHeader();
		this.lvName = new ListViewEx();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtDropName = new Class85();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.checkBox1 = new CheckBox();
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.menuName.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		base.SuspendLayout();
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 200;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(238, 303);
		this.lvName.TabIndex = 15;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtDropName.Dock = DockStyle.Fill;
		this.txtDropName.Location = new Point(0, 0);
		this.txtDropName.Multiline = true;
		this.txtDropName.Name = "txtDropName";
		this.txtDropName.ScrollBars = ScrollBars.Vertical;
		this.txtDropName.Size = new Size(225, 340);
		this.txtDropName.TabIndex = 13;
		this.txtDropName.String_0 = "";
		this.txtDropName.Color_0 = Color.Gray;
		this.txtDropName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtDropName.Color_1 = Color.LightGray;
		this.txtDropName.TextChanged += this.txtDropName_TextChanged;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = DockStyle.Bottom;
		this.checkBox1.Location = new Point(0, 323);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new Size(238, 17);
		this.checkBox1.TabIndex = 0;
		this.checkBox1.Text = "Chỉ Cất Đồ Cố Định";
		this.toolTip_0.SetToolTip(this.checkBox1, "Chỉ Cất Đồ Cố Định");
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtDropName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.checkBox1);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(467, 340);
		this.splitContainer1.SplitterDistance = 225;
		this.splitContainer1.TabIndex = 0;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(238, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(481, 372);
		this.tabControlEx1.TabIndex = 20;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(473, 346);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Thương Khố";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(473, 324);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Thiên Cơ";
		this.tabPage2.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Name = "CatDo";
		base.Size = new Size(481, 372);
		base.Tag = "Cất Đồ - Bank Item";
		base.Load += this.CatDo_Load;
		this.menuName.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000EE0 RID: 3808
	private IContainer icontainer_0;

	// Token: 0x04000EE1 RID: 3809
	private ToolTip toolTip_0;

	// Token: 0x04000EE2 RID: 3810
	private ColumnHeader columnHeader_0;

	// Token: 0x04000EE3 RID: 3811
	private ListViewEx lvName;

	// Token: 0x04000EE4 RID: 3812
	private ContextMenuStrip menuName;

	// Token: 0x04000EE5 RID: 3813
	private ToolStripMenuItem menuAddName;

	// Token: 0x04000EE6 RID: 3814
	private Class85 txtDropName;

	// Token: 0x04000EE7 RID: 3815
	private SplitContainer splitContainer1;

	// Token: 0x04000EE8 RID: 3816
	private Class85 txtSearchName;

	// Token: 0x04000EE9 RID: 3817
	private CheckBox checkBox1;

	// Token: 0x04000EEA RID: 3818
	private Control1 tabControlEx1;

	// Token: 0x04000EEB RID: 3819
	private TabPage tabPage1;

	// Token: 0x04000EEC RID: 3820
	private TabPage tabPage2;

	// Token: 0x020001DB RID: 475
	[CompilerGenerated]
	[Serializable]
	private sealed class Class216
	{
		// Token: 0x06001971 RID: 6513 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000EED RID: 3821
		public static readonly CatDo.Class216 <>9 = new CatDo.Class216();

		// Token: 0x04000EEE RID: 3822
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
