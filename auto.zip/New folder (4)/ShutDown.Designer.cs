﻿// Token: 0x020002F6 RID: 758
internal partial class ShutDown : global::System.Windows.Forms.Form
{
	// Token: 0x06002B9E RID: 11166 RVA: 0x001261DC File Offset: 0x001243DC
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.lblExitTime = new global::System.Windows.Forms.Label();
		this.lblClose = new global::System.Windows.Forms.Label();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.lblExitTime.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.lblExitTime.BackColor = global::System.Drawing.Color.White;
		this.lblExitTime.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lblExitTime.ForeColor = global::System.Drawing.Color.Green;
		this.lblExitTime.Location = new global::System.Drawing.Point(-1, 0);
		this.lblExitTime.Name = "lblExitTime";
		this.lblExitTime.Size = new global::System.Drawing.Size(130, 36);
		this.lblExitTime.TabIndex = 1;
		this.lblExitTime.Text = "Tắt máy sau 5:00";
		this.lblExitTime.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.lblClose.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.lblClose.BackColor = global::System.Drawing.Color.Silver;
		this.lblClose.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.lblClose.Location = new global::System.Drawing.Point(117, 36);
		this.lblClose.Name = "lblClose";
		this.lblClose.Size = new global::System.Drawing.Size(12, 12);
		this.lblClose.TabIndex = 1;
		this.lblClose.Text = "  ";
		this.lblClose.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.lblClose.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.lblClose_MouseClick);
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.Red;
		base.ClientSize = new global::System.Drawing.Size(129, 48);
		base.Controls.Add(this.lblExitTime);
		base.Controls.Add(this.lblClose);
		base.Name = "ShutDown";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "ShutDown";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.ShutDown_Load);
		base.ResumeLayout(false);
	}

	// Token: 0x04001D07 RID: 7431
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04001D08 RID: 7432
	private global::System.Windows.Forms.Label lblExitTime;

	// Token: 0x04001D09 RID: 7433
	private global::System.Windows.Forms.Label lblClose;

	// Token: 0x04001D0A RID: 7434
	private global::System.Windows.Forms.Timer timer_0;
}
