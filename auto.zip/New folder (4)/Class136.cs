﻿using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

// Token: 0x02000159 RID: 345
internal class Class136 : Class134, Interface5
{
	// Token: 0x0600105E RID: 4190 RVA: 0x0000D546 File Offset: 0x0000B746
	static Class136()
	{
		ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Class136.smethod_0);
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_0(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x0005B0AC File Offset: 0x000592AC
	private void method_2(HttpWebRequest httpWebRequest_0, Class141 class141_0)
	{
		if (class141_0.Boolean_0)
		{
			string text = class141_0.String_1;
			string domain = string.Empty;
			int num = text.IndexOf('\\');
			if (num >= 0)
			{
				domain = text.Substring(0, num);
				text = text.Substring(num + 1);
			}
			httpWebRequest_0.Credentials = new NetworkCredential(text, class141_0.String_2)
			{
				Domain = domain
			};
		}
	}

	// Token: 0x06001061 RID: 4193 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void imethod_0(Class130 class130_0)
	{
	}

	// Token: 0x06001062 RID: 4194 RVA: 0x0005B2E8 File Offset: 0x000594E8
	public virtual Stream imethod_1(Class141 class141_0, long long_0, long long_1)
	{
		HttpWebRequest httpWebRequest = (HttpWebRequest)base.method_0(class141_0);
		this.method_2(httpWebRequest, class141_0);
		if (long_0 != 0L)
		{
			if (long_1 == 0L)
			{
				httpWebRequest.AddRange((int)long_0);
			}
			else
			{
				httpWebRequest.AddRange((int)long_0, (int)long_1);
			}
		}
		return httpWebRequest.GetResponse().GetResponseStream();
	}

	// Token: 0x06001063 RID: 4195 RVA: 0x0005B330 File Offset: 0x00059530
	public virtual Class140 imethod_2(Class141 class141_0, out Stream stream_0)
	{
		HttpWebRequest httpWebRequest = (HttpWebRequest)base.method_0(class141_0);
		this.method_2(httpWebRequest, class141_0);
		HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
		Class140 @class = new Class140();
		@class.String_0 = httpWebResponse.ContentType;
		@class.DateTime_0 = httpWebResponse.LastModified;
		@class.Int64_0 = httpWebResponse.ContentLength;
		@class.Boolean_0 = (string.Compare(httpWebResponse.Headers["Accept-Ranges"], "bytes", true) == 0);
		stream_0 = httpWebResponse.GetResponseStream();
		return @class;
	}
}
