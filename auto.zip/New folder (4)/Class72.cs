﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000091 RID: 145
internal class Class72 : IAsyncResult
{
	// Token: 0x060006C8 RID: 1736 RVA: 0x00007606 File Offset: 0x00005806
	internal Class72(AsyncCallback asyncCallback_1, object object_2)
	{
		this.asyncCallback_0 = asyncCallback_1;
		this.object_0 = object_2;
		this.object_1 = new object();
	}

	// Token: 0x170001C7 RID: 455
	// (get) Token: 0x060006C9 RID: 1737 RVA: 0x00007627 File Offset: 0x00005827
	// (set) Token: 0x060006CA RID: 1738 RVA: 0x0000762F File Offset: 0x0000582F
	internal bool Boolean_0
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
		}
	}

	// Token: 0x170001C8 RID: 456
	// (get) Token: 0x060006CB RID: 1739 RVA: 0x00007638 File Offset: 0x00005838
	// (set) Token: 0x060006CC RID: 1740 RVA: 0x00007640 File Offset: 0x00005840
	internal bool Boolean_1
	{
		get
		{
			return this.bool_2;
		}
		set
		{
			this.bool_2 = value;
		}
	}

	// Token: 0x170001C9 RID: 457
	// (get) Token: 0x060006CD RID: 1741 RVA: 0x00007649 File Offset: 0x00005849
	public object AsyncState
	{
		get
		{
			return this.object_0;
		}
	}

	// Token: 0x170001CA RID: 458
	// (get) Token: 0x060006CE RID: 1742 RVA: 0x00037354 File Offset: 0x00035554
	public WaitHandle AsyncWaitHandle
	{
		get
		{
			object obj = this.object_1;
			WaitHandle result;
			lock (obj)
			{
				ManualResetEvent manualResetEvent;
				if ((manualResetEvent = this.manualResetEvent_0) == null)
				{
					manualResetEvent = (this.manualResetEvent_0 = new ManualResetEvent(this.bool_0));
				}
				result = manualResetEvent;
			}
			return result;
		}
	}

	// Token: 0x170001CB RID: 459
	// (get) Token: 0x060006CF RID: 1743 RVA: 0x00007651 File Offset: 0x00005851
	public bool CompletedSynchronously
	{
		get
		{
			return this.bool_3;
		}
	}

	// Token: 0x170001CC RID: 460
	// (get) Token: 0x060006D0 RID: 1744 RVA: 0x000373B0 File Offset: 0x000355B0
	public bool IsCompleted
	{
		get
		{
			object obj = this.object_1;
			bool result;
			lock (obj)
			{
				result = this.bool_0;
			}
			return result;
		}
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x000373F4 File Offset: 0x000355F4
	private static void smethod_0(Class72 class72_0)
	{
		Class72.Class73 @class = new Class72.Class73();
		@class.class72_0 = class72_0;
		object obj = @class.class72_0.object_1;
		lock (obj)
		{
			@class.class72_0.bool_0 = true;
			ManualResetEvent manualResetEvent = @class.class72_0.manualResetEvent_0;
			if (manualResetEvent != null)
			{
				manualResetEvent.Set();
			}
		}
		@class.asyncCallback_0 = @class.class72_0.asyncCallback_0;
		if (@class.asyncCallback_0 == null)
		{
			return;
		}
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0), null);
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x00007659 File Offset: 0x00005859
	internal void method_0(Exception exception_1)
	{
		this.exception_0 = ((!this.bool_2 || !(exception_1 is ObjectDisposedException)) ? exception_1 : new GException5(995, "The listener is closed."));
		Class72.smethod_0(this);
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x00007689 File Offset: 0x00005889
	internal void method_1(GClass38 gclass38_1)
	{
		this.method_2(gclass38_1, false);
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00007693 File Offset: 0x00005893
	internal void method_2(GClass38 gclass38_1, bool bool_4)
	{
		this.gclass38_0 = gclass38_1;
		this.bool_3 = bool_4;
		Class72.smethod_0(this);
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x000076A9 File Offset: 0x000058A9
	internal GClass38 method_3()
	{
		if (this.exception_0 != null)
		{
			throw this.exception_0;
		}
		return this.gclass38_0;
	}

	// Token: 0x0400034A RID: 842
	private AsyncCallback asyncCallback_0;

	// Token: 0x0400034B RID: 843
	private bool bool_0;

	// Token: 0x0400034C RID: 844
	private GClass38 gclass38_0;

	// Token: 0x0400034D RID: 845
	private bool bool_1;

	// Token: 0x0400034E RID: 846
	private Exception exception_0;

	// Token: 0x0400034F RID: 847
	private bool bool_2;

	// Token: 0x04000350 RID: 848
	private object object_0;

	// Token: 0x04000351 RID: 849
	private object object_1;

	// Token: 0x04000352 RID: 850
	private bool bool_3;

	// Token: 0x04000353 RID: 851
	private ManualResetEvent manualResetEvent_0;

	// Token: 0x02000092 RID: 146
	[CompilerGenerated]
	private sealed class Class73
	{
		// Token: 0x060006D7 RID: 1751 RVA: 0x00037490 File Offset: 0x00035690
		internal void method_0(object object_0)
		{
			try
			{
				this.asyncCallback_0(this.class72_0);
			}
			catch
			{
			}
		}

		// Token: 0x04000354 RID: 852
		public AsyncCallback asyncCallback_0;

		// Token: 0x04000355 RID: 853
		public Class72 class72_0;
	}
}
