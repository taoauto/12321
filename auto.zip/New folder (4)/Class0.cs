﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000004 RID: 4
internal class Class0
{
	// Token: 0x06000006 RID: 6
	[DllImport("Kernel32.dll")]
	private static extern IntPtr LoadLibrary(string string_0);

	// Token: 0x06000007 RID: 7
	[DllImport("Kernel32.dll")]
	private static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

	// Token: 0x06000008 RID: 8 RVA: 0x00002E53 File Offset: 0x00001053
	public static Delegate smethod_0<T>(string string_0, string string_1)
	{
		return Marshal.GetDelegateForFunctionPointer(Class0.GetProcAddress(Class0.LoadLibrary(string_0), string_1), typeof(T));
	}
}
