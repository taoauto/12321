﻿using System;
using System.Net;

// Token: 0x02000154 RID: 340
internal class Class134
{
	// Token: 0x0600103F RID: 4159 RVA: 0x0000D49E File Offset: 0x0000B69E
	static Class134()
	{
		ServicePointManager.DefaultConnectionLimit = int.MaxValue;
	}

	// Token: 0x06001040 RID: 4160 RVA: 0x0005AFF4 File Offset: 0x000591F4
	protected WebRequest method_0(Class141 class141_0)
	{
		WebRequest webRequest = WebRequest.Create(class141_0.String_0);
		webRequest.Timeout = 30000;
		this.method_1(webRequest);
		return webRequest;
	}

	// Token: 0x06001041 RID: 4161 RVA: 0x0005B020 File Offset: 0x00059220
	protected void method_1(WebRequest webRequest_0)
	{
		if (Class137.interface7_0.Boolean_0)
		{
			webRequest_0.Proxy = new WebProxy(Class137.interface7_0.String_0, Class137.interface7_0.Int32_0)
			{
				BypassProxyOnLocal = Class137.interface7_0.Boolean_1
			};
			if (!string.IsNullOrEmpty(Class137.interface7_0.String_1))
			{
				webRequest_0.Proxy.Credentials = new NetworkCredential(Class137.interface7_0.String_1, Class137.interface7_0.String_2, Class137.interface7_0.String_3);
			}
		}
	}
}
