﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// Token: 0x02000104 RID: 260
public partial class HotkeysEditorForm : Form
{
	// Token: 0x06000D58 RID: 3416 RVA: 0x0000B980 File Offset: 0x00009B80
	public HotkeysEditorForm(GClass79 gclass79_0)
	{
		this.InitializeComponent();
		this.method_1(gclass79_0);
		this.dgv.DataSource = this.bindingList_0;
	}

	// Token: 0x06000D59 RID: 3417 RVA: 0x0004F954 File Offset: 0x0004DB54
	private int method_0(Keys keys_0, Keys keys_1)
	{
		int num = ((int)(keys_0 & (Keys)255)).CompareTo((int)(keys_1 & (Keys)255));
		if (num == 0)
		{
			num = keys_0.CompareTo(keys_1);
		}
		return num;
	}

	// Token: 0x06000D5A RID: 3418 RVA: 0x0004F990 File Offset: 0x0004DB90
	private void method_1(GClass79 gclass79_0)
	{
		List<Keys> list = new List<Keys>(gclass79_0.Keys);
		list.Sort(new Comparison<Keys>(this.method_0));
		this.bindingList_0.Clear();
		foreach (Keys keys in list)
		{
			this.bindingList_0.Add(new Class105(keys, gclass79_0[keys]));
		}
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x0004FA18 File Offset: 0x0004DC18
	public GClass79 method_2()
	{
		GClass79 gclass = new GClass79();
		foreach (Class105 @class in this.bindingList_0)
		{
			gclass[@class.method_0()] = @class.FCTBAction_0;
		}
		return gclass;
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x0000B9B1 File Offset: 0x00009BB1
	private void btAdd_Click(object sender, EventArgs e)
	{
		this.bindingList_0.Add(new Class105(Keys.None, FCTBAction.None));
	}

	// Token: 0x06000D5D RID: 3421 RVA: 0x0004FA78 File Offset: 0x0004DC78
	private void dgv_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
	{
		DataGridViewComboBoxCell dataGridViewComboBoxCell = this.dgv[0, e.RowIndex] as DataGridViewComboBoxCell;
		if (dataGridViewComboBoxCell.Items.Count == 0)
		{
			foreach (string item in new string[]
			{
				"",
				"Ctrl",
				"Ctrl + Shift",
				"Ctrl + Alt",
				"Shift",
				"Shift + Alt",
				"Alt",
				"Ctrl + Shift + Alt"
			})
			{
				dataGridViewComboBoxCell.Items.Add(item);
			}
		}
		dataGridViewComboBoxCell = (this.dgv[1, e.RowIndex] as DataGridViewComboBoxCell);
		if (dataGridViewComboBoxCell.Items.Count == 0)
		{
			foreach (object item2 in Enum.GetValues(typeof(Keys)))
			{
				dataGridViewComboBoxCell.Items.Add(item2);
			}
		}
		dataGridViewComboBoxCell = (this.dgv[2, e.RowIndex] as DataGridViewComboBoxCell);
		if (dataGridViewComboBoxCell.Items.Count == 0)
		{
			foreach (object item3 in Enum.GetValues(typeof(FCTBAction)))
			{
				dataGridViewComboBoxCell.Items.Add(item3);
			}
		}
	}

	// Token: 0x06000D5E RID: 3422 RVA: 0x0004FC18 File Offset: 0x0004DE18
	private void btResore_Click(object sender, EventArgs e)
	{
		GClass79 gclass = new GClass79();
		gclass.vmethod_0();
		this.method_1(gclass);
	}

	// Token: 0x06000D5F RID: 3423 RVA: 0x0004FC38 File Offset: 0x0004DE38
	private void btRemove_Click(object sender, EventArgs e)
	{
		for (int i = this.dgv.RowCount - 1; i >= 0; i--)
		{
			if (this.dgv.Rows[i].Selected)
			{
				this.dgv.Rows.RemoveAt(i);
			}
		}
	}

	// Token: 0x06000D60 RID: 3424 RVA: 0x0004FC88 File Offset: 0x0004DE88
	private void HotkeysEditorForm_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (base.DialogResult == DialogResult.OK)
		{
			string text = this.method_3();
			if (!string.IsNullOrEmpty(text) && MessageBox.Show("Some actions are not assigned!\r\nActions: " + text + "\r\nPress Yes to save and exit, press No to continue editing", "Some actions is not assigned", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
			{
				e.Cancel = true;
			}
		}
	}

	// Token: 0x06000D61 RID: 3425 RVA: 0x0004FCD4 File Offset: 0x0004DED4
	private string method_3()
	{
		StringBuilder stringBuilder = new StringBuilder();
		Dictionary<FCTBAction, FCTBAction> dictionary = new Dictionary<FCTBAction, FCTBAction>();
		foreach (Class105 @class in this.bindingList_0)
		{
			dictionary[@class.FCTBAction_0] = @class.FCTBAction_0;
		}
		foreach (object obj in Enum.GetValues(typeof(FCTBAction)))
		{
			if ((FCTBAction)obj != FCTBAction.None && !((FCTBAction)obj).ToString().StartsWith("CustomAction") && !dictionary.ContainsKey((FCTBAction)obj))
			{
				stringBuilder.Append(((obj != null) ? obj.ToString() : null) + ", ");
			}
		}
		return stringBuilder.ToString().TrimEnd(new char[]
		{
			' ',
			','
		});
	}

	// Token: 0x06000D62 RID: 3426 RVA: 0x0000B9C5 File Offset: 0x00009BC5
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000690 RID: 1680
	private BindingList<Class105> bindingList_0 = new BindingList<Class105>();

	// Token: 0x04000691 RID: 1681
	private IContainer icontainer_0;
}
