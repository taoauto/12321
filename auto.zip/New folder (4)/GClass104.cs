﻿using System;
using System.Drawing;

// Token: 0x02000138 RID: 312
public class GClass104 : GClass101
{
	// Token: 0x06000F99 RID: 3993 RVA: 0x0000CED1 File Offset: 0x0000B0D1
	public GClass104(int int_1, Rectangle rectangle_1) : base(rectangle_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000F9A RID: 3994 RVA: 0x0000CEE1 File Offset: 0x0000B0E1
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Pen pen_0)
	{
		graphics_0.DrawRectangle(pen_0, this.rectangle_0);
	}

	// Token: 0x04000807 RID: 2055
	public readonly int int_0;
}
