﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using WebSocketSharp;

// Token: 0x0200003B RID: 59
public static class GClass22
{
	// Token: 0x0600026B RID: 619 RVA: 0x00027AB8 File Offset: 0x00025CB8
	private static byte[] smethod_0(this byte[] byte_1)
	{
		if ((long)byte_1.Length == 0L)
		{
			return byte_1;
		}
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream(byte_1))
		{
			result = memoryStream.smethod_2();
		}
		return result;
	}

	// Token: 0x0600026C RID: 620 RVA: 0x00027AF8 File Offset: 0x00025CF8
	private static MemoryStream smethod_1(this Stream stream_0)
	{
		MemoryStream memoryStream = new MemoryStream();
		if (stream_0.Length == 0L)
		{
			return memoryStream;
		}
		stream_0.Position = 0L;
		MemoryStream result;
		using (DeflateStream deflateStream = new DeflateStream(memoryStream, CompressionMode.Compress, true))
		{
			stream_0.CopyTo(deflateStream, 1024);
			deflateStream.Close();
			memoryStream.Write(GClass22.byte_0, 0, 1);
			memoryStream.Position = 0L;
			result = memoryStream;
		}
		return result;
	}

	// Token: 0x0600026D RID: 621 RVA: 0x00027B6C File Offset: 0x00025D6C
	private static byte[] smethod_2(this Stream stream_0)
	{
		byte[] result;
		using (MemoryStream memoryStream = stream_0.smethod_1())
		{
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x0600026E RID: 622 RVA: 0x00027BAC File Offset: 0x00025DAC
	private static byte[] smethod_3(this byte[] byte_1)
	{
		if ((long)byte_1.Length == 0L)
		{
			return byte_1;
		}
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream(byte_1))
		{
			result = memoryStream.smethod_5();
		}
		return result;
	}

	// Token: 0x0600026F RID: 623 RVA: 0x00027BEC File Offset: 0x00025DEC
	private static MemoryStream smethod_4(this Stream stream_0)
	{
		MemoryStream memoryStream = new MemoryStream();
		if (stream_0.Length == 0L)
		{
			return memoryStream;
		}
		stream_0.Position = 0L;
		MemoryStream result;
		using (DeflateStream deflateStream = new DeflateStream(stream_0, CompressionMode.Decompress, true))
		{
			deflateStream.CopyTo(memoryStream, 1024);
			memoryStream.Position = 0L;
			result = memoryStream;
		}
		return result;
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00027C50 File Offset: 0x00025E50
	private static byte[] smethod_5(this Stream stream_0)
	{
		byte[] result;
		using (MemoryStream memoryStream = stream_0.smethod_4())
		{
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x06000271 RID: 625 RVA: 0x00027C90 File Offset: 0x00025E90
	private static bool smethod_6(this string string_1)
	{
		return string_1 == "GET" || string_1 == "HEAD" || string_1 == "POST" || string_1 == "PUT" || string_1 == "DELETE" || string_1 == "CONNECT" || string_1 == "OPTIONS" || string_1 == "TRACE";
	}

	// Token: 0x06000272 RID: 626 RVA: 0x000049CB File Offset: 0x00002BCB
	private static bool smethod_7(this string string_1)
	{
		return string_1 == "GET" || string_1 == "HEAD" || string_1 == "POST";
	}

	// Token: 0x06000273 RID: 627 RVA: 0x00027D08 File Offset: 0x00025F08
	internal static byte[] smethod_8(this ushort ushort_0, string string_1)
	{
		byte[] array = ushort_0.smethod_38(GEnum5.Big);
		if (string_1 != null && string_1.Length != 0)
		{
			List<byte> list = new List<byte>(array);
			list.AddRange(Encoding.UTF8.GetBytes(string_1));
			return list.ToArray();
		}
		return array;
	}

	// Token: 0x06000274 RID: 628 RVA: 0x000049F4 File Offset: 0x00002BF4
	internal static void smethod_9(this GClass41 gclass41_0, GEnum9 genum9_0)
	{
		gclass41_0.Int32_0 = (int)genum9_0;
		gclass41_0.Stream_0.Close();
	}

	// Token: 0x06000275 RID: 629 RVA: 0x00004A08 File Offset: 0x00002C08
	internal static void smethod_10(this GClass41 gclass41_0, string string_1)
	{
		gclass41_0.GClass45_1.method_6("WWW-Authenticate", string_1, true);
		gclass41_0.smethod_9(GEnum9.Unauthorized);
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00004A27 File Offset: 0x00002C27
	internal static byte[] smethod_11(this byte[] byte_1, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return byte_1;
		}
		return byte_1.smethod_0();
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00004A35 File Offset: 0x00002C35
	internal static Stream smethod_12(this Stream stream_0, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return stream_0;
		}
		return stream_0.smethod_1();
	}

	// Token: 0x06000278 RID: 632 RVA: 0x00004A43 File Offset: 0x00002C43
	internal static byte[] smethod_13(this Stream stream_0, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return stream_0.smethod_60();
		}
		return stream_0.smethod_2();
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00004A56 File Offset: 0x00002C56
	internal static bool smethod_14(this string string_1, params char[] char_0)
	{
		return char_0 != null && char_0.Length != 0 && string_1.IndexOfAny(char_0) > -1;
	}

	// Token: 0x0600027A RID: 634 RVA: 0x00004A6B File Offset: 0x00002C6B
	internal static bool smethod_15(this NameValueCollection nameValueCollection_0, string string_1)
	{
		return nameValueCollection_0[string_1] != null;
	}

	// Token: 0x0600027B RID: 635 RVA: 0x00027D48 File Offset: 0x00025F48
	internal static bool smethod_16(this NameValueCollection nameValueCollection_0, string string_1, string string_2, StringComparison stringComparison_0)
	{
		string text = nameValueCollection_0[string_1];
		if (text == null)
		{
			return false;
		}
		string[] array = text.Split(new char[]
		{
			','
		});
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].Trim().Equals(string_2, stringComparison_0))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00027D98 File Offset: 0x00025F98
	internal static bool smethod_17<T>(this IEnumerable<T> ienumerable_0, Func<T, bool> func_0)
	{
		foreach (T arg in ienumerable_0)
		{
			if (func_0(arg))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x0600027D RID: 637 RVA: 0x00027DEC File Offset: 0x00025FEC
	internal static bool smethod_18(this string[] string_1)
	{
		GClass22.Class17 @class = new GClass22.Class17();
		@class.string_0 = string_1;
		@class.int_1 = @class.string_0.Length;
		@class.int_1--;
		@class.func_0 = null;
		@class.func_0 = new Func<int, bool>(@class.method_0);
		return @class.func_0(0);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x00027E48 File Offset: 0x00026048
	internal static T[] smethod_19<T>(this T[] gparam_0, int int_1)
	{
		T[] array = new T[int_1];
		Array.Copy(gparam_0, 0, array, 0, int_1);
		return array;
	}

	// Token: 0x0600027F RID: 639 RVA: 0x00027E68 File Offset: 0x00026068
	internal static T[] smethod_20<T>(this T[] gparam_0, long long_0)
	{
		T[] array = new T[long_0];
		Array.Copy(gparam_0, 0L, array, 0L, long_0);
		return array;
	}

	// Token: 0x06000280 RID: 640 RVA: 0x00027E8C File Offset: 0x0002608C
	internal static void smethod_21(this Stream stream_0, Stream stream_1, int int_1)
	{
		byte[] buffer = new byte[int_1];
		for (;;)
		{
			int num = stream_0.Read(buffer, 0, int_1);
			if (num <= 0)
			{
				break;
			}
			stream_1.Write(buffer, 0, num);
		}
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00027EBC File Offset: 0x000260BC
	internal static void smethod_22(this Stream stream_0, Stream stream_1, int int_1, Action action_0, Action<Exception> action_1)
	{
		GClass22.Class18 @class = new GClass22.Class18();
		@class.stream_0 = stream_0;
		@class.action_0 = action_0;
		@class.stream_1 = stream_1;
		@class.int_0 = int_1;
		@class.action_1 = action_1;
		@class.byte_0 = new byte[@class.int_0];
		@class.asyncCallback_0 = null;
		@class.asyncCallback_0 = new AsyncCallback(@class.method_0);
		try
		{
			@class.stream_0.BeginRead(@class.byte_0, 0, @class.int_0, @class.asyncCallback_0, null);
		}
		catch (Exception obj)
		{
			if (@class.action_1 != null)
			{
				@class.action_1(obj);
			}
		}
	}

	// Token: 0x06000282 RID: 642 RVA: 0x00004A77 File Offset: 0x00002C77
	internal static byte[] smethod_23(this byte[] byte_1, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return byte_1;
		}
		return byte_1.smethod_3();
	}

	// Token: 0x06000283 RID: 643 RVA: 0x00004A85 File Offset: 0x00002C85
	internal static Stream smethod_24(this Stream stream_0, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return stream_0;
		}
		return stream_0.smethod_4();
	}

	// Token: 0x06000284 RID: 644 RVA: 0x00004A93 File Offset: 0x00002C93
	internal static byte[] smethod_25(this Stream stream_0, CompressionMethod compressionMethod_0)
	{
		if (compressionMethod_0 != CompressionMethod.Deflate)
		{
			return stream_0.smethod_60();
		}
		return stream_0.smethod_5();
	}

	// Token: 0x06000285 RID: 645 RVA: 0x00004AA6 File Offset: 0x00002CA6
	internal static void smethod_26(this EventHandler eventHandler_0, object object_0, EventArgs eventArgs_0)
	{
		if (eventHandler_0 == null)
		{
			return;
		}
		eventHandler_0(object_0, eventArgs_0);
	}

	// Token: 0x06000286 RID: 646 RVA: 0x00004AB4 File Offset: 0x00002CB4
	internal static void smethod_27<T>(this EventHandler<T> eventHandler_0, object object_0, T gparam_0) where T : EventArgs
	{
		if (eventHandler_0 == null)
		{
			return;
		}
		eventHandler_0(object_0, gparam_0);
	}

	// Token: 0x06000287 RID: 647 RVA: 0x00004AC2 File Offset: 0x00002CC2
	internal static bool smethod_28(this int int_1, char char_0, Action<int> action_0)
	{
		action_0(int_1);
		return int_1 == (int)char_0;
	}

	// Token: 0x06000288 RID: 648 RVA: 0x00027F68 File Offset: 0x00026168
	internal static string smethod_29(this Uri uri_0)
	{
		if (uri_0.IsAbsoluteUri)
		{
			return uri_0.AbsolutePath;
		}
		string originalString = uri_0.OriginalString;
		if (originalString[0] != '/')
		{
			return null;
		}
		int num = originalString.IndexOfAny(new char[]
		{
			'?',
			'#'
		});
		if (num <= 0)
		{
			return originalString;
		}
		return originalString.Substring(0, num);
	}

	// Token: 0x06000289 RID: 649 RVA: 0x00027FC0 File Offset: 0x000261C0
	internal static GClass34 smethod_30(this NameValueCollection nameValueCollection_0, bool bool_0)
	{
		string text = nameValueCollection_0[bool_0 ? "Set-Cookie" : "Cookie"];
		if (text == null)
		{
			return new GClass34();
		}
		return GClass34.smethod_5(text, bool_0);
	}

	// Token: 0x0600028A RID: 650 RVA: 0x00004ACF File Offset: 0x00002CCF
	internal static string smethod_31(this Uri uri_0, bool bool_0)
	{
		if (bool_0)
		{
			if (uri_0.HostNameType == UriHostNameType.IPv6)
			{
				return uri_0.Host;
			}
		}
		return uri_0.DnsSafeHost;
	}

	// Token: 0x0600028B RID: 651 RVA: 0x00027FF4 File Offset: 0x000261F4
	internal static string smethod_32(this GEnum6 genum6_0)
	{
		if (genum6_0 == GEnum6.ProtocolError)
		{
			return "A WebSocket protocol error has occurred.";
		}
		if (genum6_0 == GEnum6.UnsupportedData)
		{
			return "Unsupported data has been received.";
		}
		if (genum6_0 == GEnum6.Abnormal)
		{
			return "An exception has occurred.";
		}
		if (genum6_0 == GEnum6.InvalidData)
		{
			return "Invalid data has been received.";
		}
		if (genum6_0 == GEnum6.PolicyViolation)
		{
			return "A policy violation has occurred.";
		}
		if (genum6_0 == GEnum6.TooBig)
		{
			return "A too big message has been received.";
		}
		if (genum6_0 == GEnum6.MandatoryExtension)
		{
			return "WebSocket client didn't receive expected extension(s).";
		}
		if (genum6_0 == GEnum6.ServerError)
		{
			return "WebSocket server got an internal error.";
		}
		if (genum6_0 != GEnum6.TlsHandshakeFailure)
		{
			return string.Empty;
		}
		return "An error has occurred during a TLS handshake.";
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00028084 File Offset: 0x00026284
	internal static string smethod_33(this string string_1, char char_0)
	{
		int num = string_1.IndexOf(char_0);
		if (num <= 0)
		{
			return null;
		}
		return string_1.Substring(0, num).Trim();
	}

	// Token: 0x0600028D RID: 653 RVA: 0x00004AEC File Offset: 0x00002CEC
	internal static string smethod_34(this byte[] byte_1)
	{
		return Encoding.UTF8.GetString(byte_1);
	}

	// Token: 0x0600028E RID: 654 RVA: 0x00004AF9 File Offset: 0x00002CF9
	internal static byte[] smethod_35(this string string_1)
	{
		return Encoding.UTF8.GetBytes(string_1);
	}

	// Token: 0x0600028F RID: 655 RVA: 0x00004B06 File Offset: 0x00002D06
	internal static string smethod_36(this string string_1, char char_0)
	{
		return string_1.smethod_37(char_0, false);
	}

	// Token: 0x06000290 RID: 656 RVA: 0x000280AC File Offset: 0x000262AC
	internal static string smethod_37(this string string_1, char char_0, bool bool_0)
	{
		int num = string_1.IndexOf(char_0);
		if (num >= 0)
		{
			if (num != string_1.Length - 1)
			{
				string text = string_1.Substring(num + 1).Trim();
				if (!bool_0)
				{
					return text;
				}
				return text.smethod_76();
			}
		}
		return null;
	}

	// Token: 0x06000291 RID: 657 RVA: 0x000280F0 File Offset: 0x000262F0
	internal static byte[] smethod_38(this ushort ushort_0, GEnum5 genum5_0)
	{
		byte[] bytes = BitConverter.GetBytes(ushort_0);
		if (!genum5_0.smethod_86())
		{
			Array.Reverse(bytes);
		}
		return bytes;
	}

	// Token: 0x06000292 RID: 658 RVA: 0x00028114 File Offset: 0x00026314
	internal static byte[] smethod_39(this ulong ulong_0, GEnum5 genum5_0)
	{
		byte[] bytes = BitConverter.GetBytes(ulong_0);
		if (!genum5_0.smethod_86())
		{
			Array.Reverse(bytes);
		}
		return bytes;
	}

	// Token: 0x06000293 RID: 659 RVA: 0x00004B10 File Offset: 0x00002D10
	internal static bool smethod_40(this string string_1, CompressionMethod compressionMethod_0)
	{
		return string_1.StartsWith(compressionMethod_0.smethod_62(new string[0]));
	}

	// Token: 0x06000294 RID: 660 RVA: 0x00004B24 File Offset: 0x00002D24
	internal static bool smethod_41(this byte byte_1)
	{
		return byte_1 > 7 && byte_1 < 16;
	}

	// Token: 0x06000295 RID: 661 RVA: 0x00004B31 File Offset: 0x00002D31
	internal static bool smethod_42(this Enum3 enum3_0)
	{
		return enum3_0 >= Enum3.Close;
	}

	// Token: 0x06000296 RID: 662 RVA: 0x00004B3A File Offset: 0x00002D3A
	internal static bool smethod_43(this byte byte_1)
	{
		return byte_1 == 1 || byte_1 == 2;
	}

	// Token: 0x06000297 RID: 663 RVA: 0x00004B3A File Offset: 0x00002D3A
	internal static bool smethod_44(this Enum3 enum3_0)
	{
		return enum3_0 == Enum3.Text || enum3_0 == Enum3.Binary;
	}

	// Token: 0x06000298 RID: 664 RVA: 0x00004B46 File Offset: 0x00002D46
	internal static bool smethod_45(this string string_1, Version version_0)
	{
		if (!(version_0 == GClass42.version_0))
		{
			return string_1.smethod_6();
		}
		return string_1.smethod_7();
	}

	// Token: 0x06000299 RID: 665 RVA: 0x00004B62 File Offset: 0x00002D62
	internal static bool smethod_46(this int int_1)
	{
		return int_1 > 0 && int_1 < 65536;
	}

	// Token: 0x0600029A RID: 666 RVA: 0x00004B72 File Offset: 0x00002D72
	internal static bool smethod_47(this ushort ushort_0)
	{
		return ushort_0 == 1004 || ushort_0 == 1005 || ushort_0 == 1006 || ushort_0 == 1015;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x00004B72 File Offset: 0x00002D72
	internal static bool smethod_48(this GEnum6 genum6_0)
	{
		return genum6_0 == GEnum6.Undefined || genum6_0 == GEnum6.NoStatus || genum6_0 == GEnum6.Abnormal || genum6_0 == GEnum6.TlsHandshakeFailure;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x00004B96 File Offset: 0x00002D96
	internal static bool smethod_49(this byte byte_1)
	{
		return Enum.IsDefined(typeof(Enum3), byte_1);
	}

	// Token: 0x0600029D RID: 669 RVA: 0x00028138 File Offset: 0x00026338
	internal static bool smethod_50(this string string_1)
	{
		int length = string_1.Length;
		for (int i = 0; i < length; i++)
		{
			char c = string_1[i];
			if (c < ' ')
			{
				if ("\r\n\t".IndexOf(c) == -1)
				{
					return false;
				}
				if (c == '\n')
				{
					i++;
					if (i == length)
					{
						return true;
					}
					c = string_1[i];
					if (" \t".IndexOf(c) == -1)
					{
						return false;
					}
				}
			}
			else if (c == '\u007f')
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x0600029E RID: 670 RVA: 0x000281AC File Offset: 0x000263AC
	internal static bool smethod_51(this string string_1)
	{
		foreach (char c in string_1)
		{
			if (c < ' ')
			{
				return false;
			}
			if (c > '~')
			{
				return false;
			}
			if ("()<>@,;:\\\"/[]?={} \t".IndexOf(c) > -1)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x0600029F RID: 671 RVA: 0x000281F4 File Offset: 0x000263F4
	internal static bool smethod_52(this NameValueCollection nameValueCollection_0, Version version_0)
	{
		StringComparison stringComparison_ = StringComparison.OrdinalIgnoreCase;
		if (!(version_0 < GClass42.version_1))
		{
			return !nameValueCollection_0.smethod_16("Connection", "close", stringComparison_);
		}
		return nameValueCollection_0.smethod_16("Connection", "keep-alive", stringComparison_);
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x00004BAD File Offset: 0x00002DAD
	internal static string smethod_53(this string string_1)
	{
		return string.Format("\"{0}\"", string_1.Replace("\"", "\\\""));
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x00028238 File Offset: 0x00026438
	internal static byte[] smethod_54(this Stream stream_0, int int_1)
	{
		byte[] array = new byte[int_1];
		int num = 0;
		int num2 = 0;
		while (int_1 > 0)
		{
			int num3 = stream_0.Read(array, num, int_1);
			if (num3 <= 0)
			{
				if (num2 >= GClass22.int_0)
				{
					return array.smethod_91(0, num);
				}
				num2++;
			}
			else
			{
				num2 = 0;
				num += num3;
				int_1 -= num3;
			}
		}
		return array;
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x0002828C File Offset: 0x0002648C
	internal static byte[] smethod_55(this Stream stream_0, long long_0, int int_1)
	{
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			byte[] buffer = new byte[int_1];
			int num = 0;
			while (long_0 > 0L)
			{
				if (long_0 < (long)int_1)
				{
					int_1 = (int)long_0;
				}
				int num2 = stream_0.Read(buffer, 0, int_1);
				if (num2 <= 0)
				{
					if (num >= GClass22.int_0)
					{
						break;
					}
					num++;
				}
				else
				{
					num = 0;
					memoryStream.Write(buffer, 0, num2);
					long_0 -= (long)num2;
				}
			}
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x00028314 File Offset: 0x00026514
	internal static void smethod_56(this Stream stream_0, int int_1, Action<byte[]> action_0, Action<Exception> action_1)
	{
		GClass22.Class19 @class = new GClass22.Class19();
		@class.stream_0 = stream_0;
		@class.int_2 = int_1;
		@class.action_0 = action_0;
		@class.action_1 = action_1;
		@class.byte_0 = new byte[@class.int_2];
		@class.int_1 = 0;
		@class.int_0 = 0;
		@class.asyncCallback_0 = null;
		@class.asyncCallback_0 = new AsyncCallback(@class.method_0);
		try
		{
			@class.stream_0.BeginRead(@class.byte_0, @class.int_1, @class.int_2, @class.asyncCallback_0, null);
		}
		catch (Exception obj)
		{
			if (@class.action_1 != null)
			{
				@class.action_1(obj);
			}
		}
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x000283CC File Offset: 0x000265CC
	internal static void smethod_57(this Stream stream_0, long long_0, int int_1, Action<byte[]> action_0, Action<Exception> action_1)
	{
		GClass22.Class20 @class = new GClass22.Class20();
		@class.int_0 = int_1;
		@class.stream_0 = stream_0;
		@class.action_1 = action_0;
		@class.action_2 = action_1;
		@class.memoryStream_0 = new MemoryStream();
		@class.byte_0 = new byte[@class.int_0];
		@class.int_1 = 0;
		@class.action_0 = null;
		@class.action_0 = new Action<long>(@class.method_0);
		try
		{
			@class.action_0(long_0);
		}
		catch (Exception obj)
		{
			@class.memoryStream_0.Dispose();
			if (@class.action_2 != null)
			{
				@class.action_2(obj);
			}
		}
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x00028478 File Offset: 0x00026678
	internal static T[] smethod_58<T>(this T[] gparam_0)
	{
		int num = gparam_0.Length;
		T[] array = new T[num];
		int num2 = num - 1;
		for (int i = 0; i <= num2; i++)
		{
			array[i] = gparam_0[num2 - i];
		}
		return array;
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x00004BC9 File Offset: 0x00002DC9
	internal static IEnumerable<string> smethod_59(this string string_1, params char[] char_0)
	{
		int length = string_1.Length;
		StringBuilder stringBuilder = new StringBuilder(32);
		int num = length - 1;
		bool flag = false;
		bool flag2 = false;
		int num2;
		for (int i = 0; i <= num; i = num2 + 1)
		{
			char c = string_1[i];
			stringBuilder.Append(c);
			if (c == '"')
			{
				if (flag)
				{
					flag = false;
				}
				else
				{
					flag2 = !flag2;
				}
			}
			else if (c == '\\')
			{
				if (i == num)
				{
					break;
				}
				if (string_1[i + 1] == '"')
				{
					flag = true;
				}
			}
			else if (Array.IndexOf<char>(char_0, c) > -1 && !flag2)
			{
				stringBuilder.Length--;
				yield return stringBuilder.ToString();
				stringBuilder.Length = 0;
			}
			num2 = i;
		}
		yield return stringBuilder.ToString();
		yield break;
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x000284B0 File Offset: 0x000266B0
	internal static byte[] smethod_60(this Stream stream_0)
	{
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			stream_0.Position = 0L;
			stream_0.CopyTo(memoryStream, 1024);
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x00028504 File Offset: 0x00026704
	internal static CompressionMethod smethod_61(this string string_1)
	{
		foreach (object obj in Enum.GetValues(typeof(CompressionMethod)))
		{
			CompressionMethod compressionMethod = (CompressionMethod)obj;
			if (compressionMethod.smethod_62(new string[0]) == string_1)
			{
				return compressionMethod;
			}
		}
		return CompressionMethod.None;
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x0002857C File Offset: 0x0002677C
	internal static string smethod_62(this CompressionMethod compressionMethod_0, params string[] string_1)
	{
		if (compressionMethod_0 == CompressionMethod.None)
		{
			return string.Empty;
		}
		string text = string.Format("permessage-{0}", compressionMethod_0.ToString().ToLower());
		if (string_1 != null && string_1.Length != 0)
		{
			return string.Format("{0}; {1}", text, string_1.smethod_104("; "));
		}
		return text;
	}

	// Token: 0x060002AA RID: 682 RVA: 0x000285D0 File Offset: 0x000267D0
	internal static IPAddress smethod_63(this string string_1)
	{
		if (string_1 == null || string_1.Length == 0)
		{
			return null;
		}
		IPAddress result;
		if (IPAddress.TryParse(string_1, out result))
		{
			return result;
		}
		IPAddress result2;
		try
		{
			result2 = Dns.GetHostAddresses(string_1)[0];
		}
		catch
		{
			result2 = null;
		}
		return result2;
	}

	// Token: 0x060002AB RID: 683 RVA: 0x00004BE0 File Offset: 0x00002DE0
	internal static List<T> smethod_64<T>(this IEnumerable<T> ienumerable_0)
	{
		return new List<T>(ienumerable_0);
	}

	// Token: 0x060002AC RID: 684 RVA: 0x00004BE8 File Offset: 0x00002DE8
	internal static string smethod_65(this IPAddress ipaddress_0, bool bool_0)
	{
		if (bool_0)
		{
			if (ipaddress_0.AddressFamily == AddressFamily.InterNetworkV6)
			{
				return string.Format("[{0}]", ipaddress_0.ToString());
			}
		}
		return ipaddress_0.ToString();
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00004C10 File Offset: 0x00002E10
	internal static ushort smethod_66(this byte[] byte_1, GEnum5 genum5_0)
	{
		return BitConverter.ToUInt16(byte_1.smethod_103(genum5_0), 0);
	}

	// Token: 0x060002AE RID: 686 RVA: 0x00004C1F File Offset: 0x00002E1F
	internal static ulong smethod_67(this byte[] byte_1, GEnum5 genum5_0)
	{
		return BitConverter.ToUInt64(byte_1.smethod_103(genum5_0), 0);
	}

	// Token: 0x060002AF RID: 687 RVA: 0x00004C2E File Offset: 0x00002E2E
	internal static IEnumerable<string> smethod_68(this IEnumerable<string> ienumerable_0)
	{
		GClass22.Class23 @class = new GClass22.Class23(-2);
		@class.ienumerable_1 = ienumerable_0;
		return @class;
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x00028618 File Offset: 0x00026818
	internal static string smethod_69(this string string_1)
	{
		string text = string_1.TrimEnd(new char[]
		{
			'/'
		});
		if (text.Length <= 0)
		{
			return "/";
		}
		return text;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x00028648 File Offset: 0x00026848
	internal static string smethod_70(this string string_1)
	{
		string text = string_1.TrimEnd(new char[]
		{
			'/',
			'\\'
		});
		if (text.Length <= 0)
		{
			return string_1[0].ToString();
		}
		return text;
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x00028688 File Offset: 0x00026888
	internal static bool smethod_71(this string string_1, out Version version_0)
	{
		version_0 = null;
		bool result;
		try
		{
			version_0 = new Version(string_1);
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x000286BC File Offset: 0x000268BC
	internal static bool smethod_72(this string string_1, out Uri uri_0, out string string_2)
	{
		uri_0 = null;
		string_2 = null;
		Uri uri = string_1.smethod_105();
		if (uri == null)
		{
			string_2 = "An invalid URI string.";
			return false;
		}
		if (!uri.IsAbsoluteUri)
		{
			string_2 = "A relative URI.";
			return false;
		}
		string scheme = uri.Scheme;
		if (!(scheme == "ws") && !(scheme == "wss"))
		{
			string_2 = "The scheme part is not 'ws' or 'wss'.";
			return false;
		}
		int port = uri.Port;
		if (port == 0)
		{
			string_2 = "The port part is zero.";
			return false;
		}
		if (uri.Fragment.Length > 0)
		{
			string_2 = "It includes the fragment component.";
			return false;
		}
		uri_0 = ((port != -1) ? uri : new Uri(string.Format("{0}://{1}:{2}{3}", new object[]
		{
			scheme,
			uri.Host,
			(scheme == "ws") ? 80 : 443,
			uri.PathAndQuery
		})));
		return true;
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x000287A0 File Offset: 0x000269A0
	internal static bool smethod_73(this byte[] byte_1, out string string_1)
	{
		string_1 = null;
		bool result;
		try
		{
			string_1 = Encoding.UTF8.GetString(byte_1);
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x000287D8 File Offset: 0x000269D8
	internal static bool smethod_74(this string string_1, out byte[] byte_1)
	{
		byte_1 = null;
		bool result;
		try
		{
			byte_1 = Encoding.UTF8.GetBytes(string_1);
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00028810 File Offset: 0x00026A10
	internal static bool smethod_75(this FileInfo fileInfo_0, out FileStream fileStream_0)
	{
		fileStream_0 = null;
		bool result;
		try
		{
			fileStream_0 = fileInfo_0.OpenRead();
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x00028844 File Offset: 0x00026A44
	internal static string smethod_76(this string string_1)
	{
		int num = string_1.IndexOf('"');
		if (num == -1)
		{
			return string_1;
		}
		int num2 = string_1.LastIndexOf('"');
		if (num2 == num)
		{
			return string_1;
		}
		int num3 = num2 - num - 1;
		if (num3 <= 0)
		{
			return string.Empty;
		}
		return string_1.Substring(num + 1, num3).Replace("\\\"", "\"");
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00028898 File Offset: 0x00026A98
	internal static bool smethod_77(this NameValueCollection nameValueCollection_0, string string_1)
	{
		StringComparison stringComparison_ = StringComparison.OrdinalIgnoreCase;
		return nameValueCollection_0.smethod_16("Upgrade", string_1, StringComparison.OrdinalIgnoreCase) && nameValueCollection_0.smethod_16("Connection", "Upgrade", stringComparison_);
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00004C3E File Offset: 0x00002E3E
	internal static string smethod_78(this string string_1, Encoding encoding_0)
	{
		return Class78.smethod_27(string_1, encoding_0);
	}

	// Token: 0x060002BA RID: 698 RVA: 0x00004C47 File Offset: 0x00002E47
	internal static string smethod_79(this string string_1, Encoding encoding_0)
	{
		return Class78.smethod_34(string_1, encoding_0);
	}

	// Token: 0x060002BB RID: 699 RVA: 0x000288CC File Offset: 0x00026ACC
	internal static void smethod_80(this Stream stream_0, byte[] byte_1, int int_1)
	{
		using (MemoryStream memoryStream = new MemoryStream(byte_1))
		{
			memoryStream.CopyTo(stream_0, int_1);
		}
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00028904 File Offset: 0x00026B04
	internal static void smethod_81(this Stream stream_0, byte[] byte_1, int int_1, Action action_0, Action<Exception> action_1)
	{
		GClass22.Class24 @class = new GClass22.Class24();
		@class.action_0 = action_0;
		@class.action_1 = action_1;
		@class.memoryStream_0 = new MemoryStream(byte_1);
		@class.memoryStream_0.smethod_22(stream_0, int_1, new Action(@class.method_0), new Action<Exception>(@class.method_1));
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00004C50 File Offset: 0x00002E50
	public static string smethod_82(this GEnum9 genum9_0)
	{
		return ((int)genum9_0).smethod_83();
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00028958 File Offset: 0x00026B58
	public static string smethod_83(this int int_1)
	{
		if (int_1 <= 207)
		{
			switch (int_1)
			{
			case 100:
				return "Continue";
			case 101:
				return "Switching Protocols";
			case 102:
				return "Processing";
			default:
				switch (int_1)
				{
				case 200:
					return "OK";
				case 201:
					return "Created";
				case 202:
					return "Accepted";
				case 203:
					return "Non-Authoritative Information";
				case 204:
					return "No Content";
				case 205:
					return "Reset Content";
				case 206:
					return "Partial Content";
				case 207:
					return "Multi-Status";
				}
				break;
			}
		}
		else
		{
			switch (int_1)
			{
			case 300:
				return "Multiple Choices";
			case 301:
				return "Moved Permanently";
			case 302:
				return "Found";
			case 303:
				return "See Other";
			case 304:
				return "Not Modified";
			case 305:
				return "Use Proxy";
			case 306:
				break;
			case 307:
				return "Temporary Redirect";
			default:
				switch (int_1)
				{
				case 400:
					return "Bad Request";
				case 401:
					return "Unauthorized";
				case 402:
					return "Payment Required";
				case 403:
					return "Forbidden";
				case 404:
					return "Not Found";
				case 405:
					return "Method Not Allowed";
				case 406:
					return "Not Acceptable";
				case 407:
					return "Proxy Authentication Required";
				case 408:
					return "Request Timeout";
				case 409:
					return "Conflict";
				case 410:
					return "Gone";
				case 411:
					return "Length Required";
				case 412:
					return "Precondition Failed";
				case 413:
					return "Request Entity Too Large";
				case 414:
					return "Request-Uri Too Long";
				case 415:
					return "Unsupported Media Type";
				case 416:
					return "Requested Range Not Satisfiable";
				case 417:
					return "Expectation Failed";
				case 418:
				case 419:
				case 420:
				case 421:
					break;
				case 422:
					return "Unprocessable Entity";
				case 423:
					return "Locked";
				case 424:
					return "Failed Dependency";
				default:
					switch (int_1)
					{
					case 500:
						return "Internal Server Error";
					case 501:
						return "Not Implemented";
					case 502:
						return "Bad Gateway";
					case 503:
						return "Service Unavailable";
					case 504:
						return "Gateway Timeout";
					case 505:
						return "Http Version Not Supported";
					case 507:
						return "Insufficient Storage";
					}
					break;
				}
				break;
			}
		}
		return string.Empty;
	}

	// Token: 0x060002BF RID: 703 RVA: 0x00004C58 File Offset: 0x00002E58
	public static bool smethod_84(this ushort ushort_0)
	{
		return ushort_0 > 999 && ushort_0 < 5000;
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x00028B9C File Offset: 0x00026D9C
	public static bool smethod_85(this string string_1, char char_0)
	{
		if (string_1 == null)
		{
			return false;
		}
		int length = string_1.Length;
		return length >= 2 && string_1[0] == char_0 && string_1[length - 1] == char_0;
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00004C6C File Offset: 0x00002E6C
	public static bool smethod_86(this GEnum5 genum5_0)
	{
		return BitConverter.IsLittleEndian == (genum5_0 == GEnum5.Little);
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00028BD4 File Offset: 0x00026DD4
	public static bool smethod_87(this IPAddress ipaddress_0)
	{
		if (ipaddress_0 == null)
		{
			throw new ArgumentNullException("address");
		}
		if (ipaddress_0.Equals(IPAddress.Any))
		{
			return true;
		}
		if (ipaddress_0.Equals(IPAddress.Loopback))
		{
			return true;
		}
		if (Socket.OSSupportsIPv6)
		{
			if (ipaddress_0.Equals(IPAddress.IPv6Any))
			{
				return true;
			}
			if (ipaddress_0.Equals(IPAddress.IPv6Loopback))
			{
				return true;
			}
		}
		foreach (IPAddress obj in Dns.GetHostAddresses(Dns.GetHostName()))
		{
			if (ipaddress_0.Equals(obj))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00004C79 File Offset: 0x00002E79
	public static bool smethod_88(this string string_1)
	{
		return string_1 == null || string_1.Length == 0;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x00028C5C File Offset: 0x00026E5C
	public static bool smethod_89(this string string_1)
	{
		if (string_1 == null || string_1.Length < 2)
		{
			return false;
		}
		char c = string_1[0];
		if (c == 'h')
		{
			return string_1 == "http" || string_1 == "https";
		}
		if (c == 'w')
		{
			return string_1 == "ws" || string_1 == "wss";
		}
		if (c == 'f')
		{
			return string_1 == "file" || string_1 == "ftp";
		}
		if (c == 'g')
		{
			return string_1 == "gopher";
		}
		if (c == 'm')
		{
			return string_1 == "mailto";
		}
		if (c != 'n')
		{
			return false;
		}
		c = string_1[1];
		if (c != 'e')
		{
			return string_1 == "nntp";
		}
		return string_1 == "news" || string_1 == "net.pipe" || string_1 == "net.tcp";
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x00028D50 File Offset: 0x00026F50
	public static bool smethod_90(this string string_1)
	{
		if (string_1 == null)
		{
			return false;
		}
		if (string_1.Length == 0)
		{
			return false;
		}
		int num = string_1.IndexOf(':');
		return num != -1 && num < 10 && string_1.Substring(0, num).smethod_89();
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00028D90 File Offset: 0x00026F90
	public static T[] smethod_91<T>(this T[] gparam_0, int int_1, int int_2)
	{
		if (gparam_0 == null)
		{
			throw new ArgumentNullException("array");
		}
		int num = gparam_0.Length;
		if (num == 0)
		{
			if (int_1 != 0)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (int_2 != 0)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			return gparam_0;
		}
		else
		{
			if (int_1 < 0 || int_1 >= num)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (int_2 < 0 || int_2 > num - int_1)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			if (int_2 == 0)
			{
				return new T[0];
			}
			if (int_2 == num)
			{
				return gparam_0;
			}
			T[] array = new T[int_2];
			Array.Copy(gparam_0, int_1, array, 0, int_2);
			return array;
		}
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x00028E1C File Offset: 0x0002701C
	public static T[] smethod_92<T>(this T[] gparam_0, long long_0, long long_1)
	{
		if (gparam_0 == null)
		{
			throw new ArgumentNullException("array");
		}
		long num = (long)gparam_0.Length;
		if (num == 0L)
		{
			if (long_0 != 0L)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (long_1 != 0L)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			return gparam_0;
		}
		else
		{
			if (long_0 < 0L || long_0 >= num)
			{
				throw new ArgumentOutOfRangeException("startIndex");
			}
			if (long_1 < 0L || long_1 > num - long_0)
			{
				throw new ArgumentOutOfRangeException("length");
			}
			if (long_1 == 0L)
			{
				return new T[0];
			}
			if (long_1 == num)
			{
				return gparam_0;
			}
			T[] array = new T[long_1];
			Array.Copy(gparam_0, long_0, array, 0L, long_1);
			return array;
		}
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x00028EAC File Offset: 0x000270AC
	public static void smethod_93(this int int_1, Action action_0)
	{
		if (int_1 <= 0)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (int i = 0; i < int_1; i++)
		{
			action_0();
		}
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x00028ED4 File Offset: 0x000270D4
	public static void smethod_94(this long long_0, Action action_0)
	{
		if (long_0 <= 0L)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (long num = 0L; num < long_0; num += 1L)
		{
			action_0();
		}
	}

	// Token: 0x060002CA RID: 714 RVA: 0x00028F00 File Offset: 0x00027100
	public static void smethod_95(this uint uint_0, Action action_0)
	{
		if (uint_0 == 0U)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (uint num = 0U; num < uint_0; num += 1U)
		{
			action_0();
		}
	}

	// Token: 0x060002CB RID: 715 RVA: 0x00028F28 File Offset: 0x00027128
	public static void smethod_96(this ulong ulong_0, Action action_0)
	{
		if (ulong_0 == 0UL)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (ulong num = 0UL; num < ulong_0; num += 1UL)
		{
			action_0();
		}
	}

	// Token: 0x060002CC RID: 716 RVA: 0x00028F54 File Offset: 0x00027154
	public static void smethod_97(this int int_1, Action<int> action_0)
	{
		if (int_1 <= 0)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (int i = 0; i < int_1; i++)
		{
			action_0(i);
		}
	}

	// Token: 0x060002CD RID: 717 RVA: 0x00028F80 File Offset: 0x00027180
	public static void smethod_98(this long long_0, Action<long> action_0)
	{
		if (long_0 <= 0L)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (long num = 0L; num < long_0; num += 1L)
		{
			action_0(num);
		}
	}

	// Token: 0x060002CE RID: 718 RVA: 0x00028FAC File Offset: 0x000271AC
	public static void smethod_99(this uint uint_0, Action<uint> action_0)
	{
		if (uint_0 == 0U)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (uint num = 0U; num < uint_0; num += 1U)
		{
			action_0(num);
		}
	}

	// Token: 0x060002CF RID: 719 RVA: 0x00028FD4 File Offset: 0x000271D4
	public static void smethod_100(this ulong ulong_0, Action<ulong> action_0)
	{
		if (ulong_0 == 0UL)
		{
			return;
		}
		if (action_0 == null)
		{
			return;
		}
		for (ulong num = 0UL; num < ulong_0; num += 1UL)
		{
			action_0(num);
		}
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x00029000 File Offset: 0x00027200
	[Obsolete("This method will be removed.")]
	public static T smethod_101<T>(this byte[] byte_1, GEnum5 genum5_0) where T : struct
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("source");
		}
		if (byte_1.Length == 0)
		{
			return default(T);
		}
		Type typeFromHandle = typeof(T);
		byte[] value = byte_1.smethod_103(genum5_0);
		if (typeFromHandle == typeof(bool))
		{
			return (T)((object)BitConverter.ToBoolean(value, 0));
		}
		if (typeFromHandle == typeof(char))
		{
			return (T)((object)BitConverter.ToChar(value, 0));
		}
		if (typeFromHandle == typeof(double))
		{
			return (T)((object)BitConverter.ToDouble(value, 0));
		}
		if (typeFromHandle == typeof(short))
		{
			return (T)((object)BitConverter.ToInt16(value, 0));
		}
		if (typeFromHandle == typeof(int))
		{
			return (T)((object)BitConverter.ToInt32(value, 0));
		}
		if (typeFromHandle == typeof(long))
		{
			return (T)((object)BitConverter.ToInt64(value, 0));
		}
		if (typeFromHandle == typeof(float))
		{
			return (T)((object)BitConverter.ToSingle(value, 0));
		}
		if (typeFromHandle == typeof(ushort))
		{
			return (T)((object)BitConverter.ToUInt16(value, 0));
		}
		if (typeFromHandle == typeof(uint))
		{
			return (T)((object)BitConverter.ToUInt32(value, 0));
		}
		if (!(typeFromHandle == typeof(ulong)))
		{
			return default(T);
		}
		return (T)((object)BitConverter.ToUInt64(value, 0));
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x000291C0 File Offset: 0x000273C0
	[Obsolete("This method will be removed.")]
	public static byte[] smethod_102<T>(this T gparam_0, GEnum5 genum5_0) where T : struct
	{
		Type typeFromHandle = typeof(T);
		byte[] array;
		if (!(typeFromHandle == typeof(bool)))
		{
			if (!(typeFromHandle == typeof(byte)))
			{
				array = ((typeFromHandle == typeof(char)) ? BitConverter.GetBytes((char)((object)gparam_0)) : ((typeFromHandle == typeof(double)) ? BitConverter.GetBytes((double)((object)gparam_0)) : ((typeFromHandle == typeof(short)) ? BitConverter.GetBytes((short)((object)gparam_0)) : ((typeFromHandle == typeof(int)) ? BitConverter.GetBytes((int)((object)gparam_0)) : ((typeFromHandle == typeof(long)) ? BitConverter.GetBytes((long)((object)gparam_0)) : ((typeFromHandle == typeof(float)) ? BitConverter.GetBytes((float)((object)gparam_0)) : ((typeFromHandle == typeof(ushort)) ? BitConverter.GetBytes((ushort)((object)gparam_0)) : ((typeFromHandle == typeof(uint)) ? BitConverter.GetBytes((uint)((object)gparam_0)) : ((typeFromHandle == typeof(ulong)) ? BitConverter.GetBytes((ulong)((object)gparam_0)) : GClass25.byte_0)))))))));
			}
			else
			{
				(array = new byte[1])[0] = (byte)((object)gparam_0);
			}
		}
		else
		{
			array = BitConverter.GetBytes((bool)((object)gparam_0));
		}
		byte[] array2 = array;
		if (array2.Length > 1 && !genum5_0.smethod_86())
		{
			Array.Reverse(array2);
		}
		return array2;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x00004C89 File Offset: 0x00002E89
	public static byte[] smethod_103(this byte[] byte_1, GEnum5 genum5_0)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("source");
		}
		if (byte_1.Length < 2)
		{
			return byte_1;
		}
		if (genum5_0.smethod_86())
		{
			return byte_1;
		}
		return byte_1.smethod_58<byte>();
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x000293A8 File Offset: 0x000275A8
	public static string smethod_104<T>(this T[] gparam_0, string string_1)
	{
		if (gparam_0 == null)
		{
			throw new ArgumentNullException("array");
		}
		int num = gparam_0.Length;
		if (num == 0)
		{
			return string.Empty;
		}
		if (string_1 == null)
		{
			string_1 = string.Empty;
		}
		StringBuilder stringBuilder = new StringBuilder(64);
		int num2 = num - 1;
		for (int i = 0; i < num2; i++)
		{
			stringBuilder.AppendFormat("{0}{1}", gparam_0[i], string_1);
		}
		stringBuilder.Append(gparam_0[num2].ToString());
		return stringBuilder.ToString();
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x0002942C File Offset: 0x0002762C
	public static Uri smethod_105(this string string_1)
	{
		Uri result;
		Uri.TryCreate(string_1, string_1.smethod_90() ? UriKind.Absolute : UriKind.Relative, out result);
		return result;
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x00029450 File Offset: 0x00027650
	[Obsolete("This method will be removed.")]
	public static void smethod_106(this GClass41 gclass41_0, byte[] byte_1)
	{
		if (gclass41_0 == null)
		{
			throw new ArgumentNullException("response");
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		long num = (long)byte_1.Length;
		if (num == 0L)
		{
			gclass41_0.method_7();
			return;
		}
		gclass41_0.Int64_0 = num;
		Stream stream_ = gclass41_0.Stream_0;
		if (num <= 2147483647L)
		{
			stream_.Write(byte_1, 0, (int)num);
		}
		else
		{
			stream_.smethod_80(byte_1, 1024);
		}
		stream_.Close();
	}

	// Token: 0x0400017C RID: 380
	private static readonly byte[] byte_0 = new byte[1];

	// Token: 0x0400017D RID: 381
	private static readonly int int_0 = 5;

	// Token: 0x0400017E RID: 382
	private const string string_0 = "()<>@,;:\\\"/[]?={} \t";

	// Token: 0x0200003C RID: 60
	[CompilerGenerated]
	private sealed class Class17
	{
		// Token: 0x060002D8 RID: 728 RVA: 0x000294BC File Offset: 0x000276BC
		internal bool method_0(int int_2)
		{
			if (int_2 == this.int_0)
			{
				return false;
			}
			string b = this.string_0[int_2];
			for (int i = int_2 + 1; i < this.int_1; i++)
			{
				if (this.string_0[i] == b)
				{
					return true;
				}
			}
			return this.func_0(++int_2);
		}

		// Token: 0x0400017F RID: 383
		public int int_0;

		// Token: 0x04000180 RID: 384
		public string[] string_0;

		// Token: 0x04000181 RID: 385
		public int int_1;

		// Token: 0x04000182 RID: 386
		public Func<int, bool> func_0;
	}

	// Token: 0x0200003D RID: 61
	[CompilerGenerated]
	private sealed class Class18
	{
		// Token: 0x060002DA RID: 730 RVA: 0x00029514 File Offset: 0x00027714
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				int num = this.stream_0.EndRead(iasyncResult_0);
				if (num <= 0)
				{
					if (this.action_0 != null)
					{
						this.action_0();
					}
				}
				else
				{
					this.stream_1.Write(this.byte_0, 0, num);
					this.stream_0.BeginRead(this.byte_0, 0, this.int_0, this.asyncCallback_0, null);
				}
			}
			catch (Exception obj)
			{
				if (this.action_1 != null)
				{
					this.action_1(obj);
				}
			}
		}

		// Token: 0x04000183 RID: 387
		public Stream stream_0;

		// Token: 0x04000184 RID: 388
		public Action action_0;

		// Token: 0x04000185 RID: 389
		public Stream stream_1;

		// Token: 0x04000186 RID: 390
		public byte[] byte_0;

		// Token: 0x04000187 RID: 391
		public int int_0;

		// Token: 0x04000188 RID: 392
		public AsyncCallback asyncCallback_0;

		// Token: 0x04000189 RID: 393
		public Action<Exception> action_1;
	}

	// Token: 0x0200003E RID: 62
	[CompilerGenerated]
	private sealed class Class19
	{
		// Token: 0x060002DC RID: 732 RVA: 0x000295A4 File Offset: 0x000277A4
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				int num = this.stream_0.EndRead(iasyncResult_0);
				if (num <= 0)
				{
					if (this.int_0 < GClass22.int_0)
					{
						int num2 = this.int_0;
						this.int_0 = num2 + 1;
						this.stream_0.BeginRead(this.byte_0, this.int_1, this.int_2, this.asyncCallback_0, null);
					}
					else if (this.action_0 != null)
					{
						this.action_0(this.byte_0.smethod_91(0, this.int_1));
					}
				}
				else if (num == this.int_2)
				{
					if (this.action_0 != null)
					{
						this.action_0(this.byte_0);
					}
				}
				else
				{
					this.int_0 = 0;
					this.int_1 += num;
					this.int_2 -= num;
					this.stream_0.BeginRead(this.byte_0, this.int_1, this.int_2, this.asyncCallback_0, null);
				}
			}
			catch (Exception obj)
			{
				if (this.action_1 != null)
				{
					this.action_1(obj);
				}
			}
		}

		// Token: 0x0400018A RID: 394
		public Stream stream_0;

		// Token: 0x0400018B RID: 395
		public int int_0;

		// Token: 0x0400018C RID: 396
		public byte[] byte_0;

		// Token: 0x0400018D RID: 397
		public int int_1;

		// Token: 0x0400018E RID: 398
		public int int_2;

		// Token: 0x0400018F RID: 399
		public AsyncCallback asyncCallback_0;

		// Token: 0x04000190 RID: 400
		public Action<byte[]> action_0;

		// Token: 0x04000191 RID: 401
		public Action<Exception> action_1;
	}

	// Token: 0x0200003F RID: 63
	[CompilerGenerated]
	private sealed class Class20
	{
		// Token: 0x060002DE RID: 734 RVA: 0x000296C8 File Offset: 0x000278C8
		internal void method_0(long long_0)
		{
			GClass22.Class21 @class = new GClass22.Class21();
			@class.class20_0 = this;
			@class.long_0 = long_0;
			if (@class.long_0 < (long)this.int_0)
			{
				this.int_0 = (int)@class.long_0;
			}
			this.stream_0.BeginRead(this.byte_0, 0, this.int_0, new AsyncCallback(@class.method_0), null);
		}

		// Token: 0x04000192 RID: 402
		public int int_0;

		// Token: 0x04000193 RID: 403
		public Stream stream_0;

		// Token: 0x04000194 RID: 404
		public byte[] byte_0;

		// Token: 0x04000195 RID: 405
		public int int_1;

		// Token: 0x04000196 RID: 406
		public Action<long> action_0;

		// Token: 0x04000197 RID: 407
		public Action<byte[]> action_1;

		// Token: 0x04000198 RID: 408
		public MemoryStream memoryStream_0;

		// Token: 0x04000199 RID: 409
		public Action<Exception> action_2;
	}

	// Token: 0x02000040 RID: 64
	[CompilerGenerated]
	private sealed class Class21
	{
		// Token: 0x060002E0 RID: 736 RVA: 0x0002972C File Offset: 0x0002792C
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				int num = this.class20_0.stream_0.EndRead(iasyncResult_0);
				if (num <= 0)
				{
					if (this.class20_0.int_1 < GClass22.int_0)
					{
						int int_ = this.class20_0.int_1;
						this.class20_0.int_1 = int_ + 1;
						this.class20_0.action_0(this.long_0);
					}
					else
					{
						if (this.class20_0.action_1 != null)
						{
							this.class20_0.memoryStream_0.Close();
							this.class20_0.action_1(this.class20_0.memoryStream_0.ToArray());
						}
						this.class20_0.memoryStream_0.Dispose();
					}
				}
				else
				{
					this.class20_0.memoryStream_0.Write(this.class20_0.byte_0, 0, num);
					if ((long)num == this.long_0)
					{
						if (this.class20_0.action_1 != null)
						{
							this.class20_0.memoryStream_0.Close();
							this.class20_0.action_1(this.class20_0.memoryStream_0.ToArray());
						}
						this.class20_0.memoryStream_0.Dispose();
					}
					else
					{
						this.class20_0.int_1 = 0;
						this.class20_0.action_0(this.long_0 - (long)num);
					}
				}
			}
			catch (Exception obj)
			{
				this.class20_0.memoryStream_0.Dispose();
				if (this.class20_0.action_2 != null)
				{
					this.class20_0.action_2(obj);
				}
			}
		}

		// Token: 0x0400019A RID: 410
		public long long_0;

		// Token: 0x0400019B RID: 411
		public GClass22.Class20 class20_0;
	}

	// Token: 0x02000043 RID: 67
	[CompilerGenerated]
	private sealed class Class24
	{
		// Token: 0x060002F3 RID: 755 RVA: 0x00004D34 File Offset: 0x00002F34
		internal void method_0()
		{
			if (this.action_0 != null)
			{
				this.action_0();
			}
			this.memoryStream_0.Dispose();
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00004D54 File Offset: 0x00002F54
		internal void method_1(Exception exception_0)
		{
			this.memoryStream_0.Dispose();
			if (this.action_1 != null)
			{
				this.action_1(exception_0);
			}
		}

		// Token: 0x040001AE RID: 430
		public Action action_0;

		// Token: 0x040001AF RID: 431
		public MemoryStream memoryStream_0;

		// Token: 0x040001B0 RID: 432
		public Action<Exception> action_1;
	}
}
