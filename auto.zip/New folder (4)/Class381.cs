﻿using System;

// Token: 0x020002B7 RID: 695
internal class Class381
{
	// Token: 0x04001A27 RID: 6695
	public static int int_0 = 1;

	// Token: 0x04001A28 RID: 6696
	public static int int_1 = 2;

	// Token: 0x04001A29 RID: 6697
	public static int int_2 = 3;

	// Token: 0x04001A2A RID: 6698
	public static int int_3 = 4;

	// Token: 0x04001A2B RID: 6699
	public static int int_4 = 5;

	// Token: 0x04001A2C RID: 6700
	public static int int_5 = 6;

	// Token: 0x04001A2D RID: 6701
	public static int int_6 = 7;

	// Token: 0x04001A2E RID: 6702
	public static int int_7 = 8;

	// Token: 0x04001A2F RID: 6703
	public static int int_8 = 9;

	// Token: 0x04001A30 RID: 6704
	public static int int_9 = 32;

	// Token: 0x04001A31 RID: 6705
	public static int int_10 = 37;

	// Token: 0x04001A32 RID: 6706
	public static int int_11 = 53;

	// Token: 0x04001A33 RID: 6707
	public static int int_12 = 54;
}
