﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x020000D9 RID: 217
public class GClass73
{
	// Token: 0x170002BD RID: 701
	// (get) Token: 0x06000A14 RID: 2580 RVA: 0x00009992 File Offset: 0x00007B92
	// (set) Token: 0x06000A15 RID: 2581 RVA: 0x0000999A File Offset: 0x00007B9A
	public bool Boolean_0 { get; set; }

	// Token: 0x170002BE RID: 702
	// (get) Token: 0x06000A16 RID: 2582 RVA: 0x000099A3 File Offset: 0x00007BA3
	// (set) Token: 0x06000A17 RID: 2583 RVA: 0x000099AB File Offset: 0x00007BAB
	public bool Boolean_1 { get; set; }

	// Token: 0x06000A18 RID: 2584 RVA: 0x000099B4 File Offset: 0x00007BB4
	public GClass73()
	{
		this.Boolean_1 = true;
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x000416FC File Offset: 0x0003F8FC
	public string method_0(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
		GClass86 gclass = new GClass86(fastColoredTextBox_1);
		gclass.method_2();
		return this.method_1(gclass);
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x00041724 File Offset: 0x0003F924
	public string method_1(GClass86 gclass86_0)
	{
		this.fastColoredTextBox_0 = gclass86_0.fastColoredTextBox_0;
		Dictionary<StyleIndex, object> dictionary = new Dictionary<StyleIndex, object>();
		StringBuilder stringBuilder = new StringBuilder();
		StringBuilder stringBuilder2 = new StringBuilder();
		StyleIndex styleIndex = StyleIndex.None;
		gclass86_0.method_40();
		int int_ = gclass86_0.GStruct2_0.int_1;
		dictionary[StyleIndex.None] = null;
		this.dictionary_0.Clear();
		int num = this.method_4(gclass86_0.fastColoredTextBox_0.Color_4);
		if (this.Boolean_0)
		{
			stringBuilder2.AppendFormat("{{\\cf{1} {0}}}\\tab", int_ + 1, num);
		}
		foreach (GStruct2 gstruct in ((IEnumerable<GStruct2>)gclass86_0))
		{
			GStruct0 gstruct2 = gclass86_0.fastColoredTextBox_0[gstruct.int_1][gstruct.int_0];
			if (gstruct2.styleIndex_0 != styleIndex)
			{
				this.method_3(stringBuilder, stringBuilder2, styleIndex);
				styleIndex = gstruct2.styleIndex_0;
				dictionary[styleIndex] = null;
			}
			if (gstruct.int_1 != int_)
			{
				for (int i = int_; i < gstruct.int_1; i++)
				{
					stringBuilder2.AppendLine("\\line");
					if (this.Boolean_0)
					{
						stringBuilder2.AppendFormat("{{\\cf{1} {0}}}\\tab", i + 2, num);
					}
				}
				int_ = gstruct.int_1;
			}
			char char_ = gstruct2.char_0;
			if (char_ != '\\')
			{
				if (char_ != '{')
				{
					if (char_ != '}')
					{
						int char_2 = (int)gstruct2.char_0;
						if (char_2 < 128)
						{
							stringBuilder2.Append(gstruct2.char_0);
						}
						else
						{
							stringBuilder2.AppendFormat("{{\\u{0}}}", char_2);
						}
					}
					else
					{
						stringBuilder2.Append("\\}");
					}
				}
				else
				{
					stringBuilder2.Append("\\{");
				}
			}
			else
			{
				stringBuilder2.Append("\\\\");
			}
		}
		this.method_3(stringBuilder, stringBuilder2, styleIndex);
		SortedList<int, Color> sortedList = new SortedList<int, Color>();
		foreach (KeyValuePair<Color, int> keyValuePair in this.dictionary_0)
		{
			sortedList.Add(keyValuePair.Value, keyValuePair.Key);
		}
		stringBuilder2.Length = 0;
		stringBuilder2.AppendFormat("{{\\colortbl;", new object[0]);
		foreach (KeyValuePair<int, Color> keyValuePair2 in sortedList)
		{
			stringBuilder2.Append(GClass73.smethod_0(keyValuePair2.Value) + ";");
		}
		stringBuilder2.AppendLine("}");
		if (this.Boolean_1)
		{
			stringBuilder.Insert(0, string.Format("{{\\fonttbl{{\\f0\\fmodern {0};}}}}{{\\fs{1} ", this.fastColoredTextBox_0.Font.Name, (int)(2f * this.fastColoredTextBox_0.Font.SizeInPoints), this.fastColoredTextBox_0.Int32_2));
			stringBuilder.AppendLine("}");
		}
		stringBuilder.Insert(0, stringBuilder2.ToString());
		stringBuilder.Insert(0, "{\\rtf1\\ud\\deff0");
		stringBuilder.AppendLine("}");
		return stringBuilder.ToString();
	}

	// Token: 0x06000A1B RID: 2587 RVA: 0x00041A98 File Offset: 0x0003FC98
	private GClass74 method_2(StyleIndex styleIndex_0)
	{
		List<GClass87> list = new List<GClass87>();
		GClass88 gclass = null;
		int num = 1;
		bool flag = false;
		for (int i = 0; i < this.fastColoredTextBox_0.GClass87_0.Length; i++)
		{
			if (this.fastColoredTextBox_0.GClass87_0[i] != null && ((int)styleIndex_0 & num) != 0 && this.fastColoredTextBox_0.GClass87_0[i].GClass87.\u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E)
			{
				GClass87 gclass2 = this.fastColoredTextBox_0.GClass87_0[i];
				list.Add(gclass2);
				if (gclass2 is GClass88 && (!flag || this.fastColoredTextBox_0.Boolean_16))
				{
					flag = true;
					gclass = (gclass2 as GClass88);
				}
			}
			num <<= 1;
		}
		GClass74 result;
		if (!flag)
		{
			result = this.fastColoredTextBox_0.GClass88_0.GClass87.\u202E\u206A\u206D\u200D\u206D\u206D\u200E\u200E\u202A\u200D\u200E\u200C\u202E\u200D\u202A\u200B\u202E\u206E\u200D\u200B\u200B\u206D\u200B\u206A\u206D\u202C\u202B\u200E\u202D\u206A\u202C\u206C\u202B\u200B\u200C\u206A\u202C\u206E\u202E\u206D\u202E();
		}
		else
		{
			result = gclass.GClass87.\u202E\u206A\u206D\u200D\u206D\u206D\u200E\u200E\u202A\u200D\u200E\u200C\u202E\u200D\u202A\u200B\u202E\u206E\u200D\u200B\u200B\u206D\u200B\u206A\u206D\u202C\u202B\u200E\u202D\u206A\u202C\u206C\u202B\u200B\u200C\u206A\u202C\u206E\u202E\u206D\u202E();
		}
		return result;
	}

	// Token: 0x06000A1C RID: 2588 RVA: 0x00041B60 File Offset: 0x0003FD60
	public static string smethod_0(Color color_0)
	{
		if (color_0 == Color.Transparent)
		{
			return "";
		}
		return string.Format("\\red{0}\\green{1}\\blue{2}", color_0.R, color_0.G, color_0.B);
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x00041BB0 File Offset: 0x0003FDB0
	private void method_3(StringBuilder stringBuilder_0, StringBuilder stringBuilder_1, StyleIndex styleIndex_0)
	{
		if (stringBuilder_1.Length == 0)
		{
			return;
		}
		GClass74 gclass = this.method_2(styleIndex_0);
		int num = this.method_4(gclass.Color_0);
		int num2 = this.method_4(gclass.Color_1);
		StringBuilder stringBuilder = new StringBuilder();
		if (num >= 0)
		{
			stringBuilder.AppendFormat("\\cf{0}", num);
		}
		if (num2 >= 0)
		{
			stringBuilder.AppendFormat("\\highlight{0}", num2);
		}
		if (!string.IsNullOrEmpty(gclass.String_0))
		{
			stringBuilder.Append(gclass.String_0.Trim());
		}
		if (stringBuilder.Length > 0)
		{
			stringBuilder_0.AppendFormat("{{{0} {1}}}", stringBuilder, stringBuilder_1.ToString());
		}
		else
		{
			stringBuilder_0.Append(stringBuilder_1.ToString());
		}
		stringBuilder_1.Length = 0;
	}

	// Token: 0x06000A1E RID: 2590 RVA: 0x000099CE File Offset: 0x00007BCE
	private int method_4(Color color_0)
	{
		if (color_0.A == 0)
		{
			return -1;
		}
		if (!this.dictionary_0.ContainsKey(color_0))
		{
			this.dictionary_0[color_0] = this.dictionary_0.Count + 1;
		}
		return this.dictionary_0[color_0];
	}

	// Token: 0x040004EB RID: 1259
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040004EC RID: 1260
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x040004ED RID: 1261
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040004EE RID: 1262
	private Dictionary<Color, int> dictionary_0 = new Dictionary<Color, int>();
}
