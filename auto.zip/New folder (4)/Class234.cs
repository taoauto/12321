﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

// Token: 0x020001F8 RID: 504
internal class Class234
{
	// Token: 0x17000658 RID: 1624
	// (get) Token: 0x06001A4A RID: 6730 RVA: 0x000130ED File Offset: 0x000112ED
	// (set) Token: 0x06001A4B RID: 6731 RVA: 0x000130F5 File Offset: 0x000112F5
	public IEnumerable<Class159> IEnumerable_0 { get; set; } = Enumerable.Empty<Class159>();

	// Token: 0x17000659 RID: 1625
	// (get) Token: 0x06001A4C RID: 6732 RVA: 0x000130FE File Offset: 0x000112FE
	// (set) Token: 0x06001A4D RID: 6733 RVA: 0x00013106 File Offset: 0x00011306
	public IEnumerable<Class159> IEnumerable_1 { get; set; } = Enumerable.Empty<Class159>();

	// Token: 0x0400106A RID: 4202
	[CompilerGenerated]
	private IEnumerable<Class159> ienumerable_0;

	// Token: 0x0400106B RID: 4203
	[CompilerGenerated]
	private IEnumerable<Class159> ienumerable_1;
}
