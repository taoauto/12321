﻿using System;

// Token: 0x0200013D RID: 317
internal static class Class122
{
	// Token: 0x06000FA8 RID: 4008 RVA: 0x000593BC File Offset: 0x000575BC
	public static string smethod_0(long long_3)
	{
		if (long_3 < 1024L)
		{
			return string.Format("{0} b", long_3);
		}
		if (long_3 >= 1024L && long_3 < 1048576L)
		{
			return string.Format("{0:0} KB", (float)long_3 / 1024f);
		}
		if (long_3 >= 1048576L && long_3 < 1073741824L)
		{
			return string.Format("{0:0,###} MB", (float)long_3 / 1024f);
		}
		return string.Format("{0:0,###.###} GB", (float)long_3 / 1024f);
	}

	// Token: 0x0400080F RID: 2063
	private const long long_0 = 1024L;

	// Token: 0x04000810 RID: 2064
	private const long long_1 = 1048576L;

	// Token: 0x04000811 RID: 2065
	private const long long_2 = 1073741824L;

	// Token: 0x04000812 RID: 2066
	private const string string_0 = "{0} b";

	// Token: 0x04000813 RID: 2067
	private const string string_1 = "{0:0} KB";

	// Token: 0x04000814 RID: 2068
	private const string string_2 = "{0:0,###} MB";

	// Token: 0x04000815 RID: 2069
	private const string string_3 = "{0:0,###.###} GB";
}
