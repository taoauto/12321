﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Text;

// Token: 0x0200004A RID: 74
public class GClass23
{
	// Token: 0x06000321 RID: 801 RVA: 0x00004FC7 File Offset: 0x000031C7
	internal GClass23(GEnum7 genum7_1, StackFrame stackFrame_1, string string_1)
	{
		this.genum7_0 = genum7_1;
		this.stackFrame_0 = stackFrame_1;
		this.string_0 = (string_1 ?? string.Empty);
		this.dateTime_0 = DateTime.Now;
	}

	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x06000322 RID: 802 RVA: 0x00004FF8 File Offset: 0x000031F8
	public StackFrame StackFrame_0
	{
		get
		{
			return this.stackFrame_0;
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x06000323 RID: 803 RVA: 0x00005000 File Offset: 0x00003200
	public DateTime DateTime_0
	{
		get
		{
			return this.dateTime_0;
		}
	}

	// Token: 0x170000D7 RID: 215
	// (get) Token: 0x06000324 RID: 804 RVA: 0x00005008 File Offset: 0x00003208
	public GEnum7 GEnum7_0
	{
		get
		{
			return this.genum7_0;
		}
	}

	// Token: 0x170000D8 RID: 216
	// (get) Token: 0x06000325 RID: 805 RVA: 0x00005010 File Offset: 0x00003210
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x06000326 RID: 806 RVA: 0x0002A3A8 File Offset: 0x000285A8
	public virtual string ToString()
	{
		string text = string.Format("{0}|{1,-5}|", this.dateTime_0, this.genum7_0);
		MethodBase method = this.stackFrame_0.GetMethod();
		Type declaringType = method.DeclaringType;
		string arg = string.Format("{0}{1}.{2}|", text, declaringType.Name, method.Name);
		string[] array = this.string_0.Replace("\r\n", "\n").TrimEnd(new char[]
		{
			'\n'
		}).Split(new char[]
		{
			'\n'
		});
		if (array.Length <= 1)
		{
			return string.Format("{0}{1}", arg, this.string_0);
		}
		StringBuilder stringBuilder = new StringBuilder(string.Format("{0}{1}\n", arg, array[0]), 64);
		string format = string.Format("{{0,{0}}}{{1}}\n", text.Length);
		for (int i = 1; i < array.Length; i++)
		{
			stringBuilder.AppendFormat(format, "", array[i]);
		}
		StringBuilder stringBuilder2 = stringBuilder;
		int length = stringBuilder2.Length;
		stringBuilder2.Length = length - 1;
		return stringBuilder.ToString();
	}

	// Token: 0x040001C2 RID: 450
	private StackFrame stackFrame_0;

	// Token: 0x040001C3 RID: 451
	private DateTime dateTime_0;

	// Token: 0x040001C4 RID: 452
	private GEnum7 genum7_0;

	// Token: 0x040001C5 RID: 453
	private string string_0;
}
