﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Token: 0x02000087 RID: 135
[Serializable]
public class GClass34 : IEnumerable<GClass33>, ICollection<GClass33>, IEnumerable
{
	// Token: 0x06000625 RID: 1573 RVA: 0x00006F92 File Offset: 0x00005192
	public GClass34()
	{
		this._list = new List<GClass33>();
		this._sync = ((ICollection)this._list).SyncRoot;
	}

	// Token: 0x17000196 RID: 406
	// (get) Token: 0x06000626 RID: 1574 RVA: 0x00006FB6 File Offset: 0x000051B6
	internal IList<GClass33> IList_0
	{
		get
		{
			return this._list;
		}
	}

	// Token: 0x17000197 RID: 407
	// (get) Token: 0x06000627 RID: 1575 RVA: 0x00034AEC File Offset: 0x00032CEC
	internal IEnumerable<GClass33> IEnumerable_0
	{
		get
		{
			List<GClass33> list = new List<GClass33>(this._list);
			if (list.Count > 1)
			{
				list.Sort(new Comparison<GClass33>(GClass34.smethod_1));
			}
			return list;
		}
	}

	// Token: 0x17000198 RID: 408
	// (get) Token: 0x06000628 RID: 1576 RVA: 0x00006FBE File Offset: 0x000051BE
	public int Count
	{
		get
		{
			return this._list.Count;
		}
	}

	// Token: 0x17000199 RID: 409
	// (get) Token: 0x06000629 RID: 1577 RVA: 0x00006FCB File Offset: 0x000051CB
	// (set) Token: 0x0600062A RID: 1578 RVA: 0x00006FD3 File Offset: 0x000051D3
	public bool IsReadOnly
	{
		get
		{
			return this._readOnly;
		}
		internal set
		{
			this._readOnly = value;
		}
	}

	// Token: 0x1700019A RID: 410
	// (get) Token: 0x0600062B RID: 1579 RVA: 0x00006FDC File Offset: 0x000051DC
	public bool Boolean_0
	{
		get
		{
			return false;
		}
	}

	// Token: 0x1700019B RID: 411
	public GClass33 this[int int_0]
	{
		get
		{
			if (int_0 < 0 || int_0 >= this._list.Count)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			return this._list[int_0];
		}
	}

	// Token: 0x1700019C RID: 412
	public GClass33 this[string string_0]
	{
		get
		{
			if (string_0 == null)
			{
				throw new ArgumentNullException("name");
			}
			StringComparison comparisonType = StringComparison.InvariantCultureIgnoreCase;
			foreach (GClass33 gclass in this.IEnumerable_0)
			{
				if (gclass.String_3.Equals(string_0, comparisonType))
				{
					return gclass;
				}
			}
			return null;
		}
	}

	// Token: 0x1700019D RID: 413
	// (get) Token: 0x0600062E RID: 1582 RVA: 0x0000700A File Offset: 0x0000520A
	public object Object_0
	{
		get
		{
			return this._sync;
		}
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00034B94 File Offset: 0x00032D94
	private void method_1(GClass33 gclass33_0)
	{
		int num = this.method_2(gclass33_0);
		if (num == -1)
		{
			this._list.Add(gclass33_0);
			return;
		}
		this._list[num] = gclass33_0;
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x00007012 File Offset: 0x00005212
	private static int smethod_0(GClass33 gclass33_0, GClass33 gclass33_1)
	{
		return gclass33_0.String_3.Length + gclass33_0.String_6.Length - (gclass33_1.String_3.Length + gclass33_1.String_6.Length);
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00034BC8 File Offset: 0x00032DC8
	private static int smethod_1(GClass33 gclass33_0, GClass33 gclass33_1)
	{
		int num = gclass33_0.Int32_2 - gclass33_1.Int32_2;
		if (num != 0)
		{
			return num;
		}
		if ((num = gclass33_0.String_3.CompareTo(gclass33_1.String_3)) == 0)
		{
			return gclass33_1.String_4.Length - gclass33_0.String_4.Length;
		}
		return num;
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00034C18 File Offset: 0x00032E18
	private static GClass34 smethod_2(string string_0)
	{
		GClass34 gclass = new GClass34();
		GClass33 gclass2 = null;
		int num = 0;
		StringComparison comparisonType = StringComparison.InvariantCultureIgnoreCase;
		List<string> list = string_0.smethod_59(new char[]
		{
			',',
			';'
		}).smethod_64<string>();
		for (int i = 0; i < list.Count; i++)
		{
			string text = list[i].Trim();
			if (text.Length != 0)
			{
				int num2 = text.IndexOf('=');
				if (num2 == -1)
				{
					if (gclass2 != null && text.Equals("$port", comparisonType))
					{
						gclass2.String_5 = "\"\"";
					}
				}
				else if (num2 == 0)
				{
					if (gclass2 != null)
					{
						gclass.method_1(gclass2);
						gclass2 = null;
					}
				}
				else
				{
					string text2 = text.Substring(0, num2).TrimEnd(new char[]
					{
						' '
					});
					string text3 = (num2 < text.Length - 1) ? text.Substring(num2 + 1).TrimStart(new char[]
					{
						' '
					}) : string.Empty;
					if (text2.Equals("$version", comparisonType))
					{
						int num3;
						if (text3.Length != 0 && int.TryParse(text3.smethod_76(), out num3))
						{
							num = num3;
						}
					}
					else if (text2.Equals("$path", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_4 = text3;
						}
					}
					else if (text2.Equals("$domain", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_2 = text3;
						}
					}
					else if (text2.Equals("$port", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_5 = text3;
						}
					}
					else
					{
						if (gclass2 != null)
						{
							gclass.method_1(gclass2);
						}
						if (GClass33.smethod_2(text2, text3, out gclass2) && num != 0)
						{
							gclass2.Int32_2 = num;
						}
					}
				}
			}
		}
		if (gclass2 != null)
		{
			gclass.method_1(gclass2);
		}
		return gclass;
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00034DF4 File Offset: 0x00032FF4
	private static GClass34 smethod_3(string string_0)
	{
		GClass34 gclass = new GClass34();
		GClass33 gclass2 = null;
		StringComparison comparisonType = StringComparison.InvariantCultureIgnoreCase;
		List<string> list = string_0.smethod_59(new char[]
		{
			',',
			';'
		}).smethod_64<string>();
		for (int i = 0; i < list.Count; i++)
		{
			string text = list[i].Trim();
			if (text.Length != 0)
			{
				int num = text.IndexOf('=');
				if (num == -1)
				{
					if (gclass2 != null)
					{
						if (text.Equals("port", comparisonType))
						{
							gclass2.String_5 = "\"\"";
						}
						else if (text.Equals("discard", comparisonType))
						{
							gclass2.Boolean_1 = true;
						}
						else if (text.Equals("secure", comparisonType))
						{
							gclass2.Boolean_4 = true;
						}
						else if (text.Equals("httponly", comparisonType))
						{
							gclass2.Boolean_3 = true;
						}
					}
				}
				else if (num == 0)
				{
					if (gclass2 != null)
					{
						gclass.method_1(gclass2);
						gclass2 = null;
					}
				}
				else
				{
					string text2 = text.Substring(0, num).TrimEnd(new char[]
					{
						' '
					});
					string text3 = (num < text.Length - 1) ? text.Substring(num + 1).TrimStart(new char[]
					{
						' '
					}) : string.Empty;
					if (text2.Equals("version", comparisonType))
					{
						int int32_;
						if (gclass2 != null && text3.Length != 0 && int.TryParse(text3.smethod_76(), out int32_))
						{
							gclass2.Int32_2 = int32_;
						}
					}
					else if (text2.Equals("expires", comparisonType))
					{
						if (text3.Length != 0)
						{
							if (i == list.Count - 1)
							{
								break;
							}
							i++;
							if (gclass2 != null && !(gclass2.DateTime_0 != DateTime.MinValue))
							{
								StringBuilder stringBuilder = new StringBuilder(text3, 32);
								stringBuilder.AppendFormat(", {0}", list[i].Trim());
								DateTime dateTime;
								if (DateTime.TryParseExact(stringBuilder.ToString(), new string[]
								{
									"ddd, dd'-'MMM'-'yyyy HH':'mm':'ss 'GMT'",
									"r"
								}, CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out dateTime))
								{
									gclass2.DateTime_0 = dateTime.ToLocalTime();
								}
							}
						}
					}
					else if (text2.Equals("max-age", comparisonType))
					{
						int int32_2;
						if (gclass2 != null && text3.Length != 0 && int.TryParse(text3.smethod_76(), out int32_2))
						{
							gclass2.Int32_0 = int32_2;
						}
					}
					else if (text2.Equals("path", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_4 = text3;
						}
					}
					else if (text2.Equals("domain", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_2 = text3;
						}
					}
					else if (text2.Equals("port", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_5 = text3;
						}
					}
					else if (text2.Equals("comment", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_1 = GClass34.smethod_4(text3, Encoding.UTF8);
						}
					}
					else if (text2.Equals("commenturl", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.Uri_0 = text3.smethod_76().smethod_105();
						}
					}
					else if (text2.Equals("samesite", comparisonType))
					{
						if (gclass2 != null && text3.Length != 0)
						{
							gclass2.String_0 = text3.smethod_76();
						}
					}
					else
					{
						if (gclass2 != null)
						{
							gclass.method_1(gclass2);
						}
						GClass33.smethod_2(text2, text3, out gclass2);
					}
				}
			}
		}
		if (gclass2 != null)
		{
			gclass.method_1(gclass2);
		}
		return gclass;
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x000351BC File Offset: 0x000333BC
	private int method_2(GClass33 gclass33_0)
	{
		for (int i = this._list.Count - 1; i >= 0; i--)
		{
			if (this._list[i].method_3(gclass33_0))
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x000351F8 File Offset: 0x000333F8
	private static string smethod_4(string string_0, Encoding encoding_0)
	{
		if (string_0.IndexOfAny(new char[]
		{
			'%',
			'+'
		}) == -1)
		{
			return string_0;
		}
		string result;
		try
		{
			result = Class78.smethod_27(string_0, encoding_0);
		}
		catch
		{
			result = null;
		}
		return result;
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00035244 File Offset: 0x00033444
	internal static GClass34 smethod_5(string string_0, bool bool_0)
	{
		GClass34 result;
		try
		{
			result = (bool_0 ? GClass34.smethod_3(string_0) : GClass34.smethod_2(string_0));
		}
		catch (Exception exception_)
		{
			throw new GException4("It could not be parsed.", exception_);
		}
		return result;
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x00035284 File Offset: 0x00033484
	internal void method_3(GClass33 gclass33_0)
	{
		int num = this.method_2(gclass33_0);
		if (num == -1)
		{
			if (gclass33_0.Boolean_2)
			{
				return;
			}
			this._list.Add(gclass33_0);
			return;
		}
		else
		{
			if (gclass33_0.Boolean_2)
			{
				this._list.RemoveAt(num);
				return;
			}
			this._list[num] = gclass33_0;
			return;
		}
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x000352D8 File Offset: 0x000334D8
	internal void method_4(GClass34 gclass34_0)
	{
		foreach (GClass33 gclass33_ in gclass34_0._list)
		{
			this.method_3(gclass33_);
		}
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x00007043 File Offset: 0x00005243
	internal void method_5()
	{
		if (this._list.Count > 1)
		{
			this._list.Sort(new Comparison<GClass33>(GClass34.smethod_0));
		}
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x0000706A File Offset: 0x0000526A
	public void Add(GClass33 cookie)
	{
		if (this._readOnly)
		{
			throw new InvalidOperationException("The collection is read-only.");
		}
		if (cookie == null)
		{
			throw new ArgumentNullException("cookie");
		}
		this.method_1(cookie);
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x0003532C File Offset: 0x0003352C
	public void method_6(GClass34 gclass34_0)
	{
		if (this._readOnly)
		{
			throw new InvalidOperationException("The collection is read-only.");
		}
		if (gclass34_0 == null)
		{
			throw new ArgumentNullException("cookies");
		}
		foreach (GClass33 gclass33_ in gclass34_0._list)
		{
			this.method_1(gclass33_);
		}
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x00007094 File Offset: 0x00005294
	public void Clear()
	{
		if (this._readOnly)
		{
			throw new InvalidOperationException("The collection is read-only.");
		}
		this._list.Clear();
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x000070B4 File Offset: 0x000052B4
	public bool Contains(GClass33 cookie)
	{
		if (cookie == null)
		{
			throw new ArgumentNullException("cookie");
		}
		return this.method_2(cookie) > -1;
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x000353A4 File Offset: 0x000335A4
	public void CopyTo(GClass33[] array, int index)
	{
		if (array == null)
		{
			throw new ArgumentNullException("array");
		}
		if (index < 0)
		{
			throw new ArgumentOutOfRangeException("index", "Less than zero.");
		}
		if (array.Length - index < this._list.Count)
		{
			throw new ArgumentException("The available space of the array is not enough to copy to.");
		}
		this._list.CopyTo(array, index);
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x000070CE File Offset: 0x000052CE
	public IEnumerator<GClass33> GetEnumerator()
	{
		return this._list.GetEnumerator();
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x00035400 File Offset: 0x00033600
	public bool Remove(GClass33 cookie)
	{
		if (this._readOnly)
		{
			throw new InvalidOperationException("The collection is read-only.");
		}
		if (cookie == null)
		{
			throw new ArgumentNullException("cookie");
		}
		int num = this.method_2(cookie);
		if (num == -1)
		{
			return false;
		}
		this._list.RemoveAt(num);
		return true;
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x000070CE File Offset: 0x000052CE
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this._list.GetEnumerator();
	}

	// Token: 0x04000304 RID: 772
	private List<GClass33> _list;

	// Token: 0x04000305 RID: 773
	private bool _readOnly;

	// Token: 0x04000306 RID: 774
	private object _sync;
}
