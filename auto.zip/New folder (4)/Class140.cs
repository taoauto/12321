﻿using System;

// Token: 0x0200015C RID: 348
[Serializable]
internal class Class140
{
	// Token: 0x1700043F RID: 1087
	// (get) Token: 0x06001086 RID: 4230 RVA: 0x0000D647 File Offset: 0x0000B847
	// (set) Token: 0x06001087 RID: 4231 RVA: 0x0000D64F File Offset: 0x0000B84F
	public string String_0
	{
		get
		{
			return this.mimeType;
		}
		set
		{
			this.mimeType = value;
		}
	}

	// Token: 0x17000440 RID: 1088
	// (get) Token: 0x06001088 RID: 4232 RVA: 0x0000D658 File Offset: 0x0000B858
	// (set) Token: 0x06001089 RID: 4233 RVA: 0x0000D660 File Offset: 0x0000B860
	public bool Boolean_0
	{
		get
		{
			return this.acceptRanges;
		}
		set
		{
			this.acceptRanges = value;
		}
	}

	// Token: 0x17000441 RID: 1089
	// (get) Token: 0x0600108A RID: 4234 RVA: 0x0000D669 File Offset: 0x0000B869
	// (set) Token: 0x0600108B RID: 4235 RVA: 0x0000D671 File Offset: 0x0000B871
	public long Int64_0
	{
		get
		{
			return this.fileSize;
		}
		set
		{
			this.fileSize = value;
		}
	}

	// Token: 0x17000442 RID: 1090
	// (get) Token: 0x0600108C RID: 4236 RVA: 0x0000D67A File Offset: 0x0000B87A
	// (set) Token: 0x0600108D RID: 4237 RVA: 0x0000D682 File Offset: 0x0000B882
	public DateTime DateTime_0
	{
		get
		{
			return this.lastModified;
		}
		set
		{
			this.lastModified = value;
		}
	}

	// Token: 0x0400085D RID: 2141
	private bool acceptRanges;

	// Token: 0x0400085E RID: 2142
	private long fileSize;

	// Token: 0x0400085F RID: 2143
	private DateTime lastModified = DateTime.MinValue;

	// Token: 0x04000860 RID: 2144
	private string mimeType;
}
