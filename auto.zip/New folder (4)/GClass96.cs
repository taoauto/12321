﻿using System;
using System.Text.RegularExpressions;

// Token: 0x0200012A RID: 298
public class GClass96
{
	// Token: 0x170003DC RID: 988
	// (get) Token: 0x06000EE0 RID: 3808 RVA: 0x0000C8E2 File Offset: 0x0000AAE2
	public Regex Regex_0
	{
		get
		{
			if (this.regex_0 == null)
			{
				this.regex_0 = new Regex(this.string_0, GClass98.RegexOptions_0 | this.regexOptions_0);
			}
			return this.regex_0;
		}
	}

	// Token: 0x0400076F RID: 1903
	private Regex regex_0;

	// Token: 0x04000770 RID: 1904
	public string string_0;

	// Token: 0x04000771 RID: 1905
	public RegexOptions regexOptions_0;

	// Token: 0x04000772 RID: 1906
	public GClass87 gclass87_0;
}
