﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x02000009 RID: 9
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Class2
{
	// Token: 0x06000020 RID: 32 RVA: 0x00002E70 File Offset: 0x00001070
	internal Class2()
	{
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000021 RID: 33 RVA: 0x00002F52 File Offset: 0x00001152
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			if (Class2.resourceManager_0 == null)
			{
				Class2.resourceManager_0 = new ResourceManager("‮‏‌‫⁫⁫⁪‍‪​⁬‬⁭⁫‫⁬‌‍⁫⁭‏‫‭‪⁬⁬‮⁭⁮‍‌‎‬‫⁬‫‫⁬​⁬‮", typeof(Class2).Assembly);
			}
			return Class2.resourceManager_0;
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000022 RID: 34 RVA: 0x00002F7E File Offset: 0x0000117E
	// (set) Token: 0x06000023 RID: 35 RVA: 0x00002F85 File Offset: 0x00001185
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return Class2.cultureInfo_0;
		}
		set
		{
			Class2.cultureInfo_0 = value;
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000024 RID: 36 RVA: 0x00002F8D File Offset: 0x0000118D
	internal static string String_0
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_CanNotReadOrSeek", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000025 RID: 37 RVA: 0x00002FA3 File Offset: 0x000011A3
	internal static string String_1
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_EmptyString", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000026 RID: 38 RVA: 0x00002FB9 File Offset: 0x000011B9
	internal static string String_2
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_HttpRequest_SetNotAvailableHeader", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000027 RID: 39 RVA: 0x00002FCF File Offset: 0x000011CF
	internal static string String_3
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_MultiThreading_BegIndexRangeMoreEndIndex", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000028 RID: 40 RVA: 0x00002FE5 File Offset: 0x000011E5
	internal static string String_4
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_OnlyAbsoluteUri", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000029 RID: 41 RVA: 0x00002FFB File Offset: 0x000011FB
	internal static string String_5
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentException_WrongPath", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x0600002A RID: 42 RVA: 0x00003011 File Offset: 0x00001211
	internal static string String_6
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentOutOfRangeException_CanNotBeGreater", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600002B RID: 43 RVA: 0x00003027 File Offset: 0x00001227
	internal static string String_7
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentOutOfRangeException_CanNotBeLess", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600002C RID: 44 RVA: 0x0000303D File Offset: 0x0000123D
	internal static string String_8
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentOutOfRangeException_CanNotBeLessOrGreater", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600002D RID: 45 RVA: 0x00003053 File Offset: 0x00001253
	internal static string String_9
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentOutOfRangeException_StringHelper_MoreLengthString", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600002E RID: 46 RVA: 0x00003069 File Offset: 0x00001269
	internal static string String_10
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ArgumentOutOfRangeException_StringLengthCanNotBeMore", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x0600002F RID: 47 RVA: 0x0000307F File Offset: 0x0000127F
	internal static string String_11
	{
		get
		{
			return Class2.ResourceManager_0.GetString("DirectoryNotFoundException_DirectoryNotFound", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000030 RID: 48 RVA: 0x00003095 File Offset: 0x00001295
	internal static string String_12
	{
		get
		{
			return Class2.ResourceManager_0.GetString("FormatException_ProxyClient_WrongPort", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000031 RID: 49 RVA: 0x000030AB File Offset: 0x000012AB
	internal static string String_13
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_ClientError", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000032 RID: 50 RVA: 0x000030C1 File Offset: 0x000012C1
	internal static string String_14
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_ConnectTimeout", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x06000033 RID: 51 RVA: 0x000030D7 File Offset: 0x000012D7
	internal static string String_15
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_Default", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x06000034 RID: 52 RVA: 0x000030ED File Offset: 0x000012ED
	internal static string String_16
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedConnect", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000035 RID: 53 RVA: 0x00003103 File Offset: 0x00001303
	internal static string String_17
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedGetHostAddresses", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000036 RID: 54 RVA: 0x00003119 File Offset: 0x00001319
	internal static string String_18
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedReceiveMessageBody", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000037 RID: 55 RVA: 0x0000312F File Offset: 0x0000132F
	internal static string String_19
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedReceiveResponse", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000038 RID: 56 RVA: 0x00003145 File Offset: 0x00001345
	internal static string String_20
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedSendRequest", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000039 RID: 57 RVA: 0x0000315B File Offset: 0x0000135B
	internal static string String_21
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_FailedSslConnect", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600003A RID: 58 RVA: 0x00003171 File Offset: 0x00001371
	internal static string String_22
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_LimitRedirections", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x0600003B RID: 59 RVA: 0x00003187 File Offset: 0x00001387
	internal static string String_23
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_ReceivedEmptyResponse", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x0600003C RID: 60 RVA: 0x0000319D File Offset: 0x0000139D
	internal static string String_24
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_ReceivedWrongResponse", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x0600003D RID: 61 RVA: 0x000031B3 File Offset: 0x000013B3
	internal static string String_25
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_SeverError", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x0600003E RID: 62 RVA: 0x000031C9 File Offset: 0x000013C9
	internal static string String_26
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_WaitDataTimeout", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x0600003F RID: 63 RVA: 0x000031DF File Offset: 0x000013DF
	internal static string String_27
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_WrongChunkedBlockLength", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000040 RID: 64 RVA: 0x000031F5 File Offset: 0x000013F5
	internal static string String_28
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_WrongCookie", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000041 RID: 65 RVA: 0x0000320B File Offset: 0x0000140B
	internal static string String_29
	{
		get
		{
			return Class2.ResourceManager_0.GetString("HttpException_WrongHeader", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000042 RID: 66 RVA: 0x00003221 File Offset: 0x00001421
	internal static string String_30
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_ChainProxyClient_NotProxies", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000043 RID: 67 RVA: 0x00003237 File Offset: 0x00001437
	internal static string String_31
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_HttpResponse_HasError", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000044 RID: 68 RVA: 0x0000324D File Offset: 0x0000144D
	internal static string String_32
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_NotSupportedEncodingFormat", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000045 RID: 69 RVA: 0x00003263 File Offset: 0x00001463
	internal static string String_33
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_ProxyClient_WrongHost", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000046 RID: 70 RVA: 0x00003279 File Offset: 0x00001479
	internal static string String_34
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_ProxyClient_WrongPassword", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000047 RID: 71 RVA: 0x0000328F File Offset: 0x0000148F
	internal static string String_35
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_ProxyClient_WrongPort", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000048 RID: 72 RVA: 0x000032A5 File Offset: 0x000014A5
	internal static string String_36
	{
		get
		{
			return Class2.ResourceManager_0.GetString("InvalidOperationException_ProxyClient_WrongUsername", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000049 RID: 73 RVA: 0x000032BB File Offset: 0x000014BB
	internal static string String_37
	{
		get
		{
			return Class2.ResourceManager_0.GetString("NetException_Default", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600004A RID: 74 RVA: 0x000032D1 File Offset: 0x000014D1
	internal static string String_38
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_CommandError", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600004B RID: 75 RVA: 0x000032E7 File Offset: 0x000014E7
	internal static string String_39
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_ConnectTimeout", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600004C RID: 76 RVA: 0x000032FD File Offset: 0x000014FD
	internal static string String_40
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_Default", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x0600004D RID: 77 RVA: 0x00003313 File Offset: 0x00001513
	internal static string String_41
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_Error", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x0600004E RID: 78 RVA: 0x00003329 File Offset: 0x00001529
	internal static string String_42
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_FailedConnect", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x0600004F RID: 79 RVA: 0x0000333F File Offset: 0x0000153F
	internal static string String_43
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_FailedGetHostAddresses", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000050 RID: 80 RVA: 0x00003355 File Offset: 0x00001555
	internal static string String_44
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_NotSupportedAddressType", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000051 RID: 81 RVA: 0x0000336B File Offset: 0x0000156B
	internal static string String_45
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_ReceivedEmptyResponse", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000052 RID: 82 RVA: 0x00003381 File Offset: 0x00001581
	internal static string String_46
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_ReceivedWrongResponse", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000053 RID: 83 RVA: 0x00003397 File Offset: 0x00001597
	internal static string String_47
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_ReceivedWrongStatusCode", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000054 RID: 84 RVA: 0x000033AD File Offset: 0x000015AD
	internal static string String_48
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_Socks5_FailedAuthOn", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000055 RID: 85 RVA: 0x000033C3 File Offset: 0x000015C3
	internal static string String_49
	{
		get
		{
			return Class2.ResourceManager_0.GetString("ProxyException_WaitDataTimeout", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000056 RID: 86 RVA: 0x000033D9 File Offset: 0x000015D9
	internal static string String_50
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks_UnknownError", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000037 RID: 55
	// (get) Token: 0x06000057 RID: 87 RVA: 0x000033EF File Offset: 0x000015EF
	internal static string String_51
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks4_CommandReplyRequestRejectedCannotConnectToIdentd", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x06000058 RID: 88 RVA: 0x00003405 File Offset: 0x00001605
	internal static string String_52
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks4_CommandReplyRequestRejectedDifferentIdentd", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x06000059 RID: 89 RVA: 0x0000341B File Offset: 0x0000161B
	internal static string String_53
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks4_CommandReplyRequestRejectedOrFailed", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600005A RID: 90 RVA: 0x00003431 File Offset: 0x00001631
	internal static string String_54
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_AuthMethodReplyNoAcceptableMethods", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x0600005B RID: 91 RVA: 0x00003447 File Offset: 0x00001647
	internal static string String_55
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyAddressTypeNotSupported", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x0600005C RID: 92 RVA: 0x0000345D File Offset: 0x0000165D
	internal static string String_56
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyCommandNotSupported", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x0600005D RID: 93 RVA: 0x00003473 File Offset: 0x00001673
	internal static string String_57
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyConnectionNotAllowedByRuleset", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x0600005E RID: 94 RVA: 0x00003489 File Offset: 0x00001689
	internal static string String_58
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyConnectionRefused", Class2.cultureInfo_0);
		}
	}

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x0600005F RID: 95 RVA: 0x0000349F File Offset: 0x0000169F
	internal static string String_59
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyGeneralSocksServerFailure", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x06000060 RID: 96 RVA: 0x000034B5 File Offset: 0x000016B5
	internal static string String_60
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyHostUnreachable", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x06000061 RID: 97 RVA: 0x000034CB File Offset: 0x000016CB
	internal static string String_61
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyNetworkUnreachable", Class2.cultureInfo_0);
		}
	}

	// Token: 0x17000042 RID: 66
	// (get) Token: 0x06000062 RID: 98 RVA: 0x000034E1 File Offset: 0x000016E1
	internal static string String_62
	{
		get
		{
			return Class2.ResourceManager_0.GetString("Socks5_CommandReplyTTLExpired", Class2.cultureInfo_0);
		}
	}

	// Token: 0x04000006 RID: 6
	private static ResourceManager resourceManager_0;

	// Token: 0x04000007 RID: 7
	private static CultureInfo cultureInfo_0;
}
