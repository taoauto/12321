﻿using System;
using System.Drawing;

// Token: 0x02000137 RID: 311
public class GClass103 : GClass101
{
	// Token: 0x06000F97 RID: 3991 RVA: 0x0000CEC1 File Offset: 0x0000B0C1
	public GClass103(int int_1, Rectangle rectangle_1) : base(rectangle_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000F98 RID: 3992 RVA: 0x000592C8 File Offset: 0x000574C8
	public void method_0(Graphics graphics_0, Pen pen_0, Brush brush_0, Pen pen_1)
	{
		graphics_0.FillRectangle(brush_0, this.rectangle_0);
		graphics_0.DrawRectangle(pen_0, this.rectangle_0);
		graphics_0.DrawLine(pen_1, this.rectangle_0.Left + 2, this.rectangle_0.Top + this.rectangle_0.Height / 2, this.rectangle_0.Right - 2, this.rectangle_0.Top + this.rectangle_0.Height / 2);
		graphics_0.DrawLine(pen_1, this.rectangle_0.Left + this.rectangle_0.Width / 2, this.rectangle_0.Top + 2, this.rectangle_0.Left + this.rectangle_0.Width / 2, this.rectangle_0.Bottom - 2);
	}

	// Token: 0x04000806 RID: 2054
	public readonly int int_0;
}
