﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x020000AD RID: 173
internal class Class84 : GClass46
{
	// Token: 0x06000851 RID: 2129 RVA: 0x0003C1E0 File Offset: 0x0003A3E0
	internal Class84(TcpClient tcpClient_1, string string_0, bool bool_1, GClass44 gclass44_0, GClass24 gclass24_1)
	{
		this.tcpClient_0 = tcpClient_1;
		this.bool_0 = bool_1;
		this.gclass24_0 = gclass24_1;
		NetworkStream stream = tcpClient_1.GetStream();
		if (bool_1)
		{
			SslStream sslStream = new SslStream(stream, false, gclass44_0.RemoteCertificateValidationCallback_0);
			sslStream.AuthenticateAsServer(gclass44_0.X509Certificate2_0, gclass44_0.Boolean_1, gclass44_0.SslProtocols_0, gclass44_0.Boolean_0);
			this.stream_0 = sslStream;
		}
		else
		{
			this.stream_0 = stream;
		}
		Socket client = tcpClient_1.Client;
		this.endPoint_0 = client.LocalEndPoint;
		this.endPoint_1 = client.RemoteEndPoint;
		this.class26_0 = Class26.smethod_6(this.stream_0, 90000);
		this.gclass25_0 = new GClass25(this, string_0);
	}

	// Token: 0x17000249 RID: 585
	// (get) Token: 0x06000852 RID: 2130 RVA: 0x00008761 File Offset: 0x00006961
	internal GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
	}

	// Token: 0x1700024A RID: 586
	// (get) Token: 0x06000853 RID: 2131 RVA: 0x00008769 File Offset: 0x00006969
	internal Stream Stream_0
	{
		get
		{
			return this.stream_0;
		}
	}

	// Token: 0x1700024B RID: 587
	// (get) Token: 0x06000854 RID: 2132 RVA: 0x00008771 File Offset: 0x00006971
	public override GClass34 \u206E\u200B\u200E\u206F\u200C\u206E\u202C\u202A\u206E\u206A\u202D\u202E\u200C\u200B\u202B\u206B\u202B\u206C\u200B\u202A\u202A\u202B\u200F\u200C\u200F\u202B\u206F\u206D\u200D\u200C\u202C\u200B\u206F\u200F\u200F\u206A\u202E\u206B\u202A\u206B\u202E
	{
		get
		{
			return this.class26_0.GClass34_0;
		}
	}

	// Token: 0x1700024C RID: 588
	// (get) Token: 0x06000855 RID: 2133 RVA: 0x0000877E File Offset: 0x0000697E
	public override NameValueCollection \u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E
	{
		get
		{
			return this.class26_0.NameValueCollection_0;
		}
	}

	// Token: 0x1700024D RID: 589
	// (get) Token: 0x06000856 RID: 2134 RVA: 0x0000878B File Offset: 0x0000698B
	public override string \u206A\u200F\u206E\u206E\u206F\u200F\u200E\u206C\u200E\u200C\u206D\u200B\u202A\u206C\u206B\u200D\u200D\u200C\u202E\u202A\u202C\u200E\u206D\u206D\u200C\u206A\u202B\u200E\u200D\u206B\u200C\u200B\u206C\u202C\u206E\u202A\u202C\u206C\u202C\u202E\u202E
	{
		get
		{
			return this.class26_0.NameValueCollection_0["Host"];
		}
	}

	// Token: 0x1700024E RID: 590
	// (get) Token: 0x06000857 RID: 2135 RVA: 0x000087A2 File Offset: 0x000069A2
	public override bool \u200E\u206C\u200E\u206B\u202D\u200E\u202A\u200F\u202A\u206C\u200B\u206A\u206B\u200B\u202D\u202D\u202E\u202E\u200F\u206B\u202C\u200C\u206C\u202B\u206B\u206B\u206D\u200E\u206F\u200B\u206C\u206B\u206A\u202B\u202C\u202C\u206A\u202A\u206C\u202A\u202E
	{
		get
		{
			return this.iprincipal_0 != null;
		}
	}

	// Token: 0x1700024F RID: 591
	// (get) Token: 0x06000858 RID: 2136 RVA: 0x000087AD File Offset: 0x000069AD
	public override bool \u202C\u202C\u200C\u200E\u202B\u206D\u206D\u206B\u206C\u202B\u200B\u206A\u200E\u200E\u200B\u206F\u200C\u202E\u202B\u200C\u200D\u206E\u206F\u202D\u206F\u202A\u202E\u206B\u206C\u202A\u202C\u200E\u202C\u202A\u202A\u202C\u206D\u200E\u200E\u200C\u202E
	{
		get
		{
			return this.GClass46.\u202D\u200D\u202A\u200B\u206B\u202E\u206F\u202A\u206C\u206F\u200B\u206C\u202C\u200B\u206A\u206C\u200D\u200D\u202D\u206A\u206B\u206D\u206D\u206C\u206E\u206F\u200C\u206F\u206A\u206E\u206D\u202B\u206B\u206F\u206B\u202C\u206B\u206F\u202A\u206F\u202E.Address.smethod_87();
		}
	}

	// Token: 0x17000250 RID: 592
	// (get) Token: 0x06000859 RID: 2137 RVA: 0x000087BF File Offset: 0x000069BF
	public override bool \u202A\u206B\u206D\u206A\u200C\u206D\u200E\u206F\u200E\u200E\u200B\u200D\u206D\u200E\u206E\u200D\u202C\u200B\u202D\u202C\u202A\u206F\u200B\u200C\u202A\u206E\u206D\u206E\u202C\u202D\u200B\u206E\u202B\u202D\u202E\u200C\u206D\u202B\u202A\u200E\u202E
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x17000251 RID: 593
	// (get) Token: 0x0600085A RID: 2138 RVA: 0x000087C7 File Offset: 0x000069C7
	public override bool \u206B\u206B\u206C\u206F\u202D\u202C\u202A\u206E\u202C\u200F\u206E\u202C\u202A\u206B\u200C\u206F\u200C\u202A\u206C\u206B\u202A\u206C\u206F\u200C\u206B\u200C\u200F\u206F\u200B\u206B\u200D\u206B\u206B\u200F\u202E\u206F\u200C\u200B\u200F\u200E\u202E
	{
		get
		{
			return this.class26_0.Boolean_0;
		}
	}

	// Token: 0x17000252 RID: 594
	// (get) Token: 0x0600085B RID: 2139 RVA: 0x000087D4 File Offset: 0x000069D4
	public override string \u200C\u202D\u200E\u202C\u202E\u206A\u206D\u206B\u206C\u202C\u202D\u202E\u206B\u206C\u200F\u202B\u200F\u200B\u202D\u206F\u202B\u206C\u206E\u206C\u200C\u206D\u202B\u202A\u200F\u206D\u202E\u200D\u206D\u206A\u206B\u200D\u202B\u200F\u200E\u206E\u202E
	{
		get
		{
			return this.class26_0.NameValueCollection_0["Origin"];
		}
	}

	// Token: 0x17000253 RID: 595
	// (get) Token: 0x0600085C RID: 2140 RVA: 0x0003C298 File Offset: 0x0003A498
	public override NameValueCollection \u206F\u206F\u206D\u202A\u206F\u202D\u200C\u202C\u202D\u200B\u206E\u202A\u202A\u200F\u200F\u206D\u202A\u206A\u206F\u202D\u202C\u200D\u202C\u206F\u200F\u200D\u200F\u200F\u202E\u200F\u206F\u200C\u206D\u200F\u200B\u202B\u200D\u206F\u202D\u202D\u202E
	{
		get
		{
			if (this.nameValueCollection_0 == null)
			{
				Uri uri = this.GClass46.\u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E;
				this.nameValueCollection_0 = Class79.smethod_2((uri != null) ? uri.Query : null, Encoding.UTF8);
			}
			return this.nameValueCollection_0;
		}
	}

	// Token: 0x17000254 RID: 596
	// (get) Token: 0x0600085D RID: 2141 RVA: 0x0003C2DC File Offset: 0x0003A4DC
	public override Uri \u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E
	{
		get
		{
			if (this.uri_0 == null)
			{
				this.uri_0 = Class78.smethod_15(this.class26_0.String_2, this.class26_0.NameValueCollection_0["Host"], this.class26_0.Boolean_0, this.bool_0);
			}
			return this.uri_0;
		}
	}

	// Token: 0x17000255 RID: 597
	// (get) Token: 0x0600085E RID: 2142 RVA: 0x000087EB File Offset: 0x000069EB
	public override string \u206F\u206B\u200F\u202B\u200D\u202E\u202B\u202B\u200D\u206E\u202C\u206D\u202A\u200D\u206E\u200B\u206E\u202B\u202D\u200F\u202E\u200B\u202A\u200C\u206C\u206E\u206C\u200B\u200F\u200B\u202E\u202A\u200C\u202D\u202E\u206D\u202A\u206E\u206F\u206A\u202E
	{
		get
		{
			return this.class26_0.NameValueCollection_0["Sec-WebSocket-Key"];
		}
	}

	// Token: 0x17000256 RID: 598
	// (get) Token: 0x0600085F RID: 2143 RVA: 0x00008802 File Offset: 0x00006A02
	public override IEnumerable<string> \u202C\u206C\u200B\u200F\u202B\u200C\u202E\u200D\u200E\u206C\u206E\u206E\u202B\u200B\u202D\u202B\u206F\u206B\u206A\u202E\u202C\u206E\u206C\u202E\u206C\u206A\u206E\u200F\u200E\u202A\u202A\u200E\u202A\u202B\u206D\u200D\u206E\u200C\u206C\u202C\u202E
	{
		get
		{
			string text = this.class26_0.NameValueCollection_0["Sec-WebSocket-Protocol"];
			if (text != null && text.Length != 0)
			{
				string[] array = text.Split(new char[]
				{
					','
				});
				for (int i = 0; i < array.Length; i++)
				{
					string text2 = array[i].Trim();
					if (text2.Length != 0)
					{
						yield return text2;
					}
				}
				array = null;
				yield break;
			}
			yield break;
		}
	}

	// Token: 0x17000257 RID: 599
	// (get) Token: 0x06000860 RID: 2144 RVA: 0x00008812 File Offset: 0x00006A12
	public override string \u202B\u202C\u200E\u206E\u202E\u200D\u206A\u206F\u206D\u200C\u200F\u202B\u206C\u200E\u200E\u206A\u202A\u202E\u206B\u206F\u200B\u206F\u202D\u206A\u202A\u202E\u206A\u202C\u206E\u200B\u200E\u206A\u206F\u206B\u206B\u206B\u206D\u200E\u200E\u202A\u202E
	{
		get
		{
			return this.class26_0.NameValueCollection_0["Sec-WebSocket-Version"];
		}
	}

	// Token: 0x17000258 RID: 600
	// (get) Token: 0x06000861 RID: 2145 RVA: 0x00008829 File Offset: 0x00006A29
	public override IPEndPoint \u200B\u202E\u206C\u206F\u202B\u206C\u200D\u206A\u200D\u200F\u206A\u200C\u206B\u206F\u206C\u202D\u206B\u202D\u202D\u206F\u206C\u200F\u202C\u202D\u200C\u200C\u202B\u206E\u200E\u202A\u200D\u200B\u202B\u200D\u206F\u202E\u206B\u202E\u200E\u202C\u202E
	{
		get
		{
			return (IPEndPoint)this.endPoint_0;
		}
	}

	// Token: 0x17000259 RID: 601
	// (get) Token: 0x06000862 RID: 2146 RVA: 0x00008836 File Offset: 0x00006A36
	public override IPrincipal \u200B\u206A\u202D\u200C\u200E\u200C\u206F\u206B\u200E\u202B\u200D\u206E\u206A\u200F\u202E\u200F\u202D\u200E\u206E\u200B\u206B\u200D\u200F\u206B\u200F\u202E\u200D\u206A\u202B\u206C\u200B\u202C\u200C\u206B\u206A\u202E\u200B\u202C\u200D\u200E\u202E
	{
		get
		{
			return this.iprincipal_0;
		}
	}

	// Token: 0x1700025A RID: 602
	// (get) Token: 0x06000863 RID: 2147 RVA: 0x0000883E File Offset: 0x00006A3E
	public override IPEndPoint \u202D\u200D\u202A\u200B\u206B\u202E\u206F\u202A\u206C\u206F\u200B\u206C\u202C\u200B\u206A\u206C\u200D\u200D\u202D\u206A\u206B\u206D\u206D\u206C\u206E\u206F\u200C\u206F\u206A\u206E\u206D\u202B\u206B\u206F\u206B\u202C\u206B\u206F\u202A\u206F\u202E
	{
		get
		{
			return (IPEndPoint)this.endPoint_1;
		}
	}

	// Token: 0x1700025B RID: 603
	// (get) Token: 0x06000864 RID: 2148 RVA: 0x0000884B File Offset: 0x00006A4B
	public override GClass25 \u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E
	{
		get
		{
			return this.gclass25_0;
		}
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x0003C33C File Offset: 0x0003A53C
	private Class26 method_0(string string_0)
	{
		byte[] array = Class27.smethod_4(string_0).method_0();
		this.stream_0.Write(array, 0, array.Length);
		return Class26.smethod_6(this.stream_0, 15000);
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0003C378 File Offset: 0x0003A578
	internal bool method_1(WebSocketSharp.Net.AuthenticationSchemes authenticationSchemes_0, string string_0, Func<IIdentity, GClass43> func_0)
	{
		Class84.Class83 @class = new Class84.Class83();
		@class.class84_0 = this;
		@class.authenticationSchemes_0 = authenticationSchemes_0;
		@class.string_0 = string_0;
		@class.func_0 = func_0;
		@class.string_1 = new Class63(@class.authenticationSchemes_0, @class.string_0).ToString();
		@class.int_0 = -1;
		@class.func_1 = null;
		@class.func_1 = new Func<bool>(@class.method_0);
		return @class.func_1();
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x00008853 File Offset: 0x00006A53
	internal void method_2()
	{
		this.stream_0.Close();
		this.tcpClient_0.Close();
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x0003C3F0 File Offset: 0x0003A5F0
	internal void method_3(GEnum9 genum9_0)
	{
		byte[] array = Class27.smethod_3(genum9_0).method_0();
		this.stream_0.Write(array, 0, array.Length);
		this.stream_0.Close();
		this.tcpClient_0.Close();
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0000886B File Offset: 0x00006A6B
	public virtual string ToString()
	{
		return this.class26_0.ToString();
	}

	// Token: 0x0400045B RID: 1115
	private GClass24 gclass24_0;

	// Token: 0x0400045C RID: 1116
	private NameValueCollection nameValueCollection_0;

	// Token: 0x0400045D RID: 1117
	private Class26 class26_0;

	// Token: 0x0400045E RID: 1118
	private Uri uri_0;

	// Token: 0x0400045F RID: 1119
	private bool bool_0;

	// Token: 0x04000460 RID: 1120
	private EndPoint endPoint_0;

	// Token: 0x04000461 RID: 1121
	private Stream stream_0;

	// Token: 0x04000462 RID: 1122
	private TcpClient tcpClient_0;

	// Token: 0x04000463 RID: 1123
	private IPrincipal iprincipal_0;

	// Token: 0x04000464 RID: 1124
	private EndPoint endPoint_1;

	// Token: 0x04000465 RID: 1125
	private GClass25 gclass25_0;

	// Token: 0x020000AF RID: 175
	[CompilerGenerated]
	private sealed class Class83
	{
		// Token: 0x06000873 RID: 2163 RVA: 0x0003C53C File Offset: 0x0003A73C
		internal bool method_0()
		{
			int num = this.int_0;
			this.int_0 = num + 1;
			if (this.int_0 > 99)
			{
				return false;
			}
			IPrincipal principal = Class78.smethod_16(this.class84_0.class26_0.NameValueCollection_0["Authorization"], this.authenticationSchemes_0, this.string_0, this.class84_0.class26_0.String_1, this.func_0);
			if (principal != null && principal.Identity.IsAuthenticated)
			{
				this.class84_0.iprincipal_0 = principal;
				return true;
			}
			this.class84_0.class26_0 = this.class84_0.method_0(this.string_1);
			return this.func_1();
		}

		// Token: 0x0400046C RID: 1132
		public int int_0;

		// Token: 0x0400046D RID: 1133
		public Class84 class84_0;

		// Token: 0x0400046E RID: 1134
		public WebSocketSharp.Net.AuthenticationSchemes authenticationSchemes_0;

		// Token: 0x0400046F RID: 1135
		public string string_0;

		// Token: 0x04000470 RID: 1136
		public Func<IIdentity, GClass43> func_0;

		// Token: 0x04000471 RID: 1137
		public string string_1;

		// Token: 0x04000472 RID: 1138
		public Func<bool> func_1;
	}
}
