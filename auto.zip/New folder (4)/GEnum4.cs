﻿using System;

// Token: 0x02000032 RID: 50
public enum GEnum4
{
	// Token: 0x0400013D RID: 317
	Http,
	// Token: 0x0400013E RID: 318
	Socks4,
	// Token: 0x0400013F RID: 319
	Socks4a,
	// Token: 0x04000140 RID: 320
	Socks5,
	// Token: 0x04000141 RID: 321
	Chain
}
