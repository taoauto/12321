﻿using System;

// Token: 0x0200017B RID: 379
public enum GEnum23
{
	// Token: 0x04000990 RID: 2448
	ExportTable,
	// Token: 0x04000991 RID: 2449
	ImportTable,
	// Token: 0x04000992 RID: 2450
	ResourceTable,
	// Token: 0x04000993 RID: 2451
	ExceptionTable,
	// Token: 0x04000994 RID: 2452
	CertificateTable,
	// Token: 0x04000995 RID: 2453
	BaseRelocTable,
	// Token: 0x04000996 RID: 2454
	Debug,
	// Token: 0x04000997 RID: 2455
	Architecture,
	// Token: 0x04000998 RID: 2456
	GlobalPtr,
	// Token: 0x04000999 RID: 2457
	TLSTable,
	// Token: 0x0400099A RID: 2458
	LoadConfigTable,
	// Token: 0x0400099B RID: 2459
	BoundImport,
	// Token: 0x0400099C RID: 2460
	IAT,
	// Token: 0x0400099D RID: 2461
	DelayImportDescriptor,
	// Token: 0x0400099E RID: 2462
	CLRRuntimeHeader,
	// Token: 0x0400099F RID: 2463
	Reserved
}
