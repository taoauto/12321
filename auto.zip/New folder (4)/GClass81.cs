﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000107 RID: 263
public class GClass81 : IEnumerable, IList<GStruct0>, ICollection<GStruct0>, IEnumerable<GStruct0>
{
	// Token: 0x17000391 RID: 913
	// (get) Token: 0x06000D75 RID: 3445 RVA: 0x0000BA77 File Offset: 0x00009C77
	// (set) Token: 0x06000D76 RID: 3446 RVA: 0x0000BA7F File Offset: 0x00009C7F
	public string String_0 { get; set; }

	// Token: 0x17000392 RID: 914
	// (get) Token: 0x06000D77 RID: 3447 RVA: 0x0000BA88 File Offset: 0x00009C88
	// (set) Token: 0x06000D78 RID: 3448 RVA: 0x0000BA90 File Offset: 0x00009C90
	public string String_1 { get; set; }

	// Token: 0x17000393 RID: 915
	// (get) Token: 0x06000D79 RID: 3449 RVA: 0x0000BA99 File Offset: 0x00009C99
	// (set) Token: 0x06000D7A RID: 3450 RVA: 0x0000BAA1 File Offset: 0x00009CA1
	public bool Boolean_0 { get; set; }

	// Token: 0x17000394 RID: 916
	// (get) Token: 0x06000D7B RID: 3451 RVA: 0x0000BAAA File Offset: 0x00009CAA
	// (set) Token: 0x06000D7C RID: 3452 RVA: 0x0000BAB2 File Offset: 0x00009CB2
	public DateTime DateTime_0 { get; set; }

	// Token: 0x17000395 RID: 917
	// (get) Token: 0x06000D7D RID: 3453 RVA: 0x0000BABB File Offset: 0x00009CBB
	// (set) Token: 0x06000D7E RID: 3454 RVA: 0x0000BAC3 File Offset: 0x00009CC3
	public Brush Brush_0 { get; set; }

	// Token: 0x17000396 RID: 918
	// (get) Token: 0x06000D7F RID: 3455 RVA: 0x0000BACC File Offset: 0x00009CCC
	// (set) Token: 0x06000D80 RID: 3456 RVA: 0x0000BAD4 File Offset: 0x00009CD4
	public int Int32_0 { get; private set; }

	// Token: 0x17000397 RID: 919
	// (get) Token: 0x06000D81 RID: 3457 RVA: 0x0000BADD File Offset: 0x00009CDD
	// (set) Token: 0x06000D82 RID: 3458 RVA: 0x0000BAE5 File Offset: 0x00009CE5
	public int Int32_1 { get; set; }

	// Token: 0x06000D83 RID: 3459 RVA: 0x0000BAEE File Offset: 0x00009CEE
	internal GClass81(int int_2)
	{
		this.Int32_0 = int_2;
		this.list_0 = new List<GStruct0>();
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x000507F0 File Offset: 0x0004E9F0
	public void method_0(StyleIndex styleIndex_0)
	{
		this.String_0 = null;
		this.String_1 = null;
		for (int i = 0; i < this.Count; i++)
		{
			GStruct0 value = this[i];
			value.styleIndex_0 &= ~styleIndex_0;
			this[i] = value;
		}
	}

	// Token: 0x17000398 RID: 920
	// (get) Token: 0x06000D85 RID: 3461 RVA: 0x0005083C File Offset: 0x0004EA3C
	public virtual string String_2
	{
		get
		{
			StringBuilder stringBuilder = new StringBuilder(this.Count);
			foreach (GStruct0 gstruct in this)
			{
				stringBuilder.Append(gstruct.char_0);
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x0000BB08 File Offset: 0x00009D08
	public void method_1()
	{
		this.String_0 = null;
		this.String_1 = null;
	}

	// Token: 0x17000399 RID: 921
	// (get) Token: 0x06000D87 RID: 3463 RVA: 0x000508A0 File Offset: 0x0004EAA0
	public int Int32_2
	{
		get
		{
			int num = 0;
			int num2 = 0;
			while (num2 < this.Count && this[num2].char_0 == ' ')
			{
				num++;
				num2++;
			}
			return num;
		}
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x0000BB18 File Offset: 0x00009D18
	public int IndexOf(GStruct0 item)
	{
		return this.list_0.IndexOf(item);
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x0000BB26 File Offset: 0x00009D26
	public void Insert(int index, GStruct0 item)
	{
		this.list_0.Insert(index, item);
	}

	// Token: 0x06000D8A RID: 3466 RVA: 0x0000BB35 File Offset: 0x00009D35
	public void RemoveAt(int index)
	{
		this.list_0.RemoveAt(index);
	}

	// Token: 0x1700039A RID: 922
	public GStruct0 this[int index]
	{
		get
		{
			return this.list_0[index];
		}
		set
		{
			this.list_0[index] = value;
		}
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x0000BB60 File Offset: 0x00009D60
	public void Add(GStruct0 item)
	{
		this.list_0.Add(item);
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0000BB6E File Offset: 0x00009D6E
	public void Clear()
	{
		this.list_0.Clear();
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x0000BB7B File Offset: 0x00009D7B
	public bool Contains(GStruct0 item)
	{
		return this.list_0.Contains(item);
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x0000BB89 File Offset: 0x00009D89
	public void CopyTo(GStruct0[] array, int arrayIndex)
	{
		this.list_0.CopyTo(array, arrayIndex);
	}

	// Token: 0x1700039B RID: 923
	// (get) Token: 0x06000D91 RID: 3473 RVA: 0x0000BB98 File Offset: 0x00009D98
	public int Count
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x1700039C RID: 924
	// (get) Token: 0x06000D92 RID: 3474 RVA: 0x00006FDC File Offset: 0x000051DC
	public bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x0000BBA5 File Offset: 0x00009DA5
	public bool Remove(GStruct0 item)
	{
		return this.list_0.Remove(item);
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x0000BBB3 File Offset: 0x00009DB3
	public IEnumerator<GStruct0> GetEnumerator()
	{
		return this.list_0.GetEnumerator();
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0000BBB3 File Offset: 0x00009DB3
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.list_0.GetEnumerator();
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x0000BBC5 File Offset: 0x00009DC5
	public virtual void vmethod_0(int int_2, int int_3)
	{
		if (int_2 >= this.Count)
		{
			return;
		}
		this.list_0.RemoveRange(int_2, Math.Min(this.Count - int_2, int_3));
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x0000BBEB File Offset: 0x00009DEB
	public virtual void vmethod_1()
	{
		this.list_0.TrimExcess();
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x0000BBF8 File Offset: 0x00009DF8
	public virtual void vmethod_2(IEnumerable<GStruct0> ienumerable_0)
	{
		this.list_0.AddRange(ienumerable_0);
	}

	// Token: 0x040006A4 RID: 1700
	protected List<GStruct0> list_0;

	// Token: 0x040006A5 RID: 1701
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040006A6 RID: 1702
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040006A7 RID: 1703
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040006A8 RID: 1704
	[CompilerGenerated]
	private DateTime dateTime_0;

	// Token: 0x040006A9 RID: 1705
	[CompilerGenerated]
	private Brush brush_0;

	// Token: 0x040006AA RID: 1706
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040006AB RID: 1707
	[CompilerGenerated]
	private int int_1;
}
