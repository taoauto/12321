﻿using System;
using System.Collections.Specialized;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x0200007D RID: 125
internal abstract class Class62
{
	// Token: 0x06000596 RID: 1430 RVA: 0x000068EE File Offset: 0x00004AEE
	protected Class62(AuthenticationSchemes authenticationSchemes_1, NameValueCollection nameValueCollection_1)
	{
		this.authenticationSchemes_0 = authenticationSchemes_1;
		this.nameValueCollection_0 = nameValueCollection_1;
	}

	// Token: 0x1700016A RID: 362
	// (get) Token: 0x06000597 RID: 1431 RVA: 0x00006904 File Offset: 0x00004B04
	public string String_0
	{
		get
		{
			return this.nameValueCollection_0["algorithm"];
		}
	}

	// Token: 0x1700016B RID: 363
	// (get) Token: 0x06000598 RID: 1432 RVA: 0x00006916 File Offset: 0x00004B16
	public string String_1
	{
		get
		{
			return this.nameValueCollection_0["nonce"];
		}
	}

	// Token: 0x1700016C RID: 364
	// (get) Token: 0x06000599 RID: 1433 RVA: 0x00006928 File Offset: 0x00004B28
	public string String_2
	{
		get
		{
			return this.nameValueCollection_0["opaque"];
		}
	}

	// Token: 0x1700016D RID: 365
	// (get) Token: 0x0600059A RID: 1434 RVA: 0x0000693A File Offset: 0x00004B3A
	public string String_3
	{
		get
		{
			return this.nameValueCollection_0["qop"];
		}
	}

	// Token: 0x1700016E RID: 366
	// (get) Token: 0x0600059B RID: 1435 RVA: 0x0000694C File Offset: 0x00004B4C
	public string String_4
	{
		get
		{
			return this.nameValueCollection_0["realm"];
		}
	}

	// Token: 0x1700016F RID: 367
	// (get) Token: 0x0600059C RID: 1436 RVA: 0x0000695E File Offset: 0x00004B5E
	public AuthenticationSchemes AuthenticationSchemes_0
	{
		get
		{
			return this.authenticationSchemes_0;
		}
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x000331E8 File Offset: 0x000313E8
	internal static string smethod_0()
	{
		byte[] array = new byte[16];
		new Random().NextBytes(array);
		StringBuilder stringBuilder = new StringBuilder(32);
		foreach (byte b in array)
		{
			stringBuilder.Append(b.ToString("x2"));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x00033240 File Offset: 0x00031440
	internal static NameValueCollection smethod_1(string string_0)
	{
		NameValueCollection nameValueCollection = new NameValueCollection();
		foreach (string text in string_0.smethod_59(new char[]
		{
			','
		}))
		{
			int num = text.IndexOf('=');
			string name = (num > 0) ? text.Substring(0, num).Trim() : null;
			string value = (num < 0) ? text.Trim().Trim(new char[]
			{
				'"'
			}) : ((num < text.Length - 1) ? text.Substring(num + 1).Trim().Trim(new char[]
			{
				'"'
			}) : string.Empty);
			nameValueCollection.Add(name, value);
		}
		return nameValueCollection;
	}

	// Token: 0x0600059F RID: 1439
	internal abstract string \u202E\u200F\u202D\u206F\u206C\u200B\u200F\u202C\u200F\u200D\u200F\u206F\u202C\u200C\u202A\u202D\u206F\u206A\u200E\u200B\u200B\u200E\u200E\u206C\u200D\u202E\u206A\u202A\u206A\u200E\u206F\u206E\u200E\u200B\u202A\u202E\u206B\u200D\u202E\u202C\u202E();

	// Token: 0x060005A0 RID: 1440
	internal abstract string \u206D\u206A\u200E\u202B\u200B\u202A\u206E\u200C\u206E\u202C\u206F\u202C\u206C\u206D\u202C\u206F\u206E\u206D\u200B\u200E\u202D\u202D\u206D\u200C\u200F\u206C\u202D\u206F\u206D\u200F\u206C\u200B\u202E\u200D\u206B\u206B\u200E\u206C\u200B\u206F\u202E();

	// Token: 0x060005A1 RID: 1441 RVA: 0x00006966 File Offset: 0x00004B66
	public virtual string ToString()
	{
		if (this.authenticationSchemes_0 == AuthenticationSchemes.Basic)
		{
			return this.Class62.\u202E\u200F\u202D\u206F\u206C\u200B\u200F\u202C\u200F\u200D\u200F\u206F\u202C\u200C\u202A\u202D\u206F\u206A\u200E\u200B\u200B\u200E\u200E\u206C\u200D\u202E\u206A\u202A\u206A\u200E\u206F\u206E\u200E\u200B\u202A\u202E\u206B\u200D\u202E\u202C\u202E();
		}
		if (this.authenticationSchemes_0 != AuthenticationSchemes.Digest)
		{
			return string.Empty;
		}
		return this.Class62.\u206D\u206A\u200E\u202B\u200B\u202A\u206E\u200C\u206E\u202C\u206F\u202C\u206C\u206D\u202C\u206F\u206E\u206D\u200B\u200E\u202D\u202D\u206D\u200C\u200F\u206C\u202D\u206F\u206D\u200F\u206C\u200B\u202E\u200D\u206B\u206B\u200E\u206C\u200B\u206F\u202E();
	}

	// Token: 0x040002D3 RID: 723
	private AuthenticationSchemes authenticationSchemes_0;

	// Token: 0x040002D4 RID: 724
	internal NameValueCollection nameValueCollection_0;
}
