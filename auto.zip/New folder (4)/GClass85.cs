﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000110 RID: 272
public static class GClass85
{
	// Token: 0x06000DD5 RID: 3541
	[DllImport("kernel32.dll")]
	private static extern void GetNativeSystemInfo(ref GClass85.Struct0 struct0_0);

	// Token: 0x06000DD6 RID: 3542
	[DllImport("kernel32.dll")]
	private static extern void GetSystemInfo(ref GClass85.Struct0 struct0_0);

	// Token: 0x06000DD7 RID: 3543 RVA: 0x00050E30 File Offset: 0x0004F030
	public static GEnum19 smethod_0()
	{
		GClass85.Struct0 @struct = default(GClass85.Struct0);
		if (Environment.OSVersion.Version.Major <= 5 && (Environment.OSVersion.Version.Major != 5 || Environment.OSVersion.Version.Minor < 1))
		{
			GClass85.GetSystemInfo(ref @struct);
		}
		else
		{
			GClass85.GetNativeSystemInfo(ref @struct);
		}
		ushort num = @struct.ushort_0;
		if (num != 0)
		{
			if (num != 6)
			{
				if (num != 9)
				{
					return GEnum19.Unknown;
				}
			}
			return GEnum19.X64;
		}
		return GEnum19.X86;
	}

	// Token: 0x040006C4 RID: 1732
	private const ushort ushort_0 = 0;

	// Token: 0x040006C5 RID: 1733
	private const ushort ushort_1 = 6;

	// Token: 0x040006C6 RID: 1734
	private const ushort ushort_2 = 9;

	// Token: 0x040006C7 RID: 1735
	private const ushort ushort_3 = 65535;

	// Token: 0x02000111 RID: 273
	private struct Struct0
	{
		// Token: 0x040006C8 RID: 1736
		public ushort ushort_0;

		// Token: 0x040006C9 RID: 1737
		public ushort ushort_1;

		// Token: 0x040006CA RID: 1738
		public uint uint_0;

		// Token: 0x040006CB RID: 1739
		public IntPtr intptr_0;

		// Token: 0x040006CC RID: 1740
		public IntPtr intptr_1;

		// Token: 0x040006CD RID: 1741
		public UIntPtr uintptr_0;

		// Token: 0x040006CE RID: 1742
		public uint uint_1;

		// Token: 0x040006CF RID: 1743
		public uint uint_2;

		// Token: 0x040006D0 RID: 1744
		public uint uint_3;

		// Token: 0x040006D1 RID: 1745
		public ushort ushort_2;

		// Token: 0x040006D2 RID: 1746
		public ushort ushort_3;
	}
}
