﻿using System;
using System.Text;

// Token: 0x02000313 RID: 787
internal class Class437 : Encoding
{
	// Token: 0x17000A9B RID: 2715
	// (get) Token: 0x06002DA3 RID: 11683 RVA: 0x00133AC0 File Offset: 0x00131CC0
	protected GClass128 GClass128_0
	{
		get
		{
			GClass128 gclass = this.gclass128_0;
			if (gclass == null)
			{
				gclass = (this.gclass128_0 = new GClass128());
			}
			DecoderFallback decoderFallback = base.DecoderFallback;
			if (decoderFallback != null && decoderFallback != gclass.Fallback)
			{
				gclass.Fallback = decoderFallback;
			}
			return gclass;
		}
	}

	// Token: 0x17000A9C RID: 2716
	// (get) Token: 0x06002DA4 RID: 11684 RVA: 0x00133B04 File Offset: 0x00131D04
	protected GClass129 GClass129_0
	{
		get
		{
			GClass129 gclass = this.gclass129_0;
			if (gclass == null)
			{
				gclass = (this.gclass129_0 = new GClass129());
			}
			EncoderFallback encoderFallback = base.EncoderFallback;
			if (encoderFallback != null && encoderFallback != gclass.Fallback)
			{
				gclass.Fallback = encoderFallback;
			}
			return gclass;
		}
	}

	// Token: 0x17000A9D RID: 2717
	// (get) Token: 0x06002DA5 RID: 11685 RVA: 0x000088A2 File Offset: 0x00006AA2
	public virtual string BodyName
	{
		get
		{
			return "viscii-simple";
		}
	}

	// Token: 0x17000A9E RID: 2718
	// (get) Token: 0x06002DA6 RID: 11686 RVA: 0x000088A9 File Offset: 0x00006AA9
	public virtual string EncodingName
	{
		get
		{
			return this.BodyName;
		}
	}

	// Token: 0x17000A9F RID: 2719
	// (get) Token: 0x06002DA7 RID: 11687 RVA: 0x0000354C File Offset: 0x0000174C
	public virtual bool IsSingleByte
	{
		get
		{
			return true;
		}
	}

	// Token: 0x06002DA8 RID: 11688 RVA: 0x0002153B File Offset: 0x0001F73B
	public virtual object Clone()
	{
		Class437 @class = (Class437)base.Clone();
		@class.gclass128_0 = null;
		@class.gclass129_0 = null;
		return @class;
	}

	// Token: 0x06002DA9 RID: 11689 RVA: 0x00021556 File Offset: 0x0001F756
	public virtual Decoder GetDecoder()
	{
		return new GClass128();
	}

	// Token: 0x06002DAA RID: 11690 RVA: 0x0002155D File Offset: 0x0001F75D
	public virtual Encoder GetEncoder()
	{
		return new GClass129();
	}

	// Token: 0x06002DAB RID: 11691 RVA: 0x00021564 File Offset: 0x0001F764
	public virtual int GetByteCount(char[] chars, int index, int count)
	{
		return this.GClass129_0.GetByteCount(chars, index, count, true);
	}

	// Token: 0x06002DAC RID: 11692 RVA: 0x00021575 File Offset: 0x0001F775
	public virtual int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex)
	{
		return this.GClass129_0.GetBytes(chars, charIndex, charCount, bytes, byteIndex, true);
	}

	// Token: 0x06002DAD RID: 11693 RVA: 0x0002158A File Offset: 0x0001F78A
	public virtual int GetCharCount(byte[] bytes, int index, int count)
	{
		return this.GClass128_0.GetCharCount(bytes, index, count, true);
	}

	// Token: 0x06002DAE RID: 11694 RVA: 0x0002159B File Offset: 0x0001F79B
	public virtual int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
	{
		return this.GClass128_0.GetChars(bytes, byteIndex, byteCount, chars, charIndex, true);
	}

	// Token: 0x06002DAF RID: 11695 RVA: 0x00008926 File Offset: 0x00006B26
	public virtual int GetMaxByteCount(int charCount)
	{
		return charCount;
	}

	// Token: 0x06002DB0 RID: 11696 RVA: 0x00008926 File Offset: 0x00006B26
	public virtual int GetMaxCharCount(int byteCount)
	{
		return byteCount;
	}

	// Token: 0x04001EFF RID: 7935
	public static readonly char[] char_0 = new char[]
	{
		'\0',
		'\u0001',
		'Ẳ',
		'\u0003',
		'\u0004',
		'Ẵ',
		'Ẫ',
		'\a',
		'\b',
		'\t',
		'\n',
		'\v',
		'\f',
		'\r',
		'\u000e',
		'\u000f',
		'\u0010',
		'\u0011',
		'\u0012',
		'\u0013',
		'Ỷ',
		'\u0015',
		'\u0016',
		'\u0017',
		'\u0018',
		'Ỹ',
		'\u001a',
		'\u001b',
		'\u001c',
		'\u001d',
		'Ỵ',
		'\u001f',
		' ',
		'!',
		'"',
		'#',
		'$',
		'%',
		'&',
		'\'',
		'(',
		')',
		'*',
		'+',
		',',
		'-',
		'.',
		'/',
		'0',
		'1',
		'2',
		'3',
		'4',
		'5',
		'6',
		'7',
		'8',
		'9',
		':',
		';',
		'<',
		'=',
		'>',
		'?',
		'@',
		'A',
		'B',
		'C',
		'D',
		'E',
		'F',
		'G',
		'H',
		'I',
		'J',
		'K',
		'L',
		'M',
		'N',
		'O',
		'P',
		'Q',
		'R',
		'S',
		'T',
		'U',
		'V',
		'W',
		'X',
		'Y',
		'Z',
		'[',
		'\\',
		']',
		'^',
		'_',
		'`',
		'a',
		'b',
		'c',
		'd',
		'e',
		'f',
		'g',
		'h',
		'i',
		'j',
		'k',
		'l',
		'm',
		'n',
		'o',
		'p',
		'q',
		'r',
		's',
		't',
		'u',
		'v',
		'w',
		'x',
		'y',
		'z',
		'{',
		'|',
		'}',
		'~',
		'\u007f',
		'Ạ',
		'Ắ',
		'Ằ',
		'Ặ',
		'Ấ',
		'Ầ',
		'Ẩ',
		'Ậ',
		'Ẽ',
		'Ẹ',
		'Ế',
		'Ề',
		'Ể',
		'Ễ',
		'Ệ',
		'Ố',
		'Ồ',
		'Ổ',
		'Ỗ',
		'Ộ',
		'Ợ',
		'Ớ',
		'Ờ',
		'Ở',
		'Ị',
		'Ỏ',
		'Ọ',
		'Ỉ',
		'Ủ',
		'Ũ',
		'Ụ',
		'Ỳ',
		'Õ',
		'ắ',
		'ằ',
		'ặ',
		'ấ',
		'ầ',
		'ẩ',
		'ậ',
		'ẽ',
		'ẹ',
		'ế',
		'ề',
		'ể',
		'ễ',
		'ệ',
		'ố',
		'ồ',
		'ổ',
		'ỗ',
		'Ỡ',
		'Ơ',
		'ộ',
		'ờ',
		'ở',
		'ị',
		'Ự',
		'Ứ',
		'Ừ',
		'Ử',
		'ơ',
		'ớ',
		'Ư',
		'À',
		'Á',
		'Â',
		'Ã',
		'Ả',
		'Ă',
		'ẳ',
		'ẵ',
		'È',
		'É',
		'Ê',
		'Ẻ',
		'Ì',
		'Í',
		'Ĩ',
		'ỳ',
		'Đ',
		'ứ',
		'Ò',
		'Ó',
		'Ô',
		'ạ',
		'ỷ',
		'ừ',
		'ử',
		'Ù',
		'Ú',
		'ỹ',
		'ỵ',
		'Ý',
		'ỡ',
		'ư',
		'à',
		'á',
		'â',
		'ã',
		'ả',
		'ă',
		'ữ',
		'ẫ',
		'è',
		'é',
		'ê',
		'ẻ',
		'ì',
		'í',
		'ĩ',
		'ỉ',
		'đ',
		'ự',
		'ò',
		'ó',
		'ô',
		'õ',
		'ỏ',
		'ọ',
		'ụ',
		'ù',
		'ú',
		'ũ',
		'ủ',
		'ý',
		'ợ',
		'Ữ'
	};

	// Token: 0x04001F00 RID: 7936
	private GClass128 gclass128_0;

	// Token: 0x04001F01 RID: 7937
	private GClass129 gclass129_0;
}
