﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020002BD RID: 701
internal class Class386
{
	// Token: 0x17000875 RID: 2165
	// (get) Token: 0x06002705 RID: 9989 RVA: 0x0001D11D File Offset: 0x0001B31D
	// (set) Token: 0x06002706 RID: 9990 RVA: 0x0001D125 File Offset: 0x0001B325
	public Class159 Class159_0 { get; set; }

	// Token: 0x17000876 RID: 2166
	// (get) Token: 0x06002707 RID: 9991 RVA: 0x0001D12E File Offset: 0x0001B32E
	// (set) Token: 0x06002708 RID: 9992 RVA: 0x0001D136 File Offset: 0x0001B336
	public List<Class385> List_0 { get; set; } = new List<Class385>();

	// Token: 0x06002709 RID: 9993 RVA: 0x0001D13F File Offset: 0x0001B33F
	public Class386(Class159 class159_1)
	{
		this.Class159_0 = class159_1;
	}

	// Token: 0x17000877 RID: 2167
	// (get) Token: 0x0600270A RID: 9994 RVA: 0x0001D159 File Offset: 0x0001B359
	// (set) Token: 0x0600270B RID: 9995 RVA: 0x0001D161 File Offset: 0x0001B361
	public int Int32_0 { get; set; }

	// Token: 0x0600270C RID: 9996 RVA: 0x00116D60 File Offset: 0x00114F60
	public void method_0()
	{
		this.List_0.Clear();
		uint num = this.Class159_0.Class405_0.method_20(new uint[]
		{
			this.Class159_0.Class392_0.UInt32_63[0],
			220U
		});
		uint num2 = 0U;
		while ((ulong)num2 < (ulong)((long)this.Int32_0))
		{
			Class385 @class = new Class385();
			@class.UInt32_0 = this.Class159_0.Class405_0.method_11(num + num2 * 4U);
			@class.String_0 = this.Class159_0.Class405_0.method_15(@class.UInt32_0).ToString("X8");
			@class.String_1 = this.Class159_0.Class405_0.method_26(@class.UInt32_0 + 64U);
			@class.Single_0 = this.Class159_0.Class405_0.method_22(@class.UInt32_0 + 112U);
			@class.Single_1 = this.Class159_0.Class405_0.method_22(@class.UInt32_0 + 116U);
			this.List_0.Add(@class);
			num2 += 1U;
		}
	}

	// Token: 0x04001A97 RID: 6807
	[CompilerGenerated]
	private Class159 class159_0;

	// Token: 0x04001A98 RID: 6808
	[CompilerGenerated]
	private List<Class385> list_0;

	// Token: 0x04001A99 RID: 6809
	[CompilerGenerated]
	private int int_0;
}
