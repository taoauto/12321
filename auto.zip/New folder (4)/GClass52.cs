﻿using System;

// Token: 0x020000BA RID: 186
public class GClass52 : GClass51
{
	// Token: 0x060008DA RID: 2266 RVA: 0x00008BD8 File Offset: 0x00006DD8
	public GClass52(string string_4)
	{
		this.string_0 = string_4.Replace("\r", "");
		this.String_0 = "Code snippet:";
		this.String_1 = this.string_0;
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x00008C0D File Offset: 0x00006E0D
	public override string \u202B\u202E\u206A\u200C\u202B\u206D\u206F\u200E\u200D\u200C\u206F\u200E\u206F\u200F\u200F\u202B\u206E\u200C\u206B\u206E\u202C\u200B\u206F\u206E\u206C\u200D\u202C\u206C\u200B\u200F\u206D\u206C\u206C\u202A\u202B\u202A\u206E\u206E\u200D\u206B\u202E()
	{
		return this.String_2 ?? this.string_0.Replace("\n", " ").Replace("^", "");
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x00008B56 File Offset: 0x00006D56
	public override string \u200F\u206C\u202D\u206E\u206B\u200F\u202C\u202E\u200C\u206A\u200E\u206F\u200F\u206A\u200D\u202A\u202B\u206C\u202C\u206D\u202C\u200D\u206E\u206B\u202D\u202A\u206A\u206E\u206C\u206B\u206C\u202A\u200C\u200D\u200F\u206A\u206A\u206F\u206A\u206F\u202E()
	{
		return this.string_0;
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x0003CFBC File Offset: 0x0003B1BC
	public override void \u202E\u200D\u206F\u200D\u202B\u202A\u202B\u200B\u206B\u202B\u206A\u202A\u206E\u200B\u206D\u206A\u200F\u202C\u200B\u206F\u200B\u206F\u202B\u202B\u206F\u202D\u206D\u206B\u202C\u200D\u202B\u202D\u202C\u200D\u206A\u206F\u206B\u202D\u200C\u202E(GClass55 gclass55_1, GEventArgs7 geventArgs7_0)
	{
		geventArgs7_0.FastColoredTextBox_0.method_87();
		geventArgs7_0.FastColoredTextBox_0.GClass86_5.method_38();
		GStruct2 gstruct2_ = gclass55_1.GClass86_0.GStruct2_0;
		GStruct2 gstruct2_2 = geventArgs7_0.FastColoredTextBox_0.GClass86_5.GStruct2_0;
		if (geventArgs7_0.FastColoredTextBox_0.Boolean_18)
		{
			for (int i = gstruct2_.int_1 + 1; i <= gstruct2_2.int_1; i++)
			{
				geventArgs7_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(0, i);
				geventArgs7_0.FastColoredTextBox_0.vmethod_44(i);
			}
		}
		geventArgs7_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = gstruct2_;
		while (geventArgs7_0.FastColoredTextBox_0.GClass86_5.Char_1 != '^' && geventArgs7_0.FastColoredTextBox_0.GClass86_5.vmethod_1())
		{
		}
		geventArgs7_0.FastColoredTextBox_0.GClass86_5.method_10(true);
		geventArgs7_0.FastColoredTextBox_0.vmethod_20("");
		geventArgs7_0.FastColoredTextBox_0.GClass86_5.method_39();
		geventArgs7_0.FastColoredTextBox_0.method_88();
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00008C3D File Offset: 0x00006E3D
	public override GEnum10 \u206A\u200E\u206A\u206E\u200F\u206C\u202D\u200F\u206D\u200E\u200C\u202D\u200D\u202E\u206C\u200B\u200E\u206F\u200D\u202D\u202E\u206A\u206D\u202A\u206E\u202B\u206F\u202D\u200B\u200B\u206D\u206D\u206D\u202D\u202A\u200F\u200C\u202A\u206F\u200D\u202E(string string_4)
	{
		if (this.string_0.StartsWith(string_4, StringComparison.InvariantCultureIgnoreCase) && this.string_0 != string_4)
		{
			return GEnum10.Visible;
		}
		return GEnum10.Hidden;
	}
}
