﻿using System;

// Token: 0x020002AE RID: 686
internal class Class372
{
	// Token: 0x17000846 RID: 2118
	// (get) Token: 0x0600266B RID: 9835 RVA: 0x0001CB43 File Offset: 0x0001AD43
	public static string String_0
	{
		get
		{
			return "Thiên Long Tự";
		}
	}

	// Token: 0x040019C9 RID: 6601
	public static int int_0 = 13;

	// Token: 0x040019CA RID: 6602
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 20U,
		Int32_0 = 147,
		Int32_1 = 96,
		Int32_2 = Class372.int_0,
		String_2 = "Dương Bạch Ngưu"
	};

	// Token: 0x040019CB RID: 6603
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 96,
		Int32_1 = 66,
		Int32_2 = Class372.int_0,
		String_2 = "Bản Nhân"
	};

	// Token: 0x040019CC RID: 6604
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 96,
		Int32_1 = 89,
		Int32_2 = Class372.int_0,
		String_2 = "Bản Phàm"
	};

	// Token: 0x040019CD RID: 6605
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 98,
		Int32_1 = 67,
		Int32_2 = Class372.int_0,
		String_2 = "Bản Quán"
	};
}
