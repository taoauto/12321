﻿using System;

// Token: 0x02000287 RID: 647
internal class Class338
{
	// Token: 0x17000779 RID: 1913
	// (get) Token: 0x0600241B RID: 9243 RVA: 0x0001B89D File Offset: 0x00019A9D
	public static string String_0
	{
		get
		{
			return "Yến Tử Ổ";
		}
	}

	// Token: 0x040017D6 RID: 6102
	public static int int_0 = 236;

	// Token: 0x040017D7 RID: 6103
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 2635U,
		Int32_0 = 79,
		Int32_1 = 202,
		Int32_2 = Class338.int_0,
		String_2 = "Hô Diên Báo"
	};

	// Token: 0x040017D8 RID: 6104
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 2640U,
		Int32_0 = 217,
		Int32_1 = 150,
		Int32_2 = Class338.int_0,
		String_2 = "Tiền Hoành Vũ"
	};

	// Token: 0x040017D9 RID: 6105
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 2929U,
		Int32_0 = 63,
		Int32_1 = 67,
		Int32_2 = Class338.int_0,
		String_2 = "Mộ Dung Phục"
	};

	// Token: 0x040017DA RID: 6106
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 2641U,
		Int32_0 = 181,
		Int32_1 = 89,
		Int32_2 = Class338.int_0,
		String_2 = "Hoa Hách Cấn"
	};

	// Token: 0x040017DB RID: 6107
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 5036U,
		Int32_0 = 180,
		Int32_1 = 90,
		Int32_2 = Class338.int_0,
		String_2 = "Hoa Hách Cấn"
	};
}
