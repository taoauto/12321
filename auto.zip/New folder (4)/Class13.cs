﻿using System;

// Token: 0x02000029 RID: 41
internal static class Class13
{
	// Token: 0x060001F3 RID: 499 RVA: 0x00004495 File Offset: 0x00002695
	internal static ArgumentException smethod_0(string string_0)
	{
		return new ArgumentException(Class2.String_1, string_0);
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x000044A2 File Offset: 0x000026A2
	internal static ArgumentOutOfRangeException smethod_1<T>(string string_0, T gparam_0) where T : struct
	{
		return new ArgumentOutOfRangeException(string_0, string.Format(Class2.String_7, gparam_0));
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x000044BA File Offset: 0x000026BA
	internal static ArgumentOutOfRangeException smethod_2<T>(string string_0, T gparam_0) where T : struct
	{
		return new ArgumentOutOfRangeException(string_0, string.Format(Class2.String_6, gparam_0));
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x000044D2 File Offset: 0x000026D2
	internal static ArgumentException smethod_3(string string_0, Exception exception_0 = null)
	{
		return new ArgumentException(Class2.String_5, string_0, exception_0);
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x000044E0 File Offset: 0x000026E0
	internal static ArgumentOutOfRangeException smethod_4(string string_0)
	{
		return new ArgumentOutOfRangeException("port", string.Format(Class2.String_8, 1, 65535));
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00004506 File Offset: 0x00002706
	internal static bool smethod_5(int int_0)
	{
		return int_0 >= 1 && int_0 <= 65535;
	}
}
