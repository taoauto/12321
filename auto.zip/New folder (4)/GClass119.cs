﻿using System;

// Token: 0x02000194 RID: 404
public static class GClass119
{
	// Token: 0x0600126C RID: 4716 RVA: 0x0000E8F7 File Offset: 0x0000CAF7
	public static IntPtr smethod_0(this IntPtr intptr_0, long long_0)
	{
		return new IntPtr(intptr_0.ToInt32() + (int)long_0);
	}

	// Token: 0x0600126D RID: 4717 RVA: 0x0000E908 File Offset: 0x0000CB08
	public static IntPtr smethod_1(this IntPtr intptr_0, IntPtr intptr_1)
	{
		return new IntPtr(intptr_0.ToInt32() + intptr_1.ToInt32());
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x0000E91E File Offset: 0x0000CB1E
	public static bool smethod_2(this IntPtr intptr_0, long long_0)
	{
		return intptr_0.ToInt64() == long_0;
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x0000E92A File Offset: 0x0000CB2A
	public static IntPtr smethod_3(long long_0)
	{
		return new IntPtr((int)long_0);
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x0000E933 File Offset: 0x0000CB33
	public static bool smethod_4(this IntPtr intptr_0)
	{
		return intptr_0 == IntPtr.Zero;
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x0000E940 File Offset: 0x0000CB40
	public static bool smethod_5(this UIntPtr uintptr_0)
	{
		return uintptr_0 == UIntPtr.Zero;
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x0000E94D File Offset: 0x0000CB4D
	public static IntPtr smethod_6(this IntPtr intptr_0, long long_0)
	{
		return new IntPtr((int)(intptr_0.ToInt64() - long_0));
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x0000E95E File Offset: 0x0000CB5E
	public static IntPtr smethod_7(this IntPtr intptr_0, IntPtr intptr_1)
	{
		return new IntPtr((int)(intptr_0.ToInt64() - intptr_1.ToInt64()));
	}
}
