﻿using System;
using System.Diagnostics;
using System.Drawing;

// Token: 0x020002EC RID: 748
internal static class Class411
{
	// Token: 0x06002ACB RID: 10955 RVA: 0x0001F25C File Offset: 0x0001D45C
	[DebuggerStepThrough]
	public static bool smethod_0<T>(this T gparam_0, T gparam_1, T gparam_2) where T : IComparable<T>
	{
		return gparam_0.CompareTo(gparam_1) >= 0 && gparam_0.CompareTo(gparam_2) <= 0;
	}

	// Token: 0x06002ACC RID: 10956 RVA: 0x0001F285 File Offset: 0x0001D485
	[DebuggerStepThrough]
	public static Size smethod_1(this Size size_0)
	{
		return new Size(size_0.Height, size_0.Width);
	}
}
