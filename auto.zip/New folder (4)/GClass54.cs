﻿using System;

// Token: 0x020000BC RID: 188
public class GClass54 : GClass51
{
	// Token: 0x060008E2 RID: 2274 RVA: 0x00008C91 File Offset: 0x00006E91
	public GClass54(string string_4, int int_1) : base(string_4, int_1)
	{
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x0000354C File Offset: 0x0000174C
	public override GEnum10 \u206A\u200E\u206A\u206E\u200F\u206C\u202D\u200F\u206D\u200E\u200C\u202D\u200D\u202E\u206C\u200B\u200E\u206F\u200D\u202D\u202E\u206A\u206D\u202A\u206E\u202B\u206F\u202D\u200B\u200B\u206D\u206D\u206D\u202D\u202A\u200F\u200C\u202A\u206F\u200D\u202E(string string_4)
	{
		return GEnum10.Visible;
	}
}
