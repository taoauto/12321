﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

// Token: 0x02000220 RID: 544
public class GClass124 : TextBox
{
	// Token: 0x06001D47 RID: 7495 RVA: 0x00015911 File Offset: 0x00013B11
	public GClass124()
	{
		this.method_1();
		base.KeyDown += this.GClass124_KeyDown;
	}

	// Token: 0x06001D48 RID: 7496 RVA: 0x0003CBF0 File Offset: 0x0003ADF0
	private void GClass124_KeyDown(object sender, KeyEventArgs e)
	{
		TextBox textBox = sender as TextBox;
		if (e.Control && e.KeyCode == Keys.A)
		{
			textBox.SelectAll();
		}
	}

	// Token: 0x06001D49 RID: 7497 RVA: 0x000089C6 File Offset: 0x00006BC6
	public void method_0()
	{
		base.SelectionStart = this.TextLength;
		base.ScrollToCaret();
	}

	// Token: 0x06001D4A RID: 7498 RVA: 0x000D8844 File Offset: 0x000D6A44
	private void method_1()
	{
		this.color_0 = Color.LightGray;
		this.color_1 = Color.Gray;
		this.font_0 = this.Font;
		this.solidBrush_0 = new SolidBrush(this.color_1);
		this.panel_0 = null;
		this.method_3();
		base.Enter += this.GClass124_Enter;
		base.Leave += this.GClass124_Leave;
		base.TextChanged += this.GClass124_TextChanged;
	}

	// Token: 0x06001D4B RID: 7499 RVA: 0x0001593C File Offset: 0x00013B3C
	private void method_2()
	{
		if (this.panel_0 != null)
		{
			base.Controls.Remove(this.panel_0);
			this.panel_0 = null;
		}
	}

	// Token: 0x06001D4C RID: 7500 RVA: 0x000D88C8 File Offset: 0x000D6AC8
	private void method_3()
	{
		if (this.panel_0 == null && this.TextLength <= 0)
		{
			this.panel_0 = new Panel();
			this.panel_0.Paint += this.panel_0_Paint;
			this.panel_0.Invalidate();
			this.panel_0.Click += this.panel_0_Click;
			base.Controls.Add(this.panel_0);
		}
	}

	// Token: 0x06001D4D RID: 7501 RVA: 0x000089FC File Offset: 0x00006BFC
	private void panel_0_Click(object sender, EventArgs e)
	{
		base.Focus();
	}

	// Token: 0x06001D4E RID: 7502 RVA: 0x000D893C File Offset: 0x000D6B3C
	private void panel_0_Paint(object sender, PaintEventArgs e)
	{
		this.panel_0.Location = new Point(2, 0);
		this.panel_0.Height = base.Height;
		this.panel_0.Width = base.Width;
		this.panel_0.Anchor = (AnchorStyles.Left | AnchorStyles.Right);
		if (base.ContainsFocus)
		{
			this.solidBrush_0 = new SolidBrush(this.color_1);
		}
		else
		{
			this.solidBrush_0 = new SolidBrush(this.color_0);
		}
		e.Graphics.DrawString(this.string_0, this.font_0, this.solidBrush_0, new PointF(-2f, 1f));
	}

	// Token: 0x06001D4F RID: 7503 RVA: 0x0001595E File Offset: 0x00013B5E
	private void GClass124_Enter(object sender, EventArgs e)
	{
		this.solidBrush_0 = new SolidBrush(this.color_1);
		if (this.TextLength <= 0)
		{
			this.method_2();
			this.method_3();
		}
	}

	// Token: 0x06001D50 RID: 7504 RVA: 0x00015986 File Offset: 0x00013B86
	private void GClass124_Leave(object sender, EventArgs e)
	{
		if (this.TextLength > 0)
		{
			this.method_2();
			return;
		}
		base.Invalidate();
	}

	// Token: 0x06001D51 RID: 7505 RVA: 0x0001599E File Offset: 0x00013B9E
	private void GClass124_TextChanged(object sender, EventArgs e)
	{
		if (this.TextLength > 0)
		{
			this.method_2();
			return;
		}
		this.method_3();
	}

	// Token: 0x06001D52 RID: 7506 RVA: 0x000159B6 File Offset: 0x00013BB6
	protected virtual void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		this.method_3();
	}

	// Token: 0x06001D53 RID: 7507 RVA: 0x000159C5 File Offset: 0x00013BC5
	protected virtual void OnInvalidated(InvalidateEventArgs e)
	{
		base.OnInvalidated(e);
		if (this.panel_0 != null)
		{
			this.panel_0.Invalidate();
		}
	}

	// Token: 0x170006B3 RID: 1715
	// (get) Token: 0x06001D54 RID: 7508 RVA: 0x000159E1 File Offset: 0x00013BE1
	// (set) Token: 0x06001D55 RID: 7509 RVA: 0x000159E9 File Offset: 0x00013BE9
	[Category("Watermark attribtues")]
	[Description("Sets the text of the watermark")]
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x170006B4 RID: 1716
	// (get) Token: 0x06001D56 RID: 7510 RVA: 0x000159F8 File Offset: 0x00013BF8
	// (set) Token: 0x06001D57 RID: 7511 RVA: 0x00015A00 File Offset: 0x00013C00
	[Category("Watermark attribtues")]
	[Description("When the control gaines focus, this color will be used as the watermark's forecolor")]
	public Color Color_0
	{
		get
		{
			return this.color_1;
		}
		set
		{
			this.color_1 = value;
			base.Invalidate();
		}
	}

	// Token: 0x170006B5 RID: 1717
	// (get) Token: 0x06001D58 RID: 7512 RVA: 0x00015A0F File Offset: 0x00013C0F
	// (set) Token: 0x06001D59 RID: 7513 RVA: 0x00015A17 File Offset: 0x00013C17
	[Category("Watermark attribtues")]
	[Description("When the control looses focus, this color will be used as the watermark's forecolor")]
	public Color Color_1
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x170006B6 RID: 1718
	// (get) Token: 0x06001D5A RID: 7514 RVA: 0x00015A26 File Offset: 0x00013C26
	// (set) Token: 0x06001D5B RID: 7515 RVA: 0x00015A2E File Offset: 0x00013C2E
	[Category("Watermark attribtues")]
	[Description("The font used on the watermark. Default is the same as the control")]
	public Font Font_0
	{
		get
		{
			return this.font_0;
		}
		set
		{
			this.font_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x06001D5C RID: 7516 RVA: 0x000D89E4 File Offset: 0x000D6BE4
	protected virtual void OnKeyPress(KeyPressEventArgs e)
	{
		base.OnKeyPress(e);
		NumberFormatInfo numberFormat = CultureInfo.CurrentCulture.NumberFormat;
		string text = e.KeyChar.ToString();
		if (char.IsDigit(text, 0))
		{
			return;
		}
		if (base.SelectionStart == 0 && text.Equals(numberFormat.NegativeSign))
		{
			return;
		}
		if ((e.KeyChar == '\u0016' || e.KeyChar == '\u0003') && (Control.ModifierKeys & Keys.Control) == Keys.Control)
		{
			return;
		}
		if (e.KeyChar == '\b')
		{
			return;
		}
		e.Handled = true;
	}

	// Token: 0x06001D5D RID: 7517 RVA: 0x000D8A6C File Offset: 0x000D6C6C
	protected virtual void WndProc(ref Message m)
	{
		if (m.Msg == 770)
		{
			string text = Clipboard.GetText();
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			if (text.IndexOf('+') >= 0 && base.SelectionStart != 0)
			{
				return;
			}
			int num;
			if (!int.TryParse(text, out num))
			{
				return;
			}
			if (num < 0 && base.SelectionStart != 0)
			{
				return;
			}
		}
		base.WndProc(ref m);
	}

	// Token: 0x040011E7 RID: 4583
	protected string string_0 = "Default Watermark...";

	// Token: 0x040011E8 RID: 4584
	protected Color color_0;

	// Token: 0x040011E9 RID: 4585
	protected Color color_1;

	// Token: 0x040011EA RID: 4586
	private Panel panel_0;

	// Token: 0x040011EB RID: 4587
	private Font font_0;

	// Token: 0x040011EC RID: 4588
	private SolidBrush solidBrush_0;
}
