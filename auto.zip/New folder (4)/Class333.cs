﻿using System;

// Token: 0x02000282 RID: 642
internal class Class333
{
	// Token: 0x17000774 RID: 1908
	// (get) Token: 0x0600240C RID: 9228 RVA: 0x0001B87A File Offset: 0x00019A7A
	public static string String_0
	{
		get
		{
			return "Quỷ Cốc";
		}
	}

	// Token: 0x040017C2 RID: 6082
	public static int int_0 = 678;

	// Token: 0x040017C3 RID: 6083
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 150,
		Int32_1 = 150,
		Int32_2 = Class333.int_0,
		String_2 = "Tô Cầm"
	};

	// Token: 0x040017C4 RID: 6084
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 96,
		Int32_1 = 98,
		Int32_2 = Class333.int_0,
		String_2 = "Vương Huyền Phong"
	};

	// Token: 0x040017C5 RID: 6085
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 99,
		Int32_1 = 56,
		Int32_2 = Class333.int_0,
		String_2 = "Vương Thiền Nhất"
	};

	// Token: 0x040017C6 RID: 6086
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 92,
		Int32_1 = 55,
		Int32_2 = Class333.int_0,
		String_2 = "Lý Kế Long"
	};
}
