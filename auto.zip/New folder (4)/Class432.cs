﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;

// Token: 0x0200030D RID: 781
internal class Class432
{
	// Token: 0x17000A0A RID: 2570
	// (get) Token: 0x06002C93 RID: 11411 RVA: 0x00020758 File Offset: 0x0001E958
	public bool Boolean_0
	{
		get
		{
			return this.UInt32_28 == 9U;
		}
	}

	// Token: 0x17000A0B RID: 2571
	// (get) Token: 0x06002C94 RID: 11412 RVA: 0x0012D68C File Offset: 0x0012B88C
	public string String_0
	{
		get
		{
			string text = "";
			foreach (char value in this.String_2)
			{
				if (Class426.string_0.Contains(value))
				{
					text += value.ToString();
				}
			}
			return text;
		}
	}

	// Token: 0x17000A0C RID: 2572
	// (get) Token: 0x06002C95 RID: 11413 RVA: 0x0012D6DC File Offset: 0x0012B8DC
	public bool Boolean_1
	{
		get
		{
			return this.method_3(this.UInt32_29) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_0) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_130) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_133) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_138);
		}
	}

	// Token: 0x17000A0D RID: 2573
	// (get) Token: 0x06002C96 RID: 11414 RVA: 0x0012D738 File Offset: 0x0012B938
	public Class424 Class424_0
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class366.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class367.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class369.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class370.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class371.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class333.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class372.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class373.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class374.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class375.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class376.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class377.class424_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class332.class424_0;
			}
			return null;
		}
	}

	// Token: 0x17000A0E RID: 2574
	// (get) Token: 0x06002C97 RID: 11415 RVA: 0x00020764 File Offset: 0x0001E964
	// (set) Token: 0x06002C98 RID: 11416 RVA: 0x0002076C File Offset: 0x0001E96C
	public Class159 Class159_0 { get; set; }

	// Token: 0x17000A0F RID: 2575
	// (get) Token: 0x06002C99 RID: 11417 RVA: 0x00020775 File Offset: 0x0001E975
	// (set) Token: 0x06002C9A RID: 11418 RVA: 0x0002077D File Offset: 0x0001E97D
	public uint UInt32_0 { get; set; }

	// Token: 0x17000A10 RID: 2576
	// (get) Token: 0x06002C9B RID: 11419 RVA: 0x00020786 File Offset: 0x0001E986
	// (set) Token: 0x06002C9C RID: 11420 RVA: 0x0002078E File Offset: 0x0001E98E
	public string String_1 { get; set; } = string.Empty;

	// Token: 0x17000A11 RID: 2577
	// (get) Token: 0x06002C9D RID: 11421 RVA: 0x0012D858 File Offset: 0x0012BA58
	public string String_2
	{
		get
		{
			this.UInt32_0 = this.class405_0.method_20(this.class392_0.UInt32_2);
			string text = this.class405_0.method_28(this.UInt32_0 + this.class392_0.UInt32_5);
			if (string.IsNullOrEmpty(text.Trim()))
			{
				text = "ĐăngNhập";
			}
			return text;
		}
	}

	// Token: 0x17000A12 RID: 2578
	// (get) Token: 0x06002C9E RID: 11422 RVA: 0x00020797 File Offset: 0x0001E997
	public byte[] Byte_0
	{
		get
		{
			this.UInt32_0 = this.class405_0.method_20(this.class392_0.UInt32_2);
			return this.class405_0.method_29(this.UInt32_0 + this.class392_0.UInt32_5);
		}
	}

	// Token: 0x17000A13 RID: 2579
	// (get) Token: 0x06002C9F RID: 11423 RVA: 0x000207D2 File Offset: 0x0001E9D2
	// (set) Token: 0x06002CA0 RID: 11424 RVA: 0x000207DA File Offset: 0x0001E9DA
	public uint UInt32_1 { get; set; }

	// Token: 0x17000A14 RID: 2580
	// (get) Token: 0x06002CA1 RID: 11425 RVA: 0x000207E3 File Offset: 0x0001E9E3
	// (set) Token: 0x06002CA2 RID: 11426 RVA: 0x000207EB File Offset: 0x0001E9EB
	public uint UInt32_2 { get; set; }

	// Token: 0x17000A15 RID: 2581
	// (get) Token: 0x06002CA3 RID: 11427 RVA: 0x000207F4 File Offset: 0x0001E9F4
	// (set) Token: 0x06002CA4 RID: 11428 RVA: 0x000207FC File Offset: 0x0001E9FC
	public uint UInt32_3 { get; set; }

	// Token: 0x17000A16 RID: 2582
	// (get) Token: 0x06002CA5 RID: 11429 RVA: 0x00020805 File Offset: 0x0001EA05
	public bool Boolean_2
	{
		get
		{
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_10) == 1U;
		}
	}

	// Token: 0x17000A17 RID: 2583
	// (get) Token: 0x06002CA6 RID: 11430 RVA: 0x00020827 File Offset: 0x0001EA27
	// (set) Token: 0x06002CA7 RID: 11431 RVA: 0x0002082F File Offset: 0x0001EA2F
	public uint UInt32_4 { get; set; }

	// Token: 0x17000A18 RID: 2584
	// (get) Token: 0x06002CA8 RID: 11432 RVA: 0x00020838 File Offset: 0x0001EA38
	// (set) Token: 0x06002CA9 RID: 11433 RVA: 0x00020840 File Offset: 0x0001EA40
	public uint UInt32_5 { get; set; }

	// Token: 0x17000A19 RID: 2585
	// (get) Token: 0x06002CAA RID: 11434 RVA: 0x00020849 File Offset: 0x0001EA49
	// (set) Token: 0x06002CAB RID: 11435 RVA: 0x00020851 File Offset: 0x0001EA51
	public uint UInt32_6 { get; set; }

	// Token: 0x17000A1A RID: 2586
	// (get) Token: 0x06002CAC RID: 11436 RVA: 0x0002085A File Offset: 0x0001EA5A
	// (set) Token: 0x06002CAD RID: 11437 RVA: 0x00020862 File Offset: 0x0001EA62
	public uint UInt32_7 { get; set; }

	// Token: 0x17000A1B RID: 2587
	// (get) Token: 0x06002CAE RID: 11438 RVA: 0x0002086B File Offset: 0x0001EA6B
	// (set) Token: 0x06002CAF RID: 11439 RVA: 0x00020873 File Offset: 0x0001EA73
	public uint UInt32_8 { get; set; }

	// Token: 0x17000A1C RID: 2588
	// (get) Token: 0x06002CB0 RID: 11440 RVA: 0x0002087C File Offset: 0x0001EA7C
	// (set) Token: 0x06002CB1 RID: 11441 RVA: 0x00020884 File Offset: 0x0001EA84
	public uint UInt32_9 { get; set; }

	// Token: 0x17000A1D RID: 2589
	// (get) Token: 0x06002CB2 RID: 11442 RVA: 0x0002088D File Offset: 0x0001EA8D
	// (set) Token: 0x06002CB3 RID: 11443 RVA: 0x00020895 File Offset: 0x0001EA95
	public uint UInt32_10 { get; set; }

	// Token: 0x17000A1E RID: 2590
	// (get) Token: 0x06002CB4 RID: 11444 RVA: 0x0002089E File Offset: 0x0001EA9E
	// (set) Token: 0x06002CB5 RID: 11445 RVA: 0x000208A6 File Offset: 0x0001EAA6
	public uint UInt32_11 { get; set; }

	// Token: 0x17000A1F RID: 2591
	// (get) Token: 0x06002CB6 RID: 11446 RVA: 0x000208AF File Offset: 0x0001EAAF
	// (set) Token: 0x06002CB7 RID: 11447 RVA: 0x000208B7 File Offset: 0x0001EAB7
	public uint UInt32_12 { get; set; }

	// Token: 0x17000A20 RID: 2592
	// (get) Token: 0x06002CB8 RID: 11448 RVA: 0x000208C0 File Offset: 0x0001EAC0
	// (set) Token: 0x06002CB9 RID: 11449 RVA: 0x000208C8 File Offset: 0x0001EAC8
	public uint UInt32_13 { get; set; }

	// Token: 0x17000A21 RID: 2593
	// (get) Token: 0x06002CBA RID: 11450 RVA: 0x000208D1 File Offset: 0x0001EAD1
	// (set) Token: 0x06002CBB RID: 11451 RVA: 0x000208D9 File Offset: 0x0001EAD9
	public uint UInt32_14 { get; set; }

	// Token: 0x17000A22 RID: 2594
	// (get) Token: 0x06002CBC RID: 11452 RVA: 0x000208E2 File Offset: 0x0001EAE2
	// (set) Token: 0x06002CBD RID: 11453 RVA: 0x000208EA File Offset: 0x0001EAEA
	public uint UInt32_15 { get; set; }

	// Token: 0x06002CBE RID: 11454 RVA: 0x000208F3 File Offset: 0x0001EAF3
	public void method_0()
	{
		this.Class159_0.method_57(0, 120);
	}

	// Token: 0x06002CBF RID: 11455 RVA: 0x00020903 File Offset: 0x0001EB03
	public void method_1(string string_14)
	{
		this.Class159_0.method_282("TXT = '" + string_14 + "';", false);
		this.Class159_0.method_57(3, 105);
	}

	// Token: 0x17000A23 RID: 2595
	// (get) Token: 0x06002CC0 RID: 11456 RVA: 0x0002092F File Offset: 0x0001EB2F
	public bool Boolean_3
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_153) == 1U;
		}
	}

	// Token: 0x17000A24 RID: 2596
	// (get) Token: 0x06002CC1 RID: 11457 RVA: 0x0002094A File Offset: 0x0001EB4A
	public bool Boolean_4
	{
		get
		{
			return this.class405_0.method_12(this.class405_0.method_44(this.class392_0.UInt32_152)) == 1U;
		}
	}

	// Token: 0x17000A25 RID: 2597
	// (get) Token: 0x06002CC2 RID: 11458 RVA: 0x00020970 File Offset: 0x0001EB70
	public uint UInt32_16
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_18 = 17512U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_18);
		}
	}

	// Token: 0x17000A26 RID: 2598
	// (get) Token: 0x06002CC3 RID: 11459 RVA: 0x000209AD File Offset: 0x0001EBAD
	public uint UInt32_17
	{
		get
		{
			return this.class405_0.method_17(this.class392_0.UInt32_58[0], 117668U);
		}
	}

	// Token: 0x17000A27 RID: 2599
	// (get) Token: 0x06002CC4 RID: 11460 RVA: 0x000209CC File Offset: 0x0001EBCC
	public uint UInt32_18
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_19 = 11164U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_19);
		}
	}

	// Token: 0x17000A28 RID: 2600
	// (get) Token: 0x06002CC5 RID: 11461 RVA: 0x00020A09 File Offset: 0x0001EC09
	public uint UInt32_19
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_20 = 11864U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_20);
		}
	}

	// Token: 0x17000A29 RID: 2601
	// (get) Token: 0x06002CC6 RID: 11462 RVA: 0x00020A46 File Offset: 0x0001EC46
	public uint UInt32_20
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_21 = 17836U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_21);
		}
	}

	// Token: 0x17000A2A RID: 2602
	// (get) Token: 0x06002CC7 RID: 11463 RVA: 0x00020A83 File Offset: 0x0001EC83
	public uint UInt32_21
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_22 = 11876U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_22);
		}
	}

	// Token: 0x17000A2B RID: 2603
	// (get) Token: 0x06002CC8 RID: 11464 RVA: 0x00020AC0 File Offset: 0x0001ECC0
	public uint UInt32_22
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.class392_0.UInt32_23 = 11872U;
			}
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_23);
		}
	}

	// Token: 0x17000A2C RID: 2604
	// (get) Token: 0x06002CC9 RID: 11465 RVA: 0x0012D8B4 File Offset: 0x0012BAB4
	public uint UInt32_23
	{
		get
		{
			uint num = this.class405_0.method_20(this.class392_0.UInt32_144);
			if (num == 10141355U)
			{
				num = 30U;
			}
			else if (num >= 10141020U)
			{
				num = num - 10141020U + 20U;
			}
			if (num == 0U)
			{
				num = 20U;
			}
			return num;
		}
	}

	// Token: 0x17000A2D RID: 2605
	// (get) Token: 0x06002CCA RID: 11466 RVA: 0x0012D900 File Offset: 0x0012BB00
	public uint UInt32_24
	{
		get
		{
			uint num = this.class405_0.method_20(this.class392_0.UInt32_145);
			if (num == 10141356U)
			{
				num = 30U;
			}
			else if (num >= 10141030U)
			{
				num = num - 10141030U + 20U;
			}
			if (num == 0U)
			{
				num = 20U;
			}
			return num;
		}
	}

	// Token: 0x17000A2E RID: 2606
	// (get) Token: 0x06002CCB RID: 11467 RVA: 0x00020AFD File Offset: 0x0001ECFD
	// (set) Token: 0x06002CCC RID: 11468 RVA: 0x00020B05 File Offset: 0x0001ED05
	public bool Boolean_5 { get; set; }

	// Token: 0x17000A2F RID: 2607
	// (get) Token: 0x06002CCD RID: 11469 RVA: 0x00020B0E File Offset: 0x0001ED0E
	// (set) Token: 0x06002CCE RID: 11470 RVA: 0x00020B16 File Offset: 0x0001ED16
	public bool Boolean_6 { get; set; }

	// Token: 0x17000A30 RID: 2608
	// (get) Token: 0x06002CCF RID: 11471 RVA: 0x0012D94C File Offset: 0x0012BB4C
	public bool Boolean_7
	{
		get
		{
			uint uint32_ = this.UInt32_24;
			uint num = this.class405_0.method_20(this.class392_0.UInt32_54);
			for (uint num2 = 30U; num2 < 30U + uint32_; num2 += 1U)
			{
				if (this.class405_0.method_11(num + num2 * 4U) == 0U)
				{
					return false;
				}
			}
			return true;
		}
	}

	// Token: 0x17000A31 RID: 2609
	// (get) Token: 0x06002CD0 RID: 11472 RVA: 0x0012D99C File Offset: 0x0012BB9C
	public bool Boolean_8
	{
		get
		{
			uint uint32_ = this.UInt32_23;
			uint num = this.class405_0.method_20(this.class392_0.UInt32_54);
			for (uint num2 = 0U; num2 < uint32_; num2 += 1U)
			{
				if (this.class405_0.method_11(num + num2 * 4U) == 0U)
				{
					return false;
				}
			}
			return true;
		}
	}

	// Token: 0x17000A32 RID: 2610
	// (get) Token: 0x06002CD1 RID: 11473 RVA: 0x0012D9E8 File Offset: 0x0012BBE8
	public bool Boolean_9
	{
		get
		{
			for (uint num = 0U; num < 12U; num += 1U)
			{
				if (this.class405_0.method_20(new uint[]
				{
					this.class392_0.UInt32_63[0],
					6476U,
					num * 4U
				}) > 0U)
				{
					return true;
				}
			}
			return false;
		}
	}

	// Token: 0x17000A33 RID: 2611
	// (get) Token: 0x06002CD2 RID: 11474 RVA: 0x0012DA38 File Offset: 0x0012BC38
	public bool Boolean_10
	{
		get
		{
			uint uint32_ = this.UInt32_23;
			uint num = this.class405_0.method_20(this.class392_0.UInt32_54);
			uint num2 = 0U;
			for (uint num3 = 0U; num3 < uint32_; num3 += 1U)
			{
				if (this.class405_0.method_11(num + num3 * 4U) == 0U)
				{
					num2 += 1U;
				}
				if (num2 >= 2U)
				{
					break;
				}
			}
			return num2 < 2U;
		}
	}

	// Token: 0x17000A34 RID: 2612
	// (get) Token: 0x06002CD3 RID: 11475 RVA: 0x0012DA94 File Offset: 0x0012BC94
	public bool Boolean_11
	{
		get
		{
			uint uint32_ = this.UInt32_23;
			uint num = this.class405_0.method_20(this.class392_0.UInt32_54);
			uint num2 = 0U;
			for (uint num3 = 0U; num3 < uint32_; num3 += 1U)
			{
				if (this.class405_0.method_11(num + num3 * 4U) == 0U)
				{
					num2 += 1U;
				}
				if (num2 >= 3U)
				{
					break;
				}
			}
			return num2 < 3U;
		}
	}

	// Token: 0x17000A35 RID: 2613
	// (get) Token: 0x06002CD4 RID: 11476 RVA: 0x00020B1F File Offset: 0x0001ED1F
	// (set) Token: 0x06002CD5 RID: 11477 RVA: 0x00020B27 File Offset: 0x0001ED27
	public string String_3 { get; set; }

	// Token: 0x17000A36 RID: 2614
	// (get) Token: 0x06002CD6 RID: 11478 RVA: 0x00020B30 File Offset: 0x0001ED30
	// (set) Token: 0x06002CD7 RID: 11479 RVA: 0x00020B38 File Offset: 0x0001ED38
	public uint UInt32_25 { get; set; }

	// Token: 0x17000A37 RID: 2615
	// (get) Token: 0x06002CD8 RID: 11480 RVA: 0x00020B41 File Offset: 0x0001ED41
	// (set) Token: 0x06002CD9 RID: 11481 RVA: 0x00020B49 File Offset: 0x0001ED49
	private int Int32_0 { get; set; }

	// Token: 0x17000A38 RID: 2616
	// (get) Token: 0x06002CDA RID: 11482 RVA: 0x00020B52 File Offset: 0x0001ED52
	public string[] String_4
	{
		get
		{
			return this.string_2;
		}
	}

	// Token: 0x17000A39 RID: 2617
	// (get) Token: 0x06002CDB RID: 11483 RVA: 0x00020B5A File Offset: 0x0001ED5A
	// (set) Token: 0x06002CDC RID: 11484 RVA: 0x00020B62 File Offset: 0x0001ED62
	public string String_5 { get; set; }

	// Token: 0x17000A3A RID: 2618
	// (get) Token: 0x06002CDD RID: 11485 RVA: 0x00020B6B File Offset: 0x0001ED6B
	// (set) Token: 0x06002CDE RID: 11486 RVA: 0x00020B73 File Offset: 0x0001ED73
	public string String_6 { get; set; }

	// Token: 0x17000A3B RID: 2619
	// (get) Token: 0x06002CDF RID: 11487 RVA: 0x00020B7C File Offset: 0x0001ED7C
	// (set) Token: 0x06002CE0 RID: 11488 RVA: 0x00020B84 File Offset: 0x0001ED84
	public string String_7 { get; set; }

	// Token: 0x06002CE1 RID: 11489 RVA: 0x00020B8D File Offset: 0x0001ED8D
	public static bool smethod_0(int int_3)
	{
		return int_3 >= 31 && int_3 <= 90 && int_3 != 64;
	}

	// Token: 0x06002CE2 RID: 11490 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	public static string smethod_1(int int_3)
	{
		return "";
	}

	// Token: 0x17000A3C RID: 2620
	// (get) Token: 0x06002CE3 RID: 11491 RVA: 0x00020BA1 File Offset: 0x0001EDA1
	public string String_8
	{
		get
		{
			return Regex.Replace(this.String_2, "[^0-9a-zA-Z]", "");
		}
	}

	// Token: 0x06002CE4 RID: 11492 RVA: 0x0012DAF0 File Offset: 0x0012BCF0
	public void method_2()
	{
		try
		{
			this.String_6 = "";
			this.String_7 = "";
			this.Class159_0.Class239_0.method_2();
			this.Class159_0.Class239_0.Boolean_0 = true;
			Stopwatch.StartNew();
			this.list_0.Clear();
			if (this.list_0.Count == 0)
			{
				this.string_2 = new string[4];
				this.list_0.Add(this.Class159_0.Class405_0.method_11(this.Class159_0.UInt32_3 + 10070784U) + 4751780U);
				this.list_0.Add(this.Class159_0.Class405_0.method_11(this.Class159_0.UInt32_3 + 10070784U) + 4751780U + 16U);
				this.list_0.Add(this.Class159_0.Class405_0.method_11(this.Class159_0.UInt32_3 + 10070784U) + 4751780U + 32U);
				this.list_0.Add(this.Class159_0.Class405_0.method_11(this.Class159_0.UInt32_3 + 10070784U) + 4751780U + 48U);
			}
			int num = -1;
			List<Class432.Class434> list = new List<Class432.Class434>();
			int num2 = 0;
			while (num2 < this.list_0.Count && num <= 3)
			{
				int num3 = (int)this.Class159_0.Class405_0.method_14(this.list_0[num2]);
				int num4 = (int)this.Class159_0.Class405_0.method_14(this.list_0[num2] + 2U);
				int num5 = (int)this.Class159_0.Class405_0.method_14(this.list_0[num2] + 4U);
				int num6 = (int)this.Class159_0.Class405_0.method_14(this.list_0[num2] + 6U);
				if (Class432.smethod_0(num3) && Class432.smethod_0(num4) && Class432.smethod_0(num5) && Class432.smethod_0(num6))
				{
					num++;
					this.string_2[num] = Class265.char_0[num3].ToString() + Class265.char_0[num4].ToString() + Class265.char_0[num5].ToString() + Class265.char_0[num6].ToString();
					list.Add(new Class432.Class434
					{
						int_0 = 4 - num,
						string_0 = this.string_2[num]
					});
				}
				num2++;
			}
			list = list.OrderBy(new Func<Class432.Class434, int>(Class432.Class435.<>9.method_0)).Reverse<Class432.Class434>().ToList<Class432.Class434>();
			for (int i = 0; i < list.Count; i++)
			{
				this.string_2[i] = list[i].string_0;
			}
			try
			{
				this.String_3 = string.Empty;
				this.String_5 = string.Empty;
				uint num9;
				do
				{
					if (this.UInt32_25 == 0U)
					{
						Class405 @class = this.Class159_0.Class405_0;
						uint[] array = new uint[]
						{
							0U,
							28U,
							16U,
							36U,
							68U,
							16U,
							212U,
							4U,
							104U,
							8U,
							240U
						};
						array[0] = this.Class159_0.UInt32_3 + 10131324U;
						this.UInt32_25 = @class.method_20(array);
						if (this.class405_0.method_11(this.UInt32_25).ToString("X8").StartsWith("A0"))
						{
							goto IL_58A;
						}
						uint num7 = this.Class159_0.Class239_0.method_3("## 00 00 00 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ??");
						if (num7 == 0U)
						{
							goto IL_77C;
						}
						this.UInt32_25 = num7 + 4U;
					}
					else
					{
						uint num8 = this.Class159_0.Class239_0.method_4("## 00 00 00 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ?? A0 ??");
						if (num8 == 0U)
						{
							goto IL_77C;
						}
						this.UInt32_25 = num8 + 4U;
					}
					num9 = this.class405_0.method_14(this.UInt32_25);
					if (num9 == 40960U || num9 == 41215U)
					{
						this.String_3 = "";
						byte[] array2 = new byte[9216];
						Class405.ReadProcessMemory_1(this.class405_0.IntPtr_0, this.UInt32_25, array2, array2.Length, 0);
						for (int j = 0; j < 9216; j += 2)
						{
							byte[] array3 = new byte[4];
							array3[0] = array2[j];
							array3[1] = array2[j + 1];
							num9 = BitConverter.ToUInt32(array3, 0);
							if (num9 == 40960U)
							{
								this.String_6 += "0";
								this.String_7 += "0";
							}
							else
							{
								this.String_6 += "1";
								this.String_7 += "1";
							}
							if (this.String_6.Length == 8)
							{
								this.String_3 += Convert.ToInt32(this.String_6, 2).ToString("X2");
								this.String_6 = "";
							}
						}
					}
					string text = this.String_3;
					this.String_3 = string.Concat(new string[]
					{
						this.String_3,
						this.string_2[0],
						this.string_2[1],
						this.string_2[2],
						this.string_2[3]
					});
					this.String_5 = Class426.Class430.smethod_3(this.String_3);
				}
				while (Class159.list_1.Contains(this.String_5));
				Class159.list_1.Add(this.String_5);
				Class268.smethod_0();
				goto IL_77C;
				IL_58A:
				this.String_3 = "";
				num9 = this.class405_0.method_14(this.UInt32_25);
				if (num9 == 40960U || num9 == 41215U)
				{
					byte[] array4 = new byte[9216];
					Class405.ReadProcessMemory_1(this.class405_0.IntPtr_0, this.UInt32_25, array4, array4.Length, 0);
					for (int k = 0; k < 9216; k += 2)
					{
						byte[] array5 = new byte[4];
						array5[0] = array4[k];
						array5[1] = array4[k + 1];
						num9 = BitConverter.ToUInt32(array5, 0);
						if (num9 == 40960U)
						{
							this.String_6 += "0";
							this.String_7 += "0";
						}
						else
						{
							this.String_6 += "1";
							this.String_7 += "1";
						}
						if (this.String_6.Length == 8)
						{
							this.String_3 += Convert.ToInt32(this.String_6, 2).ToString("X2");
							this.String_6 = "";
						}
					}
				}
				string text2 = this.String_3;
				this.String_3 = string.Concat(new string[]
				{
					this.String_3,
					this.string_2[0],
					this.string_2[1],
					this.string_2[2],
					this.string_2[3]
				});
				this.String_5 = Class426.Class430.smethod_3(this.String_3);
				if (!Class159.list_1.Contains(this.String_5))
				{
					Class159.list_1.Add(this.String_5);
					Class268.smethod_0();
				}
				this.Class159_0.Class239_0.Boolean_0 = false;
				this.bool_7 = true;
				IL_77C:;
			}
			catch
			{
			}
		}
		catch
		{
		}
		this.Class159_0.Class239_0.Boolean_0 = false;
		this.bool_7 = true;
	}

	// Token: 0x17000A3D RID: 2621
	// (get) Token: 0x06002CE5 RID: 11493 RVA: 0x00020BB8 File Offset: 0x0001EDB8
	// (set) Token: 0x06002CE6 RID: 11494 RVA: 0x00020BC0 File Offset: 0x0001EDC0
	public uint UInt32_26 { get; set; }

	// Token: 0x17000A3E RID: 2622
	// (get) Token: 0x06002CE7 RID: 11495 RVA: 0x0012E2D0 File Offset: 0x0012C4D0
	// (set) Token: 0x06002CE8 RID: 11496 RVA: 0x00020BC9 File Offset: 0x0001EDC9
	public Bitmap Bitmap_0
	{
		get
		{
			if (this.bitmap_0 == null && !string.IsNullOrEmpty(this.String_7) && this.String_7.Length == 4608)
			{
				this.bitmap_0 = new Bitmap(128, 36);
				int num = 0;
				string text = this.String_7;
				for (int i = 0; i < text.Length; i++)
				{
					if (text[i] == '0')
					{
						this.bitmap_0.SetPixel(num / 2 % 128, num / 2 / 128, Color.Black);
					}
					else
					{
						this.bitmap_0.SetPixel(num / 2 % 128, num / 2 / 128, Color.White);
					}
					num += 2;
				}
				this.bitmap_0 = new Bitmap(this.bitmap_0, new Size(160, 45));
			}
			return this.bitmap_0;
		}
		set
		{
			this.bitmap_0 = value;
		}
	}

	// Token: 0x17000A3F RID: 2623
	// (get) Token: 0x06002CE9 RID: 11497 RVA: 0x0012E3B4 File Offset: 0x0012C5B4
	public string String_9
	{
		get
		{
			uint num = this.class405_0.method_0("UI_CEGUI.dll");
			if (this.class392_0.UInt32_106 == 1U)
			{
				num += 400392U;
			}
			else
			{
				num += 226052U;
			}
			return this.class405_0.method_26(this.class405_0.method_11(num));
		}
	}

	// Token: 0x17000A40 RID: 2624
	// (get) Token: 0x06002CEA RID: 11498 RVA: 0x00020BD2 File Offset: 0x0001EDD2
	public bool Boolean_12
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_137) == 1U;
		}
	}

	// Token: 0x17000A41 RID: 2625
	// (get) Token: 0x06002CEB RID: 11499 RVA: 0x00020BED File Offset: 0x0001EDED
	public bool Boolean_13
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_138) == 1U;
		}
	}

	// Token: 0x17000A42 RID: 2626
	// (get) Token: 0x06002CEC RID: 11500 RVA: 0x00020C08 File Offset: 0x0001EE08
	public uint UInt32_27
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_59);
		}
	}

	// Token: 0x17000A43 RID: 2627
	// (get) Token: 0x06002CED RID: 11501 RVA: 0x00020C20 File Offset: 0x0001EE20
	// (set) Token: 0x06002CEE RID: 11502 RVA: 0x00020C28 File Offset: 0x0001EE28
	public uint UInt32_28 { get; set; }

	// Token: 0x17000A44 RID: 2628
	// (get) Token: 0x06002CEF RID: 11503 RVA: 0x00020C31 File Offset: 0x0001EE31
	public bool Boolean_14
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_60) == 1U;
		}
	}

	// Token: 0x17000A45 RID: 2629
	// (get) Token: 0x06002CF0 RID: 11504 RVA: 0x00020C4C File Offset: 0x0001EE4C
	public bool Boolean_15
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_157) == 1U;
		}
	}

	// Token: 0x17000A46 RID: 2630
	// (get) Token: 0x06002CF1 RID: 11505 RVA: 0x00020C67 File Offset: 0x0001EE67
	public bool Boolean_16
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_62) == 1U;
		}
	}

	// Token: 0x17000A47 RID: 2631
	// (get) Token: 0x06002CF2 RID: 11506 RVA: 0x00020C82 File Offset: 0x0001EE82
	// (set) Token: 0x06002CF3 RID: 11507 RVA: 0x00020C8A File Offset: 0x0001EE8A
	public string String_10 { get; set; }

	// Token: 0x17000A48 RID: 2632
	// (get) Token: 0x06002CF4 RID: 11508 RVA: 0x00020C93 File Offset: 0x0001EE93
	// (set) Token: 0x06002CF5 RID: 11509 RVA: 0x00020C9B File Offset: 0x0001EE9B
	public uint UInt32_29 { get; set; }

	// Token: 0x06002CF6 RID: 11510 RVA: 0x00020CA4 File Offset: 0x0001EEA4
	public bool method_3(uint uint_28)
	{
		return uint_28 >= 663U && uint_28 <= 667U;
	}

	// Token: 0x06002CF7 RID: 11511 RVA: 0x00020CB9 File Offset: 0x0001EEB9
	public bool method_4(uint uint_28)
	{
		return uint_28 >= 501U && uint_28 <= 545U;
	}

	// Token: 0x17000A49 RID: 2633
	// (get) Token: 0x06002CF8 RID: 11512 RVA: 0x00020CCE File Offset: 0x0001EECE
	public string String_11
	{
		get
		{
			return Class426.smethod_64(this.string_7);
		}
	}

	// Token: 0x17000A4A RID: 2634
	// (get) Token: 0x06002CF9 RID: 11513 RVA: 0x00020CDB File Offset: 0x0001EEDB
	// (set) Token: 0x06002CFA RID: 11514 RVA: 0x00020CE3 File Offset: 0x0001EEE3
	public string String_12 { get; set; }

	// Token: 0x17000A4B RID: 2635
	// (get) Token: 0x06002CFB RID: 11515 RVA: 0x00020CEC File Offset: 0x0001EEEC
	// (set) Token: 0x06002CFC RID: 11516 RVA: 0x00020CF4 File Offset: 0x0001EEF4
	public string String_13 { get; set; }

	// Token: 0x17000A4C RID: 2636
	// (get) Token: 0x06002CFD RID: 11517 RVA: 0x00020CFD File Offset: 0x0001EEFD
	// (set) Token: 0x06002CFE RID: 11518 RVA: 0x00020D05 File Offset: 0x0001EF05
	public string String_14 { get; set; }

	// Token: 0x17000A4D RID: 2637
	// (get) Token: 0x06002CFF RID: 11519 RVA: 0x00020D0E File Offset: 0x0001EF0E
	// (set) Token: 0x06002D00 RID: 11520 RVA: 0x00020D16 File Offset: 0x0001EF16
	public uint UInt32_30 { get; set; }

	// Token: 0x17000A4E RID: 2638
	// (get) Token: 0x06002D01 RID: 11521 RVA: 0x00020D1F File Offset: 0x0001EF1F
	// (set) Token: 0x06002D02 RID: 11522 RVA: 0x00020D27 File Offset: 0x0001EF27
	public uint UInt32_31 { get; set; }

	// Token: 0x17000A4F RID: 2639
	// (get) Token: 0x06002D03 RID: 11523 RVA: 0x00020D30 File Offset: 0x0001EF30
	// (set) Token: 0x06002D04 RID: 11524 RVA: 0x00020D38 File Offset: 0x0001EF38
	public int Int32_1 { get; set; }

	// Token: 0x17000A50 RID: 2640
	// (get) Token: 0x06002D05 RID: 11525 RVA: 0x00020D41 File Offset: 0x0001EF41
	// (set) Token: 0x06002D06 RID: 11526 RVA: 0x00020D49 File Offset: 0x0001EF49
	public uint UInt32_32 { get; set; }

	// Token: 0x17000A51 RID: 2641
	// (get) Token: 0x06002D07 RID: 11527 RVA: 0x00020D52 File Offset: 0x0001EF52
	// (set) Token: 0x06002D08 RID: 11528 RVA: 0x00020D5A File Offset: 0x0001EF5A
	public string String_15 { get; set; }

	// Token: 0x17000A52 RID: 2642
	// (get) Token: 0x06002D09 RID: 11529 RVA: 0x00020D63 File Offset: 0x0001EF63
	// (set) Token: 0x06002D0A RID: 11530 RVA: 0x00020D6B File Offset: 0x0001EF6B
	public uint UInt32_33 { get; set; }

	// Token: 0x17000A53 RID: 2643
	// (get) Token: 0x06002D0B RID: 11531 RVA: 0x00020D74 File Offset: 0x0001EF74
	public uint UInt32_34
	{
		get
		{
			return this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_4);
		}
	}

	// Token: 0x17000A54 RID: 2644
	// (get) Token: 0x06002D0C RID: 11532 RVA: 0x00020D93 File Offset: 0x0001EF93
	public uint UInt32_35
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_132);
		}
	}

	// Token: 0x17000A55 RID: 2645
	// (get) Token: 0x06002D0D RID: 11533 RVA: 0x00020DAB File Offset: 0x0001EFAB
	public bool Boolean_17
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_134) == 1U;
		}
	}

	// Token: 0x17000A56 RID: 2646
	// (get) Token: 0x06002D0E RID: 11534 RVA: 0x00020DC6 File Offset: 0x0001EFC6
	public bool Boolean_18
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_122) == 1U;
		}
	}

	// Token: 0x17000A57 RID: 2647
	// (get) Token: 0x06002D0F RID: 11535 RVA: 0x00020DE1 File Offset: 0x0001EFE1
	public bool Boolean_19
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_125) == 1U;
		}
	}

	// Token: 0x17000A58 RID: 2648
	// (get) Token: 0x06002D10 RID: 11536 RVA: 0x00020DFC File Offset: 0x0001EFFC
	public bool Boolean_20
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_127) == 1U;
		}
	}

	// Token: 0x17000A59 RID: 2649
	// (get) Token: 0x06002D11 RID: 11537 RVA: 0x00020E17 File Offset: 0x0001F017
	public bool Boolean_21
	{
		get
		{
			return this.Class159_0.Class394_0.class393_0 != null && this.Class159_0.Class394_0.class393_0.List_0.Contains(271U);
		}
	}

	// Token: 0x17000A5A RID: 2650
	// (get) Token: 0x06002D12 RID: 11538 RVA: 0x00020E51 File Offset: 0x0001F051
	public bool Boolean_22
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_126) == 1U;
		}
	}

	// Token: 0x17000A5B RID: 2651
	// (get) Token: 0x06002D13 RID: 11539 RVA: 0x00020E6C File Offset: 0x0001F06C
	public bool Boolean_23
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_124) == 1U;
		}
	}

	// Token: 0x17000A5C RID: 2652
	// (get) Token: 0x06002D14 RID: 11540 RVA: 0x00020E87 File Offset: 0x0001F087
	public bool Boolean_24
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_128) == 1U;
		}
	}

	// Token: 0x17000A5D RID: 2653
	// (get) Token: 0x06002D15 RID: 11541 RVA: 0x00020EA2 File Offset: 0x0001F0A2
	public bool Boolean_25
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_130) == 1U;
		}
	}

	// Token: 0x17000A5E RID: 2654
	// (get) Token: 0x06002D16 RID: 11542 RVA: 0x00020EBD File Offset: 0x0001F0BD
	public uint UInt32_36
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_67);
		}
	}

	// Token: 0x17000A5F RID: 2655
	// (get) Token: 0x06002D17 RID: 11543 RVA: 0x00020ED5 File Offset: 0x0001F0D5
	public uint UInt32_37
	{
		get
		{
			return Class432.smethod_2(this.UInt32_5, this.UInt32_8, true);
		}
	}

	// Token: 0x17000A60 RID: 2656
	// (get) Token: 0x06002D18 RID: 11544 RVA: 0x00020EE9 File Offset: 0x0001F0E9
	public uint UInt32_38
	{
		get
		{
			return Class432.smethod_2(this.UInt32_5, this.UInt32_8, false);
		}
	}

	// Token: 0x17000A61 RID: 2657
	// (get) Token: 0x06002D19 RID: 11545 RVA: 0x00020EFD File Offset: 0x0001F0FD
	public uint UInt32_39
	{
		get
		{
			return Class432.smethod_2(this.UInt32_6, this.UInt32_9, true);
		}
	}

	// Token: 0x17000A62 RID: 2658
	// (get) Token: 0x06002D1A RID: 11546 RVA: 0x00020F11 File Offset: 0x0001F111
	public uint UInt32_40
	{
		get
		{
			return Class432.smethod_2(this.UInt32_6, this.UInt32_9, false);
		}
	}

	// Token: 0x17000A63 RID: 2659
	// (get) Token: 0x06002D1B RID: 11547 RVA: 0x00020F25 File Offset: 0x0001F125
	public uint UInt32_41
	{
		get
		{
			return Class432.smethod_2(this.UInt32_11, this.UInt32_12, false);
		}
	}

	// Token: 0x17000A64 RID: 2660
	// (get) Token: 0x06002D1C RID: 11548 RVA: 0x00020F39 File Offset: 0x0001F139
	public uint UInt32_42
	{
		get
		{
			return Class432.smethod_2(this.UInt32_11, this.UInt32_12, true);
		}
	}

	// Token: 0x17000A65 RID: 2661
	// (get) Token: 0x06002D1D RID: 11549 RVA: 0x00020F4D File Offset: 0x0001F14D
	public bool Boolean_26
	{
		get
		{
			return this.UInt32_28 != 5U && (this.UInt32_28 > 2U && this.UInt32_28 < 10U);
		}
	}

	// Token: 0x17000A66 RID: 2662
	// (get) Token: 0x06002D1E RID: 11550 RVA: 0x00020F70 File Offset: 0x0001F170
	public bool Boolean_27
	{
		get
		{
			if (this.UInt32_28 <= 0U)
			{
				return false;
			}
			if (this.UInt32_28 != 2U)
			{
				if (this.UInt32_28 != 7U)
				{
					return true;
				}
			}
			return false;
		}
	}

	// Token: 0x06002D1F RID: 11551 RVA: 0x0012E40C File Offset: 0x0012C60C
	private static uint smethod_2(uint uint_28, uint uint_29, bool bool_9 = true)
	{
		if (uint_29 == 0U)
		{
			return 0U;
		}
		uint num = uint_28 * 100U / uint_29;
		if (num == 0U && uint_28 > 0U)
		{
			return 1U;
		}
		if (bool_9 && num >= 100U)
		{
			return 99U;
		}
		return num;
	}

	// Token: 0x17000A67 RID: 2663
	// (get) Token: 0x06002D20 RID: 11552 RVA: 0x00020F94 File Offset: 0x0001F194
	public int Int32_2
	{
		get
		{
			if (this.UInt32_2 > 0U && this.UInt32_2 < 150U)
			{
				return Class402.int_0[(int)this.UInt32_2];
			}
			return Class402.int_0[1];
		}
	}

	// Token: 0x17000A68 RID: 2664
	// (get) Token: 0x06002D21 RID: 11553 RVA: 0x00020FC0 File Offset: 0x0001F1C0
	public float Single_0
	{
		get
		{
			return this.UInt32_7 * 100f / (float)this.Int32_2;
		}
	}

	// Token: 0x17000A69 RID: 2665
	// (get) Token: 0x06002D22 RID: 11554 RVA: 0x0012E43C File Offset: 0x0012C63C
	public bool Boolean_28
	{
		get
		{
			if ((ulong)this.UInt32_1 != (ulong)((long)Class381.int_11) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_3) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_6) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_4) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_10) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_5) && (ulong)this.UInt32_1 != (ulong)((long)Class381.int_8))
			{
				if ((ulong)this.UInt32_1 != (ulong)((long)Class381.int_12))
				{
					return false;
				}
			}
			return true;
		}
	}

	// Token: 0x17000A6A RID: 2666
	// (get) Token: 0x06002D23 RID: 11555 RVA: 0x00020FD8 File Offset: 0x0001F1D8
	public bool Boolean_29
	{
		get
		{
			return !this.Boolean_28;
		}
	}

	// Token: 0x17000A6B RID: 2667
	// (get) Token: 0x06002D24 RID: 11556 RVA: 0x00020FE3 File Offset: 0x0001F1E3
	// (set) Token: 0x06002D25 RID: 11557 RVA: 0x00020FEB File Offset: 0x0001F1EB
	public bool Boolean_30 { get; set; }

	// Token: 0x17000A6C RID: 2668
	// (get) Token: 0x06002D26 RID: 11558 RVA: 0x00020FF4 File Offset: 0x0001F1F4
	public bool Boolean_31
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_123) == 1U;
		}
	}

	// Token: 0x17000A6D RID: 2669
	// (get) Token: 0x06002D27 RID: 11559 RVA: 0x0002100F File Offset: 0x0001F20F
	public bool Boolean_32
	{
		get
		{
			return this.Boolean_34 && this.String_1.Contains(this.String_10);
		}
	}

	// Token: 0x17000A6E RID: 2670
	// (get) Token: 0x06002D28 RID: 11560 RVA: 0x00021031 File Offset: 0x0001F231
	// (set) Token: 0x06002D29 RID: 11561 RVA: 0x00021039 File Offset: 0x0001F239
	public bool Boolean_33 { get; set; }

	// Token: 0x17000A6F RID: 2671
	// (get) Token: 0x06002D2A RID: 11562 RVA: 0x0012E4C8 File Offset: 0x0012C6C8
	public bool Boolean_34
	{
		get
		{
			if (!string.IsNullOrEmpty(this.String_1) && !string.IsNullOrEmpty(this.String_2))
			{
				if (!this.String_1.Contains("00000000") && !this.String_1.Contains("FFFFFFFF") && !(this.String_2 == "ĐăngNhập") && this.UInt32_2 >= 1U)
				{
					if (this.UInt32_2 != 4294967295U)
					{
						this.Boolean_33 = true;
						return true;
					}
				}
				return false;
			}
			return false;
		}
	}

	// Token: 0x17000A70 RID: 2672
	// (get) Token: 0x06002D2B RID: 11563 RVA: 0x0012E548 File Offset: 0x0012C748
	public uint UInt32_43
	{
		get
		{
			uint num = 0U;
			uint num2 = this.class405_0.method_20(this.class392_0.UInt32_58);
			for (uint num3 = 0U; num3 < 20U; num3 += 1U)
			{
				if (this.class405_0.method_11(num2 + this.class392_0.UInt32_24 * num3 + this.class392_0.UInt32_25) != 0U)
				{
					if (this.class405_0.method_11(num2 + this.class392_0.UInt32_24 * num3 + this.class392_0.UInt32_27) <= 0U)
					{
						break;
					}
					num += 1U;
				}
			}
			return num;
		}
	}

	// Token: 0x17000A71 RID: 2673
	// (get) Token: 0x06002D2C RID: 11564 RVA: 0x00021042 File Offset: 0x0001F242
	// (set) Token: 0x06002D2D RID: 11565 RVA: 0x0002104A File Offset: 0x0001F24A
	public bool Boolean_35 { get; set; }

	// Token: 0x17000A72 RID: 2674
	// (get) Token: 0x06002D2E RID: 11566 RVA: 0x00021053 File Offset: 0x0001F253
	public bool Boolean_36
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_0) == 1U;
		}
	}

	// Token: 0x17000A73 RID: 2675
	// (get) Token: 0x06002D2F RID: 11567 RVA: 0x0012E5D4 File Offset: 0x0012C7D4
	public bool Boolean_37
	{
		get
		{
			if (this.class392_0.UInt32_106 != 1U)
			{
				return this.class405_0.method_20(new uint[]
				{
					6563448U,
					0U,
					12U,
					100U
				}) == 1U;
			}
			if (this.Class159_0.Class392_0.Boolean_1)
			{
				return this.class405_0.method_20(new uint[]
				{
					11421928U,
					8U,
					4U,
					332U
				}) == 1U;
			}
			return this.class405_0.method_20(new uint[]
			{
				11344780U,
				0U,
				12U,
				100U
			}) == 1U;
		}
	}

	// Token: 0x17000A74 RID: 2676
	// (get) Token: 0x06002D30 RID: 11568 RVA: 0x0002106E File Offset: 0x0001F26E
	public bool Boolean_38
	{
		get
		{
			Class405 @class = this.class405_0;
			uint[] array = new uint[]
			{
				0U,
				8U,
				4U,
				324U
			};
			array[0] = this.Class159_0.UInt32_3 + 8740008U;
			return @class.method_20(array) == 1U;
		}
	}

	// Token: 0x17000A75 RID: 2677
	// (get) Token: 0x06002D31 RID: 11569 RVA: 0x000210A3 File Offset: 0x0001F2A3
	public bool Boolean_39
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_135) == 1U;
		}
	}

	// Token: 0x17000A76 RID: 2678
	// (get) Token: 0x06002D32 RID: 11570 RVA: 0x000210BE File Offset: 0x0001F2BE
	public bool Boolean_40
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_136) == 1U;
		}
	}

	// Token: 0x17000A77 RID: 2679
	// (get) Token: 0x06002D33 RID: 11571 RVA: 0x0012E660 File Offset: 0x0012C860
	public List<uint> List_0
	{
		get
		{
			List<uint> list = new List<uint>();
			if (this.class405_0.method_20(this.class392_0.UInt32_142) != 0U)
			{
				list.Add(this.class405_0.method_20(this.class392_0.UInt32_142));
			}
			if (this.class392_0.UInt32_106 == 1U)
			{
				uint num = 0U;
				do
				{
					this.class392_0.UInt32_143[2] = num;
					if (this.class405_0.method_20(this.class392_0.UInt32_143) != 0U)
					{
						list.Add(this.class405_0.method_20(this.class392_0.UInt32_143));
					}
					num += 4U;
				}
				while (num <= 12U);
			}
			return list;
		}
	}

	// Token: 0x17000A78 RID: 2680
	// (get) Token: 0x06002D34 RID: 11572 RVA: 0x0012E70C File Offset: 0x0012C90C
	public bool Boolean_41
	{
		get
		{
			if (Main.Boolean_23)
			{
				return false;
			}
			if (User.Boolean_1 && this.UInt32_2 >= 20U)
			{
				return true;
			}
			bool flag = this.class405_0.method_20(this.class392_0.UInt32_142) > 0U;
			if (this.class392_0.UInt32_106 == 1U)
			{
				uint num = 0U;
				while (!flag)
				{
					this.class392_0.UInt32_143[2] = num;
					flag = (this.class405_0.method_20(this.class392_0.UInt32_143) > 0U);
					num += 4U;
					if (num > 12U)
					{
						break;
					}
				}
			}
			return flag;
		}
	}

	// Token: 0x17000A79 RID: 2681
	// (get) Token: 0x06002D35 RID: 11573 RVA: 0x0012E798 File Offset: 0x0012C998
	public string String_16
	{
		get
		{
			uint uint32_ = this.UInt32_1;
			if (uint32_ <= 32U)
			{
				switch (uint32_)
				{
				case 1U:
					return "Thiếu Lâm";
				case 2U:
					return "Minh Giáo";
				case 3U:
					return "Cái Bang";
				case 4U:
					return "Võ Đang";
				case 5U:
					return "Nga My";
				case 6U:
					return "Tinh Túc";
				case 7U:
					return "Thiên Long";
				case 8U:
					return "Thiên Sơn";
				case 9U:
					return "Tiêu Dao";
				default:
					if (uint32_ == 32U)
					{
						return "Mộ Dung";
					}
					break;
				}
			}
			else
			{
				if (uint32_ == 37U)
				{
					return "Đường Môn";
				}
				if (uint32_ == 53U)
				{
					return "Quỷ Cốc";
				}
				if (uint32_ == 54U)
				{
					return "Đào Hoa";
				}
			}
			return "Không Có";
		}
	}

	// Token: 0x06002D36 RID: 11574 RVA: 0x0012E848 File Offset: 0x0012CA48
	public static string smethod_3(string string_14)
	{
		int num = Class426.smethod_41(string_14);
		if (num <= 32)
		{
			switch (num)
			{
			case 1:
				return "Thiếu Lâm";
			case 2:
				return "Minh Giáo";
			case 3:
				return "Cái Bang";
			case 4:
				return "Võ Đang";
			case 5:
				return "Nga My";
			case 6:
				return "Tinh Túc";
			case 7:
				return "Thiên Long";
			case 8:
				return "Thiên Sơn";
			case 9:
				return "Tiêu Dao";
			default:
				if (num == 32)
				{
					return "Mộ Dung";
				}
				break;
			}
		}
		else
		{
			if (num == 37)
			{
				return "Đường Môn";
			}
			if (num == 53)
			{
				return "Quỷ Cốc";
			}
			if (num == 54)
			{
				return "Đào Hoa";
			}
		}
		return "Không Có";
	}

	// Token: 0x06002D37 RID: 11575 RVA: 0x0012E8F8 File Offset: 0x0012CAF8
	public static int smethod_4(string string_14)
	{
		uint num = Class448.smethod_0(string_14);
		if (num <= 2589541653U)
		{
			if (num <= 997612403U)
			{
				if (num != 82019574U)
				{
					if (num != 982159052U)
					{
						if (num == 997612403U)
						{
							if (string_14 == "Minh Giáo")
							{
								return 2;
							}
						}
					}
					else if (string_14 == "Võ Đang")
					{
						return 4;
					}
				}
				else if (string_14 == "Thiên Long")
				{
					return 7;
				}
			}
			else if (num != 1481168545U)
			{
				if (num != 2110238270U)
				{
					if (num == 2589541653U)
					{
						if (string_14 == "Quỷ Cốc")
						{
							return 53;
						}
					}
				}
				else if (string_14 == "Đường Môn")
				{
					return 37;
				}
			}
			else if (string_14 == "Nga My")
			{
				return 5;
			}
		}
		else if (num <= 3266684102U)
		{
			if (num != 2732708749U)
			{
				if (num != 3116342875U)
				{
					if (num == 3266684102U)
					{
						if (string_14 == "Đào Hoa")
						{
							return 54;
						}
					}
				}
				else if (string_14 == "Tinh Túc")
				{
					return 6;
				}
			}
			else if (string_14 == "Thiếu Lâm")
			{
				return 1;
			}
		}
		else if (num <= 3994016365U)
		{
			if (num != 3561406658U)
			{
				if (num == 3994016365U)
				{
					if (string_14 == "Mộ Dung")
					{
						return 32;
					}
				}
			}
			else if (string_14 == "Cái Bang")
			{
				return 3;
			}
		}
		else if (num != 4084724735U)
		{
			if (num == 4218621386U)
			{
				if (string_14 == "Thiên Sơn")
				{
					return 8;
				}
			}
		}
		else if (string_14 == "Tiêu Dao")
		{
			return 9;
		}
		return -1;
	}

	// Token: 0x06002D38 RID: 11576 RVA: 0x0012EA88 File Offset: 0x0012CC88
	public static string smethod_5(int int_3)
	{
		if (int_3 <= 32)
		{
			switch (int_3)
			{
			case 1:
				return "Thiếu Lâm";
			case 2:
				return "Minh Giáo";
			case 3:
				return "Cái Bang";
			case 4:
				return "Võ Đang";
			case 5:
				return "Nga My";
			case 6:
				return "Tinh Túc";
			case 7:
				return "Thiên Long";
			case 8:
				return "Thiên Sơn";
			case 9:
				return "Tiêu Dao";
			default:
				if (int_3 == 32)
				{
					return "Mộ Dung";
				}
				break;
			}
		}
		else
		{
			if (int_3 == 37)
			{
				return "Đường Môn";
			}
			if (int_3 == 53)
			{
				return "Quỷ Cốc";
			}
			if (int_3 == 54)
			{
				return "Đào Hoa";
			}
		}
		return "Không Có";
	}

	// Token: 0x17000A7A RID: 2682
	// (get) Token: 0x06002D39 RID: 11577 RVA: 0x0012EB30 File Offset: 0x0012CD30
	public Class424 Class424_1
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class374.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class369.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class366.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class377.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class371.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class376.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class372.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class373.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class375.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class370.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class367.class424_1;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class333.class424_2;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class332.class424_1;
			}
			return null;
		}
	}

	// Token: 0x17000A7B RID: 2683
	// (get) Token: 0x06002D3A RID: 11578 RVA: 0x0012EC50 File Offset: 0x0012CE50
	public Class424 Class424_2
	{
		get
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				if ((ulong)this.UInt32_29 == (ulong)((long)Class350.int_0))
				{
					return Class350.class424_16;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class360.int_0))
				{
					return Class360.class424_7;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class352.int_0))
				{
					return Class352.class424_14;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class353.int_0))
				{
					return Class353.class424_4;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class359.int_0))
				{
					return Class359.class424_1;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class355.int_0))
				{
					return Class355.class424_4;
				}
				return Class352.class424_14;
			}
			else
			{
				if ((ulong)this.UInt32_29 == (ulong)((long)Class350.int_0))
				{
					return Class350.class424_17;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class360.int_0))
				{
					return Class360.class424_23;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class352.int_0))
				{
					return Class352.class424_15;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class353.int_0))
				{
					return Class353.class424_4;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class359.int_0))
				{
					return Class359.class424_2;
				}
				if ((ulong)this.UInt32_29 == (ulong)((long)Class355.int_0))
				{
					return Class355.class424_4;
				}
				return Class352.class424_15;
			}
		}
	}

	// Token: 0x17000A7C RID: 2684
	// (get) Token: 0x06002D3B RID: 11579 RVA: 0x0012ED78 File Offset: 0x0012CF78
	public bool Boolean_42
	{
		get
		{
			return (this.class392_0.UInt32_106 == 1U && this.class405_0.method_20(this.class392_0.UInt32_150) == 1U) || this.class405_0.method_20(this.class392_0.UInt32_149) == 1U;
		}
	}

	// Token: 0x17000A7D RID: 2685
	// (get) Token: 0x06002D3C RID: 11580 RVA: 0x0012EDC8 File Offset: 0x0012CFC8
	public Class424 Class424_3
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class350.class424_28;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class350.class424_29;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class350.class424_30;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class350.class424_31;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class350.class424_32;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class350.class424_33;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class350.class424_35;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class350.class424_36;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class350.class424_37;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class350.class424_38;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class350.class424_40;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class350.class424_39;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class350.class424_34;
			}
			return null;
		}
	}

	// Token: 0x17000A7E RID: 2686
	// (get) Token: 0x06002D3D RID: 11581 RVA: 0x0012EEE8 File Offset: 0x0012D0E8
	public Class424 Class424_4
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class374.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class369.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class366.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class377.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class371.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class376.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class372.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class373.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class375.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class370.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class367.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class333.class424_3;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class332.class424_3;
			}
			return null;
		}
	}

	// Token: 0x17000A7F RID: 2687
	// (get) Token: 0x06002D3E RID: 11582 RVA: 0x0012F008 File Offset: 0x0012D208
	public int Int32_3
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class365.Int32_68;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class365.Int32_73;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class365.Int32_77;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class365.Int32_74;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class365.Int32_69;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class365.Int32_75;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class365.Int32_78;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class365.Int32_76;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class365.Int32_70;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class365.Int32_79;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class365.Int32_71;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class365.Int32_72;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class365.Int32_22;
			}
			return -1;
		}
	}

	// Token: 0x17000A80 RID: 2688
	// (get) Token: 0x06002D3F RID: 11583 RVA: 0x0012F128 File Offset: 0x0012D328
	public int Int32_4
	{
		get
		{
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_0))
			{
				return Class374.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_1))
			{
				return Class369.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_2))
			{
				return Class366.Int32_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_3))
			{
				return Class377.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_4))
			{
				return Class371.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_5))
			{
				return Class376.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_6))
			{
				return Class372.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_7))
			{
				return Class373.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_8))
			{
				return Class375.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_9))
			{
				return Class370.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_10))
			{
				return Class367.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_11))
			{
				return Class333.int_0;
			}
			if ((ulong)this.UInt32_1 == (ulong)((long)Class381.int_12))
			{
				return Class332.int_0;
			}
			return -1;
		}
	}

	// Token: 0x06002D40 RID: 11584 RVA: 0x0012F248 File Offset: 0x0012D448
	public static bool smethod_6(int int_3)
	{
		if (int_3 == 0)
		{
			return false;
		}
		if (int_3 == 30008034)
		{
			return true;
		}
		if (int_3 == 30000000)
		{
			return true;
		}
		if (int_3 >= 20109001 && int_3 <= 20109015)
		{
			return true;
		}
		if (int_3 == 20109101)
		{
			return true;
		}
		if (int_3 == 20109102)
		{
			return true;
		}
		if (int_3 == 30008053)
		{
			return true;
		}
		if (int_3 == 30103042)
		{
			return true;
		}
		if (int_3 == 10141153)
		{
			return true;
		}
		if (int_3 != 10157001)
		{
			if (int_3 != 10157002)
			{
				if (int_3 != 10156001 && int_3 != 10156002 && int_3 != 10156003)
				{
					if (int_3 != 10156004)
					{
						return !int_3.ToString().StartsWith("101") && !int_3.ToString().StartsWith("102") && !int_3.ToString().StartsWith("103") && !int_3.ToString().StartsWith("104") && !int_3.ToString().StartsWith("201") && !int_3.ToString().StartsWith("300") && !int_3.ToString().StartsWith("301");
					}
				}
				return true;
			}
		}
		return true;
	}

	// Token: 0x06002D41 RID: 11585 RVA: 0x0012F390 File Offset: 0x0012D590
	public Class432(Class159 class159_1)
	{
		this.Class159_0 = class159_1;
		this.class392_0 = class159_1.Class392_0;
		this.class405_0 = class159_1.Class405_0;
		this.method_6();
	}

	// Token: 0x17000A81 RID: 2689
	// (get) Token: 0x06002D42 RID: 11586 RVA: 0x0012F3F8 File Offset: 0x0012D5F8
	public Dictionary<uint, string> Dictionary_0
	{
		get
		{
			Dictionary<uint, string> dictionary = new Dictionary<uint, string>();
			this.UInt32_10 = this.class405_0.method_20(this.class392_0.UInt32_58);
			for (uint num = 0U; num < 10U; num += 1U)
			{
				uint num2 = this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_25);
				string value;
				if (this.class392_0.UInt32_106 != 1U)
				{
					value = this.class405_0.method_32(this.UInt32_10 + this.class392_0.UInt32_24 * num + 28U, false);
				}
				else
				{
					value = this.class405_0.method_32(this.UInt32_10 + this.class392_0.UInt32_24 * num + 32U, false);
				}
				if (num2 != 0U)
				{
					dictionary.Add(num2, value);
				}
			}
			return dictionary;
		}
	}

	// Token: 0x06002D43 RID: 11587 RVA: 0x0012F4D0 File Offset: 0x0012D6D0
	public uint[] method_5()
	{
		uint num = 0U;
		uint num2 = 0U;
		uint num3 = 0U;
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_0.Concat(this.Class159_0.Class196_0.IEnumerable_4))
		{
			if (@class.String_3.Contains("tienhoachungtu"))
			{
				num += @class.UInt32_5;
			}
			if (@class.String_3.Contains("hoaphi"))
			{
				num2 += @class.UInt32_5;
			}
			if (@class.String_3.Contains("chucphucmaobut"))
			{
				num3 += @class.UInt32_5;
			}
		}
		return new uint[]
		{
			num,
			num2,
			num3
		};
	}

	// Token: 0x17000A82 RID: 2690
	// (get) Token: 0x06002D44 RID: 11588 RVA: 0x0012F5A8 File Offset: 0x0012D7A8
	public int[] Int32_5
	{
		get
		{
			int num = 0;
			int num2 = 0;
			foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3.Contains("hoahongbatu"))
				{
					num += (int)@class.UInt32_5;
				}
				if (@class.String_3.Contains("kimtamti"))
				{
					num2 += (int)@class.UInt32_5;
				}
			}
			return new int[]
			{
				num,
				num2
			};
		}
	}

	// Token: 0x17000A83 RID: 2691
	// (get) Token: 0x06002D45 RID: 11589 RVA: 0x000210D9 File Offset: 0x0001F2D9
	public IEnumerable<Class237> IEnumerable_0
	{
		get
		{
			Class432.Class436 @class = new Class432.Class436(-2);
			@class.class432_0 = this;
			return @class;
		}
	}

	// Token: 0x17000A84 RID: 2692
	// (get) Token: 0x06002D46 RID: 11590 RVA: 0x0012F644 File Offset: 0x0012D844
	public Class237 Class237_0
	{
		get
		{
			uint num = this.class405_0.method_20(this.class392_0.UInt32_58);
			uint num2 = 0U;
			Class237 result = null;
			uint num3 = 0U;
			for (uint num4 = 0U; num4 < 10U; num4 += 1U)
			{
				uint num5 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_25);
				if (num5 > 0U && this.Dictionary_0.ContainsKey(num5))
				{
					string value = string.Empty;
					if (this.class392_0.UInt32_106 == 1U)
					{
						value = this.class405_0.method_32(num + this.class392_0.UInt32_24 * num4 + 32U, false).Trim();
					}
					else
					{
						value = this.class405_0.method_32(num + this.class392_0.UInt32_24 * num4 + 28U, false).Trim();
					}
					if (!string.IsNullOrEmpty(value))
					{
						uint uint32_ = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_28);
						uint uint32_2 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_148);
						Class237 @class = new Class237();
						@class.UInt32_10 = num2;
						num2 += 1U;
						@class.UInt32_2 = num + this.class392_0.UInt32_24 * num4;
						@class.String_0 = num5.ToString("X8");
						@class.UInt32_3 = uint32_;
						@class.UInt32_4 = uint32_2;
						@class.UInt32_5 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 192U);
						@class.UInt32_6 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 204U);
						@class.UInt32_7 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 196U);
						@class.UInt32_9 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 208U);
						@class.UInt32_8 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 200U);
						@class.UInt32_0 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 104U);
						@class.UInt32_1 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 108U);
						@class.String_1 = value;
						if (!(Class426.smethod_57(@class.String_1) == "thiemdiendieu") && !Class426.smethod_57(@class.String_1).Contains("nier") && @class.UInt32_3 >= 60U)
						{
							if (@class.UInt32_0 > num3)
							{
								num3 = @class.UInt32_0;
								result = @class;
							}
							if (@class.UInt32_1 > num3)
							{
								num3 = @class.UInt32_1;
								result = @class;
							}
						}
					}
				}
			}
			return result;
		}
	}

	// Token: 0x17000A85 RID: 2693
	// (get) Token: 0x06002D47 RID: 11591 RVA: 0x0012F95C File Offset: 0x0012DB5C
	public Class237 Class237_1
	{
		get
		{
			uint num = this.class405_0.method_20(this.class392_0.UInt32_58);
			uint num2 = 0U;
			Class237 result = null;
			uint num3 = 0U;
			for (uint num4 = 0U; num4 < 10U; num4 += 1U)
			{
				uint num5 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_25);
				if (num5 != 0U && num5 != 4294967295U)
				{
					string text = string.Empty;
					if (this.class392_0.UInt32_106 == 1U)
					{
						text = this.class405_0.method_32(num + this.class392_0.UInt32_24 * num4 + 32U, false).Trim();
					}
					else
					{
						text = this.class405_0.method_32(num + this.class392_0.UInt32_24 * num4 + 28U, false).Trim();
					}
					uint uint32_ = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_28);
					uint uint32_2 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + this.class392_0.UInt32_148);
					Class237 @class = new Class237();
					@class.UInt32_10 = num2;
					num2 += 1U;
					@class.UInt32_2 = num + this.class392_0.UInt32_24 * num4;
					@class.String_0 = num5.ToString("X8");
					@class.UInt32_3 = uint32_;
					@class.UInt32_4 = uint32_2;
					@class.UInt32_5 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 192U);
					@class.UInt32_6 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 204U);
					@class.UInt32_7 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 196U);
					@class.UInt32_9 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 208U);
					@class.UInt32_8 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 200U);
					@class.UInt32_0 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 104U);
					@class.UInt32_1 = this.class405_0.method_11(num + this.class392_0.UInt32_24 * num4 + 108U);
					@class.String_1 = text;
					if (!(Class426.smethod_57(@class.String_1) == "thiemdiendieu") && !Class426.smethod_57(@class.String_1).Contains("nier"))
					{
						if (@class.UInt32_0 > num3)
						{
							num3 = @class.UInt32_0;
							result = @class;
						}
						if (@class.UInt32_1 > num3)
						{
							num3 = @class.UInt32_1;
							result = @class;
						}
					}
				}
			}
			return result;
		}
	}

	// Token: 0x17000A86 RID: 2694
	// (get) Token: 0x06002D48 RID: 11592 RVA: 0x000210E9 File Offset: 0x0001F2E9
	// (set) Token: 0x06002D49 RID: 11593 RVA: 0x000210F1 File Offset: 0x0001F2F1
	public uint UInt32_44 { get; set; }

	// Token: 0x17000A87 RID: 2695
	// (get) Token: 0x06002D4A RID: 11594 RVA: 0x000210FA File Offset: 0x0001F2FA
	public bool Boolean_43
	{
		get
		{
			Class405 @class = this.class405_0;
			uint[] array = new uint[]
			{
				0U,
				8U,
				4U,
				324U
			};
			array[0] = this.Class159_0.UInt32_3 + 8759088U;
			return @class.method_20(array) == 1U;
		}
	}

	// Token: 0x17000A88 RID: 2696
	// (get) Token: 0x06002D4B RID: 11595 RVA: 0x0002112F File Offset: 0x0001F32F
	public bool Boolean_44
	{
		get
		{
			Class405 @class = this.class405_0;
			uint[] array = new uint[]
			{
				0U,
				8U,
				4U,
				324U
			};
			array[0] = this.Class159_0.UInt32_3 + 8785632U;
			return @class.method_20(array) == 1U;
		}
	}

	// Token: 0x17000A89 RID: 2697
	// (get) Token: 0x06002D4C RID: 11596 RVA: 0x00021164 File Offset: 0x0001F364
	public bool Boolean_45
	{
		get
		{
			Class405 @class = this.class405_0;
			uint[] array = new uint[]
			{
				0U,
				8U,
				4U,
				324U
			};
			array[0] = this.Class159_0.UInt32_3 + 8754600U;
			return @class.method_20(array) == 1U;
		}
	}

	// Token: 0x17000A8A RID: 2698
	// (get) Token: 0x06002D4D RID: 11597 RVA: 0x00021199 File Offset: 0x0001F399
	public bool Boolean_46
	{
		get
		{
			Class405 @class = this.class405_0;
			uint[] array = new uint[]
			{
				0U,
				8U,
				4U,
				324U
			};
			array[0] = this.Class159_0.UInt32_3 + 8782344U;
			return @class.method_20(array) == 1U;
		}
	}

	// Token: 0x06002D4E RID: 11598 RVA: 0x0012FC50 File Offset: 0x0012DE50
	public void method_6()
	{
		this.UInt32_44 = this.class405_0.method_11(this.Class159_0.UInt32_3 + 11235844U);
		this.Boolean_5 = this.Boolean_8;
		this.Boolean_6 = this.Boolean_7;
		this.UInt32_0 = this.class405_0.method_20(this.class392_0.UInt32_2);
		this.UInt32_1 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_6);
		this.UInt32_2 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_7);
		if (this.class392_0.UInt32_106 == 1U)
		{
			this.String_1 = this.class405_0.method_15(this.UInt32_0 + this.class392_0.UInt32_3).ToString("X8");
		}
		else
		{
			this.String_1 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_3).ToString("X8");
		}
		this.UInt32_28 = this.class405_0.method_20(this.class392_0.UInt32_59);
		this.UInt32_29 = this.class405_0.method_20(this.class392_0.UInt32_66);
		if (this.UInt32_29 == 242U)
		{
			this.UInt32_29 = 0U;
		}
		this.string_7 = this.class405_0.method_34(this.class392_0.UInt32_68);
		this.UInt32_3 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_8);
		this.UInt32_4 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_11);
		this.UInt32_5 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_12);
		this.UInt32_8 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_15);
		this.UInt32_6 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_13);
		this.UInt32_7 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_14);
		this.UInt32_9 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_16);
		this.UInt32_15 = this.class405_0.method_11(this.UInt32_0 + 18168U);
		this.String_15 = this.class405_0.method_26(this.UInt32_0 + this.class392_0.UInt32_17);
		this.UInt32_33 = this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_9);
		this.String_17 = "";
		if (this.UInt32_4 != 0U)
		{
			this.UInt32_10 = this.class405_0.method_20(this.class392_0.UInt32_58);
			uint num = 0U;
			while (num < 10U)
			{
				if (this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_25) == this.UInt32_4)
				{
					this.UInt32_11 = this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_26);
					this.UInt32_12 = this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_27);
					this.UInt32_13 = this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_28);
					this.UInt32_14 = this.class405_0.method_11(this.UInt32_10 + this.class392_0.UInt32_24 * num + this.class392_0.UInt32_148);
					if (this.class392_0.UInt32_106 == 1U)
					{
						this.String_17 = this.class405_0.method_32(this.UInt32_10 + this.class392_0.UInt32_24 * num + 32U, false).Trim();
						break;
					}
					this.String_17 = this.class405_0.method_32(this.UInt32_10 + this.class392_0.UInt32_24 * num + 28U, false).Trim();
					break;
				}
				else
				{
					num += 1U;
				}
			}
		}
		else
		{
			this.UInt32_13 = 0U;
			this.UInt32_12 = 0U;
			this.UInt32_11 = 0U;
		}
		bool boolean_ = this.Boolean_14;
		if (this.Boolean_14 && string.IsNullOrEmpty(this.String_7))
		{
			if (this.Class159_0.Stopwatch_15 == null)
			{
				this.Class159_0.Stopwatch_15 = Stopwatch.StartNew();
			}
			if (this.Class159_0.Stopwatch_15.Elapsed.TotalSeconds >= 6.0 && !this.Boolean_47)
			{
				this.Boolean_47 = true;
				new Thread(new ThreadStart(this.method_10)).Start();
			}
		}
		if (!this.Boolean_14)
		{
			this.Boolean_47 = false;
			this.String_7 = null;
		}
		this.bool_2 = (this.class405_0.method_20(this.class392_0.UInt32_61) == 1U);
		if (this.class392_0.UInt32_106 == 1U)
		{
			this.String_10 = this.class405_0.method_16(this.class392_0.UInt32_63).ToString("X8");
		}
		else
		{
			this.String_10 = this.class405_0.method_20(this.class392_0.UInt32_63).ToString("X8");
		}
		if (this.Class159_0.List_23.Contains(this.Class159_0) && this.Class159_0.List_23.Count > 0)
		{
			this.String_10 = this.Class159_0.List_23[0].Class432_0.String_1;
		}
		if (this.Class159_0.List_24.Contains(this.Class159_0) && this.Class159_0.List_24.Count > 0)
		{
			this.String_10 = this.Class159_0.List_24[0].Class432_0.String_1;
		}
		if (this.class392_0.UInt32_106 == 1U)
		{
			this.class392_0.UInt32_53[1] = Class432.UInt32_45;
		}
		this.UInt32_30 = this.class405_0.method_17(this.class392_0.UInt32_53[0], Class432.UInt32_45);
		this.UInt32_31 = this.class405_0.method_17(this.class392_0.UInt32_53[0], Class432.UInt32_45 + 4U);
		if (this.UInt32_31 - this.UInt32_30 == 4U)
		{
			this.Int32_1 = 1;
			this.String_13 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53), 32U);
			this.String_14 = "";
		}
		else if (this.UInt32_31 - this.UInt32_30 == 8U)
		{
			this.Int32_1 = 2;
			this.String_14 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53) + 4U, 32U);
			this.String_13 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53), 32U);
		}
		else
		{
			this.Int32_1 = 0;
			this.String_13 = "";
			this.String_14 = "";
		}
		this.String_12 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53), 32U) + this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53) + 4U, 32U);
		if (this.class392_0.UInt32_106 != 1U)
		{
			this.String_13 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53), 40U);
			this.String_14 = this.class405_0.method_33(this.class405_0.method_20(this.class392_0.UInt32_53) + 4U, 40U);
		}
		this.String_12 = this.String_13 + this.String_14;
		this.uint_22 = this.class405_0.method_20(this.class392_0.UInt32_46) / 60000U;
		this.UInt32_32 = this.class405_0.method_20(this.class392_0.UInt32_46) / 1000U;
		this.uint_24 = this.class405_0.method_20(this.class392_0.uint_42);
		this.Boolean_35 = false;
		if (this.Class159_0.Class394_0.class393_0 != null && (this.Class159_0.Class394_0.class393_0.List_0.Contains(1665U) || this.Class159_0.Class394_0.class393_0.List_0.Contains(2746U) || this.Class159_0.Class394_0.class393_0.List_0.Contains(2209U)))
		{
			this.Boolean_35 = true;
		}
		if (!this.Boolean_35)
		{
			if (this.class392_0.UInt32_106 == 1U)
			{
				this.Boolean_35 = (this.class405_0.method_11(this.UInt32_0 + 160U) != uint.MaxValue);
			}
			else
			{
				this.Boolean_35 = (this.class405_0.method_17(this.class392_0.UInt32_108, this.class392_0.UInt32_109) == 1U);
			}
		}
		this.Boolean_30 = (this.class405_0.method_11(this.UInt32_0 + this.class392_0.UInt32_85) != uint.MaxValue);
	}

	// Token: 0x17000A8B RID: 2699
	// (get) Token: 0x06002D4F RID: 11599 RVA: 0x000211CE File Offset: 0x0001F3CE
	// (set) Token: 0x06002D50 RID: 11600 RVA: 0x000211D5 File Offset: 0x0001F3D5
	public static uint UInt32_45 { get; set; } = 68U;

	// Token: 0x17000A8C RID: 2700
	// (get) Token: 0x06002D51 RID: 11601 RVA: 0x000211DD File Offset: 0x0001F3DD
	// (set) Token: 0x06002D52 RID: 11602 RVA: 0x000211E5 File Offset: 0x0001F3E5
	public bool Boolean_47 { get; set; }

	// Token: 0x17000A8D RID: 2701
	// (get) Token: 0x06002D53 RID: 11603 RVA: 0x000211EE File Offset: 0x0001F3EE
	// (set) Token: 0x06002D54 RID: 11604 RVA: 0x000211F6 File Offset: 0x0001F3F6
	public string String_17 { get; set; }

	// Token: 0x17000A8E RID: 2702
	// (get) Token: 0x06002D55 RID: 11605 RVA: 0x0013061C File Offset: 0x0012E81C
	public bool Boolean_48
	{
		get
		{
			foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_0)
			{
				if (Class363.dictionary_7.ContainsKey(@class.String_2))
				{
					return true;
				}
			}
			return false;
		}
	}

	// Token: 0x17000A8F RID: 2703
	// (get) Token: 0x06002D56 RID: 11606 RVA: 0x000211FF File Offset: 0x0001F3FF
	// (set) Token: 0x06002D57 RID: 11607 RVA: 0x00021207 File Offset: 0x0001F407
	public bool Boolean_49 { get; set; }

	// Token: 0x06002D58 RID: 11608 RVA: 0x00130688 File Offset: 0x0012E888
	public void method_7(string string_14)
	{
		int num = Class426.smethod_43(string_14);
		int num2 = Class426.smethod_43(string_14.Replace(num.ToString() + ",", ""));
		this.method_8((float)num, (float)num2);
	}

	// Token: 0x06002D59 RID: 11609 RVA: 0x001306C8 File Offset: 0x0012E8C8
	public void method_8(float float_0, float float_1)
	{
		if (this.Boolean_30)
		{
			this.Class159_0.method_272();
		}
		foreach (Class417 @class in this.Class159_0.List_1)
		{
			if (!string.IsNullOrEmpty(@class.String_1) && @class.String_1.Contains("Shoes2"))
			{
				this.Class159_0.method_57(Class265.smethod_13(float_0), 59);
				this.Class159_0.method_57(Class265.smethod_13(float_1), 60);
				this.Class159_0.method_58(@class.UInt32_4, 61);
				this.Class159_0.method_57(0, 126);
				break;
			}
		}
	}

	// Token: 0x06002D5A RID: 11610 RVA: 0x00021210 File Offset: 0x0001F410
	public void method_9(float float_0, float float_1)
	{
		this.Class159_0.method_57(Class405.smethod_11(float_0), 50);
		this.Class159_0.method_57(Class405.smethod_11(float_1), 51);
		this.Class159_0.method_57(0, 119);
	}

	// Token: 0x17000A90 RID: 2704
	// (get) Token: 0x06002D5B RID: 11611 RVA: 0x00130798 File Offset: 0x0012E998
	public bool Boolean_50
	{
		get
		{
			foreach (Class393 @class in this.Class159_0.Class394_0.list_1)
			{
				if ((@class.String_2 == "Tiêu Như Úy" || @class.String_2 == "Tiêu Như Quân") && (long)this.Class159_0.Int32_10 == (long)((ulong)@class.UInt32_1))
				{
					return true;
				}
			}
			return false;
		}
	}

	// Token: 0x17000A91 RID: 2705
	// (get) Token: 0x06002D5C RID: 11612 RVA: 0x00021246 File Offset: 0x0001F446
	public bool Boolean_51
	{
		get
		{
			return this.class405_0.method_20(this.class392_0.UInt32_141) == 1U;
		}
	}

	// Token: 0x17000A92 RID: 2706
	// (get) Token: 0x06002D5D RID: 11613 RVA: 0x00021261 File Offset: 0x0001F461
	public uint UInt32_46
	{
		get
		{
			return this.class405_0.method_19(this.class392_0.UInt32_158, 196U);
		}
	}

	// Token: 0x17000A93 RID: 2707
	// (get) Token: 0x06002D5E RID: 11614 RVA: 0x00130834 File Offset: 0x0012EA34
	public bool Boolean_52
	{
		get
		{
			return (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_1) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_2) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_3) || (ulong)this.UInt32_29 == (ulong)((long)Class365.Int32_86) || (ulong)this.UInt32_29 == (ulong)((long)Class355.int_0);
		}
	}

	// Token: 0x06002D60 RID: 11616 RVA: 0x00021287 File Offset: 0x0001F487
	[CompilerGenerated]
	private void method_10()
	{
		Thread.CurrentThread.IsBackground = true;
		this.method_2();
	}

	// Token: 0x04001E78 RID: 7800
	[CompilerGenerated]
	private Class159 class159_0;

	// Token: 0x04001E79 RID: 7801
	public Class405 class405_0;

	// Token: 0x04001E7A RID: 7802
	public Class392 class392_0;

	// Token: 0x04001E7B RID: 7803
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001E7C RID: 7804
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001E7D RID: 7805
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001E7E RID: 7806
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001E7F RID: 7807
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001E80 RID: 7808
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04001E81 RID: 7809
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04001E82 RID: 7810
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04001E83 RID: 7811
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04001E84 RID: 7812
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04001E85 RID: 7813
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x04001E86 RID: 7814
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x04001E87 RID: 7815
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x04001E88 RID: 7816
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x04001E89 RID: 7817
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x04001E8A RID: 7818
	[CompilerGenerated]
	private uint uint_14;

	// Token: 0x04001E8B RID: 7819
	[CompilerGenerated]
	private uint uint_15;

	// Token: 0x04001E8C RID: 7820
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04001E8D RID: 7821
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04001E8E RID: 7822
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001E8F RID: 7823
	[CompilerGenerated]
	private uint uint_16;

	// Token: 0x04001E90 RID: 7824
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04001E91 RID: 7825
	public string[] string_2;

	// Token: 0x04001E92 RID: 7826
	private Bitmap bitmap_0;

	// Token: 0x04001E93 RID: 7827
	[CompilerGenerated]
	private string string_3;

	// Token: 0x04001E94 RID: 7828
	[CompilerGenerated]
	private string string_4;

	// Token: 0x04001E95 RID: 7829
	[CompilerGenerated]
	private string string_5;

	// Token: 0x04001E96 RID: 7830
	private int[] int_1 = new int[4];

	// Token: 0x04001E97 RID: 7831
	private List<uint> list_0 = new List<uint>();

	// Token: 0x04001E98 RID: 7832
	[CompilerGenerated]
	private uint uint_17;

	// Token: 0x04001E99 RID: 7833
	[CompilerGenerated]
	private uint uint_18;

	// Token: 0x04001E9A RID: 7834
	public bool bool_2;

	// Token: 0x04001E9B RID: 7835
	[CompilerGenerated]
	private string string_6;

	// Token: 0x04001E9C RID: 7836
	[CompilerGenerated]
	private uint uint_19;

	// Token: 0x04001E9D RID: 7837
	public string string_7;

	// Token: 0x04001E9E RID: 7838
	[CompilerGenerated]
	private string string_8;

	// Token: 0x04001E9F RID: 7839
	[CompilerGenerated]
	private string string_9;

	// Token: 0x04001EA0 RID: 7840
	[CompilerGenerated]
	private string string_10;

	// Token: 0x04001EA1 RID: 7841
	[CompilerGenerated]
	private uint uint_20;

	// Token: 0x04001EA2 RID: 7842
	[CompilerGenerated]
	private uint uint_21;

	// Token: 0x04001EA3 RID: 7843
	[CompilerGenerated]
	private int int_2;

	// Token: 0x04001EA4 RID: 7844
	public uint uint_22;

	// Token: 0x04001EA5 RID: 7845
	[CompilerGenerated]
	private uint uint_23;

	// Token: 0x04001EA6 RID: 7846
	public uint uint_24;

	// Token: 0x04001EA7 RID: 7847
	[CompilerGenerated]
	private string string_11;

	// Token: 0x04001EA8 RID: 7848
	[CompilerGenerated]
	private uint uint_25;

	// Token: 0x04001EA9 RID: 7849
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x04001EAA RID: 7850
	[CompilerGenerated]
	private bool bool_4;

	// Token: 0x04001EAB RID: 7851
	[CompilerGenerated]
	private bool bool_5;

	// Token: 0x04001EAC RID: 7852
	[CompilerGenerated]
	private uint uint_26;

	// Token: 0x04001EAD RID: 7853
	[CompilerGenerated]
	private static uint uint_27;

	// Token: 0x04001EAE RID: 7854
	[CompilerGenerated]
	private bool bool_6;

	// Token: 0x04001EAF RID: 7855
	[CompilerGenerated]
	private string string_12;

	// Token: 0x04001EB0 RID: 7856
	public bool bool_7;

	// Token: 0x04001EB1 RID: 7857
	[CompilerGenerated]
	private bool bool_8;

	// Token: 0x04001EB2 RID: 7858
	public string string_13 = "";

	// Token: 0x0200030E RID: 782
	private class Class434
	{
		// Token: 0x04001EB3 RID: 7859
		public int int_0;

		// Token: 0x04001EB4 RID: 7860
		public string string_0;
	}

	// Token: 0x0200030F RID: 783
	[CompilerGenerated]
	[Serializable]
	private sealed class Class435
	{
		// Token: 0x06002D64 RID: 11620 RVA: 0x000212A6 File Offset: 0x0001F4A6
		internal int method_0(Class432.Class434 class434_0)
		{
			return class434_0.int_0;
		}

		// Token: 0x04001EB5 RID: 7861
		public static readonly Class432.Class435 <>9 = new Class432.Class435();

		// Token: 0x04001EB6 RID: 7862
		public static Func<Class432.Class434, int> <>9__165_0;
	}
}
