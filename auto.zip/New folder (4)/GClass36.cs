﻿using System;
using System.Collections.Specialized;
using System.Security.Principal;

// Token: 0x0200008D RID: 141
public class GClass36 : GenericIdentity
{
	// Token: 0x06000683 RID: 1667 RVA: 0x000072DD File Offset: 0x000054DD
	internal GClass36(NameValueCollection nameValueCollection_1) : base(nameValueCollection_1["username"], "Digest")
	{
		this.nameValueCollection_0 = nameValueCollection_1;
	}

	// Token: 0x170001AA RID: 426
	// (get) Token: 0x06000684 RID: 1668 RVA: 0x000072FC File Offset: 0x000054FC
	public string String_0
	{
		get
		{
			return this.nameValueCollection_0["algorithm"];
		}
	}

	// Token: 0x170001AB RID: 427
	// (get) Token: 0x06000685 RID: 1669 RVA: 0x0000730E File Offset: 0x0000550E
	public string String_1
	{
		get
		{
			return this.nameValueCollection_0["cnonce"];
		}
	}

	// Token: 0x170001AC RID: 428
	// (get) Token: 0x06000686 RID: 1670 RVA: 0x00007320 File Offset: 0x00005520
	public string String_2
	{
		get
		{
			return this.nameValueCollection_0["nc"];
		}
	}

	// Token: 0x170001AD RID: 429
	// (get) Token: 0x06000687 RID: 1671 RVA: 0x00007332 File Offset: 0x00005532
	public string String_3
	{
		get
		{
			return this.nameValueCollection_0["nonce"];
		}
	}

	// Token: 0x170001AE RID: 430
	// (get) Token: 0x06000688 RID: 1672 RVA: 0x00007344 File Offset: 0x00005544
	public string String_4
	{
		get
		{
			return this.nameValueCollection_0["opaque"];
		}
	}

	// Token: 0x170001AF RID: 431
	// (get) Token: 0x06000689 RID: 1673 RVA: 0x00007356 File Offset: 0x00005556
	public string String_5
	{
		get
		{
			return this.nameValueCollection_0["qop"];
		}
	}

	// Token: 0x170001B0 RID: 432
	// (get) Token: 0x0600068A RID: 1674 RVA: 0x00007368 File Offset: 0x00005568
	public string String_6
	{
		get
		{
			return this.nameValueCollection_0["realm"];
		}
	}

	// Token: 0x170001B1 RID: 433
	// (get) Token: 0x0600068B RID: 1675 RVA: 0x0000737A File Offset: 0x0000557A
	public string String_7
	{
		get
		{
			return this.nameValueCollection_0["response"];
		}
	}

	// Token: 0x170001B2 RID: 434
	// (get) Token: 0x0600068C RID: 1676 RVA: 0x0000738C File Offset: 0x0000558C
	public string String_8
	{
		get
		{
			return this.nameValueCollection_0["uri"];
		}
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00036B64 File Offset: 0x00034D64
	internal bool method_0(string string_0, string string_1, string string_2, string string_3)
	{
		NameValueCollection nameValueCollection = new NameValueCollection(this.nameValueCollection_0);
		nameValueCollection["password"] = string_0;
		nameValueCollection["realm"] = string_1;
		nameValueCollection["method"] = string_2;
		nameValueCollection["entity"] = string_3;
		string b = Class64.smethod_7(nameValueCollection);
		return this.nameValueCollection_0["response"] == b;
	}

	// Token: 0x0400032A RID: 810
	private NameValueCollection nameValueCollection_0;
}
