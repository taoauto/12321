﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000232 RID: 562
internal class DropItem : UserControl
{
	// Token: 0x06001E83 RID: 7811 RVA: 0x000169E7 File Offset: 0x00014BE7
	public DropItem()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001E84 RID: 7812 RVA: 0x000E2F98 File Offset: 0x000E1198
	private void DropItem_Load(object sender, EventArgs e)
	{
		if (base.Tag != null)
		{
			if (base.Tag.ToString() == "DropItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Hủy Đồ";
			}
			if (base.Tag.ToString() == "UseItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Dùng Đồ";
			}
			if (base.Tag.ToString() == "SellItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Bán Đồ";
			}
			if (base.Tag.ToString() == "BankItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Thương Khố";
			}
			if (base.Tag.ToString() == "ThienCoItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Thiên Cơ";
			}
			if (base.Tag.ToString() == "GomItem")
			{
				this.gameItemForm1.lvName.Columns[0].Text = "Gom Đồ";
			}
		}
	}

	// Token: 0x06001E85 RID: 7813 RVA: 0x000169F5 File Offset: 0x00014BF5
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001E86 RID: 7814 RVA: 0x000E30FC File Offset: 0x000E12FC
	private void InitializeComponent()
	{
		this.btnSave = new Button();
		this.splitContainer1 = new SplitContainer();
		this.textEdit1 = new TextEdit();
		this.comboPlayer1 = new ComboPlayer();
		this.gameItemForm1 = new GameItemForm();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.btnSave.Dock = DockStyle.Bottom;
		this.btnSave.Location = new Point(0, 383);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new Size(442, 23);
		this.btnSave.TabIndex = 7;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.textEdit1);
		this.splitContainer1.Panel1.Controls.Add(this.comboPlayer1);
		this.splitContainer1.Panel2.Controls.Add(this.gameItemForm1);
		this.splitContainer1.Size = new Size(442, 383);
		this.splitContainer1.SplitterDistance = 217;
		this.splitContainer1.TabIndex = 0;
		this.textEdit1.Dock = DockStyle.Fill;
		this.textEdit1.Location = new Point(0, 0);
		this.textEdit1.Name = "textEdit1";
		this.textEdit1.Size = new Size(217, 362);
		this.textEdit1.TabIndex = 1;
		this.comboPlayer1.Dock = DockStyle.Bottom;
		this.comboPlayer1.Location = new Point(0, 362);
		this.comboPlayer1.Name = "comboPlayer1";
		this.comboPlayer1.Size = new Size(217, 21);
		this.comboPlayer1.TabIndex = 0;
		this.gameItemForm1.Dock = DockStyle.Fill;
		this.gameItemForm1.Location = new Point(0, 0);
		this.gameItemForm1.Name = "gameItemForm1";
		this.gameItemForm1.Size = new Size(221, 383);
		this.gameItemForm1.TabIndex = 0;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.btnSave);
		base.Name = "DropItem";
		base.Size = new Size(442, 406);
		base.Tag = "Hủy Vật Phẩm - Drop Item";
		base.Load += this.DropItem_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040012ED RID: 4845
	private IContainer icontainer_0;

	// Token: 0x040012EE RID: 4846
	private Button btnSave;

	// Token: 0x040012EF RID: 4847
	private SplitContainer splitContainer1;

	// Token: 0x040012F0 RID: 4848
	private GameItemForm gameItemForm1;

	// Token: 0x040012F1 RID: 4849
	private ComboPlayer comboPlayer1;

	// Token: 0x040012F2 RID: 4850
	private TextEdit textEdit1;
}
