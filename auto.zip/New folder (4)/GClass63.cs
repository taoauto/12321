﻿using System;

// Token: 0x020000CC RID: 204
public class GClass63 : GClass61
{
	// Token: 0x060009B7 RID: 2487 RVA: 0x00009597 File Offset: 0x00007797
	public GClass63(GClass99 gclass99_1, string string_1) : base(gclass99_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x060009B8 RID: 2488 RVA: 0x0003F368 File Offset: 0x0003D568
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = this.class90_0.GStruct2_0;
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1 = this.class90_1.GStruct2_0;
		this.gclass99_0.vmethod_13();
		GClass65.smethod_0(this.gclass99_0);
		base.GClass61.\u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E();
	}

	// Token: 0x060009B9 RID: 2489 RVA: 0x000095A7 File Offset: 0x000077A7
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		this.gclass99_0.vmethod_14(ref this.string_0);
		GClass63.smethod_0(this.string_0, this.gclass99_0);
		base.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
	}

	// Token: 0x060009BA RID: 2490 RVA: 0x0003F3D4 File Offset: 0x0003D5D4
	internal static void smethod_0(string string_1, GClass99 gclass99_1)
	{
		FastColoredTextBox fastColoredTextBox_ = gclass99_1.FastColoredTextBox_0;
		try
		{
			fastColoredTextBox_.GClass86_5.method_38();
			char c = '\0';
			if (gclass99_1.Count == 0)
			{
				GClass62.smethod_1(gclass99_1);
				fastColoredTextBox_.GClass86_5.GStruct2_0 = GStruct2.GStruct2_0;
			}
			fastColoredTextBox_.method_101(fastColoredTextBox_.GClass86_5.GStruct2_0.int_1);
			int length = string_1.Length;
			for (int i = 0; i < length; i++)
			{
				char c2 = string_1[i];
				if (c2 == '\r' && (i >= length - 1 || string_1[i + 1] != '\n'))
				{
					GClass62.smethod_0('\n', ref c, gclass99_1);
				}
				else
				{
					GClass62.smethod_0(c2, ref c, gclass99_1);
				}
			}
			gclass99_1.vmethod_11(new GClass99.GEventArgs20(0, 1));
		}
		finally
		{
			fastColoredTextBox_.GClass86_5.method_39();
		}
	}

	// Token: 0x060009BB RID: 2491 RVA: 0x000095D1 File Offset: 0x000077D1
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		return new GClass63(this.gclass99_0, this.string_0);
	}

	// Token: 0x040004CA RID: 1226
	public string string_0;
}
