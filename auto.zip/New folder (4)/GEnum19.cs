﻿using System;

// Token: 0x02000112 RID: 274
public enum GEnum19
{
	// Token: 0x040006D4 RID: 1748
	X86,
	// Token: 0x040006D5 RID: 1749
	X64,
	// Token: 0x040006D6 RID: 1750
	Unknown
}
