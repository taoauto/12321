﻿using System;
using System.Collections.Specialized;
using System.IO;

// Token: 0x0200006E RID: 110
public abstract class GClass27 : GInterface0
{
	// Token: 0x060004B1 RID: 1201 RVA: 0x00005EF4 File Offset: 0x000040F4
	protected GClass27()
	{
		this.dateTime_0 = DateTime.MaxValue;
	}

	// Token: 0x17000133 RID: 307
	// (get) Token: 0x060004B2 RID: 1202 RVA: 0x00005F07 File Offset: 0x00004107
	protected NameValueCollection NameValueCollection_0
	{
		get
		{
			if (this.gclass46_0 == null)
			{
				return null;
			}
			return this.gclass46_0.GClass46.\u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E;
		}
	}

	// Token: 0x17000134 RID: 308
	// (get) Token: 0x060004B3 RID: 1203 RVA: 0x00005F1E File Offset: 0x0000411E
	[Obsolete("This property will be removed.")]
	protected GClass24 GClass24_0
	{
		get
		{
			if (this.gclass25_0 == null)
			{
				return null;
			}
			return this.gclass25_0.GClass24_0;
		}
	}

	// Token: 0x17000135 RID: 309
	// (get) Token: 0x060004B4 RID: 1204 RVA: 0x00005F35 File Offset: 0x00004135
	protected NameValueCollection NameValueCollection_1
	{
		get
		{
			if (this.gclass46_0 == null)
			{
				return null;
			}
			return this.gclass46_0.GClass46.\u206F\u206F\u206D\u202A\u206F\u202D\u200C\u202C\u202D\u200B\u206E\u202A\u202A\u200F\u200F\u206D\u202A\u206A\u206F\u202D\u202C\u200D\u202C\u206F\u200F\u200D\u200F\u200F\u202E\u200F\u206F\u200C\u206D\u200F\u200B\u202B\u200D\u206F\u202D\u202D\u202E;
		}
	}

	// Token: 0x17000136 RID: 310
	// (get) Token: 0x060004B5 RID: 1205 RVA: 0x00005F4C File Offset: 0x0000414C
	protected GClass31 GClass31_0
	{
		get
		{
			return this.gclass31_0;
		}
	}

	// Token: 0x17000137 RID: 311
	// (get) Token: 0x060004B6 RID: 1206 RVA: 0x00005F54 File Offset: 0x00004154
	public GEnum8 GEnum8_0
	{
		get
		{
			if (this.gclass25_0 == null)
			{
				return GEnum8.Connecting;
			}
			return this.gclass25_0.GEnum8_0;
		}
	}

	// Token: 0x17000138 RID: 312
	// (get) Token: 0x060004B7 RID: 1207 RVA: 0x00005F6B File Offset: 0x0000416B
	public GClass46 GClass46_0
	{
		get
		{
			return this.gclass46_0;
		}
	}

	// Token: 0x17000139 RID: 313
	// (get) Token: 0x060004B8 RID: 1208 RVA: 0x00005F73 File Offset: 0x00004173
	// (set) Token: 0x060004B9 RID: 1209 RVA: 0x00005F7B File Offset: 0x0000417B
	public Func<GClass34, GClass34, bool> Func_0
	{
		get
		{
			return this.func_0;
		}
		set
		{
			this.func_0 = value;
		}
	}

	// Token: 0x1700013A RID: 314
	// (get) Token: 0x060004BA RID: 1210 RVA: 0x00005F84 File Offset: 0x00004184
	// (set) Token: 0x060004BB RID: 1211 RVA: 0x00005FA0 File Offset: 0x000041A0
	public bool Boolean_0
	{
		get
		{
			if (this.gclass25_0 == null)
			{
				return this.bool_0;
			}
			return this.gclass25_0.Boolean_3;
		}
		set
		{
			if (this.gclass25_0 != null)
			{
				this.gclass25_0.Boolean_3 = value;
				return;
			}
			this.bool_0 = value;
		}
	}

	// Token: 0x1700013B RID: 315
	// (get) Token: 0x060004BC RID: 1212 RVA: 0x00005FBE File Offset: 0x000041BE
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x1700013C RID: 316
	// (get) Token: 0x060004BD RID: 1213 RVA: 0x00005FC6 File Offset: 0x000041C6
	// (set) Token: 0x060004BE RID: 1214 RVA: 0x00005FCE File Offset: 0x000041CE
	public bool Boolean_1
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
		}
	}

	// Token: 0x1700013D RID: 317
	// (get) Token: 0x060004BF RID: 1215 RVA: 0x00005FD7 File Offset: 0x000041D7
	// (set) Token: 0x060004C0 RID: 1216 RVA: 0x00005FDF File Offset: 0x000041DF
	public Func<string, bool> Func_1
	{
		get
		{
			return this.func_1;
		}
		set
		{
			this.func_1 = value;
		}
	}

	// Token: 0x1700013E RID: 318
	// (get) Token: 0x060004C1 RID: 1217 RVA: 0x00005FE8 File Offset: 0x000041E8
	// (set) Token: 0x060004C2 RID: 1218 RVA: 0x00030224 File Offset: 0x0002E424
	public string String_1
	{
		get
		{
			string string_;
			if (this.gclass25_0 == null)
			{
				if ((string_ = this.string_1) == null)
				{
					return string.Empty;
				}
			}
			else
			{
				string_ = this.gclass25_0.String_2;
			}
			return string_;
		}
		set
		{
			if (this.GEnum8_0 != GEnum8.Connecting)
			{
				throw new InvalidOperationException("The session has already started.");
			}
			if (value == null || value.Length == 0)
			{
				this.string_1 = null;
				return;
			}
			if (!value.smethod_51())
			{
				throw new ArgumentException("Not a token.", "value");
			}
			this.string_1 = value;
		}
	}

	// Token: 0x1700013F RID: 319
	// (get) Token: 0x060004C3 RID: 1219 RVA: 0x0000600D File Offset: 0x0000420D
	public DateTime DateTime_0
	{
		get
		{
			return this.dateTime_0;
		}
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x00030278 File Offset: 0x0002E478
	private string method_1(GClass46 gclass46_1)
	{
		if (this.func_1 != null && !this.func_1(gclass46_1.GClass46.\u200C\u202D\u200E\u202C\u202E\u206A\u206D\u206B\u206C\u202C\u202D\u202E\u206B\u206C\u200F\u202B\u200F\u200B\u202D\u206F\u202B\u206C\u206E\u206C\u200C\u206D\u202B\u202A\u200F\u206D\u202E\u200D\u206D\u206A\u206B\u200D\u202B\u200F\u200E\u206E\u202E))
		{
			return "It includes no Origin header or an invalid one.";
		}
		if (this.func_0 != null)
		{
			GClass34 arg = gclass46_1.GClass46.\u206E\u200B\u200E\u206F\u200C\u206E\u202C\u202A\u206E\u206A\u202D\u202E\u200C\u200B\u202B\u206B\u202B\u206C\u200B\u202A\u202A\u202B\u200F\u200C\u200F\u202B\u206F\u206D\u200D\u200C\u202C\u200B\u206F\u200F\u200F\u206A\u202E\u206B\u202A\u206B\u202E;
			GClass34 gclass34_ = gclass46_1.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.GClass34_0;
			if (!this.func_0(arg, gclass34_))
			{
				return "It includes no cookie or an invalid one.";
			}
		}
		return null;
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x00006015 File Offset: 0x00004215
	private void method_2(object sender, GEventArgs2 e)
	{
		if (this.string_0 == null)
		{
			return;
		}
		this.gclass31_0.method_13(this.string_0);
		this.vmethod_0(e);
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00006039 File Offset: 0x00004239
	private void method_3(object sender, GEventArgs3 e)
	{
		this.vmethod_1(e);
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x00006042 File Offset: 0x00004242
	private void method_4(object sender, GEventArgs4 e)
	{
		this.vmethod_2(e);
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x0000604B File Offset: 0x0000424B
	private void method_5(object sender, EventArgs e)
	{
		this.string_0 = this.gclass31_0.method_9(this);
		if (this.string_0 == null)
		{
			this.gclass25_0.method_74(GEnum6.Away);
			return;
		}
		this.dateTime_0 = DateTime.Now;
		this.vmethod_3();
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x000302D8 File Offset: 0x0002E4D8
	internal void method_6(GClass46 gclass46_1, GClass31 gclass31_1)
	{
		if (this.gclass25_0 != null)
		{
			this.gclass25_0.GClass24_0.method_2("A session instance cannot be reused.");
			gclass46_1.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E.method_64(GEnum9.ServiceUnavailable);
			return;
		}
		this.gclass46_0 = gclass46_1;
		this.gclass31_0 = gclass31_1;
		this.gclass25_0 = gclass46_1.GClass46.\u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E;
		this.gclass25_0.Func_0 = new Func<GClass46, string>(this.method_1);
		this.gclass25_0.Boolean_3 = this.bool_0;
		this.gclass25_0.Boolean_1 = this.bool_1;
		this.gclass25_0.String_2 = this.string_1;
		TimeSpan timeSpan_ = gclass31_1.TimeSpan_0;
		if (timeSpan_ != this.gclass25_0.TimeSpan_0)
		{
			this.gclass25_0.TimeSpan_0 = timeSpan_;
		}
		this.gclass25_0.Event_3 += this.method_5;
		this.gclass25_0.Event_2 += this.method_4;
		this.gclass25_0.Event_1 += this.method_3;
		this.gclass25_0.Event_0 += this.method_2;
		this.gclass25_0.method_66();
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x00006089 File Offset: 0x00004289
	protected void method_7()
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_72();
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x000060A9 File Offset: 0x000042A9
	protected void method_8(ushort ushort_0, string string_2)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_75(ushort_0, string_2);
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x000060CB File Offset: 0x000042CB
	protected void method_9(GEnum6 genum6_0, string string_2)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_76(genum6_0, string_2);
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x000060ED File Offset: 0x000042ED
	protected void method_10()
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_77();
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x0000610D File Offset: 0x0000430D
	protected void method_11(ushort ushort_0, string string_2)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_80(ushort_0, string_2);
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0000612F File Offset: 0x0000432F
	protected void method_12(GEnum6 genum6_0, string string_2)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The session has not started yet.");
		}
		this.gclass25_0.method_81(genum6_0, string_2);
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x00006151 File Offset: 0x00004351
	[Obsolete("This method will be removed.")]
	protected void method_13(string string_2, Exception exception_0)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("message");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentException("An empty string.", "message");
		}
		this.vmethod_1(new GEventArgs3(string_2, exception_0));
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_0(GEventArgs2 geventArgs2_0)
	{
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
	{
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_2(GEventArgs4 geventArgs4_0)
	{
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_3()
	{
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x00006186 File Offset: 0x00004386
	protected void method_14(byte[] byte_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_86(byte_0);
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x000061A7 File Offset: 0x000043A7
	protected void method_15(FileInfo fileInfo_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_87(fileInfo_0);
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x000061C8 File Offset: 0x000043C8
	protected void method_16(string string_2)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_88(string_2);
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x000061E9 File Offset: 0x000043E9
	protected void method_17(Stream stream_0, int int_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_89(stream_0, int_0);
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0000620B File Offset: 0x0000440B
	protected void method_18(byte[] byte_0, Action<bool> action_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_90(byte_0, action_0);
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0000622D File Offset: 0x0000442D
	protected void method_19(FileInfo fileInfo_0, Action<bool> action_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_91(fileInfo_0, action_0);
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0000624F File Offset: 0x0000444F
	protected void method_20(string string_2, Action<bool> action_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_92(string_2, action_0);
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x00006271 File Offset: 0x00004471
	protected void method_21(Stream stream_0, int int_0, Action<bool> action_0)
	{
		if (this.gclass25_0 == null)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		this.gclass25_0.method_93(stream_0, int_0, action_0);
	}

	// Token: 0x04000282 RID: 642
	private GClass46 gclass46_0;

	// Token: 0x04000283 RID: 643
	private Func<GClass34, GClass34, bool> func_0;

	// Token: 0x04000284 RID: 644
	private bool bool_0;

	// Token: 0x04000285 RID: 645
	private string string_0;

	// Token: 0x04000286 RID: 646
	private bool bool_1;

	// Token: 0x04000287 RID: 647
	private Func<string, bool> func_1;

	// Token: 0x04000288 RID: 648
	private string string_1;

	// Token: 0x04000289 RID: 649
	private GClass31 gclass31_0;

	// Token: 0x0400028A RID: 650
	private DateTime dateTime_0;

	// Token: 0x0400028B RID: 651
	private GClass25 gclass25_0;
}
