﻿using System;

// Token: 0x020000CF RID: 207
public class GClass65 : GClass61
{
	// Token: 0x060009C4 RID: 2500 RVA: 0x0000960E File Offset: 0x0000780E
	public GClass65(GClass99 gclass99_1) : base(gclass99_1)
	{
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x0003F8DC File Offset: 0x0003DADC
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(this.class90_0.Int32_0, Math.Min(this.class90_0.GStruct2_0.int_1, this.class90_0.GStruct2_1.int_1));
		this.gclass99_0.vmethod_13();
		GClass63.smethod_0(this.string_0, this.gclass99_0);
		this.gclass99_0.vmethod_10(this.class90_0.GStruct2_0.int_1, this.class90_0.GStruct2_1.int_1);
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = this.class90_0.GStruct2_0;
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1 = this.class90_0.GStruct2_1;
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x0003F9BC File Offset: 0x0003DBBC
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		FastColoredTextBox fastColoredTextBox_ = this.gclass99_0.FastColoredTextBox_0;
		string a = null;
		this.gclass99_0.vmethod_14(ref a);
		if (a == "")
		{
			throw new ArgumentOutOfRangeException();
		}
		this.string_0 = fastColoredTextBox_.GClass86_5.String_1;
		GClass65.smethod_0(this.gclass99_0);
		this.class90_1 = new Class90(fastColoredTextBox_.GClass86_5);
		this.gclass99_0.vmethod_10(this.class90_1.GStruct2_0.int_1, this.class90_1.GStruct2_0.int_1);
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x0003FA50 File Offset: 0x0003DC50
	internal static void smethod_0(GClass99 gclass99_1)
	{
		FastColoredTextBox fastColoredTextBox_ = gclass99_1.FastColoredTextBox_0;
		GStruct2 gstruct2_ = fastColoredTextBox_.GClass86_5.GStruct2_0;
		GStruct2 gstruct2_2 = fastColoredTextBox_.GClass86_5.GStruct2_1;
		int num = Math.Min(gstruct2_2.int_1, gstruct2_.int_1);
		int num2 = Math.Max(gstruct2_2.int_1, gstruct2_.int_1);
		int int32_ = fastColoredTextBox_.GClass86_5.Int32_2;
		int int32_2 = fastColoredTextBox_.GClass86_5.Int32_3;
		if (num < 0)
		{
			return;
		}
		if (num == num2)
		{
			gclass99_1[num].vmethod_0(int32_, int32_2 - int32_);
		}
		else
		{
			gclass99_1[num].vmethod_0(int32_, gclass99_1[num].Count - int32_);
			gclass99_1[num2].vmethod_0(0, int32_2);
			gclass99_1.GClass99.\u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(num + 1, num2 - num - 1);
			GClass62.smethod_2(num, gclass99_1);
		}
		fastColoredTextBox_.GClass86_5.GStruct2_0 = new GStruct2(int32_, num);
		gclass99_1.vmethod_11(new GClass99.GEventArgs20(num, num2));
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x00009617 File Offset: 0x00007817
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		return new GClass65(this.gclass99_0);
	}

	// Token: 0x040004D0 RID: 1232
	private string string_0;
}
