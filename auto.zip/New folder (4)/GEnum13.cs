﻿using System;

// Token: 0x020000EF RID: 239
public enum GEnum13
{
	// Token: 0x040005DC RID: 1500
	Strategy1,
	// Token: 0x040005DD RID: 1501
	Strategy2
}
