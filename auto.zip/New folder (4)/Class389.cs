﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x020002C2 RID: 706
internal class Class389
{
	// Token: 0x17000896 RID: 2198
	// (get) Token: 0x06002763 RID: 10083 RVA: 0x001183C8 File Offset: 0x001165C8
	public List<Class388> List_0
	{
		get
		{
			List<Class388> list = new List<Class388>();
			uint num = this.class159_0.Class405_0.method_20(this.class159_0.Class392_0.UInt32_119) + 8U;
			Class388 @class = new Class388();
			@class.UInt32_0 = num;
			@class.UInt32_2 = this.class159_0.Class405_0.method_11(@class.UInt32_0 + 272U);
			@class.UInt32_3 = this.class159_0.Class405_0.method_11(@class.UInt32_0 + 8U);
			@class.String_0 = this.class159_0.Class405_0.method_26(@class.UInt32_0 + 14U).Trim();
			list.Add(@class);
			for (uint num2 = 1U; num2 < 17U; num2 += 1U)
			{
				uint num3 = num + 280U * num2;
				Class388 class2 = new Class388();
				class2.UInt32_0 = num3;
				class2.UInt32_1 = num2;
				class2.UInt32_2 = this.class159_0.Class405_0.method_11(class2.UInt32_0 + 272U);
				class2.UInt32_3 = this.class159_0.Class405_0.method_11(class2.UInt32_0 + 8U);
				class2.String_0 = this.class159_0.Class405_0.method_26(num3 + 14U).Trim();
				if (class2.String_0 == "#{CJG_101231_121}")
				{
					class2.String_0 = "Cái Bang Nghi Vấn Ban Đầu";
				}
				if (Class363.dictionary_3.ContainsKey(class2.String_0))
				{
					class2.String_0 = Class363.dictionary_3[class2.String_0];
				}
				if (class2.String_0.Trim() != string.Empty)
				{
					list.Add(class2);
				}
			}
			return list;
		}
	}

	// Token: 0x06002764 RID: 10084 RVA: 0x0001D462 File Offset: 0x0001B662
	public Class389(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x06002765 RID: 10085 RVA: 0x0011857C File Offset: 0x0011677C
	public void method_0()
	{
		foreach (Class388 class388_ in this.List_0)
		{
			this.class159_0.method_357(class388_);
		}
	}

	// Token: 0x06002766 RID: 10086 RVA: 0x001185D8 File Offset: 0x001167D8
	public bool method_1(int int_0, int int_1)
	{
		foreach (Class388 @class in this.List_0)
		{
			if ((ulong)@class.UInt32_2 == (ulong)((long)int_0) && (ulong)@class.UInt32_3 == (ulong)((long)int_1))
			{
				this.class159_0.method_357(@class);
				return true;
			}
		}
		return false;
	}

	// Token: 0x06002767 RID: 10087 RVA: 0x0001D471 File Offset: 0x0001B671
	public bool method_2(int int_0)
	{
		if (int_0 <= this.List_0.Count - 1)
		{
			this.class159_0.method_357(this.List_0[int_0]);
			return true;
		}
		return false;
	}

	// Token: 0x06002768 RID: 10088 RVA: 0x0001D49D File Offset: 0x0001B69D
	public void method_3()
	{
		this.class159_0.method_282("QuestFrameAcceptClicked();", false);
	}

	// Token: 0x06002769 RID: 10089 RVA: 0x0001D4B0 File Offset: 0x0001B6B0
	public void method_4()
	{
		this.class159_0.method_282("QuestFrameMissionComplete(1);", false);
	}

	// Token: 0x0600276A RID: 10090 RVA: 0x00118650 File Offset: 0x00116850
	public bool method_5(string string_1)
	{
		foreach (Class388 @class in this.List_0)
		{
			if (Class426.smethod_57(@class.String_0).Contains(Class426.smethod_57(string_1)))
			{
				this.class159_0.method_357(@class);
				return true;
			}
		}
		if (this.class159_0.List_0.Contains(Enum14.NhiemVuChinhTuyen))
		{
			Thread.Sleep(1000);
			foreach (Class388 class2 in this.List_0)
			{
				if (Class426.smethod_57(class2.String_0).Contains(Class426.smethod_57(string_1)))
				{
					this.class159_0.method_357(class2);
					return true;
				}
			}
			Thread.Sleep(1000);
			foreach (Class388 class3 in this.List_0)
			{
				if (Class426.smethod_57(class3.String_0).Contains(Class426.smethod_57(string_1)))
				{
					this.class159_0.method_357(class3);
					return true;
				}
			}
			Thread.Sleep(1000);
			foreach (Class388 class4 in this.List_0)
			{
				if (Class426.smethod_57(class4.String_0).Contains(Class426.smethod_57(string_1)))
				{
					this.class159_0.method_357(class4);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600276B RID: 10091 RVA: 0x0001D4C3 File Offset: 0x0001B6C3
	public void method_6()
	{
		this.class159_0.method_57(0, 122);
	}

	// Token: 0x17000897 RID: 2199
	// (get) Token: 0x0600276C RID: 10092 RVA: 0x0001D4D3 File Offset: 0x0001B6D3
	// (set) Token: 0x0600276D RID: 10093 RVA: 0x0001D4DB File Offset: 0x0001B6DB
	public uint UInt32_0 { get; set; }

	// Token: 0x17000898 RID: 2200
	// (get) Token: 0x0600276E RID: 10094 RVA: 0x0001D4E4 File Offset: 0x0001B6E4
	// (set) Token: 0x0600276F RID: 10095 RVA: 0x0001D4EC File Offset: 0x0001B6EC
	public uint UInt32_1 { get; set; }

	// Token: 0x17000899 RID: 2201
	// (get) Token: 0x06002770 RID: 10096 RVA: 0x0001D4F5 File Offset: 0x0001B6F5
	// (set) Token: 0x06002771 RID: 10097 RVA: 0x0001D4FD File Offset: 0x0001B6FD
	public uint UInt32_2 { get; set; }

	// Token: 0x1700089A RID: 2202
	// (get) Token: 0x06002772 RID: 10098 RVA: 0x0001D506 File Offset: 0x0001B706
	public uint UInt32_3
	{
		get
		{
			return this.class159_0.Class405_0.method_17(this.class159_0.Class392_0.UInt32_119[0], 60U);
		}
	}

	// Token: 0x1700089B RID: 2203
	// (get) Token: 0x06002773 RID: 10099 RVA: 0x00118838 File Offset: 0x00116A38
	public string String_0
	{
		get
		{
			return Class426.Class430.smethod_3(this.UInt32_1.ToString() + this.UInt32_2.ToString()).Substring(0, 3);
		}
	}

	// Token: 0x06002774 RID: 10100 RVA: 0x00118874 File Offset: 0x00116A74
	public static void smethod_0(Class159 class159_1)
	{
		foreach (Class389 @class in Class389.smethod_2(class159_1))
		{
			if (@class.Boolean_0)
			{
				class159_1.method_356(@class);
				break;
			}
		}
	}

	// Token: 0x06002775 RID: 10101 RVA: 0x001188D4 File Offset: 0x00116AD4
	public static void smethod_1(Class159 class159_1)
	{
		foreach (Class389 @class in Class389.smethod_2(class159_1))
		{
			if (((@class.UInt32_1 != 119001U && @class.UInt32_1 != 118001U) || @class.UInt32_2 != 1U) && @class.UInt32_1 != 119005U && @class.UInt32_1 != 118012U)
			{
				if (@class.UInt32_1 != 2108U)
				{
					continue;
				}
			}
			class159_1.method_356(@class);
			break;
		}
	}

	// Token: 0x1700089C RID: 2204
	// (get) Token: 0x06002776 RID: 10102 RVA: 0x00118978 File Offset: 0x00116B78
	public bool Boolean_0
	{
		get
		{
			return this.UInt32_1 == 200005U || this.UInt32_1 == 118001U || this.UInt32_1 == 119005U || this.UInt32_1 == 119001U || this.UInt32_1 == 200001U || this.UInt32_1 == 13035U || this.UInt32_1 == 9044U || this.UInt32_1 == 10051U || this.UInt32_1 == 16035U || this.UInt32_1 == 14035U || this.UInt32_1 == 9035U || this.UInt32_1 == 17035U || this.UInt32_1 == 15035U || this.UInt32_1 == 12035U || this.UInt32_1 == 11035U || this.UInt32_1 == 10035U;
		}
	}

	// Token: 0x06002777 RID: 10103 RVA: 0x00118A78 File Offset: 0x00116C78
	public static List<Class389> smethod_2(Class159 class159_1)
	{
		List<Class389> list = new List<Class389>();
		uint num = class159_1.Class405_0.method_20(class159_1.Class392_0.UInt32_119) + 8U;
		Class389 @class = new Class389(class159_1);
		@class.uint_0 = num;
		@class.UInt32_1 = class159_1.Class405_0.method_11(@class.uint_0 + 272U);
		@class.UInt32_2 = class159_1.Class405_0.method_11(@class.uint_0 + 8U);
		@class.string_0 = class159_1.Class405_0.method_26(@class.uint_0 + 14U);
		list.Add(@class);
		for (uint num2 = 1U; num2 < 20U; num2 += 1U)
		{
			uint num3 = num + 280U * num2;
			@class = new Class389(class159_1);
			@class.uint_0 = num3;
			@class.UInt32_0 = num2;
			@class.UInt32_1 = class159_1.Class405_0.method_11(@class.uint_0 + 272U);
			@class.UInt32_2 = class159_1.Class405_0.method_11(@class.uint_0 + 8U);
			@class.string_0 = class159_1.Class405_0.method_26(num3 + 14U).Trim();
			if (@class.string_0 == "#{CJG_101231_121}")
			{
				@class.string_0 = "Cái Bang Nghi Vấn Ban Đầu";
			}
			if (Class363.dictionary_3.ContainsKey(@class.string_0))
			{
				@class.string_0 = Class363.dictionary_3[@class.string_0];
			}
			if (@class.string_0.Trim() != "")
			{
				list.Add(@class);
			}
		}
		return list;
	}

	// Token: 0x1700089D RID: 2205
	// (get) Token: 0x06002778 RID: 10104 RVA: 0x00118BF4 File Offset: 0x00116DF4
	public string String_1
	{
		get
		{
			string text = "";
			foreach (Class388 @class in this.List_0)
			{
				text += @class.String_0;
			}
			return text;
		}
	}

	// Token: 0x06002779 RID: 10105 RVA: 0x00118C58 File Offset: 0x00116E58
	public static string smethod_3(Class159 class159_1)
	{
		string text = "";
		foreach (Class389 @class in Class389.smethod_2(class159_1))
		{
			text += @class.string_0;
		}
		return text;
	}

	// Token: 0x0600277A RID: 10106 RVA: 0x00118CBC File Offset: 0x00116EBC
	public static string smethod_4(Class159 class159_1)
	{
		string text = "";
		using (List<Class389>.Enumerator enumerator = Class389.smethod_2(class159_1).GetEnumerator())
		{
			if (enumerator.MoveNext())
			{
				Class389 @class = enumerator.Current;
				text += @class.string_0;
			}
		}
		return text;
	}

	// Token: 0x04001AC6 RID: 6854
	public uint uint_0;

	// Token: 0x04001AC7 RID: 6855
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001AC8 RID: 6856
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001AC9 RID: 6857
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001ACA RID: 6858
	private Class159 class159_0;

	// Token: 0x04001ACB RID: 6859
	public string string_0;
}
