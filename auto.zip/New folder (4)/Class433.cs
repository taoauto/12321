﻿using System;

// Token: 0x0200030C RID: 780
internal class Class433 : Class432
{
	// Token: 0x06002C92 RID: 11410 RVA: 0x0002074F File Offset: 0x0001E94F
	public Class433(Class159 class159_1) : base(class159_1)
	{
	}
}
