﻿using System;

// Token: 0x02000109 RID: 265
public enum GEnum17 : byte
{
	// Token: 0x040006B2 RID: 1714
	Visible,
	// Token: 0x040006B3 RID: 1715
	StartOfHiddenBlock,
	// Token: 0x040006B4 RID: 1716
	Hidden
}
