﻿using System;
using System.Collections.Generic;

// Token: 0x02000108 RID: 264
public struct GStruct1
{
	// Token: 0x06000D99 RID: 3481 RVA: 0x0000BC06 File Offset: 0x00009E06
	public GStruct1(int int_3)
	{
		this.list_0 = null;
		this.genum17_0 = GEnum17.Visible;
		this.int_0 = int_3;
		this.int_1 = 0;
		this.int_2 = 0;
	}

	// Token: 0x1700039D RID: 925
	// (get) Token: 0x06000D9A RID: 3482 RVA: 0x0000BC2B File Offset: 0x00009E2B
	public List<int> List_0
	{
		get
		{
			if (this.list_0 == null)
			{
				this.list_0 = new List<int>();
			}
			return this.list_0;
		}
	}

	// Token: 0x1700039E RID: 926
	// (get) Token: 0x06000D9B RID: 3483 RVA: 0x000508D8 File Offset: 0x0004EAD8
	public int Int32_0
	{
		get
		{
			switch (this.genum17_0)
			{
			case GEnum17.Visible:
				if (this.list_0 == null)
				{
					return 1;
				}
				return this.list_0.Count + 1;
			case GEnum17.StartOfHiddenBlock:
				return 1;
			case GEnum17.Hidden:
				return 0;
			default:
				return 0;
			}
		}
	}

	// Token: 0x06000D9C RID: 3484 RVA: 0x0000BC46 File Offset: 0x00009E46
	internal int method_0(int int_3)
	{
		if (int_3 != 0)
		{
			return this.List_0[int_3 - 1];
		}
		return 0;
	}

	// Token: 0x06000D9D RID: 3485 RVA: 0x0000BC5B File Offset: 0x00009E5B
	internal int method_1(int int_3, GClass81 gclass81_0)
	{
		if (this.Int32_0 <= 0)
		{
			return 0;
		}
		if (int_3 != this.Int32_0 - 1)
		{
			return this.List_0[int_3] - 1;
		}
		return gclass81_0.Count - 1;
	}

	// Token: 0x06000D9E RID: 3486 RVA: 0x0005091C File Offset: 0x0004EB1C
	public int method_2(int int_3)
	{
		if (this.list_0 != null && this.list_0.Count != 0)
		{
			for (int i = 0; i < this.list_0.Count; i++)
			{
				if (this.list_0[i] > int_3)
				{
					return i;
				}
			}
			return this.list_0.Count;
		}
		return 0;
	}

	// Token: 0x040006AC RID: 1708
	private List<int> list_0;

	// Token: 0x040006AD RID: 1709
	internal int int_0;

	// Token: 0x040006AE RID: 1710
	internal int int_1;

	// Token: 0x040006AF RID: 1711
	internal int int_2;

	// Token: 0x040006B0 RID: 1712
	public GEnum17 genum17_0;
}
