﻿using System;

// Token: 0x02000149 RID: 329
internal class EventArgs1 : EventArgs
{
	// Token: 0x0600101F RID: 4127 RVA: 0x0000D41F File Offset: 0x0000B61F
	public EventArgs1(Class130 class130_1)
	{
		this.class130_0 = class130_1;
	}

	// Token: 0x06001020 RID: 4128 RVA: 0x0000D42E File Offset: 0x0000B62E
	public EventArgs1(Class130 class130_1, bool bool_1) : this(class130_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x17000423 RID: 1059
	// (get) Token: 0x06001021 RID: 4129 RVA: 0x0000D43E File Offset: 0x0000B63E
	public Class130 Class130_0
	{
		get
		{
			return this.class130_0;
		}
	}

	// Token: 0x17000424 RID: 1060
	// (get) Token: 0x06001022 RID: 4130 RVA: 0x0000D446 File Offset: 0x0000B646
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x0400084A RID: 2122
	private Class130 class130_0;

	// Token: 0x0400084B RID: 2123
	private bool bool_0;
}
