﻿using System;

// Token: 0x02000184 RID: 388
[Serializable]
public struct GStruct13
{
	// Token: 0x040009F5 RID: 2549
	public uint Characteristics;

	// Token: 0x040009F6 RID: 2550
	public uint TimeDateStamp;

	// Token: 0x040009F7 RID: 2551
	public ushort MajorVersion;

	// Token: 0x040009F8 RID: 2552
	public ushort MinorVersion;

	// Token: 0x040009F9 RID: 2553
	public ushort NumberOfNamedEntries;

	// Token: 0x040009FA RID: 2554
	public ushort NumberOfIdEntries;
}
