﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001FB RID: 507
public class GomItem : UserControl
{
	// Token: 0x06001A5C RID: 6748 RVA: 0x0001318D File Offset: 0x0001138D
	public GomItem()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001A5D RID: 6749 RVA: 0x000C763C File Offset: 0x000C583C
	private void GomItem_Load(object sender, EventArgs e)
	{
		this.txtName.Text = Class415.String_22;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(GomItem.Class236.<>9.method_0)).ToArray<ListViewItem>());
		this.tabPage2.Controls.Add(new GomItemKNB
		{
			Dock = DockStyle.Fill
		});
	}

	// Token: 0x06001A5E RID: 6750 RVA: 0x000C76C0 File Offset: 0x000C58C0
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]).Replace("[locked]", "") == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtName.Text = this.txtName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtName.method_1();
	}

	// Token: 0x06001A5F RID: 6751 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuAddType_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A60 RID: 6752 RVA: 0x0001319B File Offset: 0x0001139B
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001A61 RID: 6753 RVA: 0x0001319B File Offset: 0x0001139B
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001A62 RID: 6754 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A63 RID: 6755 RVA: 0x000131A3 File Offset: 0x000113A3
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x06001A64 RID: 6756 RVA: 0x000C77D0 File Offset: 0x000C59D0
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_22 = this.txtName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x06001A65 RID: 6757 RVA: 0x00002E18 File Offset: 0x00001018
	private void tabPage2_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A66 RID: 6758 RVA: 0x000131BC File Offset: 0x000113BC
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A67 RID: 6759 RVA: 0x000C7838 File Offset: 0x000C5A38
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(GomItem));
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddType = new ToolStripMenuItem();
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.menuName_1 = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtName = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.menuName.SuspendLayout();
		this.menuName_1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		base.SuspendLayout();
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddType
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddType.Name = "menuAddType";
		this.menuAddType.Size = new Size(104, 22);
		this.menuAddType.Text = "Thêm";
		this.menuAddType.Click += this.menuAddType_Click;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName_1;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(237, 323);
		this.lvName.TabIndex = 24;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 180;
		this.menuName_1.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName_1.Name = "menuName";
		this.menuName_1.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtName.Dock = DockStyle.Fill;
		this.txtName.Location = new Point(0, 0);
		this.txtName.Multiline = true;
		this.txtName.Name = "txtName";
		this.txtName.ScrollBars = ScrollBars.Vertical;
		this.txtName.Size = new Size(229, 343);
		this.txtName.TabIndex = 22;
		this.txtName.String_0 = "";
		this.txtName.Color_0 = Color.Gray;
		this.txtName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtName.Color_1 = Color.LightGray;
		this.txtName.TextChanged += this.txtName_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(470, 343);
		this.splitContainer1.SplitterDistance = 229;
		this.splitContainer1.TabIndex = 0;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(237, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(484, 375);
		this.tabControlEx1.TabIndex = 2;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(476, 349);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Đồ Thường";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(476, 349);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Đồ KNB";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.tabPage2.Click += this.tabPage2_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Name = "GomItem";
		base.Size = new Size(484, 375);
		base.Tag = "Gom Đồ";
		base.Load += this.GomItem_Load;
		this.menuName.ResumeLayout(false);
		this.menuName_1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x0400107E RID: 4222
	private IContainer icontainer_0;

	// Token: 0x0400107F RID: 4223
	private ContextMenuStrip menuName;

	// Token: 0x04001080 RID: 4224
	private ToolStripMenuItem menuAddType;

	// Token: 0x04001081 RID: 4225
	private ListViewEx lvName;

	// Token: 0x04001082 RID: 4226
	private ColumnHeader columnHeader_0;

	// Token: 0x04001083 RID: 4227
	private ContextMenuStrip menuName_1;

	// Token: 0x04001084 RID: 4228
	private ToolStripMenuItem menuAddName;

	// Token: 0x04001085 RID: 4229
	private Class85 txtName;

	// Token: 0x04001086 RID: 4230
	private SplitContainer splitContainer1;

	// Token: 0x04001087 RID: 4231
	private Class85 txtSearchName;

	// Token: 0x04001088 RID: 4232
	private Control1 tabControlEx1;

	// Token: 0x04001089 RID: 4233
	private TabPage tabPage1;

	// Token: 0x0400108A RID: 4234
	private TabPage tabPage2;

	// Token: 0x020001FC RID: 508
	[CompilerGenerated]
	[Serializable]
	private sealed class Class236
	{
		// Token: 0x06001A6A RID: 6762 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x0400108B RID: 4235
		public static readonly GomItem.Class236 <>9 = new GomItem.Class236();

		// Token: 0x0400108C RID: 4236
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
