﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

// Token: 0x02000211 RID: 529
internal class Class244 : ToolStripRenderer
{
	// Token: 0x17000685 RID: 1669
	// (get) Token: 0x06001B59 RID: 7001 RVA: 0x00013CB4 File Offset: 0x00011EB4
	// (set) Token: 0x06001B5A RID: 7002 RVA: 0x000D0E20 File Offset: 0x000CF020
	public ToolStripRenderMode ToolStripRenderMode_0
	{
		get
		{
			return this.toolStripRenderMode_0;
		}
		set
		{
			this.toolStripRenderMode_0 = value;
			ToolStripRenderMode toolStripRenderMode = this.toolStripRenderMode_0;
			if (toolStripRenderMode == ToolStripRenderMode.System)
			{
				this.toolStripRenderer_0 = new ToolStripSystemRenderer();
				return;
			}
			if (toolStripRenderMode == ToolStripRenderMode.Professional)
			{
				this.toolStripRenderer_0 = new ToolStripProfessionalRenderer();
				return;
			}
			this.toolStripRenderer_0 = null;
		}
	}

	// Token: 0x17000686 RID: 1670
	// (get) Token: 0x06001B5B RID: 7003 RVA: 0x00013CBC File Offset: 0x00011EBC
	// (set) Token: 0x06001B5C RID: 7004 RVA: 0x00013CC4 File Offset: 0x00011EC4
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x17000687 RID: 1671
	// (get) Token: 0x06001B5D RID: 7005 RVA: 0x00013CCD File Offset: 0x00011ECD
	// (set) Token: 0x06001B5E RID: 7006 RVA: 0x00013CD5 File Offset: 0x00011ED5
	public bool Boolean_1
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			if (value && !Application.RenderWithVisualStyles)
			{
				return;
			}
			this.bool_1 = value;
		}
	}

	// Token: 0x06001B5F RID: 7007 RVA: 0x00013CE9 File Offset: 0x00011EE9
	protected virtual void Initialize(ToolStrip toolStrip)
	{
		base.Initialize(toolStrip);
	}

	// Token: 0x06001B60 RID: 7008 RVA: 0x000D0E64 File Offset: 0x000CF064
	protected virtual void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
	{
		Color color = SystemColors.AppWorkspace;
		if (this.Boolean_1)
		{
			color = new VisualStyleRenderer(VisualStyleElement.Tab.Pane.Normal).GetColor(ColorProperty.BorderColorHint);
		}
		using (Pen pen = new Pen(color))
		{
			using (Pen pen2 = new Pen(e.BackColor))
			{
				Rectangle bounds = e.ToolStrip.Bounds;
				int num = this.Boolean_0 ? 0 : (bounds.Width - 1 - e.ToolStrip.Padding.Horizontal);
				int num2 = this.Boolean_0 ? 0 : (bounds.Height - 1);
				if (e.ToolStrip.Orientation == Orientation.Horizontal)
				{
					e.Graphics.DrawLine(pen, 0, num2, bounds.Width, num2);
				}
				else
				{
					e.Graphics.DrawLine(pen, num, 0, num, bounds.Height);
					if (!this.Boolean_0)
					{
						for (int i = num + 1; i < bounds.Width; i++)
						{
							e.Graphics.DrawLine(pen2, i, 0, i, bounds.Height);
						}
					}
				}
				foreach (object obj in e.ToolStrip.Items)
				{
					ToolStripItem toolStripItem = (ToolStripItem)obj;
					if (!toolStripItem.IsOnOverflow)
					{
						GClass122 gclass = toolStripItem as GClass122;
						if (gclass != null)
						{
							Rectangle bounds2 = gclass.Bounds;
							int num3 = this.Boolean_0 ? bounds2.Left : bounds2.Right;
							int num4 = this.Boolean_0 ? bounds2.Top : (bounds2.Bottom - 1);
							int num5 = this.Boolean_0 ? 0 : 1;
							if (e.ToolStrip.Orientation == Orientation.Horizontal)
							{
								e.Graphics.DrawLine(pen, bounds2.Left, num4, bounds2.Right, num4);
								if (gclass.Boolean_0)
								{
									e.Graphics.DrawLine(pen2, bounds2.Left + 2 - num5, num4, bounds2.Right - 2 - num5, num4);
								}
							}
							else
							{
								e.Graphics.DrawLine(pen, num3, bounds2.Top, num3, bounds2.Bottom);
								if (gclass.Boolean_0)
								{
									e.Graphics.DrawLine(pen2, num3, bounds2.Top + 2 - num5, num3, bounds2.Bottom - 2 - num5);
								}
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06001B61 RID: 7009 RVA: 0x00013CF2 File Offset: 0x00011EF2
	protected virtual void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawToolStripBackground(e);
			return;
		}
		base.OnRenderToolStripBackground(e);
	}

	// Token: 0x06001B62 RID: 7010 RVA: 0x000D112C File Offset: 0x000CF32C
	protected virtual void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
	{
		Graphics graphics = e.Graphics;
		GClass121 gclass = e.ToolStrip as GClass121;
		GClass122 gclass2 = e.Item as GClass122;
		if (gclass != null && gclass2 != null)
		{
			bool boolean_ = gclass2.Boolean_0;
			bool selected = gclass2.Selected;
			int num = 0;
			int num2 = 0;
			int num3 = gclass2.Bounds.Width - 1;
			int num4 = gclass2.Bounds.Height - 1;
			Rectangle bounds;
			if (this.Boolean_1)
			{
				if (gclass.Orientation == Orientation.Horizontal)
				{
					if (!boolean_)
					{
						num = 2;
						num4--;
					}
					else
					{
						num = 1;
					}
					bounds = new Rectangle(0, 0, num3, num4);
				}
				else
				{
					if (!boolean_)
					{
						num2 = 2;
						num3--;
					}
					else
					{
						num2 = 1;
					}
					bounds = new Rectangle(0, 0, num4, num3);
				}
				using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
				{
					VisualStyleElement element = VisualStyleElement.Tab.TabItem.Normal;
					if (boolean_)
					{
						element = VisualStyleElement.Tab.TabItem.Pressed;
					}
					if (selected)
					{
						element = VisualStyleElement.Tab.TabItem.Hot;
					}
					if (!gclass2.Enabled)
					{
						element = VisualStyleElement.Tab.TabItem.Disabled;
					}
					if (!boolean_ || selected)
					{
						int num5 = bounds.Width;
						bounds.Width = num5 + 1;
					}
					else
					{
						int num5 = bounds.Height;
						bounds.Height = num5 + 1;
					}
					using (Graphics graphics2 = Graphics.FromImage(bitmap))
					{
						new VisualStyleRenderer(element).DrawBackground(graphics2, bounds);
						if (gclass.Orientation == Orientation.Vertical)
						{
							if (this.Boolean_0)
							{
								bitmap.RotateFlip(RotateFlipType.Rotate90FlipNone);
							}
							else
							{
								bitmap.RotateFlip(RotateFlipType.Rotate270FlipNone);
							}
						}
						else if (this.Boolean_0)
						{
							bitmap.RotateFlip(RotateFlipType.Rotate180FlipX);
						}
						if (this.Boolean_0)
						{
							num2 = gclass2.Bounds.Width - bitmap.Width - num2;
							num = gclass2.Bounds.Height - bitmap.Height - num;
						}
						graphics.DrawImage(bitmap, num2, num);
						return;
					}
				}
			}
			if (gclass.Orientation == Orientation.Horizontal)
			{
				if (!boolean_)
				{
					num = 2;
					num4--;
				}
				else
				{
					num = 1;
				}
				if (this.Boolean_0)
				{
					num2 = 1;
					num = 0;
				}
				else
				{
					num++;
				}
				num3--;
			}
			else
			{
				if (!boolean_)
				{
					num2 = 2;
					num3--;
				}
				else
				{
					num2 = 1;
				}
				if (this.Boolean_0)
				{
					num2 = 0;
					num = 1;
				}
			}
			num4--;
			bounds = new Rectangle(num2, num, num3, num4);
			using (GraphicsPath graphicsPath = new GraphicsPath())
			{
				if (this.Boolean_0 && gclass.Orientation == Orientation.Horizontal)
				{
					graphicsPath.AddLine(bounds.Left, bounds.Top, bounds.Left, bounds.Bottom - 2);
					graphicsPath.AddArc(bounds.Left, bounds.Bottom - 3, 2, 2, 90f, 90f);
					graphicsPath.AddLine(bounds.Left + 2, bounds.Bottom, bounds.Right - 2, bounds.Bottom);
					graphicsPath.AddArc(bounds.Right - 2, bounds.Bottom - 3, 2, 2, 0f, 90f);
					graphicsPath.AddLine(bounds.Right, bounds.Bottom - 2, bounds.Right, bounds.Top);
				}
				else if (!this.Boolean_0 && gclass.Orientation == Orientation.Horizontal)
				{
					graphicsPath.AddLine(bounds.Left, bounds.Bottom, bounds.Left, bounds.Top + 2);
					graphicsPath.AddArc(bounds.Left, bounds.Top + 1, 2, 2, 180f, 90f);
					graphicsPath.AddLine(bounds.Left + 2, bounds.Top, bounds.Right - 2, bounds.Top);
					graphicsPath.AddArc(bounds.Right - 2, bounds.Top + 1, 2, 2, 270f, 90f);
					graphicsPath.AddLine(bounds.Right, bounds.Top + 2, bounds.Right, bounds.Bottom);
				}
				else if (this.Boolean_0 && gclass.Orientation == Orientation.Vertical)
				{
					graphicsPath.AddLine(bounds.Left, bounds.Top, bounds.Right - 2, bounds.Top);
					graphicsPath.AddArc(bounds.Right - 2, bounds.Top + 1, 2, 2, 270f, 90f);
					graphicsPath.AddLine(bounds.Right, bounds.Top + 2, bounds.Right, bounds.Bottom - 2);
					graphicsPath.AddArc(bounds.Right - 2, bounds.Bottom - 3, 2, 2, 0f, 90f);
					graphicsPath.AddLine(bounds.Right - 2, bounds.Bottom, bounds.Left, bounds.Bottom);
				}
				else
				{
					graphicsPath.AddLine(bounds.Right, bounds.Top, bounds.Left + 2, bounds.Top);
					graphicsPath.AddArc(bounds.Left, bounds.Top + 1, 2, 2, 180f, 90f);
					graphicsPath.AddLine(bounds.Left, bounds.Top + 2, bounds.Left, bounds.Bottom - 2);
					graphicsPath.AddArc(bounds.Left, bounds.Bottom - 3, 2, 2, 90f, 90f);
					graphicsPath.AddLine(bounds.Left + 2, bounds.Bottom, bounds.Right, bounds.Bottom);
				}
				if (boolean_ || selected)
				{
					Color color = selected ? Color.WhiteSmoke : Color.White;
					if (this.toolStripRenderMode_0 == ToolStripRenderMode.Professional)
					{
						color = (selected ? ProfessionalColors.ButtonCheckedGradientBegin : ProfessionalColors.ButtonCheckedGradientEnd);
						using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(gclass2.ContentRectangle, color, ProfessionalColors.ButtonCheckedGradientMiddle, LinearGradientMode.Vertical))
						{
							graphics.FillPath(linearGradientBrush, graphicsPath);
							goto IL_608;
						}
					}
					using (SolidBrush solidBrush = new SolidBrush(color))
					{
						graphics.FillPath(solidBrush, graphicsPath);
					}
				}
				IL_608:
				using (Pen pen = new Pen(boolean_ ? ControlPaint.Dark(SystemColors.AppWorkspace) : SystemColors.AppWorkspace))
				{
					graphics.DrawPath(pen, graphicsPath);
				}
			}
			return;
		}
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawButtonBackground(e);
			return;
		}
		base.OnRenderButtonBackground(e);
	}

	// Token: 0x06001B63 RID: 7011 RVA: 0x000D1834 File Offset: 0x000CFA34
	protected virtual void OnRenderItemImage(ToolStripItemImageRenderEventArgs e)
	{
		Rectangle imageRectangle = e.ImageRectangle;
		GClass122 gclass = e.Item as GClass122;
		if (gclass != null)
		{
			int num = (this.Boolean_0 ? -1 : 1) * (gclass.Boolean_0 ? 1 : 2);
			if (e.ToolStrip.Orientation == Orientation.Horizontal)
			{
				imageRectangle.Offset(this.Boolean_0 ? 2 : 1, num + (this.Boolean_0 ? 1 : 0));
			}
			else
			{
				imageRectangle.Offset(num + 2, 0);
			}
		}
		ToolStripItemImageRenderEventArgs e2 = new ToolStripItemImageRenderEventArgs(e.Graphics, e.Item, e.Image, imageRectangle);
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawItemImage(e2);
			return;
		}
		base.OnRenderItemImage(e2);
	}

	// Token: 0x06001B64 RID: 7012 RVA: 0x000D18E4 File Offset: 0x000CFAE4
	protected virtual void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
	{
		Rectangle textRectangle = e.TextRectangle;
		GClass122 gclass = e.Item as GClass122;
		Color textColor = e.TextColor;
		Font textFont = e.TextFont;
		if (gclass != null)
		{
			int num = (this.Boolean_0 ? -1 : 1) * (gclass.Boolean_0 ? 1 : 2);
			if (e.ToolStrip.Orientation == Orientation.Horizontal)
			{
				textRectangle.Offset(this.Boolean_0 ? 2 : 1, num + (this.Boolean_0 ? 1 : -1));
			}
			else
			{
				textRectangle.Offset(num + 2, 0);
			}
			if (gclass.Selected)
			{
				textColor = gclass.Color_0;
			}
			else if (gclass.Boolean_0)
			{
				textColor = gclass.Color_1;
			}
			if (gclass.Boolean_0)
			{
				textFont = gclass.Font_0;
			}
		}
		ToolStripItemTextRenderEventArgs toolStripItemTextRenderEventArgs = new ToolStripItemTextRenderEventArgs(e.Graphics, e.Item, e.Text, textRectangle, textColor, textFont, e.TextFormat);
		toolStripItemTextRenderEventArgs.TextDirection = e.TextDirection;
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawItemText(toolStripItemTextRenderEventArgs);
			return;
		}
		base.OnRenderItemText(toolStripItemTextRenderEventArgs);
	}

	// Token: 0x06001B65 RID: 7013 RVA: 0x00013D10 File Offset: 0x00011F10
	protected virtual void OnRenderArrow(ToolStripArrowRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawArrow(e);
			return;
		}
		base.OnRenderArrow(e);
	}

	// Token: 0x06001B66 RID: 7014 RVA: 0x00013D2E File Offset: 0x00011F2E
	protected virtual void OnRenderDropDownButtonBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawDropDownButtonBackground(e);
			return;
		}
		base.OnRenderDropDownButtonBackground(e);
	}

	// Token: 0x06001B67 RID: 7015 RVA: 0x00013D4C File Offset: 0x00011F4C
	protected virtual void OnRenderGrip(ToolStripGripRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawGrip(e);
			return;
		}
		base.OnRenderGrip(e);
	}

	// Token: 0x06001B68 RID: 7016 RVA: 0x00013D6A File Offset: 0x00011F6A
	protected virtual void OnRenderImageMargin(ToolStripRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawImageMargin(e);
			return;
		}
		base.OnRenderImageMargin(e);
	}

	// Token: 0x06001B69 RID: 7017 RVA: 0x00013D88 File Offset: 0x00011F88
	protected virtual void OnRenderItemBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawItemBackground(e);
			return;
		}
		base.OnRenderItemBackground(e);
	}

	// Token: 0x06001B6A RID: 7018 RVA: 0x00013DA6 File Offset: 0x00011FA6
	protected virtual void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawItemCheck(e);
			return;
		}
		base.OnRenderItemCheck(e);
	}

	// Token: 0x06001B6B RID: 7019 RVA: 0x00013DC4 File Offset: 0x00011FC4
	protected virtual void OnRenderLabelBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawLabelBackground(e);
			return;
		}
		base.OnRenderLabelBackground(e);
	}

	// Token: 0x06001B6C RID: 7020 RVA: 0x00013DE2 File Offset: 0x00011FE2
	protected virtual void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawMenuItemBackground(e);
			return;
		}
		base.OnRenderMenuItemBackground(e);
	}

	// Token: 0x06001B6D RID: 7021 RVA: 0x00013E00 File Offset: 0x00012000
	protected virtual void OnRenderOverflowButtonBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawOverflowButtonBackground(e);
			return;
		}
		base.OnRenderOverflowButtonBackground(e);
	}

	// Token: 0x06001B6E RID: 7022 RVA: 0x00013E1E File Offset: 0x0001201E
	protected virtual void OnRenderSeparator(ToolStripSeparatorRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawSeparator(e);
			return;
		}
		base.OnRenderSeparator(e);
	}

	// Token: 0x06001B6F RID: 7023 RVA: 0x00013E3C File Offset: 0x0001203C
	protected virtual void OnRenderSplitButtonBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawSplitButton(e);
			return;
		}
		base.OnRenderSplitButtonBackground(e);
	}

	// Token: 0x06001B70 RID: 7024 RVA: 0x00013E5A File Offset: 0x0001205A
	protected virtual void OnRenderStatusStripSizingGrip(ToolStripRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawStatusStripSizingGrip(e);
			return;
		}
		base.OnRenderStatusStripSizingGrip(e);
	}

	// Token: 0x06001B71 RID: 7025 RVA: 0x00013E78 File Offset: 0x00012078
	protected virtual void OnRenderToolStripContentPanelBackground(ToolStripContentPanelRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawToolStripContentPanelBackground(e);
			return;
		}
		base.OnRenderToolStripContentPanelBackground(e);
	}

	// Token: 0x06001B72 RID: 7026 RVA: 0x00013E96 File Offset: 0x00012096
	protected virtual void OnRenderToolStripPanelBackground(ToolStripPanelRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawToolStripPanelBackground(e);
			return;
		}
		base.OnRenderToolStripPanelBackground(e);
	}

	// Token: 0x06001B73 RID: 7027 RVA: 0x00013EB4 File Offset: 0x000120B4
	protected virtual void OnRenderToolStripStatusLabelBackground(ToolStripItemRenderEventArgs e)
	{
		if (this.toolStripRenderer_0 != null)
		{
			this.toolStripRenderer_0.DrawToolStripStatusLabelBackground(e);
			return;
		}
		base.OnRenderToolStripStatusLabelBackground(e);
	}

	// Token: 0x04001154 RID: 4436
	private const int int_0 = 2;

	// Token: 0x04001155 RID: 4437
	private ToolStripRenderer toolStripRenderer_0;

	// Token: 0x04001156 RID: 4438
	private ToolStripRenderMode toolStripRenderMode_0;

	// Token: 0x04001157 RID: 4439
	private bool bool_0;

	// Token: 0x04001158 RID: 4440
	private bool bool_1 = Application.RenderWithVisualStyles;
}
