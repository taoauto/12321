﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000E6 RID: 230
public class GEventArgs9 : EventArgs
{
	// Token: 0x06000C74 RID: 3188 RVA: 0x0000AFD8 File Offset: 0x000091D8
	public GEventArgs9(int int_2, int int_3)
	{
		this.Int32_0 = int_2;
		this.Int32_1 = int_3;
	}

	// Token: 0x17000345 RID: 837
	// (get) Token: 0x06000C75 RID: 3189 RVA: 0x0000AFEE File Offset: 0x000091EE
	// (set) Token: 0x06000C76 RID: 3190 RVA: 0x0000AFF6 File Offset: 0x000091F6
	public int Int32_0 { get; private set; }

	// Token: 0x17000346 RID: 838
	// (get) Token: 0x06000C77 RID: 3191 RVA: 0x0000AFFF File Offset: 0x000091FF
	// (set) Token: 0x06000C78 RID: 3192 RVA: 0x0000B007 File Offset: 0x00009207
	public int Int32_1 { get; private set; }

	// Token: 0x040005B8 RID: 1464
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040005B9 RID: 1465
	[CompilerGenerated]
	private int int_1;
}
