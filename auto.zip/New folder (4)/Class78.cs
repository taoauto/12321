﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Principal;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x0200009F RID: 159
internal static class Class78
{
	// Token: 0x0600077B RID: 1915 RVA: 0x00038A5C File Offset: 0x00036C5C
	private static Dictionary<string, char> smethod_0()
	{
		object obj = Class78.object_0;
		Dictionary<string, char> result;
		lock (obj)
		{
			if (Class78.dictionary_0 == null)
			{
				Class78.smethod_6();
			}
			result = Class78.dictionary_0;
		}
		return result;
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x00007F18 File Offset: 0x00006118
	private static int smethod_1(char char_1)
	{
		if (char_1 >= '0' && char_1 <= '9')
		{
			return (int)(char_1 - '0');
		}
		if (char_1 >= 'A' && char_1 <= 'F')
		{
			return (int)(char_1 - 'A' + '\n');
		}
		if (char_1 >= 'a' && char_1 <= 'f')
		{
			return (int)(char_1 - 'a' + '\n');
		}
		return -1;
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x00038AA8 File Offset: 0x00036CA8
	private static int smethod_2(byte[] byte_0, int int_0, int int_1)
	{
		int num = 0;
		int num2 = int_0 + int_1 - 1;
		for (int i = int_0; i <= num2; i++)
		{
			int num3 = Class78.smethod_1((char)byte_0[i]);
			if (num3 == -1)
			{
				return -1;
			}
			num = (num << 4) + num3;
		}
		return num;
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x00038AE4 File Offset: 0x00036CE4
	private static int smethod_3(string string_0, int int_0, int int_1)
	{
		int num = 0;
		int num2 = int_0 + int_1 - 1;
		for (int i = int_0; i <= num2; i++)
		{
			int num3 = Class78.smethod_1(string_0[i]);
			if (num3 == -1)
			{
				return -1;
			}
			num = (num << 4) + num3;
		}
		return num;
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00038B24 File Offset: 0x00036D24
	private static string smethod_4(string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		int num = 0;
		StringBuilder stringBuilder2 = new StringBuilder();
		int num2 = 0;
		foreach (char c in string_0)
		{
			if (num == 0)
			{
				if (c == '&')
				{
					stringBuilder2.Append('&');
					num = 1;
				}
				else
				{
					stringBuilder.Append(c);
				}
			}
			else if (c == '&')
			{
				stringBuilder.Append(stringBuilder2.ToString());
				stringBuilder2.Length = 0;
				stringBuilder2.Append('&');
				num = 1;
			}
			else
			{
				stringBuilder2.Append(c);
				if (num == 1)
				{
					if (c == ';')
					{
						stringBuilder.Append(stringBuilder2.ToString());
						stringBuilder2.Length = 0;
						num = 0;
					}
					else
					{
						num2 = 0;
						num = ((c == '#') ? 3 : 2);
					}
				}
				else if (num == 2)
				{
					if (c == ';')
					{
						string text = stringBuilder2.ToString();
						string key = text.Substring(1, text.Length - 2);
						Dictionary<string, char> dictionary = Class78.smethod_0();
						if (dictionary.ContainsKey(key))
						{
							stringBuilder.Append(dictionary[key]);
						}
						else
						{
							stringBuilder.Append(text);
						}
						stringBuilder2.Length = 0;
						num = 0;
					}
				}
				else if (num == 3)
				{
					if (c == ';')
					{
						if (stringBuilder2.Length > 3 && num2 < 65536)
						{
							stringBuilder.Append((char)num2);
						}
						else
						{
							stringBuilder.Append(stringBuilder2.ToString());
						}
						stringBuilder2.Length = 0;
						num = 0;
					}
					else if (c == 'x')
					{
						num = ((stringBuilder2.Length == 3) ? 4 : 2);
					}
					else if (!Class78.smethod_8(c))
					{
						num = 2;
					}
					else
					{
						num2 = num2 * 10 + (int)(c - '0');
					}
				}
				else if (num == 4)
				{
					if (c == ';')
					{
						if (stringBuilder2.Length > 4 && num2 < 65536)
						{
							stringBuilder.Append((char)num2);
						}
						else
						{
							stringBuilder.Append(stringBuilder2.ToString());
						}
						stringBuilder2.Length = 0;
						num = 0;
					}
					else
					{
						int num3 = Class78.smethod_1(c);
						if (num3 == -1)
						{
							num = 2;
						}
						else
						{
							num2 = (num2 << 4) + num3;
						}
					}
				}
			}
		}
		if (stringBuilder2.Length > 0)
		{
			stringBuilder.Append(stringBuilder2.ToString());
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00038D44 File Offset: 0x00036F44
	private static string smethod_5(string string_0, bool bool_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in string_0)
		{
			stringBuilder.Append((c == '"') ? "&quot;" : ((c == '&') ? "&amp;" : ((c == '<') ? "&lt;" : ((c == '>') ? "&gt;" : ((bool_0 || c <= '\u009f') ? c.ToString() : string.Format("&#{0};", (int)c))))));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00038DD4 File Offset: 0x00036FD4
	private static void smethod_6()
	{
		Class78.dictionary_0 = new Dictionary<string, char>();
		Class78.dictionary_0.Add("nbsp", '\u00a0');
		Class78.dictionary_0.Add("iexcl", '¡');
		Class78.dictionary_0.Add("cent", '¢');
		Class78.dictionary_0.Add("pound", '£');
		Class78.dictionary_0.Add("curren", '¤');
		Class78.dictionary_0.Add("yen", '¥');
		Class78.dictionary_0.Add("brvbar", '¦');
		Class78.dictionary_0.Add("sect", '§');
		Class78.dictionary_0.Add("uml", '¨');
		Class78.dictionary_0.Add("copy", '©');
		Class78.dictionary_0.Add("ordf", 'ª');
		Class78.dictionary_0.Add("laquo", '«');
		Class78.dictionary_0.Add("not", '¬');
		Class78.dictionary_0.Add("shy", '­');
		Class78.dictionary_0.Add("reg", '®');
		Class78.dictionary_0.Add("macr", '¯');
		Class78.dictionary_0.Add("deg", '°');
		Class78.dictionary_0.Add("plusmn", '±');
		Class78.dictionary_0.Add("sup2", '²');
		Class78.dictionary_0.Add("sup3", '³');
		Class78.dictionary_0.Add("acute", '´');
		Class78.dictionary_0.Add("micro", 'µ');
		Class78.dictionary_0.Add("para", '¶');
		Class78.dictionary_0.Add("middot", '·');
		Class78.dictionary_0.Add("cedil", '¸');
		Class78.dictionary_0.Add("sup1", '¹');
		Class78.dictionary_0.Add("ordm", 'º');
		Class78.dictionary_0.Add("raquo", '»');
		Class78.dictionary_0.Add("frac14", '¼');
		Class78.dictionary_0.Add("frac12", '½');
		Class78.dictionary_0.Add("frac34", '¾');
		Class78.dictionary_0.Add("iquest", '¿');
		Class78.dictionary_0.Add("Agrave", 'À');
		Class78.dictionary_0.Add("Aacute", 'Á');
		Class78.dictionary_0.Add("Acirc", 'Â');
		Class78.dictionary_0.Add("Atilde", 'Ã');
		Class78.dictionary_0.Add("Auml", 'Ä');
		Class78.dictionary_0.Add("Aring", 'Å');
		Class78.dictionary_0.Add("AElig", 'Æ');
		Class78.dictionary_0.Add("Ccedil", 'Ç');
		Class78.dictionary_0.Add("Egrave", 'È');
		Class78.dictionary_0.Add("Eacute", 'É');
		Class78.dictionary_0.Add("Ecirc", 'Ê');
		Class78.dictionary_0.Add("Euml", 'Ë');
		Class78.dictionary_0.Add("Igrave", 'Ì');
		Class78.dictionary_0.Add("Iacute", 'Í');
		Class78.dictionary_0.Add("Icirc", 'Î');
		Class78.dictionary_0.Add("Iuml", 'Ï');
		Class78.dictionary_0.Add("ETH", 'Ð');
		Class78.dictionary_0.Add("Ntilde", 'Ñ');
		Class78.dictionary_0.Add("Ograve", 'Ò');
		Class78.dictionary_0.Add("Oacute", 'Ó');
		Class78.dictionary_0.Add("Ocirc", 'Ô');
		Class78.dictionary_0.Add("Otilde", 'Õ');
		Class78.dictionary_0.Add("Ouml", 'Ö');
		Class78.dictionary_0.Add("times", '×');
		Class78.dictionary_0.Add("Oslash", 'Ø');
		Class78.dictionary_0.Add("Ugrave", 'Ù');
		Class78.dictionary_0.Add("Uacute", 'Ú');
		Class78.dictionary_0.Add("Ucirc", 'Û');
		Class78.dictionary_0.Add("Uuml", 'Ü');
		Class78.dictionary_0.Add("Yacute", 'Ý');
		Class78.dictionary_0.Add("THORN", 'Þ');
		Class78.dictionary_0.Add("szlig", 'ß');
		Class78.dictionary_0.Add("agrave", 'à');
		Class78.dictionary_0.Add("aacute", 'á');
		Class78.dictionary_0.Add("acirc", 'â');
		Class78.dictionary_0.Add("atilde", 'ã');
		Class78.dictionary_0.Add("auml", 'ä');
		Class78.dictionary_0.Add("aring", 'å');
		Class78.dictionary_0.Add("aelig", 'æ');
		Class78.dictionary_0.Add("ccedil", 'ç');
		Class78.dictionary_0.Add("egrave", 'è');
		Class78.dictionary_0.Add("eacute", 'é');
		Class78.dictionary_0.Add("ecirc", 'ê');
		Class78.dictionary_0.Add("euml", 'ë');
		Class78.dictionary_0.Add("igrave", 'ì');
		Class78.dictionary_0.Add("iacute", 'í');
		Class78.dictionary_0.Add("icirc", 'î');
		Class78.dictionary_0.Add("iuml", 'ï');
		Class78.dictionary_0.Add("eth", 'ð');
		Class78.dictionary_0.Add("ntilde", 'ñ');
		Class78.dictionary_0.Add("ograve", 'ò');
		Class78.dictionary_0.Add("oacute", 'ó');
		Class78.dictionary_0.Add("ocirc", 'ô');
		Class78.dictionary_0.Add("otilde", 'õ');
		Class78.dictionary_0.Add("ouml", 'ö');
		Class78.dictionary_0.Add("divide", '÷');
		Class78.dictionary_0.Add("oslash", 'ø');
		Class78.dictionary_0.Add("ugrave", 'ù');
		Class78.dictionary_0.Add("uacute", 'ú');
		Class78.dictionary_0.Add("ucirc", 'û');
		Class78.dictionary_0.Add("uuml", 'ü');
		Class78.dictionary_0.Add("yacute", 'ý');
		Class78.dictionary_0.Add("thorn", 'þ');
		Class78.dictionary_0.Add("yuml", 'ÿ');
		Class78.dictionary_0.Add("fnof", 'ƒ');
		Class78.dictionary_0.Add("Alpha", 'Α');
		Class78.dictionary_0.Add("Beta", 'Β');
		Class78.dictionary_0.Add("Gamma", 'Γ');
		Class78.dictionary_0.Add("Delta", 'Δ');
		Class78.dictionary_0.Add("Epsilon", 'Ε');
		Class78.dictionary_0.Add("Zeta", 'Ζ');
		Class78.dictionary_0.Add("Eta", 'Η');
		Class78.dictionary_0.Add("Theta", 'Θ');
		Class78.dictionary_0.Add("Iota", 'Ι');
		Class78.dictionary_0.Add("Kappa", 'Κ');
		Class78.dictionary_0.Add("Lambda", 'Λ');
		Class78.dictionary_0.Add("Mu", 'Μ');
		Class78.dictionary_0.Add("Nu", 'Ν');
		Class78.dictionary_0.Add("Xi", 'Ξ');
		Class78.dictionary_0.Add("Omicron", 'Ο');
		Class78.dictionary_0.Add("Pi", 'Π');
		Class78.dictionary_0.Add("Rho", 'Ρ');
		Class78.dictionary_0.Add("Sigma", 'Σ');
		Class78.dictionary_0.Add("Tau", 'Τ');
		Class78.dictionary_0.Add("Upsilon", 'Υ');
		Class78.dictionary_0.Add("Phi", 'Φ');
		Class78.dictionary_0.Add("Chi", 'Χ');
		Class78.dictionary_0.Add("Psi", 'Ψ');
		Class78.dictionary_0.Add("Omega", 'Ω');
		Class78.dictionary_0.Add("alpha", 'α');
		Class78.dictionary_0.Add("beta", 'β');
		Class78.dictionary_0.Add("gamma", 'γ');
		Class78.dictionary_0.Add("delta", 'δ');
		Class78.dictionary_0.Add("epsilon", 'ε');
		Class78.dictionary_0.Add("zeta", 'ζ');
		Class78.dictionary_0.Add("eta", 'η');
		Class78.dictionary_0.Add("theta", 'θ');
		Class78.dictionary_0.Add("iota", 'ι');
		Class78.dictionary_0.Add("kappa", 'κ');
		Class78.dictionary_0.Add("lambda", 'λ');
		Class78.dictionary_0.Add("mu", 'μ');
		Class78.dictionary_0.Add("nu", 'ν');
		Class78.dictionary_0.Add("xi", 'ξ');
		Class78.dictionary_0.Add("omicron", 'ο');
		Class78.dictionary_0.Add("pi", 'π');
		Class78.dictionary_0.Add("rho", 'ρ');
		Class78.dictionary_0.Add("sigmaf", 'ς');
		Class78.dictionary_0.Add("sigma", 'σ');
		Class78.dictionary_0.Add("tau", 'τ');
		Class78.dictionary_0.Add("upsilon", 'υ');
		Class78.dictionary_0.Add("phi", 'φ');
		Class78.dictionary_0.Add("chi", 'χ');
		Class78.dictionary_0.Add("psi", 'ψ');
		Class78.dictionary_0.Add("omega", 'ω');
		Class78.dictionary_0.Add("thetasym", 'ϑ');
		Class78.dictionary_0.Add("upsih", 'ϒ');
		Class78.dictionary_0.Add("piv", 'ϖ');
		Class78.dictionary_0.Add("bull", '•');
		Class78.dictionary_0.Add("hellip", '…');
		Class78.dictionary_0.Add("prime", '′');
		Class78.dictionary_0.Add("Prime", '″');
		Class78.dictionary_0.Add("oline", '‾');
		Class78.dictionary_0.Add("frasl", '⁄');
		Class78.dictionary_0.Add("weierp", '℘');
		Class78.dictionary_0.Add("image", 'ℑ');
		Class78.dictionary_0.Add("real", 'ℜ');
		Class78.dictionary_0.Add("trade", '™');
		Class78.dictionary_0.Add("alefsym", 'ℵ');
		Class78.dictionary_0.Add("larr", '←');
		Class78.dictionary_0.Add("uarr", '↑');
		Class78.dictionary_0.Add("rarr", '→');
		Class78.dictionary_0.Add("darr", '↓');
		Class78.dictionary_0.Add("harr", '↔');
		Class78.dictionary_0.Add("crarr", '↵');
		Class78.dictionary_0.Add("lArr", '⇐');
		Class78.dictionary_0.Add("uArr", '⇑');
		Class78.dictionary_0.Add("rArr", '⇒');
		Class78.dictionary_0.Add("dArr", '⇓');
		Class78.dictionary_0.Add("hArr", '⇔');
		Class78.dictionary_0.Add("forall", '∀');
		Class78.dictionary_0.Add("part", '∂');
		Class78.dictionary_0.Add("exist", '∃');
		Class78.dictionary_0.Add("empty", '∅');
		Class78.dictionary_0.Add("nabla", '∇');
		Class78.dictionary_0.Add("isin", '∈');
		Class78.dictionary_0.Add("notin", '∉');
		Class78.dictionary_0.Add("ni", '∋');
		Class78.dictionary_0.Add("prod", '∏');
		Class78.dictionary_0.Add("sum", '∑');
		Class78.dictionary_0.Add("minus", '−');
		Class78.dictionary_0.Add("lowast", '∗');
		Class78.dictionary_0.Add("radic", '√');
		Class78.dictionary_0.Add("prop", '∝');
		Class78.dictionary_0.Add("infin", '∞');
		Class78.dictionary_0.Add("ang", '∠');
		Class78.dictionary_0.Add("and", '∧');
		Class78.dictionary_0.Add("or", '∨');
		Class78.dictionary_0.Add("cap", '∩');
		Class78.dictionary_0.Add("cup", '∪');
		Class78.dictionary_0.Add("int", '∫');
		Class78.dictionary_0.Add("there4", '∴');
		Class78.dictionary_0.Add("sim", '∼');
		Class78.dictionary_0.Add("cong", '≅');
		Class78.dictionary_0.Add("asymp", '≈');
		Class78.dictionary_0.Add("ne", '≠');
		Class78.dictionary_0.Add("equiv", '≡');
		Class78.dictionary_0.Add("le", '≤');
		Class78.dictionary_0.Add("ge", '≥');
		Class78.dictionary_0.Add("sub", '⊂');
		Class78.dictionary_0.Add("sup", '⊃');
		Class78.dictionary_0.Add("nsub", '⊄');
		Class78.dictionary_0.Add("sube", '⊆');
		Class78.dictionary_0.Add("supe", '⊇');
		Class78.dictionary_0.Add("oplus", '⊕');
		Class78.dictionary_0.Add("otimes", '⊗');
		Class78.dictionary_0.Add("perp", '⊥');
		Class78.dictionary_0.Add("sdot", '⋅');
		Class78.dictionary_0.Add("lceil", '⌈');
		Class78.dictionary_0.Add("rceil", '⌉');
		Class78.dictionary_0.Add("lfloor", '⌊');
		Class78.dictionary_0.Add("rfloor", '⌋');
		Class78.dictionary_0.Add("lang", '〈');
		Class78.dictionary_0.Add("rang", '〉');
		Class78.dictionary_0.Add("loz", '◊');
		Class78.dictionary_0.Add("spades", '♠');
		Class78.dictionary_0.Add("clubs", '♣');
		Class78.dictionary_0.Add("hearts", '♥');
		Class78.dictionary_0.Add("diams", '♦');
		Class78.dictionary_0.Add("quot", '"');
		Class78.dictionary_0.Add("amp", '&');
		Class78.dictionary_0.Add("lt", '<');
		Class78.dictionary_0.Add("gt", '>');
		Class78.dictionary_0.Add("OElig", 'Œ');
		Class78.dictionary_0.Add("oelig", 'œ');
		Class78.dictionary_0.Add("Scaron", 'Š');
		Class78.dictionary_0.Add("scaron", 'š');
		Class78.dictionary_0.Add("Yuml", 'Ÿ');
		Class78.dictionary_0.Add("circ", 'ˆ');
		Class78.dictionary_0.Add("tilde", '˜');
		Class78.dictionary_0.Add("ensp", '\u2002');
		Class78.dictionary_0.Add("emsp", '\u2003');
		Class78.dictionary_0.Add("thinsp", '\u2009');
		Class78.dictionary_0.Add("zwnj", '‌');
		Class78.dictionary_0.Add("zwj", '‍');
		Class78.dictionary_0.Add("lrm", '‎');
		Class78.dictionary_0.Add("rlm", '‏');
		Class78.dictionary_0.Add("ndash", '–');
		Class78.dictionary_0.Add("mdash", '—');
		Class78.dictionary_0.Add("lsquo", '‘');
		Class78.dictionary_0.Add("rsquo", '’');
		Class78.dictionary_0.Add("sbquo", '‚');
		Class78.dictionary_0.Add("ldquo", '“');
		Class78.dictionary_0.Add("rdquo", '”');
		Class78.dictionary_0.Add("bdquo", '„');
		Class78.dictionary_0.Add("dagger", '†');
		Class78.dictionary_0.Add("Dagger", '‡');
		Class78.dictionary_0.Add("permil", '‰');
		Class78.dictionary_0.Add("lsaquo", '‹');
		Class78.dictionary_0.Add("rsaquo", '›');
		Class78.dictionary_0.Add("euro", '€');
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00007F4E File Offset: 0x0000614E
	private static bool smethod_7(char char_1)
	{
		return (char_1 >= 'A' && char_1 <= 'Z') || (char_1 >= 'a' && char_1 <= 'z');
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x00007F6B File Offset: 0x0000616B
	private static bool smethod_8(char char_1)
	{
		return char_1 >= '0' && char_1 <= '9';
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00007F7C File Offset: 0x0000617C
	private static bool smethod_9(char char_1)
	{
		return char_1 == '*' || char_1 == '-' || char_1 == '.' || char_1 == '_';
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00007F94 File Offset: 0x00006194
	private static bool smethod_10(char char_1)
	{
		return char_1 == '!' || char_1 == '\'' || char_1 == '(' || char_1 == ')' || char_1 == '*' || char_1 == '-' || char_1 == '.' || char_1 == '_' || char_1 == '~';
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00007FC5 File Offset: 0x000061C5
	private static bool smethod_11(char char_1)
	{
		return char_1 == '-' || char_1 == '.' || char_1 == '_' || char_1 == '~';
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x0003A190 File Offset: 0x00038390
	private static byte[] smethod_12(byte[] byte_0, int int_0, int int_1)
	{
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			int num = int_0 + int_1 - 1;
			for (int i = int_0; i <= num; i++)
			{
				byte b = byte_0[i];
				char c = (char)b;
				if (c == '%')
				{
					if (i > num - 2)
					{
						break;
					}
					int num2 = Class78.smethod_2(byte_0, i + 1, 2);
					if (num2 == -1)
					{
						break;
					}
					memoryStream.WriteByte((byte)num2);
					i += 2;
				}
				else if (c == '+')
				{
					memoryStream.WriteByte(32);
				}
				else
				{
					memoryStream.WriteByte(b);
				}
			}
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x0003A22C File Offset: 0x0003842C
	private static void smethod_13(byte byte_0, Stream stream_0)
	{
		if (byte_0 > 31 && byte_0 < 127)
		{
			if (byte_0 == 32)
			{
				stream_0.WriteByte(43);
				return;
			}
			if (Class78.smethod_8((char)byte_0))
			{
				stream_0.WriteByte(byte_0);
				return;
			}
			if (Class78.smethod_7((char)byte_0))
			{
				stream_0.WriteByte(byte_0);
				return;
			}
			if (Class78.smethod_9((char)byte_0))
			{
				stream_0.WriteByte(byte_0);
				return;
			}
		}
		byte[] buffer = new byte[]
		{
			37,
			(byte)Class78.char_0[byte_0 >> 4],
			(byte)Class78.char_0[(int)(byte_0 & 15)]
		};
		stream_0.Write(buffer, 0, 3);
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x0003A2B8 File Offset: 0x000384B8
	private static byte[] smethod_14(byte[] byte_0, int int_0, int int_1)
	{
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			int num = int_0 + int_1 - 1;
			for (int i = int_0; i <= num; i++)
			{
				Class78.smethod_13(byte_0[i], memoryStream);
			}
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x0003A310 File Offset: 0x00038510
	internal static Uri smethod_15(string string_0, string string_1, bool bool_0, bool bool_1)
	{
		if (string_0 == null || string_0.Length == 0)
		{
			return null;
		}
		if (string_1 == null || string_1.Length == 0)
		{
			return null;
		}
		string text = null;
		string arg = null;
		if (string_0.IndexOf('/') == 0)
		{
			arg = string_0;
		}
		else if (string_0.smethod_90())
		{
			Uri uri;
			if (!Uri.TryCreate(string_0, UriKind.Absolute, out uri))
			{
				return null;
			}
			text = uri.Scheme;
			if (!(bool_0 ? (text == "ws" || text == "wss") : (text == "http" || text == "https")))
			{
				return null;
			}
			string_1 = uri.Authority;
			arg = uri.PathAndQuery;
		}
		else if (!(string_0 == "*"))
		{
			string_1 = string_0;
		}
		if (text == null)
		{
			text = (bool_0 ? (bool_1 ? "wss" : "ws") : (bool_1 ? "https" : "http"));
		}
		if (string_1.IndexOf(':') == -1)
		{
			string_1 = string.Format("{0}:{1}", string_1, bool_1 ? 443 : 80);
		}
		Uri result;
		if (!Uri.TryCreate(string.Format("{0}://{1}{2}", text, string_1, arg), UriKind.Absolute, out result))
		{
			return null;
		}
		return result;
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x0003A43C File Offset: 0x0003863C
	internal static IPrincipal smethod_16(string string_0, AuthenticationSchemes authenticationSchemes_0, string string_1, string string_2, Func<IIdentity, GClass43> func_0)
	{
		if (string_0 == null || string_0.Length == 0)
		{
			return null;
		}
		if (authenticationSchemes_0 == AuthenticationSchemes.Digest)
		{
			if (string_1 == null || string_1.Length == 0)
			{
				return null;
			}
			if (string_2 == null || string_2.Length == 0)
			{
				return null;
			}
		}
		else if (authenticationSchemes_0 != AuthenticationSchemes.Basic)
		{
			return null;
		}
		if (func_0 == null)
		{
			return null;
		}
		if (string_0.IndexOf(authenticationSchemes_0.ToString(), StringComparison.OrdinalIgnoreCase) != 0)
		{
			return null;
		}
		Class64 @class = Class64.smethod_8(string_0);
		if (@class == null)
		{
			return null;
		}
		IIdentity identity = @class.method_1();
		if (identity == null)
		{
			return null;
		}
		GClass43 gclass = null;
		try
		{
			gclass = func_0(identity);
		}
		catch
		{
		}
		if (gclass == null)
		{
			return null;
		}
		if (authenticationSchemes_0 == AuthenticationSchemes.Basic)
		{
			if (!(((GClass35)identity).String_0 == gclass.String_1))
			{
				return null;
			}
			return new GenericPrincipal(identity, gclass.String_2);
		}
		else
		{
			if (!((GClass36)identity).method_0(gclass.String_1, string_1, string_2, null))
			{
				return null;
			}
			return new GenericPrincipal(identity, gclass.String_2);
		}
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x0003A52C File Offset: 0x0003872C
	internal static Encoding smethod_17(string string_0)
	{
		string value = "charset=";
		StringComparison comparisonType = StringComparison.OrdinalIgnoreCase;
		foreach (string text in string_0.smethod_59(new char[]
		{
			';'
		}))
		{
			string text2 = text.Trim();
			if (text2.IndexOf(value, comparisonType) == 0)
			{
				string text3 = text2.smethod_37('=', true);
				if (text3 != null && text3.Length != 0)
				{
					return Encoding.GetEncoding(text3);
				}
				return null;
			}
		}
		return null;
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x0003A5C4 File Offset: 0x000387C4
	internal static bool smethod_18(string string_0, out Encoding encoding_0)
	{
		encoding_0 = null;
		bool result;
		try
		{
			encoding_0 = Class78.smethod_17(string_0);
			goto IL_14;
		}
		catch
		{
			result = false;
		}
		return result;
		IL_14:
		return encoding_0 != null;
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00007FDD File Offset: 0x000061DD
	public static string smethod_19(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length <= 0)
		{
			return string_0;
		}
		return Class78.smethod_5(string_0, true);
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00007FFF File Offset: 0x000061FF
	public static void smethod_20(string string_0, TextWriter textWriter_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (textWriter_0 == null)
		{
			throw new ArgumentNullException("output");
		}
		if (string_0.Length == 0)
		{
			return;
		}
		textWriter_0.Write(Class78.smethod_5(string_0, true));
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x00008033 File Offset: 0x00006233
	public static string smethod_21(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length <= 0)
		{
			return string_0;
		}
		return Class78.smethod_4(string_0);
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x00008054 File Offset: 0x00006254
	public static void smethod_22(string string_0, TextWriter textWriter_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (textWriter_0 == null)
		{
			throw new ArgumentNullException("output");
		}
		if (string_0.Length == 0)
		{
			return;
		}
		textWriter_0.Write(Class78.smethod_4(string_0));
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x00008087 File Offset: 0x00006287
	public static string smethod_23(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length <= 0)
		{
			return string_0;
		}
		return Class78.smethod_5(string_0, false);
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x000080A9 File Offset: 0x000062A9
	public static void smethod_24(string string_0, TextWriter textWriter_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (textWriter_0 == null)
		{
			throw new ArgumentNullException("output");
		}
		if (string_0.Length == 0)
		{
			return;
		}
		textWriter_0.Write(Class78.smethod_5(string_0, false));
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x000080DD File Offset: 0x000062DD
	public static string smethod_25(string string_0)
	{
		return Class78.smethod_27(string_0, Encoding.UTF8);
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0003A5FC File Offset: 0x000387FC
	public static string smethod_26(byte[] byte_0, Encoding encoding_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num <= 0)
		{
			return string.Empty;
		}
		return (encoding_0 ?? Encoding.UTF8).GetString(Class78.smethod_12(byte_0, 0, num));
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x0003A63C File Offset: 0x0003883C
	public static string smethod_27(string string_0, Encoding encoding_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length == 0)
		{
			return string_0;
		}
		byte[] bytes = Encoding.ASCII.GetBytes(string_0);
		return (encoding_0 ?? Encoding.UTF8).GetString(Class78.smethod_12(bytes, 0, bytes.Length));
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x0003A688 File Offset: 0x00038888
	public static string smethod_28(byte[] byte_0, int int_0, int int_1, Encoding encoding_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num == 0)
		{
			if (int_0 != 0)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 != 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			return string.Empty;
		}
		else
		{
			if (int_0 < 0 || int_0 >= num)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 < 0 || int_1 > num - int_0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (int_1 <= 0)
			{
				return string.Empty;
			}
			return (encoding_0 ?? Encoding.UTF8).GetString(Class78.smethod_12(byte_0, int_0, int_1));
		}
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x0003A718 File Offset: 0x00038918
	public static byte[] smethod_29(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num <= 0)
		{
			return byte_0;
		}
		return Class78.smethod_12(byte_0, 0, num);
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0003A748 File Offset: 0x00038948
	public static byte[] smethod_30(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length == 0)
		{
			return new byte[0];
		}
		byte[] bytes = Encoding.ASCII.GetBytes(string_0);
		return Class78.smethod_12(bytes, 0, bytes.Length);
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x0003A788 File Offset: 0x00038988
	public static byte[] smethod_31(byte[] byte_0, int int_0, int int_1)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num == 0)
		{
			if (int_0 != 0)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 != 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			return byte_0;
		}
		else
		{
			if (int_0 < 0 || int_0 >= num)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 < 0 || int_1 > num - int_0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (int_1 <= 0)
			{
				return new byte[0];
			}
			return Class78.smethod_12(byte_0, int_0, int_1);
		}
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0003A804 File Offset: 0x00038A04
	public static string smethod_32(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num <= 0)
		{
			return string.Empty;
		}
		return Encoding.ASCII.GetString(Class78.smethod_14(byte_0, 0, num));
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x000080EA File Offset: 0x000062EA
	public static string smethod_33(string string_0)
	{
		return Class78.smethod_34(string_0, Encoding.UTF8);
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x0003A840 File Offset: 0x00038A40
	public static string smethod_34(string string_0, Encoding encoding_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		int length = string_0.Length;
		if (length == 0)
		{
			return string_0;
		}
		if (encoding_0 == null)
		{
			encoding_0 = Encoding.UTF8;
		}
		byte[] array = new byte[encoding_0.GetMaxByteCount(length)];
		int bytes = encoding_0.GetBytes(string_0, 0, length, array, 0);
		return Encoding.ASCII.GetString(Class78.smethod_14(array, 0, bytes));
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x0003A89C File Offset: 0x00038A9C
	public static string smethod_35(byte[] byte_0, int int_0, int int_1)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num == 0)
		{
			if (int_0 != 0)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 != 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			return string.Empty;
		}
		else
		{
			if (int_0 < 0 || int_0 >= num)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 < 0 || int_1 > num - int_0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (int_1 <= 0)
			{
				return string.Empty;
			}
			return Encoding.ASCII.GetString(Class78.smethod_14(byte_0, int_0, int_1));
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x0003A924 File Offset: 0x00038B24
	public static byte[] smethod_36(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num <= 0)
		{
			return byte_0;
		}
		return Class78.smethod_14(byte_0, 0, num);
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x000080F7 File Offset: 0x000062F7
	public static byte[] smethod_37(string string_0)
	{
		return Class78.smethod_38(string_0, Encoding.UTF8);
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x0003A954 File Offset: 0x00038B54
	public static byte[] smethod_38(string string_0, Encoding encoding_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("s");
		}
		if (string_0.Length == 0)
		{
			return new byte[0];
		}
		byte[] bytes = (encoding_0 ?? Encoding.UTF8).GetBytes(string_0);
		return Class78.smethod_14(bytes, 0, bytes.Length);
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x0003A99C File Offset: 0x00038B9C
	public static byte[] smethod_39(byte[] byte_0, int int_0, int int_1)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("bytes");
		}
		int num = byte_0.Length;
		if (num == 0)
		{
			if (int_0 != 0)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 != 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			return byte_0;
		}
		else
		{
			if (int_0 < 0 || int_0 >= num)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (int_1 < 0 || int_1 > num - int_0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (int_1 <= 0)
			{
				return new byte[0];
			}
			return Class78.smethod_14(byte_0, int_0, int_1);
		}
	}

	// Token: 0x0400041E RID: 1054
	private static Dictionary<string, char> dictionary_0;

	// Token: 0x0400041F RID: 1055
	private static char[] char_0 = "0123456789ABCDEF".ToCharArray();

	// Token: 0x04000420 RID: 1056
	private static object object_0 = new object();
}
