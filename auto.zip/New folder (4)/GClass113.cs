﻿using System;

// Token: 0x02000190 RID: 400
[Serializable]
public abstract class GClass113
{
	// Token: 0x06001249 RID: 4681 RVA: 0x0000E6E6 File Offset: 0x0000C8E6
	public virtual void vmethod_0()
	{
		this._lasterror = null;
	}

	// Token: 0x0600124A RID: 4682 RVA: 0x0000E6EF File Offset: 0x0000C8EF
	public virtual Exception vmethod_1()
	{
		return this._lasterror;
	}

	// Token: 0x0600124B RID: 4683 RVA: 0x0000E6F7 File Offset: 0x0000C8F7
	protected virtual bool vmethod_2(Exception exception_0)
	{
		this._lasterror = exception_0;
		return false;
	}

	// Token: 0x0600124C RID: 4684 RVA: 0x0000E701 File Offset: 0x0000C901
	protected virtual bool vmethod_3(string string_0)
	{
		return this.vmethod_2(new Exception(string_0));
	}

	// Token: 0x04000A2B RID: 2603
	protected Exception _lasterror;
}
