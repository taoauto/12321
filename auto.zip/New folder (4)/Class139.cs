﻿using System;
using System.Windows.Forms;

// Token: 0x02000158 RID: 344
internal class Class139 : Interface3
{
	// Token: 0x0600105B RID: 4187 RVA: 0x0000D536 File Offset: 0x0000B736
	public Control[] imethod_0()
	{
		return new Control[]
		{
			new Proxy()
		};
	}

	// Token: 0x0600105C RID: 4188 RVA: 0x0005B288 File Offset: 0x00059488
	public void imethod_1(Control[] control_0)
	{
		Proxy proxy = new Proxy();
		Class144.bool_0 = proxy.Boolean_0;
		Class144.string_1 = proxy.String_0;
		Class144.int_5 = proxy.Int32_0;
		Class144.bool_1 = proxy.Boolean_1;
		Class144.string_2 = proxy.String_1;
		Class144.string_3 = proxy.String_2;
		Class144.string_4 = proxy.String_3;
	}
}
