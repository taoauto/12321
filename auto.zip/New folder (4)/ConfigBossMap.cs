﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x0200016B RID: 363
public class ConfigBossMap : UserControl
{
	// Token: 0x060011AB RID: 4523 RVA: 0x0000E1B3 File Offset: 0x0000C3B3
	public ConfigBossMap()
	{
		this.InitializeComponent();
	}

	// Token: 0x060011AC RID: 4524 RVA: 0x00063044 File Offset: 0x00061244
	private void ConfigBossMap_Load(object sender, EventArgs e)
	{
		this.class159_0 = Main.class159_0;
		this.label3.Text = this.class159_0.Class432_0.string_7;
		this.checkBox1.Checked = this.class159_0.Boolean_13;
		this.chkVeLacDuong.Checked = Class268.Boolean_18;
		if (this.class159_0 == null)
		{
			base.Dispose();
			return;
		}
		HashSet<string> hashSet = new HashSet<string>();
		this.txtOnlyBossMap.Text = Class415.String_6;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && !hashSet.Contains(@class.String_2))
				{
					hashSet.Add(@class.String_2);
					this.listviewmonter.Items.Add(@class.String_2);
				}
			}
		}
		this.Text = "[" + this.class159_0.Class432_0.String_2 + "] Cài Đặt BossMap trên => " + Main.class159_0.Class432_0.string_7;
		this.int_0 = (int)Main.class159_0.Class432_0.UInt32_29;
		string[] array = Class415.smethod_7(this.class159_0.Class432_0.UInt32_29.ToString()).Split(new char[]
		{
			'-'
		});
		int i = 0;
		while (i < array.Length)
		{
			string text = array[i];
			int num = 0;
			int num2 = 0;
			try
			{
				num = Class426.smethod_43(text.Split(new char[]
				{
					','
				})[0]);
				num2 = Class426.smethod_43(text.Split(new char[]
				{
					','
				})[1]);
				goto IL_23B;
			}
			catch
			{
				goto IL_23B;
			}
			goto IL_1FE;
			IL_230:
			i++;
			continue;
			IL_1FE:
			if (num2 != 0)
			{
				this.lstv.Items.Add(new ListViewItem(num.ToString() + "," + num2.ToString()));
				goto IL_230;
			}
			goto IL_230;
			IL_23B:
			if (num != 0)
			{
				goto IL_1FE;
			}
			goto IL_230;
		}
	}

	// Token: 0x060011AD RID: 4525 RVA: 0x000632BC File Offset: 0x000614BC
	private void btnAdd_Click(object sender, EventArgs e)
	{
		string text = ((int)this.class159_0.Single_3).ToString() + "," + ((int)this.class159_0.Single_4).ToString();
		if (this.lstv.Items.Count > 0 && this.lstv.Items[this.lstv.Items.Count - 1].Text == text)
		{
			return;
		}
		ListViewItem value = new ListViewItem(text);
		this.lstv.Items.Add(value);
	}

	// Token: 0x060011AE RID: 4526 RVA: 0x00063358 File Offset: 0x00061558
	private void btnSave_Click(object sender, EventArgs e)
	{
		string text = string.Empty;
		foreach (object obj in this.lstv.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = text + listViewItem.Text + "-";
		}
		text = text.Trim(new char[]
		{
			'-'
		});
		Class415.smethod_6(this.class159_0.Class432_0.UInt32_29.ToString(), text);
	}

	// Token: 0x060011AF RID: 4527 RVA: 0x0000E1C8 File Offset: 0x0000C3C8
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		while (this.lstv.SelectedItems.Count > 0)
		{
			this.lstv.Items.Remove(this.lstv.SelectedItems[0]);
		}
	}

	// Token: 0x060011B0 RID: 4528 RVA: 0x0000E201 File Offset: 0x0000C401
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		this.class159_0.Boolean_13 = this.checkBox1.Checked;
	}

	// Token: 0x060011B1 RID: 4529 RVA: 0x0000E219 File Offset: 0x0000C419
	private void textBoxEx2_TextChanged(object sender, EventArgs e)
	{
		this.listviewmonter.Search(this.textBoxEx2.Text);
	}

	// Token: 0x060011B2 RID: 4530 RVA: 0x000633FC File Offset: 0x000615FC
	private void listviewmonter_SelectedIndexChanged(object sender, EventArgs e)
	{
		foreach (object obj in this.listviewmonter.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtOnlyBossMap.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtOnlyBossMap.Text = this.txtOnlyBossMap.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtOnlyBossMap.method_1();
	}

	// Token: 0x060011B3 RID: 4531 RVA: 0x0000E232 File Offset: 0x0000C432
	private void txtOnlyBossMap_TextChanged(object sender, EventArgs e)
	{
		Class415.String_6 = this.txtOnlyBossMap.Text;
	}

	// Token: 0x060011B4 RID: 4532 RVA: 0x0000E244 File Offset: 0x0000C444
	private void chkVeLacDuong_CheckedChanged(object sender, EventArgs e)
	{
		Class268.Boolean_18 = this.chkVeLacDuong.Checked;
	}

	// Token: 0x060011B5 RID: 4533 RVA: 0x0000E256 File Offset: 0x0000C456
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060011B6 RID: 4534 RVA: 0x000634FC File Offset: 0x000616FC
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ConfigBossMap));
		this.checkBox1 = new CheckBox();
		this.btnSave = new Button();
		this.btnAdd = new Button();
		this.mnuDelete = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.txtOnlyBossMap = new Class85();
		this.listviewmonter = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.lstv = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.splitContainer1 = new SplitContainer();
		this.panel3 = new Panel();
		this.splitContainer2 = new SplitContainer();
		this.textBoxEx2 = new Class85();
		this.chkVeLacDuong = new CheckBox();
		this.label3 = new Label();
		this.label2 = new Label();
		this.mnuDelete.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.panel3.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		base.SuspendLayout();
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = DockStyle.Bottom;
		this.checkBox1.Location = new Point(0, 5);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Padding = new Padding(10, 0, 0, 0);
		this.checkBox1.Size = new Size(227, 17);
		this.checkBox1.TabIndex = 10;
		this.checkBox1.Text = "Chạy Thử";
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.btnSave.Dock = DockStyle.Bottom;
		this.btnSave.Location = new Point(0, 45);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new Size(227, 23);
		this.btnSave.TabIndex = 9;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += this.btnSave_Click;
		this.btnAdd.Dock = DockStyle.Bottom;
		this.btnAdd.Location = new Point(0, 22);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new Size(227, 23);
		this.btnAdd.TabIndex = 7;
		this.btnAdd.Text = "Thêm Tọa Độ Hiện Tại - Add point";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += this.btnAdd_Click;
		this.mnuDelete.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_0
		});
		this.mnuDelete.Name = "mnuDelete";
		this.mnuDelete.Size = new Size(95, 26);
		this.toolStripMenuItem_0.Name = "xóaToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(94, 22);
		this.toolStripMenuItem_0.Text = "Xóa";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.txtOnlyBossMap.Dock = DockStyle.Fill;
		this.txtOnlyBossMap.Location = new Point(0, 0);
		this.txtOnlyBossMap.Multiline = true;
		this.txtOnlyBossMap.Name = "txtOnlyBossMap";
		this.txtOnlyBossMap.Size = new Size(276, 197);
		this.txtOnlyBossMap.TabIndex = 13;
		this.txtOnlyBossMap.String_0 = "Danh Sách Quái...";
		this.txtOnlyBossMap.Color_0 = Color.Gray;
		this.txtOnlyBossMap.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtOnlyBossMap.Color_1 = Color.LightGray;
		this.txtOnlyBossMap.TextChanged += this.txtOnlyBossMap_TextChanged;
		this.listviewmonter.AllowColumnReorder = true;
		this.listviewmonter.AllowDrop = true;
		this.listviewmonter.AllowReorder = true;
		this.listviewmonter.AllowSort = false;
		this.listviewmonter.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1
		});
		this.listviewmonter.Dock = DockStyle.Fill;
		this.listviewmonter.DoubleClickActivation = false;
		this.listviewmonter.FullRowSelect = true;
		this.listviewmonter.GridLines = true;
		this.listviewmonter.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listviewmonter.hideItems");
		this.listviewmonter.HideSelection = false;
		this.listviewmonter.LineColor = Color.Red;
		this.listviewmonter.Location = new Point(0, 20);
		this.listviewmonter.Name = "listviewmonter";
		this.listviewmonter.Size = new Size(276, 195);
		this.listviewmonter.TabIndex = 11;
		this.listviewmonter.UseCompatibleStateImageBehavior = false;
		this.listviewmonter.View = View.Details;
		this.listviewmonter.SelectedIndexChanged += this.listviewmonter_SelectedIndexChanged;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 218;
		this.lstv.AllowColumnReorder = true;
		this.lstv.AllowDrop = true;
		this.lstv.AllowReorder = true;
		this.lstv.AllowSort = false;
		this.lstv.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lstv.ContextMenuStrip = this.mnuDelete;
		this.lstv.Dock = DockStyle.Fill;
		this.lstv.DoubleClickActivation = false;
		this.lstv.FullRowSelect = true;
		this.lstv.GridLines = true;
		this.lstv.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lstv.hideItems");
		this.lstv.HideSelection = false;
		this.lstv.LineColor = Color.Red;
		this.lstv.Location = new Point(0, 20);
		this.lstv.Name = "lstv";
		this.lstv.Size = new Size(227, 328);
		this.lstv.TabIndex = 6;
		this.lstv.Tag = "Cài Đặt Boss Map";
		this.lstv.UseCompatibleStateImageBehavior = false;
		this.lstv.View = View.Details;
		this.columnHeader_0.Text = "Tọa độ";
		this.columnHeader_0.Width = 179;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.lstv);
		this.splitContainer1.Panel1.Controls.Add(this.label3);
		this.splitContainer1.Panel1.Controls.Add(this.panel3);
		this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
		this.splitContainer1.Size = new Size(507, 416);
		this.splitContainer1.SplitterDistance = 227;
		this.splitContainer1.TabIndex = 15;
		this.panel3.Controls.Add(this.checkBox1);
		this.panel3.Controls.Add(this.btnAdd);
		this.panel3.Controls.Add(this.btnSave);
		this.panel3.Dock = DockStyle.Bottom;
		this.panel3.Location = new Point(0, 348);
		this.panel3.Name = "panel3";
		this.panel3.Size = new Size(227, 68);
		this.panel3.TabIndex = 9;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.Location = new Point(0, 0);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Orientation = Orientation.Horizontal;
		this.splitContainer2.Panel1.Controls.Add(this.chkVeLacDuong);
		this.splitContainer2.Panel1.Controls.Add(this.label2);
		this.splitContainer2.Panel1.Controls.Add(this.txtOnlyBossMap);
		this.splitContainer2.Panel2.Controls.Add(this.listviewmonter);
		this.splitContainer2.Panel2.Controls.Add(this.textBoxEx2);
		this.splitContainer2.Size = new Size(276, 416);
		this.splitContainer2.SplitterDistance = 197;
		this.splitContainer2.TabIndex = 2;
		this.textBoxEx2.Dock = DockStyle.Top;
		this.textBoxEx2.Location = new Point(0, 0);
		this.textBoxEx2.Name = "textBoxEx2";
		this.textBoxEx2.Size = new Size(276, 20);
		this.textBoxEx2.TabIndex = 12;
		this.textBoxEx2.String_0 = "Search..";
		this.textBoxEx2.Color_0 = Color.Gray;
		this.textBoxEx2.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textBoxEx2.Color_1 = Color.LightGray;
		this.textBoxEx2.TextChanged += this.textBoxEx2_TextChanged;
		this.chkVeLacDuong.AutoSize = true;
		this.chkVeLacDuong.Dock = DockStyle.Top;
		this.chkVeLacDuong.Location = new Point(0, 20);
		this.chkVeLacDuong.Name = "chkVeLacDuong";
		this.chkVeLacDuong.Size = new Size(276, 17);
		this.chkVeLacDuong.TabIndex = 13;
		this.chkVeLacDuong.Text = "Hết Boss Tự Về Lạc Dương";
		this.chkVeLacDuong.UseVisualStyleBackColor = true;
		this.chkVeLacDuong.CheckedChanged += this.chkVeLacDuong_CheckedChanged;
		this.label3.Dock = DockStyle.Top;
		this.label3.Location = new Point(0, 0);
		this.label3.Name = "label3";
		this.label3.Size = new Size(227, 20);
		this.label3.TabIndex = 13;
		this.label3.Text = "Bản Đồ";
		this.label3.TextAlign = ContentAlignment.MiddleCenter;
		this.label2.Dock = DockStyle.Top;
		this.label2.Location = new Point(0, 0);
		this.label2.Name = "label2";
		this.label2.Size = new Size(276, 20);
		this.label2.TabIndex = 14;
		this.label2.Text = "Đánh Quái Tại Bản Đồ Này";
		this.label2.TextAlign = ContentAlignment.MiddleCenter;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.White;
		base.Controls.Add(this.splitContainer1);
		base.Name = "ConfigBossMap";
		base.Size = new Size(507, 416);
		base.Load += this.ConfigBossMap_Load;
		this.mnuDelete.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.panel3.ResumeLayout(false);
		this.panel3.PerformLayout();
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel1.PerformLayout();
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.Panel2.PerformLayout();
		this.splitContainer2.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x0400091E RID: 2334
	private int int_0 = -1;

	// Token: 0x0400091F RID: 2335
	private Class159 class159_0;

	// Token: 0x04000920 RID: 2336
	private IContainer icontainer_0;

	// Token: 0x04000921 RID: 2337
	private CheckBox checkBox1;

	// Token: 0x04000922 RID: 2338
	private Button btnSave;

	// Token: 0x04000923 RID: 2339
	private Button btnAdd;

	// Token: 0x04000924 RID: 2340
	private ListViewEx lstv;

	// Token: 0x04000925 RID: 2341
	private ColumnHeader columnHeader_0;

	// Token: 0x04000926 RID: 2342
	private ListViewEx listviewmonter;

	// Token: 0x04000927 RID: 2343
	private ColumnHeader columnHeader_1;

	// Token: 0x04000928 RID: 2344
	private Class85 txtOnlyBossMap;

	// Token: 0x04000929 RID: 2345
	private ContextMenuStrip mnuDelete;

	// Token: 0x0400092A RID: 2346
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400092B RID: 2347
	private SplitContainer splitContainer1;

	// Token: 0x0400092C RID: 2348
	private Panel panel3;

	// Token: 0x0400092D RID: 2349
	private SplitContainer splitContainer2;

	// Token: 0x0400092E RID: 2350
	private Class85 textBoxEx2;

	// Token: 0x0400092F RID: 2351
	private CheckBox chkVeLacDuong;

	// Token: 0x04000930 RID: 2352
	private Label label3;

	// Token: 0x04000931 RID: 2353
	private Label label2;
}
