﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000288 RID: 648
public class GClass126
{
	// Token: 0x0600241E RID: 9246 RVA: 0x0001B8A4 File Offset: 0x00019AA4
	public GClass126(double double_2, double double_3)
	{
		this.Double_0 = double_2;
		this.Double_1 = double_3;
	}

	// Token: 0x1700077A RID: 1914
	// (get) Token: 0x0600241F RID: 9247 RVA: 0x0001B8BA File Offset: 0x00019ABA
	// (set) Token: 0x06002420 RID: 9248 RVA: 0x0001B8C2 File Offset: 0x00019AC2
	public double Double_0 { get; set; }

	// Token: 0x1700077B RID: 1915
	// (get) Token: 0x06002421 RID: 9249 RVA: 0x0001B8CB File Offset: 0x00019ACB
	// (set) Token: 0x06002422 RID: 9250 RVA: 0x0001B8D3 File Offset: 0x00019AD3
	public double Double_1 { get; set; }

	// Token: 0x040017DC RID: 6108
	[CompilerGenerated]
	private double double_0;

	// Token: 0x040017DD RID: 6109
	[CompilerGenerated]
	private double double_1;
}
