﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020002F6 RID: 758
internal partial class ShutDown : Form
{
	// Token: 0x06002B98 RID: 11160 RVA: 0x0001FE1D File Offset: 0x0001E01D
	public ShutDown()
	{
		this.InitializeComponent();
		base.FormBorderStyle = FormBorderStyle.None;
		base.Disposed += this.ShutDown_Disposed;
		base.Show();
	}

	// Token: 0x06002B99 RID: 11161 RVA: 0x0001FE52 File Offset: 0x0001E052
	private void ShutDown_Disposed(object sender, EventArgs e)
	{
		Class407.smethod_7();
	}

	// Token: 0x06002B9A RID: 11162 RVA: 0x00013421 File Offset: 0x00011621
	private void lblClose_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			base.Dispose();
		}
	}

	// Token: 0x06002B9B RID: 11163 RVA: 0x00126160 File Offset: 0x00124360
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.int_0--;
		Class407.smethod_4();
		TimeSpan timeSpan = TimeSpan.FromSeconds((double)this.int_0);
		this.lblExitTime.Text = "Tắt máy sau " + string.Format("{0:0}:{1:00}", timeSpan.Minutes, timeSpan.Seconds);
		if (this.int_0 == 0)
		{
			Process.Start("shutdown", "-s -t 0");
		}
	}

	// Token: 0x06002B9C RID: 11164 RVA: 0x0001FE59 File Offset: 0x0001E059
	private void ShutDown_Load(object sender, EventArgs e)
	{
		Class438.smethod_14(this, Class438.Enum22.TopLeft);
	}

	// Token: 0x06002B9D RID: 11165 RVA: 0x0001FE62 File Offset: 0x0001E062
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001D06 RID: 7430
	private int int_0 = 60;
}
