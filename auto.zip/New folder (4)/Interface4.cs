﻿using System;

// Token: 0x0200014F RID: 335
internal interface Interface4
{
	// Token: 0x0600102D RID: 4141
	void imethod_0(Class130 class130_0);

	// Token: 0x0600102E RID: 4142
	Class141 imethod_1();
}
