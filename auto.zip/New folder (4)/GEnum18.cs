﻿using System;

// Token: 0x0200010A RID: 266
public enum GEnum18
{
	// Token: 0x040006B6 RID: 1718
	None,
	// Token: 0x040006B7 RID: 1719
	Increased,
	// Token: 0x040006B8 RID: 1720
	Decreased
}
