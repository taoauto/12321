﻿using System;

// Token: 0x02000148 RID: 328
internal class EventArgs0 : EventArgs
{
	// Token: 0x0600101B RID: 4123 RVA: 0x0000D3F0 File Offset: 0x0000B5F0
	public EventArgs0(Interface5 interface5_1, string string_1)
	{
		this.string_0 = string_1;
		this.interface5_0 = interface5_1;
	}

	// Token: 0x17000421 RID: 1057
	// (get) Token: 0x0600101C RID: 4124 RVA: 0x0000D406 File Offset: 0x0000B606
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x17000422 RID: 1058
	// (get) Token: 0x0600101D RID: 4125 RVA: 0x0000D40E File Offset: 0x0000B60E
	// (set) Token: 0x0600101E RID: 4126 RVA: 0x0000D416 File Offset: 0x0000B616
	public Interface5 Interface5_0
	{
		get
		{
			return this.interface5_0;
		}
		set
		{
			this.interface5_0 = value;
		}
	}

	// Token: 0x04000848 RID: 2120
	private Interface5 interface5_0;

	// Token: 0x04000849 RID: 2121
	private string string_0;
}
