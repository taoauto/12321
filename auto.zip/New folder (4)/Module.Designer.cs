﻿// Token: 0x020001F7 RID: 503
public partial class Module : global::System.Windows.Forms.Form
{
	// Token: 0x06001A49 RID: 6729 RVA: 0x000C6690 File Offset: 0x000C4890
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.listViewEx1 = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.contextMenuStrip1 = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.refreshToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.contextMenuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.listViewEx1.AllowColumnReorder = true;
		this.listViewEx1.AllowDrop = true;
		this.listViewEx1.AllowReorder = true;
		this.listViewEx1.AllowSort = false;
		this.listViewEx1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewEx1.ContextMenuStrip = this.contextMenuStrip1;
		this.listViewEx1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewEx1.FullRowSelect = true;
		this.listViewEx1.GridLines = true;
		this.listViewEx1.HideSelection = false;
		this.listViewEx1.LineColor = global::System.Drawing.Color.Red;
		this.listViewEx1.Location = new global::System.Drawing.Point(0, 0);
		this.listViewEx1.Name = "listViewEx1";
		this.listViewEx1.Size = new global::System.Drawing.Size(800, 450);
		this.listViewEx1.TabIndex = 0;
		this.listViewEx1.UseCompatibleStateImageBehavior = false;
		this.listViewEx1.View = global::System.Windows.Forms.View.Details;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 460;
		this.contextMenuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.refreshToolStripMenuItem
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new global::System.Drawing.Size(181, 48);
		this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
		this.refreshToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.refreshToolStripMenuItem.Text = "Refresh";
		this.refreshToolStripMenuItem.Click += new global::System.EventHandler(this.refreshToolStripMenuItem_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(800, 450);
		base.Controls.Add(this.listViewEx1);
		base.Name = "Module";
		this.Text = "Module";
		base.Load += new global::System.EventHandler(this.Module_Load);
		this.contextMenuStrip1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04001065 RID: 4197
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04001066 RID: 4198
	private global::_i.ListViewEx listViewEx1;

	// Token: 0x04001067 RID: 4199
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x04001068 RID: 4200
	private global::System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

	// Token: 0x04001069 RID: 4201
	private global::System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
}
