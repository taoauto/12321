﻿using System;

// Token: 0x0200029E RID: 670
internal class Class358
{
	// Token: 0x17000794 RID: 1940
	// (get) Token: 0x060024AB RID: 9387 RVA: 0x0001BCBB File Offset: 0x00019EBB
	public static string String_0
	{
		get
		{
			return "Thánh Thú Sơn";
		}
	}

	// Token: 0x0400188E RID: 6286
	public static int int_0 = 201;

	// Token: 0x0400188F RID: 6287
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 2173U,
		Int32_0 = 137,
		Int32_1 = 107,
		Int32_2 = Class358.int_0,
		String_2 = "Vân Phiêu Phiêu"
	};
}
