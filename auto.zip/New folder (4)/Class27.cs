﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Text;

// Token: 0x02000049 RID: 73
internal class Class27 : Class25
{
	// Token: 0x0600030F RID: 783 RVA: 0x00004E82 File Offset: 0x00003082
	private Class27(string string_3, string string_4, Version version_1, NameValueCollection nameValueCollection_1) : base(version_1, nameValueCollection_1)
	{
		this.string_1 = string_3;
		this.string_2 = string_4;
	}

	// Token: 0x06000310 RID: 784 RVA: 0x00004E9B File Offset: 0x0000309B
	internal Class27(GEnum9 genum9_0) : this(genum9_0, genum9_0.smethod_82())
	{
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0002A1B0 File Offset: 0x000283B0
	internal Class27(GEnum9 genum9_0, string string_3)
	{
		int num = (int)genum9_0;
		this..ctor(num.ToString(), string_3, GClass42.version_1, new NameValueCollection());
		base.NameValueCollection_0["Server"] = "websocket-sharp/1.0";
	}

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x06000312 RID: 786 RVA: 0x00004EAA File Offset: 0x000030AA
	public GClass34 GClass34_0
	{
		get
		{
			return base.NameValueCollection_0.smethod_30(true);
		}
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x06000313 RID: 787 RVA: 0x0002A1EC File Offset: 0x000283EC
	public bool Boolean_0
	{
		get
		{
			return base.NameValueCollection_0.smethod_16("Connection", "close", StringComparison.OrdinalIgnoreCase);
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x06000314 RID: 788 RVA: 0x00004EB8 File Offset: 0x000030B8
	public bool Boolean_1
	{
		get
		{
			return this.string_1 == "407";
		}
	}

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x06000315 RID: 789 RVA: 0x00004ECA File Offset: 0x000030CA
	public bool Boolean_2
	{
		get
		{
			return this.string_1 == "301" || this.string_1 == "302";
		}
	}

	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x06000316 RID: 790 RVA: 0x00004EF0 File Offset: 0x000030F0
	public bool Boolean_3
	{
		get
		{
			return this.string_1 == "401";
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x06000317 RID: 791 RVA: 0x00004F02 File Offset: 0x00003102
	public bool Boolean_4
	{
		get
		{
			return base.Version_0 > GClass42.version_0 && this.string_1 == "101" && base.NameValueCollection_0.smethod_77("websocket");
		}
	}

	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x06000318 RID: 792 RVA: 0x00004F3A File Offset: 0x0000313A
	public string String_1
	{
		get
		{
			return this.string_2;
		}
	}

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x06000319 RID: 793 RVA: 0x00004F42 File Offset: 0x00003142
	public string String_2
	{
		get
		{
			return this.string_1;
		}
	}

	// Token: 0x0600031A RID: 794 RVA: 0x00004F4A File Offset: 0x0000314A
	internal static Class27 smethod_3(GEnum9 genum9_0)
	{
		Class27 @class = new Class27(genum9_0);
		@class.NameValueCollection_0["Connection"] = "close";
		return @class;
	}

	// Token: 0x0600031B RID: 795 RVA: 0x00004F67 File Offset: 0x00003167
	internal static Class27 smethod_4(string string_3)
	{
		Class27 @class = new Class27(GEnum9.Unauthorized);
		@class.NameValueCollection_0["WWW-Authenticate"] = string_3;
		return @class;
	}

	// Token: 0x0600031C RID: 796 RVA: 0x00004F84 File Offset: 0x00003184
	internal static Class27 smethod_5()
	{
		Class27 @class = new Class27(GEnum9.SwitchingProtocols);
		NameValueCollection nameValueCollection_ = @class.NameValueCollection_0;
		nameValueCollection_["Upgrade"] = "websocket";
		nameValueCollection_["Connection"] = "Upgrade";
		return @class;
	}

	// Token: 0x0600031D RID: 797 RVA: 0x0002A210 File Offset: 0x00028410
	internal static Class27 smethod_6(string[] string_3)
	{
		string[] array = string_3[0].Split(new char[]
		{
			' '
		}, 3);
		if (array.Length != 3)
		{
			throw new ArgumentException("Invalid status line: " + string_3[0]);
		}
		GClass45 gclass = new GClass45();
		for (int i = 1; i < string_3.Length; i++)
		{
			gclass.method_5(string_3[i], true);
		}
		return new Class27(array[1], array[2], new Version(array[0].Substring(5)), gclass);
	}

	// Token: 0x0600031E RID: 798 RVA: 0x00004FB2 File Offset: 0x000031B2
	internal static Class27 smethod_7(Stream stream_0, int int_1)
	{
		return Class25.smethod_2<Class27>(stream_0, new Func<string[], Class27>(Class27.smethod_6), int_1);
	}

	// Token: 0x0600031F RID: 799 RVA: 0x0002A284 File Offset: 0x00028484
	public void method_1(GClass34 gclass34_0)
	{
		if (gclass34_0 != null && gclass34_0.Count != 0)
		{
			NameValueCollection nameValueCollection_ = base.NameValueCollection_0;
			foreach (GClass33 gclass in gclass34_0.IEnumerable_0)
			{
				nameValueCollection_.Add("Set-Cookie", gclass.method_6());
			}
			return;
		}
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0002A2F0 File Offset: 0x000284F0
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("HTTP/{0} {1} {2}{3}", new object[]
		{
			base.Version_0,
			this.string_1,
			this.string_2,
			"\r\n"
		});
		NameValueCollection nameValueCollection_ = base.NameValueCollection_0;
		foreach (string text in nameValueCollection_.AllKeys)
		{
			stringBuilder.AppendFormat("{0}: {1}{2}", text, nameValueCollection_[text], "\r\n");
		}
		stringBuilder.Append("\r\n");
		string string_ = base.String_0;
		if (string_.Length > 0)
		{
			stringBuilder.Append(string_);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x040001C0 RID: 448
	private string string_1;

	// Token: 0x040001C1 RID: 449
	private string string_2;
}
