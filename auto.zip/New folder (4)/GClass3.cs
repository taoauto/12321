﻿using System;
using System.Collections.Generic;

// Token: 0x02000008 RID: 8
public class GClass3 : List<KeyValuePair<string, string>>
{
	// Token: 0x17000001 RID: 1
	public object this[string string_0]
	{
		set
		{
			if (string_0 == null)
			{
				throw new ArgumentNullException("paramName");
			}
			if (string_0.Length == 0)
			{
				throw Class13.smethod_0("paramName");
			}
			string value2 = (value == null) ? string.Empty : value.ToString();
			base.Add(new KeyValuePair<string, string>(string_0, value2));
		}
	}
}
