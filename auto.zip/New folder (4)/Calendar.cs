﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using _i;

// Token: 0x02000209 RID: 521
internal class Calendar : UserControl
{
	// Token: 0x17000676 RID: 1654
	// (get) Token: 0x06001AF6 RID: 6902 RVA: 0x000138E9 File Offset: 0x00011AE9
	// (set) Token: 0x06001AF7 RID: 6903 RVA: 0x000138F1 File Offset: 0x00011AF1
	public string String_0 { get; set; }

	// Token: 0x06001AF8 RID: 6904 RVA: 0x000CBE88 File Offset: 0x000CA088
	public Calendar()
	{
		this.InitializeComponent();
		this.Text = "Đặt Lịch Phụ Bản - All";
		foreach (string text in Class159.Class220_0.method_0("Calender", "All").Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Split(new char[]
			{
				'|'
			}).Length > 1)
			{
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = text.Split(new char[]
				{
					'|'
				})[0].Trim();
				listViewItem.SubItems.Add(text.Split(new char[]
				{
					'|'
				})[1].Trim());
				this.listViewCalendar.Items.Add(listViewItem);
			}
		}
		this.cboMap.SelectedIndex = 0;
	}

	// Token: 0x06001AF9 RID: 6905 RVA: 0x000CBF6C File Offset: 0x000CA16C
	private void btnAdd_Click(object sender, EventArgs e)
	{
		if (this.cboNote.Text == "")
		{
			return;
		}
		string text = this.cboNote.Text;
		if (Class426.smethod_57(this.cboNote.Text).Contains("actac") && this.cboMap.Text.Contains("Ác Tặc"))
		{
			text = text + " [" + Regex.Replace(this.cboMap.Text, ".* - ", "") + "]";
		}
		if (Class426.smethod_57(this.cboNote.Text).Contains("tangkinhcac") && this.cboMap.Text.Contains("Tàng Kinh Các"))
		{
			text = text + " [" + Regex.Replace(this.cboMap.Text, ".* - ", "") + "]";
		}
		ListViewItem listViewItem = new ListViewItem();
		listViewItem.Text = string.Concat(new string[]
		{
			this.method_1(this.nudHour.Value),
			":",
			this.method_1(this.nudMinute.Value),
			" -> ",
			this.method_1(this.nudHourEnd.Value),
			":",
			this.method_1(this.nudMinuteEnd.Value)
		});
		listViewItem.SubItems.Add(text);
		this.listViewCalendar.Items.Add(listViewItem);
		this.method_0();
	}

	// Token: 0x06001AFA RID: 6906 RVA: 0x000CC100 File Offset: 0x000CA300
	public void method_0()
	{
		string text = (this.cboPlayer.SelectedItem as Class339).String_0;
		string text2 = "";
		foreach (object obj in this.listViewCalendar.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text2 = string.Concat(new string[]
			{
				text2,
				listViewItem.Text,
				" | ",
				listViewItem.SubItems[1].Text,
				"\r\n"
			});
		}
		if (this.Text == "Đặt Lịch Phụ Bản - All")
		{
			Class159.Class220_0.method_1("Calender", "All", text2);
			return;
		}
		Class159.Class220_0.method_1("Calender", Class426.smethod_51(this.Text.Replace("Đặt Lịch Phụ Bản - ", "")), text2);
	}

	// Token: 0x06001AFB RID: 6907 RVA: 0x000138FA File Offset: 0x00011AFA
	public string method_1(decimal decimal_0)
	{
		if (decimal_0 < 10m)
		{
			return "0" + decimal_0.ToString();
		}
		return decimal_0.ToString();
	}

	// Token: 0x06001AFC RID: 6908 RVA: 0x00013924 File Offset: 0x00011B24
	private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
	{
		while (this.listViewCalendar.SelectedItems.Count > 0)
		{
			this.listViewCalendar.SelectedItems[0].Remove();
		}
		this.method_0();
	}

	// Token: 0x06001AFD RID: 6909 RVA: 0x000CC204 File Offset: 0x000CA404
	private void Calendar_Load(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Class339("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(this.method_2));
		this.cboPlayer.SelectedIndex = 0;
	}

	// Token: 0x06001AFE RID: 6910 RVA: 0x000CC270 File Offset: 0x000CA470
	private void menuCopy_Click(object sender, EventArgs e)
	{
		string text = "";
		foreach (object obj in this.listViewCalendar.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = string.Concat(new string[]
			{
				text,
				listViewItem.Text,
				" | ",
				listViewItem.SubItems[1].Text,
				"\r\n"
			});
		}
		Calendar.string_1 = text;
		try
		{
			Clipboard.SetText(text);
		}
		catch
		{
		}
	}

	// Token: 0x06001AFF RID: 6911 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuDelete_Opening(object sender, CancelEventArgs e)
	{
	}

	// Token: 0x06001B00 RID: 6912 RVA: 0x000CC328 File Offset: 0x000CA528
	private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
	{
		string text = Calendar.string_1;
		try
		{
			if (text == string.Empty)
			{
				text = Clipboard.GetText();
			}
		}
		catch
		{
		}
		foreach (string text2 in text.Split(new char[]
		{
			'\n'
		}))
		{
			if (text2.Split(new char[]
			{
				'|'
			}).Length > 1)
			{
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = text2.Split(new char[]
				{
					'|'
				})[0].Trim();
				listViewItem.SubItems.Add(text2.Split(new char[]
				{
					'|'
				})[1].Trim());
				this.listViewCalendar.Items.Add(listViewItem);
			}
		}
		this.method_0();
	}

	// Token: 0x06001B01 RID: 6913 RVA: 0x00002E18 File Offset: 0x00001018
	private void cboMap_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001B02 RID: 6914 RVA: 0x000CC404 File Offset: 0x000CA604
	private void btnAutoAd_Click(object sender, EventArgs e)
	{
		foreach (string text in this.string_2.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Split(new char[]
			{
				'|'
			}).Length > 1)
			{
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = text.Split(new char[]
				{
					'|'
				})[0].Trim();
				listViewItem.SubItems.Add(text.Split(new char[]
				{
					'|'
				})[1].Trim());
				this.listViewCalendar.Items.Add(listViewItem);
			}
		}
		this.method_0();
	}

	// Token: 0x06001B03 RID: 6915 RVA: 0x000CC4B0 File Offset: 0x000CA6B0
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.listViewCalendar.Items.Clear();
		string text = (this.cboPlayer.SelectedItem as Class339).String_0;
		string text2 = "";
		if (text == "0000FFFF")
		{
			this.Text = "Đặt Lịch Phụ Bản - All";
			text2 = Class159.Class220_0.method_0("Calender", "All");
		}
		else
		{
			foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
			{
				if (keyValuePair.Value.Class432_0.String_1 == text)
				{
					Class159 value = keyValuePair.Value;
					this.Text = "Đặt Lịch Phụ Bản - " + value.Class432_0.String_2;
					text2 = Class159.Class220_0.method_0("Calender", value.Class432_0.String_0);
				}
			}
		}
		foreach (string text3 in text2.Split(new char[]
		{
			'\n'
		}))
		{
			if (text3.Split(new char[]
			{
				'|'
			}).Length > 1)
			{
				ListViewItem listViewItem = new ListViewItem
				{
					Text = text3.Split(new char[]
					{
						'|'
					})[0].Trim()
				};
				listViewItem.SubItems.Add(text3.Split(new char[]
				{
					'|'
				})[1].Trim());
				this.listViewCalendar.Items.Add(listViewItem);
			}
		}
		this.cboMap.SelectedIndex = 0;
	}

	// Token: 0x06001B04 RID: 6916 RVA: 0x00013958 File Offset: 0x00011B58
	private void listViewCalendar_DragDrop(object sender, DragEventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001B05 RID: 6917 RVA: 0x00013960 File Offset: 0x00011B60
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001B06 RID: 6918 RVA: 0x000CC670 File Offset: 0x000CA870
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Calendar));
		this.menuDelete = new ContextMenuStrip(this.icontainer_0);
		this.menuCopy = new ToolStripMenuItem();
		this.pasteToolStripMenuItem = new ToolStripMenuItem();
		this.deleteToolStripMenuItem = new ToolStripMenuItem();
		this.cboNote = new ComboBox();
		this.label_0 = new Label();
		this.nudMinute = new NumericUpDown();
		this.nudHour = new NumericUpDown();
		this.label9 = new Label();
		this.label7 = new Label();
		this.nudMinuteEnd = new NumericUpDown();
		this.nudHourEnd = new NumericUpDown();
		this.label1 = new Label();
		this.label2 = new Label();
		this.btnAdd = new Button();
		this.cboMap = new ComboBox();
		this.btnAutoAd = new Button();
		this.listViewCalendar = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.cboPlayer = new ComboBox();
		this.panel1 = new Panel();
		this.menuDelete.SuspendLayout();
		((ISupportInitialize)this.nudMinute).BeginInit();
		((ISupportInitialize)this.nudHour).BeginInit();
		((ISupportInitialize)this.nudMinuteEnd).BeginInit();
		((ISupportInitialize)this.nudHourEnd).BeginInit();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.menuDelete.Items.AddRange(new ToolStripItem[]
		{
			this.menuCopy,
			this.pasteToolStripMenuItem,
			this.deleteToolStripMenuItem
		});
		this.menuDelete.Name = "menuDelete";
		this.menuDelete.Size = new Size(128, 70);
		this.menuDelete.Opening += this.menuDelete_Opening;
		this.menuCopy.Name = "menuCopy";
		this.menuCopy.Size = new Size(127, 22);
		this.menuCopy.Text = "Copy [All]";
		this.menuCopy.Click += this.menuCopy_Click;
		this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
		this.pasteToolStripMenuItem.Size = new Size(127, 22);
		this.pasteToolStripMenuItem.Text = "Paste";
		this.pasteToolStripMenuItem.Click += this.pasteToolStripMenuItem_Click;
		this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
		this.deleteToolStripMenuItem.Size = new Size(127, 22);
		this.deleteToolStripMenuItem.Text = "Delete";
		this.deleteToolStripMenuItem.Click += this.deleteToolStripMenuItem_Click;
		this.cboNote.Dock = DockStyle.Top;
		this.cboNote.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboNote.FormattingEnabled = true;
		this.cboNote.Items.AddRange(new object[]
		{
			"Ác Tặc [Key]",
			"Ác Bá [Key]",
			"Tàng Kinh Các [Key]",
			"Dã Trư [Key]",
			"Phụng Hoàng Lăng Mộ [Key]",
			"Kỳ Cuộc [Key]",
			"Lâu Lan Tầm Bảo [Key]",
			"Phiêu Miễu Phong [Key]",
			"Huyết Chiến Phiêu Miễu Phong [Key]",
			"Thiên Giáng Kỳ Thú [Key]",
			"Q123 Tô Châu [Key]",
			"Q123 Lâu Lan [Key]",
			"Yến Tử Ô [Key]",
			"Tứ Tuyệt Trang [Key]",
			"Tụ Bảo Bồn",
			"Luyện Kim",
			"Luyện Kim Nhanh",
			"Phù Về Thành",
			"Nhiệm Vụ Hàng Ngày",
			"Nhiệm Vụ Sư Môn",
			"Thủ Bị [Chiến Minh]",
			"Bán Đồ + Cất Đồ + Trị Liệu",
			"Thiếu Thất Sơn",
			"Sát Tinh",
			"Nhận Bóng",
			"Móng Heo",
			"Tam Thần Huyễn Cảnh",
			"Vương Lăng",
			"Lên Bãi Train",
			"Dùng Thổ Linh Châu",
			"Reset Time",
			"Nhận Kinh Nghiệm Lưu Trữ",
			"Phúc Địa",
			"Phúc Địa Khó",
			"Phân Giải Trang Bị Pet",
			"Reset Giờ Toàn Bộ Người Chơi",
			"Thoát Game",
			"Mã Tặc",
			"Trừng Ác",
			"Thần Khí 9 Sao",
			"Đổi Huyễn Sắc Câu Thiên Thái",
			"Trang Sức Cửu Lê",
			"Đến Kim Lăng",
			"Binh Thánh",
			"Binh Thánh Khó",
			"Nhận Phỉ Thúy"
		});
		this.cboNote.Location = new Point(0, 0);
		this.cboNote.Name = "cboNote";
		this.cboNote.Size = new Size(358, 21);
		this.cboNote.TabIndex = 1;
		this.label_0.AutoSize = true;
		this.label_0.Location = new Point(11, 8);
		this.label_0.Name = "Từ";
		this.label_0.Size = new Size(20, 13);
		this.label_0.TabIndex = 2;
		this.label_0.Text = "Từ";
		this.nudMinute.Location = new Point(108, 6);
		NumericUpDown numericUpDown = this.nudMinute;
		int[] array = new int[4];
		array[0] = 59;
		numericUpDown.Maximum = new decimal(array);
		this.nudMinute.Name = "nudMinute";
		this.nudMinute.Size = new Size(38, 20);
		this.nudMinute.TabIndex = 213;
		this.nudHour.Location = new Point(37, 6);
		NumericUpDown numericUpDown2 = this.nudHour;
		int[] array2 = new int[4];
		array2[0] = 23;
		numericUpDown2.Maximum = new decimal(array2);
		this.nudHour.Name = "nudHour";
		this.nudHour.Size = new Size(38, 20);
		this.nudHour.TabIndex = 211;
		NumericUpDown numericUpDown3 = this.nudHour;
		int[] array3 = new int[4];
		array3[0] = 1;
		numericUpDown3.Value = new decimal(array3);
		this.label9.AutoSize = true;
		this.label9.Location = new Point(81, 8);
		this.label9.Name = "label9";
		this.label9.Size = new Size(21, 13);
		this.label9.TabIndex = 212;
		this.label9.Text = "giờ";
		this.label7.AutoSize = true;
		this.label7.Location = new Point(152, 8);
		this.label7.Name = "label7";
		this.label7.Size = new Size(40, 13);
		this.label7.TabIndex = 214;
		this.label7.Text = "phút ->";
		this.nudMinuteEnd.Location = new Point(269, 6);
		NumericUpDown numericUpDown4 = this.nudMinuteEnd;
		int[] array4 = new int[4];
		array4[0] = 59;
		numericUpDown4.Maximum = new decimal(array4);
		this.nudMinuteEnd.Name = "nudMinuteEnd";
		this.nudMinuteEnd.Size = new Size(38, 20);
		this.nudMinuteEnd.TabIndex = 217;
		this.nudHourEnd.Location = new Point(198, 6);
		NumericUpDown numericUpDown5 = this.nudHourEnd;
		int[] array5 = new int[4];
		array5[0] = 23;
		numericUpDown5.Maximum = new decimal(array5);
		this.nudHourEnd.Name = "nudHourEnd";
		this.nudHourEnd.Size = new Size(38, 20);
		this.nudHourEnd.TabIndex = 215;
		NumericUpDown numericUpDown6 = this.nudHourEnd;
		int[] array6 = new int[4];
		array6[0] = 1;
		numericUpDown6.Value = new decimal(array6);
		this.label1.AutoSize = true;
		this.label1.Location = new Point(242, 8);
		this.label1.Name = "label1";
		this.label1.Size = new Size(21, 13);
		this.label1.TabIndex = 216;
		this.label1.Text = "giờ";
		this.label2.AutoSize = true;
		this.label2.Location = new Point(313, 8);
		this.label2.Name = "label2";
		this.label2.Size = new Size(28, 13);
		this.label2.TabIndex = 218;
		this.label2.Text = "phút";
		this.btnAdd.Dock = DockStyle.Top;
		this.btnAdd.Location = new Point(0, 74);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new Size(358, 23);
		this.btnAdd.TabIndex = 219;
		this.btnAdd.Text = "Thêm";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += this.btnAdd_Click;
		this.cboMap.Dock = DockStyle.Top;
		this.cboMap.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboMap.FormattingEnabled = true;
		this.cboMap.Items.AddRange(new object[]
		{
			"Bản đồ [Tự động]",
			"[Ác Tặc] - Vô Lượng Sơn",
			"[Ác Tặc] - Kính Hồ",
			"[Ác Tặc] - Kiếm Các",
			"[Ác Tặc] - Thái Hồ",
			"[Ác Tặc] - Tung Sơn",
			"[Ác Tặc] | - Đôn Hoàng",
			"[Tàng Kinh Các] - Tây Hồ",
			"[Tàng Kinh Các] - Nhĩ Hải",
			"[Tàng Kinh Các] - Nhạn Nam"
		});
		this.cboMap.Location = new Point(0, 53);
		this.cboMap.Name = "cboMap";
		this.cboMap.Size = new Size(358, 21);
		this.cboMap.TabIndex = 220;
		this.cboMap.SelectedIndexChanged += this.cboMap_SelectedIndexChanged;
		this.btnAutoAd.Dock = DockStyle.Bottom;
		this.btnAutoAd.Location = new Point(0, 483);
		this.btnAutoAd.Name = "btnAutoAd";
		this.btnAutoAd.Size = new Size(358, 23);
		this.btnAutoAd.TabIndex = 221;
		this.btnAutoAd.Text = "Thêm tự động";
		this.btnAutoAd.UseVisualStyleBackColor = true;
		this.btnAutoAd.Click += this.btnAutoAd_Click;
		this.listViewCalendar.AllowColumnReorder = true;
		this.listViewCalendar.AllowDrop = true;
		this.listViewCalendar.AllowReorder = true;
		this.listViewCalendar.AllowSort = true;
		this.listViewCalendar.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.listViewCalendar.ContextMenuStrip = this.menuDelete;
		this.listViewCalendar.Dock = DockStyle.Fill;
		this.listViewCalendar.DoubleClickActivation = false;
		this.listViewCalendar.FullRowSelect = true;
		this.listViewCalendar.GridLines = true;
		this.listViewCalendar.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewCalendar.hideItems");
		this.listViewCalendar.HideSelection = false;
		this.listViewCalendar.LineColor = Color.Red;
		this.listViewCalendar.Location = new Point(0, 97);
		this.listViewCalendar.Name = "listViewCalendar";
		this.listViewCalendar.Size = new Size(358, 365);
		this.listViewCalendar.TabIndex = 0;
		this.listViewCalendar.UseCompatibleStateImageBehavior = false;
		this.listViewCalendar.View = View.Details;
		this.listViewCalendar.DragDrop += this.listViewCalendar_DragDrop;
		this.columnHeader_0.Text = "Thời Gian";
		this.columnHeader_0.Width = 106;
		this.columnHeader_1.Text = "Mô Tả";
		this.columnHeader_1.Width = 203;
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Items.AddRange(new object[]
		{
			"Thiết Lập Dành Cho Tất Cả"
		});
		this.cboPlayer.Location = new Point(0, 462);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(358, 21);
		this.cboPlayer.TabIndex = 237;
		this.cboPlayer.SelectedIndexChanged += this.cboPlayer_SelectedIndexChanged;
		this.panel1.Controls.Add(this.label_0);
		this.panel1.Controls.Add(this.label7);
		this.panel1.Controls.Add(this.label9);
		this.panel1.Controls.Add(this.nudHour);
		this.panel1.Controls.Add(this.nudMinute);
		this.panel1.Controls.Add(this.label2);
		this.panel1.Controls.Add(this.nudMinuteEnd);
		this.panel1.Controls.Add(this.label1);
		this.panel1.Controls.Add(this.nudHourEnd);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(0, 21);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(358, 32);
		this.panel1.TabIndex = 238;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(358, 506);
		base.Controls.Add(this.listViewCalendar);
		base.Controls.Add(this.cboPlayer);
		base.Controls.Add(this.btnAutoAd);
		base.Controls.Add(this.btnAdd);
		base.Controls.Add(this.cboMap);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.cboNote);
		base.Name = "Calendar";
		base.Tag = "Đặt Lịch";
		this.Text = "Đặt Lịch Phụ Bản";
		base.Load += this.Calendar_Load;
		this.menuDelete.ResumeLayout(false);
		((ISupportInitialize)this.nudMinute).EndInit();
		((ISupportInitialize)this.nudHour).EndInit();
		((ISupportInitialize)this.nudMinuteEnd).EndInit();
		((ISupportInitialize)this.nudHourEnd).EndInit();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x06001B08 RID: 6920 RVA: 0x00013991 File Offset: 0x00011B91
	[CompilerGenerated]
	private void method_2(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Class339(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x040010EB RID: 4331
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040010EC RID: 4332
	public static bool bool_0 = false;

	// Token: 0x040010ED RID: 4333
	public static string string_1 = string.Empty;

	// Token: 0x040010EE RID: 4334
	private string string_2 = "01:59 -> 03:00 | Ác Tặc [Key]\r\n04:01 -> 05:00 | Ác Bá[Key]\r\n10:01 -> 10:40 | Ác Bá[Key]\r\n10:40 -> 11:15 | Tàng Kinh Các[Key]\r\n11:29 -> 11:50 | Lâu Lan Tầm Bảo[Key]\r\n12:01 -> 13:00 | Ác Bá[Key]\r\n13:00 -> 14:00 | Ác Tặc[Key]\r\n14:00 -> 14:20 | Kỳ Cuộc[Key]\r\n14:59 -> 16:00 | Ác Tặc[Key]\r\n16:01 -> 16:25 | Ác Bá[Key]\r\n16:25 -> 17:00 | Tàng Kinh Các[Key]\r\n17:00 -> 18:00 | Ác Tặc[Key]\r\n18:59 -> 20:00 | Ác Tặc[Key]\r\n20:01 -> 21:00 | Ác Bá[Key]\r\n21:00 -> 21:25 | Ác Tặc[Key]\r\n21:25 -> 22:00 | Tàng Kinh Các[Key]\r\n22:01 -> 23:00 | Ác Bá[Key]\r\n22:55 -> 23:30 | Tàng Kinh Các[Key]\r\n23:30 -> 23:45 | Dã Trư[Key]\r\n00:01 -> 01:00 | Ác Bá[Key]";

	// Token: 0x040010EF RID: 4335
	private IContainer icontainer_0;

	// Token: 0x040010F0 RID: 4336
	private ListViewEx listViewCalendar;

	// Token: 0x040010F1 RID: 4337
	private ComboBox cboNote;

	// Token: 0x040010F2 RID: 4338
	private Label label_0;

	// Token: 0x040010F3 RID: 4339
	private NumericUpDown nudMinute;

	// Token: 0x040010F4 RID: 4340
	private NumericUpDown nudHour;

	// Token: 0x040010F5 RID: 4341
	private Label label9;

	// Token: 0x040010F6 RID: 4342
	private Label label7;

	// Token: 0x040010F7 RID: 4343
	private NumericUpDown nudMinuteEnd;

	// Token: 0x040010F8 RID: 4344
	private NumericUpDown nudHourEnd;

	// Token: 0x040010F9 RID: 4345
	private Label label1;

	// Token: 0x040010FA RID: 4346
	private Label label2;

	// Token: 0x040010FB RID: 4347
	private Button btnAdd;

	// Token: 0x040010FC RID: 4348
	private ColumnHeader columnHeader_0;

	// Token: 0x040010FD RID: 4349
	private ColumnHeader columnHeader_1;

	// Token: 0x040010FE RID: 4350
	private ContextMenuStrip menuDelete;

	// Token: 0x040010FF RID: 4351
	private ToolStripMenuItem deleteToolStripMenuItem;

	// Token: 0x04001100 RID: 4352
	private ToolStripMenuItem menuCopy;

	// Token: 0x04001101 RID: 4353
	private ToolStripMenuItem pasteToolStripMenuItem;

	// Token: 0x04001102 RID: 4354
	private ComboBox cboMap;

	// Token: 0x04001103 RID: 4355
	private Button btnAutoAd;

	// Token: 0x04001104 RID: 4356
	private ComboBox cboPlayer;

	// Token: 0x04001105 RID: 4357
	private Panel panel1;
}
