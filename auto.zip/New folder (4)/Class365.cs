﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020002A7 RID: 679
internal class Class365
{
	// Token: 0x170007A8 RID: 1960
	// (get) Token: 0x060024FB RID: 9467 RVA: 0x0001BE6E File Offset: 0x0001A06E
	// (set) Token: 0x060024FC RID: 9468 RVA: 0x0001BE75 File Offset: 0x0001A075
	public static int Int32_0 { get; set; } = 580;

	// Token: 0x170007A9 RID: 1961
	// (get) Token: 0x060024FD RID: 9469 RVA: 0x0001BE7D File Offset: 0x0001A07D
	// (set) Token: 0x060024FE RID: 9470 RVA: 0x0001BE84 File Offset: 0x0001A084
	public static int Int32_1 { get; set; } = 0;

	// Token: 0x170007AA RID: 1962
	// (get) Token: 0x060024FF RID: 9471 RVA: 0x0001BE8C File Offset: 0x0001A08C
	// (set) Token: 0x06002500 RID: 9472 RVA: 0x0001BE93 File Offset: 0x0001A093
	public static int Int32_2 { get; set; } = 1;

	// Token: 0x170007AB RID: 1963
	// (get) Token: 0x06002501 RID: 9473 RVA: 0x0001BE9B File Offset: 0x0001A09B
	// (set) Token: 0x06002502 RID: 9474 RVA: 0x0001BEA2 File Offset: 0x0001A0A2
	public static int Int32_3 { get; set; } = 2;

	// Token: 0x170007AC RID: 1964
	// (get) Token: 0x06002503 RID: 9475 RVA: 0x0001BEAA File Offset: 0x0001A0AA
	// (set) Token: 0x06002504 RID: 9476 RVA: 0x0001BEB1 File Offset: 0x0001A0B1
	public static int Int32_4 { get; set; } = 194;

	// Token: 0x170007AD RID: 1965
	// (get) Token: 0x06002505 RID: 9477 RVA: 0x0001BEB9 File Offset: 0x0001A0B9
	// (set) Token: 0x06002506 RID: 9478 RVA: 0x0001BEC0 File Offset: 0x0001A0C0
	public static int Int32_5 { get; set; } = 77;

	// Token: 0x170007AE RID: 1966
	// (get) Token: 0x06002507 RID: 9479 RVA: 0x0001BEC8 File Offset: 0x0001A0C8
	// (set) Token: 0x06002508 RID: 9480 RVA: 0x0001BECF File Offset: 0x0001A0CF
	public static int Int32_6 { get; set; } = 3;

	// Token: 0x170007AF RID: 1967
	// (get) Token: 0x06002509 RID: 9481 RVA: 0x0001BED7 File Offset: 0x0001A0D7
	// (set) Token: 0x0600250A RID: 9482 RVA: 0x0001BEDE File Offset: 0x0001A0DE
	public static int Int32_7 { get; set; } = 4;

	// Token: 0x170007B0 RID: 1968
	// (get) Token: 0x0600250B RID: 9483 RVA: 0x0001BEE6 File Offset: 0x0001A0E6
	// (set) Token: 0x0600250C RID: 9484 RVA: 0x0001BEED File Offset: 0x0001A0ED
	public static int Int32_8 { get; set; } = 5;

	// Token: 0x170007B1 RID: 1969
	// (get) Token: 0x0600250D RID: 9485 RVA: 0x0001BEF5 File Offset: 0x0001A0F5
	// (set) Token: 0x0600250E RID: 9486 RVA: 0x0001BEFC File Offset: 0x0001A0FC
	public static int Int32_9 { get; set; } = 6;

	// Token: 0x170007B2 RID: 1970
	// (get) Token: 0x0600250F RID: 9487 RVA: 0x0001BF04 File Offset: 0x0001A104
	// (set) Token: 0x06002510 RID: 9488 RVA: 0x0001BF0B File Offset: 0x0001A10B
	public static int Int32_10 { get; set; } = 7;

	// Token: 0x170007B3 RID: 1971
	// (get) Token: 0x06002511 RID: 9489 RVA: 0x0001BF13 File Offset: 0x0001A113
	// (set) Token: 0x06002512 RID: 9490 RVA: 0x0001BF1A File Offset: 0x0001A11A
	public static int Int32_11 { get; set; } = 8;

	// Token: 0x170007B4 RID: 1972
	// (get) Token: 0x06002513 RID: 9491 RVA: 0x0001BF22 File Offset: 0x0001A122
	// (set) Token: 0x06002514 RID: 9492 RVA: 0x0001BF29 File Offset: 0x0001A129
	public static int Int32_12 { get; set; } = 9;

	// Token: 0x170007B5 RID: 1973
	// (get) Token: 0x06002515 RID: 9493 RVA: 0x0001BF31 File Offset: 0x0001A131
	// (set) Token: 0x06002516 RID: 9494 RVA: 0x0001BF38 File Offset: 0x0001A138
	public static int Int32_13 { get; set; } = 11;

	// Token: 0x170007B6 RID: 1974
	// (get) Token: 0x06002517 RID: 9495 RVA: 0x0001BF40 File Offset: 0x0001A140
	// (set) Token: 0x06002518 RID: 9496 RVA: 0x0001BF47 File Offset: 0x0001A147
	public static int Int32_14 { get; set; } = 10;

	// Token: 0x170007B7 RID: 1975
	// (get) Token: 0x06002519 RID: 9497 RVA: 0x0001BF4F File Offset: 0x0001A14F
	// (set) Token: 0x0600251A RID: 9498 RVA: 0x0001BF56 File Offset: 0x0001A156
	public static int Int32_15 { get; set; } = 12;

	// Token: 0x170007B8 RID: 1976
	// (get) Token: 0x0600251B RID: 9499 RVA: 0x0001BF5E File Offset: 0x0001A15E
	// (set) Token: 0x0600251C RID: 9500 RVA: 0x0001BF65 File Offset: 0x0001A165
	public static int Int32_16 { get; set; } = 13;

	// Token: 0x170007B9 RID: 1977
	// (get) Token: 0x0600251D RID: 9501 RVA: 0x0001BF6D File Offset: 0x0001A16D
	// (set) Token: 0x0600251E RID: 9502 RVA: 0x0001BF74 File Offset: 0x0001A174
	public static int Int32_17 { get; set; } = 14;

	// Token: 0x170007BA RID: 1978
	// (get) Token: 0x0600251F RID: 9503 RVA: 0x0001BF7C File Offset: 0x0001A17C
	// (set) Token: 0x06002520 RID: 9504 RVA: 0x0001BF83 File Offset: 0x0001A183
	public static int Int32_18 { get; set; } = 15;

	// Token: 0x170007BB RID: 1979
	// (get) Token: 0x06002521 RID: 9505 RVA: 0x0001BF8B File Offset: 0x0001A18B
	// (set) Token: 0x06002522 RID: 9506 RVA: 0x0001BF92 File Offset: 0x0001A192
	public static int Int32_19 { get; set; } = 16;

	// Token: 0x170007BC RID: 1980
	// (get) Token: 0x06002523 RID: 9507 RVA: 0x0001BF9A File Offset: 0x0001A19A
	// (set) Token: 0x06002524 RID: 9508 RVA: 0x0001BFA1 File Offset: 0x0001A1A1
	public static int Int32_20 { get; set; } = 17;

	// Token: 0x170007BD RID: 1981
	// (get) Token: 0x06002525 RID: 9509 RVA: 0x0001BFA9 File Offset: 0x0001A1A9
	// (set) Token: 0x06002526 RID: 9510 RVA: 0x0001BFB0 File Offset: 0x0001A1B0
	public static int Int32_21 { get; set; } = 678;

	// Token: 0x170007BE RID: 1982
	// (get) Token: 0x06002527 RID: 9511 RVA: 0x0001BFB8 File Offset: 0x0001A1B8
	// (set) Token: 0x06002528 RID: 9512 RVA: 0x0001BFBF File Offset: 0x0001A1BF
	public static int Int32_22 { get; set; } = 731;

	// Token: 0x170007BF RID: 1983
	// (get) Token: 0x06002529 RID: 9513 RVA: 0x0001BFC7 File Offset: 0x0001A1C7
	// (set) Token: 0x0600252A RID: 9514 RVA: 0x0001BFCE File Offset: 0x0001A1CE
	public static int Int32_23 { get; set; } = 732;

	// Token: 0x170007C0 RID: 1984
	// (get) Token: 0x0600252B RID: 9515 RVA: 0x0001BFD6 File Offset: 0x0001A1D6
	// (set) Token: 0x0600252C RID: 9516 RVA: 0x0001BFDD File Offset: 0x0001A1DD
	public static int Int32_24 { get; set; } = 19;

	// Token: 0x170007C1 RID: 1985
	// (get) Token: 0x0600252D RID: 9517 RVA: 0x0001BFE5 File Offset: 0x0001A1E5
	// (set) Token: 0x0600252E RID: 9518 RVA: 0x0001BFEC File Offset: 0x0001A1EC
	public static int Int32_25 { get; set; } = 20;

	// Token: 0x170007C2 RID: 1986
	// (get) Token: 0x0600252F RID: 9519 RVA: 0x0001BFF4 File Offset: 0x0001A1F4
	// (set) Token: 0x06002530 RID: 9520 RVA: 0x0001BFFB File Offset: 0x0001A1FB
	public static int Int32_26 { get; set; } = 21;

	// Token: 0x170007C3 RID: 1987
	// (get) Token: 0x06002531 RID: 9521 RVA: 0x0001C003 File Offset: 0x0001A203
	// (set) Token: 0x06002532 RID: 9522 RVA: 0x0001C00A File Offset: 0x0001A20A
	public static int Int32_27 { get; set; } = 22;

	// Token: 0x170007C4 RID: 1988
	// (get) Token: 0x06002533 RID: 9523 RVA: 0x0001C012 File Offset: 0x0001A212
	// (set) Token: 0x06002534 RID: 9524 RVA: 0x0001C019 File Offset: 0x0001A219
	public static int Int32_28 { get; set; } = 23;

	// Token: 0x170007C5 RID: 1989
	// (get) Token: 0x06002535 RID: 9525 RVA: 0x0001C021 File Offset: 0x0001A221
	// (set) Token: 0x06002536 RID: 9526 RVA: 0x0001C028 File Offset: 0x0001A228
	public static int Int32_29 { get; set; } = 24;

	// Token: 0x170007C6 RID: 1990
	// (get) Token: 0x06002537 RID: 9527 RVA: 0x0001C030 File Offset: 0x0001A230
	// (set) Token: 0x06002538 RID: 9528 RVA: 0x0001C037 File Offset: 0x0001A237
	public static int Int32_30 { get; set; } = 25;

	// Token: 0x170007C7 RID: 1991
	// (get) Token: 0x06002539 RID: 9529 RVA: 0x0001C03F File Offset: 0x0001A23F
	// (set) Token: 0x0600253A RID: 9530 RVA: 0x0001C046 File Offset: 0x0001A246
	public static int Int32_31 { get; set; } = 26;

	// Token: 0x170007C8 RID: 1992
	// (get) Token: 0x0600253B RID: 9531 RVA: 0x0001C04E File Offset: 0x0001A24E
	// (set) Token: 0x0600253C RID: 9532 RVA: 0x0001C055 File Offset: 0x0001A255
	public static int Int32_32 { get; set; } = 27;

	// Token: 0x170007C9 RID: 1993
	// (get) Token: 0x0600253D RID: 9533 RVA: 0x0001C05D File Offset: 0x0001A25D
	// (set) Token: 0x0600253E RID: 9534 RVA: 0x0001C064 File Offset: 0x0001A264
	public static int Int32_33 { get; set; } = 28;

	// Token: 0x170007CA RID: 1994
	// (get) Token: 0x0600253F RID: 9535 RVA: 0x0001C06C File Offset: 0x0001A26C
	// (set) Token: 0x06002540 RID: 9536 RVA: 0x0001C073 File Offset: 0x0001A273
	public static int Int32_34 { get; set; } = 29;

	// Token: 0x170007CB RID: 1995
	// (get) Token: 0x06002541 RID: 9537 RVA: 0x0001C07B File Offset: 0x0001A27B
	// (set) Token: 0x06002542 RID: 9538 RVA: 0x0001C082 File Offset: 0x0001A282
	public static int Int32_35 { get; set; } = 30;

	// Token: 0x170007CC RID: 1996
	// (get) Token: 0x06002543 RID: 9539 RVA: 0x0001C08A File Offset: 0x0001A28A
	// (set) Token: 0x06002544 RID: 9540 RVA: 0x0001C091 File Offset: 0x0001A291
	public static int Int32_36 { get; set; } = 31;

	// Token: 0x170007CD RID: 1997
	// (get) Token: 0x06002545 RID: 9541 RVA: 0x0001C099 File Offset: 0x0001A299
	// (set) Token: 0x06002546 RID: 9542 RVA: 0x0001C0A0 File Offset: 0x0001A2A0
	public static int Int32_37 { get; set; } = 32;

	// Token: 0x170007CE RID: 1998
	// (get) Token: 0x06002547 RID: 9543 RVA: 0x0001C0A8 File Offset: 0x0001A2A8
	// (set) Token: 0x06002548 RID: 9544 RVA: 0x0001C0AF File Offset: 0x0001A2AF
	public static int Int32_38 { get; set; } = 33;

	// Token: 0x170007CF RID: 1999
	// (get) Token: 0x06002549 RID: 9545 RVA: 0x0001C0B7 File Offset: 0x0001A2B7
	// (set) Token: 0x0600254A RID: 9546 RVA: 0x0001C0BE File Offset: 0x0001A2BE
	public static int Int32_39 { get; set; } = 34;

	// Token: 0x170007D0 RID: 2000
	// (get) Token: 0x0600254B RID: 9547 RVA: 0x0001C0C6 File Offset: 0x0001A2C6
	// (set) Token: 0x0600254C RID: 9548 RVA: 0x0001C0CD File Offset: 0x0001A2CD
	public static int Int32_40 { get; set; } = 35;

	// Token: 0x170007D1 RID: 2001
	// (get) Token: 0x0600254D RID: 9549 RVA: 0x0001C0D5 File Offset: 0x0001A2D5
	// (set) Token: 0x0600254E RID: 9550 RVA: 0x0001C0DC File Offset: 0x0001A2DC
	public static int Int32_41 { get; set; } = 79;

	// Token: 0x170007D2 RID: 2002
	// (get) Token: 0x0600254F RID: 9551 RVA: 0x0001C0E4 File Offset: 0x0001A2E4
	// (set) Token: 0x06002550 RID: 9552 RVA: 0x0001C0EB File Offset: 0x0001A2EB
	public static int Int32_42 { get; set; } = 81;

	// Token: 0x170007D3 RID: 2003
	// (get) Token: 0x06002551 RID: 9553 RVA: 0x0001C0F3 File Offset: 0x0001A2F3
	// (set) Token: 0x06002552 RID: 9554 RVA: 0x0001C0FA File Offset: 0x0001A2FA
	public static int Int32_43 { get; set; } = 199;

	// Token: 0x170007D4 RID: 2004
	// (get) Token: 0x06002553 RID: 9555 RVA: 0x0001C102 File Offset: 0x0001A302
	// (set) Token: 0x06002554 RID: 9556 RVA: 0x0001C109 File Offset: 0x0001A309
	public static int Int32_44 { get; set; } = 216;

	// Token: 0x170007D5 RID: 2005
	// (get) Token: 0x06002555 RID: 9557 RVA: 0x0001C111 File Offset: 0x0001A311
	// (set) Token: 0x06002556 RID: 9558 RVA: 0x0001C118 File Offset: 0x0001A318
	public static int Int32_45 { get; set; } = 262;

	// Token: 0x170007D6 RID: 2006
	// (get) Token: 0x06002557 RID: 9559 RVA: 0x0001C120 File Offset: 0x0001A320
	// (set) Token: 0x06002558 RID: 9560 RVA: 0x0001C127 File Offset: 0x0001A327
	public static int Int32_46 { get; set; } = 263;

	// Token: 0x170007D7 RID: 2007
	// (get) Token: 0x06002559 RID: 9561 RVA: 0x0001C12F File Offset: 0x0001A32F
	// (set) Token: 0x0600255A RID: 9562 RVA: 0x0001C136 File Offset: 0x0001A336
	public static int Int32_47 { get; set; } = 264;

	// Token: 0x170007D8 RID: 2008
	// (get) Token: 0x0600255B RID: 9563 RVA: 0x0001C13E File Offset: 0x0001A33E
	// (set) Token: 0x0600255C RID: 9564 RVA: 0x0001C145 File Offset: 0x0001A345
	public static int Int32_48 { get; set; } = 292;

	// Token: 0x170007D9 RID: 2009
	// (get) Token: 0x0600255D RID: 9565 RVA: 0x0001C14D File Offset: 0x0001A34D
	// (set) Token: 0x0600255E RID: 9566 RVA: 0x0001C154 File Offset: 0x0001A354
	public static int Int32_49 { get; set; } = 294;

	// Token: 0x170007DA RID: 2010
	// (get) Token: 0x0600255F RID: 9567 RVA: 0x0001C15C File Offset: 0x0001A35C
	// (set) Token: 0x06002560 RID: 9568 RVA: 0x0001C163 File Offset: 0x0001A363
	public static int Int32_50 { get; set; } = 213;

	// Token: 0x170007DB RID: 2011
	// (get) Token: 0x06002561 RID: 9569 RVA: 0x0001C16B File Offset: 0x0001A36B
	// (set) Token: 0x06002562 RID: 9570 RVA: 0x0001C172 File Offset: 0x0001A372
	public static int Int32_51 { get; set; } = 284;

	// Token: 0x170007DC RID: 2012
	// (get) Token: 0x06002563 RID: 9571 RVA: 0x0001C17A File Offset: 0x0001A37A
	// (set) Token: 0x06002564 RID: 9572 RVA: 0x0001C181 File Offset: 0x0001A381
	public static int Int32_52 { get; set; } = 615;

	// Token: 0x170007DD RID: 2013
	// (get) Token: 0x06002565 RID: 9573 RVA: 0x0001C189 File Offset: 0x0001A389
	// (set) Token: 0x06002566 RID: 9574 RVA: 0x0001C190 File Offset: 0x0001A390
	public static int Int32_53 { get; set; } = 153;

	// Token: 0x170007DE RID: 2014
	// (get) Token: 0x06002567 RID: 9575 RVA: 0x0001C198 File Offset: 0x0001A398
	// (set) Token: 0x06002568 RID: 9576 RVA: 0x0001C19F File Offset: 0x0001A39F
	public static int Int32_54 { get; set; } = 182;

	// Token: 0x170007DF RID: 2015
	// (get) Token: 0x06002569 RID: 9577 RVA: 0x0001C1A7 File Offset: 0x0001A3A7
	// (set) Token: 0x0600256A RID: 9578 RVA: 0x0001C1AE File Offset: 0x0001A3AE
	public static int Int32_55 { get; set; } = 183;

	// Token: 0x170007E0 RID: 2016
	// (get) Token: 0x0600256B RID: 9579 RVA: 0x0001C1B6 File Offset: 0x0001A3B6
	// (set) Token: 0x0600256C RID: 9580 RVA: 0x0001C1BD File Offset: 0x0001A3BD
	public static int Int32_56 { get; set; } = 184;

	// Token: 0x170007E1 RID: 2017
	// (get) Token: 0x0600256D RID: 9581 RVA: 0x0001C1C5 File Offset: 0x0001A3C5
	// (set) Token: 0x0600256E RID: 9582 RVA: 0x0001C1CC File Offset: 0x0001A3CC
	public static int Int32_57 { get; set; } = 185;

	// Token: 0x170007E2 RID: 2018
	// (get) Token: 0x0600256F RID: 9583 RVA: 0x0001C1D4 File Offset: 0x0001A3D4
	// (set) Token: 0x06002570 RID: 9584 RVA: 0x0001C1DB File Offset: 0x0001A3DB
	public static int Int32_58 { get; set; } = 186;

	// Token: 0x170007E3 RID: 2019
	// (get) Token: 0x06002571 RID: 9585 RVA: 0x0001C1E3 File Offset: 0x0001A3E3
	// (set) Token: 0x06002572 RID: 9586 RVA: 0x0001C1EA File Offset: 0x0001A3EA
	public static int Int32_59 { get; set; } = 187;

	// Token: 0x170007E4 RID: 2020
	// (get) Token: 0x06002573 RID: 9587 RVA: 0x0001C1F2 File Offset: 0x0001A3F2
	// (set) Token: 0x06002574 RID: 9588 RVA: 0x0001C1F9 File Offset: 0x0001A3F9
	public static int Int32_60 { get; set; } = 188;

	// Token: 0x170007E5 RID: 2021
	// (get) Token: 0x06002575 RID: 9589 RVA: 0x0001C201 File Offset: 0x0001A401
	// (set) Token: 0x06002576 RID: 9590 RVA: 0x0001C208 File Offset: 0x0001A408
	public static int Int32_61 { get; set; } = 189;

	// Token: 0x170007E6 RID: 2022
	// (get) Token: 0x06002577 RID: 9591 RVA: 0x0001C210 File Offset: 0x0001A410
	// (set) Token: 0x06002578 RID: 9592 RVA: 0x0001C217 File Offset: 0x0001A417
	public static int Int32_62 { get; set; } = 741;

	// Token: 0x170007E7 RID: 2023
	// (get) Token: 0x06002579 RID: 9593 RVA: 0x0001C21F File Offset: 0x0001A41F
	// (set) Token: 0x0600257A RID: 9594 RVA: 0x0001C226 File Offset: 0x0001A426
	public static int Int32_63 { get; set; } = 190;

	// Token: 0x170007E8 RID: 2024
	// (get) Token: 0x0600257B RID: 9595 RVA: 0x0001C22E File Offset: 0x0001A42E
	// (set) Token: 0x0600257C RID: 9596 RVA: 0x0001C235 File Offset: 0x0001A435
	public static int Int32_64 { get; set; } = 289;

	// Token: 0x170007E9 RID: 2025
	// (get) Token: 0x0600257D RID: 9597 RVA: 0x0001C23D File Offset: 0x0001A43D
	// (set) Token: 0x0600257E RID: 9598 RVA: 0x0001C244 File Offset: 0x0001A444
	public static int Int32_65 { get; set; } = 616;

	// Token: 0x170007EA RID: 2026
	// (get) Token: 0x0600257F RID: 9599 RVA: 0x0001C24C File Offset: 0x0001A44C
	// (set) Token: 0x06002580 RID: 9600 RVA: 0x0001C253 File Offset: 0x0001A453
	public static int Int32_66 { get; set; } = 229;

	// Token: 0x170007EB RID: 2027
	// (get) Token: 0x06002581 RID: 9601 RVA: 0x0001C25B File Offset: 0x0001A45B
	// (set) Token: 0x06002582 RID: 9602 RVA: 0x0001C262 File Offset: 0x0001A462
	public static int Int32_67 { get; set; } = 18;

	// Token: 0x170007EC RID: 2028
	// (get) Token: 0x06002583 RID: 9603 RVA: 0x0001C26A File Offset: 0x0001A46A
	// (set) Token: 0x06002584 RID: 9604 RVA: 0x0001C271 File Offset: 0x0001A471
	public static int Int32_68 { get; set; } = 173;

	// Token: 0x170007ED RID: 2029
	// (get) Token: 0x06002585 RID: 9605 RVA: 0x0001C279 File Offset: 0x0001A479
	// (set) Token: 0x06002586 RID: 9606 RVA: 0x0001C280 File Offset: 0x0001A480
	public static int Int32_69 { get; set; } = 179;

	// Token: 0x170007EE RID: 2030
	// (get) Token: 0x06002587 RID: 9607 RVA: 0x0001C288 File Offset: 0x0001A488
	// (set) Token: 0x06002588 RID: 9608 RVA: 0x0001C28F File Offset: 0x0001A48F
	public static int Int32_70 { get; set; } = 178;

	// Token: 0x170007EF RID: 2031
	// (get) Token: 0x06002589 RID: 9609 RVA: 0x0001C297 File Offset: 0x0001A497
	// (set) Token: 0x0600258A RID: 9610 RVA: 0x0001C29E File Offset: 0x0001A49E
	public static int Int32_71 { get; set; } = 618;

	// Token: 0x170007F0 RID: 2032
	// (get) Token: 0x0600258B RID: 9611 RVA: 0x0001C2A6 File Offset: 0x0001A4A6
	// (set) Token: 0x0600258C RID: 9612 RVA: 0x0001C2AD File Offset: 0x0001A4AD
	public static int Int32_72 { get; set; } = 681;

	// Token: 0x170007F1 RID: 2033
	// (get) Token: 0x0600258D RID: 9613 RVA: 0x0001C2B5 File Offset: 0x0001A4B5
	// (set) Token: 0x0600258E RID: 9614 RVA: 0x0001C2BC File Offset: 0x0001A4BC
	public static int Int32_73 { get; set; } = 175;

	// Token: 0x170007F2 RID: 2034
	// (get) Token: 0x0600258F RID: 9615 RVA: 0x0001C2C4 File Offset: 0x0001A4C4
	// (set) Token: 0x06002590 RID: 9616 RVA: 0x0001C2CB File Offset: 0x0001A4CB
	public static int Int32_74 { get; set; } = 176;

	// Token: 0x170007F3 RID: 2035
	// (get) Token: 0x06002591 RID: 9617 RVA: 0x0001C2D3 File Offset: 0x0001A4D3
	// (set) Token: 0x06002592 RID: 9618 RVA: 0x0001C2DA File Offset: 0x0001A4DA
	public static int Int32_75 { get; set; } = 180;

	// Token: 0x170007F4 RID: 2036
	// (get) Token: 0x06002593 RID: 9619 RVA: 0x0001C2E2 File Offset: 0x0001A4E2
	// (set) Token: 0x06002594 RID: 9620 RVA: 0x0001C2E9 File Offset: 0x0001A4E9
	public static int Int32_76 { get; set; } = 181;

	// Token: 0x170007F5 RID: 2037
	// (get) Token: 0x06002595 RID: 9621 RVA: 0x0001C2F1 File Offset: 0x0001A4F1
	// (set) Token: 0x06002596 RID: 9622 RVA: 0x0001C2F8 File Offset: 0x0001A4F8
	public static int Int32_77 { get; set; } = 174;

	// Token: 0x170007F6 RID: 2038
	// (get) Token: 0x06002597 RID: 9623 RVA: 0x0001C300 File Offset: 0x0001A500
	// (set) Token: 0x06002598 RID: 9624 RVA: 0x0001C307 File Offset: 0x0001A507
	public static int Int32_78 { get; set; } = 177;

	// Token: 0x170007F7 RID: 2039
	// (get) Token: 0x06002599 RID: 9625 RVA: 0x0001C30F File Offset: 0x0001A50F
	// (set) Token: 0x0600259A RID: 9626 RVA: 0x0001C316 File Offset: 0x0001A516
	public static int Int32_79 { get; set; } = 288;

	// Token: 0x170007F8 RID: 2040
	// (get) Token: 0x0600259B RID: 9627 RVA: 0x0001C31E File Offset: 0x0001A51E
	// (set) Token: 0x0600259C RID: 9628 RVA: 0x0001C325 File Offset: 0x0001A525
	public static int Int32_80 { get; set; } = 742;

	// Token: 0x170007F9 RID: 2041
	// (get) Token: 0x0600259D RID: 9629 RVA: 0x0001C32D File Offset: 0x0001A52D
	// (set) Token: 0x0600259E RID: 9630 RVA: 0x0001C334 File Offset: 0x0001A534
	public static int Int32_81 { get; set; } = 170;

	// Token: 0x170007FA RID: 2042
	// (get) Token: 0x0600259F RID: 9631 RVA: 0x0001C33C File Offset: 0x0001A53C
	// (set) Token: 0x060025A0 RID: 9632 RVA: 0x0001C343 File Offset: 0x0001A543
	public static int Int32_82 { get; set; } = 272;

	// Token: 0x170007FB RID: 2043
	// (get) Token: 0x060025A1 RID: 9633 RVA: 0x0001C34B File Offset: 0x0001A54B
	// (set) Token: 0x060025A2 RID: 9634 RVA: 0x0001C352 File Offset: 0x0001A552
	public static int Int32_83 { get; set; } = 201;

	// Token: 0x170007FC RID: 2044
	// (get) Token: 0x060025A3 RID: 9635 RVA: 0x0001C35A File Offset: 0x0001A55A
	// (set) Token: 0x060025A4 RID: 9636 RVA: 0x0001C361 File Offset: 0x0001A561
	public static int Int32_84 { get; set; } = 256;

	// Token: 0x170007FD RID: 2045
	// (get) Token: 0x060025A5 RID: 9637 RVA: 0x0001C369 File Offset: 0x0001A569
	// (set) Token: 0x060025A6 RID: 9638 RVA: 0x0001C370 File Offset: 0x0001A570
	public static int Int32_85 { get; set; } = 232;

	// Token: 0x170007FE RID: 2046
	// (get) Token: 0x060025A7 RID: 9639 RVA: 0x0001C378 File Offset: 0x0001A578
	// (set) Token: 0x060025A8 RID: 9640 RVA: 0x0001C37F File Offset: 0x0001A57F
	public static int Int32_86 { get; set; } = 246;

	// Token: 0x170007FF RID: 2047
	// (get) Token: 0x060025A9 RID: 9641 RVA: 0x0001C387 File Offset: 0x0001A587
	// (set) Token: 0x060025AA RID: 9642 RVA: 0x0001C38E File Offset: 0x0001A58E
	public static int Int32_87 { get; set; } = 260;

	// Token: 0x17000800 RID: 2048
	// (get) Token: 0x060025AB RID: 9643 RVA: 0x0001C396 File Offset: 0x0001A596
	// (set) Token: 0x060025AC RID: 9644 RVA: 0x0001C39D File Offset: 0x0001A59D
	public static int Int32_88 { get; set; } = 268;

	// Token: 0x17000801 RID: 2049
	// (get) Token: 0x060025AD RID: 9645 RVA: 0x0001C3A5 File Offset: 0x0001A5A5
	// (set) Token: 0x060025AE RID: 9646 RVA: 0x0001C3AC File Offset: 0x0001A5AC
	public static int Int32_89 { get; set; } = 280;

	// Token: 0x17000802 RID: 2050
	// (get) Token: 0x060025AF RID: 9647 RVA: 0x0001C3B4 File Offset: 0x0001A5B4
	// (set) Token: 0x060025B0 RID: 9648 RVA: 0x0001C3BB File Offset: 0x0001A5BB
	public static int Int32_90 { get; set; } = 281;

	// Token: 0x17000803 RID: 2051
	// (get) Token: 0x060025B1 RID: 9649 RVA: 0x0001C3C3 File Offset: 0x0001A5C3
	// (set) Token: 0x060025B2 RID: 9650 RVA: 0x0001C3CA File Offset: 0x0001A5CA
	public static int Int32_91 { get; set; } = 261;

	// Token: 0x17000804 RID: 2052
	// (get) Token: 0x060025B3 RID: 9651 RVA: 0x0001C3D2 File Offset: 0x0001A5D2
	// (set) Token: 0x060025B4 RID: 9652 RVA: 0x0001C3D9 File Offset: 0x0001A5D9
	public static int Int32_92 { get; set; } = 119;

	// Token: 0x17000805 RID: 2053
	// (get) Token: 0x060025B5 RID: 9653 RVA: 0x0001C3E1 File Offset: 0x0001A5E1
	// (set) Token: 0x060025B6 RID: 9654 RVA: 0x0001C3E8 File Offset: 0x0001A5E8
	public static int Int32_93 { get; set; } = 118;

	// Token: 0x17000806 RID: 2054
	// (get) Token: 0x060025B7 RID: 9655 RVA: 0x0001C3F0 File Offset: 0x0001A5F0
	// (set) Token: 0x060025B8 RID: 9656 RVA: 0x0001C3F7 File Offset: 0x0001A5F7
	public static int Int32_94 { get; set; } = 269;

	// Token: 0x17000807 RID: 2055
	// (get) Token: 0x060025B9 RID: 9657 RVA: 0x0001C3FF File Offset: 0x0001A5FF
	// (set) Token: 0x060025BA RID: 9658 RVA: 0x0001C406 File Offset: 0x0001A606
	public static int Int32_95 { get; set; } = 653;

	// Token: 0x17000808 RID: 2056
	// (get) Token: 0x060025BB RID: 9659 RVA: 0x0001C40E File Offset: 0x0001A60E
	// (set) Token: 0x060025BC RID: 9660 RVA: 0x0001C415 File Offset: 0x0001A615
	public static int Int32_96 { get; set; } = 652;

	// Token: 0x17000809 RID: 2057
	// (get) Token: 0x060025BD RID: 9661 RVA: 0x0001C41D File Offset: 0x0001A61D
	// (set) Token: 0x060025BE RID: 9662 RVA: 0x0001C424 File Offset: 0x0001A624
	public static int Int32_97 { get; set; } = 61;

	// Token: 0x1700080A RID: 2058
	// (get) Token: 0x060025BF RID: 9663 RVA: 0x0001C42C File Offset: 0x0001A62C
	// (set) Token: 0x060025C0 RID: 9664 RVA: 0x0001C433 File Offset: 0x0001A633
	public static int Int32_98 { get; set; } = 291;

	// Token: 0x1700080B RID: 2059
	// (get) Token: 0x060025C1 RID: 9665 RVA: 0x0001C43B File Offset: 0x0001A63B
	// (set) Token: 0x060025C2 RID: 9666 RVA: 0x0001C442 File Offset: 0x0001A642
	public static int Int32_99 { get; set; } = 546;

	// Token: 0x1700080C RID: 2060
	// (get) Token: 0x060025C3 RID: 9667 RVA: 0x0001C44A File Offset: 0x0001A64A
	// (set) Token: 0x060025C4 RID: 9668 RVA: 0x0001C451 File Offset: 0x0001A651
	public static int Int32_100 { get; set; } = 547;

	// Token: 0x1700080D RID: 2061
	// (get) Token: 0x060025C5 RID: 9669 RVA: 0x0001C459 File Offset: 0x0001A659
	// (set) Token: 0x060025C6 RID: 9670 RVA: 0x0001C460 File Offset: 0x0001A660
	public static int Int32_101 { get; set; } = 236;

	// Token: 0x1700080E RID: 2062
	// (get) Token: 0x060025C7 RID: 9671 RVA: 0x0001C468 File Offset: 0x0001A668
	// (set) Token: 0x060025C8 RID: 9672 RVA: 0x0001C46F File Offset: 0x0001A66F
	public static int Int32_102 { get; set; } = 110;

	// Token: 0x1700080F RID: 2063
	// (get) Token: 0x060025C9 RID: 9673 RVA: 0x0001C477 File Offset: 0x0001A677
	// (set) Token: 0x060025CA RID: 9674 RVA: 0x0001C47E File Offset: 0x0001A67E
	public static int Int32_103 { get; set; } = 66;

	// Token: 0x17000810 RID: 2064
	// (get) Token: 0x060025CB RID: 9675 RVA: 0x0001C486 File Offset: 0x0001A686
	// (set) Token: 0x060025CC RID: 9676 RVA: 0x0001C48D File Offset: 0x0001A68D
	public static int Int32_104 { get; set; } = 566;

	// Token: 0x17000811 RID: 2065
	// (get) Token: 0x060025CD RID: 9677 RVA: 0x0001C495 File Offset: 0x0001A695
	// (set) Token: 0x060025CE RID: 9678 RVA: 0x0001C49C File Offset: 0x0001A69C
	public static int Int32_105 { get; set; } = 112;

	// Token: 0x17000812 RID: 2066
	// (get) Token: 0x060025CF RID: 9679 RVA: 0x0001C4A4 File Offset: 0x0001A6A4
	// (set) Token: 0x060025D0 RID: 9680 RVA: 0x0001C4AB File Offset: 0x0001A6AB
	public static int Int32_106 { get; set; } = 777;

	// Token: 0x17000813 RID: 2067
	// (get) Token: 0x060025D1 RID: 9681 RVA: 0x0001C4B3 File Offset: 0x0001A6B3
	// (set) Token: 0x060025D2 RID: 9682 RVA: 0x0001C4BA File Offset: 0x0001A6BA
	public static int Int32_107 { get; set; } = 600;

	// Token: 0x17000814 RID: 2068
	// (get) Token: 0x060025D3 RID: 9683 RVA: 0x0001C4C2 File Offset: 0x0001A6C2
	// (set) Token: 0x060025D4 RID: 9684 RVA: 0x0001C4C9 File Offset: 0x0001A6C9
	public static int Int32_108 { get; set; } = 611;

	// Token: 0x17000815 RID: 2069
	// (get) Token: 0x060025D5 RID: 9685 RVA: 0x0001C4D1 File Offset: 0x0001A6D1
	// (set) Token: 0x060025D6 RID: 9686 RVA: 0x0001C4D8 File Offset: 0x0001A6D8
	public static int Int32_109 { get; set; } = 651;

	// Token: 0x17000816 RID: 2070
	// (get) Token: 0x060025D7 RID: 9687 RVA: 0x0001C4E0 File Offset: 0x0001A6E0
	// (set) Token: 0x060025D8 RID: 9688 RVA: 0x0001C4E7 File Offset: 0x0001A6E7
	public static int Int32_110 { get; set; } = 677;

	// Token: 0x17000817 RID: 2071
	// (get) Token: 0x060025D9 RID: 9689 RVA: 0x0001C4EF File Offset: 0x0001A6EF
	// (set) Token: 0x060025DA RID: 9690 RVA: 0x0001C4F6 File Offset: 0x0001A6F6
	public static int Int32_111 { get; set; } = 662;

	// Token: 0x17000818 RID: 2072
	// (get) Token: 0x060025DB RID: 9691 RVA: 0x0001C4FE File Offset: 0x0001A6FE
	// (set) Token: 0x060025DC RID: 9692 RVA: 0x0001C505 File Offset: 0x0001A705
	public static int Int32_112 { get; set; } = 663;

	// Token: 0x17000819 RID: 2073
	// (get) Token: 0x060025DD RID: 9693 RVA: 0x0001C50D File Offset: 0x0001A70D
	// (set) Token: 0x060025DE RID: 9694 RVA: 0x0001C514 File Offset: 0x0001A714
	public static int Int32_113 { get; set; } = 664;

	// Token: 0x1700081A RID: 2074
	// (get) Token: 0x060025DF RID: 9695 RVA: 0x0001C51C File Offset: 0x0001A71C
	// (set) Token: 0x060025E0 RID: 9696 RVA: 0x0001C523 File Offset: 0x0001A723
	public static int Int32_114 { get; set; } = 665;

	// Token: 0x1700081B RID: 2075
	// (get) Token: 0x060025E1 RID: 9697 RVA: 0x0001C52B File Offset: 0x0001A72B
	// (set) Token: 0x060025E2 RID: 9698 RVA: 0x0001C532 File Offset: 0x0001A732
	public static int Int32_115 { get; set; } = 666;

	// Token: 0x1700081C RID: 2076
	// (get) Token: 0x060025E3 RID: 9699 RVA: 0x0001C53A File Offset: 0x0001A73A
	// (set) Token: 0x060025E4 RID: 9700 RVA: 0x0001C541 File Offset: 0x0001A741
	public static int Int32_116 { get; set; } = 667;

	// Token: 0x1700081D RID: 2077
	// (get) Token: 0x060025E5 RID: 9701 RVA: 0x0001C549 File Offset: 0x0001A749
	// (set) Token: 0x060025E6 RID: 9702 RVA: 0x0001C550 File Offset: 0x0001A750
	public static int Int32_117 { get; set; } = 231;

	// Token: 0x1700081E RID: 2078
	// (get) Token: 0x060025E7 RID: 9703 RVA: 0x0001C558 File Offset: 0x0001A758
	// (set) Token: 0x060025E8 RID: 9704 RVA: 0x0001C55F File Offset: 0x0001A75F
	public static int Int32_118 { get; set; } = 114;

	// Token: 0x1700081F RID: 2079
	// (get) Token: 0x060025E9 RID: 9705 RVA: 0x0001C567 File Offset: 0x0001A767
	// (set) Token: 0x060025EA RID: 9706 RVA: 0x0001C56E File Offset: 0x0001A76E
	public static int Int32_119 { get; set; } = 37;

	// Token: 0x17000820 RID: 2080
	// (get) Token: 0x060025EB RID: 9707 RVA: 0x0001C576 File Offset: 0x0001A776
	// (set) Token: 0x060025EC RID: 9708 RVA: 0x0001C57D File Offset: 0x0001A77D
	public static int Int32_120 { get; set; } = 113;

	// Token: 0x17000821 RID: 2081
	// (get) Token: 0x060025ED RID: 9709 RVA: 0x0001C585 File Offset: 0x0001A785
	// (set) Token: 0x060025EE RID: 9710 RVA: 0x0001C58C File Offset: 0x0001A78C
	public static int Int32_121 { get; set; } = 36;

	// Token: 0x17000822 RID: 2082
	// (get) Token: 0x060025EF RID: 9711 RVA: 0x0001C594 File Offset: 0x0001A794
	// (set) Token: 0x060025F0 RID: 9712 RVA: 0x0001C59B File Offset: 0x0001A79B
	public static int Int32_122 { get; set; } = 121;

	// Token: 0x17000823 RID: 2083
	// (get) Token: 0x060025F1 RID: 9713 RVA: 0x0001C5A3 File Offset: 0x0001A7A3
	// (set) Token: 0x060025F2 RID: 9714 RVA: 0x0001C5AA File Offset: 0x0001A7AA
	public static int Int32_123 { get; set; } = 120;

	// Token: 0x17000824 RID: 2084
	// (get) Token: 0x060025F3 RID: 9715 RVA: 0x0001C5B2 File Offset: 0x0001A7B2
	// (set) Token: 0x060025F4 RID: 9716 RVA: 0x0001C5B9 File Offset: 0x0001A7B9
	public static int Int32_124 { get; set; } = 116;

	// Token: 0x17000825 RID: 2085
	// (get) Token: 0x060025F5 RID: 9717 RVA: 0x0001C5C1 File Offset: 0x0001A7C1
	// (set) Token: 0x060025F6 RID: 9718 RVA: 0x0001C5C8 File Offset: 0x0001A7C8
	public static int Int32_125 { get; set; } = 117;

	// Token: 0x17000826 RID: 2086
	// (get) Token: 0x060025F7 RID: 9719 RVA: 0x0001C5D0 File Offset: 0x0001A7D0
	// (set) Token: 0x060025F8 RID: 9720 RVA: 0x0001C5D7 File Offset: 0x0001A7D7
	public static int Int32_126 { get; set; } = 115;

	// Token: 0x17000827 RID: 2087
	// (get) Token: 0x060025F9 RID: 9721 RVA: 0x0001C5DF File Offset: 0x0001A7DF
	// (set) Token: 0x060025FA RID: 9722 RVA: 0x0001C5E6 File Offset: 0x0001A7E6
	public static int Int32_127 { get; set; } = 38;

	// Token: 0x17000828 RID: 2088
	// (get) Token: 0x060025FB RID: 9723 RVA: 0x0001C5EE File Offset: 0x0001A7EE
	// (set) Token: 0x060025FC RID: 9724 RVA: 0x0001C5F5 File Offset: 0x0001A7F5
	public static int Int32_128 { get; set; } = 550;

	// Token: 0x17000829 RID: 2089
	// (get) Token: 0x060025FD RID: 9725 RVA: 0x0001C5FD File Offset: 0x0001A7FD
	// (set) Token: 0x060025FE RID: 9726 RVA: 0x0001C604 File Offset: 0x0001A804
	public static int Int32_129 { get; set; } = 551;

	// Token: 0x1700082A RID: 2090
	// (get) Token: 0x060025FF RID: 9727 RVA: 0x0001C60C File Offset: 0x0001A80C
	// (set) Token: 0x06002600 RID: 9728 RVA: 0x0001C613 File Offset: 0x0001A813
	public static int Int32_130 { get; set; } = 699;

	// Token: 0x1700082B RID: 2091
	// (get) Token: 0x06002601 RID: 9729 RVA: 0x0001C61B File Offset: 0x0001A81B
	// (set) Token: 0x06002602 RID: 9730 RVA: 0x0001C622 File Offset: 0x0001A822
	public static int Int32_131 { get; set; } = 698;

	// Token: 0x1700082C RID: 2092
	// (get) Token: 0x06002603 RID: 9731 RVA: 0x0001C62A File Offset: 0x0001A82A
	// (set) Token: 0x06002604 RID: 9732 RVA: 0x0001C631 File Offset: 0x0001A831
	public static int Int32_132 { get; set; } = 300;

	// Token: 0x1700082D RID: 2093
	// (get) Token: 0x06002605 RID: 9733 RVA: 0x0001C639 File Offset: 0x0001A839
	// (set) Token: 0x06002606 RID: 9734 RVA: 0x0001C640 File Offset: 0x0001A840
	public static int Int32_133 { get; set; } = 697;

	// Token: 0x1700082E RID: 2094
	// (get) Token: 0x06002607 RID: 9735 RVA: 0x0001C648 File Offset: 0x0001A848
	// (set) Token: 0x06002608 RID: 9736 RVA: 0x0001C64F File Offset: 0x0001A84F
	public static int Int32_134 { get; set; } = 233;

	// Token: 0x1700082F RID: 2095
	// (get) Token: 0x06002609 RID: 9737 RVA: 0x0001C657 File Offset: 0x0001A857
	// (set) Token: 0x0600260A RID: 9738 RVA: 0x0001C65E File Offset: 0x0001A85E
	public static int Int32_135 { get; set; } = 224;

	// Token: 0x17000830 RID: 2096
	// (get) Token: 0x0600260B RID: 9739 RVA: 0x0001C666 File Offset: 0x0001A866
	// (set) Token: 0x0600260C RID: 9740 RVA: 0x0001C66D File Offset: 0x0001A86D
	public static int Int32_136 { get; set; } = 738;

	// Token: 0x17000831 RID: 2097
	// (get) Token: 0x0600260D RID: 9741 RVA: 0x0001C675 File Offset: 0x0001A875
	// (set) Token: 0x0600260E RID: 9742 RVA: 0x0001C67C File Offset: 0x0001A87C
	public static int Int32_137 { get; set; } = 755;

	// Token: 0x17000832 RID: 2098
	// (get) Token: 0x0600260F RID: 9743 RVA: 0x0001C684 File Offset: 0x0001A884
	// (set) Token: 0x06002610 RID: 9744 RVA: 0x0001C68B File Offset: 0x0001A88B
	public static int Int32_138 { get; set; } = 762;

	// Token: 0x17000833 RID: 2099
	// (get) Token: 0x06002611 RID: 9745 RVA: 0x0001C693 File Offset: 0x0001A893
	// (set) Token: 0x06002612 RID: 9746 RVA: 0x0001C69A File Offset: 0x0001A89A
	public static int Int32_139 { get; set; } = 234;

	// Token: 0x17000834 RID: 2100
	// (get) Token: 0x06002613 RID: 9747 RVA: 0x0001C6A2 File Offset: 0x0001A8A2
	// (set) Token: 0x06002614 RID: 9748 RVA: 0x0001C6A9 File Offset: 0x0001A8A9
	public static int Int32_140 { get; set; } = 724;

	// Token: 0x17000835 RID: 2101
	// (get) Token: 0x06002615 RID: 9749 RVA: 0x0001C6B1 File Offset: 0x0001A8B1
	// (set) Token: 0x06002616 RID: 9750 RVA: 0x0001C6B8 File Offset: 0x0001A8B8
	public static int Int32_141 { get; set; } = 725;

	// Token: 0x17000836 RID: 2102
	// (get) Token: 0x06002617 RID: 9751 RVA: 0x0001C6C0 File Offset: 0x0001A8C0
	// (set) Token: 0x06002618 RID: 9752 RVA: 0x0001C6C7 File Offset: 0x0001A8C7
	public static int Int32_142 { get; set; } = 726;

	// Token: 0x17000837 RID: 2103
	// (get) Token: 0x06002619 RID: 9753 RVA: 0x0001C6CF File Offset: 0x0001A8CF
	// (set) Token: 0x0600261A RID: 9754 RVA: 0x0001C6D6 File Offset: 0x0001A8D6
	public static int Int32_143 { get; set; } = 727;

	// Token: 0x17000838 RID: 2104
	// (get) Token: 0x0600261B RID: 9755 RVA: 0x0001C6DE File Offset: 0x0001A8DE
	// (set) Token: 0x0600261C RID: 9756 RVA: 0x0001C6E5 File Offset: 0x0001A8E5
	public static int Int32_144 { get; set; } = 770;

	// Token: 0x17000839 RID: 2105
	// (get) Token: 0x0600261D RID: 9757 RVA: 0x0001C6ED File Offset: 0x0001A8ED
	// (set) Token: 0x0600261E RID: 9758 RVA: 0x0001C6F4 File Offset: 0x0001A8F4
	public static int Int32_145 { get; set; } = 202;

	// Token: 0x1700083A RID: 2106
	// (get) Token: 0x0600261F RID: 9759 RVA: 0x0001C6FC File Offset: 0x0001A8FC
	// (set) Token: 0x06002620 RID: 9760 RVA: 0x0001C703 File Offset: 0x0001A903
	public static int Int32_146 { get; set; } = 752;

	// Token: 0x1700083B RID: 2107
	// (get) Token: 0x06002621 RID: 9761 RVA: 0x0001C70B File Offset: 0x0001A90B
	// (set) Token: 0x06002622 RID: 9762 RVA: 0x0001C712 File Offset: 0x0001A912
	public static int Int32_147 { get; set; } = 749;

	// Token: 0x1700083C RID: 2108
	// (get) Token: 0x06002623 RID: 9763 RVA: 0x0001C71A File Offset: 0x0001A91A
	// (set) Token: 0x06002624 RID: 9764 RVA: 0x0001C721 File Offset: 0x0001A921
	public static int Int32_148 { get; set; } = 750;

	// Token: 0x1700083D RID: 2109
	// (get) Token: 0x06002625 RID: 9765 RVA: 0x0001C729 File Offset: 0x0001A929
	// (set) Token: 0x06002626 RID: 9766 RVA: 0x0001C730 File Offset: 0x0001A930
	public static int Int32_149 { get; set; } = 756;

	// Token: 0x1700083E RID: 2110
	// (get) Token: 0x06002627 RID: 9767 RVA: 0x0001C738 File Offset: 0x0001A938
	// (set) Token: 0x06002628 RID: 9768 RVA: 0x0001C73F File Offset: 0x0001A93F
	public static int Int32_150 { get; set; } = 769;

	// Token: 0x04001918 RID: 6424
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x04001919 RID: 6425
	[CompilerGenerated]
	private static int int_1;

	// Token: 0x0400191A RID: 6426
	[CompilerGenerated]
	private static int int_2;

	// Token: 0x0400191B RID: 6427
	[CompilerGenerated]
	private static int int_3;

	// Token: 0x0400191C RID: 6428
	[CompilerGenerated]
	private static int int_4;

	// Token: 0x0400191D RID: 6429
	[CompilerGenerated]
	private static int int_5;

	// Token: 0x0400191E RID: 6430
	[CompilerGenerated]
	private static int int_6;

	// Token: 0x0400191F RID: 6431
	[CompilerGenerated]
	private static int int_7;

	// Token: 0x04001920 RID: 6432
	[CompilerGenerated]
	private static int int_8;

	// Token: 0x04001921 RID: 6433
	[CompilerGenerated]
	private static int int_9;

	// Token: 0x04001922 RID: 6434
	[CompilerGenerated]
	private static int int_10;

	// Token: 0x04001923 RID: 6435
	[CompilerGenerated]
	private static int int_11;

	// Token: 0x04001924 RID: 6436
	[CompilerGenerated]
	private static int int_12;

	// Token: 0x04001925 RID: 6437
	[CompilerGenerated]
	private static int int_13;

	// Token: 0x04001926 RID: 6438
	[CompilerGenerated]
	private static int int_14;

	// Token: 0x04001927 RID: 6439
	[CompilerGenerated]
	private static int int_15;

	// Token: 0x04001928 RID: 6440
	[CompilerGenerated]
	private static int int_16;

	// Token: 0x04001929 RID: 6441
	[CompilerGenerated]
	private static int int_17;

	// Token: 0x0400192A RID: 6442
	[CompilerGenerated]
	private static int int_18;

	// Token: 0x0400192B RID: 6443
	[CompilerGenerated]
	private static int int_19;

	// Token: 0x0400192C RID: 6444
	[CompilerGenerated]
	private static int int_20;

	// Token: 0x0400192D RID: 6445
	[CompilerGenerated]
	private static int int_21;

	// Token: 0x0400192E RID: 6446
	[CompilerGenerated]
	private static int int_22;

	// Token: 0x0400192F RID: 6447
	[CompilerGenerated]
	private static int int_23;

	// Token: 0x04001930 RID: 6448
	[CompilerGenerated]
	private static int int_24;

	// Token: 0x04001931 RID: 6449
	[CompilerGenerated]
	private static int int_25;

	// Token: 0x04001932 RID: 6450
	[CompilerGenerated]
	private static int int_26;

	// Token: 0x04001933 RID: 6451
	[CompilerGenerated]
	private static int int_27;

	// Token: 0x04001934 RID: 6452
	[CompilerGenerated]
	private static int int_28;

	// Token: 0x04001935 RID: 6453
	[CompilerGenerated]
	private static int int_29;

	// Token: 0x04001936 RID: 6454
	[CompilerGenerated]
	private static int int_30;

	// Token: 0x04001937 RID: 6455
	[CompilerGenerated]
	private static int int_31;

	// Token: 0x04001938 RID: 6456
	[CompilerGenerated]
	private static int int_32;

	// Token: 0x04001939 RID: 6457
	[CompilerGenerated]
	private static int int_33;

	// Token: 0x0400193A RID: 6458
	[CompilerGenerated]
	private static int int_34;

	// Token: 0x0400193B RID: 6459
	[CompilerGenerated]
	private static int int_35;

	// Token: 0x0400193C RID: 6460
	[CompilerGenerated]
	private static int int_36;

	// Token: 0x0400193D RID: 6461
	[CompilerGenerated]
	private static int int_37;

	// Token: 0x0400193E RID: 6462
	[CompilerGenerated]
	private static int int_38;

	// Token: 0x0400193F RID: 6463
	[CompilerGenerated]
	private static int int_39;

	// Token: 0x04001940 RID: 6464
	[CompilerGenerated]
	private static int int_40;

	// Token: 0x04001941 RID: 6465
	[CompilerGenerated]
	private static int int_41;

	// Token: 0x04001942 RID: 6466
	[CompilerGenerated]
	private static int int_42;

	// Token: 0x04001943 RID: 6467
	[CompilerGenerated]
	private static int int_43;

	// Token: 0x04001944 RID: 6468
	[CompilerGenerated]
	private static int int_44;

	// Token: 0x04001945 RID: 6469
	[CompilerGenerated]
	private static int int_45;

	// Token: 0x04001946 RID: 6470
	[CompilerGenerated]
	private static int int_46;

	// Token: 0x04001947 RID: 6471
	[CompilerGenerated]
	private static int int_47;

	// Token: 0x04001948 RID: 6472
	[CompilerGenerated]
	private static int int_48;

	// Token: 0x04001949 RID: 6473
	[CompilerGenerated]
	private static int int_49;

	// Token: 0x0400194A RID: 6474
	[CompilerGenerated]
	private static int int_50;

	// Token: 0x0400194B RID: 6475
	[CompilerGenerated]
	private static int int_51;

	// Token: 0x0400194C RID: 6476
	[CompilerGenerated]
	private static int int_52;

	// Token: 0x0400194D RID: 6477
	[CompilerGenerated]
	private static int int_53;

	// Token: 0x0400194E RID: 6478
	[CompilerGenerated]
	private static int int_54;

	// Token: 0x0400194F RID: 6479
	[CompilerGenerated]
	private static int int_55;

	// Token: 0x04001950 RID: 6480
	[CompilerGenerated]
	private static int int_56;

	// Token: 0x04001951 RID: 6481
	[CompilerGenerated]
	private static int int_57;

	// Token: 0x04001952 RID: 6482
	[CompilerGenerated]
	private static int int_58;

	// Token: 0x04001953 RID: 6483
	[CompilerGenerated]
	private static int int_59;

	// Token: 0x04001954 RID: 6484
	[CompilerGenerated]
	private static int int_60;

	// Token: 0x04001955 RID: 6485
	[CompilerGenerated]
	private static int int_61;

	// Token: 0x04001956 RID: 6486
	[CompilerGenerated]
	private static int int_62;

	// Token: 0x04001957 RID: 6487
	[CompilerGenerated]
	private static int int_63;

	// Token: 0x04001958 RID: 6488
	[CompilerGenerated]
	private static int int_64;

	// Token: 0x04001959 RID: 6489
	[CompilerGenerated]
	private static int int_65;

	// Token: 0x0400195A RID: 6490
	[CompilerGenerated]
	private static int int_66;

	// Token: 0x0400195B RID: 6491
	[CompilerGenerated]
	private static int int_67;

	// Token: 0x0400195C RID: 6492
	[CompilerGenerated]
	private static int int_68;

	// Token: 0x0400195D RID: 6493
	[CompilerGenerated]
	private static int int_69;

	// Token: 0x0400195E RID: 6494
	[CompilerGenerated]
	private static int int_70;

	// Token: 0x0400195F RID: 6495
	[CompilerGenerated]
	private static int int_71;

	// Token: 0x04001960 RID: 6496
	[CompilerGenerated]
	private static int int_72;

	// Token: 0x04001961 RID: 6497
	[CompilerGenerated]
	private static int int_73;

	// Token: 0x04001962 RID: 6498
	[CompilerGenerated]
	private static int int_74;

	// Token: 0x04001963 RID: 6499
	[CompilerGenerated]
	private static int int_75;

	// Token: 0x04001964 RID: 6500
	[CompilerGenerated]
	private static int int_76;

	// Token: 0x04001965 RID: 6501
	[CompilerGenerated]
	private static int int_77;

	// Token: 0x04001966 RID: 6502
	[CompilerGenerated]
	private static int int_78;

	// Token: 0x04001967 RID: 6503
	[CompilerGenerated]
	private static int int_79;

	// Token: 0x04001968 RID: 6504
	[CompilerGenerated]
	private static int int_80;

	// Token: 0x04001969 RID: 6505
	[CompilerGenerated]
	private static int int_81;

	// Token: 0x0400196A RID: 6506
	[CompilerGenerated]
	private static int int_82;

	// Token: 0x0400196B RID: 6507
	[CompilerGenerated]
	private static int int_83;

	// Token: 0x0400196C RID: 6508
	[CompilerGenerated]
	private static int int_84;

	// Token: 0x0400196D RID: 6509
	[CompilerGenerated]
	private static int int_85;

	// Token: 0x0400196E RID: 6510
	[CompilerGenerated]
	private static int int_86;

	// Token: 0x0400196F RID: 6511
	[CompilerGenerated]
	private static int int_87;

	// Token: 0x04001970 RID: 6512
	[CompilerGenerated]
	private static int int_88;

	// Token: 0x04001971 RID: 6513
	[CompilerGenerated]
	private static int int_89;

	// Token: 0x04001972 RID: 6514
	[CompilerGenerated]
	private static int int_90;

	// Token: 0x04001973 RID: 6515
	[CompilerGenerated]
	private static int int_91;

	// Token: 0x04001974 RID: 6516
	[CompilerGenerated]
	private static int int_92;

	// Token: 0x04001975 RID: 6517
	[CompilerGenerated]
	private static int int_93;

	// Token: 0x04001976 RID: 6518
	[CompilerGenerated]
	private static int int_94;

	// Token: 0x04001977 RID: 6519
	[CompilerGenerated]
	private static int int_95;

	// Token: 0x04001978 RID: 6520
	[CompilerGenerated]
	private static int int_96;

	// Token: 0x04001979 RID: 6521
	[CompilerGenerated]
	private static int int_97;

	// Token: 0x0400197A RID: 6522
	[CompilerGenerated]
	private static int int_98;

	// Token: 0x0400197B RID: 6523
	[CompilerGenerated]
	private static int int_99;

	// Token: 0x0400197C RID: 6524
	[CompilerGenerated]
	private static int int_100;

	// Token: 0x0400197D RID: 6525
	[CompilerGenerated]
	private static int int_101;

	// Token: 0x0400197E RID: 6526
	[CompilerGenerated]
	private static int int_102;

	// Token: 0x0400197F RID: 6527
	[CompilerGenerated]
	private static int int_103;

	// Token: 0x04001980 RID: 6528
	[CompilerGenerated]
	private static int int_104;

	// Token: 0x04001981 RID: 6529
	[CompilerGenerated]
	private static int int_105;

	// Token: 0x04001982 RID: 6530
	[CompilerGenerated]
	private static int int_106;

	// Token: 0x04001983 RID: 6531
	[CompilerGenerated]
	private static int int_107;

	// Token: 0x04001984 RID: 6532
	[CompilerGenerated]
	private static int int_108;

	// Token: 0x04001985 RID: 6533
	[CompilerGenerated]
	private static int int_109;

	// Token: 0x04001986 RID: 6534
	[CompilerGenerated]
	private static int int_110;

	// Token: 0x04001987 RID: 6535
	[CompilerGenerated]
	private static int int_111;

	// Token: 0x04001988 RID: 6536
	[CompilerGenerated]
	private static int int_112;

	// Token: 0x04001989 RID: 6537
	[CompilerGenerated]
	private static int int_113;

	// Token: 0x0400198A RID: 6538
	[CompilerGenerated]
	private static int int_114;

	// Token: 0x0400198B RID: 6539
	[CompilerGenerated]
	private static int int_115;

	// Token: 0x0400198C RID: 6540
	[CompilerGenerated]
	private static int int_116;

	// Token: 0x0400198D RID: 6541
	[CompilerGenerated]
	private static int int_117;

	// Token: 0x0400198E RID: 6542
	[CompilerGenerated]
	private static int int_118;

	// Token: 0x0400198F RID: 6543
	[CompilerGenerated]
	private static int int_119;

	// Token: 0x04001990 RID: 6544
	[CompilerGenerated]
	private static int int_120;

	// Token: 0x04001991 RID: 6545
	[CompilerGenerated]
	private static int int_121;

	// Token: 0x04001992 RID: 6546
	[CompilerGenerated]
	private static int int_122;

	// Token: 0x04001993 RID: 6547
	[CompilerGenerated]
	private static int int_123;

	// Token: 0x04001994 RID: 6548
	[CompilerGenerated]
	private static int int_124;

	// Token: 0x04001995 RID: 6549
	[CompilerGenerated]
	private static int int_125;

	// Token: 0x04001996 RID: 6550
	[CompilerGenerated]
	private static int int_126;

	// Token: 0x04001997 RID: 6551
	[CompilerGenerated]
	private static int int_127;

	// Token: 0x04001998 RID: 6552
	[CompilerGenerated]
	private static int int_128;

	// Token: 0x04001999 RID: 6553
	[CompilerGenerated]
	private static int int_129;

	// Token: 0x0400199A RID: 6554
	[CompilerGenerated]
	private static int int_130;

	// Token: 0x0400199B RID: 6555
	[CompilerGenerated]
	private static int int_131;

	// Token: 0x0400199C RID: 6556
	[CompilerGenerated]
	private static int int_132;

	// Token: 0x0400199D RID: 6557
	[CompilerGenerated]
	private static int int_133;

	// Token: 0x0400199E RID: 6558
	[CompilerGenerated]
	private static int int_134;

	// Token: 0x0400199F RID: 6559
	[CompilerGenerated]
	private static int int_135;

	// Token: 0x040019A0 RID: 6560
	[CompilerGenerated]
	private static int int_136;

	// Token: 0x040019A1 RID: 6561
	[CompilerGenerated]
	private static int int_137;

	// Token: 0x040019A2 RID: 6562
	[CompilerGenerated]
	private static int int_138;

	// Token: 0x040019A3 RID: 6563
	[CompilerGenerated]
	private static int int_139;

	// Token: 0x040019A4 RID: 6564
	[CompilerGenerated]
	private static int int_140;

	// Token: 0x040019A5 RID: 6565
	[CompilerGenerated]
	private static int int_141;

	// Token: 0x040019A6 RID: 6566
	[CompilerGenerated]
	private static int int_142;

	// Token: 0x040019A7 RID: 6567
	[CompilerGenerated]
	private static int int_143;

	// Token: 0x040019A8 RID: 6568
	[CompilerGenerated]
	private static int int_144;

	// Token: 0x040019A9 RID: 6569
	[CompilerGenerated]
	private static int int_145;

	// Token: 0x040019AA RID: 6570
	[CompilerGenerated]
	private static int int_146;

	// Token: 0x040019AB RID: 6571
	[CompilerGenerated]
	private static int int_147;

	// Token: 0x040019AC RID: 6572
	[CompilerGenerated]
	private static int int_148;

	// Token: 0x040019AD RID: 6573
	[CompilerGenerated]
	private static int int_149;

	// Token: 0x040019AE RID: 6574
	[CompilerGenerated]
	private static int int_150;
}
