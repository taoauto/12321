﻿using System;

// Token: 0x02000146 RID: 326
public enum GEnum21 : byte
{
	// Token: 0x04000834 RID: 2100
	NeedToPrepare,
	// Token: 0x04000835 RID: 2101
	Preparing,
	// Token: 0x04000836 RID: 2102
	WaitingForReconnect,
	// Token: 0x04000837 RID: 2103
	Prepared,
	// Token: 0x04000838 RID: 2104
	Working,
	// Token: 0x04000839 RID: 2105
	Pausing,
	// Token: 0x0400083A RID: 2106
	Paused,
	// Token: 0x0400083B RID: 2107
	Ended,
	// Token: 0x0400083C RID: 2108
	EndedWithError
}
