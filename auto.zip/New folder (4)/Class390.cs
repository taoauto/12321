﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020002C3 RID: 707
internal class Class390
{
	// Token: 0x1700089E RID: 2206
	// (get) Token: 0x0600277B RID: 10107 RVA: 0x0001D52C File Offset: 0x0001B72C
	// (set) Token: 0x0600277C RID: 10108 RVA: 0x0001D534 File Offset: 0x0001B734
	public uint UInt32_0 { get; set; }

	// Token: 0x1700089F RID: 2207
	// (get) Token: 0x0600277D RID: 10109 RVA: 0x0001D53D File Offset: 0x0001B73D
	// (set) Token: 0x0600277E RID: 10110 RVA: 0x0001D545 File Offset: 0x0001B745
	public uint UInt32_1 { get; set; }

	// Token: 0x170008A0 RID: 2208
	// (get) Token: 0x0600277F RID: 10111 RVA: 0x0001D54E File Offset: 0x0001B74E
	// (set) Token: 0x06002780 RID: 10112 RVA: 0x0001D556 File Offset: 0x0001B756
	public uint UInt32_2 { get; set; }

	// Token: 0x170008A1 RID: 2209
	// (get) Token: 0x06002781 RID: 10113 RVA: 0x0001D55F File Offset: 0x0001B75F
	// (set) Token: 0x06002782 RID: 10114 RVA: 0x0001D567 File Offset: 0x0001B767
	public uint UInt32_3 { get; set; }

	// Token: 0x170008A2 RID: 2210
	// (get) Token: 0x06002783 RID: 10115 RVA: 0x0001D570 File Offset: 0x0001B770
	// (set) Token: 0x06002784 RID: 10116 RVA: 0x0001D578 File Offset: 0x0001B778
	public string String_0 { get; set; }

	// Token: 0x170008A3 RID: 2211
	// (get) Token: 0x06002785 RID: 10117 RVA: 0x0001D581 File Offset: 0x0001B781
	// (set) Token: 0x06002786 RID: 10118 RVA: 0x0001D589 File Offset: 0x0001B789
	public string String_1 { get; set; }

	// Token: 0x170008A4 RID: 2212
	// (get) Token: 0x06002787 RID: 10119 RVA: 0x0001D592 File Offset: 0x0001B792
	// (set) Token: 0x06002788 RID: 10120 RVA: 0x0001D59A File Offset: 0x0001B79A
	public uint UInt32_4 { get; set; }

	// Token: 0x170008A5 RID: 2213
	// (get) Token: 0x06002789 RID: 10121 RVA: 0x00118D1C File Offset: 0x00116F1C
	public bool Boolean_0
	{
		get
		{
			return !this.String_1.Contains("FightSkillXinShou_12") && (this.String_1.Contains("FightSkill") || this.String_1.Contains("FabaoSkill") || this.String_1.Contains("MiJiSkill") || this.String_1.Contains("fuqiskill") || this.String_1.Contains("Shoes2_5") || this.String_1.Contains("RideHeader1_1") || this.String_1.Contains("MenpaiLiveSkill2_7") || (this.String_1.Contains("WuhunSkill") && this.UInt32_4 > 100U) || this.String_1.Contains("TaskTools2_13") || this.String_1.Contains("PetSkill2_4") || this.String_1.Contains("CommonLiveSkill2_2") || this.String_1.Contains("CircularTaskTool43_2") || this.String_1.Contains("Shoes2_4") || this.String_1.Contains("TaskTools4_1"));
		}
	}

	// Token: 0x0600278A RID: 10122 RVA: 0x0001D5A3 File Offset: 0x0001B7A3
	public static IEnumerable<Class390> smethod_0(Class159 class159_0)
	{
		Class390.Class391 @class = new Class390.Class391(-2);
		@class.class159_1 = class159_0;
		return @class;
	}

	// Token: 0x0600278B RID: 10123 RVA: 0x00118E6C File Offset: 0x0011706C
	private static HashSet<uint> smethod_1(uint uint_5, Class159 class159_0)
	{
		HashSet<uint> hashSet = new HashSet<uint>();
		Class390.smethod_3(uint_5, hashSet, class159_0);
		hashSet.Remove(uint_5);
		return hashSet;
	}

	// Token: 0x0600278C RID: 10124 RVA: 0x00118E90 File Offset: 0x00117090
	public static HashSet<uint> smethod_2(uint[] uint_5, Class159 class159_0)
	{
		uint num = class159_0.Class405_0.method_20(uint_5);
		if (num > 0U)
		{
			return Class390.smethod_1(num, class159_0);
		}
		return new HashSet<uint>();
	}

	// Token: 0x0600278D RID: 10125 RVA: 0x00118EBC File Offset: 0x001170BC
	private static void smethod_3(uint uint_5, HashSet<uint> hashSet_0, Class159 class159_0)
	{
		if (hashSet_0.Count > 10000)
		{
			return;
		}
		if (!hashSet_0.Contains(uint_5) && uint_5 > 0U)
		{
			hashSet_0.Add(uint_5);
			Class390.smethod_3(class159_0.Class405_0.method_11(uint_5), hashSet_0, class159_0);
			Class390.smethod_3(class159_0.Class405_0.method_11(uint_5 + 4U), hashSet_0, class159_0);
			Class390.smethod_3(class159_0.Class405_0.method_11(uint_5 + 8U), hashSet_0, class159_0);
		}
	}

	// Token: 0x04001ACC RID: 6860
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001ACD RID: 6861
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001ACE RID: 6862
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001ACF RID: 6863
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001AD0 RID: 6864
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001AD1 RID: 6865
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001AD2 RID: 6866
	[CompilerGenerated]
	private uint uint_4;
}
