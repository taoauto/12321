﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x020002E3 RID: 739
internal class Class406
{
	// Token: 0x1700099F RID: 2463
	// (get) Token: 0x06002A72 RID: 10866 RVA: 0x0001EED8 File Offset: 0x0001D0D8
	// (set) Token: 0x06002A73 RID: 10867 RVA: 0x0001EEE0 File Offset: 0x0001D0E0
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x170009A0 RID: 2464
	// (get) Token: 0x06002A74 RID: 10868 RVA: 0x0001EEE9 File Offset: 0x0001D0E9
	// (set) Token: 0x06002A75 RID: 10869 RVA: 0x0001EEF1 File Offset: 0x0001D0F1
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
		}
	}

	// Token: 0x170009A1 RID: 2465
	// (get) Token: 0x06002A76 RID: 10870 RVA: 0x0001EEFA File Offset: 0x0001D0FA
	// (set) Token: 0x06002A77 RID: 10871 RVA: 0x0001EF02 File Offset: 0x0001D102
	public RegistryKey RegistryKey_0
	{
		get
		{
			return this.registryKey_0;
		}
		set
		{
			this.registryKey_0 = value;
		}
	}

	// Token: 0x06002A78 RID: 10872 RVA: 0x00120524 File Offset: 0x0011E724
	public string method_0(string string_1)
	{
		RegistryKey registryKey = this.registryKey_0.OpenSubKey(this.string_0);
		if (registryKey == null)
		{
			return null;
		}
		string result;
		try
		{
			result = (string)registryKey.GetValue(string_1.ToUpper());
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Reading registry " + string_1.ToUpper());
			result = null;
		}
		return result;
	}

	// Token: 0x06002A79 RID: 10873 RVA: 0x0012058C File Offset: 0x0011E78C
	public bool method_1(string string_1, object object_0)
	{
		bool result;
		try
		{
			this.registryKey_0.CreateSubKey(this.string_0).SetValue(string_1.ToUpper(), object_0);
			result = true;
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Writing registry " + string_1.ToUpper());
			result = false;
		}
		return result;
	}

	// Token: 0x06002A7A RID: 10874 RVA: 0x001205E8 File Offset: 0x0011E7E8
	public bool method_2(string string_1)
	{
		bool result;
		try
		{
			RegistryKey registryKey = this.registryKey_0.CreateSubKey(this.string_0);
			if (registryKey == null)
			{
				result = true;
			}
			else
			{
				registryKey.DeleteValue(string_1);
				result = true;
			}
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Deleting SubKey " + this.string_0);
			result = false;
		}
		return result;
	}

	// Token: 0x06002A7B RID: 10875 RVA: 0x00120648 File Offset: 0x0011E848
	public bool method_3()
	{
		bool result;
		try
		{
			RegistryKey registryKey = this.registryKey_0;
			if (registryKey.OpenSubKey(this.string_0) != null)
			{
				registryKey.DeleteSubKeyTree(this.string_0);
			}
			result = true;
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Deleting SubKey " + this.string_0);
			result = false;
		}
		return result;
	}

	// Token: 0x06002A7C RID: 10876 RVA: 0x001206A8 File Offset: 0x0011E8A8
	public int method_4()
	{
		int result;
		try
		{
			RegistryKey registryKey = this.registryKey_0.OpenSubKey(this.string_0);
			if (registryKey != null)
			{
				result = registryKey.SubKeyCount;
			}
			else
			{
				result = 0;
			}
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Retriving subkeys of " + this.string_0);
			result = 0;
		}
		return result;
	}

	// Token: 0x06002A7D RID: 10877 RVA: 0x00120704 File Offset: 0x0011E904
	public int method_5()
	{
		int result;
		try
		{
			RegistryKey registryKey = this.registryKey_0.OpenSubKey(this.string_0);
			if (registryKey != null)
			{
				result = registryKey.ValueCount;
			}
			else
			{
				result = 0;
			}
		}
		catch (Exception exception_)
		{
			this.method_6(exception_, "Retriving keys of " + this.string_0);
			result = 0;
		}
		return result;
	}

	// Token: 0x06002A7E RID: 10878 RVA: 0x0001EF0B File Offset: 0x0001D10B
	private void method_6(Exception exception_0, string string_1)
	{
		if (this.bool_0)
		{
			MessageBox.Show(exception_0.Message, string_1, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	// Token: 0x04001C53 RID: 7251
	private bool bool_0;

	// Token: 0x04001C54 RID: 7252
	private string string_0 = "SOFTWARE\\" + Application.ProductName.ToUpper();

	// Token: 0x04001C55 RID: 7253
	private RegistryKey registryKey_0 = Registry.LocalMachine;
}
