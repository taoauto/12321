﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020002F7 RID: 759
internal class Class417
{
	// Token: 0x170009DD RID: 2525
	// (get) Token: 0x06002B9F RID: 11167 RVA: 0x0001FE81 File Offset: 0x0001E081
	// (set) Token: 0x06002BA0 RID: 11168 RVA: 0x0001FE89 File Offset: 0x0001E089
	public uint UInt32_0 { get; set; }

	// Token: 0x170009DE RID: 2526
	// (get) Token: 0x06002BA1 RID: 11169 RVA: 0x0001FE92 File Offset: 0x0001E092
	// (set) Token: 0x06002BA2 RID: 11170 RVA: 0x0001FE9A File Offset: 0x0001E09A
	public uint UInt32_1 { get; set; }

	// Token: 0x170009DF RID: 2527
	// (get) Token: 0x06002BA3 RID: 11171 RVA: 0x0001FEA3 File Offset: 0x0001E0A3
	// (set) Token: 0x06002BA4 RID: 11172 RVA: 0x0001FEAB File Offset: 0x0001E0AB
	public uint UInt32_2 { get; set; }

	// Token: 0x170009E0 RID: 2528
	// (get) Token: 0x06002BA5 RID: 11173 RVA: 0x0001FEB4 File Offset: 0x0001E0B4
	// (set) Token: 0x06002BA6 RID: 11174 RVA: 0x0001FEBC File Offset: 0x0001E0BC
	public uint UInt32_3 { get; set; }

	// Token: 0x170009E1 RID: 2529
	// (get) Token: 0x06002BA7 RID: 11175 RVA: 0x0001FEC5 File Offset: 0x0001E0C5
	// (set) Token: 0x06002BA8 RID: 11176 RVA: 0x0001FECD File Offset: 0x0001E0CD
	public uint UInt32_4 { get; set; }

	// Token: 0x170009E2 RID: 2530
	// (get) Token: 0x06002BA9 RID: 11177 RVA: 0x0001FED6 File Offset: 0x0001E0D6
	// (set) Token: 0x06002BAA RID: 11178 RVA: 0x0001FEDE File Offset: 0x0001E0DE
	public uint UInt32_5 { get; set; }

	// Token: 0x170009E3 RID: 2531
	// (get) Token: 0x06002BAB RID: 11179 RVA: 0x0001FEE7 File Offset: 0x0001E0E7
	// (set) Token: 0x06002BAC RID: 11180 RVA: 0x0001FEEF File Offset: 0x0001E0EF
	public string String_0 { get; set; }

	// Token: 0x170009E4 RID: 2532
	// (get) Token: 0x06002BAD RID: 11181 RVA: 0x0001FEF8 File Offset: 0x0001E0F8
	// (set) Token: 0x06002BAE RID: 11182 RVA: 0x0001FF00 File Offset: 0x0001E100
	public string String_1 { get; set; }

	// Token: 0x170009E5 RID: 2533
	// (get) Token: 0x06002BAF RID: 11183 RVA: 0x0001FF09 File Offset: 0x0001E109
	// (set) Token: 0x06002BB0 RID: 11184 RVA: 0x0001FF11 File Offset: 0x0001E111
	public bool Boolean_0 { get; set; }

	// Token: 0x170009E6 RID: 2534
	// (get) Token: 0x06002BB1 RID: 11185 RVA: 0x0001FF1A File Offset: 0x0001E11A
	// (set) Token: 0x06002BB2 RID: 11186 RVA: 0x0001FF22 File Offset: 0x0001E122
	public bool Boolean_1
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x06002BB3 RID: 11187 RVA: 0x0001FF2B File Offset: 0x0001E12B
	public Class417(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x06002BB4 RID: 11188 RVA: 0x0001FF3A File Offset: 0x0001E13A
	public static bool smethod_0(int int_0)
	{
		return "-311-341-371-281-401-431-461-491-521-760-2900-3430-;".Contains("-" + int_0.ToString() + "-");
	}

	// Token: 0x06002BB5 RID: 11189 RVA: 0x00126444 File Offset: 0x00124644
	public static bool smethod_1(int int_0)
	{
		return "-328-358-388-298-418-448-478-508-538-778-2918-".Contains("-" + int_0.ToString() + "-") || "-329-359-389-299-419-449-479-509-539-779-2919-".Contains("-" + int_0.ToString() + "-") || "-330-360-390-300-420-450-480-510-540-780-2920-".Contains("-" + int_0.ToString() + "-");
	}

	// Token: 0x06002BB6 RID: 11190 RVA: 0x0001FF61 File Offset: 0x0001E161
	public static bool smethod_2(int int_0)
	{
		return "-328-358-388-298-418-448-478-508-538-778-2918-3448-".Contains("-" + int_0.ToString() + "-");
	}

	// Token: 0x06002BB7 RID: 11191 RVA: 0x0001FF88 File Offset: 0x0001E188
	public static bool smethod_3(int int_0)
	{
		return "-329-359-389-299-419-449-479-509-539-779-2919-3449-".Contains("-" + int_0.ToString() + "-");
	}

	// Token: 0x06002BB8 RID: 11192 RVA: 0x0001FFAF File Offset: 0x0001E1AF
	public static bool smethod_4(int int_0)
	{
		return "-330-360-390-300-420-450-480-510-540-780-2920-3450-".Contains("-" + int_0.ToString() + "-");
	}

	// Token: 0x06002BB9 RID: 11193 RVA: 0x0001FFD6 File Offset: 0x0001E1D6
	public static int smethod_5(int int_0)
	{
		if (int_0 == 402)
		{
			return 199;
		}
		return 0;
	}

	// Token: 0x06002BBA RID: 11194 RVA: 0x0001FFE7 File Offset: 0x0001E1E7
	public static int smethod_6(int int_0)
	{
		if (int_0 == 467)
		{
			return 36;
		}
		return 0;
	}

	// Token: 0x06002BBB RID: 11195 RVA: 0x001264C0 File Offset: 0x001246C0
	public static uint smethod_7(int int_0)
	{
		if (int_0 <= 318)
		{
			if (int_0 <= 289)
			{
				if (int_0 == 248)
				{
					return 1284U;
				}
				if (int_0 == 289)
				{
					return uint.MaxValue;
				}
			}
			else
			{
				if (int_0 == 317)
				{
					return 115U;
				}
				if (int_0 == 318)
				{
					return uint.MaxValue;
				}
			}
		}
		else if (int_0 <= 439)
		{
			if (int_0 == 438)
			{
				return 158U;
			}
			if (int_0 == 439)
			{
				return uint.MaxValue;
			}
		}
		else
		{
			if (int_0 == 468)
			{
				return 168U;
			}
			if (int_0 == 767)
			{
				return 1328U;
			}
			if (int_0 == 2907)
			{
				return 2611U;
			}
		}
		return 0U;
	}

	// Token: 0x06002BBC RID: 11196 RVA: 0x0012655C File Offset: 0x0012475C
	public static int smethod_8(int int_0)
	{
		if (int_0 <= 466)
		{
			if (int_0 <= 346)
			{
				if (int_0 <= 302)
				{
					if (int_0 == 286)
					{
						return 102;
					}
					if (int_0 == 302)
					{
						return 283;
					}
				}
				else
				{
					if (int_0 == 316)
					{
						return 114;
					}
					if (int_0 == 332)
					{
						return 284;
					}
					if (int_0 == 346)
					{
						return 124;
					}
				}
			}
			else if (int_0 <= 422)
			{
				if (int_0 == 362)
				{
					return 285;
				}
				if (int_0 == 392)
				{
					return 286;
				}
				if (int_0 == 422)
				{
					return 287;
				}
			}
			else
			{
				if (int_0 == 436)
				{
					return 154;
				}
				if (int_0 == 452)
				{
					return 288;
				}
				if (int_0 == 466)
				{
					return 166;
				}
			}
		}
		else if (int_0 <= 762)
		{
			if (int_0 <= 512)
			{
				if (int_0 == 482)
				{
					return 289;
				}
				if (int_0 == 512)
				{
					return 290;
				}
			}
			else
			{
				if (int_0 == 526)
				{
					return 189;
				}
				if (int_0 == 542)
				{
					return 291;
				}
				if (int_0 == 762)
				{
					return 1305;
				}
			}
		}
		else if (int_0 <= 2906)
		{
			if (int_0 == 766)
			{
				return 1308;
			}
			if (int_0 == 2902)
			{
				return 2607;
			}
			if (int_0 == 2906)
			{
				return 2610;
			}
		}
		else
		{
			if (int_0 == 3432)
			{
				return 3646;
			}
			if (int_0 == 3436)
			{
				return 3649;
			}
			if (int_0 == 3802)
			{
				return 4124;
			}
		}
		return 0;
	}

	// Token: 0x06002BBD RID: 11197 RVA: 0x0001FFF5 File Offset: 0x0001E1F5
	public static bool smethod_9(int int_0)
	{
		return int_0 == 395 || int_0 == 374 || int_0 == 3431 || int_0 == 3447 || int_0 == 3439;
	}

	// Token: 0x06002BBE RID: 11198 RVA: 0x001266F0 File Offset: 0x001248F0
	public virtual string ToString()
	{
		return "Address: " + this.UInt32_0.ToString("X8") + "\r\n" + "DelayOffset: " + this.UInt32_5.ToString("X8") + "\r\n" + "Name:" + this.String_0 + "\r\n" + "\r\n";
	}

	// Token: 0x06002BBF RID: 11199 RVA: 0x0012676C File Offset: 0x0012496C
	public static List<Class417> smethod_10(Class159 class159_1)
	{
		List<Class417> list = new List<Class417>();
		new List<int>();
		uint[] uint32_ = class159_1.Class392_0.UInt32_2;
		Array.Resize<uint>(ref uint32_, uint32_.Length + 2);
		if (class159_1.Class392_0.UInt32_106 == 1U)
		{
			uint32_[uint32_.Length - 2] = Class417.uint_6;
		}
		else if (class159_1.Class392_0.UInt32_106 == 2U)
		{
			uint32_[uint32_.Length - 2] = 1980U;
		}
		else
		{
			uint32_[uint32_.Length - 2] = 2768U;
		}
		uint32_[uint32_.Length - 1] = 4U;
		uint uint_ = class159_1.Class405_0.method_20(uint32_);
		List<uint> list2 = new List<uint>();
		try
		{
			Class417.smethod_11(uint_, list2, class159_1);
		}
		catch
		{
		}
		foreach (uint num in list2)
		{
			if (class159_1.Class392_0.UInt32_106 == 1U)
			{
				Class417 @class = new Class417(class159_1);
				@class.UInt32_0 = num;
				@class.UInt32_2 = class159_1.Class405_0.method_12(num + 13U);
				@class.UInt32_3 = class159_1.Class405_0.method_12(num + 16U);
				@class.UInt32_4 = class159_1.Class405_0.method_11(num + 16U);
				@class.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(num + 24U, 8U));
				@class.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(num + 24U, 12U));
				@class.UInt32_5 = class159_1.Class405_0.method_17(num + 24U, 52U) * 12U;
				if (@class.UInt32_4 > 0U && @class.UInt32_5 > 0U && @class.UInt32_5 < 65536U)
				{
					list.Add(@class);
				}
			}
			else
			{
				Class417 class2 = new Class417(class159_1);
				class2.UInt32_0 = num;
				class2.UInt32_4 = class159_1.Class405_0.method_11(num + 12U);
				class2.UInt32_5 = class159_1.Class405_0.method_17(num + 16U + 4U, 64U) * 12U;
				if (class2.UInt32_4 < 4096U)
				{
					list.Add(class2);
				}
			}
		}
		if (list.Count > 100)
		{
			list.Clear();
		}
		return list;
	}

	// Token: 0x06002BC0 RID: 11200 RVA: 0x001269D4 File Offset: 0x00124BD4
	public static void smethod_11(uint uint_7, List<uint> list_0, Class159 class159_1)
	{
		if (list_0.Contains(uint_7))
		{
			return;
		}
		if (list_0.Count > 110)
		{
			return;
		}
		list_0.Add(uint_7);
		Class417.smethod_11(class159_1.Class405_0.method_11(uint_7), list_0, class159_1);
		Class417.smethod_11(class159_1.Class405_0.method_11(uint_7 + 4U), list_0, class159_1);
		Class417.smethod_11(class159_1.Class405_0.method_11(uint_7 + 8U), list_0, class159_1);
	}

	// Token: 0x04001D0B RID: 7435
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001D0C RID: 7436
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001D0D RID: 7437
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001D0E RID: 7438
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001D0F RID: 7439
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04001D10 RID: 7440
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04001D11 RID: 7441
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001D12 RID: 7442
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001D13 RID: 7443
	private bool bool_0;

	// Token: 0x04001D14 RID: 7444
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04001D15 RID: 7445
	public Class159 class159_0;

	// Token: 0x04001D16 RID: 7446
	public static uint uint_6 = 17796U;
}
