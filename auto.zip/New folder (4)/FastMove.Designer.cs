﻿// Token: 0x02000198 RID: 408
public partial class FastMove : global::System.Windows.Forms.Form
{
	// Token: 0x06001297 RID: 4759 RVA: 0x00069DA0 File Offset: 0x00067FA0
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.textBoxEx1 = new global::Class85();
		this.listViewEx1 = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.mnu = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new global::System.Windows.Forms.ToolStripMenuItem();
		this.columnHeader_1 = new global::System.Windows.Forms.ColumnHeader();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.mnu.SuspendLayout();
		base.SuspendLayout();
		this.textBoxEx1.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.textBoxEx1.Location = new global::System.Drawing.Point(0, 0);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new global::System.Drawing.Size(328, 20);
		this.textBoxEx1.TabIndex = 0;
		this.textBoxEx1.String_0 = "Search...";
		this.textBoxEx1.Color_0 = global::System.Drawing.Color.Gray;
		this.textBoxEx1.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = global::System.Drawing.Color.LightGray;
		this.textBoxEx1.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.textBoxEx1_KeyDown);
		this.listViewEx1.AllowColumnReorder = true;
		this.listViewEx1.AllowDrop = true;
		this.listViewEx1.AllowReorder = true;
		this.listViewEx1.AllowSort = false;
		this.listViewEx1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.listViewEx1.ContextMenuStrip = this.mnu;
		this.listViewEx1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewEx1.FullRowSelect = true;
		this.listViewEx1.GridLines = true;
		this.listViewEx1.HideSelection = false;
		this.listViewEx1.LineColor = global::System.Drawing.Color.Red;
		this.listViewEx1.Location = new global::System.Drawing.Point(0, 20);
		this.listViewEx1.Name = "listViewEx1";
		this.listViewEx1.Size = new global::System.Drawing.Size(328, 325);
		this.listViewEx1.TabIndex = 1;
		this.listViewEx1.UseCompatibleStateImageBehavior = false;
		this.listViewEx1.View = global::System.Windows.Forms.View.Details;
		this.columnHeader_0.Text = "Map";
		this.columnHeader_0.Width = 245;
		this.mnu.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.toolStripMenuItem_0
		});
		this.mnu.Name = "mnu";
		this.mnu.Size = new global::System.Drawing.Size(130, 26);
		this.toolStripMenuItem_0.Name = "diChuyểnToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new global::System.Drawing.Size(180, 22);
		this.toolStripMenuItem_0.Text = "Di Chuyển";
		this.toolStripMenuItem_0.Click += new global::System.EventHandler(this.toolStripMenuItem_0_Click);
		this.columnHeader_1.Text = "ID";
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(328, 345);
		base.Controls.Add(this.listViewEx1);
		base.Controls.Add(this.textBoxEx1);
		base.Name = "FastMove";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Đại Thế Giới";
		base.Load += new global::System.EventHandler(this.FastMove_Load);
		this.mnu.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000A55 RID: 2645
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04000A56 RID: 2646
	private global::Class85 textBoxEx1;

	// Token: 0x04000A57 RID: 2647
	private global::_i.ListViewEx listViewEx1;

	// Token: 0x04000A58 RID: 2648
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x04000A59 RID: 2649
	private global::System.Windows.Forms.ContextMenuStrip mnu;

	// Token: 0x04000A5A RID: 2650
	private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000A5B RID: 2651
	private global::System.Windows.Forms.ColumnHeader columnHeader_1;

	// Token: 0x04000A5C RID: 2652
	private global::System.Windows.Forms.Timer timer_0;
}
