﻿using System;
using System.IO;

// Token: 0x02000083 RID: 131
internal class Stream3 : Stream2
{
	// Token: 0x060005C8 RID: 1480 RVA: 0x00006B1E File Offset: 0x00004D1E
	internal Stream3(Stream stream_1, byte[] byte_1, int int_3, int int_4, GClass38 gclass38_1) : base(stream_1, byte_1, int_3, int_4)
	{
		this.gclass38_0 = gclass38_1;
		this.class67_0 = new Class67((GClass45)gclass38_1.GClass40_0.NameValueCollection_0);
	}

	// Token: 0x1700017A RID: 378
	// (get) Token: 0x060005C9 RID: 1481 RVA: 0x00006B4F File Offset: 0x00004D4F
	// (set) Token: 0x060005CA RID: 1482 RVA: 0x00006B57 File Offset: 0x00004D57
	internal Class67 Class67_0
	{
		get
		{
			return this.class67_0;
		}
		set
		{
			this.class67_0 = value;
		}
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x00033B28 File Offset: 0x00031D28
	private void method_1(IAsyncResult iasyncResult_0)
	{
		Class80 @class = (Class80)iasyncResult_0.AsyncState;
		Class77 class77_ = @class.Class77_0;
		try
		{
			int num = base.Stream2.\u200F\u206B\u202D\u202E\u202E\u200D\u206A\u206E\u200B\u202E\u200E\u206E\u206E\u200F\u206E\u206A\u202C\u206F\u206B\u202D\u206D\u200F\u206A\u206E\u206C\u200C\u200F\u206E\u206D\u202A\u200D\u206F\u200B\u202E\u206D\u206B\u202A\u200B\u202B\u206D\u202E(iasyncResult_0);
			this.class67_0.method_9(class77_.Byte_0, class77_.Int32_1, num);
			num = this.class67_0.method_8(@class.Byte_0, @class.Int32_2, @class.Int32_0);
			@class.Int32_2 += num;
			@class.Int32_0 -= num;
			if (@class.Int32_0 != 0 && this.class67_0.Boolean_0 && num != 0)
			{
				class77_.Int32_1 = 0;
				class77_.Int32_0 = Math.Min(8192, this.class67_0.Int32_0 + 6);
				base.Stream2.\u206E\u202B\u206E\u206E\u202C\u206A\u206F\u206D\u200B\u202A\u206D\u202B\u206F\u206A\u206F\u206E\u202B\u200B\u202A\u200D\u206B\u206F\u206F\u200C\u206B\u206E\u206C\u202A\u206A\u202A\u202C\u200D\u202B\u202D\u206C\u206E\u206A\u206E\u206B\u202C\u202E(class77_.Byte_0, class77_.Int32_1, class77_.Int32_0, new AsyncCallback(this.method_1), @class);
			}
			else
			{
				this.bool_2 = (!this.class67_0.Boolean_0 && num == 0);
				class77_.Int32_0 = @class.Int32_1 - @class.Int32_0;
				class77_.method_0();
			}
		}
		catch (Exception ex)
		{
			this.gclass38_0.Class70_0.method_16(ex.Message, 400);
			class77_.method_1(ex);
		}
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x00033C70 File Offset: 0x00031E70
	public override IAsyncResult \u206E\u202B\u206E\u206E\u202C\u206A\u206F\u206D\u200B\u202A\u206D\u202B\u206F\u206A\u206F\u206E\u202B\u200B\u202A\u200D\u206B\u206F\u206F\u200C\u206B\u206E\u206C\u202A\u206A\u202A\u202C\u200D\u202B\u202D\u206C\u206E\u206A\u206E\u206B\u202C\u202E(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
	{
		if (this.bool_1)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		if (buffer == null)
		{
			throw new ArgumentNullException("buffer");
		}
		if (offset < 0)
		{
			throw new ArgumentOutOfRangeException("offset", "A negative value.");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count", "A negative value.");
		}
		int num = buffer.Length;
		if (offset + count > num)
		{
			throw new ArgumentException("The sum of 'offset' and 'count' is greater than 'buffer' length.");
		}
		Class77 @class = new Class77(callback, state);
		if (this.bool_2)
		{
			@class.method_0();
			return @class;
		}
		int num2 = this.class67_0.method_8(buffer, offset, count);
		offset += num2;
		count -= num2;
		if (count == 0)
		{
			@class.Int32_0 = num2;
			@class.method_0();
			return @class;
		}
		if (!this.class67_0.Boolean_0)
		{
			this.bool_2 = (num2 == 0);
			@class.Int32_0 = num2;
			@class.method_0();
			return @class;
		}
		@class.Byte_0 = new byte[8192];
		@class.Int32_1 = 0;
		@class.Int32_0 = 8192;
		Class80 class2 = new Class80(buffer, offset, count, @class);
		class2.Int32_1 += num2;
		base.Stream2.\u206E\u202B\u206E\u206E\u202C\u206A\u206F\u206D\u200B\u202A\u206D\u202B\u206F\u206A\u206F\u206E\u202B\u200B\u202A\u200D\u206B\u206F\u206F\u200C\u206B\u206E\u206C\u202A\u206A\u202A\u202C\u200D\u202B\u202D\u206C\u206E\u206A\u206E\u206B\u202C\u202E(@class.Byte_0, @class.Int32_1, @class.Int32_0, new AsyncCallback(this.method_1), class2);
		return @class;
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x00006B60 File Offset: 0x00004D60
	public override void \u200B\u206D\u206C\u202A\u202B\u202B\u200F\u200E\u206C\u202E\u200F\u206B\u206A\u206B\u200B\u202B\u206F\u200E\u202D\u206F\u206E\u200D\u200E\u202B\u206A\u202D\u200C\u200E\u206B\u206B\u206B\u206C\u206E\u206B\u206A\u202E\u200F\u200C\u200F\u200C\u202E()
	{
		if (this.bool_1)
		{
			return;
		}
		this.bool_1 = true;
		base.Stream2.\u200B\u206D\u206C\u202A\u202B\u202B\u200F\u200E\u206C\u202E\u200F\u206B\u206A\u206B\u200B\u202B\u206F\u200E\u202D\u206F\u206E\u200D\u200E\u202B\u206A\u202D\u200C\u200E\u206B\u206B\u206B\u206C\u206E\u206B\u206A\u202E\u200F\u200C\u200F\u200C\u202E();
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00033DB0 File Offset: 0x00031FB0
	public override int \u200F\u206B\u202D\u202E\u202E\u200D\u206A\u206E\u200B\u202E\u200E\u206E\u206E\u200F\u206E\u206A\u202C\u206F\u206B\u202D\u206D\u200F\u206A\u206E\u206C\u200C\u200F\u206E\u206D\u202A\u200D\u206F\u200B\u202E\u206D\u206B\u202A\u200B\u202B\u206D\u202E(IAsyncResult asyncResult)
	{
		if (this.bool_1)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		if (asyncResult == null)
		{
			throw new ArgumentNullException("asyncResult");
		}
		Class77 @class = asyncResult as Class77;
		if (@class == null)
		{
			throw new ArgumentException("A wrong IAsyncResult.", "asyncResult");
		}
		if (!@class.IsCompleted)
		{
			@class.AsyncWaitHandle.WaitOne();
		}
		if (@class.Boolean_0)
		{
			throw new GException5(400, "I/O operation aborted.");
		}
		return @class.Int32_0;
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00033E30 File Offset: 0x00032030
	public override int \u200C\u200B\u200D\u200C\u202A\u202C\u206F\u202D\u200B\u202C\u202D\u200B\u202E\u200E\u202A\u200E\u202B\u200D\u202E\u206D\u200C\u206B\u200B\u206E\u202C\u206D\u200B\u206D\u202E\u206D\u200B\u206B\u200D\u202B\u206E\u202B\u206D\u206C\u206E\u200D\u202E(byte[] buffer, int offset, int count)
	{
		IAsyncResult asyncResult = this.BeginRead(buffer, offset, count, null, null);
		return this.EndRead(asyncResult);
	}

	// Token: 0x040002DF RID: 735
	private const int int_2 = 8192;

	// Token: 0x040002E0 RID: 736
	private GClass38 gclass38_0;

	// Token: 0x040002E1 RID: 737
	private Class67 class67_0;

	// Token: 0x040002E2 RID: 738
	private bool bool_1;

	// Token: 0x040002E3 RID: 739
	private bool bool_2;
}
