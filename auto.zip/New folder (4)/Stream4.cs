﻿using System;
using System.IO;
using System.Text;

// Token: 0x020000A8 RID: 168
internal class Stream4 : Stream
{
	// Token: 0x060007D5 RID: 2005 RVA: 0x0003AE70 File Offset: 0x00039070
	internal Stream4(Stream stream_1, GClass41 gclass41_1, bool bool_2)
	{
		this.stream_0 = stream_1;
		this.gclass41_0 = gclass41_1;
		if (bool_2)
		{
			this.action_0 = new Action<byte[], int, int>(this.method_5);
			this.action_2 = new Action<byte[], int, int>(this.method_4);
		}
		else
		{
			this.action_0 = new Action<byte[], int, int>(stream_1.Write);
			this.action_2 = new Action<byte[], int, int>(this.method_3);
		}
		this.memoryStream_0 = new MemoryStream();
	}

	// Token: 0x17000224 RID: 548
	// (get) Token: 0x060007D6 RID: 2006 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool CanRead
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000225 RID: 549
	// (get) Token: 0x060007D7 RID: 2007 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool CanSeek
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000226 RID: 550
	// (get) Token: 0x060007D8 RID: 2008 RVA: 0x000082D5 File Offset: 0x000064D5
	public virtual bool CanWrite
	{
		get
		{
			return !this.bool_0;
		}
	}

	// Token: 0x17000227 RID: 551
	// (get) Token: 0x060007D9 RID: 2009 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Length
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x17000228 RID: 552
	// (get) Token: 0x060007DA RID: 2010 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x060007DB RID: 2011 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Position
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x0003AEEC File Offset: 0x000390EC
	private bool method_0(bool bool_2)
	{
		if (!this.gclass41_0.Boolean_1)
		{
			if (!this.method_2())
			{
				return false;
			}
			this.gclass41_0.Boolean_1 = true;
			this.bool_1 = this.gclass41_0.Boolean_3;
			this.action_1 = (this.bool_1 ? this.action_2 : this.action_0);
		}
		this.method_1(bool_2);
		return true;
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x0003AF54 File Offset: 0x00039154
	private void method_1(bool bool_2)
	{
		using (this.memoryStream_0)
		{
			long length = this.memoryStream_0.Length;
			if (length > 2147483647L)
			{
				this.memoryStream_0.Position = 0L;
				int count = 1024;
				byte[] array = new byte[1024];
				for (;;)
				{
					int num = this.memoryStream_0.Read(array, 0, count);
					if (num <= 0)
					{
						break;
					}
					this.action_1(array, 0, num);
				}
			}
			else if (length > 0L)
			{
				this.action_1(this.memoryStream_0.GetBuffer(), 0, (int)length);
			}
		}
		if (!bool_2)
		{
			this.memoryStream_0 = new MemoryStream();
			return;
		}
		if (this.bool_1)
		{
			this.action_0(Stream4.byte_1, 0, 5);
		}
		this.memoryStream_0 = null;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0003B030 File Offset: 0x00039230
	private bool method_2()
	{
		if (!this.gclass41_0.Boolean_3 && this.gclass41_0.Int64_0 != this.memoryStream_0.Length)
		{
			return false;
		}
		string string_ = this.gclass41_0.String_0;
		GClass45 gclass45_ = this.gclass41_0.GClass45_0;
		MemoryStream memoryStream = new MemoryStream();
		Encoding utf = Encoding.UTF8;
		using (StreamWriter streamWriter = new StreamWriter(memoryStream, utf, 256))
		{
			streamWriter.Write(string_);
			streamWriter.Write(gclass45_.method_7(true));
			streamWriter.Flush();
			int num = utf.GetPreamble().Length;
			long num2 = memoryStream.Length - (long)num;
			if (num2 > (long)Stream4.int_0)
			{
				return false;
			}
			this.action_0(memoryStream.GetBuffer(), num, (int)num2);
		}
		this.gclass41_0.Boolean_0 = (gclass45_["Connection"] == "close");
		return true;
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0003B130 File Offset: 0x00039330
	private static byte[] smethod_0(int int_1)
	{
		string s = string.Format("{0:x}\r\n", int_1);
		return Encoding.ASCII.GetBytes(s);
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x0003B15C File Offset: 0x0003935C
	private void method_3(byte[] byte_2, int int_1, int int_2)
	{
		byte[] array = Stream4.smethod_0(int_2);
		this.stream_0.Write(array, 0, array.Length);
		this.stream_0.Write(byte_2, int_1, int_2);
		this.stream_0.Write(Stream4.byte_0, 0, 2);
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x0003B1A0 File Offset: 0x000393A0
	private void method_4(byte[] byte_2, int int_1, int int_2)
	{
		try
		{
			this.method_3(byte_2, int_1, int_2);
		}
		catch
		{
		}
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x0003B1CC File Offset: 0x000393CC
	private void method_5(byte[] byte_2, int int_1, int int_2)
	{
		try
		{
			this.stream_0.Write(byte_2, int_1, int_2);
		}
		catch
		{
		}
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x0003B1FC File Offset: 0x000393FC
	internal void method_6(bool bool_2)
	{
		if (this.bool_0)
		{
			return;
		}
		this.bool_0 = true;
		if (!bool_2)
		{
			if (this.method_0(true))
			{
				this.gclass41_0.method_7();
				this.gclass41_0 = null;
				this.stream_0 = null;
				return;
			}
			this.gclass41_0.Boolean_0 = true;
		}
		if (this.bool_1)
		{
			this.action_0(Stream4.byte_1, 0, 5);
		}
		this.memoryStream_0.Dispose();
		this.gclass41_0.method_4();
		this.memoryStream_0 = null;
		this.gclass41_0 = null;
		this.stream_0 = null;
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x000082E0 File Offset: 0x000064E0
	internal void method_7(byte[] byte_2, int int_1, int int_2)
	{
		this.action_0(byte_2, int_1, int_2);
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x00004192 File Offset: 0x00002392
	public virtual IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x000082F0 File Offset: 0x000064F0
	public virtual IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		return this.memoryStream_0.BeginWrite(buffer, offset, count, callback, state);
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x0000831D File Offset: 0x0000651D
	public virtual void Close()
	{
		this.method_6(false);
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x00008326 File Offset: 0x00006526
	protected virtual void Dispose(bool disposing)
	{
		this.method_6(!disposing);
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x00004192 File Offset: 0x00002392
	public virtual int EndRead(IAsyncResult asyncResult)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00008332 File Offset: 0x00006532
	public virtual void EndWrite(IAsyncResult asyncResult)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		this.memoryStream_0.EndWrite(asyncResult);
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00008359 File Offset: 0x00006559
	public virtual void Flush()
	{
		if (this.bool_0)
		{
			return;
		}
		if (!this.bool_1 && !this.gclass41_0.Boolean_3)
		{
			return;
		}
		this.method_0(false);
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x00004192 File Offset: 0x00002392
	public virtual int Read(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Seek(long offset, SeekOrigin origin)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x00004192 File Offset: 0x00002392
	public virtual void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x00008385 File Offset: 0x00006585
	public virtual void Write(byte[] buffer, int offset, int count)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		this.memoryStream_0.Write(buffer, offset, count);
	}

	// Token: 0x04000440 RID: 1088
	private MemoryStream memoryStream_0;

	// Token: 0x04000441 RID: 1089
	private static readonly byte[] byte_0 = new byte[]
	{
		13,
		10
	};

	// Token: 0x04000442 RID: 1090
	private bool bool_0;

	// Token: 0x04000443 RID: 1091
	private Stream stream_0;

	// Token: 0x04000444 RID: 1092
	private static readonly byte[] byte_1 = new byte[]
	{
		48,
		13,
		10,
		13,
		10
	};

	// Token: 0x04000445 RID: 1093
	private static readonly int int_0 = 32768;

	// Token: 0x04000446 RID: 1094
	private GClass41 gclass41_0;

	// Token: 0x04000447 RID: 1095
	private bool bool_1;

	// Token: 0x04000448 RID: 1096
	private Action<byte[], int, int> action_0;

	// Token: 0x04000449 RID: 1097
	private Action<byte[], int, int> action_1;

	// Token: 0x0400044A RID: 1098
	private Action<byte[], int, int> action_2;
}
