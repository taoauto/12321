﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x020001E1 RID: 481
internal class Class220
{
	// Token: 0x060019AC RID: 6572 RVA: 0x00012AAB File Offset: 0x00010CAB
	public static Class220 smethod_0(string string_0)
	{
		return new Class220(Class426.smethod_65(string_0));
	}

	// Token: 0x17000644 RID: 1604
	public IEnumerable<Class219> this[string string_0]
	{
		get
		{
			Class220.Class221 @class = new Class220.Class221(-2);
			@class.class220_0 = this;
			@class.string_1 = string_0;
			return @class;
		}
	}

	// Token: 0x060019AE RID: 6574 RVA: 0x000BAABC File Offset: 0x000B8CBC
	public Class220(string string_0)
	{
		TextReader textReader = null;
		string text = null;
		try
		{
			textReader = new StreamReader(new MemoryStream(Encoding.UTF8.GetBytes(string_0)));
			string text2;
			while ((text2 = textReader.ReadLine()) != null)
			{
				if (!string.IsNullOrEmpty(text2))
				{
					if (text2.StartsWith("[") && text2.EndsWith("]"))
					{
						text = text2.Substring(1, text2.Length - 2);
					}
					else
					{
						string[] array = text2.Split(new char[]
						{
							'='
						}, 2);
						Class219 key = new Class219
						{
							String_0 = (text ?? "ROOT"),
							String_1 = array[0]
						};
						this.dictionary_0[key] = array[1].Replace("\\n", "\r\n");
					}
				}
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (textReader != null)
			{
				textReader.Dispose();
			}
		}
	}

	// Token: 0x060019AF RID: 6575 RVA: 0x000BABBC File Offset: 0x000B8DBC
	public string method_0(string string_0, string string_1)
	{
		Class219 key = new Class219
		{
			String_0 = string_0,
			String_1 = string_1
		};
		string text;
		if (this.dictionary_0.TryGetValue(key, out text))
		{
			return text ?? string.Empty;
		}
		return string.Empty;
	}

	// Token: 0x060019B0 RID: 6576 RVA: 0x00012ACF File Offset: 0x00010CCF
	public void method_1(string string_0, string string_1, string string_2)
	{
		this.dictionary_0[new Class219
		{
			String_0 = string_0,
			String_1 = string_1
		}] = string_2;
	}

	// Token: 0x060019B1 RID: 6577 RVA: 0x000BAC00 File Offset: 0x000B8E00
	public void method_2(string string_0)
	{
		Class220.Class222 @class = new Class220.Class222();
		@class.string_0 = string_0;
		this.dictionary_0 = this.dictionary_0.Where(new Func<KeyValuePair<Class219, string>, bool>(@class.method_0)).ToDictionary(new Func<KeyValuePair<Class219, string>, Class219>(Class220.Class223.<>9.method_0), new Func<KeyValuePair<Class219, string>, string>(Class220.Class223.<>9.method_1));
	}

	// Token: 0x060019B2 RID: 6578 RVA: 0x000BAC7C File Offset: 0x000B8E7C
	public void method_3(string string_0)
	{
		try
		{
			Class426.smethod_69(string_0, this.ToString());
		}
		catch
		{
		}
	}

	// Token: 0x060019B3 RID: 6579 RVA: 0x000BACAC File Offset: 0x000B8EAC
	public virtual string ToString()
	{
		IEnumerable<string> enumerable = this.dictionary_0.Keys.Select(new Func<Class219, string>(Class220.Class223.<>9.method_2)).Distinct<string>();
		StringBuilder stringBuilder = new StringBuilder();
		using (IEnumerator<string> enumerator = enumerable.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Class220.Class224 @class = new Class220.Class224();
				@class.string_0 = enumerator.Current;
				stringBuilder.AppendLine("[" + @class.string_0 + "]");
				IEnumerable<KeyValuePair<Class219, string>> source = this.dictionary_0;
				Func<KeyValuePair<Class219, string>, bool> predicate;
				if ((predicate = @class.func_0) == null)
				{
					predicate = (@class.func_0 = new Func<KeyValuePair<Class219, string>, bool>(@class.method_0));
				}
				foreach (KeyValuePair<Class219, string> keyValuePair in source.Where(predicate))
				{
					if (!string.IsNullOrEmpty(keyValuePair.Value))
					{
						string str = keyValuePair.Value.Replace("\r", "").Replace("\n", "\\n");
						stringBuilder.AppendLine(keyValuePair.Key.String_1 + "=" + str);
					}
				}
				stringBuilder.AppendLine();
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x04000F26 RID: 3878
	private Dictionary<Class219, string> dictionary_0 = new Dictionary<Class219, string>();

	// Token: 0x020001E3 RID: 483
	[CompilerGenerated]
	private sealed class Class222
	{
		// Token: 0x060019BE RID: 6590 RVA: 0x00012B34 File Offset: 0x00010D34
		internal bool method_0(KeyValuePair<Class219, string> keyValuePair_0)
		{
			return keyValuePair_0.Key.String_0 != this.string_0;
		}

		// Token: 0x04000F2E RID: 3886
		public string string_0;
	}

	// Token: 0x020001E4 RID: 484
	[CompilerGenerated]
	[Serializable]
	private sealed class Class223
	{
		// Token: 0x060019C1 RID: 6593 RVA: 0x00012B59 File Offset: 0x00010D59
		internal Class219 method_0(KeyValuePair<Class219, string> keyValuePair_0)
		{
			return keyValuePair_0.Key;
		}

		// Token: 0x060019C2 RID: 6594 RVA: 0x00012B62 File Offset: 0x00010D62
		internal string method_1(KeyValuePair<Class219, string> keyValuePair_0)
		{
			return keyValuePair_0.Value;
		}

		// Token: 0x060019C3 RID: 6595 RVA: 0x00012B6B File Offset: 0x00010D6B
		internal string method_2(Class219 class219_0)
		{
			return class219_0.String_0;
		}

		// Token: 0x04000F2F RID: 3887
		public static readonly Class220.Class223 <>9 = new Class220.Class223();

		// Token: 0x04000F30 RID: 3888
		public static Func<KeyValuePair<Class219, string>, Class219> <>9__7_1;

		// Token: 0x04000F31 RID: 3889
		public static Func<KeyValuePair<Class219, string>, string> <>9__7_2;

		// Token: 0x04000F32 RID: 3890
		public static Func<Class219, string> <>9__9_0;
	}

	// Token: 0x020001E5 RID: 485
	[CompilerGenerated]
	private sealed class Class224
	{
		// Token: 0x060019C5 RID: 6597 RVA: 0x00012B73 File Offset: 0x00010D73
		internal bool method_0(KeyValuePair<Class219, string> keyValuePair_0)
		{
			return keyValuePair_0.Key.String_0 == this.string_0;
		}

		// Token: 0x04000F33 RID: 3891
		public string string_0;

		// Token: 0x04000F34 RID: 3892
		public Func<KeyValuePair<Class219, string>, bool> func_0;
	}
}
