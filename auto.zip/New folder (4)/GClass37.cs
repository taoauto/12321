﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Principal;
using WebSocketSharp.Net;

// Token: 0x02000090 RID: 144
public sealed class GClass37 : IDisposable
{
	// Token: 0x06000698 RID: 1688 RVA: 0x00036BCC File Offset: 0x00034DCC
	public GClass37()
	{
		this.authenticationSchemes_0 = AuthenticationSchemes.Anonymous;
		this.dictionary_0 = new Dictionary<Class70, Class70>();
		this.object_0 = ((ICollection)this.dictionary_0).SyncRoot;
		this.list_0 = new List<GClass38>();
		this.object_1 = ((ICollection)this.list_0).SyncRoot;
		this.dictionary_1 = new Dictionary<GClass38, GClass38>();
		this.object_2 = ((ICollection)this.dictionary_1).SyncRoot;
		this.gclass24_0 = new GClass24();
		this.gclass39_0 = new GClass39(this);
		this.list_1 = new List<Class72>();
		this.object_3 = ((ICollection)this.list_1).SyncRoot;
	}

	// Token: 0x170001B9 RID: 441
	// (get) Token: 0x06000699 RID: 1689 RVA: 0x00007455 File Offset: 0x00005655
	internal bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x170001BA RID: 442
	// (get) Token: 0x0600069A RID: 1690 RVA: 0x0000745D File Offset: 0x0000565D
	// (set) Token: 0x0600069B RID: 1691 RVA: 0x00007465 File Offset: 0x00005665
	internal bool Boolean_1
	{
		get
		{
			return this.bool_3;
		}
		set
		{
			this.bool_3 = value;
		}
	}

	// Token: 0x170001BB RID: 443
	// (get) Token: 0x0600069C RID: 1692 RVA: 0x0000746E File Offset: 0x0000566E
	// (set) Token: 0x0600069D RID: 1693 RVA: 0x0000747C File Offset: 0x0000567C
	public AuthenticationSchemes AuthenticationSchemes_0
	{
		get
		{
			this.method_9();
			return this.authenticationSchemes_0;
		}
		set
		{
			this.method_9();
			this.authenticationSchemes_0 = value;
		}
	}

	// Token: 0x170001BC RID: 444
	// (get) Token: 0x0600069E RID: 1694 RVA: 0x0000748B File Offset: 0x0000568B
	// (set) Token: 0x0600069F RID: 1695 RVA: 0x00007499 File Offset: 0x00005699
	public Func<GClass40, AuthenticationSchemes> Func_0
	{
		get
		{
			this.method_9();
			return this.func_0;
		}
		set
		{
			this.method_9();
			this.func_0 = value;
		}
	}

	// Token: 0x170001BD RID: 445
	// (get) Token: 0x060006A0 RID: 1696 RVA: 0x000074A8 File Offset: 0x000056A8
	// (set) Token: 0x060006A1 RID: 1697 RVA: 0x000074B6 File Offset: 0x000056B6
	public string String_0
	{
		get
		{
			this.method_9();
			return this.string_0;
		}
		set
		{
			this.method_9();
			this.string_0 = value;
		}
	}

	// Token: 0x170001BE RID: 446
	// (get) Token: 0x060006A2 RID: 1698 RVA: 0x000074C5 File Offset: 0x000056C5
	// (set) Token: 0x060006A3 RID: 1699 RVA: 0x000074D3 File Offset: 0x000056D3
	public bool Boolean_2
	{
		get
		{
			this.method_9();
			return this.bool_1;
		}
		set
		{
			this.method_9();
			this.bool_1 = value;
		}
	}

	// Token: 0x170001BF RID: 447
	// (get) Token: 0x060006A4 RID: 1700 RVA: 0x000074E2 File Offset: 0x000056E2
	public bool Boolean_3
	{
		get
		{
			return this.bool_2;
		}
	}

	// Token: 0x170001C0 RID: 448
	// (get) Token: 0x060006A5 RID: 1701 RVA: 0x0000354C File Offset: 0x0000174C
	public static bool Boolean_4
	{
		get
		{
			return true;
		}
	}

	// Token: 0x170001C1 RID: 449
	// (get) Token: 0x060006A6 RID: 1702 RVA: 0x000074EC File Offset: 0x000056EC
	public GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
	}

	// Token: 0x170001C2 RID: 450
	// (get) Token: 0x060006A7 RID: 1703 RVA: 0x000074F4 File Offset: 0x000056F4
	public GClass39 GClass39_0
	{
		get
		{
			this.method_9();
			return this.gclass39_0;
		}
	}

	// Token: 0x170001C3 RID: 451
	// (get) Token: 0x060006A8 RID: 1704 RVA: 0x00007502 File Offset: 0x00005702
	// (set) Token: 0x060006A9 RID: 1705 RVA: 0x00007510 File Offset: 0x00005710
	public string String_1
	{
		get
		{
			this.method_9();
			return this.string_2;
		}
		set
		{
			this.method_9();
			this.string_2 = value;
		}
	}

	// Token: 0x170001C4 RID: 452
	// (get) Token: 0x060006AA RID: 1706 RVA: 0x00036C74 File Offset: 0x00034E74
	// (set) Token: 0x060006AB RID: 1707 RVA: 0x0000751F File Offset: 0x0000571F
	public GClass44 GClass44_0
	{
		get
		{
			this.method_9();
			GClass44 result;
			if ((result = this.gclass44_0) == null)
			{
				result = (this.gclass44_0 = new GClass44());
			}
			return result;
		}
		set
		{
			this.method_9();
			this.gclass44_0 = value;
		}
	}

	// Token: 0x170001C5 RID: 453
	// (get) Token: 0x060006AC RID: 1708 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x060006AD RID: 1709 RVA: 0x00004192 File Offset: 0x00002392
	public bool Boolean_5
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170001C6 RID: 454
	// (get) Token: 0x060006AE RID: 1710 RVA: 0x0000752E File Offset: 0x0000572E
	// (set) Token: 0x060006AF RID: 1711 RVA: 0x0000753C File Offset: 0x0000573C
	public Func<IIdentity, GClass43> Func_1
	{
		get
		{
			this.method_9();
			return this.func_1;
		}
		set
		{
			this.method_9();
			this.func_1 = value;
		}
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x00036CA0 File Offset: 0x00034EA0
	private void method_0()
	{
		Class70[] array = null;
		object obj = this.object_0;
		lock (obj)
		{
			if (this.dictionary_0.Count == 0)
			{
				return;
			}
			Dictionary<Class70, Class70>.KeyCollection keys = this.dictionary_0.Keys;
			array = new Class70[keys.Count];
			keys.CopyTo(array, 0);
			this.dictionary_0.Clear();
		}
		for (int i = array.Length - 1; i >= 0; i--)
		{
			array[i].method_10(true);
		}
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x00036D30 File Offset: 0x00034F30
	private void method_1(bool bool_4)
	{
		GClass38[] array = null;
		object obj = this.object_1;
		lock (obj)
		{
			if (this.list_0.Count == 0)
			{
				return;
			}
			array = this.list_0.ToArray();
			this.list_0.Clear();
		}
		if (!bool_4)
		{
			return;
		}
		GClass38[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			GClass41 gclass41_ = array2[i].GClass41_0;
			gclass41_.Int32_0 = 503;
			gclass41_.method_7();
		}
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x00036DC4 File Offset: 0x00034FC4
	private void method_2()
	{
		GClass38[] array = null;
		object obj = this.object_2;
		lock (obj)
		{
			if (this.dictionary_1.Count == 0)
			{
				return;
			}
			Dictionary<GClass38, GClass38>.KeyCollection keys = this.dictionary_1.Keys;
			array = new GClass38[keys.Count];
			keys.CopyTo(array, 0);
			this.dictionary_1.Clear();
		}
		for (int i = array.Length - 1; i >= 0; i--)
		{
			array[i].Class70_0.method_10(true);
		}
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00036E58 File Offset: 0x00035058
	private void method_3(Exception exception_0)
	{
		Class72[] array = null;
		object obj = this.object_3;
		lock (obj)
		{
			if (this.list_1.Count == 0)
			{
				return;
			}
			array = this.list_1.ToArray();
			this.list_1.Clear();
		}
		Class72[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			array2[i].method_0(exception_0);
		}
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00036ED8 File Offset: 0x000350D8
	private void method_4(bool bool_4)
	{
		if (this.bool_2)
		{
			this.bool_2 = false;
			Class69.smethod_6(this);
		}
		object obj = this.object_2;
		lock (obj)
		{
			this.method_1(!bool_4);
		}
		this.method_2();
		this.method_0();
		this.method_3(new ObjectDisposedException(base.GetType().ToString()));
		this.bool_0 = true;
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x0000754B File Offset: 0x0000574B
	private Class72 method_5()
	{
		if (this.list_1.Count == 0)
		{
			return null;
		}
		Class72 result = this.list_1[0];
		this.list_1.RemoveAt(0);
		return result;
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00007574 File Offset: 0x00005774
	private GClass38 method_6()
	{
		if (this.list_0.Count == 0)
		{
			return null;
		}
		GClass38 result = this.list_0[0];
		this.list_0.RemoveAt(0);
		return result;
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00036F60 File Offset: 0x00035160
	internal bool method_7(Class70 class70_0)
	{
		if (!this.bool_2)
		{
			return false;
		}
		object obj = this.object_0;
		bool result;
		lock (obj)
		{
			if (!this.bool_2)
			{
				result = false;
			}
			else
			{
				this.dictionary_0[class70_0] = class70_0;
				result = true;
			}
		}
		return result;
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00036FC4 File Offset: 0x000351C4
	internal Class72 method_8(Class72 class72_0)
	{
		object obj = this.object_2;
		lock (obj)
		{
			if (!this.bool_2)
			{
				throw new GException5(995);
			}
			GClass38 gclass = this.method_6();
			if (gclass == null)
			{
				this.list_1.Add(class72_0);
			}
			else
			{
				class72_0.method_2(gclass, true);
			}
		}
		return class72_0;
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x0000759D File Offset: 0x0000579D
	internal void method_9()
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00037038 File Offset: 0x00035238
	internal string method_10()
	{
		string text = this.string_2;
		if (text != null && text.Length > 0)
		{
			return text;
		}
		return GClass37.string_1;
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x000075B8 File Offset: 0x000057B8
	internal Func<IIdentity, GClass43> method_11()
	{
		return this.func_1;
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x00037060 File Offset: 0x00035260
	internal bool method_12(GClass38 gclass38_0)
	{
		if (!this.bool_2)
		{
			return false;
		}
		object obj = this.object_2;
		bool result;
		lock (obj)
		{
			if (!this.bool_2)
			{
				result = false;
			}
			else
			{
				this.dictionary_1[gclass38_0] = gclass38_0;
				Class72 @class = this.method_5();
				if (@class == null)
				{
					this.list_0.Add(gclass38_0);
				}
				else
				{
					@class.method_1(gclass38_0);
				}
				result = true;
			}
		}
		return result;
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x000370E4 File Offset: 0x000352E4
	internal void method_13(Class70 class70_0)
	{
		object obj = this.object_0;
		lock (obj)
		{
			this.dictionary_0.Remove(class70_0);
		}
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x0003712C File Offset: 0x0003532C
	internal AuthenticationSchemes method_14(GClass40 gclass40_0)
	{
		Func<GClass40, AuthenticationSchemes> func = this.func_0;
		if (func == null)
		{
			return this.authenticationSchemes_0;
		}
		AuthenticationSchemes result;
		try
		{
			result = func(gclass40_0);
		}
		catch
		{
			result = AuthenticationSchemes.None;
		}
		return result;
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x0003716C File Offset: 0x0003536C
	internal void method_15(GClass38 gclass38_0)
	{
		object obj = this.object_2;
		lock (obj)
		{
			this.dictionary_1.Remove(gclass38_0);
		}
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x000075C0 File Offset: 0x000057C0
	public void method_16()
	{
		if (this.bool_0)
		{
			return;
		}
		this.method_4(true);
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x000371B4 File Offset: 0x000353B4
	public IAsyncResult method_17(AsyncCallback asyncCallback_0, object object_4)
	{
		this.method_9();
		if (this.gclass39_0.Count == 0)
		{
			throw new InvalidOperationException("The listener has no URI prefix on which listens.");
		}
		if (!this.bool_2)
		{
			throw new InvalidOperationException("The listener hasn't been started.");
		}
		return this.method_8(new Class72(asyncCallback_0, object_4));
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x000075D2 File Offset: 0x000057D2
	public void method_18()
	{
		if (this.bool_0)
		{
			return;
		}
		this.method_4(false);
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x00037204 File Offset: 0x00035404
	public GClass38 method_19(IAsyncResult iasyncResult_0)
	{
		this.method_9();
		if (iasyncResult_0 == null)
		{
			throw new ArgumentNullException("asyncResult");
		}
		Class72 @class = iasyncResult_0 as Class72;
		if (@class == null)
		{
			throw new ArgumentException("A wrong IAsyncResult.", "asyncResult");
		}
		if (@class.Boolean_0)
		{
			throw new InvalidOperationException("This IAsyncResult cannot be reused.");
		}
		@class.Boolean_0 = true;
		if (!@class.IsCompleted)
		{
			@class.AsyncWaitHandle.WaitOne();
		}
		return @class.method_3();
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x00037274 File Offset: 0x00035474
	public GClass38 method_20()
	{
		this.method_9();
		if (this.gclass39_0.Count == 0)
		{
			throw new InvalidOperationException("The listener has no URI prefix on which listens.");
		}
		if (!this.bool_2)
		{
			throw new InvalidOperationException("The listener hasn't been started.");
		}
		Class72 @class = this.method_8(new Class72(null, null));
		@class.Boolean_1 = true;
		return this.method_19(@class);
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x000075E4 File Offset: 0x000057E4
	public void method_21()
	{
		this.method_9();
		if (this.bool_2)
		{
			return;
		}
		Class69.smethod_4(this);
		this.bool_2 = true;
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x000372D0 File Offset: 0x000354D0
	public void method_22()
	{
		this.method_9();
		if (!this.bool_2)
		{
			return;
		}
		this.bool_2 = false;
		Class69.smethod_6(this);
		object obj = this.object_2;
		lock (obj)
		{
			this.method_1(true);
		}
		this.method_2();
		this.method_0();
		this.method_3(new GException5(995, "The listener is stopped."));
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x000075C0 File Offset: 0x000057C0
	void IDisposable.Dispose()
	{
		if (this.bool_0)
		{
			return;
		}
		this.method_4(true);
	}

	// Token: 0x04000335 RID: 821
	private AuthenticationSchemes authenticationSchemes_0;

	// Token: 0x04000336 RID: 822
	private Func<GClass40, AuthenticationSchemes> func_0;

	// Token: 0x04000337 RID: 823
	private string string_0;

	// Token: 0x04000338 RID: 824
	private Dictionary<Class70, Class70> dictionary_0;

	// Token: 0x04000339 RID: 825
	private object object_0;

	// Token: 0x0400033A RID: 826
	private List<GClass38> list_0;

	// Token: 0x0400033B RID: 827
	private object object_1;

	// Token: 0x0400033C RID: 828
	private Dictionary<GClass38, GClass38> dictionary_1;

	// Token: 0x0400033D RID: 829
	private object object_2;

	// Token: 0x0400033E RID: 830
	private static readonly string string_1 = "SECRET AREA";

	// Token: 0x0400033F RID: 831
	private bool bool_0;

	// Token: 0x04000340 RID: 832
	private bool bool_1;

	// Token: 0x04000341 RID: 833
	private volatile bool bool_2;

	// Token: 0x04000342 RID: 834
	private GClass24 gclass24_0;

	// Token: 0x04000343 RID: 835
	private GClass39 gclass39_0;

	// Token: 0x04000344 RID: 836
	private string string_2;

	// Token: 0x04000345 RID: 837
	private bool bool_3;

	// Token: 0x04000346 RID: 838
	private GClass44 gclass44_0;

	// Token: 0x04000347 RID: 839
	private Func<IIdentity, GClass43> func_1;

	// Token: 0x04000348 RID: 840
	private List<Class72> list_1;

	// Token: 0x04000349 RID: 841
	private object object_3;
}
