﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000100 RID: 256
public class GClass78
{
	// Token: 0x1700037A RID: 890
	// (get) Token: 0x06000D25 RID: 3365 RVA: 0x0000B74A File Offset: 0x0000994A
	// (set) Token: 0x06000D26 RID: 3366 RVA: 0x0000B757 File Offset: 0x00009957
	public string String_0
	{
		get
		{
			return this.GControl3_0.String_0;
		}
		set
		{
			this.GControl3_0.String_0 = value;
		}
	}

	// Token: 0x1700037B RID: 891
	// (get) Token: 0x06000D27 RID: 3367 RVA: 0x0000B765 File Offset: 0x00009965
	// (set) Token: 0x06000D28 RID: 3368 RVA: 0x0000B76D File Offset: 0x0000996D
	public GClass86 GClass86_0 { get; set; }

	// Token: 0x1700037C RID: 892
	// (get) Token: 0x06000D29 RID: 3369 RVA: 0x0000B776 File Offset: 0x00009976
	// (set) Token: 0x06000D2A RID: 3370 RVA: 0x0000B783 File Offset: 0x00009983
	public Color Color_0
	{
		get
		{
			return this.GControl3_0.BackColor;
		}
		set
		{
			this.GControl3_0.BackColor = value;
		}
	}

	// Token: 0x1700037D RID: 893
	// (get) Token: 0x06000D2B RID: 3371 RVA: 0x0000B791 File Offset: 0x00009991
	// (set) Token: 0x06000D2C RID: 3372 RVA: 0x0000B79E File Offset: 0x0000999E
	public Color Color_1
	{
		get
		{
			return this.GControl3_0.Color_0;
		}
		set
		{
			this.GControl3_0.Color_0 = value;
		}
	}

	// Token: 0x1700037E RID: 894
	// (get) Token: 0x06000D2D RID: 3373 RVA: 0x0000B7AC File Offset: 0x000099AC
	// (set) Token: 0x06000D2E RID: 3374 RVA: 0x0000B7B9 File Offset: 0x000099B9
	public Color Color_2
	{
		get
		{
			return this.GControl3_0.Color_1;
		}
		set
		{
			this.GControl3_0.Color_1 = value;
		}
	}

	// Token: 0x1700037F RID: 895
	// (get) Token: 0x06000D2F RID: 3375 RVA: 0x0000B7C7 File Offset: 0x000099C7
	// (set) Token: 0x06000D30 RID: 3376 RVA: 0x0000B7D4 File Offset: 0x000099D4
	public Color Color_3
	{
		get
		{
			return this.GControl3_0.ForeColor;
		}
		set
		{
			this.GControl3_0.ForeColor = value;
		}
	}

	// Token: 0x17000380 RID: 896
	// (get) Token: 0x06000D31 RID: 3377 RVA: 0x0000B7E2 File Offset: 0x000099E2
	// (set) Token: 0x06000D32 RID: 3378 RVA: 0x0000B7EF File Offset: 0x000099EF
	public StringAlignment StringAlignment_0
	{
		get
		{
			return this.GControl3_0.StringAlignment_0;
		}
		set
		{
			this.GControl3_0.StringAlignment_0 = value;
		}
	}

	// Token: 0x17000381 RID: 897
	// (get) Token: 0x06000D33 RID: 3379 RVA: 0x0000B7FD File Offset: 0x000099FD
	// (set) Token: 0x06000D34 RID: 3380 RVA: 0x0000B80A File Offset: 0x00009A0A
	public Font Font_0
	{
		get
		{
			return this.GControl3_0.Font;
		}
		set
		{
			this.GControl3_0.Font = value;
		}
	}

	// Token: 0x1400002F RID: 47
	// (add) Token: 0x06000D35 RID: 3381 RVA: 0x0000B818 File Offset: 0x00009A18
	// (remove) Token: 0x06000D36 RID: 3382 RVA: 0x0000B826 File Offset: 0x00009A26
	public event EventHandler Event_0
	{
		add
		{
			this.GControl3_0.Click += value;
		}
		remove
		{
			this.GControl3_0.Click -= value;
		}
	}

	// Token: 0x17000382 RID: 898
	// (get) Token: 0x06000D37 RID: 3383 RVA: 0x0000B834 File Offset: 0x00009A34
	// (set) Token: 0x06000D38 RID: 3384 RVA: 0x0000B83C File Offset: 0x00009A3C
	public Control Control_0 { get; set; }

	// Token: 0x17000383 RID: 899
	// (get) Token: 0x06000D39 RID: 3385 RVA: 0x0000B845 File Offset: 0x00009A45
	// (set) Token: 0x06000D3A RID: 3386 RVA: 0x0000B84D File Offset: 0x00009A4D
	public DockStyle DockStyle_0 { get; set; }

	// Token: 0x17000384 RID: 900
	// (get) Token: 0x06000D3B RID: 3387 RVA: 0x0000B856 File Offset: 0x00009A56
	// (set) Token: 0x06000D3C RID: 3388 RVA: 0x0000B863 File Offset: 0x00009A63
	public int Int32_0
	{
		get
		{
			return this.GControl3_0.Width;
		}
		set
		{
			this.GControl3_0.Width = value;
		}
	}

	// Token: 0x17000385 RID: 901
	// (get) Token: 0x06000D3D RID: 3389 RVA: 0x0000B871 File Offset: 0x00009A71
	// (set) Token: 0x06000D3E RID: 3390 RVA: 0x0000B87E File Offset: 0x00009A7E
	public int Int32_1
	{
		get
		{
			return this.GControl3_0.Height;
		}
		set
		{
			this.GControl3_0.Height = value;
		}
	}

	// Token: 0x17000386 RID: 902
	// (get) Token: 0x06000D3F RID: 3391 RVA: 0x0000B88C File Offset: 0x00009A8C
	// (set) Token: 0x06000D40 RID: 3392 RVA: 0x0000B894 File Offset: 0x00009A94
	public GControl3 GControl3_0 { get; private set; }

	// Token: 0x17000387 RID: 903
	// (get) Token: 0x06000D41 RID: 3393 RVA: 0x0000B89D File Offset: 0x00009A9D
	// (set) Token: 0x06000D42 RID: 3394 RVA: 0x0000B8A5 File Offset: 0x00009AA5
	internal int Int32_2 { get; set; }

	// Token: 0x17000388 RID: 904
	// (get) Token: 0x06000D43 RID: 3395 RVA: 0x0000B8AE File Offset: 0x00009AAE
	// (set) Token: 0x06000D44 RID: 3396 RVA: 0x0000B8B6 File Offset: 0x00009AB6
	public object Object_0 { get; set; }

	// Token: 0x17000389 RID: 905
	// (get) Token: 0x06000D45 RID: 3397 RVA: 0x0000B8BF File Offset: 0x00009ABF
	// (set) Token: 0x06000D46 RID: 3398 RVA: 0x0000B8CC File Offset: 0x00009ACC
	public Cursor Cursor_0
	{
		get
		{
			return this.GControl3_0.Cursor;
		}
		set
		{
			this.GControl3_0.Cursor = value;
		}
	}

	// Token: 0x1700038A RID: 906
	// (get) Token: 0x06000D47 RID: 3399 RVA: 0x0000B8DA File Offset: 0x00009ADA
	// (set) Token: 0x06000D48 RID: 3400 RVA: 0x0000B8E2 File Offset: 0x00009AE2
	public bool Boolean_0 { get; set; }

	// Token: 0x06000D49 RID: 3401 RVA: 0x0004F268 File Offset: 0x0004D468
	public virtual void vmethod_0()
	{
		this.GClass86_0.fastColoredTextBox_0.method_53(this.GClass86_0, true);
		this.GClass86_0.fastColoredTextBox_0.method_46(this.GControl3_0.Bounds);
		this.GClass86_0.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x0000B8EB File Offset: 0x00009AEB
	private GClass78(GClass86 gclass86_1, Control control_1, string string_0, bool bool_1, bool bool_2)
	{
		this.GClass86_0 = gclass86_1;
		this.Boolean_0 = bool_1;
		this.Control_0 = control_1;
		this.vmethod_1();
		this.DockStyle_0 = (bool_2 ? DockStyle.Fill : DockStyle.None);
		this.String_0 = string_0;
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x0000B924 File Offset: 0x00009B24
	public GClass78(GClass86 gclass86_1, string string_0, bool bool_1, bool bool_2) : this(gclass86_1, null, string_0, bool_1, bool_2)
	{
	}

	// Token: 0x06000D4C RID: 3404 RVA: 0x0000B932 File Offset: 0x00009B32
	public GClass78(GClass86 gclass86_1, string string_0) : this(gclass86_1, null, string_0, true, true)
	{
	}

	// Token: 0x06000D4D RID: 3405 RVA: 0x0000B93F File Offset: 0x00009B3F
	public GClass78(GClass86 gclass86_1, Control control_1, bool bool_1, bool bool_2) : this(gclass86_1, control_1, null, bool_1, bool_2)
	{
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x0000B94D File Offset: 0x00009B4D
	public GClass78(GClass86 gclass86_1, Control control_1) : this(gclass86_1, control_1, null, true, true)
	{
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x0004F2B8 File Offset: 0x0004D4B8
	protected virtual void vmethod_1()
	{
		this.GControl3_0 = new GControl3();
		this.GControl3_0.Click += this.vmethod_2;
		this.Cursor_0 = Cursors.Default;
		this.Color_2 = Color.Silver;
		this.Color_1 = Color.White;
		this.Color_0 = ((this.Control_0 == null) ? Color.Silver : SystemColors.Control);
		this.Color_3 = Color.Black;
		this.StringAlignment_0 = StringAlignment.Near;
		this.Font_0 = ((this.GClass86_0.fastColoredTextBox_0.Parent == null) ? this.GClass86_0.fastColoredTextBox_0.Font : this.GClass86_0.fastColoredTextBox_0.Parent.Font);
		if (this.Control_0 != null)
		{
			this.GControl3_0.Controls.Add(this.Control_0);
			Size preferredSize = this.Control_0.GetPreferredSize(this.Control_0.Size);
			this.GControl3_0.Width = preferredSize.Width + 2;
			this.GControl3_0.Height = preferredSize.Height + 2;
			this.Control_0.Dock = DockStyle.Fill;
			this.Control_0.Visible = true;
			this.Color_0 = SystemColors.Control;
			return;
		}
		this.GControl3_0.Height = this.GClass86_0.fastColoredTextBox_0.Int32_2 + 5;
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x0000B95A File Offset: 0x00009B5A
	protected virtual void vmethod_2(object sender, EventArgs e)
	{
		this.GClass86_0.fastColoredTextBox_0.vmethod_2(this);
	}

	// Token: 0x04000631 RID: 1585
	[CompilerGenerated]
	private GClass86 gclass86_0;

	// Token: 0x04000632 RID: 1586
	[CompilerGenerated]
	private Control control_0;

	// Token: 0x04000633 RID: 1587
	[CompilerGenerated]
	private DockStyle dockStyle_0;

	// Token: 0x04000634 RID: 1588
	[CompilerGenerated]
	private GControl3 gcontrol3_0;

	// Token: 0x04000635 RID: 1589
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000636 RID: 1590
	[CompilerGenerated]
	private object object_0;

	// Token: 0x04000637 RID: 1591
	[CompilerGenerated]
	private bool bool_0;
}
