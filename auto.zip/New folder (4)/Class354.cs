﻿using System;

// Token: 0x0200029A RID: 666
internal class Class354
{
	// Token: 0x17000790 RID: 1936
	// (get) Token: 0x0600249F RID: 9375 RVA: 0x0001BC9F File Offset: 0x00019E9F
	public static string String_0
	{
		get
		{
			return "Phụng Hoàng Cổ Thành";
		}
	}

	// Token: 0x04001880 RID: 6272
	public static int int_0 = 280;

	// Token: 0x04001881 RID: 6273
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 643U,
		Int32_0 = 163,
		Int32_1 = 164,
		Int32_2 = Class354.int_0,
		String_2 = "Hoàng Long Thiên"
	};
}
