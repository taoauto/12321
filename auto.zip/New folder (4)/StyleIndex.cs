﻿using System;

// Token: 0x020000F7 RID: 247
[Flags]
public enum StyleIndex : ushort
{
	// Token: 0x040005F9 RID: 1529
	None = 0,
	// Token: 0x040005FA RID: 1530
	Style0 = 1,
	// Token: 0x040005FB RID: 1531
	Style1 = 2,
	// Token: 0x040005FC RID: 1532
	Style2 = 4,
	// Token: 0x040005FD RID: 1533
	Style3 = 8,
	// Token: 0x040005FE RID: 1534
	Style4 = 16,
	// Token: 0x040005FF RID: 1535
	Style5 = 32,
	// Token: 0x04000600 RID: 1536
	Style6 = 64,
	// Token: 0x04000601 RID: 1537
	Style7 = 128,
	// Token: 0x04000602 RID: 1538
	Style8 = 256,
	// Token: 0x04000603 RID: 1539
	Style9 = 512,
	// Token: 0x04000604 RID: 1540
	Style10 = 1024,
	// Token: 0x04000605 RID: 1541
	Style11 = 2048,
	// Token: 0x04000606 RID: 1542
	Style12 = 4096,
	// Token: 0x04000607 RID: 1543
	Style13 = 8192,
	// Token: 0x04000608 RID: 1544
	Style14 = 16384,
	// Token: 0x04000609 RID: 1545
	Style15 = 32768,
	// Token: 0x0400060A RID: 1546
	All = 65535
}
