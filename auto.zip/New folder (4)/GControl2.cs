﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000120 RID: 288
public class GControl2 : UserControl
{
	// Token: 0x170003CF RID: 975
	// (get) Token: 0x06000E9B RID: 3739 RVA: 0x0000C5F0 File Offset: 0x0000A7F0
	// (set) Token: 0x06000E9C RID: 3740 RVA: 0x0000C5F8 File Offset: 0x0000A7F8
	[DefaultValue(typeof(Color), "ControlLight")]
	public Color Color_0 { get; set; }

	// Token: 0x170003D0 RID: 976
	// (get) Token: 0x06000E9D RID: 3741 RVA: 0x0000C601 File Offset: 0x0000A801
	// (set) Token: 0x06000E9E RID: 3742 RVA: 0x0000C609 File Offset: 0x0000A809
	[DefaultValue(typeof(Color), "DarkGray")]
	public Color Color_1 { get; set; }

	// Token: 0x170003D1 RID: 977
	// (get) Token: 0x06000E9F RID: 3743 RVA: 0x0000C612 File Offset: 0x0000A812
	// (set) Token: 0x06000EA0 RID: 3744 RVA: 0x0000C61A File Offset: 0x0000A81A
	[DefaultValue(typeof(Color), "Black")]
	public Color Color_2 { get; set; }

	// Token: 0x170003D2 RID: 978
	// (get) Token: 0x06000EA1 RID: 3745 RVA: 0x0000C623 File Offset: 0x0000A823
	// (set) Token: 0x06000EA2 RID: 3746 RVA: 0x0000C62B File Offset: 0x0000A82B
	[Description("Target FastColoredTextBox")]
	public FastColoredTextBox FastColoredTextBox_0
	{
		get
		{
			return this.fastColoredTextBox_0;
		}
		set
		{
			if (this.fastColoredTextBox_0 != null)
			{
				this.vmethod_1(this.fastColoredTextBox_0);
			}
			this.fastColoredTextBox_0 = value;
			this.vmethod_2(this.fastColoredTextBox_0);
			this.vmethod_0();
		}
	}

	// Token: 0x06000EA3 RID: 3747 RVA: 0x00055698 File Offset: 0x00053898
	public GControl2()
	{
		this.method_2();
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this.MinimumSize = new Size(0, 24);
		this.MaximumSize = new Size(1073741823, 24);
		this.Color_0 = SystemColors.ControlLight;
		this.Color_1 = Color.DarkGray;
		this.Color_2 = Color.Black;
	}

	// Token: 0x06000EA4 RID: 3748 RVA: 0x0000C65A File Offset: 0x0000A85A
	protected virtual void vmethod_0()
	{
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000EA5 RID: 3749 RVA: 0x0000C675 File Offset: 0x0000A875
	protected virtual void vmethod_1(FastColoredTextBox fastColoredTextBox_1)
	{
		fastColoredTextBox_1.Scroll -= this.vmethod_3;
		fastColoredTextBox_1.Event_6 -= this.method_1;
		fastColoredTextBox_1.Event_7 -= this.method_0;
	}

	// Token: 0x06000EA6 RID: 3750 RVA: 0x0000C6AE File Offset: 0x0000A8AE
	protected virtual void vmethod_2(FastColoredTextBox fastColoredTextBox_1)
	{
		fastColoredTextBox_1.Scroll += this.vmethod_3;
		fastColoredTextBox_1.Event_6 += this.method_1;
		fastColoredTextBox_1.Event_7 += this.method_0;
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x0000C6E7 File Offset: 0x0000A8E7
	private void method_0(object sender, EventArgs e)
	{
		base.Invalidate();
	}

	// Token: 0x06000EA8 RID: 3752 RVA: 0x0000C6E7 File Offset: 0x0000A8E7
	private void method_1(object sender, EventArgs e)
	{
		base.Invalidate();
	}

	// Token: 0x06000EA9 RID: 3753 RVA: 0x0000C6E7 File Offset: 0x0000A8E7
	protected virtual void vmethod_3(object sender, ScrollEventArgs e)
	{
		base.Invalidate();
	}

	// Token: 0x06000EAA RID: 3754 RVA: 0x0000C6EF File Offset: 0x0000A8EF
	protected virtual void OnResize(EventArgs e)
	{
		base.OnResize(e);
		base.Invalidate();
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x00055700 File Offset: 0x00053900
	protected virtual void OnPaint(PaintEventArgs e)
	{
		if (this.fastColoredTextBox_0 == null)
		{
			return;
		}
		Point point = base.PointToClient(this.fastColoredTextBox_0.PointToScreen(this.fastColoredTextBox_0.method_95(this.fastColoredTextBox_0.GClass86_5.GStruct2_0)));
		Size size = TextRenderer.MeasureText("W", this.Font);
		int num = 0;
		e.Graphics.FillRectangle(new LinearGradientBrush(new Rectangle(0, 0, base.Width, base.Height), this.BackColor, this.Color_0, 270f), new Rectangle(0, 0, base.Width, base.Height));
		float num2 = (float)this.fastColoredTextBox_0.Int32_4;
		StringFormat stringFormat = new StringFormat();
		stringFormat.Alignment = StringAlignment.Center;
		stringFormat.LineAlignment = StringAlignment.Near;
		Point p = this.fastColoredTextBox_0.method_94(0);
		p = base.PointToClient(this.fastColoredTextBox_0.PointToScreen(p));
		using (Pen pen = new Pen(this.Color_1))
		{
			using (SolidBrush solidBrush = new SolidBrush(this.ForeColor))
			{
				float num3 = (float)p.X;
				while (num3 < (float)base.Right)
				{
					if (num % 10 == 0)
					{
						e.Graphics.DrawString(num.ToString(), this.Font, solidBrush, num3, 0f, stringFormat);
					}
					e.Graphics.DrawLine(pen, (int)num3, size.Height + ((num % 5 == 0) ? 1 : 3), (int)num3, base.Height - 4);
					num3 += num2;
					num++;
				}
			}
		}
		using (Pen pen2 = new Pen(this.Color_1))
		{
			e.Graphics.DrawLine(pen2, new Point(point.X - 3, base.Height - 3), new Point(point.X + 3, base.Height - 3));
		}
		using (Pen pen3 = new Pen(this.Color_2))
		{
			e.Graphics.DrawLine(pen3, new Point(point.X - 2, size.Height + 3), new Point(point.X - 2, base.Height - 4));
			e.Graphics.DrawLine(pen3, new Point(point.X, size.Height + 1), new Point(point.X, base.Height - 4));
			e.Graphics.DrawLine(pen3, new Point(point.X + 2, size.Height + 3), new Point(point.X + 2, base.Height - 4));
		}
	}

	// Token: 0x06000EAC RID: 3756 RVA: 0x0000C6FE File Offset: 0x0000A8FE
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000EAD RID: 3757 RVA: 0x0000C71D File Offset: 0x0000A91D
	private void method_2()
	{
		this.icontainer_0 = new Container();
		base.AutoScaleMode = AutoScaleMode.Font;
	}

	// Token: 0x04000756 RID: 1878
	public EventHandler eventHandler_0;

	// Token: 0x04000757 RID: 1879
	[CompilerGenerated]
	private Color color_0;

	// Token: 0x04000758 RID: 1880
	[CompilerGenerated]
	private Color color_1;

	// Token: 0x04000759 RID: 1881
	[CompilerGenerated]
	private Color color_2;

	// Token: 0x0400075A RID: 1882
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x0400075B RID: 1883
	private IContainer icontainer_0;
}
