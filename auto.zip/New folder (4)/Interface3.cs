﻿using System;
using System.Windows.Forms;

// Token: 0x0200014E RID: 334
internal interface Interface3
{
	// Token: 0x0600102B RID: 4139
	Control[] imethod_0();

	// Token: 0x0600102C RID: 4140
	void imethod_1(Control[] control_0);
}
