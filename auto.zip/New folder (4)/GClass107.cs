﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x0200016C RID: 364
public class GClass107 : FlowLayoutPanel
{
	// Token: 0x060011B7 RID: 4535
	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool ShowScrollBar(IntPtr intptr_0, int int_0, bool bool_0);

	// Token: 0x060011B8 RID: 4536 RVA: 0x0000E275 File Offset: 0x0000C475
	public GClass107()
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
		GClass107.ShowScrollBar(base.Handle, 1, true);
	}

	// Token: 0x0200016D RID: 365
	private enum Enum11
	{
		// Token: 0x04000933 RID: 2355
		SB_HORZ,
		// Token: 0x04000934 RID: 2356
		SB_VERT,
		// Token: 0x04000935 RID: 2357
		SB_CTL,
		// Token: 0x04000936 RID: 2358
		SB_BOTH
	}
}
