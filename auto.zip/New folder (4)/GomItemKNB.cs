﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001E9 RID: 489
public class GomItemKNB : UserControl
{
	// Token: 0x060019D4 RID: 6612 RVA: 0x00012C00 File Offset: 0x00010E00
	public GomItemKNB()
	{
		this.InitializeComponent();
	}

	// Token: 0x060019D5 RID: 6613 RVA: 0x000BB6B0 File Offset: 0x000B98B0
	private void GomItemKNB_Load(object sender, EventArgs e)
	{
		this.txtName.Text = Class415.String_20;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(GomItemKNB.Class227.<>9.method_0)).ToArray<ListViewItem>());
	}

	// Token: 0x060019D6 RID: 6614 RVA: 0x000BB718 File Offset: 0x000B9918
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]).Replace("[locked]", "") == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtName.Text = this.txtName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtName.method_1();
	}

	// Token: 0x060019D7 RID: 6615 RVA: 0x00012C0E File Offset: 0x00010E0E
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060019D8 RID: 6616 RVA: 0x00012C0E File Offset: 0x00010E0E
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060019D9 RID: 6617 RVA: 0x00012C16 File Offset: 0x00010E16
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x060019DA RID: 6618 RVA: 0x000BB828 File Offset: 0x000B9A28
	private void txtName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_20 = this.txtName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x060019DB RID: 6619 RVA: 0x00012C2F File Offset: 0x00010E2F
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060019DC RID: 6620 RVA: 0x000BB890 File Offset: 0x000B9A90
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(GomItemKNB));
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtName = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.menuName.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(245, 355);
		this.lvName.TabIndex = 24;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 180;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtName.Dock = DockStyle.Fill;
		this.txtName.Location = new Point(0, 0);
		this.txtName.Multiline = true;
		this.txtName.Name = "txtName";
		this.txtName.ScrollBars = ScrollBars.Vertical;
		this.txtName.Size = new Size(235, 375);
		this.txtName.TabIndex = 22;
		this.txtName.String_0 = "";
		this.txtName.Color_0 = Color.Gray;
		this.txtName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtName.Color_1 = Color.LightGray;
		this.txtName.TextChanged += this.txtName_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(484, 375);
		this.splitContainer1.SplitterDistance = 235;
		this.splitContainer1.TabIndex = 0;
		this.splitContainer1.Tag = "Gom Đồ KNB";
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(245, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Name = "GomItemKNB";
		base.Size = new Size(484, 375);
		base.Tag = "Gom Đồ KNB";
		base.Load += this.GomItemKNB_Load;
		this.menuName.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000F45 RID: 3909
	private IContainer icontainer_0;

	// Token: 0x04000F46 RID: 3910
	private ListViewEx lvName;

	// Token: 0x04000F47 RID: 3911
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F48 RID: 3912
	private ContextMenuStrip menuName;

	// Token: 0x04000F49 RID: 3913
	private ToolStripMenuItem menuAddName;

	// Token: 0x04000F4A RID: 3914
	private Class85 txtName;

	// Token: 0x04000F4B RID: 3915
	private SplitContainer splitContainer1;

	// Token: 0x04000F4C RID: 3916
	private Class85 txtSearchName;

	// Token: 0x020001EA RID: 490
	[CompilerGenerated]
	[Serializable]
	private sealed class Class227
	{
		// Token: 0x060019DF RID: 6623 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000F4D RID: 3917
		public static readonly GomItemKNB.Class227 <>9 = new GomItemKNB.Class227();

		// Token: 0x04000F4E RID: 3918
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
