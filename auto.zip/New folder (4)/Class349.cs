﻿using System;

// Token: 0x02000295 RID: 661
internal class Class349
{
	// Token: 0x1700078B RID: 1931
	// (get) Token: 0x0600248F RID: 9359 RVA: 0x0001BC7C File Offset: 0x00019E7C
	public static string String_0
	{
		get
		{
			return "Biện Kinh";
		}
	}

	// Token: 0x04001833 RID: 6195
	public static int int_0 = 755;

	// Token: 0x04001834 RID: 6196
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 454U,
		Int32_0 = 410,
		Int32_1 = 380,
		Int32_2 = Class349.int_0,
		String_2 = "Tiêu Lăng"
	};

	// Token: 0x04001835 RID: 6197
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 455U,
		Int32_0 = 621,
		Int32_1 = 380,
		Int32_2 = Class349.int_0,
		String_2 = "Bích Lạc"
	};
}
