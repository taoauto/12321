﻿// Token: 0x020002ED RID: 749
internal partial class Pk : global::System.Windows.Forms.Form
{
	// Token: 0x06002AD4 RID: 10964 RVA: 0x00122558 File Offset: 0x00120758
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
		this.txtBoQua = new global::Class85();
		this.listViewName = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.menuName = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new global::System.Windows.Forms.ToolStripMenuItem();
		this.label1 = new global::System.Windows.Forms.Label();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.menuName.SuspendLayout();
		base.SuspendLayout();
		this.splitContainer1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.splitContainer1.Location = new global::System.Drawing.Point(0, 45);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtBoQua);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Size = new global::System.Drawing.Size(493, 280);
		this.splitContainer1.SplitterDistance = 239;
		this.splitContainer1.TabIndex = 9;
		this.txtBoQua.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.txtBoQua.Location = new global::System.Drawing.Point(0, 0);
		this.txtBoQua.Multiline = true;
		this.txtBoQua.Name = "txtBoQua";
		this.txtBoQua.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
		this.txtBoQua.Size = new global::System.Drawing.Size(239, 280);
		this.txtBoQua.TabIndex = 6;
		this.txtBoQua.String_0 = "";
		this.txtBoQua.Color_0 = global::System.Drawing.Color.Gray;
		this.txtBoQua.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtBoQua.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtBoQua.TextChanged += new global::System.EventHandler(this.txtBoQua_TextChanged);
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.ContextMenuStrip = this.menuName;
		this.listViewName.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = global::System.Drawing.Color.Red;
		this.listViewName.Location = new global::System.Drawing.Point(0, 0);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new global::System.Drawing.Size(250, 280);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = global::System.Windows.Forms.View.Details;
		this.listViewName.DoubleClick += new global::System.EventHandler(this.listViewName_DoubleClick);
		this.columnHeader_0.Text = "Tên người";
		this.columnHeader_0.Width = 219;
		this.menuName.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new global::System.Drawing.Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new global::System.Drawing.Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += new global::System.EventHandler(this.menuAddName_Click);
		this.label1.AutoSize = true;
		this.label1.Location = new global::System.Drawing.Point(10, 7);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(295, 26);
		this.label1.TabIndex = 10;
		this.label1.Text = "Chọn đánh theo và theo người chơi bất kỳ thay cho key thực\r\nAuto sẽ coi người đó là key, thứ tự ưu tiên từ trên xuống";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.White;
		base.ClientSize = new global::System.Drawing.Size(491, 322);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.splitContainer1);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Fixed3D;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Pk";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Hỗ trợ Pk";
		base.Load += new global::System.EventHandler(this.Pk_Load);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.menuName.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04001C81 RID: 7297
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04001C82 RID: 7298
	private global::System.Windows.Forms.SplitContainer splitContainer1;

	// Token: 0x04001C83 RID: 7299
	private global::Class85 txtBoQua;

	// Token: 0x04001C84 RID: 7300
	private global::_i.ListViewEx listViewName;

	// Token: 0x04001C85 RID: 7301
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x04001C86 RID: 7302
	private global::System.Windows.Forms.Label label1;

	// Token: 0x04001C87 RID: 7303
	private global::System.Windows.Forms.ContextMenuStrip menuName;

	// Token: 0x04001C88 RID: 7304
	private global::System.Windows.Forms.ToolStripMenuItem menuAddName;
}
