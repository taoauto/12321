﻿using System;

// Token: 0x02000280 RID: 640
internal class Class331
{
	// Token: 0x17000772 RID: 1906
	// (get) Token: 0x06002406 RID: 9222 RVA: 0x0001B86C File Offset: 0x00019A6C
	public static string String_0
	{
		get
		{
			return "Kim Lăng";
		}
	}

	// Token: 0x040017B6 RID: 6070
	public static int int_0 = 762;

	// Token: 0x040017B7 RID: 6071
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 38U,
		Int32_0 = 362,
		Int32_1 = 536,
		Int32_2 = Class331.int_0,
		String_2 = "Lạc Hà Phong"
	};

	// Token: 0x040017B8 RID: 6072
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 24U,
		Int32_0 = 365,
		Int32_1 = 350,
		Int32_2 = Class331.int_0,
		String_2 = "Lý Lập Thanh"
	};

	// Token: 0x040017B9 RID: 6073
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 30U,
		Int32_0 = 359,
		Int32_1 = 421,
		Int32_2 = Class331.int_0,
		String_2 = "Tiêu Lăng"
	};

	// Token: 0x040017BA RID: 6074
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 31U,
		Int32_0 = 361,
		Int32_1 = 446,
		Int32_2 = Class331.int_0,
		String_2 = "Bích Lạc"
	};

	// Token: 0x040017BB RID: 6075
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 8U,
		Int32_0 = 368,
		Int32_1 = 421,
		Int32_2 = Class331.int_0,
		String_2 = "Tiêu Ưng"
	};

	// Token: 0x040017BC RID: 6076
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 277,
		Int32_1 = 220,
		Int32_2 = Class331.int_0,
		String_2 = "Ân Hiên Kỳ"
	};
}
