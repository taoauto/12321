﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Threading;

// Token: 0x02000322 RID: 802
internal class Class445
{
	// Token: 0x06002E05 RID: 11781 RVA: 0x001350A8 File Offset: 0x001332A8
	internal static void smethod_0(string string_5 = null, bool bool_0 = true)
	{
		if (string_5 != "" && File.Exists(string_5))
		{
			AppDomain appDomain = null;
			Class445.string_1 = Path.GetDirectoryName(string_5);
			int num = 0;
			byte[] array = null;
			IntPtr intPtr = Class445.GetModuleHandle("mscorjit.dll");
			if (intPtr != IntPtr.Zero)
			{
				int num2 = Marshal.ReadInt32(intPtr, 60);
				int num3 = Marshal.ReadInt32(intPtr, num2 + 28);
				int num4 = Marshal.ReadInt32(intPtr, num2 + 44);
				intPtr = (IntPtr)((long)intPtr + (long)num4);
				array = new byte[num3];
				Class445.ReadProcessMemory(-1, intPtr, array, array.Length, ref num);
			}
			new Evidence(AppDomain.CurrentDomain.Evidence);
			appDomain = AppDomain.CreateDomain(Path.GetFileName(string_5), AppDomain.CurrentDomain.Evidence);
			if (appDomain != null)
			{
				appDomain.UnhandledException += Class445.smethod_2;
				Application.ThreadException += Class445.smethod_1;
			}
			if (bool_0)
			{
				appDomain.ExecuteAssembly(string_5);
			}
			else
			{
				appDomain.SetData("assembly", string_5);
				CrossAppDomainDelegate callBackDelegate = new CrossAppDomainDelegate(Class445.smethod_8);
				appDomain.DoCallBack(callBackDelegate);
			}
			try
			{
				if (intPtr != IntPtr.Zero)
				{
					Class445.WriteProcessMemory(-1, intPtr, array, array.Length, ref num);
				}
			}
			catch
			{
			}
			if (appDomain != null)
			{
				try
				{
					appDomain.UnhandledException -= Class445.smethod_2;
					Application.ThreadException -= Class445.smethod_1;
					CrossAppDomainDelegate callBackDelegate2 = new CrossAppDomainDelegate(Class445.smethod_11);
					appDomain.DoCallBack(callBackDelegate2);
					AppDomain.Unload(appDomain);
					appDomain = null;
					GC.Collect();
					GC.WaitForPendingFinalizers();
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x17000AA8 RID: 2728
	// (get) Token: 0x06002E06 RID: 11782 RVA: 0x000216F6 File Offset: 0x0001F8F6
	// (set) Token: 0x06002E07 RID: 11783 RVA: 0x000216FE File Offset: 0x0001F8FE
	internal string String_0 { get; set; } = "hello";

	// Token: 0x17000AA9 RID: 2729
	// (get) Token: 0x06002E08 RID: 11784 RVA: 0x00021707 File Offset: 0x0001F907
	// (set) Token: 0x06002E09 RID: 11785 RVA: 0x0002170E File Offset: 0x0001F90E
	private static string String_1 { get; set; } = "";

	// Token: 0x06002E0A RID: 11786 RVA: 0x00135258 File Offset: 0x00133458
	private static void smethod_1(object sender, ThreadExceptionEventArgs e)
	{
		Exception exception = e.Exception;
		Class445.Delegate9 @delegate = new Class445.Delegate9(Class445.smethod_10);
		AsyncCallback callback = new AsyncCallback(Class445.smethod_9);
		@delegate.BeginInvoke(exception, callback, null);
	}

	// Token: 0x06002E0B RID: 11787 RVA: 0x00135290 File Offset: 0x00133490
	private static void smethod_2(object sender, UnhandledExceptionEventArgs e)
	{
		Exception e2 = (Exception)e.ExceptionObject;
		Class445.Delegate9 @delegate = new Class445.Delegate9(Class445.smethod_10);
		AsyncCallback callback = new AsyncCallback(Class445.smethod_9);
		@delegate.BeginInvoke(e2, callback, null);
	}

	// Token: 0x06002E0C RID: 11788 RVA: 0x001352CC File Offset: 0x001334CC
	private static void smethod_3(Assembly assembly_0)
	{
		AssemblyName name = assembly_0.GetName();
		if (Class445.hashtable_0.Contains(name.FullName))
		{
			return;
		}
		Class445.hashtable_0.Add(name.FullName, name);
		Assembly assembly = null;
		AssemblyName[] referencedAssemblies = assembly_0.GetReferencedAssemblies();
		int i = 0;
		while (i < referencedAssemblies.Length)
		{
			AssemblyName assemblyName = referencedAssemblies[i];
			assembly = null;
			try
			{
				assembly = AppDomain.CurrentDomain.Load(assemblyName);
				goto IL_BC;
			}
			catch
			{
				string path = Path.Combine(Class445.string_1, assemblyName.Name + ".dll");
				if (File.Exists(path))
				{
					try
					{
						assembly = Assembly.ReflectionOnlyLoad(File.ReadAllBytes(path));
					}
					catch
					{
					}
				}
				goto IL_BC;
			}
			goto IL_90;
			IL_B3:
			i++;
			continue;
			IL_90:
			Class445.string_2 = Class445.string_2 + assemblyName.FullName + "\r\n";
			goto IL_B3;
			IL_BC:
			if (assembly == null)
			{
				goto IL_90;
			}
			Class445.smethod_3(assembly);
			goto IL_B3;
		}
	}

	// Token: 0x06002E0D RID: 11789 RVA: 0x001353BC File Offset: 0x001335BC
	private static string smethod_4(Exception exception_0)
	{
		if (exception_0.InnerException != null)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(Class445.smethod_4(exception_0.InnerException));
			stringBuilder.AppendLine("--- Next Call Stack:");
			stringBuilder.AppendLine(exception_0.StackTrace);
			return stringBuilder.ToString();
		}
		return exception_0.StackTrace;
	}

	// Token: 0x06002E0E RID: 11790 RVA: 0x00135410 File Offset: 0x00133610
	private static string smethod_5(Exception exception_0)
	{
		if (exception_0.InnerException != null)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(Class445.smethod_5(exception_0.InnerException));
			stringBuilder.AppendLine("   " + exception_0.Message);
			return stringBuilder.ToString();
		}
		return "   " + exception_0.Message;
	}

	// Token: 0x06002E0F RID: 11791 RVA: 0x0013546C File Offset: 0x0013366C
	private static string smethod_6(Exception exception_0)
	{
		if (exception_0.InnerException != null)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(Class445.smethod_6(exception_0.InnerException));
			stringBuilder.AppendLine("   " + exception_0.GetType().ToString());
			return stringBuilder.ToString();
		}
		return "   " + exception_0.GetType().ToString();
	}

	// Token: 0x06002E10 RID: 11792 RVA: 0x00021716 File Offset: 0x0001F916
	private static TimeSpan smethod_7()
	{
		return TimeSpan.FromSeconds(Environment.TickCount);
	}

	// Token: 0x06002E11 RID: 11793 RVA: 0x001354D0 File Offset: 0x001336D0
	private static void smethod_8()
	{
		string path = (string)AppDomain.CurrentDomain.GetData("assembly");
		Class445.string_2 = "";
		Class445.string_1 = Path.GetDirectoryName(path);
		Assembly assembly_ = Assembly.ReflectionOnlyLoad(File.ReadAllBytes(path));
		Class445.hashtable_0 = new Hashtable();
		Class445.smethod_3(assembly_);
		if (Class445.string_2 != "")
		{
			Form form = new Form();
			if (Application.OpenForms.Count > 0)
			{
				form.StartPosition = FormStartPosition.CenterScreen;
				form.WindowState = FormWindowState.Maximized;
				form.TopLevel = true;
				form.TopMost = true;
			}
			else
			{
				form.WindowState = FormWindowState.Maximized;
				form.StartPosition = FormStartPosition.CenterScreen;
			}
			form.Text = "Missing assembly finded!";
			RichTextBox richTextBox = new RichTextBox();
			form.Controls.Add(richTextBox);
			richTextBox.Top = 10;
			richTextBox.Left = 5;
			richTextBox.Width = form.Width - 20;
			richTextBox.Height = form.ClientRectangle.Height - 30 - richTextBox.Top;
			richTextBox.Text = "Missing assembly list:\r\n" + Class445.string_2;
			richTextBox.Font = new Font("Courier New", 10f);
			richTextBox.ReadOnly = true;
			richTextBox.WordWrap = false;
			richTextBox.ScrollBars = RichTextBoxScrollBars.ForcedBoth;
			richTextBox.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			Button button = new Button();
			form.Controls.Add(button);
			button.Top = form.ClientRectangle.Height - 25;
			button.Left = form.ClientRectangle.Width - 5 - button.Width;
			button.Text = "&OK";
			button.DialogResult = DialogResult.Cancel;
			button.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			button.FlatStyle = FlatStyle.System;
			form.CancelButton = button;
			form.AcceptButton = button;
			form.ShowDialog();
		}
	}

	// Token: 0x06002E12 RID: 11794 RVA: 0x00021724 File Offset: 0x0001F924
	private static void smethod_9(IAsyncResult iasyncResult_0)
	{
		((Class445.Delegate9)((AsyncResult)iasyncResult_0).AsyncDelegate).EndInvoke(iasyncResult_0);
	}

	// Token: 0x06002E13 RID: 11795 RVA: 0x00135690 File Offset: 0x00133890
	private static void smethod_10(Exception exception_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("Application:       " + Application.ProductName);
		stringBuilder.AppendLine("Version:           " + Application.ProductVersion);
		stringBuilder.AppendLine("Date:              " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
		stringBuilder.AppendLine("Computer name:     " + SystemInformation.ComputerName);
		stringBuilder.AppendLine("User name:         " + SystemInformation.UserName);
		stringBuilder.AppendLine("OS:                " + Environment.OSVersion.ToString());
		stringBuilder.AppendLine("Culture:           " + CultureInfo.CurrentCulture.Name);
		stringBuilder.AppendLine("Resolution:        " + SystemInformation.PrimaryMonitorSize.ToString());
		stringBuilder.AppendLine("System up time:    " + Class445.smethod_7().ToString());
		stringBuilder.AppendLine("App up time:       " + (DateTime.Now - Process.GetCurrentProcess().StartTime).ToString());
		Class445.Class446 @class = new Class445.Class446();
		if (Class445.GlobalMemoryStatusEx(@class))
		{
			stringBuilder.AppendLine("Total memory:      " + (@class.ulong_0 / 1048576UL).ToString() + "Mb");
			stringBuilder.AppendLine("Available memory:  " + (@class.ulong_1 / 1048576UL).ToString() + "Mb");
		}
		stringBuilder.AppendLine("");
		stringBuilder.AppendLine("Exception classes:   ");
		stringBuilder.Append(Class445.smethod_6(exception_0));
		stringBuilder.AppendLine("");
		stringBuilder.AppendLine("Exception messages: ");
		stringBuilder.Append(Class445.smethod_5(exception_0));
		Class445.String_1 = "";
		Class445.smethod_12(exception_0);
		stringBuilder.Append(Class445.String_1);
		stringBuilder.AppendLine("");
		stringBuilder.AppendLine("Stack Traces:");
		stringBuilder.Append(Class445.smethod_4(exception_0));
		stringBuilder.AppendLine("");
		stringBuilder.AppendLine("Loaded Modules:");
		foreach (object obj in Process.GetCurrentProcess().Modules)
		{
			ProcessModule processModule = (ProcessModule)obj;
			stringBuilder.AppendLine(processModule.FileName + " " + processModule.FileVersionInfo.FileVersion);
		}
		stringBuilder.AppendLine("");
		stringBuilder.AppendLine("Loaded Assemblies:");
		foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
		{
			stringBuilder.AppendLine(assembly.Location + "  (" + assembly.FullName + ")");
		}
		Form form = new Form();
		if (Application.OpenForms.Count > 0)
		{
			form.StartPosition = FormStartPosition.CenterScreen;
			form.WindowState = FormWindowState.Maximized;
			form.TopLevel = true;
			form.TopMost = true;
		}
		else
		{
			form.WindowState = FormWindowState.Maximized;
			form.StartPosition = FormStartPosition.CenterScreen;
		}
		form.Text = "Unhandled exception reached!";
		RichTextBox richTextBox = new RichTextBox();
		form.Controls.Add(richTextBox);
		richTextBox.Top = 10;
		richTextBox.Left = 5;
		richTextBox.Width = form.Width - 20;
		richTextBox.Height = form.ClientRectangle.Height - 30 - richTextBox.Top;
		richTextBox.Text = stringBuilder.ToString();
		richTextBox.Font = new Font("Courier New", 10f);
		richTextBox.ReadOnly = true;
		richTextBox.WordWrap = false;
		richTextBox.ScrollBars = RichTextBoxScrollBars.ForcedBoth;
		richTextBox.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
		Button button = new Button();
		form.Controls.Add(button);
		button.Top = form.ClientRectangle.Height - 25;
		button.Left = form.ClientRectangle.Width - 5 - button.Width;
		button.Text = "&OK";
		button.DialogResult = DialogResult.Cancel;
		button.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
		button.FlatStyle = FlatStyle.System;
		form.CancelButton = button;
		form.AcceptButton = button;
		form.ShowDialog();
	}

	// Token: 0x06002E14 RID: 11796 RVA: 0x0002173C File Offset: 0x0001F93C
	private static void smethod_11()
	{
		Dispatcher.CurrentDispatcher.InvokeShutdown();
	}

	// Token: 0x06002E15 RID: 11797 RVA: 0x00135B18 File Offset: 0x00133D18
	private static void smethod_12(Exception exception_0)
	{
		ReflectionTypeLoadException ex = exception_0 as ReflectionTypeLoadException;
		if (ex != null)
		{
			Class445.String_1 += "\r\n\r\nDetails of ReflectionTypeLoadException: ";
			Class445.String_1 = Class445.String_1 + "\r\n" + ex.Message;
			for (int i = 0; i < ex.LoaderExceptions.Length; i++)
			{
				if (ex.LoaderExceptions[i] != null)
				{
					Class445.String_1 = Class445.String_1 + "\r\n" + ex.LoaderExceptions[i].Message;
					if (ex.LoaderExceptions[i].StackTrace != "")
					{
						Class445.String_1 = Class445.String_1 + "\r\n Stack:" + ex.LoaderExceptions[i].StackTrace;
					}
					Class445.smethod_12(ex.LoaderExceptions[i]);
				}
			}
		}
		if (exception_0 is TypeLoadException)
		{
			Class445.String_1 = Class445.String_1 + ex.Message + "\r\n";
		}
	}

	// Token: 0x06002E16 RID: 11798 RVA: 0x00021748 File Offset: 0x0001F948
	private void method_0(object sender, EventArgs e)
	{
		Application.Exit();
	}

	// Token: 0x06002E17 RID: 11799 RVA: 0x00135C0C File Offset: 0x00133E0C
	private void method_1()
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Title = "Browse for target assembly";
		openFileDialog.InitialDirectory = "c:\\";
		if (this.string_3 != "")
		{
			openFileDialog.InitialDirectory = this.string_3;
		}
		openFileDialog.Filter = "All files (*.exe)|*.exe";
		openFileDialog.FilterIndex = 2;
		openFileDialog.RestoreDirectory = true;
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			string fileName = openFileDialog.FileName;
			this.String_0 = fileName;
			int num = fileName.LastIndexOf("\\");
			if (num != -1)
			{
				this.string_3 = fileName.Remove(num, fileName.Length - num);
			}
			if (this.string_3.Length == 2)
			{
				this.string_3 += "\\";
			}
		}
	}

	// Token: 0x06002E18 RID: 11800 RVA: 0x00135CCC File Offset: 0x00133ECC
	private void method_2(object sender, DragEventArgs e)
	{
		try
		{
			Array array = (Array)e.Data.GetData(DataFormats.FileDrop);
			if (array != null)
			{
				string text = array.GetValue(0).ToString();
				int num = text.LastIndexOf(".");
				if (num != -1 && text.Substring(num).ToLower() == ".exe")
				{
					int num2 = text.LastIndexOf("\\");
					if (num2 != -1)
					{
						this.string_3 = text.Remove(num2, text.Length - num2);
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x06002E19 RID: 11801 RVA: 0x0002174F File Offset: 0x0001F94F
	private void method_3(object sender, DragEventArgs e)
	{
		if (e.Data.GetDataPresent(DataFormats.FileDrop))
		{
			e.Effect = DragDropEffects.Copy;
			return;
		}
		e.Effect = DragDropEffects.None;
	}

	// Token: 0x06002E1A RID: 11802
	[DllImport("kernel32.dll")]
	private static extern bool FreeLibrary(IntPtr intptr_0);

	// Token: 0x06002E1B RID: 11803
	[DllImport("kernel32.dll")]
	private static extern IntPtr GetModuleHandle(string string_5);

	// Token: 0x06002E1C RID: 11804
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GlobalMemoryStatusEx([In] [Out] Class445.Class446 class446_0);

	// Token: 0x06002E1D RID: 11805
	[DllImport("kernel32.dll")]
	private static extern IntPtr LoadLibrary(string string_5);

	// Token: 0x06002E1E RID: 11806
	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenThread(Class445.Enum25 enum25_0, bool bool_0, uint uint_0);

	// Token: 0x06002E1F RID: 11807
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern int ReadProcessMemory(int int_0, IntPtr intptr_0, byte[] byte_0, int int_1, ref int int_2);

	// Token: 0x06002E20 RID: 11808
	[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "ReadProcessMemory", ExactSpelling = true, SetLastError = true)]
	private static extern int ReadProcessMemory_1(int int_0, IntPtr intptr_0, IntPtr intptr_1, int int_1, ref int int_2);

	// Token: 0x06002E21 RID: 11809
	[DllImport("kernel32.dll")]
	private static extern bool TerminateThread(IntPtr intptr_0, uint uint_0);

	// Token: 0x06002E22 RID: 11810
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern int WriteProcessMemory(int int_0, IntPtr intptr_0, byte[] byte_0, int int_1, ref int int_2);

	// Token: 0x04001F81 RID: 8065
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001F82 RID: 8066
	private static Hashtable hashtable_0;

	// Token: 0x04001F83 RID: 8067
	private static string string_1;

	// Token: 0x04001F84 RID: 8068
	private static string string_2;

	// Token: 0x04001F85 RID: 8069
	private string string_3 = "";

	// Token: 0x04001F86 RID: 8070
	[CompilerGenerated]
	private static string string_4;

	// Token: 0x02000323 RID: 803
	[Flags]
	private enum Enum25
	{
		// Token: 0x04001F88 RID: 8072
		TERMINATE = 1,
		// Token: 0x04001F89 RID: 8073
		SUSPEND_RESUME = 2,
		// Token: 0x04001F8A RID: 8074
		GET_CONTEXT = 8,
		// Token: 0x04001F8B RID: 8075
		SET_CONTEXT = 16,
		// Token: 0x04001F8C RID: 8076
		SET_INFORMATION = 32,
		// Token: 0x04001F8D RID: 8077
		QUERY_INFORMATION = 64,
		// Token: 0x04001F8E RID: 8078
		SET_THREAD_TOKEN = 128,
		// Token: 0x04001F8F RID: 8079
		IMPERSONATE = 256,
		// Token: 0x04001F90 RID: 8080
		DIRECT_IMPERSONATION = 512
	}

	// Token: 0x02000324 RID: 804
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	private class Class446
	{
		// Token: 0x06002E25 RID: 11813 RVA: 0x0002179C File Offset: 0x0001F99C
		internal Class446()
		{
			this.uint_0 = (uint)Marshal.SizeOf(typeof(Class445.Class446));
		}

		// Token: 0x04001F91 RID: 8081
		internal uint uint_0;

		// Token: 0x04001F92 RID: 8082
		internal uint uint_1;

		// Token: 0x04001F93 RID: 8083
		internal ulong ulong_0;

		// Token: 0x04001F94 RID: 8084
		internal ulong ulong_1;

		// Token: 0x04001F95 RID: 8085
		internal ulong ulong_2;

		// Token: 0x04001F96 RID: 8086
		internal ulong ulong_3;

		// Token: 0x04001F97 RID: 8087
		internal ulong ulong_4;

		// Token: 0x04001F98 RID: 8088
		internal ulong ulong_5;

		// Token: 0x04001F99 RID: 8089
		internal ulong ulong_6;
	}

	// Token: 0x02000325 RID: 805
	// (Invoke) Token: 0x06002E27 RID: 11815
	private delegate void Delegate9(Exception e);
}
