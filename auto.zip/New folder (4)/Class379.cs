﻿using System;
using System.Collections.Generic;

// Token: 0x020002B5 RID: 693
internal class Class379
{
	// Token: 0x06002680 RID: 9856 RVA: 0x0001CB9A File Offset: 0x0001AD9A
	public bool method_0(string string_2)
	{
		return !this.list_0.Contains(string_2);
	}

	// Token: 0x06002681 RID: 9857 RVA: 0x00110E0C File Offset: 0x0010F00C
	public void method_1(string string_2)
	{
		this.list_0.Add(string_2);
		if (this.string_0 == string_2)
		{
			this.bool_0 = false;
			return;
		}
		if (string_2 == "daily")
		{
			if (this.method_0("nhihai") && this.bool_0)
			{
				this.method_1("nhihai");
			}
			if (this.method_0("kiemcac") && this.bool_0)
			{
				this.method_1("kiemcac");
			}
			if (this.method_0("voluongson") && this.bool_0)
			{
				this.method_1("voluongson");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "nhihai")
		{
			if (this.method_0("daily") && this.bool_0)
			{
				this.method_1("daily");
			}
			if (this.method_0("thuongson") && this.bool_0)
			{
				this.method_1("thuongson");
			}
			if (this.method_0("thachlam") && this.bool_0)
			{
				this.method_1("thachlam");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "thuongson")
		{
			if (this.method_0("nhihai") && this.bool_0)
			{
				this.method_1("nhihai");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "thachlam")
		{
			if (this.method_0("nhihai") && this.bool_0)
			{
				this.method_1("nhihai");
			}
			if (this.method_0("ngockhue") && this.bool_0)
			{
				this.method_1("ngockhue");
			}
			if (this.method_0("namchieu") && this.bool_0)
			{
				this.method_1("namchieu");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "ngockhue")
		{
			if (this.method_0("thachlam") && this.bool_0)
			{
				this.method_1("thachlam");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "namchieu")
		{
			if (this.method_0("thachlam") && this.bool_0)
			{
				this.method_1("thachlam");
			}
			if (this.method_0("mieucuong") && this.bool_0)
			{
				this.method_1("mieucuong");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "mieucuong")
		{
			if (this.method_0("namchieu") && this.bool_0)
			{
				this.method_1("namchieu");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "kiemcac")
		{
			if (this.method_0("daily") && this.bool_0)
			{
				this.method_1("daily");
			}
			if (this.method_0("donhoang") && this.bool_0)
			{
				this.method_1("donhoang");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "donhoang")
		{
			if (this.method_0("kiemcac") && this.bool_0)
			{
				this.method_1("kiemcac");
			}
			if (this.method_0("lacduong") && this.bool_0)
			{
				this.method_1("lacduong");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "lacduong")
		{
			if (this.method_0("donhoang") && this.bool_0)
			{
				this.method_1("donhoang");
			}
			if (this.method_0("nhannam") && this.bool_0)
			{
				this.method_1("nhannam");
			}
			if (this.method_0("tungson") && this.bool_0)
			{
				this.method_1("tungson");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "nhannam")
		{
			if (this.method_0("lacduong") && this.bool_0)
			{
				this.method_1("lacduong");
			}
			if (this.method_0("nhanbac") && this.bool_0)
			{
				this.method_1("nhanbac");
			}
			if (this.method_0("thaonguyen") && this.bool_0)
			{
				this.method_1("thaonguyen");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "nhanbac")
		{
			if (this.method_0("nhannam") && this.bool_0)
			{
				this.method_1("nhannam");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "thaonguyen")
		{
			if (this.method_0("lieutay") && this.bool_0)
			{
				this.method_1("lieutay");
			}
			if (this.method_0("nhannam") && this.bool_0)
			{
				this.method_1("nhannam");
			}
			if (this.method_0("truongbachson") && this.bool_0)
			{
				this.method_1("truongbachson");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "lieutay")
		{
			if (this.method_0("thaonguyen") && this.bool_0)
			{
				this.method_1("thaonguyen");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "truongbachson")
		{
			if (this.method_0("thaonguyen") && this.bool_0)
			{
				this.method_1("thaonguyen");
			}
			if (this.method_0("hoanglongphu") && this.bool_0)
			{
				this.method_1("hoanglongphu");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "hoanglongphu")
		{
			if (this.method_0("truongbachson") && this.bool_0)
			{
				this.method_1("truongbachson");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "tungson")
		{
			if (this.method_0("lacduong") && this.bool_0)
			{
				this.method_1("lacduong");
			}
			if (this.method_0("thaiho") && this.bool_0)
			{
				this.method_1("thaiho");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "thaiho")
		{
			if (this.method_0("tungson") && this.bool_0)
			{
				this.method_1("tungson");
			}
			if (this.method_0("tochau") && this.bool_0)
			{
				this.method_1("tochau");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "tochau")
		{
			if (this.method_0("thaiho") && this.bool_0)
			{
				this.method_1("thaiho");
			}
			if (this.method_0("tayho") && this.bool_0)
			{
				this.method_1("tayho");
			}
			if (this.method_0("kinhho") && this.bool_0)
			{
				this.method_1("kinhho");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "kinhho")
		{
			if (this.method_0("tochau") && this.bool_0)
			{
				this.method_1("tochau");
			}
			if (this.method_0("voluongson") && this.bool_0)
			{
				this.method_1("voluongson");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "voluongson")
		{
			if (this.method_0("daily") && this.bool_0)
			{
				this.method_1("daily");
			}
			if (this.method_0("kinhho") && this.bool_0)
			{
				this.method_1("kinhho");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "tayho")
		{
			if (this.method_0("tochau") && this.bool_0)
			{
				this.method_1("tochau");
			}
			if (this.method_0("longtuyen") && this.bool_0)
			{
				this.method_1("longtuyen");
			}
			if (this.method_0("vodi") && this.bool_0)
			{
				this.method_1("vodi");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "longtuyen")
		{
			if (this.method_0("tayho") && this.bool_0)
			{
				this.method_1("tayho");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "vodi")
		{
			if (this.method_0("tayho") && this.bool_0)
			{
				this.method_1("tayho");
			}
			if (this.method_0("mailinh") && this.bool_0)
			{
				this.method_1("mailinh");
			}
			if (this.method_0("namhai") && this.bool_0)
			{
				this.method_1("namhai");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "mailinh")
		{
			if (this.method_0("vodi") && this.bool_0)
			{
				this.method_1("vodi");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "namhai")
		{
			if (this.method_0("quynhchau") && this.bool_0)
			{
				this.method_1("quynhchau");
			}
			if (this.method_0("vodi") && this.bool_0)
			{
				this.method_1("vodi");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
				return;
			}
		}
		else if (string_2 == "quynhchau")
		{
			if (this.method_0("namhai") && this.bool_0)
			{
				this.method_1("namhai");
			}
			if (this.bool_0)
			{
				this.list_0.Remove(string_2);
			}
		}
	}

	// Token: 0x06002682 RID: 9858 RVA: 0x001118F8 File Offset: 0x0010FAF8
	public string method_2(string string_2, string string_3)
	{
		if (string_2 == "kinhho")
		{
			if (string_3 == "tochau")
			{
				return "285,44";
			}
			if (string_3 == "voluongson")
			{
				return "38,284";
			}
		}
		if (string_2 == "voluongson")
		{
			if (string_3 == "daily")
			{
				return "32,176";
			}
			if (string_3 == "kinhho")
			{
				return "287,77";
			}
		}
		if (string_2 == "daily")
		{
			if (string_3 == "nhihai")
			{
				return "159,294";
			}
			if (string_3 == "kiemcac")
			{
				return "31,148";
			}
			if (string_3 == "voluongson")
			{
				return "304,149";
			}
		}
		if (string_2 == "nhihai")
		{
			if (string_3 == "daily")
			{
				return "287,32";
			}
			if (string_3 == "thachlam")
			{
				return "34,279";
			}
			if (string_3 == "thuongson")
			{
				return "34,157";
			}
		}
		if (string_2 == "thuongson" && string_3 == "nhihai")
		{
			return "286,56";
		}
		if (string_2 == "thachlam")
		{
			if (string_3 == "nhihai")
			{
				return "268,128";
			}
			if (string_3 == "ngockhue")
			{
				return "112,34";
			}
			if (string_3 == "namchieu")
			{
				return "33,250";
			}
		}
		if (string_2 == "ngockhue" && string_3 == "thachlam")
		{
			return "36,46";
		}
		if (string_2 == "namchieu")
		{
			if (string_3 == "thachlam")
			{
				return "280,45";
			}
			if (string_3 == "mieucuong")
			{
				return "106,285";
			}
		}
		if (string_2 == "mieucuong" && string_3 == "namchieu")
		{
			return "67,32";
		}
		if (string_2 == "kiemcac")
		{
			if (string_3 == "daily")
			{
				return "36,286";
			}
			if (string_3 == "donhoang")
			{
				return "105,40";
			}
		}
		if (string_2 == "donhoang")
		{
			if (string_3 == "kiemcac")
			{
				return "231,286";
			}
			if (string_3 == "lacduong")
			{
				return "284,146";
			}
		}
		if (string_2 == "lacduong")
		{
			if (string_3 == "donhoang")
			{
				return "45,248";
			}
			if (string_3 == "nhannam")
			{
				return "448,259";
			}
			if (string_3 == "tungson")
			{
				return "255,462";
			}
		}
		if (string_2 == "nhannam")
		{
			if (string_3 == "lacduong")
			{
				return "264,286";
			}
			if (string_3 == "nhanbac")
			{
				return "248,37";
			}
			if (string_3 == "thaonguyen")
			{
				return "33,58";
			}
		}
		if (string_2 == "nhanbac")
		{
			if (string_3 == "nhannam")
			{
				return "228,280";
			}
			if (string_3 == "thaolieutruong")
			{
				return "59,60";
			}
		}
		if (string_2 == "thaolieutruong" && string_3 == "nhanbac")
		{
			return "23,228";
		}
		if (string_2 == "thaonguyen")
		{
			if (string_3 == "lieutay")
			{
				return "119,32";
			}
			if (string_3 == "nhannam")
			{
				return "287,58";
			}
			if (string_3 == "truongbachson")
			{
				return "271,33";
			}
		}
		if (string_2 == "lieutay" && string_3 == "thaonguyen")
		{
			return "61,297";
		}
		if (string_2 == "truongbachson")
		{
			if (string_3 == "thaonguyen")
			{
				return "33,269";
			}
			if (string_3 == "hoanglongphu")
			{
				return "286,73";
			}
		}
		if (string_2 == "hoanglongphu" && string_3 == "truongbachson")
		{
			return "48,287";
		}
		if (string_2 == "tungson")
		{
			if (string_3 == "lacduong")
			{
				return "34,55";
			}
			if (string_3 == "thaiho")
			{
				return "286,247";
			}
		}
		if (string_2 == "thaiho")
		{
			if (string_3 == "tungson")
			{
				return "91,23";
			}
			if (string_3 == "tochau")
			{
				return "215,281";
			}
		}
		if (string_2 == "tochau")
		{
			if (string_3 == "tayho")
			{
				return "278,412";
			}
			if (string_3 == "thaiho")
			{
				return "279,44";
			}
			if (string_3 == "kinhho")
			{
				return "65,270";
			}
		}
		if (string_2 == "tayho")
		{
			if (string_3 == "tochau")
			{
				return "34,50";
			}
			if (string_3 == "longtuyen")
			{
				return "287,54";
			}
			if (string_3 == "vodi")
			{
				return "265,286";
			}
		}
		if (string_2 == "longtuyen" && string_3 == "tayho")
		{
			return "34,274";
		}
		if (string_2 == "vodi")
		{
			if (string_3 == "tayho")
			{
				return "36,33";
			}
			if (string_3 == "mailinh")
			{
				return "283,180";
			}
			if (string_3 == "namhai")
			{
				return "248,286";
			}
		}
		if (string_2 == "mailinh" && string_3 == "vodi")
		{
			return "33,275";
		}
		if (string_2 == "namhai")
		{
			if (string_3 == "vodi")
			{
				return "34,36";
			}
			if (string_3 == "quynhchau")
			{
				return "286,174";
			}
		}
		if (string_2 == "quynhchau" && string_3 == "namhai")
		{
			return "279,286";
		}
		return "0,0";
	}

	// Token: 0x06002683 RID: 9859 RVA: 0x00111EA0 File Offset: 0x001100A0
	public static string smethod_0(int int_0)
	{
		if (int_0 == 0)
		{
			return "lacduong";
		}
		if (int_0 == 1)
		{
			return "tochau";
		}
		if (int_0 == 2)
		{
			return "daily";
		}
		if (int_0 == 3)
		{
			return "tungson";
		}
		if (int_0 == 4)
		{
			return "thaiho";
		}
		if (int_0 == 7)
		{
			return "kiemcac";
		}
		if (int_0 == 8)
		{
			return "donhoang";
		}
		if (int_0 == 18)
		{
			return "nhannam";
		}
		if (int_0 == 19)
		{
			return "nhanbac";
		}
		if (int_0 == 20)
		{
			return "thaonguyen";
		}
		if (int_0 == 21)
		{
			return "lieutay";
		}
		if (int_0 == 22)
		{
			return "truongbachson";
		}
		if (int_0 == 23)
		{
			return "hoanglongphu";
		}
		if (int_0 == 24)
		{
			return "nhihai";
		}
		if (int_0 == 25)
		{
			return "thuongson";
		}
		if (int_0 == 26)
		{
			return "thachlam";
		}
		if (int_0 == 27)
		{
			return "ngockhue";
		}
		if (int_0 == 28)
		{
			return "namchieu";
		}
		if (int_0 == 29)
		{
			return "mieucuong";
		}
		if (int_0 == 30)
		{
			return "tayho";
		}
		if (int_0 == 31)
		{
			return "longtuyen";
		}
		if (int_0 == 32)
		{
			return "vodi";
		}
		if (int_0 == 33)
		{
			return "mailinh";
		}
		if (int_0 == Class365.Int32_39)
		{
			return "namhai";
		}
		if (int_0 == Class365.Int32_40)
		{
			return "quynhchau";
		}
		if (int_0 == Class365.Int32_43)
		{
			return "thaolieutruong";
		}
		return "";
	}

	// Token: 0x06002684 RID: 9860 RVA: 0x00111FD4 File Offset: 0x001101D4
	public static int smethod_1(string string_2)
	{
		if (string_2 == "lacduong")
		{
			return 0;
		}
		if (string_2 == "tochau")
		{
			return 1;
		}
		if (string_2 == "daily")
		{
			return 2;
		}
		if (string_2 == "tungson")
		{
			return 3;
		}
		if (string_2 == "thaiho")
		{
			return 4;
		}
		if (string_2 == "kiemcac")
		{
			return 7;
		}
		if (string_2 == "donhoang")
		{
			return 8;
		}
		if (string_2 == "nhannam")
		{
			return 18;
		}
		if (string_2 == "nhanbac")
		{
			return 19;
		}
		if (string_2 == "thaonguyen")
		{
			return 20;
		}
		if (string_2 == "lieutay")
		{
			return 21;
		}
		if (string_2 == "truongbachson")
		{
			return 22;
		}
		if (string_2 == "hoanglongphu")
		{
			return 23;
		}
		if (string_2 == "nhihai")
		{
			return 24;
		}
		if (string_2 == "thuongson")
		{
			return 25;
		}
		if (string_2 == "thachlam")
		{
			return 26;
		}
		if (string_2 == "ngockhue")
		{
			return 27;
		}
		if (string_2 == "namchieu")
		{
			return 28;
		}
		if (string_2 == "mieucuong")
		{
			return 29;
		}
		if (string_2 == "tayho")
		{
			return 30;
		}
		if (string_2 == "longtuyen")
		{
			return 31;
		}
		if (string_2 == "vodi")
		{
			return 32;
		}
		if (string_2 == "mailinh")
		{
			return 33;
		}
		if (string_2 == "namhai")
		{
			return 34;
		}
		if (string_2 == "quynhchau")
		{
			return 35;
		}
		if (string_2 == "thaolieutruong")
		{
			return Class365.Int32_43;
		}
		return -1;
	}

	// Token: 0x040019E7 RID: 6631
	public string string_0 = string.Empty;

	// Token: 0x040019E8 RID: 6632
	public string string_1 = string.Empty;

	// Token: 0x040019E9 RID: 6633
	public List<string> list_0 = new List<string>();

	// Token: 0x040019EA RID: 6634
	public bool bool_0 = true;
}
