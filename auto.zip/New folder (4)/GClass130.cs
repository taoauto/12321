﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x02000326 RID: 806
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
public class GClass130
{
	// Token: 0x06002E2A RID: 11818 RVA: 0x00002E70 File Offset: 0x00001070
	internal GClass130()
	{
	}

	// Token: 0x17000AAA RID: 2730
	// (get) Token: 0x06002E2B RID: 11819 RVA: 0x000217B9 File Offset: 0x0001F9B9
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static ResourceManager ResourceManager_0
	{
		get
		{
			if (GClass130.resourceManager_0 == null)
			{
				GClass130.resourceManager_0 = new ResourceManager("_Nn\"!=hX>vwg2H{0(@\\,}t!pY)", typeof(GClass130).Assembly);
			}
			return GClass130.resourceManager_0;
		}
	}

	// Token: 0x17000AAB RID: 2731
	// (get) Token: 0x06002E2C RID: 11820 RVA: 0x000217E5 File Offset: 0x0001F9E5
	// (set) Token: 0x06002E2D RID: 11821 RVA: 0x000217EC File Offset: 0x0001F9EC
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static CultureInfo CultureInfo_0
	{
		get
		{
			return GClass130.cultureInfo_0;
		}
		set
		{
			GClass130.cultureInfo_0 = value;
		}
	}

	// Token: 0x17000AAC RID: 2732
	// (get) Token: 0x06002E2E RID: 11822 RVA: 0x000217F4 File Offset: 0x0001F9F4
	public static Bitmap Bitmap_0
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("Beri", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AAD RID: 2733
	// (get) Token: 0x06002E2F RID: 11823 RVA: 0x0002180F File Offset: 0x0001FA0F
	public static Icon Icon_0
	{
		get
		{
			return (Icon)GClass130.ResourceManager_0.GetObject("BeriIcon", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AAE RID: 2734
	// (get) Token: 0x06002E30 RID: 11824 RVA: 0x0002182A File Offset: 0x0001FA2A
	public static UnmanagedMemoryStream UnmanagedMemoryStream_0
	{
		get
		{
			return GClass130.ResourceManager_0.GetStream("chat", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AAF RID: 2735
	// (get) Token: 0x06002E31 RID: 11825 RVA: 0x00021840 File Offset: 0x0001FA40
	public static UnmanagedMemoryStream UnmanagedMemoryStream_1
	{
		get
		{
			return GClass130.ResourceManager_0.GetStream("chatex", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB0 RID: 2736
	// (get) Token: 0x06002E32 RID: 11826 RVA: 0x00021856 File Offset: 0x0001FA56
	public static string String_0
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("ChinhTuyen", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB1 RID: 2737
	// (get) Token: 0x06002E33 RID: 11827 RVA: 0x0002186C File Offset: 0x0001FA6C
	public static Bitmap Bitmap_1
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("exp", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB2 RID: 2738
	// (get) Token: 0x06002E34 RID: 11828 RVA: 0x00021887 File Offset: 0x0001FA87
	public static string String_1
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("Fix2D", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB3 RID: 2739
	// (get) Token: 0x06002E35 RID: 11829 RVA: 0x0002189D File Offset: 0x0001FA9D
	public static string String_2
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("Fix3D", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB4 RID: 2740
	// (get) Token: 0x06002E36 RID: 11830 RVA: 0x000218B3 File Offset: 0x0001FAB3
	public static string String_3
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("FixDG", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB5 RID: 2741
	// (get) Token: 0x06002E37 RID: 11831 RVA: 0x000218C9 File Offset: 0x0001FAC9
	public static Bitmap Bitmap_2
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("hp", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB6 RID: 2742
	// (get) Token: 0x06002E38 RID: 11832 RVA: 0x000218E4 File Offset: 0x0001FAE4
	public static Icon Icon_1
	{
		get
		{
			return (Icon)GClass130.ResourceManager_0.GetObject("icon", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB7 RID: 2743
	// (get) Token: 0x06002E39 RID: 11833 RVA: 0x000218FF File Offset: 0x0001FAFF
	public static Bitmap Bitmap_3
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("loading", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB8 RID: 2744
	// (get) Token: 0x06002E3A RID: 11834 RVA: 0x0002191A File Offset: 0x0001FB1A
	public static string String_4
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("Lua", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AB9 RID: 2745
	// (get) Token: 0x06002E3B RID: 11835 RVA: 0x00021930 File Offset: 0x0001FB30
	public static string String_5
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("LuaEx", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABA RID: 2746
	// (get) Token: 0x06002E3C RID: 11836 RVA: 0x00021946 File Offset: 0x0001FB46
	public static Bitmap Bitmap_4
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("map", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABB RID: 2747
	// (get) Token: 0x06002E3D RID: 11837 RVA: 0x00021961 File Offset: 0x0001FB61
	public static string String_6
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("mapini", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABC RID: 2748
	// (get) Token: 0x06002E3E RID: 11838 RVA: 0x00021977 File Offset: 0x0001FB77
	public static Bitmap Bitmap_5
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("mid", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABD RID: 2749
	// (get) Token: 0x06002E3F RID: 11839 RVA: 0x00021992 File Offset: 0x0001FB92
	public static Bitmap Bitmap_6
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("mp", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABE RID: 2750
	// (get) Token: 0x06002E40 RID: 11840 RVA: 0x000219AD File Offset: 0x0001FBAD
	public static Icon Icon_2
	{
		get
		{
			return (Icon)GClass130.ResourceManager_0.GetObject("paused", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000ABF RID: 2751
	// (get) Token: 0x06002E41 RID: 11841 RVA: 0x000219C8 File Offset: 0x0001FBC8
	public static UnmanagedMemoryStream UnmanagedMemoryStream_2
	{
		get
		{
			return GClass130.ResourceManager_0.GetStream("pm", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AC0 RID: 2752
	// (get) Token: 0x06002E42 RID: 11842 RVA: 0x000219DE File Offset: 0x0001FBDE
	public static string String_7
	{
		get
		{
			return GClass130.ResourceManager_0.GetString("Publishers", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AC1 RID: 2753
	// (get) Token: 0x06002E43 RID: 11843 RVA: 0x000219F4 File Offset: 0x0001FBF4
	public static Bitmap Bitmap_7
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("save", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x17000AC2 RID: 2754
	// (get) Token: 0x06002E44 RID: 11844 RVA: 0x00021A0F File Offset: 0x0001FC0F
	public static Bitmap Bitmap_8
	{
		get
		{
			return (Bitmap)GClass130.ResourceManager_0.GetObject("sound", GClass130.cultureInfo_0);
		}
	}

	// Token: 0x04001F9A RID: 8090
	private static ResourceManager resourceManager_0;

	// Token: 0x04001F9B RID: 8091
	private static CultureInfo cultureInfo_0;
}
