﻿using System;

// Token: 0x02000320 RID: 800
internal class Class443
{
	// Token: 0x06002DFE RID: 11774 RVA: 0x00134974 File Offset: 0x00132B74
	public static int smethod_0(string string_0, string string_1)
	{
		if (string_0 == "daily")
		{
			if (string_1 == "nhihai")
			{
				return 3;
			}
			if (string_1 == "kiemcac")
			{
				return 4;
			}
		}
		if (string_0 == "nhihai")
		{
			if (string_1 == "daily")
			{
				return 2;
			}
			if (string_1 == "thachlam")
			{
				return 3;
			}
			if (string_1 == "thuongson")
			{
				return 1;
			}
		}
		if (string_0 == "thuongson" && string_1 == "nhihai")
		{
			return 2;
		}
		if (string_0 == "thachlam")
		{
			if (string_1 == "nhihai")
			{
				return 1;
			}
			if (string_1 == "ngockhue")
			{
				return 5;
			}
			if (string_1 == "namchieu")
			{
				return 2;
			}
		}
		if (string_0 == "ngockhue" && string_1 == "thachlam")
		{
			return 1;
		}
		if (string_0 == "namchieu")
		{
			if (string_1 == "thachlam")
			{
				return 2;
			}
			if (string_1 == "mieucuong")
			{
				return 1;
			}
		}
		if (string_0 == "mieucuong" && string_1 == "namchieu")
		{
			return 1;
		}
		if (string_0 == "kiemcac")
		{
			if (string_1 == "daily")
			{
				return 2;
			}
			if (string_1 == "donhoang")
			{
				return 3;
			}
		}
		if (string_0 == "donhoang")
		{
			if (string_1 == "kiemcac")
			{
				return 2;
			}
			if (string_1 == "lacduong")
			{
				return 3;
			}
		}
		if (string_0 == "lacduong")
		{
			if (string_1 == "donhoang")
			{
				return 4;
			}
			if (string_1 == "nhannam")
			{
				return 6;
			}
			if (string_1 == "tungson")
			{
				return 5;
			}
		}
		if (string_0 == "nhannam")
		{
			if (string_1 == "lacduong")
			{
				return 2;
			}
			if (string_1 == "nhanbac")
			{
				return 4;
			}
			if (string_1 == "thaonguyen")
			{
				return 1;
			}
		}
		if (string_0 == "nhanbac" && string_1 == "nhannam")
		{
			return 3;
		}
		if (string_0 == "thaonguyen")
		{
			if (string_1 == "lieutay")
			{
				return 2;
			}
			if (string_1 == "nhannam")
			{
				return 4;
			}
			if (string_1 == "truongbachson")
			{
				return 1;
			}
		}
		if (string_0 == "lieutay" && string_1 == "thaonguyen")
		{
			return 1;
		}
		if (string_0 == "truongbachson")
		{
			if (string_1 == "thaonguyen")
			{
				return 1;
			}
			if (string_1 == "hoanglongphu")
			{
				return 2;
			}
		}
		if (string_0 == "hoanglongphu" && string_1 == "truongbachson")
		{
			return 1;
		}
		if (string_0 == "tungson")
		{
			if (string_1 == "lacduong")
			{
				return 1;
			}
			if (string_1 == "thaiho")
			{
				return 3;
			}
		}
		if (string_0 == "thaiho")
		{
			if (string_1 == "tungson")
			{
				return 3;
			}
			if (string_1 == "tochau")
			{
				return 4;
			}
		}
		if (string_0 == "tochau")
		{
			if (string_1 == "tayho")
			{
				return 6;
			}
			if (string_1 == "thaiho")
			{
				return 5;
			}
		}
		if (string_0 == "tayho")
		{
			if (string_1 == "tochau")
			{
				return 3;
			}
			if (string_1 == "longtuyen")
			{
				return 1;
			}
			if (string_1 == "vodi")
			{
				return 4;
			}
		}
		if (string_0 == "longtuyen" && string_1 == "tayho")
		{
			return 2;
		}
		if (string_0 == "vodi")
		{
			if (string_1 == "tayho")
			{
				return 4;
			}
			if (string_1 == "mailinh")
			{
				return 2;
			}
			if (string_1 == "namhai")
			{
				return 3;
			}
		}
		if (string_0 == "mailinh" && string_1 == "vodi")
		{
			return 2;
		}
		if (string_0 == "namhai")
		{
			if (string_1 == "vodi")
			{
				return 3;
			}
			if (string_1 == "quynhchau")
			{
				return 2;
			}
		}
		if (string_0 == "quynhchau" && string_1 == "namhai")
		{
			return 1;
		}
		return -1;
	}

	// Token: 0x06002DFF RID: 11775 RVA: 0x00134D98 File Offset: 0x00132F98
	public static string smethod_1(int int_0)
	{
		if (int_0 == 0)
		{
			return "lacduong";
		}
		if (int_0 == 1)
		{
			return "tochau";
		}
		if (int_0 == 2)
		{
			return "daily";
		}
		if (int_0 == 3)
		{
			return "tungson";
		}
		if (int_0 == 4)
		{
			return "thaiho";
		}
		if (int_0 == 7)
		{
			return "kiemcac";
		}
		if (int_0 == 8)
		{
			return "donhoang";
		}
		if (int_0 == 18)
		{
			return "nhannam";
		}
		if (int_0 == 19)
		{
			return "nhanbac";
		}
		if (int_0 == 20)
		{
			return "thaonguyen";
		}
		if (int_0 == 21)
		{
			return "lieutay";
		}
		if (int_0 == 22)
		{
			return "truongbachson";
		}
		if (int_0 == 23)
		{
			return "hoanglongphu";
		}
		if (int_0 == 24)
		{
			return "nhihai";
		}
		if (int_0 == 25)
		{
			return "thuongson";
		}
		if (int_0 == 26)
		{
			return "thachlam";
		}
		if (int_0 == 27)
		{
			return "ngockhue";
		}
		if (int_0 == 28)
		{
			return "namchieu";
		}
		if (int_0 == 29)
		{
			return "mieucuong";
		}
		if (int_0 == 30)
		{
			return "tayho";
		}
		if (int_0 == 31)
		{
			return "longtuyen";
		}
		if (int_0 == 32)
		{
			return "vodi";
		}
		if (int_0 == 33)
		{
			return "mailinh";
		}
		if (int_0 == 34)
		{
			return "namhai";
		}
		if (int_0 == 35)
		{
			return "quynhchau";
		}
		return "khongbiet";
	}

	// Token: 0x06002E00 RID: 11776 RVA: 0x00134EB8 File Offset: 0x001330B8
	public static int smethod_2(string string_0)
	{
		if (string_0 == "lacduong")
		{
			return 0;
		}
		if (string_0 == "tochau")
		{
			return 1;
		}
		if (string_0 == "daily")
		{
			return 2;
		}
		if (string_0 == "tungson")
		{
			return 3;
		}
		if (string_0 == "thaiho")
		{
			return 4;
		}
		if (string_0 == "kiemcac")
		{
			return 7;
		}
		if (string_0 == "donhoang")
		{
			return 8;
		}
		if (string_0 == "nhannam")
		{
			return 18;
		}
		if (string_0 == "nhanbac")
		{
			return 19;
		}
		if (string_0 == "thaonguyen")
		{
			return 20;
		}
		if (string_0 == "lieutay")
		{
			return 21;
		}
		if (string_0 == "truongbachson")
		{
			return 22;
		}
		if (string_0 == "hoanglongphu")
		{
			return 23;
		}
		if (string_0 == "nhihai")
		{
			return 24;
		}
		if (string_0 == "thuongson")
		{
			return 25;
		}
		if (string_0 == "thachlam")
		{
			return 26;
		}
		if (string_0 == "ngockhue")
		{
			return 27;
		}
		if (string_0 == "namchieu")
		{
			return 28;
		}
		if (string_0 == "mieucuong")
		{
			return 29;
		}
		if (string_0 == "tayho")
		{
			return 30;
		}
		if (string_0 == "longtuyen")
		{
			return 31;
		}
		if (string_0 == "vodi")
		{
			return 32;
		}
		if (string_0 == "mailinh")
		{
			return 33;
		}
		if (string_0 == "namhai")
		{
			return 34;
		}
		if (string_0 == "quynhchau")
		{
			return 35;
		}
		return -1;
	}
}
