﻿using System;
using System.IO;

// Token: 0x020000A7 RID: 167
internal class Stream2 : Stream
{
	// Token: 0x060007C1 RID: 1985 RVA: 0x00008259 File Offset: 0x00006459
	internal Stream2(Stream stream_1, byte[] byte_1, int int_2, int int_3) : this(stream_1, byte_1, int_2, int_3, -1L)
	{
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x00008268 File Offset: 0x00006468
	internal Stream2(Stream stream_1, byte[] byte_1, int int_2, int int_3, long long_1)
	{
		this.stream_0 = stream_1;
		this.byte_0 = byte_1;
		this.int_1 = int_2;
		this.int_0 = int_3;
		this.long_0 = long_1;
	}

	// Token: 0x1700021F RID: 543
	// (get) Token: 0x060007C3 RID: 1987 RVA: 0x0000354C File Offset: 0x0000174C
	public virtual bool CanRead
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000220 RID: 544
	// (get) Token: 0x060007C4 RID: 1988 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool CanSeek
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000221 RID: 545
	// (get) Token: 0x060007C5 RID: 1989 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool CanWrite
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000222 RID: 546
	// (get) Token: 0x060007C6 RID: 1990 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Length
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x17000223 RID: 547
	// (get) Token: 0x060007C7 RID: 1991 RVA: 0x00004192 File Offset: 0x00002392
	// (set) Token: 0x060007C8 RID: 1992 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Position
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x0003ABF4 File Offset: 0x00038DF4
	private int method_0(byte[] byte_1, int int_2, int int_3)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("buffer");
		}
		if (int_2 < 0)
		{
			throw new ArgumentOutOfRangeException("offset", "A negative value.");
		}
		if (int_3 < 0)
		{
			throw new ArgumentOutOfRangeException("count", "A negative value.");
		}
		int num = byte_1.Length;
		if (int_2 + int_3 > num)
		{
			throw new ArgumentException("The sum of 'offset' and 'count' is greater than 'buffer' length.");
		}
		if (this.long_0 == 0L)
		{
			return -1;
		}
		if (this.int_0 != 0 && int_3 != 0)
		{
			if (int_3 > this.int_0)
			{
				int_3 = this.int_0;
			}
			if (this.long_0 > 0L && (long)int_3 > this.long_0)
			{
				int_3 = (int)this.long_0;
			}
			Buffer.BlockCopy(this.byte_0, this.int_1, byte_1, int_2, int_3);
			this.int_1 += int_3;
			this.int_0 -= int_3;
			if (this.long_0 > 0L)
			{
				this.long_0 -= (long)int_3;
			}
			return int_3;
		}
		return 0;
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x0003ACDC File Offset: 0x00038EDC
	public virtual IAsyncResult \u206E\u202B\u206E\u206E\u202C\u206A\u206F\u206D\u200B\u202A\u206D\u202B\u206F\u206A\u206F\u206E\u202B\u200B\u202A\u200D\u206B\u206F\u206F\u200C\u206B\u206E\u206C\u202A\u206A\u202A\u202C\u200D\u202B\u202D\u206C\u206E\u206A\u206E\u206B\u202C\u202E(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		int num = this.method_0(buffer, offset, count);
		if (num <= 0)
		{
			if (num != -1)
			{
				if (this.long_0 >= 0L && (long)count > this.long_0)
				{
					count = (int)this.long_0;
				}
				return this.stream_0.BeginRead(buffer, offset, count, callback, state);
			}
		}
		Class77 @class = new Class77(callback, state);
		@class.Byte_0 = buffer;
		@class.Int32_1 = offset;
		@class.Int32_0 = count;
		@class.Int32_2 = ((num > 0) ? num : 0);
		@class.method_0();
		return @class;
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x00004192 File Offset: 0x00002392
	public virtual IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x00008295 File Offset: 0x00006495
	public virtual void \u200B\u206D\u206C\u202A\u202B\u202B\u200F\u200E\u206C\u202E\u200F\u206B\u206A\u206B\u200B\u202B\u206F\u200E\u202D\u206F\u206E\u200D\u200E\u202B\u206A\u202D\u200C\u200E\u206B\u206B\u206B\u206C\u206E\u206B\u206A\u202E\u200F\u200C\u200F\u200C\u202E()
	{
		this.bool_0 = true;
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x0003AD78 File Offset: 0x00038F78
	public virtual int \u200F\u206B\u202D\u202E\u202E\u200D\u206A\u206E\u200B\u202E\u200E\u206E\u206E\u200F\u206E\u206A\u202C\u206F\u206B\u202D\u206D\u200F\u206A\u206E\u206C\u200C\u200F\u206E\u206D\u202A\u200D\u206F\u200B\u202E\u206D\u206B\u202A\u200B\u202B\u206D\u202E(IAsyncResult asyncResult)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		if (asyncResult == null)
		{
			throw new ArgumentNullException("asyncResult");
		}
		if (asyncResult is Class77)
		{
			Class77 @class = (Class77)asyncResult;
			if (!@class.IsCompleted)
			{
				@class.AsyncWaitHandle.WaitOne();
			}
			return @class.Int32_2;
		}
		int num = this.stream_0.EndRead(asyncResult);
		if (num > 0 && this.long_0 > 0L)
		{
			this.long_0 -= (long)num;
		}
		return num;
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x00004192 File Offset: 0x00002392
	public virtual void EndWrite(IAsyncResult asyncResult)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void Flush()
	{
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x0003AE04 File Offset: 0x00039004
	public virtual int \u200C\u200B\u200D\u200C\u202A\u202C\u206F\u202D\u200B\u202C\u202D\u200B\u202E\u200E\u202A\u200E\u202B\u200D\u202E\u206D\u200C\u206B\u200B\u206E\u202C\u206D\u200B\u206D\u202E\u206D\u200B\u206B\u200D\u202B\u206E\u202B\u206D\u206C\u206E\u200D\u202E(byte[] buffer, int offset, int count)
	{
		if (this.bool_0)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		int num = this.method_0(buffer, offset, count);
		if (num == -1)
		{
			return 0;
		}
		if (num > 0)
		{
			return num;
		}
		num = this.stream_0.Read(buffer, offset, count);
		if (num > 0 && this.long_0 > 0L)
		{
			this.long_0 -= (long)num;
		}
		return num;
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x00004192 File Offset: 0x00002392
	public virtual long Seek(long offset, SeekOrigin origin)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x00004192 File Offset: 0x00002392
	public virtual void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x00004192 File Offset: 0x00002392
	public virtual void Write(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	// Token: 0x0400043A RID: 1082
	private long long_0;

	// Token: 0x0400043B RID: 1083
	private byte[] byte_0;

	// Token: 0x0400043C RID: 1084
	private int int_0;

	// Token: 0x0400043D RID: 1085
	private bool bool_0;

	// Token: 0x0400043E RID: 1086
	private int int_1;

	// Token: 0x0400043F RID: 1087
	private Stream stream_0;
}
