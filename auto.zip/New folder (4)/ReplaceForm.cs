﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

// Token: 0x0200011F RID: 287
public partial class ReplaceForm : Form
{
	// Token: 0x06000E8C RID: 3724 RVA: 0x0000C548 File Offset: 0x0000A748
	public ReplaceForm(FastColoredTextBox fastColoredTextBox_1)
	{
		this.InitializeComponent();
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
	}

	// Token: 0x06000E8D RID: 3725 RVA: 0x0000B572 File Offset: 0x00009772
	private void btClose_Click(object sender, EventArgs e)
	{
		base.Close();
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x00054B50 File Offset: 0x00052D50
	private void btFindNext_Click(object sender, EventArgs e)
	{
		try
		{
			if (!this.method_1(this.tbFind.Text))
			{
				MessageBox.Show("Not found");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x00054B9C File Offset: 0x00052D9C
	public List<GClass86> method_0(string string_0)
	{
		RegexOptions regexOptions_ = this.cbMatchCase.Checked ? RegexOptions.None : RegexOptions.IgnoreCase;
		if (!this.cbRegex.Checked)
		{
			string_0 = Regex.Escape(string_0);
		}
		if (this.cbWholeWord.Checked)
		{
			string_0 = "\\b" + string_0 + "\\b";
		}
		GClass86 gclass = this.fastColoredTextBox_0.GClass86_5.Boolean_2 ? this.fastColoredTextBox_0.GClass86_6.method_6() : this.fastColoredTextBox_0.GClass86_5.method_6();
		List<GClass86> list = new List<GClass86>();
		foreach (GClass86 item in gclass.method_30(string_0, regexOptions_))
		{
			list.Add(item);
		}
		return list;
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x00054C6C File Offset: 0x00052E6C
	public bool method_1(string string_0)
	{
		RegexOptions regexOptions_ = this.cbMatchCase.Checked ? RegexOptions.None : RegexOptions.IgnoreCase;
		if (!this.cbRegex.Checked)
		{
			string_0 = Regex.Escape(string_0);
		}
		if (this.cbWholeWord.Checked)
		{
			string_0 = "\\b" + string_0 + "\\b";
		}
		GClass86 gclass = this.fastColoredTextBox_0.GClass86_5.method_6();
		gclass.method_40();
		if (this.bool_0)
		{
			this.gstruct2_0 = gclass.GStruct2_0;
			this.bool_0 = false;
		}
		gclass.GStruct2_0 = gclass.GStruct2_1;
		if (GStruct2.smethod_5(gclass.GStruct2_0, this.gstruct2_0))
		{
			gclass.GStruct2_1 = new GStruct2(this.fastColoredTextBox_0.method_23(this.fastColoredTextBox_0.Int32_14 - 1), this.fastColoredTextBox_0.Int32_14 - 1);
		}
		else
		{
			gclass.GStruct2_1 = this.gstruct2_0;
		}
		using (IEnumerator<GClass86> enumerator = gclass.method_30(string_0, regexOptions_).GetEnumerator())
		{
			if (enumerator.MoveNext())
			{
				GClass86 gclass2 = enumerator.Current;
				this.fastColoredTextBox_0.GClass86_5.GStruct2_0 = gclass2.GStruct2_0;
				this.fastColoredTextBox_0.GClass86_5.GStruct2_1 = gclass2.GStruct2_1;
				this.fastColoredTextBox_0.method_51();
				this.fastColoredTextBox_0.method_4();
				return true;
			}
		}
		if (GStruct2.smethod_5(gclass.GStruct2_0, this.gstruct2_0) && GStruct2.smethod_4(this.gstruct2_0, GStruct2.GStruct2_0))
		{
			this.fastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
			return this.method_1(string_0);
		}
		return false;
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x0000C564 File Offset: 0x0000A764
	private void tbReplace_KeyPress(object sender, KeyPressEventArgs e)
	{
		if (e.KeyChar == '\r')
		{
			this.btFindNext_Click(sender, null);
		}
		if (e.KeyChar == '\u001b')
		{
			base.Hide();
		}
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0000B5E8 File Offset: 0x000097E8
	protected virtual bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		if (keyData == Keys.Escape)
		{
			base.Close();
			return true;
		}
		return base.ProcessCmdKey(ref msg, keyData);
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x0000C588 File Offset: 0x0000A788
	private void ReplaceForm_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (e.CloseReason == CloseReason.UserClosing)
		{
			e.Cancel = true;
			base.Hide();
		}
		this.fastColoredTextBox_0.Focus();
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x00054E18 File Offset: 0x00053018
	private void btReplace_Click(object sender, EventArgs e)
	{
		try
		{
			if (this.fastColoredTextBox_0.Int32_17 != 0 && !this.fastColoredTextBox_0.GClass86_5.Boolean_1)
			{
				this.fastColoredTextBox_0.vmethod_20(this.tbReplace.Text);
			}
			this.btFindNext_Click(sender, null);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x00054E84 File Offset: 0x00053084
	private void btReplaceAll_Click(object sender, EventArgs e)
	{
		try
		{
			this.fastColoredTextBox_0.GClass86_5.method_38();
			List<GClass86> list = this.method_0(this.tbFind.Text);
			bool flag = false;
			using (List<GClass86>.Enumerator enumerator = list.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Boolean_1)
					{
						flag = true;
						break;
					}
				}
			}
			if (!flag && list.Count > 0)
			{
				this.fastColoredTextBox_0.GClass99_0.GClass59_0.vmethod_0(new GClass64(this.fastColoredTextBox_0.GClass99_0, list, this.tbReplace.Text));
				this.fastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
			}
			this.fastColoredTextBox_0.method_4();
			MessageBox.Show(list.Count.ToString() + " occurrence(s) replaced");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
		this.fastColoredTextBox_0.GClass86_5.method_39();
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x0000C5AC File Offset: 0x0000A7AC
	protected virtual void OnActivated(EventArgs e)
	{
		this.tbFind.Focus();
		this.method_2();
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x0000C5C0 File Offset: 0x0000A7C0
	private void method_2()
	{
		this.bool_0 = true;
	}

	// Token: 0x06000E98 RID: 3736 RVA: 0x0000C5C9 File Offset: 0x0000A7C9
	private void tbReplace_TextChanged(object sender, EventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x0000C5D1 File Offset: 0x0000A7D1
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000747 RID: 1863
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x04000748 RID: 1864
	private bool bool_0 = true;

	// Token: 0x04000749 RID: 1865
	private GStruct2 gstruct2_0;

	// Token: 0x0400074A RID: 1866
	private IContainer icontainer_0;
}
