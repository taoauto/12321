﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using _i;

// Token: 0x020002E8 RID: 744
internal class TuyetGiao : UserControl
{
	// Token: 0x06002AA6 RID: 10918 RVA: 0x00121944 File Offset: 0x0011FB44
	public TuyetGiao(Class159 class159_1)
	{
		this.InitializeComponent();
		this.class159_0 = class159_1;
		this.LvFriend.Columns[0].Text = "Name [" + class159_1.Class432_0.String_2 + "]";
		this.method_0();
	}

	// Token: 0x06002AA7 RID: 10919 RVA: 0x0001F0E8 File Offset: 0x0001D2E8
	private void method_0()
	{
		Task.Run(new Action(this.method_1));
	}

	// Token: 0x06002AA8 RID: 10920 RVA: 0x0001F0FC File Offset: 0x0001D2FC
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_2)).Start();
	}

	// Token: 0x06002AA9 RID: 10921 RVA: 0x0001F114 File Offset: 0x0001D314
	private void LvFriend_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.A && e.Control)
		{
			this.LvFriend.smethod_12();
		}
	}

	// Token: 0x06002AAA RID: 10922 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06002AAB RID: 10923 RVA: 0x0001F133 File Offset: 0x0001D333
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06002AAC RID: 10924 RVA: 0x0012199C File Offset: 0x0011FB9C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(TuyetGiao));
		this.contextMenuStrip1 = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.button1 = new Button();
		this.LvFriend = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.contextMenuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.contextMenuStrip1.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_0
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new Size(131, 26);
		this.toolStripMenuItem_0.Name = "tuyệtGiaoToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(130, 22);
		this.toolStripMenuItem_0.Text = "Tuyệt Giao";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.button1.Dock = DockStyle.Top;
		this.button1.Location = new Point(0, 0);
		this.button1.Name = "button1";
		this.button1.Size = new Size(314, 20);
		this.button1.TabIndex = 1;
		this.button1.Text = "Close";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.LvFriend.AllowColumnReorder = true;
		this.LvFriend.AllowDrop = true;
		this.LvFriend.AllowReorder = true;
		this.LvFriend.AllowSort = false;
		this.LvFriend.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.LvFriend.ContextMenuStrip = this.contextMenuStrip1;
		this.LvFriend.Dock = DockStyle.Fill;
		this.LvFriend.DoubleClickActivation = false;
		this.LvFriend.FullRowSelect = true;
		this.LvFriend.GridLines = true;
		this.LvFriend.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("LvFriend.hideItems");
		this.LvFriend.HideSelection = false;
		this.LvFriend.LineColor = Color.Red;
		this.LvFriend.Location = new Point(0, 20);
		this.LvFriend.Name = "LvFriend";
		this.LvFriend.Size = new Size(314, 379);
		this.LvFriend.TabIndex = 0;
		this.LvFriend.UseCompatibleStateImageBehavior = false;
		this.LvFriend.View = View.Details;
		this.LvFriend.KeyDown += this.LvFriend_KeyDown;
		this.columnHeader_0.Text = "Tên";
		this.columnHeader_0.Width = 184;
		this.columnHeader_1.Text = "Index";
		this.columnHeader_1.Width = 74;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.LvFriend);
		base.Controls.Add(this.button1);
		base.Name = "TuyetGiao";
		base.Size = new Size(314, 399);
		this.contextMenuStrip1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x06002AAD RID: 10925 RVA: 0x00121D2C File Offset: 0x0011FF2C
	[CompilerGenerated]
	private void method_1()
	{
		this.LvFriend.Items.Clear();
		this.class159_0.method_282("local online = ''; for i = 1 , 8 do local j = i; if i == 8 then j = 13; end local relealFriendNumber = DataPool:GetFriendNumber( tonumber(j) ); local index=0; while index < relealFriendNumber  do local guid =  DataPool:GetFriend( tonumber(j), tonumber(index), 'NAME' ); if( DataPool:GetFriend( tonumber(j), tonumber(index), 'NAME' ) ) then online = online  .. guid .. ':' .. (j .. ',' .. index) .. '-'; end index = index + 1; end end return online;", false);
		string text = this.class159_0.method_396("GetFriend");
		Thread.Sleep(600);
		text = this.class159_0.method_396("GetFriend");
		this.LvFriend.Items.AddRange(text.Split(new char[]
		{
			'-'
		}).ToList<string>().Where(new Func<string, bool>(TuyetGiao.Class410.<>9.method_0)).Select(new Func<string, ListViewItem>(TuyetGiao.Class410.<>9.method_1)).ToArray<ListViewItem>());
	}

	// Token: 0x06002AAE RID: 10926 RVA: 0x00121DFC File Offset: 0x0011FFFC
	[CompilerGenerated]
	private void method_2()
	{
		Thread.CurrentThread.IsBackground = true;
		foreach (ListViewItem listViewItem in this.LvFriend.SelectedItems.Cast<ListViewItem>().ToArray<ListViewItem>().Reverse<ListViewItem>())
		{
			this.class159_0.method_282("DataPool:DelFriend(" + listViewItem.SubItems[1].Text + ");", false);
			listViewItem.Remove();
			Thread.Sleep(500);
		}
		this.method_0();
	}

	// Token: 0x04001C6E RID: 7278
	private Class159 class159_0;

	// Token: 0x04001C6F RID: 7279
	private IContainer icontainer_0;

	// Token: 0x04001C70 RID: 7280
	private ListViewEx LvFriend;

	// Token: 0x04001C71 RID: 7281
	private ColumnHeader columnHeader_0;

	// Token: 0x04001C72 RID: 7282
	private ColumnHeader columnHeader_1;

	// Token: 0x04001C73 RID: 7283
	private ContextMenuStrip contextMenuStrip1;

	// Token: 0x04001C74 RID: 7284
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04001C75 RID: 7285
	private Button button1;

	// Token: 0x020002E9 RID: 745
	[CompilerGenerated]
	[Serializable]
	private sealed class Class410
	{
		// Token: 0x06002AB1 RID: 10929 RVA: 0x0001F15E File Offset: 0x0001D35E
		internal bool method_0(string string_0)
		{
			return string_0.Split(new char[]
			{
				':'
			}).Length == 2;
		}

		// Token: 0x06002AB2 RID: 10930 RVA: 0x00121EA4 File Offset: 0x001200A4
		internal ListViewItem method_1(string string_0)
		{
			return new ListViewItem(string_0.Split(new char[]
			{
				':'
			})[0])
			{
				SubItems = 
				{
					string_0.Split(new char[]
					{
						':'
					})[1]
				}
			};
		}

		// Token: 0x04001C76 RID: 7286
		public static readonly TuyetGiao.Class410 <>9 = new TuyetGiao.Class410();

		// Token: 0x04001C77 RID: 7287
		public static Func<string, bool> <>9__2_1;

		// Token: 0x04001C78 RID: 7288
		public static Func<string, ListViewItem> <>9__2_2;
	}
}
