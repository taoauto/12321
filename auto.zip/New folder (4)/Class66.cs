﻿using System;

// Token: 0x02000082 RID: 130
internal class Class66
{
	// Token: 0x060005C5 RID: 1477 RVA: 0x00006AFE File Offset: 0x00004CFE
	public Class66(byte[] byte_1)
	{
		this.byte_0 = byte_1;
	}

	// Token: 0x17000179 RID: 377
	// (get) Token: 0x060005C6 RID: 1478 RVA: 0x00006B0D File Offset: 0x00004D0D
	public int Int32_0
	{
		get
		{
			return this.byte_0.Length - this.int_0;
		}
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x00033ADC File Offset: 0x00031CDC
	public int method_0(byte[] byte_1, int int_1, int int_2)
	{
		int num = this.byte_0.Length - this.int_0;
		if (num == 0)
		{
			return num;
		}
		if (int_2 > num)
		{
			int_2 = num;
		}
		Buffer.BlockCopy(this.byte_0, this.int_0, byte_1, int_1, int_2);
		this.int_0 += int_2;
		return int_2;
	}

	// Token: 0x040002DD RID: 733
	private byte[] byte_0;

	// Token: 0x040002DE RID: 734
	private int int_0;
}
