﻿using System;

// Token: 0x020000A2 RID: 162
internal enum Enum8
{
	// Token: 0x0400042A RID: 1066
	RequestLine,
	// Token: 0x0400042B RID: 1067
	Headers
}
