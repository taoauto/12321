﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000ED RID: 237
public class GEventArgs14 : EventArgs
{
	// Token: 0x06000C9E RID: 3230 RVA: 0x0000B199 File Offset: 0x00009399
	public GEventArgs14(int int_5, string string_2, string string_3, int int_6, int int_7)
	{
		this.Int32_0 = int_5;
		this.String_0 = string_2;
		this.String_1 = string_3;
		this.Int32_1 = int_6;
		this.Int32_4 = int_7;
	}

	// Token: 0x17000357 RID: 855
	// (get) Token: 0x06000C9F RID: 3231 RVA: 0x0000B1C6 File Offset: 0x000093C6
	// (set) Token: 0x06000CA0 RID: 3232 RVA: 0x0000B1CE File Offset: 0x000093CE
	public int Int32_0 { get; internal set; }

	// Token: 0x17000358 RID: 856
	// (get) Token: 0x06000CA1 RID: 3233 RVA: 0x0000B1D7 File Offset: 0x000093D7
	// (set) Token: 0x06000CA2 RID: 3234 RVA: 0x0000B1DF File Offset: 0x000093DF
	public int Int32_1 { get; internal set; }

	// Token: 0x17000359 RID: 857
	// (get) Token: 0x06000CA3 RID: 3235 RVA: 0x0000B1E8 File Offset: 0x000093E8
	// (set) Token: 0x06000CA4 RID: 3236 RVA: 0x0000B1F0 File Offset: 0x000093F0
	public string String_0 { get; internal set; }

	// Token: 0x1700035A RID: 858
	// (get) Token: 0x06000CA5 RID: 3237 RVA: 0x0000B1F9 File Offset: 0x000093F9
	// (set) Token: 0x06000CA6 RID: 3238 RVA: 0x0000B201 File Offset: 0x00009401
	public string String_1 { get; internal set; }

	// Token: 0x1700035B RID: 859
	// (get) Token: 0x06000CA7 RID: 3239 RVA: 0x0000B20A File Offset: 0x0000940A
	// (set) Token: 0x06000CA8 RID: 3240 RVA: 0x0000B212 File Offset: 0x00009412
	public int Int32_2 { get; set; }

	// Token: 0x1700035C RID: 860
	// (get) Token: 0x06000CA9 RID: 3241 RVA: 0x0000B21B File Offset: 0x0000941B
	// (set) Token: 0x06000CAA RID: 3242 RVA: 0x0000B223 File Offset: 0x00009423
	public int Int32_3 { get; set; }

	// Token: 0x1700035D RID: 861
	// (get) Token: 0x06000CAB RID: 3243 RVA: 0x0000B22C File Offset: 0x0000942C
	// (set) Token: 0x06000CAC RID: 3244 RVA: 0x0000B234 File Offset: 0x00009434
	public int Int32_4 { get; set; }

	// Token: 0x040005D0 RID: 1488
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040005D1 RID: 1489
	[CompilerGenerated]
	private int int_1;

	// Token: 0x040005D2 RID: 1490
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040005D3 RID: 1491
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040005D4 RID: 1492
	[CompilerGenerated]
	private int int_2;

	// Token: 0x040005D5 RID: 1493
	[CompilerGenerated]
	private int int_3;

	// Token: 0x040005D6 RID: 1494
	[CompilerGenerated]
	private int int_4;
}
