﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000289 RID: 649
internal class Class339
{
	// Token: 0x1700077C RID: 1916
	// (get) Token: 0x06002423 RID: 9251 RVA: 0x0001B8DC File Offset: 0x00019ADC
	// (set) Token: 0x06002424 RID: 9252 RVA: 0x0001B8E4 File Offset: 0x00019AE4
	public string String_0 { get; private set; }

	// Token: 0x1700077D RID: 1917
	// (get) Token: 0x06002425 RID: 9253 RVA: 0x0001B8ED File Offset: 0x00019AED
	// (set) Token: 0x06002426 RID: 9254 RVA: 0x0001B8F5 File Offset: 0x00019AF5
	public string String_1 { get; private set; }

	// Token: 0x06002427 RID: 9255 RVA: 0x0001B8FE File Offset: 0x00019AFE
	public Class339(string string_2, string string_3)
	{
		this.String_0 = string_2;
		this.String_1 = string_3;
	}

	// Token: 0x06002428 RID: 9256 RVA: 0x0001B914 File Offset: 0x00019B14
	public virtual string ToString()
	{
		return this.String_1;
	}

	// Token: 0x040017DE RID: 6110
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040017DF RID: 6111
	[CompilerGenerated]
	private string string_1;
}
