﻿using System;
using System.Collections;
using System.Windows.Forms;

// Token: 0x02000301 RID: 769
internal class Class423 : IComparer
{
	// Token: 0x06002C14 RID: 11284 RVA: 0x00127974 File Offset: 0x00125B74
	public int Compare(object a, object b)
	{
		int result;
		try
		{
			ListViewItem listViewItem = a as ListViewItem;
			ListViewItem listViewItem2 = b as ListViewItem;
			uint uint32_ = ((Class417)listViewItem.Tag).UInt32_4;
			uint uint32_2 = ((Class417)listViewItem2.Tag).UInt32_4;
			if (listViewItem.Checked && !listViewItem2.Checked)
			{
				result = -1;
			}
			else if (!listViewItem.Checked && listViewItem2.Checked)
			{
				result = 1;
			}
			else if (uint32_ > uint32_2)
			{
				result = 1;
			}
			else if (uint32_ < uint32_2)
			{
				result = -1;
			}
			else
			{
				result = 0;
			}
		}
		catch
		{
			result = 0;
		}
		return result;
	}
}
