﻿using System;
using System.Text;

// Token: 0x02000171 RID: 369
internal class Class157 : Class156
{
	// Token: 0x060011E5 RID: 4581 RVA: 0x00066D84 File Offset: 0x00064F84
	public override IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string string_0, IntPtr intptr_0)
	{
		this.vmethod_0();
		if (!intptr_0.smethod_4() && !intptr_0.smethod_2(-1L))
		{
			try
			{
				IntPtr result = IntPtr.Zero;
				IntPtr procAddress = GClass120.GetProcAddress(GClass120.GetModuleHandleA("kernel32.dll"), "LoadLibraryW");
				if (procAddress.smethod_4())
				{
					throw new Exception("Unable to locate the LoadLibraryW entry point");
				}
				IntPtr intPtr = GClass120.smethod_0(intptr_0, Encoding.Unicode.GetBytes(string_0 + "\0"), 4);
				if (intPtr.smethod_4())
				{
					throw new InvalidOperationException("Failed to allocate memory in the remote process");
				}
				try
				{
					uint num = GClass120.smethod_7(intptr_0, procAddress, (uint)intPtr.ToInt32(), 10000);
					if (num == 0U)
					{
						throw new Exception("Failed to load module into remote process. Error code: " + GClass120.smethod_1(intptr_0).ToString());
					}
					if (num == 4294967295U)
					{
						throw new Exception("Error occurred when calling function in the remote process");
					}
					result = GClass119.smethod_3((long)((ulong)num));
				}
				finally
				{
					GClass120.VirtualFreeEx(intptr_0, intPtr, 0, 32768);
				}
				return result;
			}
			catch (Exception exception_)
			{
				this.vmethod_2(exception_);
				return IntPtr.Zero;
			}
		}
		throw new ArgumentOutOfRangeException("hProcess", "Invalid process handle specified.");
	}

	// Token: 0x060011E6 RID: 4582 RVA: 0x00066EB4 File Offset: 0x000650B4
	public override IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(string[] string_0, IntPtr intptr_0)
	{
		this.vmethod_0();
		if (!intptr_0.smethod_4() && !intptr_0.smethod_2(-1L))
		{
			try
			{
				IntPtr zero = IntPtr.Zero;
				IntPtr intPtr = this.vmethod_10(string_0, intptr_0, out zero, 0U);
				IntPtr[] array = null;
				if (!intPtr.smethod_4())
				{
					try
					{
						if (GClass120.smethod_7(intptr_0, intPtr, 0U, 10000) == 4294967295U)
						{
							throw new Exception("Error occurred while executing remote thread.");
						}
						byte[] array2 = GClass120.smethod_4(intptr_0, zero, (uint)((uint)string_0.Length << 2));
						if (array2 == null)
						{
							throw new InvalidOperationException("Unable to read from the remote process.");
						}
						array = new IntPtr[string_0.Length];
						for (int i = 0; i < array.Length; i++)
						{
							array[i] = new IntPtr(BitConverter.ToInt32(array2, i << 2));
						}
					}
					finally
					{
						GClass120.VirtualFreeEx(intptr_0, zero, 0, 32768);
						GClass120.VirtualFreeEx(intptr_0, intPtr, 0, 32768);
					}
				}
				return array;
			}
			catch (Exception exception_)
			{
				this.vmethod_2(exception_);
				return null;
			}
		}
		throw new ArgumentOutOfRangeException("hProcess", "Invalid process handle specified.");
	}
}
