﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000198 RID: 408
public partial class FastMove : Form
{
	// Token: 0x06001291 RID: 4753 RVA: 0x0000E975 File Offset: 0x0000CB75
	public FastMove()
	{
		this.InitializeComponent();
		base.Icon = GClass130.Icon_1;
	}

	// Token: 0x06001292 RID: 4754 RVA: 0x00069C70 File Offset: 0x00067E70
	private void FastMove_Load(object sender, EventArgs e)
	{
		foreach (KeyValuePair<int, string> keyValuePair in Class363.dictionary_4)
		{
			ListViewItem listViewItem = new ListViewItem(keyValuePair.Value);
			listViewItem.Tag = keyValuePair.Key;
			listViewItem.SubItems.Add(keyValuePair.Key.ToString());
			this.listViewEx1.Items.Add(listViewItem);
		}
	}

	// Token: 0x06001293 RID: 4755 RVA: 0x00069D08 File Offset: 0x00067F08
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		if (this.listViewEx1.SelectedItems.Count > 0)
		{
			try
			{
				this.int_0 = (int)this.listViewEx1.SelectedItems[0].Tag;
				Main.Main_0.IEnumerable_3.smethod_13(new Action<Class159>(this.method_0));
				this.Text = "=>" + this.listViewEx1.SelectedItems[0].Text;
			}
			catch
			{
			}
		}
	}

	// Token: 0x06001294 RID: 4756 RVA: 0x0000E995 File Offset: 0x0000CB95
	private void textBoxEx1_KeyDown(object sender, KeyEventArgs e)
	{
		this.listViewEx1.Search(this.textBoxEx1.Text);
	}

	// Token: 0x06001295 RID: 4757 RVA: 0x0000E9AE File Offset: 0x0000CBAE
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (this.int_0 == -1)
		{
			return;
		}
		Main.Main_0.IEnumerable_3.smethod_13(new Action<Class159>(this.method_1));
	}

	// Token: 0x06001296 RID: 4758 RVA: 0x0000E9D5 File Offset: 0x0000CBD5
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001298 RID: 4760 RVA: 0x0000E9F4 File Offset: 0x0000CBF4
	[CompilerGenerated]
	private void method_0(Class159 class159_0)
	{
		class159_0.method_70(100f, 100f, this.int_0, false, 3f, 30f);
	}

	// Token: 0x06001299 RID: 4761 RVA: 0x0000EA18 File Offset: 0x0000CC18
	[CompilerGenerated]
	private void method_1(Class159 class159_0)
	{
		if ((ulong)class159_0.Class432_0.UInt32_29 != (ulong)((long)this.int_0))
		{
			class159_0.method_70(100f, 100f, this.int_0, false, 3f, 30f);
		}
	}

	// Token: 0x04000A54 RID: 2644
	private int int_0 = -1;
}
