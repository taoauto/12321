﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;

// Token: 0x02000235 RID: 565
internal class Class268
{
	// Token: 0x170006C5 RID: 1733
	// (get) Token: 0x06001E96 RID: 7830 RVA: 0x00016A8D File Offset: 0x00014C8D
	// (set) Token: 0x06001E97 RID: 7831 RVA: 0x00016A94 File Offset: 0x00014C94
	public static Class220 Class220_0 { get; set; }

	// Token: 0x170006C6 RID: 1734
	// (get) Token: 0x06001E98 RID: 7832 RVA: 0x00016A9C File Offset: 0x00014C9C
	// (set) Token: 0x06001E99 RID: 7833 RVA: 0x00016AA3 File Offset: 0x00014CA3
	public static bool Boolean_0 { get; set; }

	// Token: 0x170006C7 RID: 1735
	// (get) Token: 0x06001E9A RID: 7834 RVA: 0x00016AAB File Offset: 0x00014CAB
	// (set) Token: 0x06001E9B RID: 7835 RVA: 0x00016AB2 File Offset: 0x00014CB2
	public static bool Boolean_1 { get; set; }

	// Token: 0x170006C8 RID: 1736
	// (get) Token: 0x06001E9C RID: 7836 RVA: 0x00016ABA File Offset: 0x00014CBA
	// (set) Token: 0x06001E9D RID: 7837 RVA: 0x00016AC1 File Offset: 0x00014CC1
	public static bool Boolean_2 { get; set; }

	// Token: 0x170006C9 RID: 1737
	// (get) Token: 0x06001E9E RID: 7838 RVA: 0x00016AC9 File Offset: 0x00014CC9
	// (set) Token: 0x06001E9F RID: 7839 RVA: 0x00016AD0 File Offset: 0x00014CD0
	public static bool Boolean_3 { get; set; }

	// Token: 0x170006CA RID: 1738
	// (get) Token: 0x06001EA0 RID: 7840 RVA: 0x00016AD8 File Offset: 0x00014CD8
	// (set) Token: 0x06001EA1 RID: 7841 RVA: 0x00016ADF File Offset: 0x00014CDF
	public static bool Boolean_4 { get; set; } = false;

	// Token: 0x170006CB RID: 1739
	// (get) Token: 0x06001EA2 RID: 7842 RVA: 0x00016AE7 File Offset: 0x00014CE7
	// (set) Token: 0x06001EA3 RID: 7843 RVA: 0x00016AEE File Offset: 0x00014CEE
	public static bool Boolean_5 { get; set; } = false;

	// Token: 0x170006CC RID: 1740
	// (get) Token: 0x06001EA4 RID: 7844 RVA: 0x00016AF6 File Offset: 0x00014CF6
	// (set) Token: 0x06001EA5 RID: 7845 RVA: 0x00016AFD File Offset: 0x00014CFD
	public static bool Boolean_6 { get; set; } = false;

	// Token: 0x170006CD RID: 1741
	// (get) Token: 0x06001EA6 RID: 7846 RVA: 0x00016B05 File Offset: 0x00014D05
	// (set) Token: 0x06001EA7 RID: 7847 RVA: 0x00016B0C File Offset: 0x00014D0C
	public static bool Boolean_7 { get; set; }

	// Token: 0x170006CE RID: 1742
	// (get) Token: 0x06001EA8 RID: 7848 RVA: 0x00016B14 File Offset: 0x00014D14
	public static string String_0
	{
		get
		{
			return "40.5.0";
		}
	}

	// Token: 0x170006CF RID: 1743
	// (get) Token: 0x06001EA9 RID: 7849 RVA: 0x00016B1B File Offset: 0x00014D1B
	// (set) Token: 0x06001EAA RID: 7850 RVA: 0x00016B22 File Offset: 0x00014D22
	public static bool Boolean_8 { get; set; }

	// Token: 0x170006D0 RID: 1744
	// (get) Token: 0x06001EAB RID: 7851 RVA: 0x00016B2A File Offset: 0x00014D2A
	// (set) Token: 0x06001EAC RID: 7852 RVA: 0x00016B31 File Offset: 0x00014D31
	public static int Int32_0 { get; set; }

	// Token: 0x170006D1 RID: 1745
	// (get) Token: 0x06001EAD RID: 7853 RVA: 0x00016B39 File Offset: 0x00014D39
	// (set) Token: 0x06001EAE RID: 7854 RVA: 0x00016B40 File Offset: 0x00014D40
	public static int Int32_1 { get; set; } = 1;

	// Token: 0x170006D2 RID: 1746
	// (get) Token: 0x06001EAF RID: 7855 RVA: 0x00016B48 File Offset: 0x00014D48
	// (set) Token: 0x06001EB0 RID: 7856 RVA: 0x00016B4F File Offset: 0x00014D4F
	public static Dictionary<string, string> Dictionary_0 { get; set; } = new Dictionary<string, string>();

	// Token: 0x170006D3 RID: 1747
	// (get) Token: 0x06001EB1 RID: 7857 RVA: 0x00016B57 File Offset: 0x00014D57
	// (set) Token: 0x06001EB2 RID: 7858 RVA: 0x00016B5E File Offset: 0x00014D5E
	public static bool Boolean_9 { get; set; }

	// Token: 0x170006D4 RID: 1748
	// (get) Token: 0x06001EB3 RID: 7859 RVA: 0x00016B66 File Offset: 0x00014D66
	// (set) Token: 0x06001EB4 RID: 7860 RVA: 0x00016B6D File Offset: 0x00014D6D
	public static int Int32_2 { get; set; }

	// Token: 0x170006D5 RID: 1749
	// (get) Token: 0x06001EB5 RID: 7861 RVA: 0x00016B75 File Offset: 0x00014D75
	// (set) Token: 0x06001EB6 RID: 7862 RVA: 0x00016B7C File Offset: 0x00014D7C
	public static int Int32_3 { get; set; }

	// Token: 0x170006D6 RID: 1750
	// (get) Token: 0x06001EB7 RID: 7863 RVA: 0x00016B84 File Offset: 0x00014D84
	// (set) Token: 0x06001EB8 RID: 7864 RVA: 0x00016B8B File Offset: 0x00014D8B
	public static bool Boolean_10 { get; set; }

	// Token: 0x170006D7 RID: 1751
	// (get) Token: 0x06001EB9 RID: 7865 RVA: 0x00016B93 File Offset: 0x00014D93
	// (set) Token: 0x06001EBA RID: 7866 RVA: 0x00016B9A File Offset: 0x00014D9A
	public static int Int32_4 { get; set; } = 179;

	// Token: 0x170006D8 RID: 1752
	// (get) Token: 0x06001EBB RID: 7867 RVA: 0x00016BA2 File Offset: 0x00014DA2
	// (set) Token: 0x06001EBC RID: 7868 RVA: 0x00016BA9 File Offset: 0x00014DA9
	public static bool Boolean_11 { get; set; }

	// Token: 0x170006D9 RID: 1753
	// (get) Token: 0x06001EBD RID: 7869 RVA: 0x00016BB1 File Offset: 0x00014DB1
	// (set) Token: 0x06001EBE RID: 7870 RVA: 0x00016BB8 File Offset: 0x00014DB8
	public static int Int32_5 { get; set; } = 6;

	// Token: 0x170006DA RID: 1754
	// (get) Token: 0x06001EBF RID: 7871 RVA: 0x00016BC0 File Offset: 0x00014DC0
	// (set) Token: 0x06001EC0 RID: 7872 RVA: 0x00016BC7 File Offset: 0x00014DC7
	public static bool Boolean_12 { get; set; }

	// Token: 0x170006DB RID: 1755
	// (get) Token: 0x06001EC1 RID: 7873 RVA: 0x00016BCF File Offset: 0x00014DCF
	// (set) Token: 0x06001EC2 RID: 7874 RVA: 0x00016BD6 File Offset: 0x00014DD6
	public static bool Boolean_13 { get; set; }

	// Token: 0x170006DC RID: 1756
	// (get) Token: 0x06001EC3 RID: 7875 RVA: 0x00016BDE File Offset: 0x00014DDE
	// (set) Token: 0x06001EC4 RID: 7876 RVA: 0x00016BE5 File Offset: 0x00014DE5
	public static bool Boolean_14 { get; set; }

	// Token: 0x170006DD RID: 1757
	// (get) Token: 0x06001EC5 RID: 7877 RVA: 0x00016BED File Offset: 0x00014DED
	// (set) Token: 0x06001EC6 RID: 7878 RVA: 0x00016BF4 File Offset: 0x00014DF4
	public static bool Boolean_15 { get; set; }

	// Token: 0x170006DE RID: 1758
	// (get) Token: 0x06001EC7 RID: 7879 RVA: 0x00016BFC File Offset: 0x00014DFC
	// (set) Token: 0x06001EC8 RID: 7880 RVA: 0x00016C03 File Offset: 0x00014E03
	public static bool Boolean_16 { get; set; }

	// Token: 0x170006DF RID: 1759
	// (get) Token: 0x06001EC9 RID: 7881 RVA: 0x00016C0B File Offset: 0x00014E0B
	// (set) Token: 0x06001ECA RID: 7882 RVA: 0x00016C12 File Offset: 0x00014E12
	public static bool Boolean_17 { get; set; }

	// Token: 0x170006E0 RID: 1760
	// (get) Token: 0x06001ECB RID: 7883 RVA: 0x00016C1A File Offset: 0x00014E1A
	// (set) Token: 0x06001ECC RID: 7884 RVA: 0x00016C21 File Offset: 0x00014E21
	public static int Int32_6 { get; set; } = 100;

	// Token: 0x170006E1 RID: 1761
	// (get) Token: 0x06001ECD RID: 7885 RVA: 0x00016C29 File Offset: 0x00014E29
	// (set) Token: 0x06001ECE RID: 7886 RVA: 0x00016C30 File Offset: 0x00014E30
	public static int Int32_7 { get; set; } = 100;

	// Token: 0x170006E2 RID: 1762
	// (get) Token: 0x06001ECF RID: 7887 RVA: 0x00016C38 File Offset: 0x00014E38
	// (set) Token: 0x06001ED0 RID: 7888 RVA: 0x00016C3F File Offset: 0x00014E3F
	public static bool Boolean_18 { get; set; }

	// Token: 0x170006E3 RID: 1763
	// (get) Token: 0x06001ED1 RID: 7889 RVA: 0x00016C47 File Offset: 0x00014E47
	// (set) Token: 0x06001ED2 RID: 7890 RVA: 0x00016C4E File Offset: 0x00014E4E
	public static bool Boolean_19 { get; set; }

	// Token: 0x170006E4 RID: 1764
	// (get) Token: 0x06001ED3 RID: 7891 RVA: 0x00016C56 File Offset: 0x00014E56
	// (set) Token: 0x06001ED4 RID: 7892 RVA: 0x00016C5D File Offset: 0x00014E5D
	public static bool Boolean_20 { get; set; }

	// Token: 0x170006E5 RID: 1765
	// (get) Token: 0x06001ED5 RID: 7893 RVA: 0x00016C65 File Offset: 0x00014E65
	public static bool Boolean_21
	{
		get
		{
			return Class268.Boolean_1;
		}
	}

	// Token: 0x170006E6 RID: 1766
	// (get) Token: 0x06001ED6 RID: 7894 RVA: 0x00016C6C File Offset: 0x00014E6C
	// (set) Token: 0x06001ED7 RID: 7895 RVA: 0x00016C73 File Offset: 0x00014E73
	public static string String_1 { get; set; }

	// Token: 0x170006E7 RID: 1767
	// (get) Token: 0x06001ED8 RID: 7896 RVA: 0x00016C7B File Offset: 0x00014E7B
	// (set) Token: 0x06001ED9 RID: 7897 RVA: 0x00016C82 File Offset: 0x00014E82
	public static uint UInt32_0 { get; set; }

	// Token: 0x170006E8 RID: 1768
	// (get) Token: 0x06001EDA RID: 7898 RVA: 0x00016C8A File Offset: 0x00014E8A
	// (set) Token: 0x06001EDB RID: 7899 RVA: 0x00016C91 File Offset: 0x00014E91
	public static bool Boolean_22 { get; set; }

	// Token: 0x170006E9 RID: 1769
	// (get) Token: 0x06001EDC RID: 7900 RVA: 0x00016C99 File Offset: 0x00014E99
	// (set) Token: 0x06001EDD RID: 7901 RVA: 0x00016CA0 File Offset: 0x00014EA0
	public static bool Boolean_23 { get; set; }

	// Token: 0x170006EA RID: 1770
	// (get) Token: 0x06001EDE RID: 7902 RVA: 0x00016CA8 File Offset: 0x00014EA8
	// (set) Token: 0x06001EDF RID: 7903 RVA: 0x00016CAF File Offset: 0x00014EAF
	public static bool Boolean_24 { get; set; }

	// Token: 0x170006EB RID: 1771
	// (get) Token: 0x06001EE0 RID: 7904 RVA: 0x00016CB7 File Offset: 0x00014EB7
	// (set) Token: 0x06001EE1 RID: 7905 RVA: 0x00016CBE File Offset: 0x00014EBE
	public static bool Boolean_25 { get; set; } = true;

	// Token: 0x170006EC RID: 1772
	// (get) Token: 0x06001EE2 RID: 7906 RVA: 0x00016CC6 File Offset: 0x00014EC6
	// (set) Token: 0x06001EE3 RID: 7907 RVA: 0x00016CCD File Offset: 0x00014ECD
	public static bool Boolean_26 { get; set; } = false;

	// Token: 0x170006ED RID: 1773
	// (get) Token: 0x06001EE4 RID: 7908 RVA: 0x00016CD5 File Offset: 0x00014ED5
	// (set) Token: 0x06001EE5 RID: 7909 RVA: 0x00016CDC File Offset: 0x00014EDC
	public static int Int32_8 { get; set; } = 15;

	// Token: 0x170006EE RID: 1774
	// (get) Token: 0x06001EE6 RID: 7910 RVA: 0x00016CE4 File Offset: 0x00014EE4
	// (set) Token: 0x06001EE7 RID: 7911 RVA: 0x00016CEB File Offset: 0x00014EEB
	public static bool Boolean_27 { get; set; }

	// Token: 0x170006EF RID: 1775
	// (get) Token: 0x06001EE8 RID: 7912 RVA: 0x00016CF3 File Offset: 0x00014EF3
	// (set) Token: 0x06001EE9 RID: 7913 RVA: 0x00016CFA File Offset: 0x00014EFA
	public static bool Boolean_28 { get; set; }

	// Token: 0x170006F0 RID: 1776
	// (get) Token: 0x06001EEA RID: 7914 RVA: 0x00016D02 File Offset: 0x00014F02
	// (set) Token: 0x06001EEB RID: 7915 RVA: 0x00016D09 File Offset: 0x00014F09
	public static bool Boolean_29 { get; set; } = false;

	// Token: 0x170006F1 RID: 1777
	// (get) Token: 0x06001EEC RID: 7916 RVA: 0x00016D11 File Offset: 0x00014F11
	// (set) Token: 0x06001EED RID: 7917 RVA: 0x00016D18 File Offset: 0x00014F18
	public static bool Boolean_30 { get; set; }

	// Token: 0x170006F2 RID: 1778
	// (get) Token: 0x06001EEE RID: 7918 RVA: 0x00016D20 File Offset: 0x00014F20
	// (set) Token: 0x06001EEF RID: 7919 RVA: 0x00016D27 File Offset: 0x00014F27
	public static bool Boolean_31 { get; set; }

	// Token: 0x170006F3 RID: 1779
	// (get) Token: 0x06001EF0 RID: 7920 RVA: 0x00016D2F File Offset: 0x00014F2F
	// (set) Token: 0x06001EF1 RID: 7921 RVA: 0x00016D36 File Offset: 0x00014F36
	public static bool Boolean_32 { get; set; }

	// Token: 0x170006F4 RID: 1780
	// (get) Token: 0x06001EF2 RID: 7922 RVA: 0x00016D3E File Offset: 0x00014F3E
	// (set) Token: 0x06001EF3 RID: 7923 RVA: 0x00016D45 File Offset: 0x00014F45
	public static bool Boolean_33 { get; set; }

	// Token: 0x170006F5 RID: 1781
	// (get) Token: 0x06001EF4 RID: 7924 RVA: 0x00016D4D File Offset: 0x00014F4D
	public static bool Boolean_34 { get; } = 1;

	// Token: 0x170006F6 RID: 1782
	// (get) Token: 0x06001EF5 RID: 7925 RVA: 0x00016D54 File Offset: 0x00014F54
	public static bool Boolean_35 { get; } = 1;

	// Token: 0x170006F7 RID: 1783
	// (get) Token: 0x06001EF6 RID: 7926 RVA: 0x00016D5B File Offset: 0x00014F5B
	// (set) Token: 0x06001EF7 RID: 7927 RVA: 0x00016D62 File Offset: 0x00014F62
	public static bool Boolean_36 { get; set; }

	// Token: 0x170006F8 RID: 1784
	// (get) Token: 0x06001EF8 RID: 7928 RVA: 0x00016D6A File Offset: 0x00014F6A
	// (set) Token: 0x06001EF9 RID: 7929 RVA: 0x00016D71 File Offset: 0x00014F71
	public static bool Boolean_37 { get; set; } = true;

	// Token: 0x170006F9 RID: 1785
	// (get) Token: 0x06001EFA RID: 7930 RVA: 0x00016D79 File Offset: 0x00014F79
	// (set) Token: 0x06001EFB RID: 7931 RVA: 0x00016D80 File Offset: 0x00014F80
	public static bool Boolean_38 { get; set; }

	// Token: 0x170006FA RID: 1786
	// (get) Token: 0x06001EFC RID: 7932 RVA: 0x00016D88 File Offset: 0x00014F88
	public static bool Boolean_39 { get; } = 1;

	// Token: 0x170006FB RID: 1787
	// (get) Token: 0x06001EFD RID: 7933 RVA: 0x00016D8F File Offset: 0x00014F8F
	// (set) Token: 0x06001EFE RID: 7934 RVA: 0x00016D96 File Offset: 0x00014F96
	public static bool Boolean_40 { get; set; }

	// Token: 0x170006FC RID: 1788
	// (get) Token: 0x06001EFF RID: 7935 RVA: 0x00016D9E File Offset: 0x00014F9E
	public static bool Boolean_41 { get; } = 1;

	// Token: 0x170006FD RID: 1789
	// (get) Token: 0x06001F00 RID: 7936 RVA: 0x00016DA5 File Offset: 0x00014FA5
	// (set) Token: 0x06001F01 RID: 7937 RVA: 0x00016DAC File Offset: 0x00014FAC
	public static bool Boolean_42 { get; set; }

	// Token: 0x170006FE RID: 1790
	// (get) Token: 0x06001F02 RID: 7938 RVA: 0x00016DB4 File Offset: 0x00014FB4
	// (set) Token: 0x06001F03 RID: 7939 RVA: 0x00016DBB File Offset: 0x00014FBB
	public static bool Boolean_43 { get; set; }

	// Token: 0x170006FF RID: 1791
	// (get) Token: 0x06001F04 RID: 7940 RVA: 0x00016DC3 File Offset: 0x00014FC3
	// (set) Token: 0x06001F05 RID: 7941 RVA: 0x00016DCA File Offset: 0x00014FCA
	public static bool Boolean_44 { get; set; }

	// Token: 0x17000700 RID: 1792
	// (get) Token: 0x06001F06 RID: 7942 RVA: 0x00016DD2 File Offset: 0x00014FD2
	// (set) Token: 0x06001F07 RID: 7943 RVA: 0x00016DD9 File Offset: 0x00014FD9
	public static bool Boolean_45 { get; set; } = true;

	// Token: 0x17000701 RID: 1793
	// (get) Token: 0x06001F08 RID: 7944 RVA: 0x00016DE1 File Offset: 0x00014FE1
	// (set) Token: 0x06001F09 RID: 7945 RVA: 0x00016DE8 File Offset: 0x00014FE8
	public static bool Boolean_46 { get; set; }

	// Token: 0x17000702 RID: 1794
	// (get) Token: 0x06001F0A RID: 7946 RVA: 0x00016DF0 File Offset: 0x00014FF0
	// (set) Token: 0x06001F0B RID: 7947 RVA: 0x00016DF7 File Offset: 0x00014FF7
	public static Stopwatch Stopwatch_0 { get; set; } = new Stopwatch();

	// Token: 0x17000703 RID: 1795
	// (get) Token: 0x06001F0C RID: 7948 RVA: 0x00016DFF File Offset: 0x00014FFF
	public static bool Boolean_47 { get; } = 1;

	// Token: 0x17000704 RID: 1796
	// (get) Token: 0x06001F0D RID: 7949 RVA: 0x00016E06 File Offset: 0x00015006
	// (set) Token: 0x06001F0E RID: 7950 RVA: 0x00016E0D File Offset: 0x0001500D
	public static bool Boolean_48 { get; set; }

	// Token: 0x06001F0F RID: 7951 RVA: 0x000E3B84 File Offset: 0x000E1D84
	public static void smethod_0()
	{
		while (Class159.list_1.Count > 500)
		{
			Class159.list_1.RemoveAt(0);
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string value in Class159.list_1)
		{
			stringBuilder.AppendLine(value);
		}
		Class159.Class220_0.method_1("Logs", "CaptchaHash", stringBuilder.ToString());
	}

	// Token: 0x17000705 RID: 1797
	// (get) Token: 0x06001F10 RID: 7952 RVA: 0x00016E15 File Offset: 0x00015015
	// (set) Token: 0x06001F11 RID: 7953 RVA: 0x00016E1C File Offset: 0x0001501C
	public static bool Boolean_49 { get; set; }

	// Token: 0x17000706 RID: 1798
	// (get) Token: 0x06001F12 RID: 7954 RVA: 0x00016E24 File Offset: 0x00015024
	public static bool Boolean_50 { get; } = 1;

	// Token: 0x17000707 RID: 1799
	// (get) Token: 0x06001F13 RID: 7955 RVA: 0x00016E2B File Offset: 0x0001502B
	public static bool Boolean_51 { get; } = 1;

	// Token: 0x17000708 RID: 1800
	// (get) Token: 0x06001F14 RID: 7956 RVA: 0x00016E32 File Offset: 0x00015032
	// (set) Token: 0x06001F15 RID: 7957 RVA: 0x00016E39 File Offset: 0x00015039
	public static bool Boolean_52 { get; set; }

	// Token: 0x17000709 RID: 1801
	// (get) Token: 0x06001F16 RID: 7958 RVA: 0x00016E41 File Offset: 0x00015041
	public static bool Boolean_53 { get; } = 1;

	// Token: 0x1700070A RID: 1802
	// (get) Token: 0x06001F17 RID: 7959 RVA: 0x00016E48 File Offset: 0x00015048
	// (set) Token: 0x06001F18 RID: 7960 RVA: 0x00016E4F File Offset: 0x0001504F
	public static int Int32_9 { get; set; } = 20;

	// Token: 0x1700070B RID: 1803
	// (get) Token: 0x06001F19 RID: 7961 RVA: 0x00016E57 File Offset: 0x00015057
	// (set) Token: 0x06001F1A RID: 7962 RVA: 0x00016E5E File Offset: 0x0001505E
	public static int Int32_10 { get; set; } = 5;

	// Token: 0x1700070C RID: 1804
	// (get) Token: 0x06001F1B RID: 7963 RVA: 0x00016E66 File Offset: 0x00015066
	// (set) Token: 0x06001F1C RID: 7964 RVA: 0x00016E6D File Offset: 0x0001506D
	public static bool Boolean_54 { get; set; }

	// Token: 0x1700070D RID: 1805
	// (get) Token: 0x06001F1D RID: 7965 RVA: 0x00016E75 File Offset: 0x00015075
	// (set) Token: 0x06001F1E RID: 7966 RVA: 0x00016E7C File Offset: 0x0001507C
	public static bool Boolean_55 { get; set; }

	// Token: 0x1700070E RID: 1806
	// (get) Token: 0x06001F1F RID: 7967 RVA: 0x00016E84 File Offset: 0x00015084
	// (set) Token: 0x06001F20 RID: 7968 RVA: 0x00016E8B File Offset: 0x0001508B
	public static bool Boolean_56 { get; set; }

	// Token: 0x1700070F RID: 1807
	// (get) Token: 0x06001F21 RID: 7969 RVA: 0x00016E93 File Offset: 0x00015093
	// (set) Token: 0x06001F22 RID: 7970 RVA: 0x00016E9A File Offset: 0x0001509A
	public static bool Boolean_57 { get; set; }

	// Token: 0x17000710 RID: 1808
	// (get) Token: 0x06001F23 RID: 7971 RVA: 0x00016EA2 File Offset: 0x000150A2
	// (set) Token: 0x06001F24 RID: 7972 RVA: 0x00016EA9 File Offset: 0x000150A9
	public static bool Boolean_58 { get; set; }

	// Token: 0x17000711 RID: 1809
	// (get) Token: 0x06001F25 RID: 7973 RVA: 0x00016EB1 File Offset: 0x000150B1
	// (set) Token: 0x06001F26 RID: 7974 RVA: 0x00016EB8 File Offset: 0x000150B8
	public static bool Boolean_59 { get; set; }

	// Token: 0x17000712 RID: 1810
	// (get) Token: 0x06001F27 RID: 7975 RVA: 0x00016EC0 File Offset: 0x000150C0
	// (set) Token: 0x06001F28 RID: 7976 RVA: 0x00016EC7 File Offset: 0x000150C7
	public static bool Boolean_60 { get; set; }

	// Token: 0x17000713 RID: 1811
	// (get) Token: 0x06001F29 RID: 7977 RVA: 0x00016ECF File Offset: 0x000150CF
	// (set) Token: 0x06001F2A RID: 7978 RVA: 0x00016EE0 File Offset: 0x000150E0
	public static bool Boolean_61
	{
		get
		{
			return Class268.Int32_17 > 0 || Class268.bool_60;
		}
		set
		{
			Class268.bool_60 = value;
		}
	}

	// Token: 0x17000714 RID: 1812
	// (get) Token: 0x06001F2B RID: 7979 RVA: 0x00016EE8 File Offset: 0x000150E8
	// (set) Token: 0x06001F2C RID: 7980 RVA: 0x00016EEF File Offset: 0x000150EF
	public static bool Boolean_62 { get; set; }

	// Token: 0x17000715 RID: 1813
	// (get) Token: 0x06001F2D RID: 7981 RVA: 0x00016EF7 File Offset: 0x000150F7
	// (set) Token: 0x06001F2E RID: 7982 RVA: 0x00016EFE File Offset: 0x000150FE
	public static bool Boolean_63 { get; set; }

	// Token: 0x17000716 RID: 1814
	// (get) Token: 0x06001F2F RID: 7983 RVA: 0x00016F06 File Offset: 0x00015106
	// (set) Token: 0x06001F30 RID: 7984 RVA: 0x00016F0D File Offset: 0x0001510D
	public static bool Boolean_64 { get; set; }

	// Token: 0x17000717 RID: 1815
	// (get) Token: 0x06001F31 RID: 7985 RVA: 0x00016F15 File Offset: 0x00015115
	// (set) Token: 0x06001F32 RID: 7986 RVA: 0x00016F1C File Offset: 0x0001511C
	public static bool Boolean_65 { get; set; }

	// Token: 0x17000718 RID: 1816
	// (get) Token: 0x06001F33 RID: 7987 RVA: 0x00016F24 File Offset: 0x00015124
	// (set) Token: 0x06001F34 RID: 7988 RVA: 0x00016F2B File Offset: 0x0001512B
	public static bool Boolean_66 { get; set; } = true;

	// Token: 0x17000719 RID: 1817
	// (get) Token: 0x06001F35 RID: 7989 RVA: 0x00016F33 File Offset: 0x00015133
	// (set) Token: 0x06001F36 RID: 7990 RVA: 0x00016F3A File Offset: 0x0001513A
	public static int Int32_11 { get; set; }

	// Token: 0x1700071A RID: 1818
	// (get) Token: 0x06001F37 RID: 7991 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_67
	{
		get
		{
			return false;
		}
	}

	// Token: 0x1700071B RID: 1819
	// (get) Token: 0x06001F38 RID: 7992 RVA: 0x00016F42 File Offset: 0x00015142
	public static string String_2
	{
		get
		{
			return "3.3";
		}
	}

	// Token: 0x1700071C RID: 1820
	// (get) Token: 0x06001F39 RID: 7993 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_68
	{
		get
		{
			return false;
		}
	}

	// Token: 0x1700071D RID: 1821
	// (get) Token: 0x06001F3A RID: 7994 RVA: 0x000E3C18 File Offset: 0x000E1E18
	public static bool Boolean_69
	{
		get
		{
			return User.string_0 == "0975716490" || User.string_0 == "0936543800" || User.string_0 == "lecaotri@yahoo.com" || User.string_0 == "tieudattai@yahoo.com";
		}
	}

	// Token: 0x1700071E RID: 1822
	// (get) Token: 0x06001F3B RID: 7995 RVA: 0x00016F49 File Offset: 0x00015149
	// (set) Token: 0x06001F3C RID: 7996 RVA: 0x00016F50 File Offset: 0x00015150
	public static bool Boolean_70 { get; set; }

	// Token: 0x1700071F RID: 1823
	// (get) Token: 0x06001F3D RID: 7997 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_71
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000720 RID: 1824
	// (get) Token: 0x06001F3E RID: 7998 RVA: 0x00016F58 File Offset: 0x00015158
	// (set) Token: 0x06001F3F RID: 7999 RVA: 0x00016F5F File Offset: 0x0001515F
	public static int Int32_12 { get; set; } = 10;

	// Token: 0x17000721 RID: 1825
	// (get) Token: 0x06001F40 RID: 8000 RVA: 0x00016F67 File Offset: 0x00015167
	// (set) Token: 0x06001F41 RID: 8001 RVA: 0x00016F6E File Offset: 0x0001516E
	public static bool Boolean_72 { get; set; }

	// Token: 0x17000722 RID: 1826
	// (get) Token: 0x06001F42 RID: 8002 RVA: 0x00016F76 File Offset: 0x00015176
	// (set) Token: 0x06001F43 RID: 8003 RVA: 0x00016F7D File Offset: 0x0001517D
	public static bool Boolean_73 { get; set; }

	// Token: 0x17000723 RID: 1827
	// (get) Token: 0x06001F44 RID: 8004 RVA: 0x0000354C File Offset: 0x0000174C
	public static bool Boolean_74
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000724 RID: 1828
	// (get) Token: 0x06001F45 RID: 8005 RVA: 0x00016F85 File Offset: 0x00015185
	// (set) Token: 0x06001F46 RID: 8006 RVA: 0x00016F8C File Offset: 0x0001518C
	public static bool Boolean_75 { get; set; }

	// Token: 0x17000725 RID: 1829
	// (get) Token: 0x06001F47 RID: 8007 RVA: 0x00016F94 File Offset: 0x00015194
	// (set) Token: 0x06001F48 RID: 8008 RVA: 0x00016F9B File Offset: 0x0001519B
	public static int Int32_13 { get; set; }

	// Token: 0x17000726 RID: 1830
	// (get) Token: 0x06001F49 RID: 8009 RVA: 0x00016FA3 File Offset: 0x000151A3
	// (set) Token: 0x06001F4A RID: 8010 RVA: 0x00016FAA File Offset: 0x000151AA
	public static bool Boolean_76 { get; set; }

	// Token: 0x17000727 RID: 1831
	// (get) Token: 0x06001F4B RID: 8011 RVA: 0x00016FB2 File Offset: 0x000151B2
	// (set) Token: 0x06001F4C RID: 8012 RVA: 0x00016FB9 File Offset: 0x000151B9
	public static int Int32_14 { get; set; }

	// Token: 0x17000728 RID: 1832
	// (get) Token: 0x06001F4D RID: 8013 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_77
	{
		get
		{
			return false;
		}
	}

	// Token: 0x17000729 RID: 1833
	// (get) Token: 0x06001F4E RID: 8014 RVA: 0x00016FC1 File Offset: 0x000151C1
	// (set) Token: 0x06001F4F RID: 8015 RVA: 0x00016FC8 File Offset: 0x000151C8
	public static bool Boolean_78 { get; set; }

	// Token: 0x1700072A RID: 1834
	// (get) Token: 0x06001F50 RID: 8016 RVA: 0x00016FD0 File Offset: 0x000151D0
	// (set) Token: 0x06001F51 RID: 8017 RVA: 0x00016FD7 File Offset: 0x000151D7
	public static bool Boolean_79 { get; set; }

	// Token: 0x1700072B RID: 1835
	// (get) Token: 0x06001F52 RID: 8018 RVA: 0x00016FDF File Offset: 0x000151DF
	public static bool Boolean_80
	{
		get
		{
			return Class268.Boolean_79;
		}
	}

	// Token: 0x1700072C RID: 1836
	// (get) Token: 0x06001F53 RID: 8019 RVA: 0x0000354C File Offset: 0x0000174C
	public static bool Boolean_81
	{
		get
		{
			return true;
		}
	}

	// Token: 0x1700072D RID: 1837
	// (get) Token: 0x06001F54 RID: 8020 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_82
	{
		get
		{
			return false;
		}
	}

	// Token: 0x1700072E RID: 1838
	// (get) Token: 0x06001F55 RID: 8021 RVA: 0x00016FE6 File Offset: 0x000151E6
	// (set) Token: 0x06001F56 RID: 8022 RVA: 0x00016FED File Offset: 0x000151ED
	public static int Int32_15 { get; set; } = 0;

	// Token: 0x1700072F RID: 1839
	// (get) Token: 0x06001F57 RID: 8023 RVA: 0x00016FF5 File Offset: 0x000151F5
	// (set) Token: 0x06001F58 RID: 8024 RVA: 0x00016FFC File Offset: 0x000151FC
	public static int Int32_16 { get; set; }

	// Token: 0x17000730 RID: 1840
	// (get) Token: 0x06001F59 RID: 8025 RVA: 0x00017004 File Offset: 0x00015204
	// (set) Token: 0x06001F5A RID: 8026 RVA: 0x0001700B File Offset: 0x0001520B
	public static bool Boolean_83 { get; set; }

	// Token: 0x17000731 RID: 1841
	// (get) Token: 0x06001F5B RID: 8027 RVA: 0x0000354C File Offset: 0x0000174C
	public static int Int32_17
	{
		get
		{
			return 1;
		}
	}

	// Token: 0x17000732 RID: 1842
	// (get) Token: 0x06001F5C RID: 8028 RVA: 0x00017013 File Offset: 0x00015213
	// (set) Token: 0x06001F5D RID: 8029 RVA: 0x0001701A File Offset: 0x0001521A
	public static bool Boolean_84 { get; set; }

	// Token: 0x17000733 RID: 1843
	// (get) Token: 0x06001F5E RID: 8030 RVA: 0x00017022 File Offset: 0x00015222
	// (set) Token: 0x06001F5F RID: 8031 RVA: 0x00017029 File Offset: 0x00015229
	public static bool Boolean_85 { get; set; }

	// Token: 0x17000734 RID: 1844
	// (get) Token: 0x06001F60 RID: 8032 RVA: 0x00017031 File Offset: 0x00015231
	public static string String_3
	{
		get
		{
			return Class426.Class430.smethod_3(Application.ExecutablePath);
		}
	}

	// Token: 0x17000735 RID: 1845
	// (get) Token: 0x06001F61 RID: 8033 RVA: 0x0001703D File Offset: 0x0001523D
	public static string String_4
	{
		get
		{
			return Path.GetDirectoryName(Application.ExecutablePath);
		}
	}

	// Token: 0x17000736 RID: 1846
	// (get) Token: 0x06001F62 RID: 8034 RVA: 0x00017049 File Offset: 0x00015249
	public static string String_5
	{
		get
		{
			return "\"" + Application.ExecutablePath + "\"";
		}
	}

	// Token: 0x040012FE RID: 4862
	[CompilerGenerated]
	private static Class220 class220_0;

	// Token: 0x040012FF RID: 4863
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x04001300 RID: 4864
	[CompilerGenerated]
	private static bool bool_1;

	// Token: 0x04001301 RID: 4865
	[CompilerGenerated]
	private static bool bool_2;

	// Token: 0x04001302 RID: 4866
	public static List<string> list_0 = new List<string>();

	// Token: 0x04001303 RID: 4867
	public static List<string> list_1 = new List<string>();

	// Token: 0x04001304 RID: 4868
	[CompilerGenerated]
	private static bool bool_3;

	// Token: 0x04001305 RID: 4869
	[CompilerGenerated]
	private static bool bool_4;

	// Token: 0x04001306 RID: 4870
	[CompilerGenerated]
	private static bool bool_5;

	// Token: 0x04001307 RID: 4871
	[CompilerGenerated]
	private static bool bool_6;

	// Token: 0x04001308 RID: 4872
	[CompilerGenerated]
	private static bool bool_7;

	// Token: 0x04001309 RID: 4873
	[CompilerGenerated]
	private static bool bool_8;

	// Token: 0x0400130A RID: 4874
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x0400130B RID: 4875
	[CompilerGenerated]
	private static int int_1;

	// Token: 0x0400130C RID: 4876
	[CompilerGenerated]
	private static Dictionary<string, string> dictionary_0;

	// Token: 0x0400130D RID: 4877
	[CompilerGenerated]
	private static bool bool_9;

	// Token: 0x0400130E RID: 4878
	[CompilerGenerated]
	private static int int_2;

	// Token: 0x0400130F RID: 4879
	[CompilerGenerated]
	private static int int_3;

	// Token: 0x04001310 RID: 4880
	[CompilerGenerated]
	private static bool bool_10;

	// Token: 0x04001311 RID: 4881
	[CompilerGenerated]
	private static int int_4;

	// Token: 0x04001312 RID: 4882
	[CompilerGenerated]
	private static bool bool_11;

	// Token: 0x04001313 RID: 4883
	[CompilerGenerated]
	private static int int_5;

	// Token: 0x04001314 RID: 4884
	[CompilerGenerated]
	private static bool bool_12;

	// Token: 0x04001315 RID: 4885
	[CompilerGenerated]
	private static bool bool_13;

	// Token: 0x04001316 RID: 4886
	[CompilerGenerated]
	private static bool bool_14;

	// Token: 0x04001317 RID: 4887
	[CompilerGenerated]
	private static bool bool_15;

	// Token: 0x04001318 RID: 4888
	[CompilerGenerated]
	private static bool bool_16;

	// Token: 0x04001319 RID: 4889
	[CompilerGenerated]
	private static bool bool_17;

	// Token: 0x0400131A RID: 4890
	[CompilerGenerated]
	private static int int_6;

	// Token: 0x0400131B RID: 4891
	[CompilerGenerated]
	private static int int_7;

	// Token: 0x0400131C RID: 4892
	[CompilerGenerated]
	private static bool bool_18;

	// Token: 0x0400131D RID: 4893
	[CompilerGenerated]
	private static bool bool_19;

	// Token: 0x0400131E RID: 4894
	[CompilerGenerated]
	private static bool bool_20;

	// Token: 0x0400131F RID: 4895
	[CompilerGenerated]
	private static string string_0;

	// Token: 0x04001320 RID: 4896
	[CompilerGenerated]
	private static uint uint_0;

	// Token: 0x04001321 RID: 4897
	[CompilerGenerated]
	private static bool bool_21;

	// Token: 0x04001322 RID: 4898
	[CompilerGenerated]
	private static bool bool_22;

	// Token: 0x04001323 RID: 4899
	[CompilerGenerated]
	private static bool bool_23;

	// Token: 0x04001324 RID: 4900
	[CompilerGenerated]
	private static bool bool_24;

	// Token: 0x04001325 RID: 4901
	[CompilerGenerated]
	private static bool bool_25;

	// Token: 0x04001326 RID: 4902
	[CompilerGenerated]
	private static int int_8;

	// Token: 0x04001327 RID: 4903
	[CompilerGenerated]
	private static bool bool_26;

	// Token: 0x04001328 RID: 4904
	[CompilerGenerated]
	private static bool bool_27;

	// Token: 0x04001329 RID: 4905
	[CompilerGenerated]
	private static bool bool_28;

	// Token: 0x0400132A RID: 4906
	[CompilerGenerated]
	private static bool bool_29;

	// Token: 0x0400132B RID: 4907
	[CompilerGenerated]
	private static bool bool_30;

	// Token: 0x0400132C RID: 4908
	[CompilerGenerated]
	private static bool bool_31;

	// Token: 0x0400132D RID: 4909
	[CompilerGenerated]
	private static bool bool_32;

	// Token: 0x0400132E RID: 4910
	[CompilerGenerated]
	private static readonly bool bool_33;

	// Token: 0x0400132F RID: 4911
	[CompilerGenerated]
	private static readonly bool bool_34;

	// Token: 0x04001330 RID: 4912
	[CompilerGenerated]
	private static bool bool_35;

	// Token: 0x04001331 RID: 4913
	[CompilerGenerated]
	private static bool bool_36;

	// Token: 0x04001332 RID: 4914
	[CompilerGenerated]
	private static bool bool_37;

	// Token: 0x04001333 RID: 4915
	[CompilerGenerated]
	private static readonly bool bool_38;

	// Token: 0x04001334 RID: 4916
	[CompilerGenerated]
	private static bool bool_39;

	// Token: 0x04001335 RID: 4917
	[CompilerGenerated]
	private static readonly bool bool_40;

	// Token: 0x04001336 RID: 4918
	[CompilerGenerated]
	private static bool bool_41;

	// Token: 0x04001337 RID: 4919
	[CompilerGenerated]
	private static bool bool_42;

	// Token: 0x04001338 RID: 4920
	[CompilerGenerated]
	private static bool bool_43;

	// Token: 0x04001339 RID: 4921
	[CompilerGenerated]
	private static bool bool_44;

	// Token: 0x0400133A RID: 4922
	[CompilerGenerated]
	private static bool bool_45;

	// Token: 0x0400133B RID: 4923
	[CompilerGenerated]
	private static Stopwatch stopwatch_0;

	// Token: 0x0400133C RID: 4924
	[CompilerGenerated]
	private static readonly bool bool_46;

	// Token: 0x0400133D RID: 4925
	[CompilerGenerated]
	private static bool bool_47;

	// Token: 0x0400133E RID: 4926
	[CompilerGenerated]
	private static bool bool_48;

	// Token: 0x0400133F RID: 4927
	[CompilerGenerated]
	private static readonly bool bool_49;

	// Token: 0x04001340 RID: 4928
	[CompilerGenerated]
	private static readonly bool bool_50;

	// Token: 0x04001341 RID: 4929
	[CompilerGenerated]
	private static bool bool_51;

	// Token: 0x04001342 RID: 4930
	[CompilerGenerated]
	private static readonly bool bool_52;

	// Token: 0x04001343 RID: 4931
	[CompilerGenerated]
	private static int int_9;

	// Token: 0x04001344 RID: 4932
	[CompilerGenerated]
	private static int int_10;

	// Token: 0x04001345 RID: 4933
	[CompilerGenerated]
	private static bool bool_53;

	// Token: 0x04001346 RID: 4934
	[CompilerGenerated]
	private static bool bool_54;

	// Token: 0x04001347 RID: 4935
	[CompilerGenerated]
	private static bool bool_55;

	// Token: 0x04001348 RID: 4936
	[CompilerGenerated]
	private static bool bool_56;

	// Token: 0x04001349 RID: 4937
	[CompilerGenerated]
	private static bool bool_57;

	// Token: 0x0400134A RID: 4938
	[CompilerGenerated]
	private static bool bool_58;

	// Token: 0x0400134B RID: 4939
	[CompilerGenerated]
	private static bool bool_59;

	// Token: 0x0400134C RID: 4940
	private static bool bool_60;

	// Token: 0x0400134D RID: 4941
	[CompilerGenerated]
	private static bool bool_61;

	// Token: 0x0400134E RID: 4942
	[CompilerGenerated]
	private static bool bool_62;

	// Token: 0x0400134F RID: 4943
	[CompilerGenerated]
	private static bool bool_63;

	// Token: 0x04001350 RID: 4944
	[CompilerGenerated]
	private static bool bool_64;

	// Token: 0x04001351 RID: 4945
	[CompilerGenerated]
	private static bool bool_65;

	// Token: 0x04001352 RID: 4946
	public static bool bool_66 = false;

	// Token: 0x04001353 RID: 4947
	public static DateTime dateTime_0 = DateTime.MinValue;

	// Token: 0x04001354 RID: 4948
	[CompilerGenerated]
	private static int int_11;

	// Token: 0x04001355 RID: 4949
	[CompilerGenerated]
	private static bool bool_67;

	// Token: 0x04001356 RID: 4950
	[CompilerGenerated]
	private static int int_12;

	// Token: 0x04001357 RID: 4951
	[CompilerGenerated]
	private static bool bool_68;

	// Token: 0x04001358 RID: 4952
	[CompilerGenerated]
	private static bool bool_69;

	// Token: 0x04001359 RID: 4953
	public static bool bool_70 = true;

	// Token: 0x0400135A RID: 4954
	[CompilerGenerated]
	private static bool bool_71;

	// Token: 0x0400135B RID: 4955
	public static int int_13 = 199;

	// Token: 0x0400135C RID: 4956
	public static int int_14 = 2;

	// Token: 0x0400135D RID: 4957
	[CompilerGenerated]
	private static int int_15;

	// Token: 0x0400135E RID: 4958
	[CompilerGenerated]
	private static bool bool_72;

	// Token: 0x0400135F RID: 4959
	[CompilerGenerated]
	private static int int_16;

	// Token: 0x04001360 RID: 4960
	public static bool bool_73;

	// Token: 0x04001361 RID: 4961
	public static string string_1;

	// Token: 0x04001362 RID: 4962
	public static int int_17;

	// Token: 0x04001363 RID: 4963
	public static bool bool_74 = true;

	// Token: 0x04001364 RID: 4964
	public static bool bool_75 = true;

	// Token: 0x04001365 RID: 4965
	public static bool bool_76 = false;

	// Token: 0x04001366 RID: 4966
	public static int int_18 = 50;

	// Token: 0x04001367 RID: 4967
	public static int int_19 = 50;

	// Token: 0x04001368 RID: 4968
	public static int int_20 = 75;

	// Token: 0x04001369 RID: 4969
	public static int int_21 = 10;

	// Token: 0x0400136A RID: 4970
	public static int int_22 = 20;

	// Token: 0x0400136B RID: 4971
	public static int int_23 = 15;

	// Token: 0x0400136C RID: 4972
	public static bool bool_77 = false;

	// Token: 0x0400136D RID: 4973
	public static bool bool_78 = true;

	// Token: 0x0400136E RID: 4974
	public static bool bool_79 = false;

	// Token: 0x0400136F RID: 4975
	public static bool bool_80 = true;

	// Token: 0x04001370 RID: 4976
	public static bool bool_81 = false;

	// Token: 0x04001371 RID: 4977
	public static bool bool_82 = false;

	// Token: 0x04001372 RID: 4978
	public static bool bool_83 = false;

	// Token: 0x04001373 RID: 4979
	public static int int_24 = 42;

	// Token: 0x04001374 RID: 4980
	public static bool bool_84 = false;

	// Token: 0x04001375 RID: 4981
	public static bool bool_85 = true;

	// Token: 0x04001376 RID: 4982
	public static bool bool_86 = false;

	// Token: 0x04001377 RID: 4983
	public static bool bool_87 = false;

	// Token: 0x04001378 RID: 4984
	public static bool bool_88 = true;

	// Token: 0x04001379 RID: 4985
	[CompilerGenerated]
	private static bool bool_89;

	// Token: 0x0400137A RID: 4986
	public static bool bool_90 = true;

	// Token: 0x0400137B RID: 4987
	public static bool bool_91 = false;

	// Token: 0x0400137C RID: 4988
	public static bool bool_92 = true;

	// Token: 0x0400137D RID: 4989
	public static Keys keys_0 = Keys.F1;

	// Token: 0x0400137E RID: 4990
	public static Keys keys_1 = Keys.F13;

	// Token: 0x0400137F RID: 4991
	public static Keys keys_2 = Keys.F13;

	// Token: 0x04001380 RID: 4992
	public static bool bool_93 = false;

	// Token: 0x04001381 RID: 4993
	public static bool bool_94 = false;

	// Token: 0x04001382 RID: 4994
	public static bool bool_95 = false;

	// Token: 0x04001383 RID: 4995
	public static int int_25 = 3;

	// Token: 0x04001384 RID: 4996
	public static int int_26 = 20;

	// Token: 0x04001385 RID: 4997
	[CompilerGenerated]
	private static bool bool_96;

	// Token: 0x04001386 RID: 4998
	public static bool bool_97 = true;

	// Token: 0x04001387 RID: 4999
	public static int int_27 = 30;

	// Token: 0x04001388 RID: 5000
	public static bool bool_98 = false;

	// Token: 0x04001389 RID: 5001
	public static int int_28 = 134;

	// Token: 0x0400138A RID: 5002
	public static bool bool_99 = false;

	// Token: 0x0400138B RID: 5003
	public static int int_29 = 1;

	// Token: 0x0400138C RID: 5004
	public static bool bool_100 = false;

	// Token: 0x0400138D RID: 5005
	public static int int_30 = 165;

	// Token: 0x0400138E RID: 5006
	public static int int_31 = Class365.Int32_35;

	// Token: 0x0400138F RID: 5007
	public static List<string> list_2 = new List<string>();

	// Token: 0x04001390 RID: 5008
	public static List<string> list_3 = new List<string>();

	// Token: 0x04001391 RID: 5009
	[CompilerGenerated]
	private static int int_32;

	// Token: 0x04001392 RID: 5010
	[CompilerGenerated]
	private static int int_33;

	// Token: 0x04001393 RID: 5011
	[CompilerGenerated]
	private static bool bool_101;

	// Token: 0x04001394 RID: 5012
	[CompilerGenerated]
	private static bool bool_102;

	// Token: 0x04001395 RID: 5013
	[CompilerGenerated]
	private static bool bool_103;
}
