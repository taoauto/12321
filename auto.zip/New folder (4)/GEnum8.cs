﻿using System;

// Token: 0x02000068 RID: 104
public enum GEnum8 : ushort
{
	// Token: 0x04000262 RID: 610
	Connecting,
	// Token: 0x04000263 RID: 611
	Open,
	// Token: 0x04000264 RID: 612
	Closing,
	// Token: 0x04000265 RID: 613
	Closed
}
