﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

// Token: 0x02000094 RID: 148
[Serializable]
public class GException5 : Win32Exception
{
	// Token: 0x060006E8 RID: 1768 RVA: 0x0000776C File Offset: 0x0000596C
	protected GException5(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0) : base(serializationInfo_0, streamingContext_0)
	{
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x00007776 File Offset: 0x00005976
	public GException5()
	{
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x0000777E File Offset: 0x0000597E
	public GException5(int int_0) : base(int_0)
	{
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x00007787 File Offset: 0x00005987
	public GException5(int int_0, string string_0) : base(int_0, string_0)
	{
	}

	// Token: 0x170001D5 RID: 469
	// (get) Token: 0x060006EC RID: 1772 RVA: 0x00007791 File Offset: 0x00005991
	public virtual int ErrorCode
	{
		get
		{
			return base.NativeErrorCode;
		}
	}
}
