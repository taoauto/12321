﻿using System;
using System.Collections.Generic;
using System.IO;

// Token: 0x02000188 RID: 392
[Serializable]
public class GClass116 : GClass115
{
	// Token: 0x0600121D RID: 4637 RVA: 0x0000E537 File Offset: 0x0000C737
	public GClass116(string string_0) : this(File.ReadAllBytes(string_0))
	{
		this.String_0 = string_0;
	}

	// Token: 0x0600121E RID: 4638 RVA: 0x00068ADC File Offset: 0x00066CDC
	public GClass116(byte[] byte_0) : base(byte_0)
	{
		string text = string.Empty;
		GStruct10 gstruct = default(GStruct10);
		GStruct7 gstruct2 = default(GStruct7);
		if (base.method_1<GStruct7>(out gstruct2) && gstruct2.e_magic == 23117)
		{
			if (base.method_3<GStruct10>((long)((ulong)gstruct2.e_lfanew), SeekOrigin.Begin, out gstruct) && (long)gstruct.Signature == 17744L)
			{
				if (gstruct.OptionalHeader.Magic == 267)
				{
					if (gstruct.OptionalHeader.DataDirectory[14].Size > 0U)
					{
						text = "Image contains a CLR runtime header. Currently only native binaries are supported; no .NET dependent libraries.";
					}
				}
				else
				{
					text = "File is of the PE32+ format. Currently support only extends to PE32 images. Either recompile the binary as x86, or choose a different target.";
				}
			}
			else
			{
				text = "Invalid NT header found in image.";
			}
		}
		else
		{
			text = "Invalid DOS Header found in image";
		}
		if (!string.IsNullOrEmpty(text))
		{
			base.Dispose();
			throw new ArgumentException(text);
		}
		this.GStruct10_0 = gstruct;
		this.GStruct7_0 = gstruct2;
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x0000E54C File Offset: 0x0000C74C
	public IEnumerable<GStruct9> method_8()
	{
		GStruct6 gstruct = this.GStruct10_0.OptionalHeader.DataDirectory[1];
		if (gstruct.Size > 0U)
		{
			uint num = this.method_11(gstruct.VirtualAddress);
			uint num2 = typeof(GStruct9).smethod_1();
			GStruct9 gstruct2;
			while (base.method_3<GStruct9>((long)((ulong)num), SeekOrigin.Begin, out gstruct2) && gstruct2.OriginalFirstThunk > 0U && gstruct2.Name > 0U)
			{
				yield return gstruct2;
				num += num2;
			}
		}
		yield break;
	}

	// Token: 0x06001220 RID: 4640 RVA: 0x0000E55C File Offset: 0x0000C75C
	public IEnumerable<GStruct15> method_9()
	{
		GClass116.Class154 @class = new GClass116.Class154(-2);
		@class.gclass116_0 = this;
		return @class;
	}

	// Token: 0x06001221 RID: 4641 RVA: 0x00068BAC File Offset: 0x00066DAC
	private GStruct15 method_10(uint uint_0)
	{
		foreach (GStruct15 gstruct in this.method_9())
		{
			if (uint_0 >= gstruct.VirtualAddress && uint_0 < gstruct.VirtualAddress + ((gstruct.VirtualSize > 0U) ? gstruct.VirtualSize : gstruct.SizeOfRawData))
			{
				return gstruct;
			}
		}
		throw new EntryPointNotFoundException("RVA does not exist within any of the current sections.");
	}

	// Token: 0x06001222 RID: 4642 RVA: 0x00068C30 File Offset: 0x00066E30
	public uint method_11(uint uint_0)
	{
		GStruct15 gstruct = this.method_10(uint_0);
		return uint_0 - (gstruct.VirtualAddress - gstruct.PointerToRawData);
	}

	// Token: 0x06001223 RID: 4643 RVA: 0x0000E56C File Offset: 0x0000C76C
	public byte[] method_12()
	{
		return base.method_0();
	}

	// Token: 0x170004A7 RID: 1191
	// (get) Token: 0x06001224 RID: 4644 RVA: 0x0000E574 File Offset: 0x0000C774
	// (set) Token: 0x06001225 RID: 4645 RVA: 0x0000E57C File Offset: 0x0000C77C
	public GStruct7 GStruct7_0 { get; private set; }

	// Token: 0x170004A8 RID: 1192
	// (get) Token: 0x06001226 RID: 4646 RVA: 0x0000E585 File Offset: 0x0000C785
	// (set) Token: 0x06001227 RID: 4647 RVA: 0x0000E58D File Offset: 0x0000C78D
	public string String_0 { get; private set; }

	// Token: 0x170004A9 RID: 1193
	// (get) Token: 0x06001228 RID: 4648 RVA: 0x0000E596 File Offset: 0x0000C796
	// (set) Token: 0x06001229 RID: 4649 RVA: 0x0000E59E File Offset: 0x0000C79E
	public GStruct10 GStruct10_0 { get; private set; }
}
