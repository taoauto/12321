﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

// Token: 0x02000163 RID: 355
internal class Class145
{
	// Token: 0x1700045D RID: 1117
	// (get) Token: 0x060010DA RID: 4314 RVA: 0x0000DAA6 File Offset: 0x0000BCA6
	// (set) Token: 0x060010DB RID: 4315 RVA: 0x0000DAAE File Offset: 0x0000BCAE
	public bool Boolean_0 { get; set; }

	// Token: 0x1700045E RID: 1118
	// (get) Token: 0x060010DC RID: 4316 RVA: 0x0000DAB7 File Offset: 0x0000BCB7
	// (set) Token: 0x060010DD RID: 4317 RVA: 0x0000DABF File Offset: 0x0000BCBF
	public string String_0 { get; set; }

	// Token: 0x1700045F RID: 1119
	// (get) Token: 0x060010DE RID: 4318 RVA: 0x0000DAC8 File Offset: 0x0000BCC8
	// (set) Token: 0x060010DF RID: 4319 RVA: 0x0000DAD0 File Offset: 0x0000BCD0
	public bool Boolean_1 { get; set; }

	// Token: 0x17000460 RID: 1120
	// (get) Token: 0x060010E0 RID: 4320 RVA: 0x0000DAD9 File Offset: 0x0000BCD9
	// (set) Token: 0x060010E1 RID: 4321 RVA: 0x0000DAE1 File Offset: 0x0000BCE1
	public bool Boolean_2 { get; set; }

	// Token: 0x060010E2 RID: 4322 RVA: 0x0005C080 File Offset: 0x0005A280
	public void method_0()
	{
		this.String_0 = null;
		this.Boolean_11 = false;
		this.Boolean_10 = false;
		this.Boolean_12 = false;
		this.Boolean_13 = false;
		this.Boolean_14 = false;
		this.Boolean_18 = false;
		this.Boolean_19 = false;
		this.Boolean_20 = false;
		this.Boolean_15 = false;
		this.Boolean_16 = false;
		this.Boolean_17 = false;
		this.Boolean_25 = false;
		this.Boolean_26 = false;
		this.bool_4 = false;
		this.bool_5 = false;
		this.Boolean_4 = false;
		this.Boolean_33 = false;
		this.Boolean_5 = false;
		this.Boolean_6 = false;
		this.bool_9 = false;
		this.bool_10 = false;
		this.Boolean_22 = false;
		this.Boolean_23 = false;
		this.Boolean_24 = false;
		this.Boolean_28 = false;
		this.Boolean_27 = false;
		this.Boolean_3 = false;
		this.Boolean_9 = false;
		this.Boolean_21 = false;
		this.bool_12 = false;
		this.Boolean_29 = false;
		this.Boolean_31 = false;
		this.Boolean_32 = false;
		this.bool_13 = false;
		this.Boolean_1 = false;
		this.Boolean_30 = false;
	}

	// Token: 0x17000461 RID: 1121
	// (get) Token: 0x060010E3 RID: 4323 RVA: 0x0000DAEA File Offset: 0x0000BCEA
	// (set) Token: 0x060010E4 RID: 4324 RVA: 0x0000DAF2 File Offset: 0x0000BCF2
	public string String_1 { get; set; }

	// Token: 0x17000462 RID: 1122
	// (get) Token: 0x060010E5 RID: 4325 RVA: 0x0000DAFB File Offset: 0x0000BCFB
	// (set) Token: 0x060010E6 RID: 4326 RVA: 0x0000DB03 File Offset: 0x0000BD03
	public bool Boolean_3 { get; set; }

	// Token: 0x060010E7 RID: 4327 RVA: 0x0005C190 File Offset: 0x0005A390
	public Class145(string string_5, string string_6, string string_7, string string_8, string string_9, string string_10, string string_11, XmlDocument xmlDocument_1, string string_12 = null)
	{
		this.xmlDocument_0 = xmlDocument_1;
		this.String_1 = string_12;
		XmlElement newChild = xmlDocument_1.CreateElement("Account");
		if (this.String_1 == null)
		{
			newChild = xmlDocument_1.CreateElement("Account" + Main.String_3.Replace("#", ""));
		}
		xmlDocument_1.SelectSingleNode("/*").AppendChild(newChild);
		this.xmlNode_0 = newChild;
		this.String_2 = string_5;
		this.String_4 = string_6;
		this.String_7 = string_9;
		this.String_8 = string_10;
		this.String_9 = string_11;
		this.String_5 = string_7;
		this.String_6 = string_8;
	}

	// Token: 0x060010E8 RID: 4328 RVA: 0x0005C26C File Offset: 0x0005A46C
	public Class145(XmlElement xmlElement_0, XmlDocument xmlDocument_1, string string_5 = null)
	{
		this.xmlDocument_0 = xmlDocument_1;
		this.String_1 = string_5;
		this.xmlNode_0 = xmlElement_0;
	}

	// Token: 0x060010E9 RID: 4329 RVA: 0x0005C2C4 File Offset: 0x0005A4C4
	public Class145(XmlDocument xmlDocument_1, string string_5 = null)
	{
		this.xmlDocument_0 = xmlDocument_1;
		this.String_1 = string_5;
	}

	// Token: 0x17000463 RID: 1123
	// (get) Token: 0x060010EA RID: 4330 RVA: 0x0005C314 File Offset: 0x0005A514
	// (set) Token: 0x060010EB RID: 4331 RVA: 0x0005C368 File Offset: 0x0005A568
	public string String_2
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["User"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("User");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["User"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("User");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[1].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000464 RID: 1124
	// (get) Token: 0x060010EC RID: 4332 RVA: 0x0005C3E4 File Offset: 0x0005A5E4
	public string String_3
	{
		get
		{
			string result;
			try
			{
				if (this.string_2 == null)
				{
					this.string_2 = string.Join("", new string[]
					{
						this.String_2,
						this.String_8,
						this.String_6,
						this.String_15,
						this.String_20,
						this.String_14,
						this.String_16,
						this.String_17,
						this.String_18,
						this.String_12
					}).smethod_0();
				}
				result = this.string_2;
			}
			catch
			{
				result = "";
			}
			return result;
		}
	}

	// Token: 0x17000465 RID: 1125
	// (get) Token: 0x060010ED RID: 4333 RVA: 0x0005C494 File Offset: 0x0005A694
	// (set) Token: 0x060010EE RID: 4334 RVA: 0x0005C568 File Offset: 0x0005A768
	public string String_4
	{
		get
		{
			string result;
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Pass"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("Pass");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				if (this.xmlNode_0.SelectSingleNode("Pass") != null)
				{
					xmlAttribute.Value = this.xmlNode_0.SelectSingleNode("Pass").InnerText;
					this.xmlNode_0.RemoveChild(this.xmlNode_0.SelectSingleNode("Pass"));
				}
				if (this.String_1 == null)
				{
					result = xmlAttribute.Value;
				}
				else
				{
					result = Class426.Class430.smethod_5(xmlAttribute.Value, this.String_1);
				}
			}
			catch
			{
				result = "";
			}
			return result;
		}
		set
		{
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Pass"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("Pass");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				if (this.String_1 != null)
				{
					xmlAttribute.Value = Class426.Class430.smethod_4(value, this.String_1);
				}
				else
				{
					xmlAttribute.Value = value;
				}
			}
			catch
			{
			}
		}
	}

	// Token: 0x17000466 RID: 1126
	// (get) Token: 0x060010EF RID: 4335 RVA: 0x0005C5EC File Offset: 0x0005A7EC
	// (set) Token: 0x060010F0 RID: 4336 RVA: 0x0005C6A4 File Offset: 0x0005A8A4
	public string String_5
	{
		get
		{
			string result;
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["NPH"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("NPH");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				if (this.xmlNode_0.SelectSingleNode("NPH") != null)
				{
					xmlAttribute.Value = this.xmlNode_0.SelectSingleNode("NPH").InnerText;
					this.xmlNode_0.RemoveChild(this.xmlNode_0.SelectSingleNode("NPH"));
				}
				result = xmlAttribute.Value;
			}
			catch
			{
				result = "";
			}
			return result;
		}
		set
		{
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["NPH"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("NPH");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				xmlAttribute.Value = value;
			}
			catch
			{
			}
		}
	}

	// Token: 0x17000467 RID: 1127
	// (get) Token: 0x060010F1 RID: 4337 RVA: 0x0005C70C File Offset: 0x0005A90C
	// (set) Token: 0x060010F2 RID: 4338 RVA: 0x0005C88C File Offset: 0x0005AA8C
	public string String_6
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Server"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Server");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			if (this.xmlNode_0.SelectSingleNode("Server") != null)
			{
				xmlAttribute.Value = this.xmlNode_0.SelectSingleNode("Server").InnerText;
				this.xmlNode_0.RemoveChild(this.xmlNode_0.SelectSingleNode("Server"));
			}
			if (xmlAttribute.Value.Contains("Giao Long 08") || xmlAttribute.Value.Contains("Tuyết Nguyên"))
			{
				xmlAttribute.Value = "Bạch Hổ";
			}
			if (xmlAttribute.Value.Contains("Thiên Long 02") || xmlAttribute.Value.Contains("Thiên Long 03"))
			{
				xmlAttribute.Value = "Chu Tước";
			}
			if (xmlAttribute.Value.Contains("Thiên Long 07") || xmlAttribute.Value.Contains("Thiên Long 09") || xmlAttribute.Value.Contains("Thiên Long 10"))
			{
				xmlAttribute.Value = "Huyền Vũ";
			}
			if (xmlAttribute.Value.Contains("Hỏa Diệm") || xmlAttribute.Value.Contains("Long Vũ Môn") || xmlAttribute.Value.Contains("Hàn Băng Miên Chưởng"))
			{
				xmlAttribute.Value = "Thanh Long";
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Server"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Server");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[3].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000468 RID: 1128
	// (get) Token: 0x060010F3 RID: 4339 RVA: 0x0005C908 File Offset: 0x0005AB08
	// (set) Token: 0x060010F4 RID: 4340 RVA: 0x0005C9C0 File Offset: 0x0005ABC0
	public string String_7
	{
		get
		{
			string result;
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Tail"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("Tail");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				if (this.xmlNode_0.SelectSingleNode("Tail") != null)
				{
					xmlAttribute.Value = this.xmlNode_0.SelectSingleNode("Tail").InnerText;
					this.xmlNode_0.RemoveChild(this.xmlNode_0.SelectSingleNode("Tail"));
				}
				result = xmlAttribute.Value;
			}
			catch
			{
				result = "";
			}
			return result;
		}
		set
		{
			try
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Tail"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlDocument_0.CreateAttribute("Tail");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
				}
				xmlAttribute.Value = value;
			}
			catch
			{
			}
		}
	}

	// Token: 0x17000469 RID: 1129
	// (get) Token: 0x060010F5 RID: 4341 RVA: 0x0005CA28 File Offset: 0x0005AC28
	// (set) Token: 0x060010F6 RID: 4342 RVA: 0x0005CA90 File Offset: 0x0005AC90
	public string String_8
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Name"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Name");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			if (string.IsNullOrEmpty(xmlAttribute.Value))
			{
				return ",,,";
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Name"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Name");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[2].Text = value;
				this.string_2 = null;
			}
			if (this.ListViewItem_0 != null)
			{
				this.ListViewItem_0.SubItems[1].Text = value;
			}
		}
	}

	// Token: 0x1700046A RID: 1130
	// (get) Token: 0x060010F7 RID: 4343 RVA: 0x0005CB2C File Offset: 0x0005AD2C
	// (set) Token: 0x060010F8 RID: 4344 RVA: 0x0005CB80 File Offset: 0x0005AD80
	public string String_9
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Ids"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Ids");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Ids"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Ids");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
		}
	}

	// Token: 0x1700046B RID: 1131
	// (get) Token: 0x060010F9 RID: 4345 RVA: 0x0005CBD8 File Offset: 0x0005ADD8
	// (set) Token: 0x060010FA RID: 4346 RVA: 0x0005CC2C File Offset: 0x0005AE2C
	public string String_10
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Team"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Team");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Team"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Team");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[10].Text = this.String_12;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x1700046C RID: 1132
	// (get) Token: 0x060010FB RID: 4347 RVA: 0x0005CCB0 File Offset: 0x0005AEB0
	// (set) Token: 0x060010FC RID: 4348 RVA: 0x0005CD04 File Offset: 0x0005AF04
	public string String_11
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Tag"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Tag");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Tag"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Tag");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[10].Text = this.String_12;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x1700046D RID: 1133
	// (get) Token: 0x060010FD RID: 4349 RVA: 0x0005CD88 File Offset: 0x0005AF88
	public string String_12
	{
		get
		{
			if (this.int_3 != 1)
			{
				return string.Concat(new string[]
				{
					"H",
					this.int_3.ToString(),
					"[",
					this.String_10,
					"],[",
					Class432.smethod_3(this.String_13),
					"],",
					this.String_11
				}).Trim(new char[]
				{
					','
				});
			}
			return string.Concat(new string[]
			{
				"[",
				this.String_10,
				"],[",
				Class432.smethod_3(this.String_13),
				"],",
				this.String_11
			}).Trim(new char[]
			{
				','
			});
		}
	}

	// Token: 0x1700046E RID: 1134
	// (get) Token: 0x060010FE RID: 4350 RVA: 0x0005CE5C File Offset: 0x0005B05C
	// (set) Token: 0x060010FF RID: 4351 RVA: 0x0005CEB0 File Offset: 0x0005B0B0
	public string String_13
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Menpai"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Menpai");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Menpai"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Menpai");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[10].Text = this.String_12;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x1700046F RID: 1135
	// (get) Token: 0x06001100 RID: 4352 RVA: 0x0005CF34 File Offset: 0x0005B134
	// (set) Token: 0x06001101 RID: 4353 RVA: 0x0005CF88 File Offset: 0x0005B188
	public string String_14
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Lvl"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Lvl");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Lvl"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Lvl");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[6].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000470 RID: 1136
	// (get) Token: 0x06001102 RID: 4354 RVA: 0x0000DB0C File Offset: 0x0000BD0C
	// (set) Token: 0x06001103 RID: 4355 RVA: 0x0000DB14 File Offset: 0x0000BD14
	public Stopwatch Stopwatch_0 { get; set; }

	// Token: 0x17000471 RID: 1137
	// (get) Token: 0x06001104 RID: 4356 RVA: 0x0000DB1D File Offset: 0x0000BD1D
	// (set) Token: 0x06001105 RID: 4357 RVA: 0x0000DB25 File Offset: 0x0000BD25
	public bool Boolean_4 { get; set; }

	// Token: 0x17000472 RID: 1138
	// (get) Token: 0x06001106 RID: 4358 RVA: 0x0005D004 File Offset: 0x0005B204
	public int Int32_0
	{
		get
		{
			try
			{
				for (int i = 0; i < Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.String_5 + "\"]").SelectSingleNode("Servers").SelectNodes("Server").Count; i++)
				{
					if (Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.String_5 + "\"]").SelectSingleNode("Servers").SelectNodes("Server")[i].InnerText == this.String_6)
					{
						return i;
					}
				}
			}
			catch
			{
			}
			return -1;
		}
	}

	// Token: 0x17000473 RID: 1139
	// (get) Token: 0x06001107 RID: 4359 RVA: 0x0005D0C0 File Offset: 0x0005B2C0
	public int Int32_1
	{
		get
		{
			try
			{
				for (int i = 0; i < Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.String_5 + "\"]").SelectSingleNode("Tails").SelectNodes("Tail").Count; i++)
				{
					if (Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.String_5 + "\"]").SelectSingleNode("Tails").SelectNodes("Tail")[i].InnerText == this.String_6)
					{
						return i;
					}
				}
			}
			catch
			{
			}
			return -1;
		}
	}

	// Token: 0x17000474 RID: 1140
	// (get) Token: 0x06001108 RID: 4360 RVA: 0x0000DB2E File Offset: 0x0000BD2E
	// (set) Token: 0x06001109 RID: 4361 RVA: 0x0000DB36 File Offset: 0x0000BD36
	public bool Boolean_5 { get; set; }

	// Token: 0x17000475 RID: 1141
	// (get) Token: 0x0600110A RID: 4362 RVA: 0x0005D17C File Offset: 0x0005B37C
	// (set) Token: 0x0600110B RID: 4363 RVA: 0x0005D1D0 File Offset: 0x0005B3D0
	public string String_15
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["LoginIndex"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("LoginIndex");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["LoginIndex"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("LoginIndex");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[4].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000476 RID: 1142
	// (get) Token: 0x0600110C RID: 4364 RVA: 0x0000DB3F File Offset: 0x0000BD3F
	// (set) Token: 0x0600110D RID: 4365 RVA: 0x0000DB47 File Offset: 0x0000BD47
	public bool Boolean_6 { get; set; }

	// Token: 0x17000477 RID: 1143
	// (get) Token: 0x0600110E RID: 4366 RVA: 0x0005D24C File Offset: 0x0005B44C
	// (set) Token: 0x0600110F RID: 4367 RVA: 0x0005D2B4 File Offset: 0x0005B4B4
	public string String_16
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["TienHoa"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("TienHoa");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			if (string.IsNullOrEmpty(xmlAttribute.Value))
			{
				return "0";
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["TienHoa"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("TienHoa");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[7].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000478 RID: 1144
	// (get) Token: 0x06001110 RID: 4368 RVA: 0x0005D330 File Offset: 0x0005B530
	// (set) Token: 0x06001111 RID: 4369 RVA: 0x0005D398 File Offset: 0x0005B598
	public string String_17
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Shit"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Shit");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			if (string.IsNullOrEmpty(xmlAttribute.Value))
			{
				return "0";
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Shit"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Shit");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[8].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x17000479 RID: 1145
	// (get) Token: 0x06001112 RID: 4370 RVA: 0x0005D414 File Offset: 0x0005B614
	// (set) Token: 0x06001113 RID: 4371 RVA: 0x0005D47C File Offset: 0x0005B67C
	public string String_18
	{
		get
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["But"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("But");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			if (string.IsNullOrEmpty(xmlAttribute.Value))
			{
				return "0";
			}
			return xmlAttribute.Value;
		}
		set
		{
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["But"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("But");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[9].Text = value;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x1700047A RID: 1146
	// (get) Token: 0x06001114 RID: 4372 RVA: 0x0005D4F8 File Offset: 0x0005B6F8
	public string String_19
	{
		get
		{
			try
			{
				return Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.String_5 + "\"]").Attributes["Path"].Value;
			}
			catch
			{
			}
			return "";
		}
	}

	// Token: 0x1700047B RID: 1147
	// (get) Token: 0x06001115 RID: 4373 RVA: 0x0000DB50 File Offset: 0x0000BD50
	public bool Boolean_7
	{
		get
		{
			return this.class159_0 != null && this.class159_0.Class432_0.Boolean_24 && this.class159_0.Class432_0.Boolean_20;
		}
	}

	// Token: 0x1700047C RID: 1148
	// (get) Token: 0x06001116 RID: 4374 RVA: 0x0005D558 File Offset: 0x0005B758
	// (set) Token: 0x06001117 RID: 4375 RVA: 0x0005D624 File Offset: 0x0005B824
	public string String_20
	{
		get
		{
			if (this.string_3 == null)
			{
				XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Status"];
				if (xmlAttribute == null)
				{
					xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Status");
					this.xmlNode_0.Attributes.Append(xmlAttribute);
					xmlAttribute.Value = "...";
				}
				else if (!xmlAttribute.Value.Contains("xong BHD") && !xmlAttribute.Value.Contains("Exit") && !xmlAttribute.Value.Contains("Captcha"))
				{
					xmlAttribute.Value = "";
				}
				this.string_3 = xmlAttribute.Value;
			}
			if (string.IsNullOrEmpty(this.string_3))
			{
				return "...";
			}
			return this.string_3;
		}
		set
		{
			this.string_3 = value;
			if (this.string_4 != value)
			{
				this.string_4 = value;
				if (value.Contains("xong"))
				{
					MicroLogin.int_5++;
					if (MicroLogin.stopwatch_3 == null)
					{
						MicroLogin.stopwatch_3 = Stopwatch.StartNew();
					}
				}
			}
			XmlAttribute xmlAttribute = this.xmlNode_0.Attributes["Status"];
			if (xmlAttribute == null)
			{
				xmlAttribute = this.xmlNode_0.OwnerDocument.CreateAttribute("Status");
				this.xmlNode_0.Attributes.Append(xmlAttribute);
			}
			xmlAttribute.Value = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[5].Text = value;
				this.string_2 = null;
			}
			if (this.ListViewItem_0 != null)
			{
				this.ListViewItem_0.SubItems[2].Text = value;
			}
		}
	}

	// Token: 0x1700047D RID: 1149
	// (get) Token: 0x06001118 RID: 4376 RVA: 0x0000DB85 File Offset: 0x0000BD85
	// (set) Token: 0x06001119 RID: 4377 RVA: 0x0000DB8D File Offset: 0x0000BD8D
	public ListViewItem ListViewItem_0 { get; set; }

	// Token: 0x1700047E RID: 1150
	// (get) Token: 0x0600111A RID: 4378 RVA: 0x0000DB96 File Offset: 0x0000BD96
	// (set) Token: 0x0600111B RID: 4379 RVA: 0x0000DB9E File Offset: 0x0000BD9E
	public Stopwatch Stopwatch_1 { get; set; }

	// Token: 0x1700047F RID: 1151
	// (get) Token: 0x0600111C RID: 4380 RVA: 0x0005D704 File Offset: 0x0005B904
	public bool Boolean_8
	{
		get
		{
			return this.class159_0 != null && (!this.class159_0.Class432_0.Boolean_18 && !this.class159_0.Class432_0.Boolean_17 && !this.class159_0.Class432_0.Boolean_22 && !this.class159_0.Class432_0.Boolean_24) && this.class159_0.Class432_0.Boolean_34;
		}
	}

	// Token: 0x17000480 RID: 1152
	// (get) Token: 0x0600111D RID: 4381 RVA: 0x0000DBA7 File Offset: 0x0000BDA7
	// (set) Token: 0x0600111E RID: 4382 RVA: 0x0000DBAF File Offset: 0x0000BDAF
	public bool Boolean_9 { get; set; }

	// Token: 0x17000481 RID: 1153
	// (get) Token: 0x0600111F RID: 4383 RVA: 0x0000DBB8 File Offset: 0x0000BDB8
	// (set) Token: 0x06001120 RID: 4384 RVA: 0x0000DBC0 File Offset: 0x0000BDC0
	public bool Boolean_10 { get; set; }

	// Token: 0x17000482 RID: 1154
	// (get) Token: 0x06001121 RID: 4385 RVA: 0x0000DBC9 File Offset: 0x0000BDC9
	// (set) Token: 0x06001122 RID: 4386 RVA: 0x0000DBD1 File Offset: 0x0000BDD1
	public bool Boolean_11 { get; set; }

	// Token: 0x17000483 RID: 1155
	// (get) Token: 0x06001123 RID: 4387 RVA: 0x0000DBDA File Offset: 0x0000BDDA
	// (set) Token: 0x06001124 RID: 4388 RVA: 0x0000DBE2 File Offset: 0x0000BDE2
	public bool Boolean_12 { get; set; }

	// Token: 0x17000484 RID: 1156
	// (get) Token: 0x06001125 RID: 4389 RVA: 0x0000DBEB File Offset: 0x0000BDEB
	// (set) Token: 0x06001126 RID: 4390 RVA: 0x0000DBF3 File Offset: 0x0000BDF3
	public bool Boolean_13 { get; set; }

	// Token: 0x17000485 RID: 1157
	// (get) Token: 0x06001127 RID: 4391 RVA: 0x0000DBFC File Offset: 0x0000BDFC
	// (set) Token: 0x06001128 RID: 4392 RVA: 0x0000DC04 File Offset: 0x0000BE04
	public bool Boolean_14 { get; set; }

	// Token: 0x17000486 RID: 1158
	// (get) Token: 0x06001129 RID: 4393 RVA: 0x0000DC0D File Offset: 0x0000BE0D
	// (set) Token: 0x0600112A RID: 4394 RVA: 0x0000DC15 File Offset: 0x0000BE15
	public bool Boolean_15 { get; set; }

	// Token: 0x17000487 RID: 1159
	// (get) Token: 0x0600112B RID: 4395 RVA: 0x0000DC1E File Offset: 0x0000BE1E
	// (set) Token: 0x0600112C RID: 4396 RVA: 0x0000DC26 File Offset: 0x0000BE26
	public bool Boolean_16 { get; set; }

	// Token: 0x17000488 RID: 1160
	// (get) Token: 0x0600112D RID: 4397 RVA: 0x0000DC2F File Offset: 0x0000BE2F
	// (set) Token: 0x0600112E RID: 4398 RVA: 0x0000DC37 File Offset: 0x0000BE37
	public bool Boolean_17 { get; set; }

	// Token: 0x17000489 RID: 1161
	// (get) Token: 0x0600112F RID: 4399 RVA: 0x0000DC40 File Offset: 0x0000BE40
	// (set) Token: 0x06001130 RID: 4400 RVA: 0x0000DC48 File Offset: 0x0000BE48
	public bool Boolean_18 { get; set; }

	// Token: 0x1700048A RID: 1162
	// (get) Token: 0x06001131 RID: 4401 RVA: 0x0000DC51 File Offset: 0x0000BE51
	// (set) Token: 0x06001132 RID: 4402 RVA: 0x0000DC59 File Offset: 0x0000BE59
	public bool Boolean_19 { get; set; }

	// Token: 0x1700048B RID: 1163
	// (get) Token: 0x06001133 RID: 4403 RVA: 0x0000DC62 File Offset: 0x0000BE62
	// (set) Token: 0x06001134 RID: 4404 RVA: 0x0000DC6A File Offset: 0x0000BE6A
	public bool Boolean_20 { get; set; }

	// Token: 0x1700048C RID: 1164
	// (get) Token: 0x06001135 RID: 4405 RVA: 0x0000DC73 File Offset: 0x0000BE73
	// (set) Token: 0x06001136 RID: 4406 RVA: 0x0000DC7B File Offset: 0x0000BE7B
	public bool Boolean_21 { get; set; }

	// Token: 0x1700048D RID: 1165
	// (get) Token: 0x06001137 RID: 4407 RVA: 0x0000DC84 File Offset: 0x0000BE84
	// (set) Token: 0x06001138 RID: 4408 RVA: 0x0000DC8C File Offset: 0x0000BE8C
	public bool Boolean_22 { get; set; }

	// Token: 0x1700048E RID: 1166
	// (get) Token: 0x06001139 RID: 4409 RVA: 0x0000DC95 File Offset: 0x0000BE95
	// (set) Token: 0x0600113A RID: 4410 RVA: 0x0000DC9D File Offset: 0x0000BE9D
	public bool Boolean_23 { get; set; }

	// Token: 0x1700048F RID: 1167
	// (get) Token: 0x0600113B RID: 4411 RVA: 0x0000DCA6 File Offset: 0x0000BEA6
	// (set) Token: 0x0600113C RID: 4412 RVA: 0x0000DCAE File Offset: 0x0000BEAE
	public bool Boolean_24 { get; set; }

	// Token: 0x17000490 RID: 1168
	// (get) Token: 0x0600113D RID: 4413 RVA: 0x0000DCB7 File Offset: 0x0000BEB7
	// (set) Token: 0x0600113E RID: 4414 RVA: 0x0000DCBF File Offset: 0x0000BEBF
	public bool Boolean_25 { get; set; }

	// Token: 0x17000491 RID: 1169
	// (get) Token: 0x0600113F RID: 4415 RVA: 0x0000DCC8 File Offset: 0x0000BEC8
	// (set) Token: 0x06001140 RID: 4416 RVA: 0x0000DCD0 File Offset: 0x0000BED0
	public bool Boolean_26 { get; set; }

	// Token: 0x17000492 RID: 1170
	// (get) Token: 0x06001141 RID: 4417 RVA: 0x0000DCD9 File Offset: 0x0000BED9
	// (set) Token: 0x06001142 RID: 4418 RVA: 0x0000DCE1 File Offset: 0x0000BEE1
	public bool Boolean_27 { get; set; }

	// Token: 0x17000493 RID: 1171
	// (get) Token: 0x06001143 RID: 4419 RVA: 0x0000DCEA File Offset: 0x0000BEEA
	// (set) Token: 0x06001144 RID: 4420 RVA: 0x0000DCF2 File Offset: 0x0000BEF2
	public bool Boolean_28 { get; set; }

	// Token: 0x17000494 RID: 1172
	// (get) Token: 0x06001145 RID: 4421 RVA: 0x0000DCFB File Offset: 0x0000BEFB
	// (set) Token: 0x06001146 RID: 4422 RVA: 0x0000DD03 File Offset: 0x0000BF03
	public bool Boolean_29 { get; set; }

	// Token: 0x17000495 RID: 1173
	// (get) Token: 0x06001147 RID: 4423 RVA: 0x0000DD0C File Offset: 0x0000BF0C
	// (set) Token: 0x06001148 RID: 4424 RVA: 0x0000DD14 File Offset: 0x0000BF14
	public bool Boolean_30 { get; set; }

	// Token: 0x17000496 RID: 1174
	// (get) Token: 0x06001149 RID: 4425 RVA: 0x0000DD1D File Offset: 0x0000BF1D
	// (set) Token: 0x0600114A RID: 4426 RVA: 0x0000DD25 File Offset: 0x0000BF25
	public bool Boolean_31 { get; set; }

	// Token: 0x17000497 RID: 1175
	// (get) Token: 0x0600114B RID: 4427 RVA: 0x0000DD2E File Offset: 0x0000BF2E
	// (set) Token: 0x0600114C RID: 4428 RVA: 0x0000DD36 File Offset: 0x0000BF36
	public bool Boolean_32 { get; set; }

	// Token: 0x17000498 RID: 1176
	// (get) Token: 0x0600114D RID: 4429 RVA: 0x0000DD3F File Offset: 0x0000BF3F
	// (set) Token: 0x0600114E RID: 4430 RVA: 0x0000DD47 File Offset: 0x0000BF47
	public bool Boolean_33 { get; set; }

	// Token: 0x17000499 RID: 1177
	// (get) Token: 0x0600114F RID: 4431 RVA: 0x0000DD50 File Offset: 0x0000BF50
	// (set) Token: 0x06001150 RID: 4432 RVA: 0x0000DD58 File Offset: 0x0000BF58
	public int Int32_2
	{
		get
		{
			return this.int_3;
		}
		set
		{
			this.int_3 = value;
			if (this.listViewItem_0 != null)
			{
				this.listViewItem_0.SubItems[10].Text = this.String_12;
				this.string_2 = null;
			}
		}
	}

	// Token: 0x06001151 RID: 4433 RVA: 0x0000DD8D File Offset: 0x0000BF8D
	public void method_1(string string_5)
	{
		if (this.class159_0 != null)
		{
			this.class159_0.method_282("DataPool:SendLoginCode(" + string_5 + ")", false);
		}
	}

	// Token: 0x1700049A RID: 1178
	// (get) Token: 0x06001152 RID: 4434 RVA: 0x0000DDB3 File Offset: 0x0000BFB3
	// (set) Token: 0x06001153 RID: 4435 RVA: 0x0000DDBB File Offset: 0x0000BFBB
	public int Int32_3 { get; set; }

	// Token: 0x06001154 RID: 4436 RVA: 0x0000DDC4 File Offset: 0x0000BFC4
	public void method_2()
	{
		this.bool_38 = true;
		new Thread(new ThreadStart(this.method_3))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06001155 RID: 4437 RVA: 0x0005D778 File Offset: 0x0005B978
	public void method_3()
	{
		try
		{
			this.Int32_3 = (int)this.class159_0.GClass123_0.method_4(new byte[]
			{
				1,
				0,
				0,
				0,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160,
				byte.MaxValue,
				160
			}, (uint)this.Int32_3, 2147483647U) + 4;
		}
		catch
		{
		}
		this.bool_38 = false;
	}

	// Token: 0x06001156 RID: 4438 RVA: 0x0000DDEA File Offset: 0x0000BFEA
	public void method_4()
	{
		this.bool_38 = true;
		new Thread(new ThreadStart(this.method_5))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06001157 RID: 4439 RVA: 0x0005D7DC File Offset: 0x0005B9DC
	public void method_5()
	{
		try
		{
			if (this.Int32_3 == 0)
			{
				this.Int32_3 = (int)this.class159_0.GClass123_0.method_4(new byte[]
				{
					1,
					0,
					0,
					0,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160,
					byte.MaxValue,
					160
				}, 0U, 2147483647U) + 4;
			}
		}
		catch
		{
		}
		this.bool_38 = false;
	}

	// Token: 0x1700049B RID: 1179
	// (get) Token: 0x06001158 RID: 4440 RVA: 0x0005D844 File Offset: 0x0005BA44
	public static List<Class145> List_0
	{
		get
		{
			List<Class145> list = new List<Class145>();
			try
			{
				int num = 1;
				foreach (object obj in MicroLogin.xmlDocument_0.SelectSingleNode("Accounts").SelectNodes("Account" + Main.String_3.Replace("#", "")))
				{
					XmlElement xmlElement_ = (XmlElement)obj;
					try
					{
						Class145 @class = new Class145(xmlElement_, MicroLogin.xmlDocument_0, null);
						@class.listViewItem_0 = new ListViewItem(num++.ToString());
						@class.listViewItem_0.SubItems.Add(@class.String_2);
						@class.listViewItem_0.SubItems.Add(@class.String_8);
						@class.listViewItem_0.SubItems.Add(@class.String_6);
						@class.listViewItem_0.SubItems.Add(@class.String_15);
						@class.listViewItem_0.SubItems.Add(@class.String_20);
						@class.listViewItem_0.SubItems.Add(@class.String_14);
						@class.listViewItem_0.SubItems.Add(@class.String_16);
						@class.listViewItem_0.SubItems.Add(@class.String_17);
						@class.listViewItem_0.SubItems.Add(@class.String_18);
						@class.listViewItem_0.SubItems.Add(@class.String_12);
						@class.listViewItem_0.Tag = @class;
						list.Add(@class);
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			return list;
		}
	}

	// Token: 0x06001159 RID: 4441 RVA: 0x0005DA54 File Offset: 0x0005BC54
	public List<Class145> method_6()
	{
		List<Class145> list = new List<Class145>();
		int num = 1;
		foreach (object obj in this.xmlDocument_0.SelectSingleNode("Accounts").SelectNodes("Account"))
		{
			XmlElement xmlElement_ = (XmlElement)obj;
			try
			{
				Class145 @class = new Class145(xmlElement_, this.xmlDocument_0, this.String_1);
				@class.listViewItem_0 = new ListViewItem(num++.ToString());
				@class.listViewItem_0.SubItems.Add(@class.String_2);
				@class.listViewItem_0.SubItems.Add(@class.String_8);
				@class.listViewItem_0.SubItems.Add(@class.String_6);
				@class.listViewItem_0.SubItems.Add(@class.String_15);
				@class.listViewItem_0.SubItems.Add(@class.String_20);
				@class.listViewItem_0.SubItems.Add(@class.String_14);
				@class.listViewItem_0.SubItems.Add(@class.String_16);
				@class.listViewItem_0.SubItems.Add(@class.String_17);
				@class.listViewItem_0.SubItems.Add(@class.String_18);
				@class.listViewItem_0.SubItems.Add(@class.String_12);
				@class.listViewItem_0.Tag = @class;
				list.Add(@class);
			}
			catch
			{
			}
		}
		return list;
	}

	// Token: 0x04000894 RID: 2196
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04000895 RID: 2197
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000896 RID: 2198
	public XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x04000897 RID: 2199
	public Stopwatch stopwatch_0;

	// Token: 0x04000898 RID: 2200
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04000899 RID: 2201
	public Stopwatch stopwatch_1 = Stopwatch.StartNew();

	// Token: 0x0400089A RID: 2202
	[CompilerGenerated]
	private bool bool_2;

	// Token: 0x0400089B RID: 2203
	[CompilerGenerated]
	private string string_1;

	// Token: 0x0400089C RID: 2204
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x0400089D RID: 2205
	private string string_2;

	// Token: 0x0400089E RID: 2206
	public ListViewItem listViewItem_0;

	// Token: 0x0400089F RID: 2207
	public bool bool_4;

	// Token: 0x040008A0 RID: 2208
	public bool bool_5;

	// Token: 0x040008A1 RID: 2209
	public int int_0 = 5;

	// Token: 0x040008A2 RID: 2210
	[CompilerGenerated]
	private Stopwatch stopwatch_2;

	// Token: 0x040008A3 RID: 2211
	[CompilerGenerated]
	private bool bool_6;

	// Token: 0x040008A4 RID: 2212
	public Stopwatch stopwatch_3 = Stopwatch.StartNew();

	// Token: 0x040008A5 RID: 2213
	[CompilerGenerated]
	private bool bool_7;

	// Token: 0x040008A6 RID: 2214
	[CompilerGenerated]
	private bool bool_8;

	// Token: 0x040008A7 RID: 2215
	public XmlNode xmlNode_0;

	// Token: 0x040008A8 RID: 2216
	public Class159 class159_0;

	// Token: 0x040008A9 RID: 2217
	public bool bool_9;

	// Token: 0x040008AA RID: 2218
	public bool bool_10;

	// Token: 0x040008AB RID: 2219
	public int int_1;

	// Token: 0x040008AC RID: 2220
	public int int_2;

	// Token: 0x040008AD RID: 2221
	private string string_3;

	// Token: 0x040008AE RID: 2222
	[CompilerGenerated]
	private ListViewItem listViewItem_1;

	// Token: 0x040008AF RID: 2223
	public string string_4;

	// Token: 0x040008B0 RID: 2224
	[CompilerGenerated]
	private Stopwatch stopwatch_4;

	// Token: 0x040008B1 RID: 2225
	[CompilerGenerated]
	private bool bool_11;

	// Token: 0x040008B2 RID: 2226
	public bool bool_12;

	// Token: 0x040008B3 RID: 2227
	public bool bool_13;

	// Token: 0x040008B4 RID: 2228
	[CompilerGenerated]
	private bool bool_14;

	// Token: 0x040008B5 RID: 2229
	[CompilerGenerated]
	private bool bool_15;

	// Token: 0x040008B6 RID: 2230
	[CompilerGenerated]
	private bool bool_16;

	// Token: 0x040008B7 RID: 2231
	[CompilerGenerated]
	private bool bool_17;

	// Token: 0x040008B8 RID: 2232
	[CompilerGenerated]
	private bool bool_18;

	// Token: 0x040008B9 RID: 2233
	[CompilerGenerated]
	private bool bool_19;

	// Token: 0x040008BA RID: 2234
	[CompilerGenerated]
	private bool bool_20;

	// Token: 0x040008BB RID: 2235
	[CompilerGenerated]
	private bool bool_21;

	// Token: 0x040008BC RID: 2236
	[CompilerGenerated]
	private bool bool_22;

	// Token: 0x040008BD RID: 2237
	[CompilerGenerated]
	private bool bool_23;

	// Token: 0x040008BE RID: 2238
	[CompilerGenerated]
	private bool bool_24;

	// Token: 0x040008BF RID: 2239
	[CompilerGenerated]
	private bool bool_25;

	// Token: 0x040008C0 RID: 2240
	[CompilerGenerated]
	private bool bool_26;

	// Token: 0x040008C1 RID: 2241
	[CompilerGenerated]
	private bool bool_27;

	// Token: 0x040008C2 RID: 2242
	[CompilerGenerated]
	private bool bool_28;

	// Token: 0x040008C3 RID: 2243
	[CompilerGenerated]
	private bool bool_29;

	// Token: 0x040008C4 RID: 2244
	[CompilerGenerated]
	private bool bool_30;

	// Token: 0x040008C5 RID: 2245
	[CompilerGenerated]
	private bool bool_31;

	// Token: 0x040008C6 RID: 2246
	[CompilerGenerated]
	private bool bool_32;

	// Token: 0x040008C7 RID: 2247
	[CompilerGenerated]
	private bool bool_33;

	// Token: 0x040008C8 RID: 2248
	[CompilerGenerated]
	private bool bool_34;

	// Token: 0x040008C9 RID: 2249
	[CompilerGenerated]
	private bool bool_35;

	// Token: 0x040008CA RID: 2250
	[CompilerGenerated]
	private bool bool_36;

	// Token: 0x040008CB RID: 2251
	[CompilerGenerated]
	private bool bool_37;

	// Token: 0x040008CC RID: 2252
	private int int_3 = 1;

	// Token: 0x040008CD RID: 2253
	[CompilerGenerated]
	private int int_4;

	// Token: 0x040008CE RID: 2254
	public bool bool_38;
}
