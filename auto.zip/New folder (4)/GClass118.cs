﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

// Token: 0x02000193 RID: 403
public static class GClass118
{
	// Token: 0x06001269 RID: 4713 RVA: 0x00069638 File Offset: 0x00067838
	public static T smethod_0<T>(T gparam_0)
	{
		T result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(memoryStream, gparam_0);
			memoryStream.Position = 0L;
			result = (T)((object)binaryFormatter.Deserialize(memoryStream));
		}
		return result;
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x0000E8EF File Offset: 0x0000CAEF
	public static uint smethod_1(this Type type_0)
	{
		return (uint)Marshal.SizeOf(type_0);
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x00069690 File Offset: 0x00067890
	public static string smethod_2(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		string text = null;
		try
		{
			text = Path.GetTempFileName();
		}
		catch (IOException)
		{
			text = Path.Combine(Directory.GetCurrentDirectory(), Path.GetRandomFileName());
		}
		try
		{
			File.WriteAllBytes(text, byte_0);
		}
		catch
		{
			text = null;
		}
		return text;
	}
}
