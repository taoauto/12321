﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000EA RID: 234
public class GEventArgs13 : EventArgs
{
	// Token: 0x1700034D RID: 845
	// (get) Token: 0x06000C88 RID: 3208 RVA: 0x0000B0A2 File Offset: 0x000092A2
	// (set) Token: 0x06000C89 RID: 3209 RVA: 0x0000B0AA File Offset: 0x000092AA
	public List<int> List_0 { get; private set; }

	// Token: 0x1700034E RID: 846
	// (get) Token: 0x06000C8A RID: 3210 RVA: 0x0000B0B3 File Offset: 0x000092B3
	// (set) Token: 0x06000C8B RID: 3211 RVA: 0x0000B0BB File Offset: 0x000092BB
	public bool Boolean_0 { get; private set; }

	// Token: 0x1700034F RID: 847
	// (get) Token: 0x06000C8C RID: 3212 RVA: 0x0000B0C4 File Offset: 0x000092C4
	// (set) Token: 0x06000C8D RID: 3213 RVA: 0x0000B0CC File Offset: 0x000092CC
	public GClass81 GClass81_0 { get; private set; }

	// Token: 0x06000C8E RID: 3214 RVA: 0x0000B0D5 File Offset: 0x000092D5
	public GEventArgs13(List<int> list_1, bool bool_1, GClass81 gclass81_1)
	{
		this.List_0 = list_1;
		this.Boolean_0 = bool_1;
		this.GClass81_0 = gclass81_1;
	}

	// Token: 0x040005C0 RID: 1472
	[CompilerGenerated]
	private List<int> list_0;

	// Token: 0x040005C1 RID: 1473
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040005C2 RID: 1474
	[CompilerGenerated]
	private GClass81 gclass81_0;
}
