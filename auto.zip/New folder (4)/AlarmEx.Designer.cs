﻿// Token: 0x02000201 RID: 513
internal partial class AlarmEx : global::System.Windows.Forms.Form
{
	// Token: 0x06001AAE RID: 6830 RVA: 0x000C8C00 File Offset: 0x000C6E00
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.timer_0.Enabled = true;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.White;
		base.ClientSize = new global::System.Drawing.Size(320, 130);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "AlarmEx";
		base.Opacity = 0.9;
		base.ShowInTaskbar = false;
		this.Text = "AlarmEx";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.AlarmEx_Load);
		base.ResumeLayout(false);
	}

	// Token: 0x040010AC RID: 4268
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x040010AD RID: 4269
	private global::System.Windows.Forms.Timer timer_0;
}
