﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using WebSocketSharp;

// Token: 0x02000074 RID: 116
public class GClass30
{
	// Token: 0x06000527 RID: 1319 RVA: 0x00031094 File Offset: 0x0002F294
	internal GClass30(GClass24 gclass24_1)
	{
		this.gclass24_0 = gclass24_1;
		this.bool_0 = true;
		this.dictionary_0 = new Dictionary<string, GClass29>();
		this.enum5_0 = Enum5.Ready;
		this.object_0 = ((ICollection)this.dictionary_0).SyncRoot;
		this.timeSpan_0 = TimeSpan.FromSeconds(1.0);
	}

	// Token: 0x17000156 RID: 342
	// (get) Token: 0x06000528 RID: 1320 RVA: 0x000310F0 File Offset: 0x0002F2F0
	public int Int32_0
	{
		get
		{
			object obj = this.object_0;
			int count;
			lock (obj)
			{
				count = this.dictionary_0.Count;
			}
			return count;
		}
	}

	// Token: 0x17000157 RID: 343
	// (get) Token: 0x06000529 RID: 1321 RVA: 0x00031138 File Offset: 0x0002F338
	public IEnumerable<GClass29> IEnumerable_0
	{
		get
		{
			object obj = this.object_0;
			IEnumerable<GClass29> result;
			lock (obj)
			{
				result = this.dictionary_0.Values.smethod_64<GClass29>();
			}
			return result;
		}
	}

	// Token: 0x17000158 RID: 344
	public GClass29 this[string string_0]
	{
		get
		{
			if (string_0 == null)
			{
				throw new ArgumentNullException("path");
			}
			if (string_0.Length == 0)
			{
				throw new ArgumentException("An empty string.", "path");
			}
			if (string_0[0] != '/')
			{
				throw new ArgumentException("Not an absolute path.", "path");
			}
			if (string_0.IndexOfAny(new char[]
			{
				'?',
				'#'
			}) > -1)
			{
				throw new ArgumentException("It includes either or both query and fragment components.", "path");
			}
			GClass29 result;
			this.method_7(string_0, out result);
			return result;
		}
	}

	// Token: 0x17000159 RID: 345
	// (get) Token: 0x0600052B RID: 1323 RVA: 0x00006581 File Offset: 0x00004781
	// (set) Token: 0x0600052C RID: 1324 RVA: 0x00031208 File Offset: 0x0002F408
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			string string_;
			if (!this.method_5(out string_))
			{
				this.gclass24_0.method_6(string_);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_5(out string_))
				{
					this.gclass24_0.method_6(string_);
				}
				else
				{
					foreach (GClass29 gclass in this.dictionary_0.Values)
					{
						gclass.Boolean_0 = value;
					}
					this.bool_0 = value;
				}
			}
		}
	}

	// Token: 0x1700015A RID: 346
	// (get) Token: 0x0600052D RID: 1325 RVA: 0x000312C0 File Offset: 0x0002F4C0
	public IEnumerable<string> IEnumerable_1
	{
		get
		{
			object obj = this.object_0;
			IEnumerable<string> result;
			lock (obj)
			{
				result = this.dictionary_0.Keys.smethod_64<string>();
			}
			return result;
		}
	}

	// Token: 0x1700015B RID: 347
	// (get) Token: 0x0600052E RID: 1326 RVA: 0x0003130C File Offset: 0x0002F50C
	[Obsolete("This property will be removed.")]
	public int Int32_1
	{
		get
		{
			int num = 0;
			foreach (GClass29 gclass in this.IEnumerable_0)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					break;
				}
				num += gclass.GClass31_0.Int32_0;
			}
			return num;
		}
	}

	// Token: 0x1700015C RID: 348
	// (get) Token: 0x0600052F RID: 1327 RVA: 0x0000658B File Offset: 0x0000478B
	// (set) Token: 0x06000530 RID: 1328 RVA: 0x00031374 File Offset: 0x0002F574
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.timeSpan_0;
		}
		set
		{
			if (value <= TimeSpan.Zero)
			{
				throw new ArgumentOutOfRangeException("value", "Zero or less.");
			}
			string string_;
			if (!this.method_5(out string_))
			{
				this.gclass24_0.method_6(string_);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_5(out string_))
				{
					this.gclass24_0.method_6(string_);
				}
				else
				{
					foreach (GClass29 gclass in this.dictionary_0.Values)
					{
						gclass.TimeSpan_0 = value;
					}
					this.timeSpan_0 = value;
				}
			}
		}
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x00031448 File Offset: 0x0002F648
	private void method_0(Enum3 enum3_0, byte[] byte_0, Action action_0)
	{
		Dictionary<CompressionMethod, byte[]> dictionary = new Dictionary<CompressionMethod, byte[]>();
		try
		{
			foreach (GClass29 gclass in this.IEnumerable_0)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					this.gclass24_0.method_2("The server is shutting down.");
					break;
				}
				gclass.GClass31_0.method_10(enum3_0, byte_0, dictionary);
			}
			if (action_0 != null)
			{
				action_0();
			}
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
		finally
		{
			dictionary.Clear();
		}
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x00031514 File Offset: 0x0002F714
	private void method_1(Enum3 enum3_0, Stream stream_0, Action action_0)
	{
		Dictionary<CompressionMethod, Stream> dictionary = new Dictionary<CompressionMethod, Stream>();
		try
		{
			foreach (GClass29 gclass in this.IEnumerable_0)
			{
				if (this.enum5_0 != Enum5.Start)
				{
					this.gclass24_0.method_2("The server is shutting down.");
					break;
				}
				gclass.GClass31_0.method_11(enum3_0, stream_0, dictionary);
			}
			if (action_0 != null)
			{
				action_0();
			}
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
		finally
		{
			foreach (Stream stream in dictionary.Values)
			{
				stream.Dispose();
			}
			dictionary.Clear();
		}
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x00006593 File Offset: 0x00004793
	private void method_2(Enum3 enum3_0, byte[] byte_0, Action action_0)
	{
		GClass30.Class55 @class = new GClass30.Class55();
		@class.gclass30_0 = this;
		@class.enum3_0 = enum3_0;
		@class.byte_0 = byte_0;
		@class.action_0 = action_0;
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x000065C7 File Offset: 0x000047C7
	private void method_3(Enum3 enum3_0, Stream stream_0, Action action_0)
	{
		GClass30.Class56 @class = new GClass30.Class56();
		@class.gclass30_0 = this;
		@class.enum3_0 = enum3_0;
		@class.stream_0 = stream_0;
		@class.action_0 = action_0;
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x00031620 File Offset: 0x0002F820
	private Dictionary<string, Dictionary<string, bool>> method_4(byte[] byte_0, TimeSpan timeSpan_1)
	{
		Dictionary<string, Dictionary<string, bool>> dictionary = new Dictionary<string, Dictionary<string, bool>>();
		foreach (GClass29 gclass in this.IEnumerable_0)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				this.gclass24_0.method_2("The server is shutting down.");
				break;
			}
			Dictionary<string, bool> value = gclass.GClass31_0.method_12(byte_0, timeSpan_1);
			dictionary.Add(gclass.String_0, value);
		}
		return dictionary;
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x000065FB File Offset: 0x000047FB
	private bool method_5(out string string_0)
	{
		string_0 = null;
		if (this.enum5_0 == Enum5.Start)
		{
			string_0 = "The server has already started.";
			return false;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			string_0 = "The server is shutting down.";
			return false;
		}
		return true;
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x000316A8 File Offset: 0x0002F8A8
	internal void method_6<T>(string string_0, Func<T> func_0) where T : GClass27
	{
		string_0 = string_0.smethod_69();
		object obj = this.object_0;
		lock (obj)
		{
			GClass29 gclass;
			if (this.dictionary_0.TryGetValue(string_0, out gclass))
			{
				throw new ArgumentException("Already in use.", "path");
			}
			gclass = new Class53<T>(string_0, func_0, null, this.gclass24_0);
			if (!this.bool_0)
			{
				gclass.Boolean_0 = false;
			}
			if (this.timeSpan_0 != gclass.TimeSpan_0)
			{
				gclass.TimeSpan_0 = this.timeSpan_0;
			}
			if (this.enum5_0 == Enum5.Start)
			{
				gclass.method_0();
			}
			this.dictionary_0.Add(string_0, gclass);
		}
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x00031768 File Offset: 0x0002F968
	internal bool method_7(string string_0, out GClass29 gclass29_0)
	{
		string_0 = string_0.smethod_69();
		object obj = this.object_0;
		bool result;
		lock (obj)
		{
			result = this.dictionary_0.TryGetValue(string_0, out gclass29_0);
		}
		return result;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x000317BC File Offset: 0x0002F9BC
	internal void method_8()
	{
		object obj = this.object_0;
		lock (obj)
		{
			foreach (GClass29 gclass in this.dictionary_0.Values)
			{
				gclass.method_0();
			}
			this.enum5_0 = Enum5.Start;
		}
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x00031844 File Offset: 0x0002FA44
	internal void method_9(ushort ushort_0, string string_0)
	{
		object obj = this.object_0;
		lock (obj)
		{
			this.enum5_0 = Enum5.ShuttingDown;
			foreach (GClass29 gclass in this.dictionary_0.Values)
			{
				gclass.method_2(ushort_0, string_0);
			}
			this.enum5_0 = Enum5.Stop;
		}
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x000318D8 File Offset: 0x0002FAD8
	public void method_10<T>(string string_0, Action<T> action_0) where T : GClass27, new()
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_0[0] != '/')
		{
			throw new ArgumentException("Not an absolute path.", "path");
		}
		if (string_0.IndexOfAny(new char[]
		{
			'?',
			'#'
		}) > -1)
		{
			throw new ArgumentException("It includes either or both query and fragment components.", "path");
		}
		string_0 = string_0.smethod_69();
		object obj = this.object_0;
		lock (obj)
		{
			GClass29 gclass;
			if (this.dictionary_0.TryGetValue(string_0, out gclass))
			{
				throw new ArgumentException("Already in use.", "path");
			}
			gclass = new Class53<T>(string_0, new Func<T>(GClass30.Class57<T>.<>9.method_0), action_0, this.gclass24_0);
			if (!this.bool_0)
			{
				gclass.Boolean_0 = false;
			}
			if (this.timeSpan_0 != gclass.TimeSpan_0)
			{
				gclass.TimeSpan_0 = this.timeSpan_0;
			}
			if (this.enum5_0 == Enum5.Start)
			{
				gclass.method_0();
			}
			this.dictionary_0.Add(string_0, gclass);
		}
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x00031A20 File Offset: 0x0002FC20
	[Obsolete("This method will be removed.")]
	public void method_11(byte[] byte_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		if ((long)byte_0.Length <= (long)GClass25.int_2)
		{
			this.method_0(Enum3.Binary, byte_0, null);
			return;
		}
		this.method_1(Enum3.Binary, new MemoryStream(byte_0), null);
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x00031A74 File Offset: 0x0002FC74
	[Obsolete("This method will be removed.")]
	public void method_12(string string_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		if ((long)array.Length <= (long)GClass25.int_2)
		{
			this.method_0(Enum3.Text, array, null);
			return;
		}
		this.method_1(Enum3.Text, new MemoryStream(array), null);
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x00031AE4 File Offset: 0x0002FCE4
	[Obsolete("This method will be removed.")]
	public void method_13(byte[] byte_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		if ((long)byte_0.Length <= (long)GClass25.int_2)
		{
			this.method_2(Enum3.Binary, byte_0, action_0);
			return;
		}
		this.method_3(Enum3.Binary, new MemoryStream(byte_0), action_0);
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x00031B38 File Offset: 0x0002FD38
	[Obsolete("This method will be removed.")]
	public void method_14(string string_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		if ((long)array.Length <= (long)GClass25.int_2)
		{
			this.method_2(Enum3.Text, array, action_0);
			return;
		}
		this.method_3(Enum3.Text, new MemoryStream(array), action_0);
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x00031BA8 File Offset: 0x0002FDA8
	[Obsolete("This method will be removed.")]
	public void method_15(Stream stream_0, int int_0, Action action_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (stream_0 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream_0.CanRead)
		{
			throw new ArgumentException("It cannot be read.", "stream");
		}
		if (int_0 < 1)
		{
			throw new ArgumentException("Less than 1.", "length");
		}
		byte[] array = stream_0.smethod_54(int_0);
		int num = array.Length;
		if (num == 0)
		{
			throw new ArgumentException("No data could be read from it.", "stream");
		}
		if (num < int_0)
		{
			this.gclass24_0.method_6(string.Format("Only {0} byte(s) of data could be read from the stream.", num));
		}
		if (num <= GClass25.int_2)
		{
			this.method_2(Enum3.Binary, array, action_0);
			return;
		}
		this.method_3(Enum3.Binary, new MemoryStream(array), action_0);
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x00006629 File Offset: 0x00004829
	[Obsolete("This method will be removed.")]
	public Dictionary<string, Dictionary<string, bool>> method_16()
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		return this.method_4(Class42.byte_3, this.timeSpan_0);
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x00031C64 File Offset: 0x0002FE64
	[Obsolete("This method will be removed.")]
	public Dictionary<string, Dictionary<string, bool>> method_17(string string_0)
	{
		if (this.enum5_0 != Enum5.Start)
		{
			throw new InvalidOperationException("The current state of the manager is not Start.");
		}
		if (string_0.smethod_88())
		{
			return this.method_4(Class42.byte_3, this.timeSpan_0);
		}
		byte[] array;
		if (!string_0.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "message");
		}
		if (array.Length > 125)
		{
			string message = "Its size is greater than 125 bytes.";
			throw new ArgumentOutOfRangeException("message", message);
		}
		Class42 @class = Class42.smethod_15(array, false);
		return this.method_4(@class.method_3(), this.timeSpan_0);
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x00031CF0 File Offset: 0x0002FEF0
	public void method_18()
	{
		List<GClass29> list = null;
		object obj = this.object_0;
		lock (obj)
		{
			list = this.dictionary_0.Values.smethod_64<GClass29>();
			this.dictionary_0.Clear();
		}
		foreach (GClass29 gclass in list)
		{
			if (gclass.Enum5_0 == Enum5.Start)
			{
				gclass.method_2(1001, string.Empty);
			}
		}
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x00031D9C File Offset: 0x0002FF9C
	public bool method_19(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_0[0] != '/')
		{
			throw new ArgumentException("Not an absolute path.", "path");
		}
		if (string_0.IndexOfAny(new char[]
		{
			'?',
			'#'
		}) > -1)
		{
			throw new ArgumentException("It includes either or both query and fragment components.", "path");
		}
		string_0 = string_0.smethod_69();
		object obj = this.object_0;
		GClass29 gclass;
		lock (obj)
		{
			if (!this.dictionary_0.TryGetValue(string_0, out gclass))
			{
				return false;
			}
			this.dictionary_0.Remove(string_0);
		}
		if (gclass.Enum5_0 == Enum5.Start)
		{
			gclass.method_2(1001, string.Empty);
		}
		return true;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x00031E88 File Offset: 0x00030088
	public bool method_20(string string_0, out GClass29 gclass29_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_0[0] != '/')
		{
			throw new ArgumentException("Not an absolute path.", "path");
		}
		if (string_0.IndexOfAny(new char[]
		{
			'?',
			'#'
		}) > -1)
		{
			throw new ArgumentException("It includes either or both query and fragment components.", "path");
		}
		return this.method_7(string_0, out gclass29_0);
	}

	// Token: 0x040002A8 RID: 680
	private volatile bool bool_0;

	// Token: 0x040002A9 RID: 681
	private Dictionary<string, GClass29> dictionary_0;

	// Token: 0x040002AA RID: 682
	private GClass24 gclass24_0;

	// Token: 0x040002AB RID: 683
	private volatile Enum5 enum5_0;

	// Token: 0x040002AC RID: 684
	private object object_0;

	// Token: 0x040002AD RID: 685
	private TimeSpan timeSpan_0;

	// Token: 0x02000075 RID: 117
	[CompilerGenerated]
	private sealed class Class55
	{
		// Token: 0x06000547 RID: 1351 RVA: 0x00006652 File Offset: 0x00004852
		internal void method_0(object object_0)
		{
			this.gclass30_0.method_0(this.enum3_0, this.byte_0, this.action_0);
		}

		// Token: 0x040002AE RID: 686
		public GClass30 gclass30_0;

		// Token: 0x040002AF RID: 687
		public Enum3 enum3_0;

		// Token: 0x040002B0 RID: 688
		public byte[] byte_0;

		// Token: 0x040002B1 RID: 689
		public Action action_0;
	}

	// Token: 0x02000076 RID: 118
	[CompilerGenerated]
	private sealed class Class56
	{
		// Token: 0x06000549 RID: 1353 RVA: 0x00006671 File Offset: 0x00004871
		internal void method_0(object object_0)
		{
			this.gclass30_0.method_1(this.enum3_0, this.stream_0, this.action_0);
		}

		// Token: 0x040002B2 RID: 690
		public GClass30 gclass30_0;

		// Token: 0x040002B3 RID: 691
		public Enum3 enum3_0;

		// Token: 0x040002B4 RID: 692
		public Stream stream_0;

		// Token: 0x040002B5 RID: 693
		public Action action_0;
	}

	// Token: 0x02000077 RID: 119
	[CompilerGenerated]
	[Serializable]
	private sealed class Class57<T> where T : GClass27, new()
	{
		// Token: 0x0600054C RID: 1356 RVA: 0x0000669C File Offset: 0x0000489C
		internal T method_0()
		{
			return Activator.CreateInstance<T>();
		}

		// Token: 0x040002B6 RID: 694
		public static readonly GClass30.Class57<T> <>9 = new GClass30.Class57<T>();

		// Token: 0x040002B7 RID: 695
		public static Func<T> <>9__33_0;
	}
}
