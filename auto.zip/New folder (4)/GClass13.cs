﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000022 RID: 34
public class GClass13 : GClass9, IEnumerable<GClass9>, IEnumerable
{
	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x060001CD RID: 461 RVA: 0x000042F0 File Offset: 0x000024F0
	private static Random Random_0
	{
		get
		{
			if (GClass13.random_0 == null)
			{
				GClass13.random_0 = new Random();
			}
			return GClass13.random_0;
		}
	}

	// Token: 0x060001CE RID: 462 RVA: 0x00004308 File Offset: 0x00002508
	public GClass13() : this("----------------" + GClass13.smethod_0(16))
	{
	}

	// Token: 0x060001CF RID: 463 RVA: 0x000263F8 File Offset: 0x000245F8
	public GClass13(string string_4)
	{
		if (string_4 == null)
		{
			throw new ArgumentNullException("boundary");
		}
		if (string_4.Length == 0)
		{
			throw Class13.smethod_0("boundary");
		}
		if (string_4.Length > 70)
		{
			throw Class13.smethod_2<int>("boundary", 70);
		}
		this.string_3 = string_4;
		this.string_0 = string.Format("multipart/form-data; boundary={0}", this.string_3);
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x0002646C File Offset: 0x0002466C
	public void method_1(GClass9 gclass9_0, string string_4)
	{
		if (gclass9_0 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_4.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		GClass13.Class11 item = new GClass13.Class11
		{
			string_0 = string_4,
			gclass9_0 = gclass9_0
		};
		this.list_0.Add(item);
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x000264C8 File Offset: 0x000246C8
	public void method_2(GClass9 gclass9_0, string string_4, string string_5)
	{
		if (gclass9_0 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_4.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_5 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		gclass9_0.String_0 = GClass6.smethod_3(Path.GetExtension(string_5));
		GClass13.Class11 item = new GClass13.Class11
		{
			string_0 = string_4,
			string_1 = string_5,
			gclass9_0 = gclass9_0
		};
		this.list_0.Add(item);
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x0002654C File Offset: 0x0002474C
	public void method_3(GClass9 gclass9_0, string string_4, string string_5, string string_6)
	{
		if (gclass9_0 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (string_4 == null)
		{
			throw new ArgumentNullException("name");
		}
		if (string_4.Length == 0)
		{
			throw Class13.smethod_0("name");
		}
		if (string_5 == null)
		{
			throw new ArgumentNullException("fileName");
		}
		if (string_6 == null)
		{
			throw new ArgumentNullException("contentType");
		}
		gclass9_0.String_0 = string_6;
		GClass13.Class11 item = new GClass13.Class11
		{
			string_0 = string_4,
			string_1 = string_5,
			gclass9_0 = gclass9_0
		};
		this.list_0.Add(item);
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x000265D4 File Offset: 0x000247D4
	public override long \u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E()
	{
		this.method_4();
		long num = 0L;
		foreach (GClass13.Class11 @class in this.list_0)
		{
			num += @class.gclass9_0.GClass9.\u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E();
			if (@class.method_0())
			{
				num += 72L;
				num += (long)@class.string_0.Length;
				num += (long)@class.string_1.Length;
				num += (long)@class.gclass9_0.String_0.Length;
			}
			else
			{
				num += 43L;
				num += (long)@class.string_0.Length;
			}
			num += (long)(this.string_3.Length + 6);
		}
		num += (long)(this.string_3.Length + 6);
		return num;
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x000266B8 File Offset: 0x000248B8
	public override void \u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(Stream stream_0)
	{
		this.method_4();
		if (stream_0 == null)
		{
			throw new ArgumentNullException("stream");
		}
		byte[] bytes = Encoding.ASCII.GetBytes("\r\n");
		byte[] bytes2 = Encoding.ASCII.GetBytes("--" + this.string_3 + "\r\n");
		foreach (GClass13.Class11 @class in this.list_0)
		{
			stream_0.Write(bytes2, 0, bytes2.Length);
			string s;
			if (@class.method_0())
			{
				s = string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n", @class.string_0, @class.string_1, @class.gclass9_0.String_0);
			}
			else
			{
				s = string.Format("Content-Disposition: form-data; name=\"{0}\"\r\n\r\n", @class.string_0);
			}
			byte[] bytes3 = Encoding.ASCII.GetBytes(s);
			stream_0.Write(bytes3, 0, bytes3.Length);
			@class.gclass9_0.GClass9.\u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(stream_0);
			stream_0.Write(bytes, 0, bytes.Length);
		}
		bytes2 = Encoding.ASCII.GetBytes("--" + this.string_3 + "--\r\n");
		stream_0.Write(bytes2, 0, bytes2.Length);
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x00004321 File Offset: 0x00002521
	public IEnumerator<GClass9> GetEnumerator()
	{
		this.method_4();
		return this.list_0.Select(new Func<GClass13.Class11, GClass9>(GClass13.Class12.<>9.method_0)).GetEnumerator();
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x000267F8 File Offset: 0x000249F8
	protected override void \u206D\u206A\u200B\u202A\u202C\u202B\u206A\u202E\u200E\u202C\u206B\u202D\u206D\u206C\u206B\u200B\u200E\u200E\u206D\u206B\u206C\u206F\u200F\u200E\u206C\u202C\u206C\u206A\u200B\u200D\u206A\u200F\u200C\u200C\u202C\u202E\u206C\u200D\u202A\u200D\u202E(bool bool_0)
	{
		if (bool_0 && this.list_0 != null)
		{
			foreach (GClass13.Class11 @class in this.list_0)
			{
				@class.gclass9_0.method_0();
			}
			this.list_0 = null;
		}
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x00004358 File Offset: 0x00002558
	IEnumerator IEnumerable.GetEnumerator()
	{
		this.method_4();
		return this.GetEnumerator();
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x00026860 File Offset: 0x00024A60
	public static string smethod_0(int int_2)
	{
		StringBuilder stringBuilder = new StringBuilder(int_2);
		for (int i = 0; i < int_2; i++)
		{
			switch (GClass13.Random_0.Next(3))
			{
			case 0:
				stringBuilder.Append((char)GClass13.Random_0.Next(48, 58));
				break;
			case 1:
				stringBuilder.Append((char)GClass13.Random_0.Next(97, 123));
				break;
			case 2:
				stringBuilder.Append((char)GClass13.Random_0.Next(65, 91));
				break;
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00004366 File Offset: 0x00002566
	private void method_4()
	{
		if (this.list_0 == null)
		{
			throw new ObjectDisposedException("MultipartContent");
		}
	}

	// Token: 0x04000112 RID: 274
	private const int int_0 = 43;

	// Token: 0x04000113 RID: 275
	private const int int_1 = 72;

	// Token: 0x04000114 RID: 276
	private const string string_1 = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n";

	// Token: 0x04000115 RID: 277
	private const string string_2 = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";

	// Token: 0x04000116 RID: 278
	[ThreadStatic]
	private static Random random_0;

	// Token: 0x04000117 RID: 279
	private string string_3;

	// Token: 0x04000118 RID: 280
	private List<GClass13.Class11> list_0 = new List<GClass13.Class11>();

	// Token: 0x02000023 RID: 35
	private sealed class Class11
	{
		// Token: 0x060001DA RID: 474 RVA: 0x0000437B File Offset: 0x0000257B
		public bool method_0()
		{
			return this.string_1 != null;
		}

		// Token: 0x04000119 RID: 281
		public string string_0;

		// Token: 0x0400011A RID: 282
		public string string_1;

		// Token: 0x0400011B RID: 283
		public GClass9 gclass9_0;
	}

	// Token: 0x02000024 RID: 36
	[CompilerGenerated]
	[Serializable]
	private sealed class Class12
	{
		// Token: 0x060001DE RID: 478 RVA: 0x00004392 File Offset: 0x00002592
		internal GClass9 method_0(GClass13.Class11 class11_0)
		{
			return class11_0.gclass9_0;
		}

		// Token: 0x0400011C RID: 284
		public static readonly GClass13.Class12 <>9 = new GClass13.Class12();

		// Token: 0x0400011D RID: 285
		public static Func<GClass13.Class11, GClass9> <>9__17_0;
	}
}
