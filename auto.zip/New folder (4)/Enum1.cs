﻿using System;

// Token: 0x02000044 RID: 68
internal enum Enum1 : byte
{
	// Token: 0x040001B2 RID: 434
	More,
	// Token: 0x040001B3 RID: 435
	Final
}
