﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x0200021B RID: 539
internal class Buff : UserControl
{
	// Token: 0x06001D07 RID: 7431 RVA: 0x00015621 File Offset: 0x00013821
	public Buff()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001D08 RID: 7432 RVA: 0x000D65A0 File Offset: 0x000D47A0
	private void Buff_Load(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Buff.Class248("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ToList<Class159>().ForEach(new Action<Class159>(this.method_1));
		this.cboPlayer.SelectedIndex = 0;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
	}

	// Token: 0x06001D09 RID: 7433 RVA: 0x000D66F0 File Offset: 0x000D48F0
	private void txtLst_TextChanged(object sender, EventArgs e)
	{
		if (base.Tag.ToString() == "Buff - All")
		{
			Class415.String_1 = this.txtLst.Text;
			return;
		}
		Class159.Class220_0.method_1("Buff", Class426.smethod_51(base.Tag.ToString().Replace("Buff - ", "")), this.txtLst.Text);
		Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().Select(new Func<KeyValuePair<int, Class159>, Class159>(Buff.Class249.<>9.method_0)).ToList<Class159>().ForEach(new Action<Class159>(this.method_2));
	}

	// Token: 0x06001D0A RID: 7434 RVA: 0x0001563A File Offset: 0x0001383A
	private void txtLst_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.A)
		{
			this.txtLst.SelectAll();
		}
	}

	// Token: 0x06001D0B RID: 7435 RVA: 0x000D67A4 File Offset: 0x000D49A4
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		string string_ = (this.cboPlayer.SelectedItem as Buff.Class248).String_0;
		if (string_ == "0000FFFF")
		{
			base.Tag = "Buff - All";
			this.txtLst.Text = Class159.Class220_0.method_0("Buff", "All");
			return;
		}
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			if (keyValuePair.Value.Class432_0.String_1 == string_)
			{
				Class159 value = keyValuePair.Value;
				base.Tag = "Buff - " + value.Class432_0.String_2;
				this.txtLst.Text = Class159.Class220_0.method_0("Buff", value.Class432_0.String_0);
			}
		}
	}

	// Token: 0x06001D0C RID: 7436 RVA: 0x00015659 File Offset: 0x00013859
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.listViewName.Search(this.txtSearch.Text);
	}

	// Token: 0x06001D0D RID: 7437 RVA: 0x000D68A0 File Offset: 0x000D4AA0
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		foreach (object obj in this.listViewName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtLst.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtLst.Text = this.txtLst.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtLst.method_1();
	}

	// Token: 0x06001D0E RID: 7438 RVA: 0x000D69A0 File Offset: 0x000D4BA0
	private void button1_Click(object sender, EventArgs e)
	{
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			if (!this.txtLst.Text.Contains(keyValuePair.Value.Class432_0.String_2))
			{
				this.txtLst.Text = this.txtLst.Text + "\r\n" + keyValuePair.Value.Class432_0.String_2;
			}
		}
	}

	// Token: 0x06001D0F RID: 7439 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_0(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06001D10 RID: 7440 RVA: 0x000D6A40 File Offset: 0x000D4C40
	private void cboPlayer_DropDown(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Buff.Class248("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ToList<Class159>().ForEach(new Action<Class159>(this.method_3));
	}

	// Token: 0x06001D11 RID: 7441 RVA: 0x00015672 File Offset: 0x00013872
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001D12 RID: 7442 RVA: 0x000D6AA4 File Offset: 0x000D4CA4
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Buff));
		this.cboPlayer = new ComboBox();
		this.splitContainer1 = new SplitContainer();
		this.txtLst = new Class85();
		this.listViewName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtSearch = new Class85();
		this.button1 = new Button();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Items.AddRange(new object[]
		{
			"Thiết Lập Dành Cho Tất Cả"
		});
		this.cboPlayer.Location = new Point(0, 332);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(473, 21);
		this.cboPlayer.TabIndex = 238;
		this.cboPlayer.DropDown += this.cboPlayer_DropDown;
		this.cboPlayer.SelectedIndexChanged += this.cboPlayer_SelectedIndexChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtLst);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(473, 332);
		this.splitContainer1.SplitterDistance = 231;
		this.splitContainer1.TabIndex = 239;
		this.txtLst.Dock = DockStyle.Fill;
		this.txtLst.Location = new Point(0, 0);
		this.txtLst.Multiline = true;
		this.txtLst.Name = "txtLst";
		this.txtLst.ScrollBars = ScrollBars.Both;
		this.txtLst.Size = new Size(231, 332);
		this.txtLst.TabIndex = 6;
		this.txtLst.String_0 = "";
		this.txtLst.Color_0 = Color.Gray;
		this.txtLst.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtLst.Color_1 = Color.LightGray;
		this.txtLst.TextChanged += this.txtLst_TextChanged;
		this.txtLst.KeyDown += this.txtLst_KeyDown;
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.Dock = DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = Color.Red;
		this.listViewName.Location = new Point(0, 20);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new Size(238, 312);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = View.Details;
		this.listViewName.DoubleClick += this.listViewName_DoubleClick;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 185;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(238, 20);
		this.txtSearch.TabIndex = 8;
		this.txtSearch.String_0 = "Search.";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 353);
		this.button1.Name = "button1";
		this.button1.Size = new Size(473, 23);
		this.button1.TabIndex = 240;
		this.button1.Text = "Lấy Danh Sách Của Tôi";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.cboPlayer);
		base.Controls.Add(this.button1);
		base.Name = "Buff";
		base.Size = new Size(473, 376);
		base.Load += this.Buff_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x06001D13 RID: 7443 RVA: 0x00015691 File Offset: 0x00013891
	[CompilerGenerated]
	private void method_1(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Buff.Class248(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x06001D14 RID: 7444 RVA: 0x000D7104 File Offset: 0x000D5304
	[CompilerGenerated]
	private void method_2(Class159 class159_0)
	{
		if (class159_0.Class432_0.String_0 == Class426.smethod_51(base.Tag.ToString().Replace("Buff - ", "")))
		{
			class159_0.String_22 = this.txtLst.Text;
		}
	}

	// Token: 0x06001D15 RID: 7445 RVA: 0x00015691 File Offset: 0x00013891
	[CompilerGenerated]
	private void method_3(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Buff.Class248(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x040011B9 RID: 4537
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040011BA RID: 4538
	private IContainer icontainer_0;

	// Token: 0x040011BB RID: 4539
	private Class85 txtLst;

	// Token: 0x040011BC RID: 4540
	private ComboBox cboPlayer;

	// Token: 0x040011BD RID: 4541
	private SplitContainer splitContainer1;

	// Token: 0x040011BE RID: 4542
	private ListViewEx listViewName;

	// Token: 0x040011BF RID: 4543
	private ColumnHeader columnHeader_0;

	// Token: 0x040011C0 RID: 4544
	private Class85 txtSearch;

	// Token: 0x040011C1 RID: 4545
	private Button button1;

	// Token: 0x0200021C RID: 540
	private class Class248
	{
		// Token: 0x170006AB RID: 1707
		// (get) Token: 0x06001D16 RID: 7446 RVA: 0x000156C9 File Offset: 0x000138C9
		// (set) Token: 0x06001D17 RID: 7447 RVA: 0x000156D1 File Offset: 0x000138D1
		public string String_0 { get; private set; }

		// Token: 0x170006AC RID: 1708
		// (get) Token: 0x06001D18 RID: 7448 RVA: 0x000156DA File Offset: 0x000138DA
		// (set) Token: 0x06001D19 RID: 7449 RVA: 0x000156E2 File Offset: 0x000138E2
		public string String_1 { get; private set; }

		// Token: 0x06001D1A RID: 7450 RVA: 0x000156EB File Offset: 0x000138EB
		public Class248(string string_2, string string_3)
		{
			this.String_0 = string_2;
			this.String_1 = string_3;
		}

		// Token: 0x06001D1B RID: 7451 RVA: 0x00015701 File Offset: 0x00013901
		public virtual string ToString()
		{
			return this.String_1;
		}

		// Token: 0x040011C2 RID: 4546
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040011C3 RID: 4547
		[CompilerGenerated]
		private string string_1;
	}

	// Token: 0x0200021D RID: 541
	[CompilerGenerated]
	[Serializable]
	private sealed class Class249
	{
		// Token: 0x06001D1E RID: 7454 RVA: 0x00015715 File Offset: 0x00013915
		internal Class159 method_0(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return keyValuePair_0.Value;
		}

		// Token: 0x040011C4 RID: 4548
		public static readonly Buff.Class249 <>9 = new Buff.Class249();

		// Token: 0x040011C5 RID: 4549
		public static Func<KeyValuePair<int, Class159>, Class159> <>9__4_0;
	}
}
