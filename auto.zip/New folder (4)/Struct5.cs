﻿using System;

// Token: 0x020002D0 RID: 720
internal struct Struct5
{
	// Token: 0x04001BDA RID: 7130
	public uint uint_0;

	// Token: 0x04001BDB RID: 7131
	public uint uint_1;
}
