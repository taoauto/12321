﻿using System;
using System.Collections.Specialized;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x0200007E RID: 126
internal class Class63 : Class62
{
	// Token: 0x060005A2 RID: 1442 RVA: 0x0000698D File Offset: 0x00004B8D
	private Class63(AuthenticationSchemes authenticationSchemes_1, NameValueCollection nameValueCollection_1) : base(authenticationSchemes_1, nameValueCollection_1)
	{
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00033314 File Offset: 0x00031514
	internal Class63(AuthenticationSchemes authenticationSchemes_1, string string_0) : base(authenticationSchemes_1, new NameValueCollection())
	{
		this.nameValueCollection_0["realm"] = string_0;
		if (authenticationSchemes_1 == AuthenticationSchemes.Digest)
		{
			this.nameValueCollection_0["nonce"] = Class62.smethod_0();
			this.nameValueCollection_0["algorithm"] = "MD5";
			this.nameValueCollection_0["qop"] = "auth";
		}
	}

	// Token: 0x17000170 RID: 368
	// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00006997 File Offset: 0x00004B97
	public string String_5
	{
		get
		{
			return this.nameValueCollection_0["domain"];
		}
	}

	// Token: 0x17000171 RID: 369
	// (get) Token: 0x060005A5 RID: 1445 RVA: 0x000069A9 File Offset: 0x00004BA9
	public string String_6
	{
		get
		{
			return this.nameValueCollection_0["stale"];
		}
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x000069BB File Offset: 0x00004BBB
	internal static Class63 smethod_2(string string_0)
	{
		return new Class63(AuthenticationSchemes.Basic, string_0);
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x000069C4 File Offset: 0x00004BC4
	internal static Class63 smethod_3(string string_0)
	{
		return new Class63(AuthenticationSchemes.Digest, string_0);
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x00033384 File Offset: 0x00031584
	internal static Class63 smethod_4(string string_0)
	{
		string[] array = string_0.Split(new char[]
		{
			' '
		}, 2);
		if (array.Length != 2)
		{
			return null;
		}
		string a = array[0].ToLower();
		if (a == "basic")
		{
			return new Class63(AuthenticationSchemes.Basic, Class62.smethod_1(array[1]));
		}
		if (!(a == "digest"))
		{
			return null;
		}
		return new Class63(AuthenticationSchemes.Digest, Class62.smethod_1(array[1]));
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x000069CD File Offset: 0x00004BCD
	internal override string \u202E\u200F\u202D\u206F\u206C\u200B\u200F\u202C\u200F\u200D\u200F\u206F\u202C\u200C\u202A\u202D\u206F\u206A\u200E\u200B\u200B\u200E\u200E\u206C\u200D\u202E\u206A\u202A\u206A\u200E\u206F\u206E\u200E\u200B\u202A\u202E\u206B\u200D\u202E\u202C\u202E()
	{
		return string.Format("Basic realm=\"{0}\"", this.nameValueCollection_0["realm"]);
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x000333F0 File Offset: 0x000315F0
	internal override string \u206D\u206A\u200E\u202B\u200B\u202A\u206E\u200C\u206E\u202C\u206F\u202C\u206C\u206D\u202C\u206F\u206E\u206D\u200B\u200E\u202D\u202D\u206D\u200C\u200F\u206C\u202D\u206F\u206D\u200F\u206C\u200B\u202E\u200D\u206B\u206B\u200E\u206C\u200B\u206F\u202E()
	{
		StringBuilder stringBuilder = new StringBuilder(128);
		string text = this.nameValueCollection_0["domain"];
		if (text != null)
		{
			stringBuilder.AppendFormat("Digest realm=\"{0}\", domain=\"{1}\", nonce=\"{2}\"", this.nameValueCollection_0["realm"], text, this.nameValueCollection_0["nonce"]);
		}
		else
		{
			stringBuilder.AppendFormat("Digest realm=\"{0}\", nonce=\"{1}\"", this.nameValueCollection_0["realm"], this.nameValueCollection_0["nonce"]);
		}
		string text2 = this.nameValueCollection_0["opaque"];
		if (text2 != null)
		{
			stringBuilder.AppendFormat(", opaque=\"{0}\"", text2);
		}
		string text3 = this.nameValueCollection_0["stale"];
		if (text3 != null)
		{
			stringBuilder.AppendFormat(", stale={0}", text3);
		}
		string text4 = this.nameValueCollection_0["algorithm"];
		if (text4 != null)
		{
			stringBuilder.AppendFormat(", algorithm={0}", text4);
		}
		string text5 = this.nameValueCollection_0["qop"];
		if (text5 != null)
		{
			stringBuilder.AppendFormat(", qop=\"{0}\"", text5);
		}
		return stringBuilder.ToString();
	}
}
