﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;

// Token: 0x02000122 RID: 290
public class GClass88 : GClass87
{
	// Token: 0x170003D4 RID: 980
	// (get) Token: 0x06000EBB RID: 3771 RVA: 0x0000C7B4 File Offset: 0x0000A9B4
	// (set) Token: 0x06000EBC RID: 3772 RVA: 0x0000C7BC File Offset: 0x0000A9BC
	public Brush Brush_0 { get; set; }

	// Token: 0x170003D5 RID: 981
	// (get) Token: 0x06000EBD RID: 3773 RVA: 0x0000C7C5 File Offset: 0x0000A9C5
	// (set) Token: 0x06000EBE RID: 3774 RVA: 0x0000C7CD File Offset: 0x0000A9CD
	public Brush Brush_1 { get; set; }

	// Token: 0x170003D6 RID: 982
	// (get) Token: 0x06000EBF RID: 3775 RVA: 0x0000C7D6 File Offset: 0x0000A9D6
	// (set) Token: 0x06000EC0 RID: 3776 RVA: 0x0000C7DE File Offset: 0x0000A9DE
	public FontStyle FontStyle_0 { get; set; }

	// Token: 0x06000EC1 RID: 3777 RVA: 0x0000C7E7 File Offset: 0x0000A9E7
	public GClass88(Brush brush_2, Brush brush_3, FontStyle fontStyle_1)
	{
		this.Brush_0 = brush_2;
		this.Brush_1 = brush_3;
		this.FontStyle_0 = fontStyle_1;
		this.stringFormat_0 = new StringFormat(StringFormatFlags.MeasureTrailingSpaces);
	}

	// Token: 0x06000EC2 RID: 3778 RVA: 0x00055B38 File Offset: 0x00053D38
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		if (this.Brush_1 != null)
		{
			graphics_0.FillRectangle(this.Brush_1, point_0.X, point_0.Y, (gclass86_0.GStruct2_1.int_0 - gclass86_0.GStruct2_0.int_0) * gclass86_0.fastColoredTextBox_0.Int32_4, gclass86_0.fastColoredTextBox_0.Int32_2);
		}
		using (Font font = new Font(gclass86_0.fastColoredTextBox_0.Font, this.FontStyle_0))
		{
			GClass81 gclass = gclass86_0.fastColoredTextBox_0[gclass86_0.GStruct2_0.int_1];
			float num = (float)gclass86_0.fastColoredTextBox_0.Int32_4;
			float num2 = (float)(point_0.Y + gclass86_0.fastColoredTextBox_0.Int32_3 / 2);
			float num3 = (float)(point_0.X - gclass86_0.fastColoredTextBox_0.Int32_4 / 3);
			if (this.Brush_0 == null)
			{
				this.Brush_0 = new SolidBrush(gclass86_0.fastColoredTextBox_0.ForeColor);
			}
			if (gclass86_0.fastColoredTextBox_0.Boolean_25)
			{
				for (int i = gclass86_0.GStruct2_0.int_0; i < gclass86_0.GStruct2_1.int_0; i++)
				{
					SizeF sizeF = FastColoredTextBox.smethod_1(font, gclass[i].char_0);
					GraphicsState gstate = graphics_0.Save();
					float num4 = (sizeF.Width > (float)(gclass86_0.fastColoredTextBox_0.Int32_4 + 1)) ? ((float)gclass86_0.fastColoredTextBox_0.Int32_4 / sizeF.Width) : 1f;
					graphics_0.TranslateTransform(num3, num2 + (1f - num4) * (float)gclass86_0.fastColoredTextBox_0.Int32_2 / 2f);
					graphics_0.ScaleTransform(num4, (float)Math.Sqrt((double)num4));
					GStruct0 gstruct = gclass[i];
					graphics_0.DrawString(gstruct.char_0.ToString(), font, this.Brush_0, 0f, 0f, this.stringFormat_0);
					graphics_0.Restore(gstate);
					num3 += num;
				}
			}
			else
			{
				for (int j = gclass86_0.GStruct2_0.int_0; j < gclass86_0.GStruct2_1.int_0; j++)
				{
					GStruct0 gstruct = gclass[j];
					graphics_0.DrawString(gstruct.char_0.ToString(), font, this.Brush_0, num3, num2, this.stringFormat_0);
					num3 += num;
				}
			}
		}
	}

	// Token: 0x06000EC3 RID: 3779 RVA: 0x00055DA0 File Offset: 0x00053FA0
	public override string \u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E()
	{
		string text = "";
		if (this.Brush_1 is SolidBrush)
		{
			string text2 = GClass72.smethod_0((this.Brush_1 as SolidBrush).Color);
			if (text2 != "")
			{
				text = text + "background-color:" + text2 + ";";
			}
		}
		if (this.Brush_0 is SolidBrush)
		{
			string text3 = GClass72.smethod_0((this.Brush_0 as SolidBrush).Color);
			if (text3 != "")
			{
				text = text + "color:" + text3 + ";";
			}
		}
		if ((this.FontStyle_0 & FontStyle.Bold) != FontStyle.Regular)
		{
			text += "font-weight:bold;";
		}
		if ((this.FontStyle_0 & FontStyle.Italic) != FontStyle.Regular)
		{
			text += "font-style:oblique;";
		}
		if ((this.FontStyle_0 & FontStyle.Strikeout) != FontStyle.Regular)
		{
			text += "text-decoration:line-through;";
		}
		if ((this.FontStyle_0 & FontStyle.Underline) != FontStyle.Regular)
		{
			text += "text-decoration:underline;";
		}
		return text;
	}

	// Token: 0x06000EC4 RID: 3780 RVA: 0x00055E90 File Offset: 0x00054090
	public override GClass74 \u202E\u206A\u206D\u200D\u206D\u206D\u200E\u200E\u202A\u200D\u200E\u200C\u202E\u200D\u202A\u200B\u202E\u206E\u200D\u200B\u200B\u206D\u200B\u206A\u206D\u202C\u202B\u200E\u202D\u206A\u202C\u206C\u202B\u200B\u200C\u206A\u202C\u206E\u202E\u206D\u202E()
	{
		GClass74 gclass = new GClass74();
		if (this.Brush_1 is SolidBrush)
		{
			gclass.Color_1 = (this.Brush_1 as SolidBrush).Color;
		}
		if (this.Brush_0 is SolidBrush)
		{
			gclass.Color_0 = (this.Brush_0 as SolidBrush).Color;
		}
		if ((this.FontStyle_0 & FontStyle.Bold) != FontStyle.Regular)
		{
			GClass74 gclass2 = gclass;
			gclass2.String_0 += "\\b";
		}
		if ((this.FontStyle_0 & FontStyle.Italic) != FontStyle.Regular)
		{
			GClass74 gclass3 = gclass;
			gclass3.String_0 += "\\i";
		}
		if ((this.FontStyle_0 & FontStyle.Strikeout) != FontStyle.Regular)
		{
			GClass74 gclass4 = gclass;
			gclass4.String_0 += "\\strike";
		}
		if ((this.FontStyle_0 & FontStyle.Underline) != FontStyle.Regular)
		{
			GClass74 gclass5 = gclass;
			gclass5.String_0 += "\\ul";
		}
		return gclass;
	}

	// Token: 0x0400075E RID: 1886
	[CompilerGenerated]
	private Brush brush_0;

	// Token: 0x0400075F RID: 1887
	[CompilerGenerated]
	private Brush brush_1;

	// Token: 0x04000760 RID: 1888
	[CompilerGenerated]
	private FontStyle fontStyle_0;

	// Token: 0x04000761 RID: 1889
	public StringFormat stringFormat_0;
}
