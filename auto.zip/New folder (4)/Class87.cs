﻿using System;
using System.IO.Pipes;
using System.Text;

// Token: 0x020000B7 RID: 183
internal class Class87
{
	// Token: 0x060008C2 RID: 2242 RVA: 0x0003CF14 File Offset: 0x0003B114
	public void method_0(string string_0, string string_1, int int_0 = 1000)
	{
		try
		{
			NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", string_1, PipeDirection.Out, PipeOptions.Asynchronous);
			namedPipeClientStream.Connect(int_0);
			byte[] bytes = Encoding.UTF8.GetBytes(string_0);
			namedPipeClientStream.BeginWrite(bytes, 0, bytes.Length, new AsyncCallback(this.method_1), namedPipeClientStream);
		}
		catch (TimeoutException)
		{
		}
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x0003CF74 File Offset: 0x0003B174
	private void method_1(IAsyncResult iasyncResult_0)
	{
		try
		{
			NamedPipeClientStream namedPipeClientStream = (NamedPipeClientStream)iasyncResult_0.AsyncState;
			namedPipeClientStream.EndWrite(iasyncResult_0);
			namedPipeClientStream.Flush();
			namedPipeClientStream.Close();
			namedPipeClientStream.Dispose();
		}
		catch (Exception)
		{
		}
	}
}
