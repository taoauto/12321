﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

// Token: 0x020002FD RID: 765
internal class Control1 : TabControl
{
	// Token: 0x06002BD8 RID: 11224 RVA: 0x000200B9 File Offset: 0x0001E2B9
	protected virtual void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		this.method_0();
	}

	// Token: 0x06002BD9 RID: 11225 RVA: 0x000200C8 File Offset: 0x0001E2C8
	public Control1()
	{
		this.TabAlignment_0 = TabAlignment.Bottom;
		this.Boolean_0 = true;
		this.class420_0 = new Control1.Class420(this);
	}

	// Token: 0x06002BDA RID: 11226 RVA: 0x000200FC File Offset: 0x0001E2FC
	protected virtual void Dispose(bool disposing)
	{
		if (this.intptr_0 != IntPtr.Zero)
		{
			Class419.DeleteObject(this.intptr_0);
			this.intptr_0 = IntPtr.Zero;
		}
		this.class420_0.ReleaseHandle();
		base.Dispose(disposing);
	}

	// Token: 0x170009EA RID: 2538
	// (get) Token: 0x06002BDB RID: 11227 RVA: 0x00020139 File Offset: 0x0001E339
	// (set) Token: 0x06002BDC RID: 11228 RVA: 0x00020141 File Offset: 0x0001E341
	[Browsable(true)]
	[DefaultValue(TabAlignment.Bottom)]
	public TabAlignment TabAlignment_0
	{
		get
		{
			return base.Alignment;
		}
		set
		{
			if (value <= TabAlignment.Bottom)
			{
				base.Alignment = value;
			}
		}
	}

	// Token: 0x170009EB RID: 2539
	// (get) Token: 0x06002BDD RID: 11229 RVA: 0x0002014E File Offset: 0x0001E34E
	// (set) Token: 0x06002BDE RID: 11230 RVA: 0x00020156 File Offset: 0x0001E356
	[Browsable(true)]
	[DefaultValue(true)]
	public bool Boolean_0
	{
		get
		{
			return base.HotTrack;
		}
		set
		{
			base.HotTrack = value;
		}
	}

	// Token: 0x170009EC RID: 2540
	// (get) Token: 0x06002BDF RID: 11231 RVA: 0x0002015F File Offset: 0x0001E35F
	// (set) Token: 0x06002BE0 RID: 11232 RVA: 0x00020167 File Offset: 0x0001E367
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public TabAppearance TabAppearance_0
	{
		get
		{
			return base.Appearance;
		}
		set
		{
			if (value == TabAppearance.Normal)
			{
				base.Appearance = value;
			}
		}
	}

	// Token: 0x170009ED RID: 2541
	// (get) Token: 0x06002BE1 RID: 11233 RVA: 0x00020173 File Offset: 0x0001E373
	// (set) Token: 0x06002BE2 RID: 11234 RVA: 0x0002017B File Offset: 0x0001E37B
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public TabDrawMode TabDrawMode_0
	{
		get
		{
			return base.DrawMode;
		}
		set
		{
			if (value == TabDrawMode.Normal)
			{
				base.DrawMode = value;
			}
		}
	}

	// Token: 0x06002BE3 RID: 11235 RVA: 0x00126CA0 File Offset: 0x00124EA0
	private void method_0()
	{
		this.bool_0 = (Application.RenderWithVisualStyles && TabRenderer.IsSupported);
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque, this.bool_0);
		base.UpdateStyles();
		if (this.bool_0)
		{
			if (this.intptr_0 == IntPtr.Zero)
			{
				this.intptr_0 = this.Font.ToHfont();
			}
			Class419.SendMessageW(base.Handle, 48U, this.intptr_0, (IntPtr)1);
			return;
		}
		Class419.SendMessageW(base.Handle, 48U, this.Font.ToHfont(), (IntPtr)1);
		if (this.intptr_0 != IntPtr.Zero)
		{
			Class419.DeleteObject(this.intptr_0);
			this.intptr_0 = IntPtr.Zero;
		}
	}

	// Token: 0x06002BE4 RID: 11236 RVA: 0x00126D64 File Offset: 0x00124F64
	protected virtual void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		if (this.bool_0)
		{
			if (this.intptr_0 != IntPtr.Zero)
			{
				Class419.DeleteObject(this.intptr_0);
			}
			this.intptr_0 = this.Font.ToHfont();
			Class419.SendMessageW(base.Handle, 48U, this.intptr_0, (IntPtr)1);
		}
	}

	// Token: 0x06002BE5 RID: 11237 RVA: 0x00126DCC File Offset: 0x00124FCC
	protected virtual void WndProc(ref Message m)
	{
		if (m.Msg == 794)
		{
			this.method_0();
		}
		else if (m.Msg == 528 && (m.WParam.ToInt32() & 65535) == 1)
		{
			StringBuilder stringBuilder = new StringBuilder(16);
			if (Class419.RealGetWindowClassW(m.LParam, stringBuilder, 16U) > 0U && stringBuilder.ToString() == "msctls_updown32")
			{
				this.class420_0.ReleaseHandle();
				this.class420_0.AssignHandle(m.LParam);
			}
		}
		base.WndProc(ref m);
	}

	// Token: 0x06002BE6 RID: 11238 RVA: 0x00126E60 File Offset: 0x00125060
	private void method_1(Graphics graphics_0, Rectangle rectangle_0)
	{
		if (!base.Visible)
		{
			return;
		}
		int selectedIndex = base.SelectedIndex;
		Rectangle rectangle_ = (selectedIndex != -1) ? base.GetTabRect(selectedIndex) : Rectangle.Empty;
		Rectangle clientRectangle = base.ClientRectangle;
		TabAlignment tabAlignment_ = this.TabAlignment_0;
		if (tabAlignment_ != TabAlignment.Top)
		{
			if (tabAlignment_ == TabAlignment.Bottom)
			{
				clientRectangle.Height -= rectangle_.Height * base.RowCount + 1;
			}
		}
		else
		{
			int num = rectangle_.Height * base.RowCount + 2;
			clientRectangle.Y += num;
			clientRectangle.Height -= num;
		}
		if (clientRectangle.IntersectsWith(rectangle_0))
		{
			TabRenderer.DrawTabPage(graphics_0, clientRectangle);
		}
		int tabCount = base.TabCount;
		if (tabCount == 0)
		{
			return;
		}
		this.int_0 = this.method_4();
		VisualStyleRenderer visualStyleRenderer = new VisualStyleRenderer(VisualStyleElement.Tab.TabItem.Normal);
		for (int i = 0; i < tabCount; i++)
		{
			if (i != selectedIndex)
			{
				Rectangle tabRect = base.GetTabRect(i);
				if (tabRect.Right >= 3 && tabRect.IntersectsWith(rectangle_0))
				{
					TabItemState state = (i == this.int_0) ? TabItemState.Hot : TabItemState.Normal;
					visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, (int)state);
					this.method_2(graphics_0, i, tabRect, visualStyleRenderer);
				}
			}
		}
		rectangle_.Inflate(2, 2);
		if (selectedIndex != -1 && rectangle_.IntersectsWith(rectangle_0))
		{
			visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, 3);
			this.method_2(graphics_0, selectedIndex, rectangle_, visualStyleRenderer);
		}
	}

	// Token: 0x06002BE7 RID: 11239 RVA: 0x00126FD0 File Offset: 0x001251D0
	private void method_2(Graphics graphics_0, int int_1, Rectangle rectangle_0, VisualStyleRenderer visualStyleRenderer_0)
	{
		if (this.class420_0.Int32_0 > 0 && rectangle_0.X >= this.class420_0.Int32_0)
		{
			return;
		}
		bool flag = visualStyleRenderer_0.State == 3;
		using (Class418 @class = new Class418(graphics_0, rectangle_0.Width, rectangle_0.Height))
		{
			Rectangle bounds = new Rectangle(0, 0, rectangle_0.Width, rectangle_0.Height);
			visualStyleRenderer_0.DrawBackground(@class.Graphics_0, bounds);
			if (flag && rectangle_0.X == 0)
			{
				int num = @class.Int32_1 - 1;
				@class.method_2(0, num, @class.method_1(0, num - 1));
			}
			if (this.TabAlignment_0 == TabAlignment.Bottom)
			{
				@class.method_0();
			}
			TabPage tabPage = base.TabPages[int_1];
			Image image = this.method_3(tabPage.ImageIndex, tabPage.ImageKey);
			if (image != null)
			{
				Point point = new Point(flag ? 8 : 6, 2);
				int num2 = point.X + image.Width;
				if (this.TabAlignment_0 == TabAlignment.Bottom)
				{
					point.Y = bounds.Bottom - image.Height - (flag ? 4 : 2);
				}
				if (this.RightToLeftLayout)
				{
					point.X = bounds.Right - num2;
				}
				@class.Graphics_0.DrawImageUnscaled(image, point);
				bounds.X += num2;
				bounds.Width -= num2;
			}
			TextRenderer.DrawText(@class.Graphics_0, tabPage.Text, this.Font, bounds, visualStyleRenderer_0.GetColor(ColorProperty.TextColor), TextFormatFlags.HorizontalCenter | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter);
			if (this.class420_0.Int32_0 > 0 && this.class420_0.Int32_0 >= rectangle_0.X && this.class420_0.Int32_0 < rectangle_0.Right)
			{
				rectangle_0.Width -= rectangle_0.Right - this.class420_0.Int32_0;
			}
			@class.method_3(graphics_0, rectangle_0);
		}
	}

	// Token: 0x06002BE8 RID: 11240 RVA: 0x00020187 File Offset: 0x0001E387
	private Image method_3(int int_1, string string_0)
	{
		if (base.ImageList == null)
		{
			return null;
		}
		if (int_1 > -1)
		{
			return base.ImageList.Images[int_1];
		}
		if (string_0.Length > 0)
		{
			return base.ImageList.Images[string_0];
		}
		return null;
	}

	// Token: 0x06002BE9 RID: 11241 RVA: 0x001271E4 File Offset: 0x001253E4
	protected virtual void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Point location = base.Location;
		e.Graphics.TranslateTransform((float)(-(float)location.X), (float)(-(float)location.Y));
		base.InvokePaintBackground(base.Parent, e);
		e.Graphics.TranslateTransform((float)location.X, (float)location.Y);
		this.method_1(e.Graphics, e.ClipRectangle);
	}

	// Token: 0x06002BEA RID: 11242 RVA: 0x00127258 File Offset: 0x00125458
	private int method_4()
	{
		Class419.Struct8 @struct = default(Class419.Struct8);
		Point point = base.PointToClient(Control.MousePosition);
		@struct.struct7_0.int_0 = point.X;
		@struct.struct7_0.int_1 = point.Y;
		GCHandle gchandle = GCHandle.Alloc(@struct, GCHandleType.Pinned);
		int result = (int)Class419.SendMessageW(base.Handle, 4877U, IntPtr.Zero, gchandle.AddrOfPinnedObject());
		gchandle.Free();
		return result;
	}

	// Token: 0x04001D33 RID: 7475
	private bool bool_0;

	// Token: 0x04001D34 RID: 7476
	private IntPtr intptr_0 = IntPtr.Zero;

	// Token: 0x04001D35 RID: 7477
	private int int_0 = -1;

	// Token: 0x04001D36 RID: 7478
	private Control1.Class420 class420_0;

	// Token: 0x020002FE RID: 766
	[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
	private class Class420 : NativeWindow
	{
		// Token: 0x06002BEB RID: 11243 RVA: 0x000201C5 File Offset: 0x0001E3C5
		public Class420(Control1 control1_1)
		{
			this.control1_0 = control1_1;
		}

		// Token: 0x170009EE RID: 2542
		// (get) Token: 0x06002BEC RID: 11244 RVA: 0x000201D4 File Offset: 0x0001E3D4
		public int Int32_0
		{
			get
			{
				return this.int_0;
			}
		}

		// Token: 0x06002BED RID: 11245 RVA: 0x001272D4 File Offset: 0x001254D4
		protected virtual void WndProc(ref Message m)
		{
			if (m.Msg != 2)
			{
				if (m.Msg != 130)
				{
					if (m.Msg == 70)
					{
						Class419.Struct9 @struct = (Class419.Struct9)m.GetLParam(typeof(Class419.Struct9));
						this.int_0 = @struct.int_0;
						goto IL_19A;
					}
					if (m.Msg == 512 && this.control1_0.int_0 > 0 && this.control1_0.int_0 != this.control1_0.SelectedIndex)
					{
						using (Graphics graphics = Graphics.FromHwnd(this.control1_0.Handle))
						{
							VisualStyleRenderer visualStyleRenderer = new VisualStyleRenderer(VisualStyleElement.Tab.TabItem.Normal);
							this.control1_0.method_2(graphics, this.control1_0.int_0, this.control1_0.GetTabRect(this.control1_0.int_0), visualStyleRenderer);
							if (this.control1_0.int_0 - this.control1_0.SelectedIndex == 1)
							{
								Rectangle tabRect = this.control1_0.GetTabRect(this.control1_0.SelectedIndex);
								tabRect.Inflate(2, 2);
								visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, 3);
								this.control1_0.method_2(graphics, this.control1_0.SelectedIndex, tabRect, visualStyleRenderer);
							}
							goto IL_19A;
						}
					}
					if (m.Msg == 513)
					{
						Rectangle tabRect2 = this.control1_0.GetTabRect(this.control1_0.SelectedIndex);
						tabRect2.X = 0;
						tabRect2.Width = 2;
						tabRect2.Inflate(0, 2);
						this.control1_0.Invalidate(tabRect2);
						goto IL_19A;
					}
					goto IL_19A;
				}
			}
			this.ReleaseHandle();
			IL_19A:
			base.WndProc(ref m);
		}

		// Token: 0x04001D37 RID: 7479
		private int int_0;

		// Token: 0x04001D38 RID: 7480
		private Control1 control1_0;
	}
}
