﻿using System;
using System.IO.Pipes;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

// Token: 0x020000B6 RID: 182
internal class Class86
{
	// Token: 0x1400000F RID: 15
	// (add) Token: 0x060008BD RID: 2237 RVA: 0x0003CDBC File Offset: 0x0003AFBC
	// (remove) Token: 0x060008BE RID: 2238 RVA: 0x0003CDF4 File Offset: 0x0003AFF4
	public event GDelegate0 Event_0
	{
		[CompilerGenerated]
		add
		{
			GDelegate0 gdelegate = this.gdelegate0_0;
			GDelegate0 gdelegate2;
			do
			{
				gdelegate2 = gdelegate;
				GDelegate0 value2 = (GDelegate0)Delegate.Combine(gdelegate2, value);
				gdelegate = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, value2, gdelegate2);
			}
			while (gdelegate != gdelegate2);
		}
		[CompilerGenerated]
		remove
		{
			GDelegate0 gdelegate = this.gdelegate0_0;
			GDelegate0 gdelegate2;
			do
			{
				gdelegate2 = gdelegate;
				GDelegate0 value2 = (GDelegate0)Delegate.Remove(gdelegate2, value);
				gdelegate = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, value2, gdelegate2);
			}
			while (gdelegate != gdelegate2);
		}
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x0003CE2C File Offset: 0x0003B02C
	public void method_0(string string_1)
	{
		try
		{
			this.string_0 = string_1;
			NamedPipeServerStream namedPipeServerStream = new NamedPipeServerStream(string_1, PipeDirection.In, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
			namedPipeServerStream.BeginWaitForConnection(new AsyncCallback(this.method_1), namedPipeServerStream);
		}
		catch (Exception)
		{
		}
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x0003CE78 File Offset: 0x0003B078
	private void method_1(IAsyncResult iasyncResult_0)
	{
		try
		{
			NamedPipeServerStream namedPipeServerStream = (NamedPipeServerStream)iasyncResult_0.AsyncState;
			namedPipeServerStream.EndWaitForConnection(iasyncResult_0);
			byte[] array = new byte[255];
			namedPipeServerStream.Read(array, 0, 255);
			string @string = Encoding.UTF8.GetString(array, 0, array.Length);
			this.gdelegate0_0(@string);
			namedPipeServerStream.Close();
			namedPipeServerStream = new NamedPipeServerStream(this.string_0, PipeDirection.In, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
			namedPipeServerStream.BeginWaitForConnection(new AsyncCallback(this.method_1), namedPipeServerStream);
		}
		catch
		{
		}
	}

	// Token: 0x0400047F RID: 1151
	[CompilerGenerated]
	private GDelegate0 gdelegate0_0;

	// Token: 0x04000480 RID: 1152
	private string string_0;
}
