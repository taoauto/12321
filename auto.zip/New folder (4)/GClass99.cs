﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

// Token: 0x0200012F RID: 303
public class GClass99 : IDisposable, IEnumerable, IList<GClass81>, ICollection<GClass81>, IEnumerable<GClass81>
{
	// Token: 0x170003F6 RID: 1014
	// (get) Token: 0x06000F3F RID: 3903 RVA: 0x0000CB50 File Offset: 0x0000AD50
	// (set) Token: 0x06000F40 RID: 3904 RVA: 0x0000CB58 File Offset: 0x0000AD58
	public GClass59 GClass59_0 { get; set; }

	// Token: 0x14000031 RID: 49
	// (add) Token: 0x06000F41 RID: 3905 RVA: 0x00058AEC File Offset: 0x00056CEC
	// (remove) Token: 0x06000F42 RID: 3906 RVA: 0x00058B24 File Offset: 0x00056D24
	public event EventHandler<GEventArgs9> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs9> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs9> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs9> value2 = (EventHandler<GEventArgs9>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs9>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs9> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs9> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs9> value2 = (EventHandler<GEventArgs9>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs9>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000032 RID: 50
	// (add) Token: 0x06000F43 RID: 3907 RVA: 0x00058B5C File Offset: 0x00056D5C
	// (remove) Token: 0x06000F44 RID: 3908 RVA: 0x00058B94 File Offset: 0x00056D94
	public event EventHandler<GEventArgs10> Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs10> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs10> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs10> value2 = (EventHandler<GEventArgs10>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs10>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs10> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs10> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs10> value2 = (EventHandler<GEventArgs10>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs10>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000033 RID: 51
	// (add) Token: 0x06000F45 RID: 3909 RVA: 0x00058BCC File Offset: 0x00056DCC
	// (remove) Token: 0x06000F46 RID: 3910 RVA: 0x00058C04 File Offset: 0x00056E04
	public event EventHandler<GClass99.GEventArgs20> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_2;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_2;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000034 RID: 52
	// (add) Token: 0x06000F47 RID: 3911 RVA: 0x00058C3C File Offset: 0x00056E3C
	// (remove) Token: 0x06000F48 RID: 3912 RVA: 0x00058C74 File Offset: 0x00056E74
	public event EventHandler<GClass99.GEventArgs20> Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_3;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_3;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000035 RID: 53
	// (add) Token: 0x06000F49 RID: 3913 RVA: 0x00058CAC File Offset: 0x00056EAC
	// (remove) Token: 0x06000F4A RID: 3914 RVA: 0x00058CE4 File Offset: 0x00056EE4
	public event EventHandler<GClass99.GEventArgs20> Event_4
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_4;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GClass99.GEventArgs20> eventHandler = this.eventHandler_4;
			EventHandler<GClass99.GEventArgs20> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GClass99.GEventArgs20> value2 = (EventHandler<GClass99.GEventArgs20>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GClass99.GEventArgs20>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000036 RID: 54
	// (add) Token: 0x06000F4B RID: 3915 RVA: 0x00058D1C File Offset: 0x00056F1C
	// (remove) Token: 0x06000F4C RID: 3916 RVA: 0x00058D54 File Offset: 0x00056F54
	public event EventHandler<GEventArgs12> Event_5
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000037 RID: 55
	// (add) Token: 0x06000F4D RID: 3917 RVA: 0x00058D8C File Offset: 0x00056F8C
	// (remove) Token: 0x06000F4E RID: 3918 RVA: 0x00058DC4 File Offset: 0x00056FC4
	public event EventHandler Event_6
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_6;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_6;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x170003F7 RID: 1015
	// (get) Token: 0x06000F4F RID: 3919 RVA: 0x0000CB61 File Offset: 0x0000AD61
	// (set) Token: 0x06000F50 RID: 3920 RVA: 0x0000CB69 File Offset: 0x0000AD69
	public FastColoredTextBox FastColoredTextBox_0
	{
		get
		{
			return this.fastColoredTextBox_0;
		}
		set
		{
			if (this.fastColoredTextBox_0 == value)
			{
				return;
			}
			this.fastColoredTextBox_0 = value;
			this.method_0();
		}
	}

	// Token: 0x06000F51 RID: 3921 RVA: 0x00058DFC File Offset: 0x00056FFC
	public virtual void \u202B\u206A\u206B\u200D\u200E\u200C\u200C\u206C\u200D\u206C\u206D\u202D\u206E\u206C\u200C\u206E\u206D\u200C\u202B\u200B\u200F\u206C\u200E\u206A\u202E\u200F\u206F\u200C\u206B\u206D\u202D\u200E\u206A\u206D\u206F\u206E\u202E\u202D\u206C\u200D\u202E()
	{
		foreach (GClass81 gclass in this.list_0)
		{
			gclass.Boolean_0 = false;
		}
	}

	// Token: 0x06000F52 RID: 3922 RVA: 0x0000CB82 File Offset: 0x0000AD82
	public virtual GClass81 vmethod_0()
	{
		return new GClass81(this.vmethod_5());
	}

	// Token: 0x06000F53 RID: 3923 RVA: 0x0000CB8F File Offset: 0x0000AD8F
	private void method_0()
	{
		if (this.eventHandler_6 != null)
		{
			this.eventHandler_6(this, EventArgs.Empty);
		}
	}

	// Token: 0x170003F8 RID: 1016
	// (get) Token: 0x06000F54 RID: 3924 RVA: 0x0000CBAA File Offset: 0x0000ADAA
	// (set) Token: 0x06000F55 RID: 3925 RVA: 0x0000CBB2 File Offset: 0x0000ADB2
	public GClass88 GClass88_0 { get; set; }

	// Token: 0x06000F56 RID: 3926 RVA: 0x00058E50 File Offset: 0x00057050
	public GClass99(FastColoredTextBox fastColoredTextBox_1)
	{
		this.FastColoredTextBox_0 = fastColoredTextBox_1;
		this.gclass83_0 = new GClass83(this);
		this.GClass59_0 = new GClass59(this);
		if (Enum.GetUnderlyingType(typeof(StyleIndex)) == typeof(uint))
		{
			this.gclass87_0 = new GClass87[32];
		}
		else
		{
			this.gclass87_0 = new GClass87[16];
		}
		this.vmethod_1();
	}

	// Token: 0x06000F57 RID: 3927 RVA: 0x0000CBBB File Offset: 0x0000ADBB
	public virtual void vmethod_1()
	{
		this.GClass88_0 = new GClass88(null, null, FontStyle.Regular);
	}

	// Token: 0x170003F9 RID: 1017
	public virtual GClass81 this[int i]
	{
		get
		{
			return this.list_0[i];
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x06000F5A RID: 3930 RVA: 0x0000CBD9 File Offset: 0x0000ADD9
	public virtual bool vmethod_2(int int_1)
	{
		return this.list_0[int_1] != null;
	}

	// Token: 0x06000F5B RID: 3931 RVA: 0x0000CBEA File Offset: 0x0000ADEA
	public virtual IList<string> vmethod_3()
	{
		return this.gclass83_0;
	}

	// Token: 0x06000F5C RID: 3932 RVA: 0x0000CBF2 File Offset: 0x0000ADF2
	public IEnumerator<GClass81> GetEnumerator()
	{
		return this.list_0.GetEnumerator();
	}

	// Token: 0x06000F5D RID: 3933 RVA: 0x0000CC04 File Offset: 0x0000AE04
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.list_0 as IEnumerator;
	}

	// Token: 0x06000F5E RID: 3934 RVA: 0x0000CC11 File Offset: 0x0000AE11
	public virtual int vmethod_4(GClass81 gclass81_0, IComparer<GClass81> icomparer_0)
	{
		return this.list_0.BinarySearch(gclass81_0, icomparer_0);
	}

	// Token: 0x06000F5F RID: 3935 RVA: 0x00058ED0 File Offset: 0x000570D0
	public virtual int vmethod_5()
	{
		int num = this.int_0;
		this.int_0 = num + 1;
		return num;
	}

	// Token: 0x06000F60 RID: 3936 RVA: 0x0000CC20 File Offset: 0x0000AE20
	public virtual void \u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(int int_1, GClass81 gclass81_0)
	{
		this.list_0.Insert(int_1, gclass81_0);
		this.vmethod_6(int_1);
	}

	// Token: 0x06000F61 RID: 3937 RVA: 0x0000CC36 File Offset: 0x0000AE36
	public virtual void vmethod_6(int int_1)
	{
		this.vmethod_7(int_1, 1);
	}

	// Token: 0x06000F62 RID: 3938 RVA: 0x0000CC40 File Offset: 0x0000AE40
	public virtual void vmethod_7(int int_1, int int_2)
	{
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, new GEventArgs9(int_1, int_2));
		}
	}

	// Token: 0x06000F63 RID: 3939 RVA: 0x0000CC5D File Offset: 0x0000AE5D
	public virtual void vmethod_8(int int_1)
	{
		this.GClass99.\u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(int_1, 1);
	}

	// Token: 0x170003FA RID: 1018
	// (get) Token: 0x06000F64 RID: 3940 RVA: 0x0000CC67 File Offset: 0x0000AE67
	public virtual bool Boolean_0
	{
		get
		{
			return this.eventHandler_1 != null;
		}
	}

	// Token: 0x06000F65 RID: 3941 RVA: 0x00058EF0 File Offset: 0x000570F0
	public virtual void \u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(int int_1, int int_2)
	{
		List<int> list = new List<int>();
		if (int_2 > 0 && this.Boolean_0)
		{
			for (int i = 0; i < int_2; i++)
			{
				list.Add(this[int_1 + i].Int32_0);
			}
		}
		this.list_0.RemoveRange(int_1, int_2);
		this.vmethod_9(int_1, int_2, list);
	}

	// Token: 0x06000F66 RID: 3942 RVA: 0x0000CC72 File Offset: 0x0000AE72
	public virtual void vmethod_9(int int_1, int int_2, List<int> list_1)
	{
		if (int_2 > 0 && this.eventHandler_1 != null)
		{
			this.eventHandler_1(this, new GEventArgs10(int_1, int_2, list_1));
		}
	}

	// Token: 0x06000F67 RID: 3943 RVA: 0x0000CC94 File Offset: 0x0000AE94
	public virtual void vmethod_10(int int_1, int int_2)
	{
		if (this.eventHandler_2 != null)
		{
			this.eventHandler_2(this, new GClass99.GEventArgs20(Math.Min(int_1, int_2), Math.Max(int_1, int_2)));
		}
	}

	// Token: 0x06000F68 RID: 3944 RVA: 0x0000CCBD File Offset: 0x0000AEBD
	public virtual int IndexOf(GClass81 item)
	{
		return this.list_0.IndexOf(item);
	}

	// Token: 0x06000F69 RID: 3945 RVA: 0x0000CCCB File Offset: 0x0000AECB
	public virtual void Insert(int index, GClass81 item)
	{
		this.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(index, item);
	}

	// Token: 0x06000F6A RID: 3946 RVA: 0x0000CCD5 File Offset: 0x0000AED5
	public virtual void RemoveAt(int index)
	{
		this.vmethod_8(index);
	}

	// Token: 0x06000F6B RID: 3947 RVA: 0x0000CCDE File Offset: 0x0000AEDE
	public virtual void Add(GClass81 item)
	{
		this.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(this.Count, item);
	}

	// Token: 0x06000F6C RID: 3948 RVA: 0x0000CCED File Offset: 0x0000AEED
	public virtual void Clear()
	{
		this.GClass99.\u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(0, this.Count);
	}

	// Token: 0x06000F6D RID: 3949 RVA: 0x0000CCFC File Offset: 0x0000AEFC
	public virtual bool Contains(GClass81 item)
	{
		return this.list_0.Contains(item);
	}

	// Token: 0x06000F6E RID: 3950 RVA: 0x0000CD0A File Offset: 0x0000AF0A
	public virtual void CopyTo(GClass81[] array, int arrayIndex)
	{
		this.list_0.CopyTo(array, arrayIndex);
	}

	// Token: 0x170003FB RID: 1019
	// (get) Token: 0x06000F6F RID: 3951 RVA: 0x0000CD19 File Offset: 0x0000AF19
	public virtual int Count
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x170003FC RID: 1020
	// (get) Token: 0x06000F70 RID: 3952 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000F71 RID: 3953 RVA: 0x00058F48 File Offset: 0x00057148
	public virtual bool Remove(GClass81 item)
	{
		int num = this.IndexOf(item);
		if (num >= 0)
		{
			this.vmethod_8(num);
			return true;
		}
		return false;
	}

	// Token: 0x06000F72 RID: 3954 RVA: 0x0000CD26 File Offset: 0x0000AF26
	public virtual void vmethod_11(GClass99.GEventArgs20 geventArgs20_0)
	{
		if (this.eventHandler_3 != null)
		{
			this.eventHandler_3(this, geventArgs20_0);
		}
	}

	// Token: 0x06000F73 RID: 3955 RVA: 0x0000CD3D File Offset: 0x0000AF3D
	public virtual void vmethod_12(GClass99.GEventArgs20 geventArgs20_0)
	{
		if (this.eventHandler_4 != null)
		{
			this.eventHandler_4(this, geventArgs20_0);
		}
	}

	// Token: 0x06000F74 RID: 3956 RVA: 0x00058F6C File Offset: 0x0005716C
	public virtual void vmethod_13()
	{
		string text = null;
		this.vmethod_14(ref text);
	}

	// Token: 0x06000F75 RID: 3957 RVA: 0x00058F84 File Offset: 0x00057184
	public virtual void vmethod_14(ref string string_0)
	{
		if (this.eventHandler_5 != null)
		{
			GEventArgs12 geventArgs = new GEventArgs12
			{
				String_0 = string_0
			};
			this.eventHandler_5(this, geventArgs);
			string_0 = geventArgs.String_0;
			if (geventArgs.Boolean_0)
			{
				string_0 = string.Empty;
			}
		}
	}

	// Token: 0x06000F76 RID: 3958 RVA: 0x0000CD54 File Offset: 0x0000AF54
	public virtual int \u200B\u206A\u206E\u200C\u202B\u202C\u206B\u202C\u202E\u202A\u200E\u200D\u202D\u206F\u206C\u206D\u200C\u206B\u200D\u202C\u202A\u200F\u202B\u206B\u200E\u206E\u200F\u202D\u200F\u200E\u200C\u206A\u206C\u200D\u202E\u206F\u206B\u202D\u206B\u206F\u202E(int int_1)
	{
		return this.list_0[int_1].Count;
	}

	// Token: 0x06000F77 RID: 3959 RVA: 0x0000CD67 File Offset: 0x0000AF67
	public virtual bool \u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(int int_1)
	{
		return !string.IsNullOrEmpty(this.list_0[int_1].String_0);
	}

	// Token: 0x06000F78 RID: 3960 RVA: 0x0000CD82 File Offset: 0x0000AF82
	public virtual bool \u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(int int_1)
	{
		return !string.IsNullOrEmpty(this.list_0[int_1].String_1);
	}

	// Token: 0x06000F79 RID: 3961 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void Dispose()
	{
	}

	// Token: 0x06000F7A RID: 3962 RVA: 0x00058FCC File Offset: 0x000571CC
	public virtual void \u202E\u206E\u202C\u200B\u206C\u200B\u200E\u202B\u206F\u200D\u206D\u206A\u202C\u206F\u206D\u206C\u202C\u200E\u200F\u202E\u202B\u206F\u202D\u202E\u202B\u200F\u206C\u200D\u206E\u202A\u202B\u206E\u200E\u206E\u200C\u206D\u206A\u202B\u206E\u206F\u202E(string string_0, Encoding encoding_0)
	{
		using (StreamWriter streamWriter = new StreamWriter(string_0, false, encoding_0))
		{
			for (int i = 0; i < this.Count - 1; i++)
			{
				streamWriter.WriteLine(this.list_0[i].String_2);
			}
			streamWriter.Write(this.list_0[this.Count - 1].String_2);
		}
	}

	// Token: 0x040007EE RID: 2030
	protected readonly List<GClass81> list_0 = new List<GClass81>();

	// Token: 0x040007EF RID: 2031
	protected GClass83 gclass83_0;

	// Token: 0x040007F0 RID: 2032
	private int int_0;

	// Token: 0x040007F1 RID: 2033
	[CompilerGenerated]
	private GClass59 gclass59_0;

	// Token: 0x040007F2 RID: 2034
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040007F3 RID: 2035
	public readonly GClass87[] gclass87_0;

	// Token: 0x040007F4 RID: 2036
	[CompilerGenerated]
	private EventHandler<GEventArgs9> eventHandler_0;

	// Token: 0x040007F5 RID: 2037
	[CompilerGenerated]
	private EventHandler<GEventArgs10> eventHandler_1;

	// Token: 0x040007F6 RID: 2038
	[CompilerGenerated]
	private EventHandler<GClass99.GEventArgs20> eventHandler_2;

	// Token: 0x040007F7 RID: 2039
	[CompilerGenerated]
	private EventHandler<GClass99.GEventArgs20> eventHandler_3;

	// Token: 0x040007F8 RID: 2040
	[CompilerGenerated]
	private EventHandler<GClass99.GEventArgs20> eventHandler_4;

	// Token: 0x040007F9 RID: 2041
	[CompilerGenerated]
	private EventHandler<GEventArgs12> eventHandler_5;

	// Token: 0x040007FA RID: 2042
	[CompilerGenerated]
	private EventHandler eventHandler_6;

	// Token: 0x040007FB RID: 2043
	[CompilerGenerated]
	private GClass88 gclass88_0;

	// Token: 0x02000130 RID: 304
	public class GEventArgs20 : EventArgs
	{
		// Token: 0x06000F7B RID: 3963 RVA: 0x0000CD9D File Offset: 0x0000AF9D
		public GEventArgs20(int int_2, int int_3)
		{
			this.int_0 = int_2;
			this.int_1 = int_3;
		}

		// Token: 0x040007FC RID: 2044
		public int int_0;

		// Token: 0x040007FD RID: 2045
		public int int_1;
	}
}
