﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020002A5 RID: 677
internal class Class363
{
	// Token: 0x170007A2 RID: 1954
	// (get) Token: 0x060024EC RID: 9452 RVA: 0x0001BE14 File Offset: 0x0001A014
	// (set) Token: 0x060024ED RID: 9453 RVA: 0x0001BE1B File Offset: 0x0001A01B
	public static List<string> List_0 { get; set; } = new List<string>
	{
		"78,176",
		"84,175",
		"88,179",
		"86,185",
		"80,186",
		"76,182"
	};

	// Token: 0x170007A3 RID: 1955
	// (get) Token: 0x060024EE RID: 9454 RVA: 0x0001BE23 File Offset: 0x0001A023
	// (set) Token: 0x060024EF RID: 9455 RVA: 0x0001BE2A File Offset: 0x0001A02A
	public static List<string> List_1 { get; set; } = new List<string>
	{
		"47,110",
		"49,116",
		"52,106",
		"55,118",
		"57,108",
		"59,113"
	};

	// Token: 0x170007A4 RID: 1956
	// (get) Token: 0x060024F0 RID: 9456 RVA: 0x0001BE32 File Offset: 0x0001A032
	// (set) Token: 0x060024F1 RID: 9457 RVA: 0x0001BE39 File Offset: 0x0001A039
	public static List<string> List_2 { get; set; } = new List<string>
	{
		"135,148",
		"135,156",
		"131,157",
		"128,154",
		"131,148",
		"137,152"
	};

	// Token: 0x170007A5 RID: 1957
	// (get) Token: 0x060024F2 RID: 9458 RVA: 0x0001BE41 File Offset: 0x0001A041
	// (set) Token: 0x060024F3 RID: 9459 RVA: 0x0001BE48 File Offset: 0x0001A048
	public static List<string> List_3 { get; set; } = new List<string>
	{
		"130,63",
		"129,69",
		"127,61",
		"123,70",
		"122,62",
		"121,67"
	};

	// Token: 0x170007A6 RID: 1958
	// (get) Token: 0x060024F4 RID: 9460 RVA: 0x0001BE50 File Offset: 0x0001A050
	// (set) Token: 0x060024F5 RID: 9461 RVA: 0x0001BE57 File Offset: 0x0001A057
	public static List<string> List_4 { get; set; } = new List<string>
	{
		"Shenqi_1_9",
		"Shenqi_1_10",
		"Shenqi_1_11",
		"Shenqi_1_12",
		"Shenqi_1_13",
		"Shenqi_1_14",
		"Shenqi_1_15",
		"CircularTaskTool45_14"
	};

	// Token: 0x170007A7 RID: 1959
	// (get) Token: 0x060024F6 RID: 9462 RVA: 0x0001BE5F File Offset: 0x0001A05F
	// (set) Token: 0x060024F7 RID: 9463 RVA: 0x0001BE66 File Offset: 0x0001A066
	public static List<string> List_5 { get; set; } = new List<string>
	{
		"Thương Lang KNT Trảo - Dũng",
		"Thương Lang KNT Trảo - Giảo",
		"Thương Lang KNT Trảo - Thận",
		"Hoàng Tước HTT Trảo - Khiếp",
		"Hoàng Tước HTT Trảo - Giảo",
		"Hoàng Tước HTT Trảo - Thận",
		"Ô Đồn Vọng Nhật Trảo-Trung",
		"Ô Đồn Vọng Nhật Trảo-Thận",
		"Bạch Thố Ẩn LT Trảo - Thận",
		"Thương Lang KNT Khôi - Dũng",
		"Thương Lang KNT Khôi - Giảo",
		"Thương Lang KNT Khôi - Thận",
		"Hoàng Tước HTT Khôi - Khiếp",
		"Hoàng Tước HTT Khôi - Giảo",
		"Hoàng Tước HTT Khôi - Thận",
		"Ô Đồn Vọng Nhật Khôi-Trung",
		"Ô Đồn Vọng Nhật Khôi-Thận",
		"Bạch Thố Ẩn LT Khôi - Thận",
		"Thương Lang KNT Giáp - Dũng",
		"Thương Lang KNT Giáp - Giảo",
		"Thương Lang KNT Giáp - Thận",
		"Hoàng Tước HTT Giáp - Khiếp",
		"Hoàng Tước HTT Giáp - Giảo",
		"Hoàng Tước HTT Giáp - Thận",
		"Ô Đồn Vọng Nhật Giáp-Trung",
		"Ô Đồn Vọng Nhật Giáp-Thận",
		"Bạch Thố Ẩn LT Giáp - Thận",
		"Thương Lang KNT Hoàn - Dũng",
		"Thương Lang KNT Hoàn - Giảo",
		"Thương Lang KNT Hoàn - Thận",
		"Hoàng Tước HTT Hoàn - Khiếp",
		"Hoàng Tước HTT Hoàn - Giảo",
		"Hoàng Tước HTT Hoàn - Thận",
		"Ô Đồn Vọng Nhật Hoàn-Trung",
		"Ô Đồn Vọng Nhật Hoàn-Thận",
		"Bạch Thố Ẩn LT Hoàn - Thận",
		"Thương Lang KNT Sức - Dũng",
		"Thương Lang KNT Sức - Giảo",
		"Thương Lang KNT Sức - Thận",
		"Hoàng Tước HTT Sức - Khiếp",
		"Hoàng Tước HTT Sức - Giảo",
		"Hoàng Tước HTT Sức - Thận",
		"Ô Đồn Vọng Nhật Sức-Trung",
		"Ô Đồn Vọng Nhật Sức-Thận",
		"Bạch Thố Ẩn LT Sức - Thận"
	};

	// Token: 0x040018E1 RID: 6369
	public static Dictionary<string, int> dictionary_0 = new Dictionary<string, int>();

	// Token: 0x040018E2 RID: 6370
	public static Dictionary<int, string> dictionary_1 = new Dictionary<int, string>
	{
		{
			Class365.Int32_85,
			"238,235"
		},
		{
			Class365.Int32_88,
			"70,67"
		},
		{
			Class365.Int32_102,
			"51,48"
		},
		{
			Class365.Int32_41,
			"31,12"
		},
		{
			Class365.Int32_42,
			"107,112"
		},
		{
			Class365.Int32_101,
			"64,21"
		},
		{
			Class365.Int32_82,
			"70,20"
		},
		{
			Class365.Int32_81,
			"86,116"
		},
		{
			Class365.Int32_117,
			"29,104"
		},
		{
			Class365.Int32_64,
			"160,169"
		},
		{
			Class365.Int32_65,
			"173,170"
		},
		{
			Class365.Int32_61,
			"96,142"
		},
		{
			Class365.Int32_59,
			"44,129"
		},
		{
			Class365.Int32_54,
			"96,158"
		},
		{
			Class365.Int32_63,
			"95,148"
		},
		{
			Class365.Int32_60,
			"89,146"
		},
		{
			Class365.Int32_57,
			"95,192"
		},
		{
			Class365.Int32_56,
			"98,159"
		},
		{
			Class365.Int32_55,
			"91,159"
		},
		{
			Class365.Int32_58,
			"96,142"
		},
		{
			Class365.Int32_62,
			"274,178"
		}
	};

	// Token: 0x040018E3 RID: 6371
	public static List<string> list_0 = new List<string>
	{
		"Lục Tinh Thạch (Cấp 3)",
		"Hồng Tinh Thạch (Cấp 3)",
		"Lam Tinh Thạch (Cấp 3)",
		"Hoàng Tinh Thạch (Cấp 3)",
		"Bích Tỷ (Cấp 3)",
		"Nguyệt Quang Thạch (Cấp 3)",
		"Hạo Thạch (Cấp 3)",
		"Hoàng Ngọc (Cấp 3)"
	};

	// Token: 0x040018E4 RID: 6372
	public static List<string> list_1 = new List<string>
	{
		"118,42",
		"126,42",
		"130,47",
		"126,52",
		"118,52",
		"114,47"
	};

	// Token: 0x040018E5 RID: 6373
	public static List<string> list_2 = new List<string>
	{
		"144,55",
		"137,55",
		"142,70",
		"133,61",
		"136,69",
		"147,66"
	};

	// Token: 0x040018E6 RID: 6374
	public static List<string> list_3 = new List<string>
	{
		"44,75",
		"56,75",
		"46,69",
		"54,69",
		"46,81",
		"54,81"
	};

	// Token: 0x040018E7 RID: 6375
	public static List<string> list_4 = new List<string>
	{
		"210,124",
		"207,120",
		"209,115",
		"214,114",
		"217,118",
		"216,123"
	};

	// Token: 0x040018E8 RID: 6376
	[CompilerGenerated]
	private static List<string> list_5;

	// Token: 0x040018E9 RID: 6377
	[CompilerGenerated]
	private static List<string> list_6;

	// Token: 0x040018EA RID: 6378
	[CompilerGenerated]
	private static List<string> list_7;

	// Token: 0x040018EB RID: 6379
	[CompilerGenerated]
	private static List<string> list_8;

	// Token: 0x040018EC RID: 6380
	[CompilerGenerated]
	private static List<string> list_9;

	// Token: 0x040018ED RID: 6381
	[CompilerGenerated]
	private static List<string> list_10;

	// Token: 0x040018EE RID: 6382
	public static HashSet<string> hashSet_0 = new HashSet<string>
	{
		"Lưu Kim Võ Lâm Ấn Đại Lý Sát Tinh",
		"Lưu Kim Võ Lâm Ấn Như Hổ Thiêm Dực",
		"Lưu Kim Võ Lâm Ấn Thần Dũng Võ Hồn",
		"Lưu Kim Võ Lâm Ấn Tiềm Tâm Tu Luyện",
		"Khoa Ngân Võ Lâm Ấn Túc Cầu Thịnh Hội",
		"Khoa Ngân Võ Lâm Ấn Tàng Kinh Các Nguy Cơ",
		"Khoa Ngân Võ Lâm Ấn Phồn Mang Tào Vận",
		"Quả Ngân Võ Lâm Ấn Bang HộiBuôn Bán",
		"Thanh Đồng Ấn-Tương Trợ Sư Môn",
		"Thanh Đồng Ấn-Trừ Ác",
		"Thanh Đồng Ấn-Trừng Hung",
		"Sinh Tài Chi Đạo"
	};

	// Token: 0x040018EF RID: 6383
	public static HashSet<string> hashSet_1 = new HashSet<string>
	{
		"Đại Lý Kỳ Thánh",
		"Tô Châu Kỳ Thánh",
		"Lạc Dương Kỳ Thánh",
		"Hắc Bạch",
		"#{YD_100806_52}",
		"Ván Cờ Sinh Tử",
		"Đánh Lén Môn Phái",
		"#{YD_100806_64}",
		"Giang hồ tà đạo",
		"Tặc Binh Xâm Nhập",
		"#{YD_100806_56}",
		"Ác Tặc Tạo Phản",
		"#{LSHDR_150203_93}",
		"Đầu Sỏ Tam Quan",
		"#{LSHDR_150203_15}",
		"Vào Tam Tài Trận"
	};

	// Token: 0x040018F0 RID: 6384
	public static HashSet<string> hashSet_2 = new HashSet<string>
	{
		"#{ZYRW_120522_66}",
		"Ngộ chân nguyên",
		"#{ZYRW_120522_67}",
		"Chân nguyên hiện thế",
		"#{ZYRW_120522_68}",
		"Tìm kiếm chân nguyên",
		"#{ZYRW_120522_69}",
		"Chân nguyên chi đạo",
		"#{ZYRW_120522_70}",
		"Huyền âm giải chân nguyên"
	};

	// Token: 0x040018F1 RID: 6385
	public static List<string> list_11 = new List<string>
	{
		"Diệt Thủ Vệ",
		"#{MZZBQ_150811_331}",
		"#{MZZBQ_150811_334}",
		"#{MZZBQ_150811_332}",
		"#{MZZBQ_150811_335}",
		"#{MZZBQ_150811_330}",
		"#{MZZBQ_150811_333}"
	};

	// Token: 0x040018F2 RID: 6386
	public static List<string> list_12 = new List<string>
	{
		"Hồi Báo Thiên Sư (1)",
		"Thiên sư kỳ đãi (1)",
		"Thiên sư kỳ đãi (2)",
		"Thiên sư kỳ đãi (3)",
		"Thiên sư kỳ đãi (4)",
		"Thiên sư kỳ đãi (5)",
		"Thiên sư kỳ đãi (6)",
		"Thiên sư kỳ đãi (7)",
		"Thiên sư kỳ đãi (8)",
		"Thiên sư kỳ đãi (9)",
		"Thiên sư kỳ đãi (10)",
		"Hồi Báo Thiên Sư (1)"
	};

	// Token: 0x040018F3 RID: 6387
	public static List<string> list_13 = new List<string>
	{
		"Đèn nhà ai nấy sáng",
		"Áo xanh lỗi lạc hành núi hiểm",
		"Vi Tiếu Chi Lữ",
		"Ác Quán Mãn Doanh",
		"Gặp nhau tại Vạn Kiếp Cốc",
		"Đại chiến Vạn Kiếp Cốc",
		"Đại tiến quân",
		"Hổ khiếu long ngâm"
	};

	// Token: 0x040018F4 RID: 6388
	public static Dictionary<string, string> dictionary_2 = new Dictionary<string, string>
	{
		{
			"Juqing_Can_001",
			"Đèn nhà ai nấy sáng"
		},
		{
			"Juqing_Can_002",
			"Áo xanh lỗi lạc hành núi hiểm"
		},
		{
			"Juqing_Can_003",
			"Vi Tiếu Chi Lữ"
		},
		{
			"Juqing_Can_004",
			"Ác Quán Mãn Doanh"
		},
		{
			"Juqing_Can_005",
			"Gặp nhau tại Vạn Kiếp Cốc"
		},
		{
			"Juqing_Can_006",
			"Đại chiến Vạn Kiếp Cốc"
		},
		{
			"Juqing_Can_007",
			"Đại tiến quân"
		},
		{
			"Juqing_Can_008",
			"Hổ khiếu long ngâm"
		},
		{
			"Juqing_Can_009",
			"Cô Tô Mộ Dung"
		},
		{
			"Juqing_Can_010",
			"Hoàn Thị Thủy Các"
		},
		{
			"Juqing_Can_011",
			"Độc chiến song hùng"
		},
		{
			"Juqing_Can_012",
			"Đêm dài lắm mộng"
		},
		{
			"Juqing_Can_013",
			"Nhất phẩm đường"
		},
		{
			"Juqing_Can_014",
			"Chỉ Điểm Quần Hào"
		},
		{
			"Juqing_Can_015",
			"Bi Tô Thanh Phong"
		},
		{
			"Juqing_Can_016",
			"Tứ hải là nhà"
		},
		{
			"Juqing_Can_017",
			"Quần Long Vô Thủ"
		},
		{
			"Juqing_Can_018",
			"Cùng Tiến Cùng Lùi"
		},
		{
			"Juqing_Can_019",
			"Thiên hạ võ công xuất Thiếu Lâm"
		},
		{
			"Juqing_Can_020",
			"Tụ Hiền Trang"
		},
		{
			"Juqing_Can_021",
			"Đỉnh thiên lập địa"
		},
		{
			"Juqing_Can_046",
			"Kỳ sau gặp mặt"
		},
		{
			"Juqing_Can_022",
			"Dù vạn người, ta vẫn cứ tiến"
		},
		{
			"Juqing_Can_023",
			"Huyết Chiến Tụ Hiền Trang"
		},
		{
			"Juqing_Can_024",
			"Bảo vệ Mã Phu Nhân"
		},
		{
			"Juqing_Can_025",
			"Nhất Bàn Tản Sa"
		},
		{
			"Juqing_Can_026",
			"Tới núi Thương Mang"
		},
		{
			"Juqing_Can_027",
			"Thiên thời không bằng địa lợi"
		},
		{
			"Juqing_Can_028",
			"Cần Vương"
		},
		{
			"Juqing_Can_029",
			"Bày mưu tính kế"
		},
		{
			"Juqing_Can_030",
			"Tứ Diện Sở Ca"
		},
		{
			"Juqing_Can_031",
			"Kim Qua Đãng Khấu Ngao Binh"
		},
		{
			"Juqing_Can_032",
			"Lục Quân Tị Dịch"
		},
		{
			"Juqing_Can_033",
			"Trân Long Kỳ Hội"
		},
		{
			"Juqing_Can_034",
			"Tịnh hầu quế âm"
		},
		{
			"Juqing_Can_035",
			"Thua thắng thành bại ai biết được"
		},
		{
			"Juqing_Can_036",
			"Chọn ngày tái chiến"
		},
		{
			"Juqing_Can_037",
			"Đóng cửa bắt trộm"
		},
		{
			"Juqing_Can_038",
			"Hội Thi Túc Cầu"
		},
		{
			"Juqing_Can_039",
			"Nhất kiếm thượng thiên sơn"
		},
		{
			"Juqing_Can_040",
			"Dù nguy mà yên"
		},
		{
			"Juqing_Can_041",
			"Y tiếu nhân gian vạn sự"
		},
		{
			"Juqing_Can_042",
			"Hoàn Phụng Không quy nguyệt dạ hồn"
		},
		{
			"Juqing_Can_043",
			"Bày tiệc rượu hỏi Quân Tam Ngữ"
		},
		{
			"Juqing_Can_044",
			"Tình yêu không phải là mơ"
		},
		{
			"Juqing_Can_045",
			"Bên Nhau Trọn Đời"
		},
		{
			"CJG_101231_115",
			"Cái Bang Nghi Vấn Ban Đầu"
		},
		{
			"CJG_101231_116",
			"Trừ độc vật giải nguy Cái Bang"
		},
		{
			"CJG_101231_117",
			"Ẩn danh do thám Cái Bang"
		},
		{
			"CJG_101231_118",
			"Cùng lên Thiếu Lâm"
		},
		{
			"CJG_101231_119",
			"Đến Thiếu Lâm trừ gian kết nghĩa"
		}
	};

	// Token: 0x040018F5 RID: 6389
	public static Dictionary<string, string> dictionary_3 = new Dictionary<string, string>
	{
		{
			"#{MISSIONNAME_JUQING_1}",
			"Hội Thi Túc Cầu"
		},
		{
			"#{CJG_101231_122}",
			"Trừ độc vật giải nguy Cái Bang"
		},
		{
			"#{CJG_101231_123}",
			"Ẩn danh do thám Cái Bang"
		},
		{
			"#{CJG_101231_124}",
			"Cùng lên Thiếu Lâm"
		},
		{
			"#{CJG_101231_125}",
			"Đến Thiếu Lâm trừ gian kết nghĩa"
		}
	};

	// Token: 0x040018F6 RID: 6390
	public static Dictionary<int, string> dictionary_4 = new Dictionary<int, string>
	{
		{
			0,
			"Lạc Dương"
		},
		{
			1,
			"Tô Châu"
		},
		{
			2,
			"Đại Lý"
		},
		{
			3,
			"Tung Sơn"
		},
		{
			4,
			"Thái Hồ"
		},
		{
			5,
			"Kính Hồ"
		},
		{
			6,
			"Vô Lượng Sơn"
		},
		{
			7,
			"Kiếm Các"
		},
		{
			8,
			"Đôn Hoàng"
		},
		{
			9,
			"Thiếu Lâm Tự"
		},
		{
			10,
			"Cái Bang Tổng Đà "
		},
		{
			11,
			"Quang Minh Điện"
		},
		{
			12,
			"Võ Đang Sơn"
		},
		{
			13,
			"Thiên Long Tự "
		},
		{
			14,
			"Lăng Ba Động "
		},
		{
			15,
			"Nga Mi Sơn"
		},
		{
			16,
			"Tinh Túc Hải "
		},
		{
			17,
			"Thiên Sơn"
		},
		{
			18,
			"Nhạn Nam"
		},
		{
			19,
			"Nhạn Bắc "
		},
		{
			20,
			"Thảo Nguyên"
		},
		{
			21,
			"Liêu Tây "
		},
		{
			22,
			"Trường Bạch Sơn "
		},
		{
			23,
			"Hoàng Long Phủ "
		},
		{
			24,
			"Nhĩ Hải "
		},
		{
			25,
			"Thương Sơn "
		},
		{
			26,
			"Thạch Lâm "
		},
		{
			27,
			"Ngọc Khê "
		},
		{
			28,
			"Nam Chiêu "
		},
		{
			29,
			"Miêu Cương "
		},
		{
			30,
			"Tây Hồ"
		},
		{
			31,
			"Long Tuyền "
		},
		{
			32,
			"Võ Di "
		},
		{
			33,
			"Mai Lĩnh "
		},
		{
			34,
			"Nam Vực"
		},
		{
			35,
			"Quỳnh Châu"
		},
		{
			36,
			"Tụ Hiền Trang "
		},
		{
			37,
			"Yến Tử ‘ "
		},
		{
			38,
			"Nhất phẩm đường "
		},
		{
			39,
			"Dự Lưu 1"
		},
		{
			40,
			"Dự Lưu 2"
		},
		{
			41,
			"Dự lưu 3"
		},
		{
			42,
			"Phản quân doanh địa"
		},
		{
			43,
			"Kỉ niệm Lạc Dương"
		},
		{
			44,
			"Kỉ niệm Tô Châu"
		},
		{
			45,
			"Đại Lý tròn một năm"
		},
		{
			46,
			"Kỉ niệm Lâu Lan"
		},
		{
			47,
			"Mộc Nhân Hạng"
		},
		{
			61,
			"Trân Long Kỳ Cuộc"
		},
		{
			66,
			"Thủy lao"
		},
		{
			71,
			"Đại Lý 2"
		},
		{
			72,
			"Đại Lý 3"
		},
		{
			73,
			"Vô Lượng Sơn 2"
		},
		{
			74,
			"Vô Lượng Sơn 3"
		},
		{
			75,
			"Kiếm Các 2"
		},
		{
			76,
			"Kiếm Các 3"
		},
		{
			77,
			"Địa phủ"
		},
		{
			78,
			"Sa mạc yếu trại"
		},
		{
			82,
			"Lôi đài"
		},
		{
			92,
			"Lôi đài"
		},
		{
			102,
			"Quang Minh động"
		},
		{
			103,
			"Đáy cốc Tiêu Dao"
		},
		{
			104,
			"Linh Tính Phong"
		},
		{
			105,
			"Cái Bang Tửu Diếu"
		},
		{
			106,
			"Đào Hoa Trận"
		},
		{
			107,
			"Tháp Lâm"
		},
		{
			108,
			"Ngũ Thần Động"
		},
		{
			109,
			"Chiết Mai Phong"
		},
		{
			110,
			"Huyệt mộ"
		},
		{
			111,
			"Chân tháp"
		},
		{
			112,
			"Huyền Vũ Đảo"
		},
		{
			113,
			"Tụ Hiền Trang "
		},
		{
			114,
			"Yến Tử ‘ "
		},
		{
			115,
			"Nhất phẩm đường "
		},
		{
			116,
			"Lôi Cổ Sơn"
		},
		{
			117,
			"Lôi Cổ Sơn"
		},
		{
			118,
			"Vạn Kiếp Cốc"
		},
		{
			119,
			"Vạn Kiếp Cốc"
		},
		{
			120,
			"Thương Mang Sơn "
		},
		{
			121,
			"Thương Mang Sơn "
		},
		{
			122,
			"Tiểu Mộc Nhân Hạng"
		},
		{
			123,
			"Hậu Hoa Viên"
		},
		{
			124,
			"Chợ"
		},
		{
			125,
			"Khoáng trường"
		},
		{
			126,
			"Nông trại"
		},
		{
			127,
			"Thư Phòng"
		},
		{
			128,
			"Thị tập"
		},
		{
			129,
			"Nhạn Nam sơn động"
		},
		{
			130,
			"Nhạn Bắc sơn động"
		},
		{
			131,
			"Tây Hồ sơn động"
		},
		{
			132,
			"Thương Sơn sơn động"
		},
		{
			133,
			"Quang Minh động"
		},
		{
			134,
			"Đáy cốc Tiêu Dao"
		},
		{
			135,
			"Linh Tính Phong"
		},
		{
			136,
			"Cái Bang Tửu Diếu"
		},
		{
			137,
			"Đào Hoa Trận"
		},
		{
			138,
			"Tháp Lâm"
		},
		{
			139,
			"Ngũ Thần Động"
		},
		{
			140,
			"Chiết Mai Phong"
		},
		{
			141,
			"Chân tháp"
		},
		{
			142,
			"Quang Minh động"
		},
		{
			143,
			"Đáy cốc Tiêu Dao"
		},
		{
			144,
			"Linh Tính Phong"
		},
		{
			145,
			"Cái Bang Tửu Diếu"
		},
		{
			146,
			"Đào Hoa Trận"
		},
		{
			147,
			"Tháp Lâm"
		},
		{
			148,
			"Ngũ Thần Động"
		},
		{
			149,
			"Chiết Mai Phong"
		},
		{
			150,
			"Chân tháp"
		},
		{
			151,
			"Thị tập"
		},
		{
			152,
			"Thị tập"
		},
		{
			153,
			"Công địa"
		},
		{
			154,
			"Thao Trường"
		},
		{
			155,
			"Nha Môn"
		},
		{
			156,
			"Lôi đài"
		},
		{
			157,
			"Lôi đài"
		},
		{
			158,
			"Lôi đài"
		},
		{
			159,
			"Lôi đài"
		},
		{
			160,
			"Lôi đài"
		},
		{
			161,
			"Lôi đài"
		},
		{
			162,
			"Lôi đài"
		},
		{
			163,
			"Lôi đài"
		},
		{
			164,
			"Dạ Tây Hồ"
		},
		{
			165,
			"Tàng Kinh Các"
		},
		{
			166,
			"Bảo Tàng Động Tầng 1 "
		},
		{
			167,
			"Khảo trường"
		},
		{
			168,
			"Hoa Sơn tuyệt đỉnh"
		},
		{
			169,
			"Bảo Tàng Động Tầng 2 "
		},
		{
			170,
			"Tặc Khấu doanh địa"
		},
		{
			171,
			"Tàng Kinh Các"
		},
		{
			172,
			"Tàng Kinh Các"
		},
		{
			173,
			"Thiếu Lâm Tự"
		},
		{
			174,
			"Cái Bang Tổng Đà "
		},
		{
			175,
			"Quang Minh Điện"
		},
		{
			176,
			"Võ Đang Sơn"
		},
		{
			177,
			"Thiên Long Tự "
		},
		{
			178,
			"Lăng Ba Động "
		},
		{
			179,
			"Nga Mi Sơn"
		},
		{
			180,
			"Tinh Túc Hải "
		},
		{
			181,
			"Thiên Sơn"
		},
		{
			182,
			"Thiếu Lâm Tự"
		},
		{
			183,
			"Cái Bang Tổng Đà "
		},
		{
			184,
			"Quang Minh Điện"
		},
		{
			185,
			"Võ Đang Sơn"
		},
		{
			186,
			"Thiên Long Tự "
		},
		{
			187,
			"Lăng Ba Động "
		},
		{
			188,
			"Nga Mi Sơn"
		},
		{
			189,
			"Tinh Túc Hải "
		},
		{
			190,
			"Thiên Sơn"
		},
		{
			191,
			"Bảo Tàng Động Tầng 3 "
		},
		{
			192,
			"Bảo Tàng Động Tầng 4 "
		},
		{
			193,
			"Bảo Tàng Động tầng 5 "
		},
		{
			194,
			"Giám ngục"
		},
		{
			195,
			"Tỷ Võ Hội Trường"
		},
		{
			196,
			"Lễ đường phổ thông"
		},
		{
			197,
			"Lễ đường cao cấp"
		},
		{
			198,
			"Lễ đường hào hoa"
		},
		{
			199,
			"Thảo Liệu Trường"
		},
		{
			200,
			"Miêu Nhân Động"
		},
		{
			201,
			"Thánh Thú Sơn"
		},
		{
			202,
			"Yến Vương Cổ Mộ Tầng 1"
		},
		{
			203,
			"Yến Vương Cổ Mộ Tầng 2"
		},
		{
			204,
			"Yến Vương Cổ Mộ Tầng 3"
		},
		{
			205,
			"Yến Vương Cổ Mộ Tầng 4"
		},
		{
			206,
			"Yến Vương Cổ Mộ Tầng 5"
		},
		{
			207,
			"Yến Vương Cổ Mộ Tầng 6"
		},
		{
			208,
			"Yến Vương Cổ Mộ Tầng 7"
		},
		{
			209,
			"Yến Vương Cổ Mộ Tầng 8"
		},
		{
			210,
			"Yến Vương Cổ Mộ Tầng 9"
		},
		{
			211,
			"Bến Tàu Sơn Động"
		},
		{
			212,
			"Kiếm Gia"
		},
		{
			213,
			"Ma Nhai Động"
		},
		{
			214,
			"Dã Nhân Câu"
		},
		{
			215,
			"Ôn Tuyền Động"
		},
		{
			216,
			"Hoàng Long Động"
		},
		{
			217,
			"Thủy Kính Hồ"
		},
		{
			218,
			"Tiên Vương Phần"
		},
		{
			219,
			"Thiên Khanh Thụ Động"
		},
		{
			220,
			"Đào Hoa Nguyên"
		},
		{
			221,
			"Hải Tặc Động"
		},
		{
			222,
			"Tuyết Lang Hồ"
		},
		{
			223,
			"Phụng Hoàng Cổ Trấn"
		},
		{
			224,
			"Tiền Trang"
		},
		{
			225,
			"Tiểu Mộc Nhân Cảng 2"
		},
		{
			226,
			"Tiểu Mộc Nhân Cảng 3"
		},
		{
			227,
			"Hậu Hoa Viên 2"
		},
		{
			228,
			"Hậu Hoa Viên 3"
		},
		{
			229,
			"Ngân Ngai Tuyết Nguyên"
		},
		{
			230,
			"Kính Hồ Phỉ Trại"
		},
		{
			231,
			"Nông trường Dã Trư"
		},
		{
			232,
			"Phó bản Thánh Thú Sơn"
		},
		{
			233,
			"Mẫu Đơn Uyển"
		},
		{
			234,
			"Tung Sơn phong thiền đài"
		},
		{
			235,
			"Diêm Hồ"
		},
		{
			236,
			"Yến Tử ‘ "
		},
		{
			237,
			"Bạch sa diêm khanh"
		},
		{
			238,
			"Đệ nhất khu nghỉ ngơi tại Lạc Dương"
		},
		{
			239,
			"Đệ nhị khu nghỉ ngơi tại Lạc Dương"
		},
		{
			240,
			"Khu nghỉ ngơi tại Đại Lý"
		},
		{
			241,
			"Khu nghỉ ngơi tại Tô Châu"
		},
		{
			242,
			"Lạc Dương"
		},
		{
			243,
			"Hàn Ngọc Cốc"
		},
		{
			244,
			"Hỏa Diệm Sơn"
		},
		{
			245,
			"Cao Xương"
		},
		{
			246,
			"Lâu Lan"
		},
		{
			247,
			"Tháp Lý Mộc "
		},
		{
			248,
			"Côn Lôn Sơn"
		},
		{
			249,
			"Đại Uyển"
		},
		{
			250,
			"Tát Mã Nhĩ Hãn"
		},
		{
			251,
			"Hỏa Diệm Cốc"
		},
		{
			252,
			"Cao Xương Mê Cung"
		},
		{
			253,
			"Tháp Khắc Lạp Mã Can"
		},
		{
			254,
			"Côn Lôn Phúc Địa"
		},
		{
			255,
			"Hãn Huyết Lĩnh"
		},
		{
			256,
			"Thánh hỏa cung"
		},
		{
			257,
			"Sân bóng đá"
		},
		{
			258,
			"Sân bóng rổ"
		},
		{
			259,
			"Sân bóng bàn"
		},
		{
			260,
			"Thúc Hà Cổ Trấn"
		},
		{
			261,
			"Phiêu Miễu Phong"
		},
		{
			262,
			"Tần Hoàng Địa Cung Tầng 1"
		},
		{
			263,
			"Tần Hoàng Địa Cung Tầng 2"
		},
		{
			264,
			"Tần Hoàng Địa Cung Tầng 3"
		},
		{
			268,
			"Huyền Vũ Đảo"
		},
		{
			269,
			"Lâu Lan Bảo Tàng Động"
		},
		{
			270,
			"Trác Lộc"
		},
		{
			271,
			"Lượng Mã Dịch"
		},
		{
			272,
			"Tàng Kinh Các"
		},
		{
			273,
			"Thiên Kiếp Lâu Tầng 1"
		},
		{
			274,
			"Thiên Kiếp Lâu Tầng 2"
		},
		{
			275,
			"Thiên Kiếp Lâu Tầng 3"
		},
		{
			276,
			"Thiên Kiếp Lâu Tầng 4"
		},
		{
			277,
			"Thiên Kiếp Lâu Tầng 5"
		},
		{
			278,
			"Thiên Kiếp Lâu Tầng 6"
		},
		{
			279,
			"Thiên Kiếp Lâu Tầng 7"
		},
		{
			280,
			"Phụng Hoàng Cổ Thành"
		},
		{
			281,
			"Phụng Hoàng Lăng Mộ"
		},
		{
			282,
			"Thanh Nguyên"
		},
		{
			283,
			"Thanh Nguyên Sơn Động"
		},
		{
			284,
			"Mộ Dung Sơn Trang"
		},
		{
			285,
			"Tàng Thư Thủy Các"
		},
		{
			286,
			"Tàng Thư Thủy Các"
		},
		{
			287,
			"Tàng Thư Thủy Các"
		},
		{
			288,
			"Mộ Dung Sơn Trang"
		},
		{
			289,
			"Mộ Dung Sơn Trang"
		},
		{
			290,
			"Đỉnh Hoa Sơn"
		},
		{
			291,
			"Tứ Tuyệt Trang"
		},
		{
			292,
			"Tần Hoàng Địa Cung Tầng 4"
		},
		{
			293,
			"Niêm Hoa Mộc Nhân Trận"
		},
		{
			294,
			"Binh Thánh Kỳ Trận"
		},
		{
			295,
			"Thông Thiên Tháp Địa Cung"
		},
		{
			296,
			"Thông Thiên Tháp Tầng 1"
		},
		{
			297,
			"Thông Thiên Tháp Tầng 2"
		},
		{
			298,
			"Thông Thiên Tháp Tầng 3"
		},
		{
			299,
			"Đỉnh Thông Thiên Tháp"
		},
		{
			300,
			"Thiên Long Huyễn Cảnh"
		},
		{
			301,
			"Phòng dự bị chiến đấu"
		},
		{
			302,
			"Chiến Trường Tranh Bá Toàn Cầu"
		},
		{
			303,
			"Chung kết-Sân 1"
		},
		{
			304,
			"Chung kết-Sân 2"
		},
		{
			305,
			"Chung kết-Sân 3"
		},
		{
			306,
			"Chung kết-Sân 4"
		},
		{
			501,
			"Tái Ngoại 1"
		},
		{
			502,
			"Tái Ngoại 2"
		},
		{
			503,
			"Tái Ngoại 3"
		},
		{
			504,
			"Tái Ngoại 4"
		},
		{
			505,
			"Tái Ngoại 5"
		},
		{
			506,
			"Lĩnh Nam 1"
		},
		{
			507,
			"Lĩnh Nam 2"
		},
		{
			508,
			"Lĩnh Nam 3"
		},
		{
			509,
			"Lĩnh Nam 4"
		},
		{
			510,
			"Lĩnh Nam 5"
		},
		{
			511,
			"Hàng Châu 1"
		},
		{
			512,
			"Hàng Châu 2"
		},
		{
			513,
			"Hàng Châu 3"
		},
		{
			514,
			"Hàng Châu 4"
		},
		{
			515,
			"Hàng Châu 5"
		},
		{
			516,
			"Hải Khẩu 1"
		},
		{
			517,
			"Hải Khẩu 2"
		},
		{
			518,
			"Hải Khẩu 3"
		},
		{
			519,
			"Hải Khẩu 4"
		},
		{
			520,
			"Hải Khẩu 5"
		},
		{
			521,
			"Điền Vực 1"
		},
		{
			522,
			"Điền Vực 2"
		},
		{
			523,
			"Điền Vực 3"
		},
		{
			524,
			"Điền Vực 4"
		},
		{
			525,
			"Điền Vực 5"
		},
		{
			526,
			"Thạch Thành 1"
		},
		{
			527,
			"Thạch Thành 2"
		},
		{
			528,
			"Thạch Thành 3"
		},
		{
			529,
			"Thạch Thành 4"
		},
		{
			530,
			"Thạch Thành 5"
		},
		{
			531,
			"Miêu Vực 1"
		},
		{
			532,
			"Miêu Vực 2"
		},
		{
			533,
			"Miêu Vực 3"
		},
		{
			534,
			"Miêu Vực 4"
		},
		{
			535,
			"Miêu Vực 5"
		},
		{
			536,
			"Liêu Địa 1"
		},
		{
			537,
			"Liêu Địa 2"
		},
		{
			538,
			"Liêu Địa 3"
		},
		{
			539,
			"Liêu Địa 4"
		},
		{
			540,
			"Liêu Địa 5"
		},
		{
			541,
			"Nhạn Môn 1"
		},
		{
			542,
			"Nhạn Môn 2"
		},
		{
			543,
			"Nhạn Môn 3"
		},
		{
			544,
			"Nhạn Môn 4"
		},
		{
			545,
			"Nhạn Môn 5"
		},
		{
			546,
			"Lôi Đài Sinh Tử"
		},
		{
			547,
			"Con Giáp Lôi Đài"
		},
		{
			548,
			"Chiến Trường Tống Liêu"
		},
		{
			549,
			"Phòng thông tin Chiến Trường Tống Liêu"
		},
		{
			550,
			"Trân Long Kỳ Cuộc"
		},
		{
			551,
			"Tặc Khấu doanh địa"
		},
		{
			552,
			"Thiếu Lâm Tự"
		},
		{
			553,
			"Cái Bang Tổng Đà "
		},
		{
			554,
			"Quang Minh Điện"
		},
		{
			555,
			"Võ Đang Sơn"
		},
		{
			556,
			"Thiên Long Tự "
		},
		{
			557,
			"Lăng Ba Động "
		},
		{
			558,
			"Nga Mi Sơn"
		},
		{
			559,
			"Tinh Túc Hải "
		},
		{
			560,
			"Thiên Sơn"
		},
		{
			561,
			"Mộ Dung Sơn Trang"
		},
		{
			565,
			"Thiếu Thất Sơn (câu chuyện)"
		},
		{
			566,
			"Thiếu Thất Sơn"
		},
		{
			567,
			"Cuộc chiến Tranh Bá liên máy chủ"
		},
		{
			568,
			"Chung kết-Sân 1"
		},
		{
			569,
			"Lâm Hải Khê Cốc"
		},
		{
			570,
			"Quân Thiên Vương Lăng"
		},
		{
			571,
			"La Phù Vương Lăng"
		},
		{
			572,
			"Triều Kinh Vương Lăng"
		},
		{
			573,
			"Mạc Nam Thanh Nguyên"
		},
		{
			574,
			"Vong Xuyên Hoa Hải"
		},
		{
			575,
			"Thiên Kỳ Nam Hoài"
		},
		{
			576,
			"Tàng Kinh Các"
		},
		{
			577,
			"Giám ngục"
		},
		{
			578,
			"Địa phủ"
		},
		{
			579,
			"Tân Lạc Dương"
		},
		{
			580,
			"Phụng Minh Trấn"
		},
		{
			581,
			"Quân Thiên Thành"
		},
		{
			582,
			"La Phù Thành"
		},
		{
			583,
			"Triều Kinh Thành"
		},
		{
			584,
			"Thiếu Lâm Thí Luyện"
		},
		{
			585,
			"Cái Bang Thí Luyện"
		},
		{
			586,
			"Minh Giáo Thí Luyện"
		},
		{
			587,
			"Võ Đang Thí Luyện"
		},
		{
			588,
			"Thiên Long Thí Luyện"
		},
		{
			589,
			"Tiêu Dao Thí Luyện"
		},
		{
			590,
			"Nga Mi Thí Luyện"
		},
		{
			591,
			"Tinh Túc Thí Luyện"
		},
		{
			592,
			"Thiên Sơn Thí Luyện"
		},
		{
			593,
			"Mộ Dung Thí Luyện"
		},
		{
			594,
			"Chung kết-Sân 2"
		},
		{
			595,
			"Chung kết-Sân 3"
		},
		{
			596,
			"Chung kết-Sân 4"
		},
		{
			597,
			"Đại Địa Đồ KVK"
		},
		{
			598,
			"Thiên Hoàng Địa Cung"
		},
		{
			599,
			"Lôi đài"
		},
		{
			600,
			"Phụng Minh Vương Lăng"
		},
		{
			601,
			"Quang Minh động"
		},
		{
			602,
			"Đáy cốc Tiêu Dao"
		},
		{
			603,
			"Linh Tính Phong"
		},
		{
			604,
			"Cái Bang Tửu Diếu"
		},
		{
			605,
			"Đào Hoa Trận"
		},
		{
			606,
			"Tháp Lâm"
		},
		{
			607,
			"Ngũ Thần Động"
		},
		{
			608,
			"Chiết Mai Phong"
		},
		{
			609,
			"Chân tháp"
		},
		{
			610,
			"Tàng Thư Thủy Các"
		},
		{
			611,
			"Huyền Hải"
		},
		{
			612,
			"Đại Côn Di Hài"
		},
		{
			613,
			"Thủy Nguyệt Động Thiên"
		},
		{
			614,
			"Hư Không Huyễn Cảnh"
		},
		{
			615,
			"Đường Gia Bảo"
		},
		{
			616,
			"Đường Gia Bảo"
		},
		{
			617,
			"Diễn Võ Trường"
		},
		{
			618,
			"Đường Gia Bảo"
		},
		{
			619,
			"Đường Môn Thí Luyện"
		},
		{
			620,
			"Thiên Hạ Đệ Nhất Lôi Đài"
		},
		{
			621,
			"Phòng chuẩn bị chiến đấu Tông Sư"
		},
		{
			622,
			"Phòng chuẩn bị chiến đấu Danh Sĩ"
		},
		{
			623,
			"Phòng chuẩn bị chiến đấu Hào Hiệp"
		},
		{
			624,
			"Trong Nhạn Môn Quan"
		},
		{
			625,
			"Thiếu Lâm (Thâu Đêm)"
		},
		{
			626,
			"Diễn Võ Trường"
		},
		{
			627,
			"Diễn Võ Trường"
		},
		{
			628,
			"Đường Gia Bảo"
		},
		{
			629,
			"Vấn Đỉnh Thiên Hạ"
		},
		{
			630,
			"Mật Chiến Thất"
		},
		{
			631,
			"Hi Hoàng Thần Vực"
		},
		{
			632,
			"Oa Hoàng Thần Vực"
		},
		{
			633,
			"Nông Hoàng Thần Vực"
		},
		{
			634,
			"Sào Hoàng Thần Vực"
		},
		{
			635,
			"Nhân Hoàng Thần Vực"
		},
		{
			636,
			"Dung Hoàng Thần Vực"
		},
		{
			637,
			"Công Hoàng Thần Vực"
		},
		{
			638,
			"Thái Hoàng Thần Vực"
		},
		{
			639,
			"Quân Thiên Thành (Đêm)"
		},
		{
			640,
			"Thần Binh Các (Cấp 1)"
		},
		{
			641,
			"Thần Binh Đường (Cấp 2)"
		},
		{
			642,
			"Thần Binh Đàn (Cấp 3)"
		},
		{
			643,
			"Thần Binh Lâu (Cấp 4)"
		},
		{
			644,
			"Thần Binh Điện (Cấp 5)"
		},
		{
			645,
			"Huyết Chiến Nhạn Môn Quan"
		},
		{
			646,
			"Hàn Băng Hải Vực"
		},
		{
			647,
			"Diệt Thế Hỏa Quật"
		},
		{
			648,
			"Cổ Hoặc Linh Cốc"
		},
		{
			649,
			"Phòng dự bị chiến đấu "
		},
		{
			650,
			"Vô Nhai Cảnh"
		},
		{
			651,
			"Viêm Ma Sơn"
		},
		{
			652,
			"Tam Tài Hiệp Cốc (Đơn)"
		},
		{
			653,
			"Tam Tài Hiệp Cốc"
		},
		{
			654,
			"Quần Hùng Lôi"
		},
		{
			655,
			"Quần Hùng Lôi"
		},
		{
			656,
			"Quần Hùng Lôi"
		},
		{
			657,
			"Quần Hùng Lôi"
		},
		{
			658,
			"Tụ Nghĩa Tinh Đàn"
		},
		{
			659,
			"Đạo Trường Sư Môn"
		},
		{
			660,
			"Đào Viên Cảnh"
		},
		{
			661,
			"Giải Đấu Ngôi Sao"
		},
		{
			662,
			"Tam Thần Huyễn Cảnh"
		},
		{
			663,
			"Thiên Thu Điện"
		},
		{
			664,
			"Bất Quy Lâm"
		},
		{
			665,
			"Vô Nhai Hải"
		},
		{
			666,
			"Viêm La Thiên"
		},
		{
			667,
			"Ngọc Hoàng Sơn"
		},
		{
			668,
			"Điện Tiền Quảng Trường"
		},
		{
			669,
			"Tẩm Thủy Đan Lâm"
		},
		{
			670,
			"Vân Dao Thước Lĩnh"
		},
		{
			671,
			"Côn Ngô-Mạc Nam Thanh Nguyên"
		},
		{
			672,
			"Côn Ngô-Vong Xuyên Hoa Hải"
		},
		{
			673,
			"Côn Ngô-Thiên Kỳ Nam Hoài"
		}
	};

	// Token: 0x040018F7 RID: 6391
	public static List<string> list_14 = new List<string>
	{
		"Cửu Tiêu Lý",
		"Toái Phách Ngoa",
		"Ưng Dương",
		"Phượng Vũ",
		"Túc Giao",
		"Bách Xuyên",
		"Cửu Tiêu Hộ Thủ",
		"Toái Phách Chưởng",
		"Cửu Tiêu Cầu",
		"Toái Phách Khải",
		"Thôi Tuyết",
		"Túy Vũ",
		"Sương Hiểu",
		"Xuyên Mộ",
		"Yêu Ngôn",
		"Liệt Nhật",
		"Toái Phách Khôi",
		"Cửu Tiêu Mão"
	};

	// Token: 0x040018F8 RID: 6392
	public static List<string> list_15 = new List<string>
	{
		"Dung Kim Lạc Nhật Đồ",
		"Thu Thủy Vô Ngấn Đồ",
		"Bích Hải Ngân Đào Đồ",
		"Vạn Hách Tùng Phong Đồ",
		"Bích Hải Lăng Ba Đồ Tường",
		"Tử Dương Tuyệt Linh Đồ Tường",
		"Bách Đại Hồng Quang Đồ Tường"
	};

	// Token: 0x040018F9 RID: 6393
	public static HashSet<string> hashSet_3 = new HashSet<string>
	{
		"Thú Cưỡi: Linh Hồ",
		"Thú Cưỡi: Kim Tiền Báo",
		"Thú Cưỡi: Linh Dương",
		"Thú Cưỡi: Mao Ngưu",
		"Thú Cưỡi: Lộc",
		"Thú Cưỡi: Hổ",
		"Thú Cưỡi: Điêu",
		"Thú Cưỡi: Hoàng Phiêu Mã",
		"Thú Cưỡi: Thanh Phụng",
		"Thú Cưỡi: Hạc",
		"Thú Cưỡi: Sư Tử",
		"Thú Cưỡi: Khôi Lang",
		"Thú Cưỡi: Mộc Diên"
	};

	// Token: 0x040018FA RID: 6394
	public static HashSet<string> hashSet_4 = new HashSet<string>
	{
		"Thú Cưỡi: Xích Vĩ Hồ",
		"Thú Cưỡi: Vân Tuyết Báo",
		"Thú Cưỡi: Tuyết Linh Dương",
		"Thú Cưỡi: Bạch Mao Ngưu",
		"Thú Cưỡi: Bạch Lộc",
		"Thú Cưỡi: Bạch Hổ",
		"Thú Cưỡi: Bạch Điêu",
		"Thú Cưỡi: Thanh Bạch Tông Mã",
		"Thú Cưỡi: Hồng Bạch Phụng",
		"Thú Cưỡi: Kim Dực Hạc",
		"Thú Cưỡi: Bạch Sư",
		"Thú Cưỡi: Bạch Lang",
		"Thú Cưỡi: Tinh Phong Diên"
	};

	// Token: 0x040018FB RID: 6395
	public static Dictionary<string, string> dictionary_5 = new Dictionary<string, string>
	{
		{
			"#{SJZYH_150824_2}|#{SJZ_100129_48}",
			"Vận chuyển đến Tây Vận Các"
		},
		{
			"#{SJZYH_150824_3}|#{SJZ_100129_62}",
			"Vận chuyển đến Bán Long Các"
		},
		{
			"#{SJZYH_150824_4}",
			"Vận chuyển đến Tinh La Đàn"
		},
		{
			"#{SJZ_100129_63}",
			"Vận chuyển đến Tứ Tuyệt Điện"
		}
	};

	// Token: 0x040018FC RID: 6396
	public static HashSet<string> hashSet_5 = new HashSet<string>
	{
		"26|Thiên sư kỳ đãi (1)->Kỳ Vọng Của Thiên Sư (1)|Châu Thiên Sư[256,273-0]|#",
		"28|Thiên sư kỳ đãi (2)->Kỳ Vọng Của Thiên Sư (2)|Châu Thiên Sư[256,273-0]|#",
		"30|Thiên sư kỳ đãi (3)->Kỳ Vọng Của Thiên Sư (3)|Châu Thiên Sư[256,273-0]|#",
		"32|Thiên sư kỳ đãi (4)->Kỳ Vọng Của Thiên Sư (4)|Châu Thiên Sư[256,273-0]|#",
		"35|Thiên sư kỳ đãi (5)->Kỳ Vọng Của Thiên Sư (5)|Châu Thiên Sư[256,273-0]|#",
		"38|Thiên sư kỳ đãi (6)->Kỳ Vọng Của Thiên Sư (6)|Châu Thiên Sư[256,273-0]|#",
		"40|Thiên sư kỳ đãi (7)->Kỳ Vọng Của Thiên Sư (7)|Châu Thiên Sư[256,273-0]|#",
		"42|Thiên sư kỳ đãi (8)->Kỳ Vọng Của Thiên Sư (8)|Châu Thiên Sư[256,273-0]|#",
		"45|Thiên sư kỳ đãi (9)->Kỳ Vọng Của Thiên Sư (9)|Châu Thiên Sư[256,273-0]|#",
		"48|Thiên sư kỳ đãi (10)->Kỳ Vọng Của Thiên Sư (10)|Châu Thiên Sư[256,273-0]|#",
		"59|Thảo Nguyên kiếp phỉ|Tiêu Tường[163,159-20]|Kill{Loan Đao Mã Phỉ[275,150-20]}",
		"60|Hắc Phong thích|Nguyễn lão thái thái[90,200-20]|Kill{Mông Cổ Hắc Phong[255,285-20]}&Pick{8-Mông Cổ Hắc Phong Thích)}|2.62.00",
		"60|Đường lương thực yếu|Nguyễn Thực[198,203-20]|Kill{30-Thảo Nguyên Lang[177,250-20]}|3.37.00",
		"62|Mệnh lệnh của Quận Chủ|Tiêu Tường[163,159-20]|Kill{35-Thiểm Điện Mã Phỉ[83,233-20]}|3.10.00",
		"62|Bằng chứng anh hùng|Tiêu Tường[163,159-20]|Kill{35-Truy Phong Mã Phỉ[192,115-20]}|3.10.00",
		"65|Thiêu đốt|Nguyễn Thực[198,203-20]|Kill{40-Đả Thảo Cốc Tống Binh[55,50-20]}|4.18.00",
		"65|Nghe danh xuống ngựa|Nguyễn Thành[138,53-20]->Thẩm Vạn Tam[170,73-33]|#|2.53.00",
		"65|Cơ hội buôn bán vô hạn|Thẩm Vạn Tam[170,73-33]|Kill{Hồng Bào Tri Thù[43,248-20]}&Pick{10-Tơ Của Hồng Bào Tri Thù}|3.73.00",
		"65|Con đường buôn bán gập ghềnh|Thẩm Vạn Tam[170,73-33]|Kill{30-Tùng Lâm Dã Nhân[112,120-20]}|3.62.00",
		"65|Vô gian đạo|Thái Dương Hoa[196,49-33]->Cam Thảo[162,274-33]|#|4.1.00",
		"67|Kinh Vệ Phân Minh|Thái Dương Hoa[196,49-33]|Kill{30-Sơn Viện Hộ Pháp[231,47-20]}|4.1.00",
		"67|Ăn miếng trả miếng|Cam Thảo[162,274-33]|Kill{30-Sơn Viện Tư Tế[121,74-20]}|3.83.00",
		"67|Làm khó|Cam Thảo[162,274-33]->Nguyệt Lý[193,71-33]|#|3.13.00",
		"70|Tuyệt thế hảo nam nhi|Đông Thích[163,284-33]->Thẩm Vạn Tam[170,73-33]|#|3.24.00",
		"70|Dừng xe Phong Lâm đêm|Thẩm Vạn Tam[170,73-33]->Sách Mẫu Lạp[50,51-27]|#|3.53.00",
		"70|La Bốc cần Long Huyết|La Bốc[46,52-27]|Kill{Long Huyết Thạch Nhân[85,266-27]}&Pick{10-Linh Kiện Long Huyết Thạch}|3.1.00",
		"70|La Bốc cần Vân Mẫu|La Bốc[46,52-27]|Kill{Vân Mẫu Thạch Nhân[150,103-27]}&Pick{10-Linh Kiện Của Vân Mẫu}|2.98.00",
		"70|La Bốc cần Nhện|La Bốc[46,52-27]|Kill{Kịch Độc Lang Thù[83,52-27]}&Pick{10-Chân Của Kịch Độc Tri Thù+10-Kịch Độc Tri Thù Ty}|2.90.00",
		"72|Nữ Oa Thạch Nhân|A Hắc[280,47-27]|Kill{35-Nữ Oa Thạch Nhân[154,252-27]}|3.20.00",
		"72|Đại Yển Sư|A Hắc[280,47-27]|Kill{35-Đại Yển Sư[268,72-27]}|3.20.00",
		"72|Yển Sư Hộ Pháp|A Hắc[280,47-27]|Kill{35-Yển Sư Hộ Pháp[210,208-27]}|3.20.00",
		"72|Ca ca ngốc|A Y Na[278,44-27]->La Bốc[46,52-27]|#|2.1.00",
		"72|Không hấp bánh bao|Cổ Lỗ Lạp[276,45-27]->Gia Luật Kim[170,207-21]|#|2.56.32",
		"75|Bạch Lang Bì|Ba Đồ[159,196-21]|Kill{Bạch Lang Vương[161,268-21]}&Pick{1-Bạch Lang Bì}|5.50.00",
		"75|Hắc Phong Mật|Ba Đồ[159,196-21]|Kill{Đại Hắc Phong[84,222-21]}&Pick{1-Hắc Phong Mật}|5.50.00",
		"78|Hồng Y Mã Phỉ|Gia Luật Kim[170,207-21]|Kill{40-Hồng Y Mã Phỉ[212,58-21]}|9.65.00",
		"78|Hắc Y Mã Phỉ|Gia Luật Kim[170,207-21]|Kill{40-Hắc Y Mã Phỉ[94,98-21]}|9.65.00",
		"80|Bắt giặc bắt vua|Gia Luật Kim[170,207-21]|Kill{1-A Sử Na Mặc Cốc[106,60-21]}|5.45.00",
		"80|Mãng Cái Tam Kiệt|Gia Luật Kim[170,207-21]|Kill{1-Long Thắng[204,52-21]+1-Tiêu Doãn[222,270-21]+1-Lý Thông[217,47-21]}|5.80.00",
		"80|Nghiên cứu chữ Huyết|Diệp Lưu Phàm[115,59-34]|Kill{Nam Vực Ngạc Ngư[70,135-34]}&Pick{6-Nam Vực Ngạc Ngư Huyết Dịch}|5.00.00",
		"80|Nhân vật kịch tình|Diệp Lưu Phàm[115,59-34]->Đinh Liên Y[112,60-34]|#|1.80.00",
		"80|Năm hạt quýt|Diệp Lưu Phàm[115,59-34]|Kill{Thạch Lão Nhân[154,162-34]}&Pick{5-Quất Hạch}|5.20.0",
		"80|Đen tối|Đinh Liên Y[112,60-34]|Kill{35-Ngạc Ngư Bang Tặc Đồ}|5.0.00",
		"82|Phòng trống|Đinh Liên Y[112,60-34]->Diệp Lưu Phàm[115,59-34]|#|2.0.0"
	};

	// Token: 0x040018FD RID: 6397
	public static HashSet<string> hashSet_6 = new HashSet<string>
	{
		"Cùng Kỳ-Huyễn",
		"Thị Ma Giả",
		"Băng Mặc Hổ",
		"Huyền Mặc Hổ",
		"Hỏa Mặc Hổ",
		"Độc Mặc Hổ",
		"Tinh La Võ Sĩ",
		"Thanh Ưng",
		"Tín đồ",
		"Băng Tằm",
		"Huyết chú vu cổ",
		"Phiên tăng chấp sự",
		"Thổ phồn ác tăng đầu lĩnh",
		"Hắc Sắc Tâm Ma",
		"Nhiếp Hồn",
		"Hoa Độc",
		"Tâm Ma",
		"Vô Tướng Tung Ảnh",
		"Đạo Thư Ác Tăng"
	};

	// Token: 0x040018FE RID: 6398
	public static List<string> list_16 = new List<string>
	{
		"62,118",
		"64,112",
		"64,123",
		"72,112",
		"72,123",
		"74,118"
	};

	// Token: 0x040018FF RID: 6399
	public static List<string> list_17 = new List<string>
	{
		"118,40",
		"124,40",
		"126,45",
		"124,50",
		"118,50",
		"116,45"
	};

	// Token: 0x04001900 RID: 6400
	public static HashSet<string> hashSet_7 = new HashSet<string>
	{
		"Tướng Tiến Tửu 1",
		"Tướng Tiến Tửu 2",
		"Hồi Âm Phiên",
		"Bẫy hiệu ứng Khai Minh Nộ Hỏa Xung Thiên",
		"Nộ Hỏa Xung Thiên",
		"Nhiên Thiêu Nộ Hỏa",
		"Băng Đông Tam Xích",
		"Địa Sát Trận",
		"Nhân Vong Trận",
		"Thiên Canh Trận",
		"Băng tằm ty (băng)",
		"Băng tằm ty (hoả)",
		"Bẫy Tiêu Dao Nội Tức",
		"Thập Bộ Nhất Sát 1",
		"Thập Bộ Nhất Sát 2",
		"Thập Bộ Nhất Sát 3",
		"Thập Bộ Nhất Sát 4",
		"Thập Bộ Nhất Sát 5",
		"Thập Bộ Nhất Sát 6",
		"Thập Bộ Nhất Sát 7",
		"Thập Bộ Nhất Sát 8",
		"Thập Bộ Nhất Sát 9",
		"Thập Bộ Nhất Sát 10",
		"Băng Tuyết Thiên",
		"Liệt Diệm Phần Thân",
		"Thùy Nhập Địa Ngục",
		"Bách Độc Triền Linh",
		"Cao Bạo Đạn",
		"Sát thương Vi Đà Chưởng",
		"Sát thương La Hán Quyền",
		"Sát thương Lăng Ba Vi Bộ",
		"Bẫy Cờ",
		"NPC Hắc Thủy",
		"Thích Cốt Hàn Sương",
		"Cuồng Phong Vũ"
	};

	// Token: 0x04001901 RID: 6401
	public static List<string> list_18 = new List<string>
	{
		"132,162",
		"142,152",
		"122,152",
		"132,142",
		"132,152"
	};

	// Token: 0x04001902 RID: 6402
	public static List<string> list_19 = new List<string>
	{
		"52,122",
		"62,112",
		"52,102",
		"42,112",
		"52,112"
	};

	// Token: 0x04001903 RID: 6403
	public static List<string> list_20 = new List<string>
	{
		"126,74",
		"136,64",
		"126,54",
		"116,64",
		"126,64"
	};

	// Token: 0x04001904 RID: 6404
	public static Dictionary<int, string> dictionary_6 = new Dictionary<int, string>
	{
		{
			0,
			"Tấn công"
		},
		{
			1,
			"Thu phục"
		},
		{
			21,
			"Triệu hồi"
		},
		{
			22,
			"Về Đại Lý Thành"
		},
		{
			28,
			"Tinh Túc Khinh Công"
		},
		{
			34,
			"Tân Thủ Khinh Công"
		},
		{
			35,
			"Ngồi thiền"
		},
		{
			249,
			"Cạm Bẫy Thiêu Đốt"
		},
		{
			278,
			"Đổi Bảo Vật Tiện Lợi"
		}
	};

	// Token: 0x04001905 RID: 6405
	public static Dictionary<string, string> dictionary_7 = new Dictionary<string, string>
	{
		{
			"PetFood_12",
			"Trân Thú Hồi Thần Đan"
		},
		{
			"PetFood_11",
			"Trân Thú Vạn Bổ Đan"
		},
		{
			"PetFood_16",
			"Trân Thú Hồi Xuân Đan"
		},
		{
			"PetFood_15",
			"Trân Thú Tư Bổ Đan"
		},
		{
			"PetBauble_4",
			"Bóng Nhiều Màu"
		}
	};

	// Token: 0x04001906 RID: 6406
	public static Dictionary<string, string> dictionary_8 = new Dictionary<string, string>
	{
		{
			"Tây lương khoáng xa xuất Lôi Tuyệt",
			"#{MZPVE_150812_80}"
		},
		{
			"Thái cư phiêu nhiên huề thủ hành",
			"#{MZPVE_150812_831}"
		},
		{
			"Kính hải vô nhai hộ khoáng quy",
			"#{MZPVE_150812_1203}"
		},
		{
			"Võ Khố Manh Oa Bất Hư Hành",
			"#{MZPVE_150812_1577}"
		},
		{
			"Xe Khoáng hiểm xuất Ngọc Hoàng Sơn",
			"#{MZPVE_150812_1950}"
		}
	};

	// Token: 0x04001907 RID: 6407
	public static Dictionary<string, string> dictionary_9 = new Dictionary<string, string>
	{
		{
			"Diệu biện chân giả thủ sơn đồng",
			"#{MZPVE_150812_245}"
		},
		{
			"Hoang mộc thiên tải sinh quỳnh hoa",
			"#{MZPVE_150812_904}"
		},
		{
			"Chân giả xà lung biện hồng hoàn",
			"#{MZPVE_150812_1279}"
		},
		{
			"Phù Tang xán nhiên kim bạc sắc",
			"#{MZPVE_150812_1653}"
		},
		{
			"Linh tê cổ mộc biện chân ngụy",
			"#{MZPVE_150812_2026}"
		}
	};

	// Token: 0x04001908 RID: 6408
	public static Dictionary<string, string> dictionary_10 = new Dictionary<string, string>
	{
		{
			"Nước đường ngon",
			"CircularTaskTool27_9"
		},
		{
			"Mộc Linh Thần Nhãn",
			"taiwanzhuanyong3_16"
		},
		{
			"Huyễn Hải Trúc Địch",
			"Icons01_2"
		},
		{
			"Phù Tang La Bàn",
			"CommonLiveSkill2_6"
		},
		{
			"Thổ Linh Chú Phù",
			"OtherTools2_6"
		}
	};

	// Token: 0x04001909 RID: 6409
	public static Dictionary<string, string> dictionary_11 = new Dictionary<string, string>
	{
		{
			"Thủ sơn bách niên hà thủ ô",
			"#{MZPVE_150812_360}"
		},
		{
			"Dược giả liên tâm tầm tiên thảo",
			"#{MZPVE_150812_1018}"
		},
		{
			"Khả thán băng liên a na ý",
			"#{MZPVE_150812_1394}"
		},
		{
			"Hỏa diệm chi địa tầm kỳ hoa",
			"#{MZPVE_150812_1768}"
		},
		{
			"Ngọc Hoàng tiên sơn dao thảo phương",
			"#{MZPVE_150812_2142}"
		}
	};

	// Token: 0x0400190A RID: 6410
	public static Dictionary<string, string> dictionary_12 = new Dictionary<string, string>
	{
		{
			"Vô sở bất tri thám kỳ văn",
			"#{MZPVE_150812_360}"
		},
		{
			"Chúc tửu cộng tế kiến mộc đài",
			"#{MZPVE_150812_971}"
		},
		{
			"Phá Băng Ngư Đường luyện ngư thuật",
			"#{MZPVE_150812_1346}"
		},
		{
			"Dung thiết luyện lô tu chú tạo",
			"#{MZPVE_150812_1720}"
		},
		{
			"Bách Luyện đoàn đài chú kiếm thành",
			"#{MZPVE_150812_2094}"
		},
		{
			"Dựng lò rèn đúc",
			"Dựng lò rèn đúc"
		},
		{
			"Cùng xây tế đài",
			"Cùng xây tế đài"
		},
		{
			"Nghe ngóng chuyện lạ",
			"Nghe ngóng chuyện lạ"
		},
		{
			"Câu cá trên băng",
			"Câu cá trên băng"
		},
		{
			"Đúc kiếm thành công",
			"Đúc kiếm thành công"
		}
	};

	// Token: 0x0400190B RID: 6411
	public static Dictionary<string, string> dictionary_13 = new Dictionary<string, string>
	{
		{
			"Ma Lạt Huyền Hải Hà",
			"CircularTaskTool73_2"
		},
		{
			"Quân Thiên Dã Sơn Khuẩn",
			"CircularTaskTool73_3"
		},
		{
			"Tây Lương Bồ Đào",
			"CircularTaskTool71_7"
		},
		{
			"Kim Trản Mỹ Tửu",
			"CircularTaskTool71_11"
		},
		{
			"Gà Nướng",
			"Food_11"
		},
		{
			"Liềm Cắt Cỏ",
			"CircularTaskTool73_5"
		},
		{
			"Chổi",
			"TaskTools5_4"
		},
		{
			"Bách Hợp Hoa",
			"Flower_2"
		},
		{
			"Điện Thờ",
			"playerhouse7_3"
		},
		{
			"Nến Tế Tự",
			"Merchandise1_11"
		},
		{
			"Ngư Đường Dược Tễ",
			"CircularTaskTool4_8"
		},
		{
			"Tiểu Quỷ Ngư",
			"CircularTaskTool72_3"
		},
		{
			"Mồi Câu",
			"OtherTools2_11"
		},
		{
			"Tiểu Hồng Ngư",
			"CircularTaskTool72_2"
		},
		{
			"Tiểu Băng Ngư",
			"CircularTaskTool72_1"
		},
		{
			"Kim Nguyên Khoáng",
			"CircularTaskTool74_2"
		},
		{
			"Đồng Nguyên Khoáng",
			"CircularTaskTool73_16"
		},
		{
			"Tích Nguyên Khoáng",
			"CircularTaskTool74_3"
		},
		{
			"Thiết Nguyên Khoáng",
			"CircularTaskTool74_1"
		},
		{
			"Thái Nguyên Khoáng",
			"CircularTaskTool74_4"
		},
		{
			"Hàn Thiết Kiếm Phôi",
			"CircularTaskTool72_7"
		},
		{
			"Thúy Ngọc Kiếm Phôi",
			"CircularTaskTool72_6"
		},
		{
			"Hồng Đồng Kiếm Phôi",
			"CircularTaskTool72_8"
		},
		{
			"Huyết Thiết Kiếm Phôi",
			"CircularTaskTool72_4"
		},
		{
			"Thanh Đồng Kiếm Phôi",
			"CircularTaskTool72_5"
		}
	};

	// Token: 0x0400190C RID: 6412
	public static Dictionary<string, string> dictionary_14 = new Dictionary<string, string>
	{
		{
			"Thiên Hoang Dược Phổ",
			"CircularTaskTool5_2"
		},
		{
			"Cuốc Ngũ Hành",
			"CircularTaskTool71_8"
		}
	};

	// Token: 0x0400190D RID: 6413
	public static Dictionary<string, string> dictionary_15 = new Dictionary<string, string>
	{
		{
			"Tìm mật thám Thiên Thu Kỳ Công",
			"#{MZPVE_150812_2344}"
		},
		{
			"Tìm mật thám Bất Quy Kỳ Công",
			"#{MZPVE_150812_2378}"
		},
		{
			"Tìm Mật Thám Vô Nhai Kỳ Công",
			"#{MZPVE_150812_2403}"
		},
		{
			"Tìm Mật Thám Viêm La Kỳ Công",
			"#{MZPVE_150812_2428}"
		},
		{
			"Tìm mật thám Ngọc Hoàng Kỳ Công",
			"#{MZPVE_150812_2453}"
		}
	};

	// Token: 0x0400190E RID: 6414
	public static Dictionary<int, string> dictionary_16 = new Dictionary<int, string>
	{
		{
			10141153,
			"Thú Cưỡi: Lưu Ly Phụng"
		},
		{
			10141157,
			"Thú Cưỡi: Ngân Nguyệt Lang"
		},
		{
			10141161,
			"Thú Cưỡi: Liệt Diệm Sư"
		},
		{
			10141165,
			"Thú Cưỡi: Như Ý Hổ"
		},
		{
			10141169,
			"Thú Cưỡi: Long Huyết Mã"
		},
		{
			10141173,
			"Thú Cưỡi: Vụ Ảnh Điêu"
		},
		{
			10141177,
			"Thú Cưỡi: Thuỵ Liên Hạc"
		},
		{
			10141181,
			"Thú Cưỡi: Thất Thái Lộc"
		},
		{
			10141222,
			"Thú Cưỡi: U Quang Linh"
		},
		{
			10141185,
			"Thú Cưỡi: Thanh Mao Ngưu"
		},
		{
			10141495,
			"Thú Cưỡi: U Linh Báo"
		}
	};

	// Token: 0x0400190F RID: 6415
	public static HashSet<string> hashSet_8 = new HashSet<string>
	{
		"Bích Lân Cương Thi",
		"Thực Phẩm Hỏng",
		"Nguyệt Lý",
		"Yến Tử Ổ trang đinh",
		"Công Dã Càn",
		"Bao Bất Đồng",
		"Đặng Bách Xuyên",
		"Nhất Phẩm Đường Võ Sĩ",
		"Top Hall Samurais",
		"Swallow's Dock Servant",
		"Attendant Gung",
		"Attendant Bao",
		"Attendant Fong"
	};

	// Token: 0x04001910 RID: 6416
	public static HashSet<string> hashSet_9 = new HashSet<string>();

	// Token: 0x04001911 RID: 6417
	public static List<string> list_21 = new List<string>
	{
		"Băng Lam Lưu Vân-Cước (Cấp 1)",
		"Băng Lam Lưu Vân-Khiên (Cấp 1)",
		"Băng Lam Lưu Vân-Yêu (Cấp 1)",
		"Hoa Lạc Hồng Trần-Cước (Cấp 1)",
		"Hoa Lạc Hồng Trần-Khiên (Cấp 1)",
		"Hoa Lạc Hồng Trần-Yêu (Cấp 1)",
		"Thúy Ngọc Tinh Trần-Cước (Cấp 1)",
		"Thúy Ngọc Tinh Trần-Khiên (Cấp 1)",
		"Thúy Ngọc Tinh Trần-Yêu (Cấp 1)",
		"Tranh Ảnh Như Mộng-Cước (Cấp 1)",
		"Tranh Ảnh Như Mộng-Khiên (Cấp 1)",
		"Tranh Ảnh Như Mộng-Yêu (Cấp 1)",
		"Tử Vi Tinh Quang-Cước (Cấp 1)",
		"Tử Vi Tinh Quang-Khiên (Cấp 1)",
		"Tử Vi Tinh Quang-Yêu (Cấp 1)",
		"Toái Toàn Tinh Thần-Cước (Cấp 1)",
		"Toái Toàn Tinh Thần-Khiên (Cấp 1)",
		"Toái Toàn Tinh Thần-Yêu (Cấp 1)",
		"Diệu Vũ Phương Lan-Cước (Cấp 1)",
		"Diệu Vũ Phương Lan-Khiên (Cấp 1)",
		"Diệu Vũ Phương Lan-Yêu (Cấp 1)",
		"Điệp Ảnh Tâm Hoa-Khiên (Cấp 1)",
		"Điệp Ảnh Tâm Hoa-Yêu (Cấp 1)",
		"Điệp Ảnh Tâm Hoa-Cước (Cấp 1)",
		"Thước Vũ Hồng Liên-Cước (Cấp 1)",
		"Thước Vũ Hồng Liên-Khiên (Cấp 1)",
		"Thước Vũ Hồng Liên-Yêu (Cấp 1)"
	};

	// Token: 0x04001912 RID: 6418
	public static HashSet<string> hashSet_10 = new HashSet<string>
	{
		"Đao Phủ",
		"Thương Bổng",
		"Đơn Đoản",
		"Song Đoản",
		"Tiêu Kiếm",
		"Phiến",
		"Hoàn",
		"Nỏ",
		"Trường Trượng"
	};

	// Token: 0x04001913 RID: 6419
	public static List<string> list_22 = new List<string>
	{
		"43,54",
		"53,54",
		"56,48",
		"53,42",
		"43,42",
		"40,48"
	};

	// Token: 0x04001914 RID: 6420
	public static List<string> list_23 = new List<string>
	{
		"43,54",
		"53,54",
		"56,48",
		"53,42",
		"43,42",
		"40,48"
	};

	// Token: 0x04001915 RID: 6421
	public static List<string> list_24 = new List<string>
	{
		"36,29",
		"36,37",
		"30,39",
		"23,37",
		"23,29",
		"30,27"
	};

	// Token: 0x04001916 RID: 6422
	public static List<string> list_25 = new List<string>
	{
		"25,95",
		"32,95",
		"34,100",
		"32,106",
		"25,106",
		"22,100"
	};

	// Token: 0x04001917 RID: 6423
	public static Dictionary<string, int> dictionary_17 = new Dictionary<string, int>();
}
