﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020001F5 RID: 501
public class TextEdit : UserControl
{
	// Token: 0x06001A3B RID: 6715 RVA: 0x00012FFC File Offset: 0x000111FC
	public TextEdit()
	{
		this.InitializeComponent();
	}

	// Token: 0x17000657 RID: 1623
	// (get) Token: 0x06001A3C RID: 6716 RVA: 0x0001300A File Offset: 0x0001120A
	// (set) Token: 0x06001A3D RID: 6717 RVA: 0x00013017 File Offset: 0x00011217
	public virtual string Text
	{
		get
		{
			return this.text.Text;
		}
		set
		{
			this.text.Text = value;
		}
	}

	// Token: 0x06001A3E RID: 6718 RVA: 0x00013025 File Offset: 0x00011225
	private void method_0()
	{
		base.Height = this.text.Height;
		if (this.lbSearch.Visible)
		{
			base.Height += this.lbSearch.Height;
		}
	}

	// Token: 0x06001A3F RID: 6719 RVA: 0x000C6190 File Offset: 0x000C4390
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		TextEdit.Class233 @class = new TextEdit.Class233();
		this.text.smethod_11(this.txtSearch.Text);
		@class.string_0 = this.txtSearch.Text.smethod_0();
		this.lbSearch.Visible = false;
		if (string.IsNullOrEmpty(@class.string_0))
		{
			return;
		}
		string[] array = this.text.IList_0.Where(new Func<string, bool>(@class.method_0)).ToArray<string>();
		if (array.Length == 0)
		{
			return;
		}
		this.lbSearch.Items.Clear();
		ListBox.ObjectCollection items = this.lbSearch.Items;
		object[] items2 = array;
		items.AddRange(items2);
		this.lbSearch.Visible = true;
		this.method_0();
	}

	// Token: 0x06001A40 RID: 6720 RVA: 0x0001305D File Offset: 0x0001125D
	private void lbSearch_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.txtSearch.Text = this.lbSearch.Text;
		this.lbSearch.Visible = false;
		this.method_0();
	}

	// Token: 0x06001A41 RID: 6721 RVA: 0x00013087 File Offset: 0x00011287
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A42 RID: 6722 RVA: 0x000C6248 File Offset: 0x000C4448
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		this.lbSearch = new ListBox();
		this.text = new FastColoredTextBox();
		this.txtSearch = new Class85();
		((ISupportInitialize)this.text).BeginInit();
		base.SuspendLayout();
		this.lbSearch.Dock = DockStyle.Top;
		this.lbSearch.FormattingEnabled = true;
		this.lbSearch.Location = new Point(0, 20);
		this.lbSearch.Name = "lbSearch";
		this.lbSearch.Size = new Size(536, 56);
		this.lbSearch.TabIndex = 18;
		this.lbSearch.Visible = false;
		this.lbSearch.SelectedIndexChanged += this.lbSearch_SelectedIndexChanged;
		this.text.Char_0 = new char[]
		{
			'(',
			')',
			'{',
			'}',
			'[',
			']',
			'"',
			'"',
			'\'',
			'\''
		};
		this.text.String_6 = "^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\n^\\s*(case|default)\\s*[^:]*(?<range>:)\\s*(?<range>[^;]+);";
		this.text.Size_0 = new Size(2, 13);
		this.text.Brush_0 = null;
		this.text.Int32_2 = 13;
		this.text.Int32_4 = 7;
		this.text.Cursor = Cursors.IBeam;
		this.text.Int32_20 = 8;
		this.text.Color_7 = Color.FromArgb(100, 180, 180, 180);
		this.text.Dock = DockStyle.Fill;
		this.text.Font = new Font("Courier New", 9f);
		this.text.Boolean_15 = false;
		this.text.Location = new Point(0, 20);
		this.text.Name = "text";
		this.text.Padding_0 = new Padding(0);
		this.text.Color_11 = Color.FromArgb(60, 0, 0, 255);
		this.text.GClass76_0 = null;
		this.text.Boolean_10 = false;
		this.text.Size = new Size(536, 472);
		this.text.TabIndex = 17;
		this.text.Int32_21 = 100;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(536, 20);
		this.txtSearch.TabIndex = 16;
		this.txtSearch.String_0 = "Search...";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lbSearch);
		base.Controls.Add(this.text);
		base.Controls.Add(this.txtSearch);
		base.Name = "TextEdit";
		base.Size = new Size(536, 492);
		((ISupportInitialize)this.text).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400105F RID: 4191
	private IContainer icontainer_0;

	// Token: 0x04001060 RID: 4192
	private ListBox lbSearch;

	// Token: 0x04001061 RID: 4193
	private FastColoredTextBox text;

	// Token: 0x04001062 RID: 4194
	private Class85 txtSearch;

	// Token: 0x020001F6 RID: 502
	[CompilerGenerated]
	private sealed class Class233
	{
		// Token: 0x06001A44 RID: 6724 RVA: 0x000130A6 File Offset: 0x000112A6
		internal bool method_0(string string_1)
		{
			return string_1.smethod_0().Contains(this.string_0);
		}

		// Token: 0x04001063 RID: 4195
		public string string_0;
	}
}
