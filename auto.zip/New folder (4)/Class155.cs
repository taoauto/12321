﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000174 RID: 372
internal class Class155 : GClass114
{
	// Token: 0x060011F8 RID: 4600 RVA: 0x0006712C File Offset: 0x0006532C
	private static byte[] smethod_1(GClass116 gclass116_0)
	{
		byte[] result = null;
		GClass109 gclass = new GClass109(gclass116_0);
		GClass109.GClass111 gclass2 = null;
		int num = 0;
		while (num < gclass.GClass111_0.GClass111_0.Length && gclass2 == null)
		{
			if ((long)gclass.GClass111_0.GClass111_0[num].Int32_0 == 24L)
			{
				gclass2 = gclass.GClass111_0.GClass111_0[num];
			}
			num++;
		}
		if (gclass2 != null && gclass2.GClass111_0.Length != 0 && Class155.smethod_4(gclass2.GClass111_0[0].Int32_0) && gclass2.GClass111_0[0].GClass112_0.Length == 1)
		{
			result = gclass2.GClass111_0[0].GClass112_0[0].method_0();
		}
		return result;
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x000671D0 File Offset: 0x000653D0
	private static uint smethod_2(IntPtr intptr_7, IntPtr intptr_8)
	{
		if (intptr_7.smethod_4() || intptr_7.smethod_2(-1L))
		{
			throw new ArgumentException("Invalid process handle.", "hProcess");
		}
		if (intptr_8.smethod_4())
		{
			throw new ArgumentException("Invalid module handle.", "hModule");
		}
		byte[] array = GClass120.smethod_4(intptr_7, intptr_8, (uint)Marshal.SizeOf(typeof(GStruct7)));
		if (array != null)
		{
			ushort num = BitConverter.ToUInt16(array, 0);
			uint num2 = BitConverter.ToUInt32(array, 60);
			if (num == 23117)
			{
				byte[] array2 = GClass120.smethod_4(intptr_7, intptr_8.smethod_0((long)((ulong)num2)), (uint)Marshal.SizeOf(typeof(GStruct10)));
				if (array2 != null && BitConverter.ToUInt32(array2, 0) == 17744U)
				{
					GStruct10 gstruct = default(GStruct10);
					uint addressOfEntryPoint;
					using (GClass117 gclass = new GClass117(256))
					{
						if (!gclass.method_9<GStruct10>(array2, out gstruct))
						{
							return 0U;
						}
						addressOfEntryPoint = gstruct.OptionalHeader.AddressOfEntryPoint;
					}
					return addressOfEntryPoint;
				}
			}
		}
		return 0U;
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x000672D8 File Offset: 0x000654D8
	private static IntPtr smethod_3(string string_0, int int_0)
	{
		IntPtr result = IntPtr.Zero;
		Process processById = Process.GetProcessById(int_0);
		int num = 0;
		while (num < processById.Modules.Count && result.smethod_4())
		{
			if (processById.Modules[num].ModuleName.ToLower() == string_0.ToLower())
			{
				result = processById.Modules[num].BaseAddress;
			}
			num++;
		}
		return result;
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x00067348 File Offset: 0x00065548
	public override IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(GClass116 gclass116_0, IntPtr intptr_7)
	{
		this.vmethod_0();
		IntPtr result;
		try
		{
			result = Class155.smethod_6(GClass118.smethod_0<GClass116>(gclass116_0), intptr_7, true);
		}
		catch (Exception exception_)
		{
			this.vmethod_2(exception_);
			result = IntPtr.Zero;
		}
		return result;
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x00067390 File Offset: 0x00065590
	public override IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string string_0, IntPtr intptr_7)
	{
		this.vmethod_0();
		IntPtr result;
		try
		{
			using (GClass116 gclass = new GClass116(string_0))
			{
				result = this.GClass114.\u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(gclass, intptr_7);
			}
		}
		catch (Exception exception_)
		{
			this.vmethod_2(exception_);
			result = IntPtr.Zero;
		}
		return result;
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x000673F0 File Offset: 0x000655F0
	public override IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(GClass116[] gclass116_0, IntPtr intptr_7)
	{
		Class155.Class150 @class = new Class155.Class150();
		@class.class155_0 = this;
		@class.intptr_0 = intptr_7;
		this.vmethod_0();
		return Array.ConvertAll<GClass116, IntPtr>(gclass116_0, new Converter<GClass116, IntPtr>(@class.method_0));
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x0006742C File Offset: 0x0006562C
	public override IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(string[] string_0, IntPtr intptr_7)
	{
		Class155.Class151 @class = new Class155.Class151();
		@class.class155_0 = this;
		@class.intptr_0 = intptr_7;
		this.vmethod_0();
		return Array.ConvertAll<string, IntPtr>(string_0, new Converter<string, IntPtr>(@class.method_0));
	}

	// Token: 0x060011FF RID: 4607 RVA: 0x00067468 File Offset: 0x00065668
	private static bool smethod_4(int int_0)
	{
		return int_0 - 1 <= 2;
	}

	// Token: 0x06001200 RID: 4608 RVA: 0x00067480 File Offset: 0x00065680
	private static bool smethod_5(GClass116 gclass116_0, IntPtr intptr_7, int int_0)
	{
		List<string> list = new List<string>();
		string empty = string.Empty;
		bool result = false;
		foreach (GStruct9 gstruct in gclass116_0.method_8())
		{
			if (gclass116_0.method_4((long)((ulong)gclass116_0.method_11(gstruct.Name)), SeekOrigin.Begin, out empty, -1, null) && !string.IsNullOrEmpty(empty) && Class155.smethod_3(empty, int_0).smethod_4())
			{
				list.Add(empty);
			}
		}
		if (list.Count > 0)
		{
			byte[] array = Class155.smethod_1(gclass116_0);
			string text = string.Empty;
			if (array == null)
			{
				if (string.IsNullOrEmpty(gclass116_0.String_0) || !File.Exists(Path.Combine(Path.GetDirectoryName(gclass116_0.String_0), Path.GetFileName(gclass116_0.String_0) + ".manifest")))
				{
					IntPtr[] array2 = GClass114.smethod_0(GEnum22.Standard).GClass114.\u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(list.ToArray(), intptr_7);
					for (int i = 0; i < array2.Length; i++)
					{
						if (array2[i].smethod_4())
						{
							return false;
						}
					}
					return true;
				}
				text = Path.Combine(Path.GetDirectoryName(gclass116_0.String_0), Path.GetFileName(gclass116_0.String_0) + ".manifest");
			}
			else
			{
				text = GClass118.smethod_2(array);
			}
			if (string.IsNullOrEmpty(text))
			{
				return false;
			}
			IntPtr intPtr = GClass120.VirtualAllocEx(intptr_7, IntPtr.Zero, (uint)Class155.byte_1.Length, 12288, 64);
			IntPtr intPtr2 = GClass120.smethod_0(intptr_7, Encoding.ASCII.GetBytes(text + "\0"), 4);
			IntPtr intPtr3 = GClass120.smethod_0(intptr_7, Encoding.ASCII.GetBytes(string.Join("\0", list.ToArray()) + "\0"), 4);
			if (!intPtr.smethod_4())
			{
				byte[] array3 = (byte[])Class155.byte_1.Clone();
				uint num = 0U;
				BitConverter.GetBytes(Class155.intptr_1.smethod_7(intPtr.smethod_0(63L)).ToInt32()).CopyTo(array3, 59);
				BitConverter.GetBytes(Class155.intptr_0.smethod_7(intPtr.smethod_0(88L)).ToInt32()).CopyTo(array3, 84);
				BitConverter.GetBytes(Class155.intptr_3.smethod_7(intPtr.smethod_0(132L)).ToInt32()).CopyTo(array3, 128);
				BitConverter.GetBytes(Class155.intptr_4.smethod_7(intPtr.smethod_0(146L)).ToInt32()).CopyTo(array3, 142);
				BitConverter.GetBytes(Class155.intptr_2.smethod_7(intPtr.smethod_0(200L)).ToInt32()).CopyTo(array3, 196);
				BitConverter.GetBytes(Class155.intptr_5.smethod_7(intPtr.smethod_0(209L)).ToInt32()).CopyTo(array3, 205);
				BitConverter.GetBytes(intPtr2.ToInt32()).CopyTo(array3, 31);
				BitConverter.GetBytes(list.Count).CopyTo(array3, 40);
				BitConverter.GetBytes(intPtr3.ToInt32()).CopyTo(array3, 49);
				if (GClass120.WriteProcessMemory(intptr_7, intPtr, array3, array3.Length, out num) && (ulong)num == (ulong)((long)array3.Length))
				{
					uint num2 = GClass120.smethod_7(intptr_7, intPtr, 0U, 5000);
					result = (num2 != uint.MaxValue && num2 > 0U);
				}
				GClass120.VirtualFreeEx(intptr_7, intPtr3, 0, 32768);
				GClass120.VirtualFreeEx(intptr_7, intPtr2, 0, 32768);
				GClass120.VirtualFreeEx(intptr_7, intPtr, 0, 32768);
			}
		}
		return result;
	}

	// Token: 0x06001201 RID: 4609 RVA: 0x00067824 File Offset: 0x00065A24
	private static IntPtr smethod_6(GClass116 gclass116_0, IntPtr intptr_7, bool bool_0 = false)
	{
		if (intptr_7.smethod_4() || intptr_7.smethod_2(-1L))
		{
			throw new ArgumentException("Invalid process handle.", "hProcess");
		}
		if (gclass116_0 == null)
		{
			throw new ArgumentException("Cannot map a non-existant PE Image.", "image");
		}
		int processId = GClass120.GetProcessId(intptr_7);
		if (processId == 0)
		{
			throw new ArgumentException("Provided handle doesn't have sufficient permissions to inject", "hProcess");
		}
		IntPtr intPtr = IntPtr.Zero;
		IntPtr intPtr2 = IntPtr.Zero;
		uint num = 0U;
		try
		{
			intPtr = GClass120.VirtualAllocEx(intptr_7, IntPtr.Zero, gclass116_0.GStruct10_0.OptionalHeader.SizeOfImage, 12288, 4);
			if (intPtr.smethod_4())
			{
				throw new InvalidOperationException("Unable to allocate memory in the remote process.");
			}
			Class155.smethod_9(gclass116_0, intPtr);
			Class155.smethod_5(gclass116_0, intptr_7, processId);
			Class155.smethod_8(gclass116_0, intptr_7, processId);
			if (bool_0)
			{
				byte[] array = new byte[(ulong)gclass116_0.GStruct7_0.e_lfanew + (ulong)((long)Marshal.SizeOf(typeof(GStruct8))) + 4UL + (ulong)gclass116_0.GStruct10_0.FileHeader.SizeOfOptionalHeader];
				if (gclass116_0.method_2(0L, SeekOrigin.Begin, array))
				{
					GClass120.WriteProcessMemory(intptr_7, intPtr, array, array.Length, out num);
				}
			}
			Class155.smethod_7(gclass116_0, intptr_7, intPtr);
			if (gclass116_0.GStruct10_0.OptionalHeader.AddressOfEntryPoint <= 0U)
			{
				return intPtr;
			}
			byte[] array2 = (byte[])Class155.byte_0.Clone();
			BitConverter.GetBytes(intPtr.ToInt32()).CopyTo(array2, 11);
			intPtr2 = GClass120.VirtualAllocEx(intptr_7, IntPtr.Zero, (uint)Class155.byte_0.Length, 12288, 64);
			if (!intPtr2.smethod_4() && GClass120.WriteProcessMemory(intptr_7, intPtr2, array2, array2.Length, out num))
			{
				if ((ulong)num == (ulong)((long)array2.Length))
				{
					IntPtr intPtr3 = GClass120.CreateRemoteThread(intptr_7, 0, 0, intPtr2, (uint)intPtr.smethod_0((long)((ulong)gclass116_0.GStruct10_0.OptionalHeader.AddressOfEntryPoint)).ToInt32(), 0, 0);
					if ((ulong)GClass120.WaitForSingleObject(intPtr3, 5000) != 0UL)
					{
						return intPtr;
					}
					GClass120.GetExitCodeThread(intPtr3, out num);
					if (num == 0U)
					{
						GClass120.VirtualFreeEx(intptr_7, intPtr, 0, 32768);
						throw new Exception("Entry method of module reported a failure " + Marshal.GetLastWin32Error().ToString());
					}
					GClass120.VirtualFreeEx(intptr_7, intPtr2, 0, 32768);
					GClass120.CloseHandle(intPtr3);
					return intPtr;
				}
			}
			throw new InvalidOperationException("Unable to write stub to the remote process.");
		}
		catch (Exception ex)
		{
			if (!intPtr.smethod_4())
			{
				GClass120.VirtualFreeEx(intptr_7, intPtr, 0, 32768);
			}
			if (!intPtr2.smethod_4())
			{
				GClass120.VirtualFreeEx(intptr_7, intPtr, 0, 32768);
			}
			intPtr = IntPtr.Zero;
			throw ex;
		}
		return intPtr;
	}

	// Token: 0x06001202 RID: 4610 RVA: 0x00067ABC File Offset: 0x00065CBC
	private static void smethod_7(GClass116 gclass116_0, IntPtr intptr_7, IntPtr intptr_8)
	{
		foreach (GStruct15 gstruct in gclass116_0.method_9())
		{
			byte[] array = new byte[gstruct.SizeOfRawData];
			if (!gclass116_0.method_2((long)((ulong)gstruct.PointerToRawData), SeekOrigin.Begin, array))
			{
				throw gclass116_0.vmethod_1();
			}
			if ((gstruct.Characteristics & 33554432U) == 0U)
			{
				uint num;
				GClass120.WriteProcessMemory(intptr_7, intptr_8.smethod_0((long)((ulong)gstruct.VirtualAddress)), array, array.Length, out num);
				IntPtr intPtr = intptr_8.smethod_0((long)((ulong)gstruct.VirtualAddress));
				GClass120.VirtualProtectEx(intptr_7, intPtr, gstruct.SizeOfRawData, gstruct.Characteristics & 16777215U, out num);
			}
		}
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x00067B80 File Offset: 0x00065D80
	private static void smethod_8(GClass116 gclass116_0, IntPtr intptr_7, int int_0)
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		foreach (GStruct9 gstruct in gclass116_0.method_8())
		{
			if (gclass116_0.method_4((long)((ulong)gclass116_0.method_11(gstruct.Name)), SeekOrigin.Begin, out empty, -1, null))
			{
				IntPtr intPtr = IntPtr.Zero;
				intPtr = Class155.smethod_3(empty, int_0);
				if (intPtr.smethod_4())
				{
					throw new FileNotFoundException(string.Format("Unable to load dependent module '{0}'.", empty));
				}
				uint num = gclass116_0.method_11(gstruct.FirstThunkPtr);
				uint num2 = (uint)Marshal.SizeOf(typeof(GStruct16));
				GStruct16 gstruct2;
				while (gclass116_0.method_3<GStruct16>((long)((ulong)num), SeekOrigin.Begin, out gstruct2) && gstruct2.u1.AddressOfData > 0U)
				{
					IntPtr intPtr2 = IntPtr.Zero;
					object obj;
					if ((gstruct2.u1.Ordinal & 2147483648U) == 0U)
					{
						if (!gclass116_0.method_4((long)((ulong)(gclass116_0.method_11(gstruct2.u1.AddressOfData) + 2U)), SeekOrigin.Begin, out empty2, -1, null))
						{
							throw gclass116_0.vmethod_1();
						}
						obj = empty2;
					}
					else
					{
						obj = (ushort)(gstruct2.u1.Ordinal & 65535U);
					}
					if (!(intPtr2 = GClass120.GetModuleHandleA(empty)).smethod_4())
					{
						IntPtr intPtr3 = obj.GetType().Equals(typeof(string)) ? GClass120.GetProcAddress(intPtr2, (string)obj) : GClass120.GetProcAddress_1(intPtr2, (uint)((ushort)obj & ushort.MaxValue));
						if (!intPtr3.smethod_4())
						{
							intPtr2 = intPtr.smethod_0((long)intPtr3.smethod_6((long)intPtr2.ToInt32()).ToInt32());
						}
					}
					else
					{
						intPtr2 = GClass120.smethod_3(intptr_7, intPtr, obj);
					}
					if (intPtr2.smethod_4())
					{
						throw new EntryPointNotFoundException(string.Format("Unable to locate imported function '{0}' from module '{1}' in the remote process.", empty2, empty));
					}
					gclass116_0.method_7<int>((long)((ulong)num), SeekOrigin.Begin, intPtr2.ToInt32());
					num += num2;
				}
			}
		}
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x00067D9C File Offset: 0x00065F9C
	private static void smethod_9(GClass116 gclass116_0, IntPtr intptr_7)
	{
		GStruct6 gstruct = gclass116_0.GStruct10_0.OptionalHeader.DataDirectory[5];
		if (gstruct.Size > 0U)
		{
			uint num = 0U;
			uint num2 = (uint)(intptr_7.ToInt32() - (int)gclass116_0.GStruct10_0.OptionalHeader.ImageBase);
			uint num3 = gclass116_0.method_11(gstruct.VirtualAddress);
			uint num4 = (uint)Marshal.SizeOf(typeof(GStruct5));
			GStruct5 gstruct2;
			while (num < gstruct.Size && gclass116_0.method_3<GStruct5>((long)((ulong)num3), SeekOrigin.Begin, out gstruct2))
			{
				int num5 = (int)((gstruct2.SizeOfBlock - num4) / 2U);
				uint num6 = gclass116_0.method_11(gstruct2.VirtualAddress);
				for (int i = 0; i < num5; i++)
				{
					ushort num7;
					if (gclass116_0.method_3<ushort>((long)((ulong)(num3 + num4) + (ulong)((long)((long)i << 1))), SeekOrigin.Begin, out num7) && (num7 >> 12 & 3) != 0)
					{
						uint num8 = num6 + (uint)(num7 & 4095);
						uint num9;
						if (!gclass116_0.method_3<uint>((long)((ulong)num8), SeekOrigin.Begin, out num9))
						{
							throw gclass116_0.vmethod_1();
						}
						gclass116_0.method_7<uint>(-4L, SeekOrigin.Current, num9 + num2);
					}
				}
				num += gstruct2.SizeOfBlock;
				num3 += gstruct2.SizeOfBlock;
			}
		}
	}

	// Token: 0x06001205 RID: 4613 RVA: 0x00067EBC File Offset: 0x000660BC
	public override bool \u200B\u200E\u200B\u200D\u206B\u200C\u200E\u202C\u202E\u206F\u202B\u206F\u206B\u206E\u206C\u200B\u206B\u206A\u202D\u202E\u202B\u202E\u206C\u200B\u206E\u202E\u202C\u206E\u202A\u206B\u206B\u202B\u200C\u200B\u202C\u202B\u200B\u206C\u202C\u202E\u202E(IntPtr intptr_7, IntPtr intptr_8)
	{
		this.vmethod_0();
		if (intptr_7.smethod_4())
		{
			throw new ArgumentNullException("hModule", "Invalid module handle");
		}
		if (!intptr_8.smethod_4() && !intptr_8.smethod_2(-1L))
		{
			IntPtr intPtr = IntPtr.Zero;
			uint num = 0U;
			try
			{
				uint num2 = Class155.smethod_2(intptr_8, intptr_7);
				if (num2 != 0U)
				{
					byte[] array = (byte[])Class155.byte_0.Clone();
					BitConverter.GetBytes(intptr_7.ToInt32()).CopyTo(array, 11);
					BitConverter.GetBytes(0U).CopyTo(array, 6);
					BitConverter.GetBytes(1000U).CopyTo(array, 1);
					intPtr = GClass120.VirtualAllocEx(intptr_8, IntPtr.Zero, (uint)Class155.byte_0.Length, 12288, 64);
					if (!intPtr.smethod_4() && GClass120.WriteProcessMemory(intptr_8, intPtr, array, array.Length, out num))
					{
						if ((ulong)num == (ulong)((long)array.Length))
						{
							IntPtr intPtr2 = GClass120.CreateRemoteThread(intptr_8, 0, 0, intPtr, (uint)intptr_7.smethod_0((long)((ulong)num2)).ToInt32(), 0, 0);
							if ((ulong)GClass120.WaitForSingleObject(intPtr2, 5000) == 0UL)
							{
								GClass120.VirtualFreeEx(intptr_8, intPtr, 0, 32768);
								GClass120.CloseHandle(intPtr2);
								return GClass120.VirtualFreeEx(intptr_8, intptr_7, 0, 32768);
							}
							return false;
						}
					}
					throw new InvalidOperationException("Unable to write stub to the remote process.");
				}
				return GClass120.VirtualFreeEx(intptr_8, intptr_7, 0, 32768);
			}
			catch (Exception exception_)
			{
				this.vmethod_2(exception_);
				return false;
			}
		}
		throw new ArgumentException("Invalid process handle.", "hProcess");
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x00068048 File Offset: 0x00066248
	public override bool[] \u202A\u206C\u202A\u206B\u206D\u206C\u206F\u206C\u206C\u200D\u200C\u202E\u202A\u200B\u202E\u206C\u202A\u202E\u200B\u202D\u200E\u206A\u206B\u200B\u200E\u200D\u200B\u206F\u206D\u206D\u200C\u200B\u200E\u206B\u200D\u206C\u206E\u200B\u206A\u202B\u202E(IntPtr[] intptr_7, IntPtr intptr_8)
	{
		this.vmethod_0();
		if (intptr_7 == null)
		{
			throw new ArgumentNullException("hModules", "Parameter cannot be null.");
		}
		if (!intptr_8.smethod_4() && !intptr_8.smethod_2(-1L))
		{
			try
			{
				bool[] array = new bool[intptr_7.Length];
				for (int i = 0; i < intptr_7.Length; i++)
				{
					array[i] = this.GClass114.\u200B\u200E\u200B\u200D\u206B\u200C\u200E\u202C\u202E\u206F\u202B\u206F\u206B\u206E\u206C\u200B\u206B\u206A\u202D\u202E\u202B\u202E\u206C\u200B\u206E\u202E\u202C\u206E\u202A\u206B\u206B\u202B\u200C\u200B\u202C\u202B\u200B\u206C\u202C\u202E\u202E(intptr_7[i], intptr_8);
				}
				return array;
			}
			catch (Exception exception_)
			{
				this.vmethod_2(exception_);
				return null;
			}
		}
		throw new ArgumentOutOfRangeException("hProcess", "Invalid process handle specified.");
	}

	// Token: 0x04000975 RID: 2421
	private static readonly byte[] byte_0 = new byte[]
	{
		104,
		0,
		0,
		0,
		0,
		104,
		1,
		0,
		0,
		0,
		104,
		0,
		0,
		0,
		0,
		byte.MaxValue,
		84,
		36,
		16,
		195
	};

	// Token: 0x04000976 RID: 2422
	private static readonly IntPtr intptr_0 = GClass120.GetProcAddress(Class155.intptr_6, "ActivateActCtx");

	// Token: 0x04000977 RID: 2423
	private static readonly IntPtr intptr_1 = GClass120.GetProcAddress(Class155.intptr_6, "CreateActCtxA");

	// Token: 0x04000978 RID: 2424
	private static readonly IntPtr intptr_2 = GClass120.GetProcAddress(Class155.intptr_6, "DeactivateActCtx");

	// Token: 0x04000979 RID: 2425
	private static readonly IntPtr intptr_3 = GClass120.GetProcAddress(Class155.intptr_6, "GetModuleHandleA");

	// Token: 0x0400097A RID: 2426
	private static readonly IntPtr intptr_4 = GClass120.GetProcAddress(Class155.intptr_6, "LoadLibraryA");

	// Token: 0x0400097B RID: 2427
	private static readonly IntPtr intptr_5 = GClass120.GetProcAddress(Class155.intptr_6, "ReleaseActCtx");

	// Token: 0x0400097C RID: 2428
	private static readonly IntPtr intptr_6 = GClass120.GetModuleHandleA("KERNEL32.dll");

	// Token: 0x0400097D RID: 2429
	private static readonly byte[] byte_1 = new byte[]
	{
		85,
		139,
		236,
		131,
		236,
		60,
		139,
		204,
		139,
		209,
		131,
		194,
		60,
		199,
		1,
		0,
		0,
		0,
		0,
		131,
		193,
		4,
		59,
		202,
		126,
		243,
		198,
		4,
		36,
		32,
		185,
		0,
		0,
		0,
		0,
		137,
		76,
		36,
		8,
		185,
		0,
		0,
		0,
		0,
		137,
		76,
		36,
		40,
		185,
		0,
		0,
		0,
		0,
		137,
		76,
		36,
		44,
		84,
		232,
		0,
		0,
		0,
		0,
		131,
		56,
		byte.MaxValue,
		15,
		132,
		137,
		0,
		0,
		0,
		137,
		68,
		36,
		48,
		139,
		204,
		131,
		193,
		32,
		81,
		80,
		232,
		0,
		0,
		0,
		0,
		131,
		248,
		0,
		116,
		107,
		198,
		68,
		36,
		36,
		1,
		139,
		76,
		36,
		40,
		131,
		249,
		0,
		126,
		62,
		131,
		233,
		1,
		137,
		76,
		36,
		40,
		139,
		76,
		36,
		36,
		131,
		249,
		0,
		116,
		46,
		byte.MaxValue,
		116,
		36,
		44,
		232,
		0,
		0,
		0,
		0,
		131,
		248,
		0,
		117,
		9,
		byte.MaxValue,
		116,
		36,
		44,
		232,
		0,
		0,
		0,
		0,
		137,
		68,
		36,
		36,
		139,
		76,
		36,
		44,
		138,
		1,
		131,
		193,
		1,
		60,
		0,
		117,
		247,
		137,
		76,
		36,
		44,
		235,
		185,
		139,
		68,
		36,
		36,
		185,
		1,
		0,
		0,
		0,
		35,
		193,
		137,
		76,
		36,
		36,
		131,
		249,
		0,
		117,
		20,
		byte.MaxValue,
		116,
		36,
		32,
		106,
		0,
		232,
		0,
		0,
		0,
		0,
		byte.MaxValue,
		116,
		36,
		48,
		232,
		0,
		0,
		0,
		0,
		139,
		68,
		36,
		36,
		139,
		229,
		93,
		195
	};

	// Token: 0x02000175 RID: 373
	[CompilerGenerated]
	private sealed class Class150
	{
		// Token: 0x0600120A RID: 4618 RVA: 0x0000E46B File Offset: 0x0000C66B
		internal IntPtr method_0(GClass116 gclass116_0)
		{
			return this.class155_0.GClass114.\u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(gclass116_0, this.intptr_0);
		}

		// Token: 0x0400097E RID: 2430
		public Class155 class155_0;

		// Token: 0x0400097F RID: 2431
		public IntPtr intptr_0;
	}

	// Token: 0x02000176 RID: 374
	[CompilerGenerated]
	private sealed class Class151
	{
		// Token: 0x0600120C RID: 4620 RVA: 0x0000E47F File Offset: 0x0000C67F
		internal IntPtr method_0(string string_0)
		{
			return this.class155_0.GClass114.\u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string_0, this.intptr_0);
		}

		// Token: 0x04000980 RID: 2432
		public Class155 class155_0;

		// Token: 0x04000981 RID: 2433
		public IntPtr intptr_0;
	}
}
