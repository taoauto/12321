﻿using System;
using System.Windows.Forms;

// Token: 0x02000003 RID: 3
public class GClass1 : ListView
{
	// Token: 0x06000005 RID: 5 RVA: 0x00002E3F File Offset: 0x0000103F
	public GClass1()
	{
		base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
	}
}
