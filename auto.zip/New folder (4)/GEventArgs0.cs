﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000027 RID: 39
public sealed class GEventArgs0 : EventArgs
{
	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x060001E7 RID: 487 RVA: 0x000043EF File Offset: 0x000025EF
	// (set) Token: 0x060001E8 RID: 488 RVA: 0x000043F7 File Offset: 0x000025F7
	public long Int64_0 { get; private set; }

	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x060001E9 RID: 489 RVA: 0x00004400 File Offset: 0x00002600
	// (set) Token: 0x060001EA RID: 490 RVA: 0x00004408 File Offset: 0x00002608
	public long Int64_1 { get; private set; }

	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x060001EB RID: 491 RVA: 0x00004411 File Offset: 0x00002611
	public double Double_0
	{
		get
		{
			return (double)this.Int64_0 / (double)this.Int64_1 * 100.0;
		}
	}

	// Token: 0x060001EC RID: 492 RVA: 0x0000442C File Offset: 0x0000262C
	public GEventArgs0(long long_2, long long_3)
	{
		this.Int64_0 = long_2;
		this.Int64_1 = long_3;
	}

	// Token: 0x04000121 RID: 289
	[CompilerGenerated]
	private long long_0;

	// Token: 0x04000122 RID: 290
	[CompilerGenerated]
	private long long_1;
}
