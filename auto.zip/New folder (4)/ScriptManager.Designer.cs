﻿// Token: 0x020002B8 RID: 696
internal partial class ScriptManager : global::System.Windows.Forms.Form
{
	// Token: 0x060026AD RID: 9901 RVA: 0x00112E58 File Offset: 0x00111058
	private void InitializeComponent()
	{
		this.txtID = new global::System.Windows.Forms.TextBox();
		this.label1 = new global::System.Windows.Forms.Label();
		this.label2 = new global::System.Windows.Forms.Label();
		this.txtMD = new global::System.Windows.Forms.TextBox();
		this.label3 = new global::System.Windows.Forms.Label();
		this.label4 = new global::System.Windows.Forms.Label();
		this.label5 = new global::System.Windows.Forms.Label();
		this.txdDo = new global::System.Windows.Forms.TextBox();
		this.recvID = new global::System.Windows.Forms.NumericUpDown();
		this.label6 = new global::System.Windows.Forms.Label();
		this.label7 = new global::System.Windows.Forms.Label();
		this.recvX = new global::System.Windows.Forms.NumericUpDown();
		this.label8 = new global::System.Windows.Forms.Label();
		this.recvY = new global::System.Windows.Forms.NumericUpDown();
		this.label9 = new global::System.Windows.Forms.Label();
		this.recvMAP = new global::System.Windows.Forms.NumericUpDown();
		this.label10 = new global::System.Windows.Forms.Label();
		this.sendMAP = new global::System.Windows.Forms.NumericUpDown();
		this.label11 = new global::System.Windows.Forms.Label();
		this.sendY = new global::System.Windows.Forms.NumericUpDown();
		this.label12 = new global::System.Windows.Forms.Label();
		this.sendX = new global::System.Windows.Forms.NumericUpDown();
		this.label13 = new global::System.Windows.Forms.Label();
		this.sendID = new global::System.Windows.Forms.NumericUpDown();
		this.btnEdit = new global::System.Windows.Forms.Button();
		this.label14 = new global::System.Windows.Forms.Label();
		this.recvClick1 = new global::System.Windows.Forms.NumericUpDown();
		this.recvClick2 = new global::System.Windows.Forms.NumericUpDown();
		this.sendClick2 = new global::System.Windows.Forms.NumericUpDown();
		this.sendClick1 = new global::System.Windows.Forms.NumericUpDown();
		this.label15 = new global::System.Windows.Forms.Label();
		this.label16 = new global::System.Windows.Forms.Label();
		this.label17 = new global::System.Windows.Forms.Label();
		this.atk1Map = new global::System.Windows.Forms.NumericUpDown();
		this.label18 = new global::System.Windows.Forms.Label();
		this.atk1Y = new global::System.Windows.Forms.NumericUpDown();
		this.label19 = new global::System.Windows.Forms.Label();
		this.atk1X = new global::System.Windows.Forms.NumericUpDown();
		this.label20 = new global::System.Windows.Forms.Label();
		this.atk1MD = new global::System.Windows.Forms.TextBox();
		this.atk2MD = new global::System.Windows.Forms.TextBox();
		this.label21 = new global::System.Windows.Forms.Label();
		this.atk2Map = new global::System.Windows.Forms.NumericUpDown();
		this.label22 = new global::System.Windows.Forms.Label();
		this.atk2Y = new global::System.Windows.Forms.NumericUpDown();
		this.label23 = new global::System.Windows.Forms.Label();
		this.atk2X = new global::System.Windows.Forms.NumericUpDown();
		this.label24 = new global::System.Windows.Forms.Label();
		this.label25 = new global::System.Windows.Forms.Label();
		this.atk3MD = new global::System.Windows.Forms.TextBox();
		this.label26 = new global::System.Windows.Forms.Label();
		this.atk3Map = new global::System.Windows.Forms.NumericUpDown();
		this.label27 = new global::System.Windows.Forms.Label();
		this.atk3Y = new global::System.Windows.Forms.NumericUpDown();
		this.label28 = new global::System.Windows.Forms.Label();
		this.atk3X = new global::System.Windows.Forms.NumericUpDown();
		this.label29 = new global::System.Windows.Forms.Label();
		this.label30 = new global::System.Windows.Forms.Label();
		this.button1 = new global::System.Windows.Forms.Button();
		this.txtInfoEx = new global::System.Windows.Forms.TextBox();
		this.label31 = new global::System.Windows.Forms.Label();
		this.numericUpDown1 = new global::System.Windows.Forms.NumericUpDown();
		this.numericUpDown2 = new global::System.Windows.Forms.NumericUpDown();
		this.label32 = new global::System.Windows.Forms.Label();
		this.btnGet = new global::System.Windows.Forms.Button();
		this.nudColloect = new global::System.Windows.Forms.NumericUpDown();
		this.label33 = new global::System.Windows.Forms.Label();
		this.chkPick = new global::System.Windows.Forms.CheckBox();
		this.chkIsThuThap = new global::System.Windows.Forms.CheckBox();
		this.chkCompleted = new global::System.Windows.Forms.CheckBox();
		this.chkUseItem = new global::System.Windows.Forms.CheckBox();
		this.label35 = new global::System.Windows.Forms.Label();
		this.txtName = new global::System.Windows.Forms.TextBox();
		this.chkComplete = new global::System.Windows.Forms.CheckBox();
		this.chkBienThan = new global::System.Windows.Forms.CheckBox();
		this.label34 = new global::System.Windows.Forms.Label();
		this.txtInfo = new global::System.Windows.Forms.TextBox();
		this.txtMonter = new global::System.Windows.Forms.TextBox();
		this.label36 = new global::System.Windows.Forms.Label();
		this.button2 = new global::System.Windows.Forms.Button();
		((global::System.ComponentModel.ISupportInitialize)this.recvID).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvX).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvY).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvMAP).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendMAP).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendY).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendX).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendID).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvClick1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvClick2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendClick2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendClick1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1Map).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1Y).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1X).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2Map).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2Y).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2X).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3Map).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3Y).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3X).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown1).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudColloect).BeginInit();
		base.SuspendLayout();
		this.txtID.Location = new global::System.Drawing.Point(134, 9);
		this.txtID.Name = "txtID";
		this.txtID.Size = new global::System.Drawing.Size(425, 20);
		this.txtID.TabIndex = 0;
		this.label1.AutoSize = true;
		this.label1.Location = new global::System.Drawing.Point(22, 12);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(18, 13);
		this.label1.TabIndex = 1;
		this.label1.Text = "ID";
		this.label2.AutoSize = true;
		this.label2.Location = new global::System.Drawing.Point(22, 38);
		this.label2.Name = "label2";
		this.label2.Size = new global::System.Drawing.Size(24, 13);
		this.label2.TabIndex = 3;
		this.label2.Text = "MD";
		this.txtMD.Location = new global::System.Drawing.Point(134, 35);
		this.txtMD.Name = "txtMD";
		this.txtMD.Size = new global::System.Drawing.Size(425, 20);
		this.txtMD.TabIndex = 2;
		this.label3.AutoSize = true;
		this.label3.Location = new global::System.Drawing.Point(22, 64);
		this.label3.Name = "label3";
		this.label3.Size = new global::System.Drawing.Size(33, 13);
		this.label3.TabIndex = 5;
		this.label3.Text = "Recv";
		this.label4.AutoSize = true;
		this.label4.Location = new global::System.Drawing.Point(22, 90);
		this.label4.Name = "label4";
		this.label4.Size = new global::System.Drawing.Size(32, 13);
		this.label4.TabIndex = 7;
		this.label4.Text = "Send";
		this.label5.AutoSize = true;
		this.label5.Location = new global::System.Drawing.Point(22, 116);
		this.label5.Name = "label5";
		this.label5.Size = new global::System.Drawing.Size(21, 13);
		this.label5.TabIndex = 9;
		this.label5.Text = "Do";
		this.txdDo.Location = new global::System.Drawing.Point(134, 113);
		this.txdDo.Name = "txdDo";
		this.txdDo.Size = new global::System.Drawing.Size(425, 20);
		this.txdDo.TabIndex = 8;
		this.recvID.Location = new global::System.Drawing.Point(163, 61);
		global::System.Windows.Forms.NumericUpDown numericUpDown = this.recvID;
		int[] array = new int[4];
		array[0] = 999;
		numericUpDown.Maximum = new decimal(array);
		this.recvID.Name = "recvID";
		this.recvID.Size = new global::System.Drawing.Size(62, 20);
		this.recvID.TabIndex = 10;
		this.label6.AutoSize = true;
		this.label6.Location = new global::System.Drawing.Point(139, 65);
		this.label6.Name = "label6";
		this.label6.Size = new global::System.Drawing.Size(18, 13);
		this.label6.TabIndex = 11;
		this.label6.Text = "ID";
		this.label7.AutoSize = true;
		this.label7.Location = new global::System.Drawing.Point(254, 66);
		this.label7.Name = "label7";
		this.label7.Size = new global::System.Drawing.Size(14, 13);
		this.label7.TabIndex = 13;
		this.label7.Text = "X";
		this.recvX.Location = new global::System.Drawing.Point(274, 62);
		global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.recvX;
		int[] array2 = new int[4];
		array2[0] = 999;
		numericUpDown2.Maximum = new decimal(array2);
		this.recvX.Name = "recvX";
		this.recvX.Size = new global::System.Drawing.Size(62, 20);
		this.recvX.TabIndex = 12;
		this.label8.AutoSize = true;
		this.label8.Location = new global::System.Drawing.Point(366, 65);
		this.label8.Name = "label8";
		this.label8.Size = new global::System.Drawing.Size(14, 13);
		this.label8.TabIndex = 15;
		this.label8.Text = "Y";
		this.recvY.Location = new global::System.Drawing.Point(386, 63);
		global::System.Windows.Forms.NumericUpDown numericUpDown3 = this.recvY;
		int[] array3 = new int[4];
		array3[0] = 999;
		numericUpDown3.Maximum = new decimal(array3);
		this.recvY.Name = "recvY";
		this.recvY.Size = new global::System.Drawing.Size(62, 20);
		this.recvY.TabIndex = 14;
		this.label9.AutoSize = true;
		this.label9.Location = new global::System.Drawing.Point(461, 64);
		this.label9.Name = "label9";
		this.label9.Size = new global::System.Drawing.Size(30, 13);
		this.label9.TabIndex = 17;
		this.label9.Text = "MAP";
		this.recvMAP.Location = new global::System.Drawing.Point(497, 62);
		global::System.Windows.Forms.NumericUpDown numericUpDown4 = this.recvMAP;
		int[] array4 = new int[4];
		array4[0] = 999;
		numericUpDown4.Maximum = new decimal(array4);
		this.recvMAP.Name = "recvMAP";
		this.recvMAP.Size = new global::System.Drawing.Size(62, 20);
		this.recvMAP.TabIndex = 16;
		this.label10.AutoSize = true;
		this.label10.Location = new global::System.Drawing.Point(461, 90);
		this.label10.Name = "label10";
		this.label10.Size = new global::System.Drawing.Size(30, 13);
		this.label10.TabIndex = 25;
		this.label10.Text = "MAP";
		this.sendMAP.Location = new global::System.Drawing.Point(497, 88);
		global::System.Windows.Forms.NumericUpDown numericUpDown5 = this.sendMAP;
		int[] array5 = new int[4];
		array5[0] = 999;
		numericUpDown5.Maximum = new decimal(array5);
		this.sendMAP.Name = "sendMAP";
		this.sendMAP.Size = new global::System.Drawing.Size(62, 20);
		this.sendMAP.TabIndex = 24;
		this.label11.AutoSize = true;
		this.label11.Location = new global::System.Drawing.Point(366, 91);
		this.label11.Name = "label11";
		this.label11.Size = new global::System.Drawing.Size(14, 13);
		this.label11.TabIndex = 23;
		this.label11.Text = "Y";
		this.sendY.Location = new global::System.Drawing.Point(386, 89);
		global::System.Windows.Forms.NumericUpDown numericUpDown6 = this.sendY;
		int[] array6 = new int[4];
		array6[0] = 999;
		numericUpDown6.Maximum = new decimal(array6);
		this.sendY.Name = "sendY";
		this.sendY.Size = new global::System.Drawing.Size(62, 20);
		this.sendY.TabIndex = 22;
		this.label12.AutoSize = true;
		this.label12.Location = new global::System.Drawing.Point(254, 92);
		this.label12.Name = "label12";
		this.label12.Size = new global::System.Drawing.Size(14, 13);
		this.label12.TabIndex = 21;
		this.label12.Text = "X";
		this.sendX.Location = new global::System.Drawing.Point(274, 88);
		global::System.Windows.Forms.NumericUpDown numericUpDown7 = this.sendX;
		int[] array7 = new int[4];
		array7[0] = 999;
		numericUpDown7.Maximum = new decimal(array7);
		this.sendX.Name = "sendX";
		this.sendX.Size = new global::System.Drawing.Size(62, 20);
		this.sendX.TabIndex = 20;
		this.label13.AutoSize = true;
		this.label13.Location = new global::System.Drawing.Point(139, 91);
		this.label13.Name = "label13";
		this.label13.Size = new global::System.Drawing.Size(18, 13);
		this.label13.TabIndex = 19;
		this.label13.Text = "ID";
		this.sendID.Location = new global::System.Drawing.Point(163, 87);
		global::System.Windows.Forms.NumericUpDown numericUpDown8 = this.sendID;
		int[] array8 = new int[4];
		array8[0] = 999;
		numericUpDown8.Maximum = new decimal(array8);
		this.sendID.Name = "sendID";
		this.sendID.Size = new global::System.Drawing.Size(62, 20);
		this.sendID.TabIndex = 18;
		this.btnEdit.Location = new global::System.Drawing.Point(484, 275);
		this.btnEdit.Name = "btnEdit";
		this.btnEdit.Size = new global::System.Drawing.Size(75, 23);
		this.btnEdit.TabIndex = 26;
		this.btnEdit.Text = "Save";
		this.btnEdit.UseVisualStyleBackColor = true;
		this.btnEdit.Click += new global::System.EventHandler(this.btnEdit_Click);
		this.label14.AutoSize = true;
		this.label14.Location = new global::System.Drawing.Point(570, 12);
		this.label14.Name = "label14";
		this.label14.Size = new global::System.Drawing.Size(30, 13);
		this.label14.TabIndex = 28;
		this.label14.Text = "Click";
		this.recvClick1.Location = new global::System.Drawing.Point(606, 10);
		global::System.Windows.Forms.NumericUpDown numericUpDown9 = this.recvClick1;
		int[] array9 = new int[4];
		array9[0] = 99999;
		numericUpDown9.Maximum = new decimal(array9);
		this.recvClick1.Name = "recvClick1";
		this.recvClick1.Size = new global::System.Drawing.Size(62, 20);
		this.recvClick1.TabIndex = 29;
		this.recvClick1.ValueChanged += new global::System.EventHandler(this.recvClick1_ValueChanged);
		this.recvClick2.Location = new global::System.Drawing.Point(674, 10);
		global::System.Windows.Forms.NumericUpDown numericUpDown10 = this.recvClick2;
		int[] array10 = new int[4];
		array10[0] = 999;
		numericUpDown10.Maximum = new decimal(array10);
		this.recvClick2.Name = "recvClick2";
		this.recvClick2.Size = new global::System.Drawing.Size(62, 20);
		this.recvClick2.TabIndex = 30;
		this.sendClick2.Location = new global::System.Drawing.Point(674, 36);
		global::System.Windows.Forms.NumericUpDown numericUpDown11 = this.sendClick2;
		int[] array11 = new int[4];
		array11[0] = 999;
		numericUpDown11.Maximum = new decimal(array11);
		this.sendClick2.Name = "sendClick2";
		this.sendClick2.Size = new global::System.Drawing.Size(62, 20);
		this.sendClick2.TabIndex = 33;
		this.sendClick1.Location = new global::System.Drawing.Point(606, 36);
		global::System.Windows.Forms.NumericUpDown numericUpDown12 = this.sendClick1;
		int[] array12 = new int[4];
		array12[0] = 99999;
		numericUpDown12.Maximum = new decimal(array12);
		this.sendClick1.Name = "sendClick1";
		this.sendClick1.Size = new global::System.Drawing.Size(62, 20);
		this.sendClick1.TabIndex = 32;
		this.label15.AutoSize = true;
		this.label15.Location = new global::System.Drawing.Point(570, 38);
		this.label15.Name = "label15";
		this.label15.Size = new global::System.Drawing.Size(30, 13);
		this.label15.TabIndex = 31;
		this.label15.Text = "Click";
		this.label16.AutoSize = true;
		this.label16.Location = new global::System.Drawing.Point(23, 142);
		this.label16.Name = "label16";
		this.label16.Size = new global::System.Drawing.Size(32, 13);
		this.label16.TabIndex = 34;
		this.label16.Text = "Atk 1";
		this.label17.AutoSize = true;
		this.label17.Location = new global::System.Drawing.Point(461, 141);
		this.label17.Name = "label17";
		this.label17.Size = new global::System.Drawing.Size(30, 13);
		this.label17.TabIndex = 42;
		this.label17.Text = "MAP";
		this.atk1Map.Location = new global::System.Drawing.Point(497, 139);
		global::System.Windows.Forms.NumericUpDown numericUpDown13 = this.atk1Map;
		int[] array13 = new int[4];
		array13[0] = 999;
		numericUpDown13.Maximum = new decimal(array13);
		this.atk1Map.Name = "atk1Map";
		this.atk1Map.Size = new global::System.Drawing.Size(62, 20);
		this.atk1Map.TabIndex = 41;
		this.atk1Map.ValueChanged += new global::System.EventHandler(this.atk1Map_ValueChanged);
		this.label18.AutoSize = true;
		this.label18.Location = new global::System.Drawing.Point(366, 142);
		this.label18.Name = "label18";
		this.label18.Size = new global::System.Drawing.Size(14, 13);
		this.label18.TabIndex = 40;
		this.label18.Text = "Y";
		this.atk1Y.Location = new global::System.Drawing.Point(386, 140);
		global::System.Windows.Forms.NumericUpDown numericUpDown14 = this.atk1Y;
		int[] array14 = new int[4];
		array14[0] = 999;
		numericUpDown14.Maximum = new decimal(array14);
		this.atk1Y.Name = "atk1Y";
		this.atk1Y.Size = new global::System.Drawing.Size(62, 20);
		this.atk1Y.TabIndex = 39;
		this.atk1Y.ValueChanged += new global::System.EventHandler(this.atk1Y_ValueChanged);
		this.label19.AutoSize = true;
		this.label19.Location = new global::System.Drawing.Point(254, 143);
		this.label19.Name = "label19";
		this.label19.Size = new global::System.Drawing.Size(14, 13);
		this.label19.TabIndex = 38;
		this.label19.Text = "X";
		this.atk1X.Location = new global::System.Drawing.Point(274, 139);
		global::System.Windows.Forms.NumericUpDown numericUpDown15 = this.atk1X;
		int[] array15 = new int[4];
		array15[0] = 999;
		numericUpDown15.Maximum = new decimal(array15);
		this.atk1X.Name = "atk1X";
		this.atk1X.Size = new global::System.Drawing.Size(62, 20);
		this.atk1X.TabIndex = 37;
		this.atk1X.ValueChanged += new global::System.EventHandler(this.atk1X_ValueChanged);
		this.label20.AutoSize = true;
		this.label20.Location = new global::System.Drawing.Point(133, 142);
		this.label20.Name = "label20";
		this.label20.Size = new global::System.Drawing.Size(24, 13);
		this.label20.TabIndex = 36;
		this.label20.Text = "MD";
		this.atk1MD.Location = new global::System.Drawing.Point(163, 138);
		this.atk1MD.Name = "atk1MD";
		this.atk1MD.Size = new global::System.Drawing.Size(62, 20);
		this.atk1MD.TabIndex = 43;
		this.atk1MD.TextChanged += new global::System.EventHandler(this.atk1MD_TextChanged);
		this.atk2MD.Location = new global::System.Drawing.Point(163, 164);
		this.atk2MD.Name = "atk2MD";
		this.atk2MD.Size = new global::System.Drawing.Size(62, 20);
		this.atk2MD.TabIndex = 52;
		this.atk2MD.Text = "000";
		this.label21.AutoSize = true;
		this.label21.Location = new global::System.Drawing.Point(461, 167);
		this.label21.Name = "label21";
		this.label21.Size = new global::System.Drawing.Size(30, 13);
		this.label21.TabIndex = 51;
		this.label21.Text = "MAP";
		this.atk2Map.Location = new global::System.Drawing.Point(497, 165);
		global::System.Windows.Forms.NumericUpDown numericUpDown16 = this.atk2Map;
		int[] array16 = new int[4];
		array16[0] = 999;
		numericUpDown16.Maximum = new decimal(array16);
		this.atk2Map.Name = "atk2Map";
		this.atk2Map.Size = new global::System.Drawing.Size(62, 20);
		this.atk2Map.TabIndex = 50;
		this.atk2Map.ValueChanged += new global::System.EventHandler(this.atk2Map_ValueChanged);
		this.label22.AutoSize = true;
		this.label22.Location = new global::System.Drawing.Point(366, 168);
		this.label22.Name = "label22";
		this.label22.Size = new global::System.Drawing.Size(14, 13);
		this.label22.TabIndex = 49;
		this.label22.Text = "Y";
		this.atk2Y.Location = new global::System.Drawing.Point(386, 166);
		global::System.Windows.Forms.NumericUpDown numericUpDown17 = this.atk2Y;
		int[] array17 = new int[4];
		array17[0] = 999;
		numericUpDown17.Maximum = new decimal(array17);
		this.atk2Y.Name = "atk2Y";
		this.atk2Y.Size = new global::System.Drawing.Size(62, 20);
		this.atk2Y.TabIndex = 48;
		this.atk2Y.ValueChanged += new global::System.EventHandler(this.atk2Y_ValueChanged);
		this.label23.AutoSize = true;
		this.label23.Location = new global::System.Drawing.Point(254, 169);
		this.label23.Name = "label23";
		this.label23.Size = new global::System.Drawing.Size(14, 13);
		this.label23.TabIndex = 47;
		this.label23.Text = "X";
		this.atk2X.Location = new global::System.Drawing.Point(274, 165);
		global::System.Windows.Forms.NumericUpDown numericUpDown18 = this.atk2X;
		int[] array18 = new int[4];
		array18[0] = 999;
		numericUpDown18.Maximum = new decimal(array18);
		this.atk2X.Name = "atk2X";
		this.atk2X.Size = new global::System.Drawing.Size(62, 20);
		this.atk2X.TabIndex = 46;
		this.atk2X.ValueChanged += new global::System.EventHandler(this.atk2X_ValueChanged);
		this.label24.AutoSize = true;
		this.label24.Location = new global::System.Drawing.Point(133, 168);
		this.label24.Name = "label24";
		this.label24.Size = new global::System.Drawing.Size(24, 13);
		this.label24.TabIndex = 45;
		this.label24.Text = "MD";
		this.label25.AutoSize = true;
		this.label25.Location = new global::System.Drawing.Point(23, 168);
		this.label25.Name = "label25";
		this.label25.Size = new global::System.Drawing.Size(32, 13);
		this.label25.TabIndex = 44;
		this.label25.Text = "Atk 2";
		this.atk3MD.Location = new global::System.Drawing.Point(163, 190);
		this.atk3MD.Name = "atk3MD";
		this.atk3MD.Size = new global::System.Drawing.Size(62, 20);
		this.atk3MD.TabIndex = 61;
		this.atk3MD.Text = "000";
		this.label26.AutoSize = true;
		this.label26.Location = new global::System.Drawing.Point(461, 193);
		this.label26.Name = "label26";
		this.label26.Size = new global::System.Drawing.Size(30, 13);
		this.label26.TabIndex = 60;
		this.label26.Text = "MAP";
		this.atk3Map.Location = new global::System.Drawing.Point(497, 191);
		global::System.Windows.Forms.NumericUpDown numericUpDown19 = this.atk3Map;
		int[] array19 = new int[4];
		array19[0] = 999;
		numericUpDown19.Maximum = new decimal(array19);
		this.atk3Map.Name = "atk3Map";
		this.atk3Map.Size = new global::System.Drawing.Size(62, 20);
		this.atk3Map.TabIndex = 59;
		this.atk3Map.ValueChanged += new global::System.EventHandler(this.atk3Map_ValueChanged);
		this.label27.AutoSize = true;
		this.label27.Location = new global::System.Drawing.Point(366, 194);
		this.label27.Name = "label27";
		this.label27.Size = new global::System.Drawing.Size(14, 13);
		this.label27.TabIndex = 58;
		this.label27.Text = "Y";
		this.atk3Y.Location = new global::System.Drawing.Point(386, 192);
		global::System.Windows.Forms.NumericUpDown numericUpDown20 = this.atk3Y;
		int[] array20 = new int[4];
		array20[0] = 999;
		numericUpDown20.Maximum = new decimal(array20);
		this.atk3Y.Name = "atk3Y";
		this.atk3Y.Size = new global::System.Drawing.Size(62, 20);
		this.atk3Y.TabIndex = 57;
		this.atk3Y.ValueChanged += new global::System.EventHandler(this.atk3Y_ValueChanged);
		this.label28.AutoSize = true;
		this.label28.Location = new global::System.Drawing.Point(254, 195);
		this.label28.Name = "label28";
		this.label28.Size = new global::System.Drawing.Size(14, 13);
		this.label28.TabIndex = 56;
		this.label28.Text = "X";
		this.atk3X.Location = new global::System.Drawing.Point(274, 191);
		global::System.Windows.Forms.NumericUpDown numericUpDown21 = this.atk3X;
		int[] array21 = new int[4];
		array21[0] = 999;
		numericUpDown21.Maximum = new decimal(array21);
		this.atk3X.Name = "atk3X";
		this.atk3X.Size = new global::System.Drawing.Size(62, 20);
		this.atk3X.TabIndex = 55;
		this.atk3X.ValueChanged += new global::System.EventHandler(this.atk3X_ValueChanged);
		this.label29.AutoSize = true;
		this.label29.Location = new global::System.Drawing.Point(133, 194);
		this.label29.Name = "label29";
		this.label29.Size = new global::System.Drawing.Size(24, 13);
		this.label29.TabIndex = 54;
		this.label29.Text = "MD";
		this.label30.AutoSize = true;
		this.label30.Location = new global::System.Drawing.Point(23, 194);
		this.label30.Name = "label30";
		this.label30.Size = new global::System.Drawing.Size(32, 13);
		this.label30.TabIndex = 53;
		this.label30.Text = "Atk 3";
		this.button1.Location = new global::System.Drawing.Point(646, 138);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(75, 23);
		this.button1.TabIndex = 62;
		this.button1.Text = "Chage Do";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.txtInfoEx.Location = new global::System.Drawing.Point(25, 219);
		this.txtInfoEx.Name = "txtInfoEx";
		this.txtInfoEx.Size = new global::System.Drawing.Size(534, 20);
		this.txtInfoEx.TabIndex = 65;
		this.txtInfoEx.TextChanged += new global::System.EventHandler(this.txtInfoEx_TextChanged);
		this.label31.AutoSize = true;
		this.label31.Location = new global::System.Drawing.Point(572, 65);
		this.label31.Name = "label31";
		this.label31.Size = new global::System.Drawing.Size(99, 13);
		this.label31.TabIndex = 68;
		this.label31.Text = "Complete Index Nội";
		this.numericUpDown1.Location = new global::System.Drawing.Point(689, 63);
		this.numericUpDown1.Name = "numericUpDown1";
		this.numericUpDown1.Size = new global::System.Drawing.Size(68, 20);
		this.numericUpDown1.TabIndex = 69;
		this.numericUpDown1.ValueChanged += new global::System.EventHandler(this.numericUpDown1_ValueChanged);
		this.numericUpDown2.Location = new global::System.Drawing.Point(689, 89);
		this.numericUpDown2.Name = "numericUpDown2";
		this.numericUpDown2.Size = new global::System.Drawing.Size(68, 20);
		this.numericUpDown2.TabIndex = 70;
		this.numericUpDown2.ValueChanged += new global::System.EventHandler(this.numericUpDown2_ValueChanged);
		this.label32.AutoSize = true;
		this.label32.Location = new global::System.Drawing.Point(572, 93);
		this.label32.Name = "label32";
		this.label32.Size = new global::System.Drawing.Size(111, 13);
		this.label32.TabIndex = 71;
		this.label32.Text = "Complete Index Ngoại";
		this.btnGet.Location = new global::System.Drawing.Point(565, 137);
		this.btnGet.Name = "btnGet";
		this.btnGet.Size = new global::System.Drawing.Size(75, 23);
		this.btnGet.TabIndex = 72;
		this.btnGet.Text = "Get";
		this.btnGet.UseVisualStyleBackColor = true;
		this.btnGet.Click += new global::System.EventHandler(this.btnGet_Click);
		this.nudColloect.Location = new global::System.Drawing.Point(689, 112);
		this.nudColloect.Name = "nudColloect";
		this.nudColloect.Size = new global::System.Drawing.Size(68, 20);
		this.nudColloect.TabIndex = 73;
		this.nudColloect.ValueChanged += new global::System.EventHandler(this.nudColloect_ValueChanged);
		this.label33.AutoSize = true;
		this.label33.Location = new global::System.Drawing.Point(570, 114);
		this.label33.Name = "label33";
		this.label33.Size = new global::System.Drawing.Size(39, 13);
		this.label33.TabIndex = 74;
		this.label33.Text = "Collect";
		this.chkPick.AutoSize = true;
		this.chkPick.Location = new global::System.Drawing.Point(36, 246);
		this.chkPick.Name = "chkPick";
		this.chkPick.Size = new global::System.Drawing.Size(55, 17);
		this.chkPick.TabIndex = 77;
		this.chkPick.Text = "IsPick";
		this.chkPick.UseVisualStyleBackColor = true;
		this.chkPick.CheckedChanged += new global::System.EventHandler(this.chkPick_CheckedChanged);
		this.chkIsThuThap.AutoSize = true;
		this.chkIsThuThap.Location = new global::System.Drawing.Point(97, 245);
		this.chkIsThuThap.Name = "chkIsThuThap";
		this.chkIsThuThap.Size = new global::System.Drawing.Size(78, 17);
		this.chkIsThuThap.TabIndex = 78;
		this.chkIsThuThap.Text = "IsThuThap";
		this.chkIsThuThap.UseVisualStyleBackColor = true;
		this.chkIsThuThap.CheckedChanged += new global::System.EventHandler(this.chkIsThuThap_CheckedChanged);
		this.chkCompleted.AutoSize = true;
		this.chkCompleted.Location = new global::System.Drawing.Point(181, 245);
		this.chkCompleted.Name = "chkCompleted";
		this.chkCompleted.Size = new global::System.Drawing.Size(76, 17);
		this.chkCompleted.TabIndex = 79;
		this.chkCompleted.Text = "Completed";
		this.chkCompleted.UseVisualStyleBackColor = true;
		this.chkCompleted.CheckedChanged += new global::System.EventHandler(this.chkCompleted_CheckedChanged);
		this.chkUseItem.AutoSize = true;
		this.chkUseItem.Location = new global::System.Drawing.Point(263, 245);
		this.chkUseItem.Name = "chkUseItem";
		this.chkUseItem.Size = new global::System.Drawing.Size(65, 17);
		this.chkUseItem.TabIndex = 80;
		this.chkUseItem.Text = "UseItem";
		this.chkUseItem.UseVisualStyleBackColor = true;
		this.chkUseItem.CheckedChanged += new global::System.EventHandler(this.chkUseItem_CheckedChanged);
		this.label35.AutoSize = true;
		this.label35.Location = new global::System.Drawing.Point(22, 280);
		this.label35.Name = "label35";
		this.label35.Size = new global::System.Drawing.Size(35, 13);
		this.label35.TabIndex = 82;
		this.label35.Text = "Name";
		this.txtName.Location = new global::System.Drawing.Point(63, 277);
		this.txtName.Name = "txtName";
		this.txtName.Size = new global::System.Drawing.Size(374, 20);
		this.txtName.TabIndex = 81;
		this.chkComplete.AutoSize = true;
		this.chkComplete.Location = new global::System.Drawing.Point(334, 245);
		this.chkComplete.Name = "chkComplete";
		this.chkComplete.Size = new global::System.Drawing.Size(81, 17);
		this.chkComplete.TabIndex = 83;
		this.chkComplete.Text = "Is Complete";
		this.chkComplete.UseVisualStyleBackColor = true;
		this.chkComplete.CheckedChanged += new global::System.EventHandler(this.chkComplete_CheckedChanged);
		this.chkBienThan.AutoSize = true;
		this.chkBienThan.Location = new global::System.Drawing.Point(421, 245);
		this.chkBienThan.Name = "chkBienThan";
		this.chkBienThan.Size = new global::System.Drawing.Size(75, 17);
		this.chkBienThan.TabIndex = 84;
		this.chkBienThan.Text = "Biến Thân";
		this.chkBienThan.UseVisualStyleBackColor = true;
		this.chkBienThan.CheckedChanged += new global::System.EventHandler(this.chkBienThan_CheckedChanged);
		this.label34.AutoSize = true;
		this.label34.Location = new global::System.Drawing.Point(22, 306);
		this.label34.Name = "label34";
		this.label34.Size = new global::System.Drawing.Size(25, 13);
		this.label34.TabIndex = 86;
		this.label34.Text = "Info";
		this.txtInfo.Location = new global::System.Drawing.Point(63, 303);
		this.txtInfo.Name = "txtInfo";
		this.txtInfo.Size = new global::System.Drawing.Size(374, 20);
		this.txtInfo.TabIndex = 85;
		this.txtMonter.Location = new global::System.Drawing.Point(63, 329);
		this.txtMonter.Name = "txtMonter";
		this.txtMonter.Size = new global::System.Drawing.Size(374, 20);
		this.txtMonter.TabIndex = 87;
		this.label36.AutoSize = true;
		this.label36.Location = new global::System.Drawing.Point(14, 332);
		this.label36.Name = "label36";
		this.label36.Size = new global::System.Drawing.Size(40, 13);
		this.label36.TabIndex = 88;
		this.label36.Text = "Monter";
		this.button2.Location = new global::System.Drawing.Point(593, 274);
		this.button2.Name = "button2";
		this.button2.Size = new global::System.Drawing.Size(75, 23);
		this.button2.TabIndex = 89;
		this.button2.Text = "Save";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += new global::System.EventHandler(this.button2_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(965, 448);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.label36);
		base.Controls.Add(this.txtMonter);
		base.Controls.Add(this.label34);
		base.Controls.Add(this.txtInfo);
		base.Controls.Add(this.chkBienThan);
		base.Controls.Add(this.chkComplete);
		base.Controls.Add(this.label35);
		base.Controls.Add(this.txtName);
		base.Controls.Add(this.chkUseItem);
		base.Controls.Add(this.chkCompleted);
		base.Controls.Add(this.chkIsThuThap);
		base.Controls.Add(this.chkPick);
		base.Controls.Add(this.label33);
		base.Controls.Add(this.nudColloect);
		base.Controls.Add(this.btnGet);
		base.Controls.Add(this.label32);
		base.Controls.Add(this.numericUpDown2);
		base.Controls.Add(this.numericUpDown1);
		base.Controls.Add(this.label31);
		base.Controls.Add(this.txtInfoEx);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.atk3MD);
		base.Controls.Add(this.label26);
		base.Controls.Add(this.atk3Map);
		base.Controls.Add(this.label27);
		base.Controls.Add(this.atk3Y);
		base.Controls.Add(this.label28);
		base.Controls.Add(this.atk3X);
		base.Controls.Add(this.label29);
		base.Controls.Add(this.label30);
		base.Controls.Add(this.atk2MD);
		base.Controls.Add(this.label21);
		base.Controls.Add(this.atk2Map);
		base.Controls.Add(this.label22);
		base.Controls.Add(this.atk2Y);
		base.Controls.Add(this.label23);
		base.Controls.Add(this.atk2X);
		base.Controls.Add(this.label24);
		base.Controls.Add(this.label25);
		base.Controls.Add(this.atk1MD);
		base.Controls.Add(this.label17);
		base.Controls.Add(this.atk1Map);
		base.Controls.Add(this.label18);
		base.Controls.Add(this.atk1Y);
		base.Controls.Add(this.label19);
		base.Controls.Add(this.atk1X);
		base.Controls.Add(this.label20);
		base.Controls.Add(this.label16);
		base.Controls.Add(this.sendClick2);
		base.Controls.Add(this.sendClick1);
		base.Controls.Add(this.label15);
		base.Controls.Add(this.recvClick2);
		base.Controls.Add(this.recvClick1);
		base.Controls.Add(this.label14);
		base.Controls.Add(this.btnEdit);
		base.Controls.Add(this.label10);
		base.Controls.Add(this.sendMAP);
		base.Controls.Add(this.label11);
		base.Controls.Add(this.sendY);
		base.Controls.Add(this.label12);
		base.Controls.Add(this.sendX);
		base.Controls.Add(this.label13);
		base.Controls.Add(this.sendID);
		base.Controls.Add(this.label9);
		base.Controls.Add(this.recvMAP);
		base.Controls.Add(this.label8);
		base.Controls.Add(this.recvY);
		base.Controls.Add(this.label7);
		base.Controls.Add(this.recvX);
		base.Controls.Add(this.label6);
		base.Controls.Add(this.recvID);
		base.Controls.Add(this.label5);
		base.Controls.Add(this.txdDo);
		base.Controls.Add(this.label4);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.txtMD);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.txtID);
		base.Name = "ScriptManager";
		this.Text = "ScriptManager";
		base.Load += new global::System.EventHandler(this.ScriptManager_Load);
		((global::System.ComponentModel.ISupportInitialize)this.recvID).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvX).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvY).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvMAP).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendMAP).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendY).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendX).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendID).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvClick1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.recvClick2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendClick2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.sendClick1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1Map).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1Y).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk1X).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2Map).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2Y).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk2X).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3Map).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3Y).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.atk3X).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown1).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.nudColloect).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04001A38 RID: 6712
	private global::System.Windows.Forms.TextBox txtID;

	// Token: 0x04001A39 RID: 6713
	private global::System.Windows.Forms.Label label1;

	// Token: 0x04001A3A RID: 6714
	private global::System.Windows.Forms.Label label2;

	// Token: 0x04001A3B RID: 6715
	private global::System.Windows.Forms.TextBox txtMD;

	// Token: 0x04001A3C RID: 6716
	private global::System.Windows.Forms.Label label3;

	// Token: 0x04001A3D RID: 6717
	private global::System.Windows.Forms.Label label4;

	// Token: 0x04001A3E RID: 6718
	private global::System.Windows.Forms.Label label5;

	// Token: 0x04001A3F RID: 6719
	private global::System.Windows.Forms.TextBox txdDo;

	// Token: 0x04001A40 RID: 6720
	private global::System.Windows.Forms.NumericUpDown recvID;

	// Token: 0x04001A41 RID: 6721
	private global::System.Windows.Forms.Label label6;

	// Token: 0x04001A42 RID: 6722
	private global::System.Windows.Forms.Label label7;

	// Token: 0x04001A43 RID: 6723
	private global::System.Windows.Forms.NumericUpDown recvX;

	// Token: 0x04001A44 RID: 6724
	private global::System.Windows.Forms.Label label8;

	// Token: 0x04001A45 RID: 6725
	private global::System.Windows.Forms.NumericUpDown recvY;

	// Token: 0x04001A46 RID: 6726
	private global::System.Windows.Forms.Label label9;

	// Token: 0x04001A47 RID: 6727
	private global::System.Windows.Forms.NumericUpDown recvMAP;

	// Token: 0x04001A48 RID: 6728
	private global::System.Windows.Forms.Label label10;

	// Token: 0x04001A49 RID: 6729
	private global::System.Windows.Forms.NumericUpDown sendMAP;

	// Token: 0x04001A4A RID: 6730
	private global::System.Windows.Forms.Label label11;

	// Token: 0x04001A4B RID: 6731
	private global::System.Windows.Forms.NumericUpDown sendY;

	// Token: 0x04001A4C RID: 6732
	private global::System.Windows.Forms.Label label12;

	// Token: 0x04001A4D RID: 6733
	private global::System.Windows.Forms.NumericUpDown sendX;

	// Token: 0x04001A4E RID: 6734
	private global::System.Windows.Forms.Label label13;

	// Token: 0x04001A4F RID: 6735
	private global::System.Windows.Forms.NumericUpDown sendID;

	// Token: 0x04001A50 RID: 6736
	private global::System.Windows.Forms.Button btnEdit;

	// Token: 0x04001A51 RID: 6737
	private global::System.Windows.Forms.Label label14;

	// Token: 0x04001A52 RID: 6738
	private global::System.Windows.Forms.NumericUpDown recvClick1;

	// Token: 0x04001A53 RID: 6739
	private global::System.Windows.Forms.NumericUpDown recvClick2;

	// Token: 0x04001A54 RID: 6740
	private global::System.Windows.Forms.NumericUpDown sendClick2;

	// Token: 0x04001A55 RID: 6741
	private global::System.Windows.Forms.NumericUpDown sendClick1;

	// Token: 0x04001A56 RID: 6742
	private global::System.Windows.Forms.Label label15;

	// Token: 0x04001A57 RID: 6743
	private global::System.Windows.Forms.Label label16;

	// Token: 0x04001A58 RID: 6744
	private global::System.Windows.Forms.Label label17;

	// Token: 0x04001A59 RID: 6745
	private global::System.Windows.Forms.NumericUpDown atk1Map;

	// Token: 0x04001A5A RID: 6746
	private global::System.Windows.Forms.Label label18;

	// Token: 0x04001A5B RID: 6747
	private global::System.Windows.Forms.NumericUpDown atk1Y;

	// Token: 0x04001A5C RID: 6748
	private global::System.Windows.Forms.Label label19;

	// Token: 0x04001A5D RID: 6749
	private global::System.Windows.Forms.NumericUpDown atk1X;

	// Token: 0x04001A5E RID: 6750
	private global::System.Windows.Forms.Label label20;

	// Token: 0x04001A5F RID: 6751
	private global::System.Windows.Forms.TextBox atk1MD;

	// Token: 0x04001A60 RID: 6752
	private global::System.Windows.Forms.TextBox atk2MD;

	// Token: 0x04001A61 RID: 6753
	private global::System.Windows.Forms.Label label21;

	// Token: 0x04001A62 RID: 6754
	private global::System.Windows.Forms.NumericUpDown atk2Map;

	// Token: 0x04001A63 RID: 6755
	private global::System.Windows.Forms.Label label22;

	// Token: 0x04001A64 RID: 6756
	private global::System.Windows.Forms.NumericUpDown atk2Y;

	// Token: 0x04001A65 RID: 6757
	private global::System.Windows.Forms.Label label23;

	// Token: 0x04001A66 RID: 6758
	private global::System.Windows.Forms.NumericUpDown atk2X;

	// Token: 0x04001A67 RID: 6759
	private global::System.Windows.Forms.Label label24;

	// Token: 0x04001A68 RID: 6760
	private global::System.Windows.Forms.Label label25;

	// Token: 0x04001A69 RID: 6761
	private global::System.Windows.Forms.TextBox atk3MD;

	// Token: 0x04001A6A RID: 6762
	private global::System.Windows.Forms.Label label26;

	// Token: 0x04001A6B RID: 6763
	private global::System.Windows.Forms.NumericUpDown atk3Map;

	// Token: 0x04001A6C RID: 6764
	private global::System.Windows.Forms.Label label27;

	// Token: 0x04001A6D RID: 6765
	private global::System.Windows.Forms.NumericUpDown atk3Y;

	// Token: 0x04001A6E RID: 6766
	private global::System.Windows.Forms.Label label28;

	// Token: 0x04001A6F RID: 6767
	private global::System.Windows.Forms.NumericUpDown atk3X;

	// Token: 0x04001A70 RID: 6768
	private global::System.Windows.Forms.Label label29;

	// Token: 0x04001A71 RID: 6769
	private global::System.Windows.Forms.Label label30;

	// Token: 0x04001A72 RID: 6770
	private global::System.Windows.Forms.Button button1;

	// Token: 0x04001A73 RID: 6771
	private global::System.Windows.Forms.TextBox txtInfoEx;

	// Token: 0x04001A74 RID: 6772
	private global::System.Windows.Forms.Label label31;

	// Token: 0x04001A75 RID: 6773
	private global::System.Windows.Forms.NumericUpDown numericUpDown1;

	// Token: 0x04001A76 RID: 6774
	private global::System.Windows.Forms.NumericUpDown numericUpDown2;

	// Token: 0x04001A77 RID: 6775
	private global::System.Windows.Forms.Label label32;

	// Token: 0x04001A78 RID: 6776
	private global::System.Windows.Forms.Button btnGet;

	// Token: 0x04001A79 RID: 6777
	private global::System.Windows.Forms.NumericUpDown nudColloect;

	// Token: 0x04001A7A RID: 6778
	private global::System.Windows.Forms.Label label33;

	// Token: 0x04001A7B RID: 6779
	private global::System.Windows.Forms.CheckBox chkPick;

	// Token: 0x04001A7C RID: 6780
	private global::System.Windows.Forms.CheckBox chkIsThuThap;

	// Token: 0x04001A7D RID: 6781
	private global::System.Windows.Forms.CheckBox chkCompleted;

	// Token: 0x04001A7E RID: 6782
	private global::System.Windows.Forms.CheckBox chkUseItem;

	// Token: 0x04001A7F RID: 6783
	private global::System.Windows.Forms.Label label35;

	// Token: 0x04001A80 RID: 6784
	private global::System.Windows.Forms.TextBox txtName;

	// Token: 0x04001A81 RID: 6785
	private global::System.Windows.Forms.CheckBox chkComplete;

	// Token: 0x04001A82 RID: 6786
	private global::System.Windows.Forms.CheckBox chkBienThan;

	// Token: 0x04001A83 RID: 6787
	private global::System.Windows.Forms.Label label34;

	// Token: 0x04001A84 RID: 6788
	private global::System.Windows.Forms.TextBox txtInfo;

	// Token: 0x04001A85 RID: 6789
	private global::System.Windows.Forms.TextBox txtMonter;

	// Token: 0x04001A86 RID: 6790
	private global::System.Windows.Forms.Label label36;

	// Token: 0x04001A87 RID: 6791
	private global::System.Windows.Forms.Button button2;
}
