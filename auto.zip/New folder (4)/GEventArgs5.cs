﻿using System;
using System.IO;
using System.Security.Principal;
using System.Text;

// Token: 0x02000069 RID: 105
public class GEventArgs5 : EventArgs
{
	// Token: 0x06000460 RID: 1120 RVA: 0x00005CAC File Offset: 0x00003EAC
	internal GEventArgs5(GClass38 gclass38_1, string string_1)
	{
		this.gclass38_0 = gclass38_1;
		this.string_0 = string_1;
	}

	// Token: 0x1700011D RID: 285
	// (get) Token: 0x06000461 RID: 1121 RVA: 0x00005CC2 File Offset: 0x00003EC2
	public GClass40 GClass40_0
	{
		get
		{
			return this.gclass38_0.GClass40_0;
		}
	}

	// Token: 0x1700011E RID: 286
	// (get) Token: 0x06000462 RID: 1122 RVA: 0x00005CCF File Offset: 0x00003ECF
	public GClass41 GClass41_0
	{
		get
		{
			return this.gclass38_0.GClass41_0;
		}
	}

	// Token: 0x1700011F RID: 287
	// (get) Token: 0x06000463 RID: 1123 RVA: 0x00005CDC File Offset: 0x00003EDC
	public IPrincipal IPrincipal_0
	{
		get
		{
			return this.gclass38_0.IPrincipal_0;
		}
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x00005CE9 File Offset: 0x00003EE9
	private string method_0(string string_1)
	{
		string_1 = string_1.TrimStart(new char[]
		{
			'/',
			'\\'
		});
		return new StringBuilder(this.string_0, 32).AppendFormat("/{0}", string_1).ToString().Replace('\\', '/');
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x0002EEBC File Offset: 0x0002D0BC
	private static bool smethod_0(string string_1, out byte[] byte_0)
	{
		byte_0 = null;
		if (!File.Exists(string_1))
		{
			return false;
		}
		bool result;
		try
		{
			byte_0 = File.ReadAllBytes(string_1);
			return true;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x0002EEFC File Offset: 0x0002D0FC
	public byte[] method_1(string string_1)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_1.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_1.IndexOf("..") > -1)
		{
			throw new ArgumentException("It contains '..'.", "path");
		}
		byte[] result;
		GEventArgs5.smethod_0(this.method_0(string_1), out result);
		return result;
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x0002EF60 File Offset: 0x0002D160
	public bool method_2(string string_1, out byte[] byte_0)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_1.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_1.IndexOf("..") > -1)
		{
			throw new ArgumentException("It contains '..'.", "path");
		}
		return GEventArgs5.smethod_0(this.method_0(string_1), out byte_0);
	}

	// Token: 0x04000266 RID: 614
	private GClass38 gclass38_0;

	// Token: 0x04000267 RID: 615
	private string string_0;
}
