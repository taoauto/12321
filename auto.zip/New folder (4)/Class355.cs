﻿using System;

// Token: 0x0200029B RID: 667
internal class Class355
{
	// Token: 0x17000791 RID: 1937
	// (get) Token: 0x060024A2 RID: 9378 RVA: 0x0001BCA6 File Offset: 0x00019EA6
	public static string String_0
	{
		get
		{
			return "Phụng Minh Trấn";
		}
	}

	// Token: 0x04001882 RID: 6274
	public static int int_0 = 580;

	// Token: 0x04001883 RID: 6275
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 151,
		Int32_1 = 70,
		Int32_2 = Class355.int_0,
		String_2 = "Tiêu Ưng"
	};

	// Token: 0x04001884 RID: 6276
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 115U,
		Int32_0 = 289,
		Int32_1 = 81,
		Int32_2 = Class355.int_0,
		String_2 = "Bích Lạc"
	};

	// Token: 0x04001885 RID: 6277
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 29U,
		Int32_0 = 289,
		Int32_1 = 67,
		Int32_2 = Class355.int_0,
		String_2 = "Tiêu Lăng"
	};

	// Token: 0x04001886 RID: 6278
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 33U,
		Int32_0 = 158,
		Int32_1 = 65,
		Int32_2 = Class355.int_0,
		String_2 = "Sào Vân Khuê"
	};

	// Token: 0x04001887 RID: 6279
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 14U,
		Int32_0 = 267,
		Int32_1 = 118,
		Int32_2 = Class355.int_0,
		String_2 = "Tiền Tiên Sinh"
	};

	// Token: 0x04001888 RID: 6280
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 98U,
		Int32_0 = 101,
		Int32_1 = 127,
		Int32_2 = Class355.int_0,
		String_2 = "Tiêu Phong"
	};
}
