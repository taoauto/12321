﻿using System;
using System.Text;

// Token: 0x02000314 RID: 788
public class GClass128 : Decoder
{
	// Token: 0x06002DB3 RID: 11699 RVA: 0x0003C670 File Offset: 0x0003A870
	public virtual int GetCharCount(byte[] bytes, int index, int count)
	{
		if (bytes == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (index < 0 || index > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("index");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		if (index + count > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("bytes");
		}
		return count;
	}

	// Token: 0x06002DB4 RID: 11700 RVA: 0x00133B44 File Offset: 0x00131D44
	public virtual int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
	{
		if (bytes == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (byteIndex < 0 || byteIndex > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("byteIndex");
		}
		if (byteCount < 0)
		{
			throw new ArgumentOutOfRangeException("byteCount");
		}
		if (byteIndex + byteCount > bytes.Length)
		{
			throw new ArgumentOutOfRangeException("bytes");
		}
		if (chars == null)
		{
			throw new ArgumentNullException("chars");
		}
		if (charIndex >= 0 && charIndex <= chars.Length)
		{
			int num = byteCount + byteIndex;
			int num2 = charIndex;
			while (byteIndex < num)
			{
				byte b = bytes[byteIndex];
				if (num2 == chars.Length)
				{
					throw new ArgumentException("chars");
				}
				chars[num2] = ((b < 31 || b > 127) ? GClass128.char_0[(int)b] : ((char)b));
				num2++;
				byteIndex++;
			}
			return num2 - charIndex;
		}
		throw new ArgumentOutOfRangeException("charIndex");
	}

	// Token: 0x04001F02 RID: 7938
	private static readonly char[] char_0 = Class437.char_0;
}
