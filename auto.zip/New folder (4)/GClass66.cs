﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000D0 RID: 208
public class GClass66 : GClass61
{
	// Token: 0x060009C9 RID: 2505 RVA: 0x0003FB38 File Offset: 0x0003DD38
	public GClass66(GClass99 gclass99_1, List<GClass66.GClass70> list_2) : base(gclass99_1)
	{
		list_2.Sort(new Comparison<GClass66.GClass70>(GClass66.Class92.<>9.method_0));
		this.list_0 = list_2;
		this.class90_1 = (this.class90_0 = new Class90(gclass99_1.FastColoredTextBox_0.GClass86_5));
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x0003FBA4 File Offset: 0x0003DDA4
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		FastColoredTextBox fastColoredTextBox_ = this.gclass99_0.FastColoredTextBox_0;
		this.gclass99_0.vmethod_13();
		fastColoredTextBox_.GClass86_5.method_38();
		for (int i = 0; i < this.list_0.Count; i++)
		{
			fastColoredTextBox_.GClass86_5.GStruct2_0 = this.list_0[i].GClass86_0.GStruct2_0;
			for (int j = 0; j < this.list_0[i].String_0.Length; j++)
			{
				fastColoredTextBox_.GClass86_5.method_11(true);
			}
			GClass65.smethod_0(this.gclass99_0);
			int index = this.list_0.Count - 1 - i;
			GClass63.smethod_0(this.list_1[index], this.gclass99_0);
			this.gclass99_0.vmethod_10(this.list_0[i].GClass86_0.GStruct2_0.int_1, this.list_0[i].GClass86_0.GStruct2_0.int_1);
		}
		fastColoredTextBox_.GClass86_5.method_39();
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(0, 1));
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x0003FCD0 File Offset: 0x0003DED0
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		FastColoredTextBox fastColoredTextBox_ = this.gclass99_0.FastColoredTextBox_0;
		this.list_1.Clear();
		this.gclass99_0.vmethod_13();
		fastColoredTextBox_.GClass86_5.method_38();
		for (int i = this.list_0.Count - 1; i >= 0; i--)
		{
			fastColoredTextBox_.GClass86_5.GStruct2_0 = this.list_0[i].GClass86_0.GStruct2_0;
			fastColoredTextBox_.GClass86_5.GStruct2_1 = this.list_0[i].GClass86_0.GStruct2_1;
			this.list_1.Add(fastColoredTextBox_.GClass86_5.String_1);
			GClass65.smethod_0(this.gclass99_0);
			GClass63.smethod_0(this.list_0[i].String_0, this.gclass99_0);
			this.gclass99_0.vmethod_10(this.list_0[i].GClass86_0.GStruct2_0.int_1, this.list_0[i].GClass86_0.GStruct2_1.int_1);
		}
		fastColoredTextBox_.GClass86_5.method_39();
		this.gclass99_0.vmethod_11(new GClass99.GEventArgs20(0, 1));
		this.class90_1 = new Class90(fastColoredTextBox_.GClass86_5);
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x00009624 File Offset: 0x00007824
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		return new GClass66(this.gclass99_0, new List<GClass66.GClass70>(this.list_0));
	}

	// Token: 0x040004D1 RID: 1233
	private List<GClass66.GClass70> list_0;

	// Token: 0x040004D2 RID: 1234
	private List<string> list_1 = new List<string>();

	// Token: 0x020000D1 RID: 209
	public class GClass70
	{
		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060009CD RID: 2509 RVA: 0x0000963C File Offset: 0x0000783C
		// (set) Token: 0x060009CE RID: 2510 RVA: 0x00009644 File Offset: 0x00007844
		public GClass86 GClass86_0 { get; set; }

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060009CF RID: 2511 RVA: 0x0000964D File Offset: 0x0000784D
		// (set) Token: 0x060009D0 RID: 2512 RVA: 0x00009655 File Offset: 0x00007855
		public string String_0 { get; set; }

		// Token: 0x040004D3 RID: 1235
		[CompilerGenerated]
		private GClass86 gclass86_0;

		// Token: 0x040004D4 RID: 1236
		[CompilerGenerated]
		private string string_0;
	}

	// Token: 0x020000D2 RID: 210
	[CompilerGenerated]
	[Serializable]
	private sealed class Class92
	{
		// Token: 0x060009D4 RID: 2516 RVA: 0x0003FE18 File Offset: 0x0003E018
		internal int method_0(GClass66.GClass70 gclass70_0, GClass66.GClass70 gclass70_1)
		{
			GStruct2 gstruct2_;
			if (gclass70_0.GClass86_0.GStruct2_0.int_1 == gclass70_1.GClass86_0.GStruct2_0.int_1)
			{
				gstruct2_ = gclass70_0.GClass86_0.GStruct2_0;
				return gstruct2_.int_0.CompareTo(gclass70_1.GClass86_0.GStruct2_0.int_0);
			}
			gstruct2_ = gclass70_0.GClass86_0.GStruct2_0;
			return gstruct2_.int_1.CompareTo(gclass70_1.GClass86_0.GStruct2_0.int_1);
		}

		// Token: 0x040004D5 RID: 1237
		public static readonly GClass66.Class92 <>9 = new GClass66.Class92();

		// Token: 0x040004D6 RID: 1238
		public static Comparison<GClass66.GClass70> <>9__3_0;
	}
}
