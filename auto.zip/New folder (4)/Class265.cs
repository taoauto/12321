﻿using System;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

// Token: 0x02000230 RID: 560
internal class Class265
{
	// Token: 0x06001E5D RID: 7773 RVA: 0x000E14F8 File Offset: 0x000DF6F8
	public static string smethod_0(byte[] byte_0)
	{
		string text = "";
		text += "        0  1  2  3  4  5  6  7   8  9  A  B  C  D  E  F\r\n";
		text += "       -- -- -- -- -- -- -- --  -- -- -- -- -- -- -- --\r\n";
		text += "0000   ";
		bool flag = false;
		int i = 0;
		while (i < byte_0.Length)
		{
			if (flag)
			{
				goto IL_40;
			}
			if (byte_0[i] != 0)
			{
				flag = true;
				goto IL_40;
			}
			IL_2A6:
			i++;
			continue;
			IL_40:
			if (i != 0 && i % 16 == 0)
			{
				text += "  ";
				int num = i / 16 - 1;
				for (int j = 0; j < 16; j++)
				{
					byte b = byte_0[num * 16 + j];
					if (b >= 32 && b <= 126)
					{
						string str = text;
						char c = (char)b;
						text = str + c.ToString();
					}
					else
					{
						text += ".";
					}
				}
				text += "  ";
				for (int k = 0; k < 16; k++)
				{
					byte b2 = byte_0[num * 16 + k];
					if (b2 >= 32 && b2 <= 255)
					{
						text += Class265.char_0[(int)b2].ToString();
					}
					else
					{
						text += ".";
					}
				}
				text = text + "\r\n" + i.ToString("X4") + "   ";
			}
			else if (i % 16 == 8)
			{
				text += " ";
			}
			text = text + byte_0[i].ToString("X2") + " ";
			if (i == byte_0.Length - 1)
			{
				StringBuilder stringBuilder = new StringBuilder();
				int num2 = 16 - byte_0.Length % 16;
				int num3 = num2 * 3 + 2;
				if (num2 >= 8)
				{
					num3++;
				}
				for (int l = 0; l < num3; l++)
				{
					stringBuilder.Append(' ');
				}
				int num4 = (i - (byte_0.Length % 16 - 1)) / 16;
				for (int m = 0; m < byte_0.Length % 16; m++)
				{
					int num5 = (int)byte_0[num4 * 16 + m];
					if (num5 >= 32 && num5 <= 126)
					{
						stringBuilder.Append((char)num5);
					}
					else
					{
						stringBuilder.Append(".");
					}
				}
				int num6 = (num3 - (16 - byte_0.Length % 16)) / 2 + 1;
				for (int n = 0; n < num6; n++)
				{
					stringBuilder.Append(' ');
				}
				for (int num7 = 0; num7 < byte_0.Length % 16; num7++)
				{
					int num8 = (int)byte_0[num4 * 16 + num7];
					if (num8 >= 32 && num8 <= 255)
					{
						stringBuilder.Append(Class265.char_0[num8]);
					}
					else
					{
						stringBuilder.Append(".");
					}
				}
				for (int num9 = 0; num9 < num3; num9++)
				{
					stringBuilder.Append(' ');
				}
				text += stringBuilder.ToString();
				num4 = (i - (byte_0.Length % 16 - 1)) / 16;
				goto IL_2A6;
			}
			goto IL_2A6;
		}
		return text + "\n\n";
	}

	// Token: 0x06001E5E RID: 7774 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	public static string smethod_1(string string_1)
	{
		return "";
	}

	// Token: 0x06001E5F RID: 7775 RVA: 0x000E17C8 File Offset: 0x000DF9C8
	public static string smethod_2(string string_1, string string_2, string string_3)
	{
		int num = string_1.IndexOf(string_2);
		if (num < 0)
		{
			return string_1;
		}
		return string_1.Substring(0, num) + string_3 + string_1.Substring(num + string_2.Length);
	}

	// Token: 0x06001E60 RID: 7776 RVA: 0x0001691B File Offset: 0x00014B1B
	public static bool smethod_3(string string_1)
	{
		return !Regex.IsMatch(string_1, "^[a-zA-Z0-9]+$");
	}

	// Token: 0x06001E61 RID: 7777 RVA: 0x0001692D File Offset: 0x00014B2D
	public static float smethod_4(float float_0, float float_1, float float_2, float float_3)
	{
		return (float)Math.Sqrt(Math.Pow((double)(float_0 - float_2), 2.0) + Math.Pow((double)(float_1 - float_3), 2.0));
	}

	// Token: 0x06001E62 RID: 7778 RVA: 0x000E1800 File Offset: 0x000DFA00
	public static string smethod_5(string string_1)
	{
		string text = "";
		for (int i = 0; i < string_1.Length; i++)
		{
			text += string.Format("{0:x2}", Convert.ToUInt32(((int)string_1[i]).ToString()));
		}
		return text;
	}

	// Token: 0x06001E63 RID: 7779 RVA: 0x000E1854 File Offset: 0x000DFA54
	public static string smethod_6(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (byte b in byte_0)
		{
			stringBuilder.Append(b.ToString("X2") + " ");
		}
		return stringBuilder.ToString().Trim();
	}

	// Token: 0x06001E64 RID: 7780 RVA: 0x000E18A4 File Offset: 0x000DFAA4
	public static string smethod_7(string string_1)
	{
		string text = "";
		while (string_1.Length > 0)
		{
			text += Convert.ToChar(Convert.ToUInt32(string_1.Substring(0, 2), 16)).ToString();
			string_1 = string_1.Substring(2, string_1.Length - 2);
		}
		return text;
	}

	// Token: 0x06001E65 RID: 7781 RVA: 0x000E18F8 File Offset: 0x000DFAF8
	public static string smethod_8(string string_1)
	{
		string text = "";
		while (string_1.Length > 0)
		{
			text += string_1.Substring(0, 2).ToString();
			string_1 = string_1.Substring(2, string_1.Length - 2);
		}
		return text;
	}

	// Token: 0x06001E66 RID: 7782 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	public static string smethod_9(string string_1)
	{
		return "";
	}

	// Token: 0x06001E67 RID: 7783 RVA: 0x000E193C File Offset: 0x000DFB3C
	public static string smethod_10(string string_1)
	{
		string_1 = Class265.smethod_11(string_1, "\\x20", " ");
		string_1 = Class265.smethod_11(string_1, "\\x21", "!");
		string_1 = Class265.smethod_11(string_1, "\\x22", "\"");
		string_1 = Class265.smethod_11(string_1, "\\x23", "#");
		string_1 = Class265.smethod_11(string_1, "\\x24", "$");
		string_1 = Class265.smethod_11(string_1, "\\x25", "%");
		string_1 = Class265.smethod_11(string_1, "\\x26", "&");
		string_1 = Class265.smethod_11(string_1, "\\x27", "'");
		string_1 = Class265.smethod_11(string_1, "\\x28", "(");
		string_1 = Class265.smethod_11(string_1, "\\x29", ")");
		string_1 = Class265.smethod_11(string_1, "\\x2A", "*");
		string_1 = Class265.smethod_11(string_1, "\\x2B", "+");
		string_1 = Class265.smethod_11(string_1, "\\x2C", ",");
		string_1 = Class265.smethod_11(string_1, "\\x2D", "-");
		string_1 = Class265.smethod_11(string_1, "\\x2E", ".");
		string_1 = Class265.smethod_11(string_1, "\\x2F", "/");
		string_1 = Class265.smethod_11(string_1, "\\x30", "0");
		string_1 = Class265.smethod_11(string_1, "\\x31", "1");
		string_1 = Class265.smethod_11(string_1, "\\x32", "2");
		string_1 = Class265.smethod_11(string_1, "\\x33", "3");
		string_1 = Class265.smethod_11(string_1, "\\x34", "4");
		string_1 = Class265.smethod_11(string_1, "\\x35", "5");
		string_1 = Class265.smethod_11(string_1, "\\x36", "6");
		string_1 = Class265.smethod_11(string_1, "\\x37", "7");
		string_1 = Class265.smethod_11(string_1, "\\x38", "8");
		string_1 = Class265.smethod_11(string_1, "\\x39", "9");
		string_1 = Class265.smethod_11(string_1, "\\x3A", ":");
		string_1 = Class265.smethod_11(string_1, "\\x3B", ";");
		string_1 = Class265.smethod_11(string_1, "\\x3C", "<");
		string_1 = Class265.smethod_11(string_1, "\\x3D", "=");
		string_1 = Class265.smethod_11(string_1, "\\x3E", ">");
		string_1 = Class265.smethod_11(string_1, "\\x3F", "?");
		string_1 = Class265.smethod_11(string_1, "\\x40", "@");
		string_1 = Class265.smethod_11(string_1, "\\x41", "A");
		string_1 = Class265.smethod_11(string_1, "\\x42", "B");
		string_1 = Class265.smethod_11(string_1, "\\x43", "C");
		string_1 = Class265.smethod_11(string_1, "\\x44", "D");
		string_1 = Class265.smethod_11(string_1, "\\x45", "E");
		string_1 = Class265.smethod_11(string_1, "\\x46", "F");
		string_1 = Class265.smethod_11(string_1, "\\x47", "G");
		string_1 = Class265.smethod_11(string_1, "\\x48", "H");
		string_1 = Class265.smethod_11(string_1, "\\x49", "I");
		string_1 = Class265.smethod_11(string_1, "\\x4A", "J");
		string_1 = Class265.smethod_11(string_1, "\\x4B", "K");
		string_1 = Class265.smethod_11(string_1, "\\x4C", "L");
		string_1 = Class265.smethod_11(string_1, "\\x4D", "M");
		string_1 = Class265.smethod_11(string_1, "\\x4E", "N");
		string_1 = Class265.smethod_11(string_1, "\\x4F", "O");
		string_1 = Class265.smethod_11(string_1, "\\x50", "P");
		string_1 = Class265.smethod_11(string_1, "\\x51", "Q");
		string_1 = Class265.smethod_11(string_1, "\\x52", "R");
		string_1 = Class265.smethod_11(string_1, "\\x53", "S");
		string_1 = Class265.smethod_11(string_1, "\\x54", "T");
		string_1 = Class265.smethod_11(string_1, "\\x55", "U");
		string_1 = Class265.smethod_11(string_1, "\\x56", "V");
		string_1 = Class265.smethod_11(string_1, "\\x57", "W");
		string_1 = Class265.smethod_11(string_1, "\\x58", "X");
		string_1 = Class265.smethod_11(string_1, "\\x59", "Y");
		string_1 = Class265.smethod_11(string_1, "\\x5A", "Z");
		string_1 = Class265.smethod_11(string_1, "\\x5B", "[");
		string_1 = Class265.smethod_11(string_1, "\\x5C", "\\");
		string_1 = Class265.smethod_11(string_1, "\\x5D", "]");
		string_1 = Class265.smethod_11(string_1, "\\x5E", "^");
		string_1 = Class265.smethod_11(string_1, "\\x5F", "_");
		string_1 = Class265.smethod_11(string_1, "\\x60", "`");
		string_1 = Class265.smethod_11(string_1, "\\x61", "a");
		string_1 = Class265.smethod_11(string_1, "\\x62", "b");
		string_1 = Class265.smethod_11(string_1, "\\x63", "c");
		string_1 = Class265.smethod_11(string_1, "\\x64", "d");
		string_1 = Class265.smethod_11(string_1, "\\x65", "e");
		string_1 = Class265.smethod_11(string_1, "\\x66", "f");
		string_1 = Class265.smethod_11(string_1, "\\x67", "g");
		string_1 = Class265.smethod_11(string_1, "\\x68", "h");
		string_1 = Class265.smethod_11(string_1, "\\x69", "i");
		string_1 = Class265.smethod_11(string_1, "\\x6A", "j");
		string_1 = Class265.smethod_11(string_1, "\\x6B", "k");
		string_1 = Class265.smethod_11(string_1, "\\x6C", "l");
		string_1 = Class265.smethod_11(string_1, "\\x6D", "m");
		string_1 = Class265.smethod_11(string_1, "\\x6E", "n");
		string_1 = Class265.smethod_11(string_1, "\\x6F", "o");
		string_1 = Class265.smethod_11(string_1, "\\x70", "p");
		string_1 = Class265.smethod_11(string_1, "\\x71", "q");
		string_1 = Class265.smethod_11(string_1, "\\x72", "r");
		string_1 = Class265.smethod_11(string_1, "\\x73", "s");
		string_1 = Class265.smethod_11(string_1, "\\x74", "t");
		string_1 = Class265.smethod_11(string_1, "\\x75", "u");
		string_1 = Class265.smethod_11(string_1, "\\x76", "v");
		string_1 = Class265.smethod_11(string_1, "\\x77", "w");
		string_1 = Class265.smethod_11(string_1, "\\x78", "x");
		string_1 = Class265.smethod_11(string_1, "\\x79", "y");
		string_1 = Class265.smethod_11(string_1, "\\x7A", "z");
		string_1 = Class265.smethod_11(string_1, "\\x7B", "{");
		string_1 = Class265.smethod_11(string_1, "\\x7C", "|");
		string_1 = Class265.smethod_11(string_1, "\\x7D", "}");
		string_1 = Class265.smethod_11(string_1, "\\x7E", "~");
		return string_1;
	}

	// Token: 0x06001E68 RID: 7784 RVA: 0x0001695A File Offset: 0x00014B5A
	public static string smethod_11(string string_1, string string_2, string string_3)
	{
		return string_1.Replace(string_2, string_3);
	}

	// Token: 0x06001E69 RID: 7785 RVA: 0x00016964 File Offset: 0x00014B64
	public static string smethod_12(int int_0)
	{
		if (int_0 == 0)
		{
			return "0";
		}
		return string.Format("{0:#,###}", int_0);
	}

	// Token: 0x06001E6A RID: 7786 RVA: 0x0001697F File Offset: 0x00014B7F
	public static int smethod_13(float float_0)
	{
		return BitConverter.ToInt32(BitConverter.GetBytes(float_0), 0);
	}

	// Token: 0x06001E6B RID: 7787 RVA: 0x000E1FF8 File Offset: 0x000E01F8
	public static int[] smethod_14(int int_0, int[] int_1)
	{
		int[] array = new int[int_1.Length + 1];
		array[0] = int_0;
		int_1.CopyTo(array, 1);
		return array;
	}

	// Token: 0x06001E6C RID: 7788 RVA: 0x000E2020 File Offset: 0x000E0220
	public static int smethod_15(int int_0, int int_1)
	{
		if (int_1 == 0)
		{
			return 0;
		}
		int num = int_0 * 100 / int_1;
		if (num == 0 && int_0 > 0)
		{
			return 1;
		}
		if (num >= 100)
		{
			return 99;
		}
		return num;
	}

	// Token: 0x06001E6D RID: 7789 RVA: 0x0001698D File Offset: 0x00014B8D
	public static int smethod_16(bool bool_0)
	{
		if (bool_0)
		{
			return 1;
		}
		return 0;
	}

	// Token: 0x06001E6E RID: 7790 RVA: 0x000E204C File Offset: 0x000E024C
	public static string smethod_17(string string_1)
	{
		string text = "";
		for (int i = 0; i < string_1.Length; i++)
		{
			text += Class265.smethod_19(string_1[i]).ToString("X2");
		}
		return text;
	}

	// Token: 0x06001E6F RID: 7791 RVA: 0x000E2094 File Offset: 0x000E0294
	public static string smethod_18(string string_1)
	{
		string text = "";
		if (string_1.Length % 2 != 0)
		{
			string_1 += "0";
		}
		for (int i = string_1.Length / 2 - 1; i >= 0; i--)
		{
			text += string_1.Substring(i * 2, 2);
		}
		return text;
	}

	// Token: 0x06001E70 RID: 7792 RVA: 0x00016995 File Offset: 0x00014B95
	public static int smethod_19(char char_1)
	{
		return (int)char_1;
	}

	// Token: 0x06001E71 RID: 7793 RVA: 0x000E20E8 File Offset: 0x000E02E8
	public static int smethod_20(string string_1)
	{
		if (string_1.Contains("?"))
		{
			return -1;
		}
		if (string_1.Contains("#"))
		{
			return 257;
		}
		int result = -1;
		int.TryParse(string_1, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x06001E72 RID: 7794 RVA: 0x000E2130 File Offset: 0x000E0330
	public static int[] smethod_21(string string_1)
	{
		string_1 = string_1.Replace(" ", "");
		if (string_1.Length % 2 != 0)
		{
			string_1 += "0";
		}
		int[] array = new int[string_1.Length / 2];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = Class265.smethod_20(string_1.Substring(i * 2, 2));
		}
		return array;
	}

	// Token: 0x06001E73 RID: 7795 RVA: 0x000E2198 File Offset: 0x000E0398
	public static string smethod_22(int[] int_0)
	{
		string text = "";
		for (int i = 0; i < int_0.Length; i++)
		{
			text = text + int_0[i].ToString() + " ";
		}
		return text + text.Length.ToString();
	}

	// Token: 0x06001E74 RID: 7796 RVA: 0x000E21E8 File Offset: 0x000E03E8
	public static string smethod_23(byte[] byte_0)
	{
		string text = "";
		for (int i = 0; i < byte_0.Length; i++)
		{
			text = text + byte_0[i].ToString() + " ";
		}
		return text + text.Length.ToString();
	}

	// Token: 0x06001E75 RID: 7797 RVA: 0x000E2238 File Offset: 0x000E0438
	public static string smethod_24(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in byte_0)
		{
			if (c == '\0')
			{
				break;
			}
			if (c < 'Ā')
			{
				stringBuilder.Append(Class265.char_0[(int)c]);
			}
			else
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06001E76 RID: 7798 RVA: 0x000E2288 File Offset: 0x000E0488
	public static string smethod_25(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in byte_0)
		{
			if (c != '\0')
			{
				if (c < 'Ā')
				{
					stringBuilder.Append(Class265.char_0[(int)c]);
				}
				else
				{
					stringBuilder.Append("?");
				}
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06001E77 RID: 7799 RVA: 0x000E22DC File Offset: 0x000E04DC
	public static string smethod_26(string string_1)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < string_1.Length; i++)
		{
			if (string_1[i] >= 'ÿ')
			{
				stringBuilder.Append(Class265.smethod_27(string_1[i]));
			}
			else
			{
				stringBuilder.Append(string_1[i]);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06001E78 RID: 7800 RVA: 0x000E2338 File Offset: 0x000E0538
	public static char smethod_27(char char_1)
	{
		for (int i = 0; i < 256; i++)
		{
			if (Class265.char_0[i] == char_1)
			{
				return (char)i;
			}
		}
		return '?';
	}

	// Token: 0x040012E7 RID: 4839
	public static readonly char[] char_0 = new char[]
	{
		'\0',
		'\u0001',
		'Ẳ',
		'\u0003',
		'\u0004',
		'Ẵ',
		'Ẫ',
		'\a',
		'\b',
		'\t',
		'\n',
		'\v',
		'\f',
		'\r',
		'\u000e',
		'\u000f',
		'\u0010',
		'\u0011',
		'\u0012',
		'\u0013',
		'Ỷ',
		'\u0015',
		'\u0016',
		'\u0017',
		'\u0018',
		'Ỹ',
		'\u001a',
		'\u001b',
		'\u001c',
		'\u001d',
		'Ỵ',
		'\u001f',
		' ',
		'!',
		'"',
		'#',
		'$',
		'%',
		'&',
		'\'',
		'(',
		')',
		'*',
		'+',
		',',
		'-',
		'.',
		'/',
		'0',
		'1',
		'2',
		'3',
		'4',
		'5',
		'6',
		'7',
		'8',
		'9',
		':',
		';',
		'<',
		'=',
		'>',
		'?',
		'@',
		'A',
		'B',
		'C',
		'D',
		'E',
		'F',
		'G',
		'H',
		'I',
		'J',
		'K',
		'L',
		'M',
		'N',
		'O',
		'P',
		'Q',
		'R',
		'S',
		'T',
		'U',
		'V',
		'W',
		'X',
		'Y',
		'Z',
		'[',
		'\\',
		']',
		'^',
		'_',
		'`',
		'a',
		'b',
		'c',
		'd',
		'e',
		'f',
		'g',
		'h',
		'i',
		'j',
		'k',
		'l',
		'm',
		'n',
		'o',
		'p',
		'q',
		'r',
		's',
		't',
		'u',
		'v',
		'w',
		'x',
		'y',
		'z',
		'{',
		'|',
		'}',
		'~',
		'\u007f',
		'Ạ',
		'Ắ',
		'Ằ',
		'Ặ',
		'Ấ',
		'Ầ',
		'Ẩ',
		'Ậ',
		'Ẽ',
		'Ẹ',
		'Ế',
		'Ề',
		'Ể',
		'Ễ',
		'Ệ',
		'Ố',
		'Ồ',
		'Ổ',
		'Ỗ',
		'Ộ',
		'Ợ',
		'Ớ',
		'Ờ',
		'Ở',
		'Ị',
		'Ỏ',
		'Ọ',
		'Ỉ',
		'Ủ',
		'Ũ',
		'Ụ',
		'Ỳ',
		'Õ',
		'ắ',
		'ằ',
		'ặ',
		'ấ',
		'ầ',
		'ẩ',
		'ậ',
		'ẽ',
		'ẹ',
		'ế',
		'ề',
		'ể',
		'ễ',
		'ệ',
		'ố',
		'ồ',
		'ổ',
		'ỗ',
		'Ỡ',
		'Ơ',
		'ộ',
		'ờ',
		'ở',
		'ị',
		'Ự',
		'Ứ',
		'Ừ',
		'Ử',
		'ơ',
		'ớ',
		'Ư',
		'À',
		'Á',
		'Â',
		'Ã',
		'Ả',
		'Ă',
		'ẳ',
		'ẵ',
		'È',
		'É',
		'Ê',
		'Ẻ',
		'Ì',
		'Í',
		'Ĩ',
		'ỳ',
		'Đ',
		'ứ',
		'Ò',
		'Ó',
		'Ô',
		'ạ',
		'ỷ',
		'ừ',
		'ử',
		'Ù',
		'Ú',
		'ỹ',
		'ỵ',
		'Ý',
		'ỡ',
		'ư',
		'à',
		'á',
		'â',
		'ã',
		'ả',
		'ă',
		'ữ',
		'ẫ',
		'è',
		'é',
		'ê',
		'ẻ',
		'ì',
		'í',
		'ĩ',
		'ỉ',
		'đ',
		'ự',
		'ò',
		'ó',
		'ô',
		'õ',
		'ỏ',
		'ọ',
		'ụ',
		'ù',
		'ú',
		'ũ',
		'ủ',
		'ý',
		'ợ',
		'Ữ'
	};

	// Token: 0x040012E8 RID: 4840
	public static readonly string[] string_0 = new string[]
	{
		"\\u0000",
		"\\u0001",
		"\\u1EB2",
		"\\u0003",
		"\\u0004",
		"\\u1EB4",
		"\\u1EAA",
		"\\u0007",
		"\\u0008",
		"\\u0009",
		"\\u000A",
		"\\u000B",
		"\\u000C",
		"\\u000D",
		"\\u000E",
		"\\u000F",
		"\\u0010",
		"\\u0011",
		"\\u0012",
		"\\u0013",
		"\\u1EF6",
		"\\u0015",
		"\\u0016",
		"\\u0017",
		"\\u0018",
		"\\u1EF8",
		"\\u001A",
		"\\u001B",
		"\\u001C",
		"\\u001D",
		"\\u1EF4",
		"\\u001F",
		"\\u0020",
		"\\u0021",
		"\\u0022",
		"\\u0023",
		"\\u0024",
		"\\u0025",
		"\\u0026",
		"\\u0027",
		"\\u0028",
		"\\u0029",
		"\\u002A",
		"\\u002B",
		"\\u002C",
		"\\u002D",
		"\\u002E",
		"\\u002F",
		"\\u0030",
		"\\u0031",
		"\\u0032",
		"\\u0033",
		"\\u0034",
		"\\u0035",
		"\\u0036",
		"\\u0037",
		"\\u0038",
		"\\u0039",
		"\\u003A",
		"\\u003B",
		"\\u003C",
		"\\u003D",
		"\\u003E",
		"\\u003F",
		"\\u0040",
		"\\u0041",
		"\\u0042",
		"\\u0043",
		"\\u0044",
		"\\u0045",
		"\\u0046",
		"\\u0047",
		"\\u0048",
		"\\u0049",
		"\\u004A",
		"\\u004B",
		"\\u004C",
		"\\u004D",
		"\\u004E",
		"\\u004F",
		"\\u0050",
		"\\u0051",
		"\\u0052",
		"\\u0053",
		"\\u0054",
		"\\u0055",
		"\\u0056",
		"\\u0057",
		"\\u0058",
		"\\u0059",
		"\\u005A",
		"\\u005B",
		"\\u005C",
		"\\u005D",
		"\\u005E",
		"\\u005F",
		"\\u0060",
		"\\u0061",
		"\\u0062",
		"\\u0063",
		"\\u0064",
		"\\u0065",
		"\\u0066",
		"\\u0067",
		"\\u0068",
		"\\u0069",
		"\\u006A",
		"\\u006B",
		"\\u006C",
		"\\u006D",
		"\\u006E",
		"\\u006F",
		"\\u0070",
		"\\u0071",
		"\\u0072",
		"\\u0073",
		"\\u0074",
		"\\u0075",
		"\\u0076",
		"\\u0077",
		"\\u0078",
		"\\u0079",
		"\\u007A",
		"\\u007B",
		"\\u007C",
		"\\u007D",
		"\\u007E",
		"\\u007F",
		"\\u1EA0",
		"\\u1EAE",
		"\\u1EB0",
		"\\u1EB6",
		"\\u1EA4",
		"\\u1EA6",
		"\\u1EA8",
		"\\u1EAC",
		"\\u1EBC",
		"\\u1EB8",
		"\\u1EBE",
		"\\u1EC0",
		"\\u1EC2",
		"\\u1EC4",
		"\\u1EC6",
		"\\u1ED0",
		"\\u1ED2",
		"\\u1ED4",
		"\\u1ED6",
		"\\u1ED8",
		"\\u1EE2",
		"\\u1EDA",
		"\\u1EDC",
		"\\u1EDE",
		"\\u1ECA",
		"\\u1ECE",
		"\\u1ECC",
		"\\u1EC8",
		"\\u1EE6",
		"\\u0168",
		"\\u1EE4",
		"\\u1EF2",
		"\\u00D5",
		"\\u1EAF",
		"\\u1EB1",
		"\\u1EB7",
		"\\u1EA5",
		"\\u1EA7",
		"\\u1EA9",
		"\\u1EAD",
		"\\u1EBD",
		"\\u1EB9",
		"\\u1EBF",
		"\\u1EC1",
		"\\u1EC3",
		"\\u1EC5",
		"\\u1EC7",
		"\\u1ED1",
		"\\u1ED3",
		"\\u1ED5",
		"\\u1ED7",
		"\\u1EE0",
		"\\u01A0",
		"\\u1ED9",
		"\\u1EDD",
		"\\u1EDF",
		"\\u1ECB",
		"\\u1EF0",
		"\\u1EE8",
		"\\u1EEA",
		"\\u1EEC",
		"\\u01A1",
		"\\u1EDB",
		"\\u01AF",
		"\\u00C0",
		"\\u00C1",
		"\\u00C2",
		"\\u00C3",
		"\\u1EA2",
		"\\u0102",
		"\\u1EB3",
		"\\u1EB5",
		"\\u00C8",
		"\\u00C9",
		"\\u00CA",
		"\\u1EBA",
		"\\u00CC",
		"\\u00CD",
		"\\u0128",
		"\\u1EF3",
		"\\u0110",
		"\\u1EE9",
		"\\u00D2",
		"\\u00D3",
		"\\u00D4",
		"\\u1EA1",
		"\\u1EF7",
		"\\u1EEB",
		"\\u1EED",
		"\\u00D9",
		"\\u00DA",
		"\\u1EF9",
		"\\u1EF5",
		"\\u00DD",
		"\\u1EE1",
		"\\u01B0",
		"\\u00E0",
		"\\u00E1",
		"\\u00E2",
		"\\u00E3",
		"\\u1EA3",
		"\\u0103",
		"\\u1EEF",
		"\\u1EAB",
		"\\u00E8",
		"\\u00E9",
		"\\u00EA",
		"\\u1EBB",
		"\\u00EC",
		"\\u00ED",
		"\\u0129",
		"\\u1EC9",
		"\\u0111",
		"\\u1EF1",
		"\\u00F2",
		"\\u00F3",
		"\\u00F4",
		"\\u00F5",
		"\\u1ECF",
		"\\u1ECD",
		"\\u1EE5",
		"\\u00F9",
		"\\u00FA",
		"\\u0169",
		"\\u1EE7",
		"\\u00FD",
		"\\u1EE3",
		"\\u1EEE"
	};
}
