﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Text;

// Token: 0x02000048 RID: 72
internal class Class26 : Class25
{
	// Token: 0x06000301 RID: 769 RVA: 0x00004DC1 File Offset: 0x00002FC1
	private Class26(string string_3, string string_4, Version version_1, NameValueCollection nameValueCollection_1) : base(version_1, nameValueCollection_1)
	{
		this.string_1 = string_3;
		this.string_2 = string_4;
	}

	// Token: 0x06000302 RID: 770 RVA: 0x00004DDA File Offset: 0x00002FDA
	internal Class26(string string_3, string string_4) : this(string_3, string_4, GClass42.version_1, new NameValueCollection())
	{
		base.NameValueCollection_0["User-Agent"] = "websocket-sharp/1.0";
	}

	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x06000303 RID: 771 RVA: 0x00029E98 File Offset: 0x00028098
	public Class64 Class64_0
	{
		get
		{
			string text = base.NameValueCollection_0["Authorization"];
			if (text != null && text.Length > 0)
			{
				return Class64.smethod_8(text);
			}
			return null;
		}
	}

	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x06000304 RID: 772 RVA: 0x00004E03 File Offset: 0x00003003
	public GClass34 GClass34_0
	{
		get
		{
			if (this.gclass34_0 == null)
			{
				this.gclass34_0 = base.NameValueCollection_0.smethod_30(false);
			}
			return this.gclass34_0;
		}
	}

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x06000305 RID: 773 RVA: 0x00004E25 File Offset: 0x00003025
	public string String_1
	{
		get
		{
			return this.string_1;
		}
	}

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x06000306 RID: 774 RVA: 0x00004E2D File Offset: 0x0000302D
	public bool Boolean_0
	{
		get
		{
			return this.string_1 == "GET" && base.Version_0 > GClass42.version_0 && base.NameValueCollection_0.smethod_77("websocket");
		}
	}

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x06000307 RID: 775 RVA: 0x00004E65 File Offset: 0x00003065
	public string String_2
	{
		get
		{
			return this.string_2;
		}
	}

	// Token: 0x06000308 RID: 776 RVA: 0x00029ECC File Offset: 0x000280CC
	internal static Class26 smethod_3(Uri uri_0)
	{
		string dnsSafeHost = uri_0.DnsSafeHost;
		int port = uri_0.Port;
		string text = string.Format("{0}:{1}", dnsSafeHost, port);
		Class26 @class = new Class26("CONNECT", text);
		@class.NameValueCollection_0["Host"] = ((port == 80) ? dnsSafeHost : text);
		return @class;
	}

	// Token: 0x06000309 RID: 777 RVA: 0x00029F20 File Offset: 0x00028120
	internal static Class26 smethod_4(Uri uri_0)
	{
		Class26 @class = new Class26("GET", uri_0.PathAndQuery);
		NameValueCollection nameValueCollection_ = @class.NameValueCollection_0;
		int port = uri_0.Port;
		string scheme = uri_0.Scheme;
		nameValueCollection_["Host"] = (((port != 80 || !(scheme == "ws")) && (port != 443 || !(scheme == "wss"))) ? uri_0.Authority : uri_0.DnsSafeHost);
		nameValueCollection_["Upgrade"] = "websocket";
		nameValueCollection_["Connection"] = "Upgrade";
		return @class;
	}

	// Token: 0x0600030A RID: 778 RVA: 0x00029FB0 File Offset: 0x000281B0
	internal Class27 method_1(Stream stream_0, int int_1)
	{
		byte[] array = base.method_0();
		stream_0.Write(array, 0, array.Length);
		return Class25.smethod_2<Class27>(stream_0, new Func<string[], Class27>(Class27.smethod_6), int_1);
	}

	// Token: 0x0600030B RID: 779 RVA: 0x00029FE4 File Offset: 0x000281E4
	internal static Class26 smethod_5(string[] string_3)
	{
		string[] array = string_3[0].Split(new char[]
		{
			' '
		}, 3);
		if (array.Length != 3)
		{
			throw new ArgumentException("Invalid request line: " + string_3[0]);
		}
		GClass45 gclass = new GClass45();
		for (int i = 1; i < string_3.Length; i++)
		{
			gclass.method_5(string_3[i], false);
		}
		return new Class26(array[0], array[1], new Version(array[2].Substring(5)), gclass);
	}

	// Token: 0x0600030C RID: 780 RVA: 0x00004E6D File Offset: 0x0000306D
	internal static Class26 smethod_6(Stream stream_0, int int_1)
	{
		return Class25.smethod_2<Class26>(stream_0, new Func<string[], Class26>(Class26.smethod_5), int_1);
	}

	// Token: 0x0600030D RID: 781 RVA: 0x0002A058 File Offset: 0x00028258
	public void method_2(GClass34 gclass34_1)
	{
		if (gclass34_1 != null && gclass34_1.Count != 0)
		{
			StringBuilder stringBuilder = new StringBuilder(64);
			foreach (GClass33 gclass in gclass34_1.IEnumerable_0)
			{
				if (!gclass.Boolean_2)
				{
					stringBuilder.AppendFormat("{0}; ", gclass.ToString());
				}
			}
			int length = stringBuilder.Length;
			if (length > 2)
			{
				stringBuilder.Length = length - 2;
				base.NameValueCollection_0["Cookie"] = stringBuilder.ToString();
			}
			return;
		}
	}

	// Token: 0x0600030E RID: 782 RVA: 0x0002A0F8 File Offset: 0x000282F8
	public virtual string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("{0} {1} HTTP/{2}{3}", new object[]
		{
			this.string_1,
			this.string_2,
			base.Version_0,
			"\r\n"
		});
		NameValueCollection nameValueCollection_ = base.NameValueCollection_0;
		foreach (string text in nameValueCollection_.AllKeys)
		{
			stringBuilder.AppendFormat("{0}: {1}{2}", text, nameValueCollection_[text], "\r\n");
		}
		stringBuilder.Append("\r\n");
		string string_ = base.String_0;
		if (string_.Length > 0)
		{
			stringBuilder.Append(string_);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x040001BD RID: 445
	private GClass34 gclass34_0;

	// Token: 0x040001BE RID: 446
	private string string_1;

	// Token: 0x040001BF RID: 447
	private string string_2;
}
