﻿// Token: 0x0200016E RID: 366
internal partial class DebugEx : global::System.Windows.Forms.Form
{
	// Token: 0x060011DE RID: 4574 RVA: 0x0006505C File Offset: 0x0006325C
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::DebugEx));
		this.menuGameObject = new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.gameObjectToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.allToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.instanceToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.uskill3ToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.pickToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.trapToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.packetItemToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.packetToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.thienCoToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.trangBiToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.shopToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.bankToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.rideToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.lootToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.tuiChanNguyenToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.teamToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.questFrameItemToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.gameTaskToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.useSkill3ToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.doActionToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.doSubActionToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.useToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.gameControlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.tabControlEx1 = new global::Control1();
		this.tabPage1 = new global::System.Windows.Forms.TabPage();
		this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
		this.lvObject = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_1 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_2 = new global::System.Windows.Forms.ColumnHeader();
		this.pgGameObject = new global::System.Windows.Forms.PropertyGrid();
		this.tabPage2 = new global::System.Windows.Forms.TabPage();
		this.btnSendPacket = new global::System.Windows.Forms.Button();
		this.txtPacket = new global::Class85();
		this.button1 = new global::System.Windows.Forms.Button();
		this.btnPush = new global::System.Windows.Forms.Button();
		this.txtQuestFrameClick = new global::Class85();
		this.txtPushDebugMessage = new global::Class85();
		this.btnDoString = new global::System.Windows.Forms.Button();
		this.txtDoString = new global::Class85();
		this.txtToString = new global::Class85();
		this.tabPage3 = new global::System.Windows.Forms.TabPage();
		this.pgTLBB = new global::System.Windows.Forms.PropertyGrid();
		this.tabPage4 = new global::System.Windows.Forms.TabPage();
		this.panSniff = new global::System.Windows.Forms.Panel();
		this.txtHex = new global::Class85();
		this.btnClearSniff = new global::System.Windows.Forms.Button();
		this.btnShowSniff = new global::System.Windows.Forms.Button();
		this.tabPage5 = new global::System.Windows.Forms.TabPage();
		this.pgGame = new global::System.Windows.Forms.PropertyGrid();
		this.petToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
		this.menuGameObject.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.tabPage2.SuspendLayout();
		this.tabPage3.SuspendLayout();
		this.tabPage4.SuspendLayout();
		this.tabPage5.SuspendLayout();
		base.SuspendLayout();
		this.menuGameObject.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.gameObjectToolStripMenuItem,
			this.packetItemToolStripMenuItem,
			this.teamToolStripMenuItem,
			this.questFrameItemToolStripMenuItem,
			this.gameTaskToolStripMenuItem,
			this.useSkill3ToolStripMenuItem,
			this.doActionToolStripMenuItem,
			this.doSubActionToolStripMenuItem,
			this.useToolStripMenuItem,
			this.gameControlToolStripMenuItem,
			this.petToolStripMenuItem
		});
		this.menuGameObject.Name = "menuGameObject";
		this.menuGameObject.Size = new global::System.Drawing.Size(181, 268);
		this.gameObjectToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.allToolStripMenuItem,
			this.instanceToolStripMenuItem,
			this.uskill3ToolStripMenuItem,
			this.pickToolStripMenuItem,
			this.trapToolStripMenuItem
		});
		this.gameObjectToolStripMenuItem.Name = "gameObjectToolStripMenuItem";
		this.gameObjectToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.gameObjectToolStripMenuItem.Text = "GameObject";
		this.allToolStripMenuItem.Name = "allToolStripMenuItem";
		this.allToolStripMenuItem.Size = new global::System.Drawing.Size(118, 22);
		this.allToolStripMenuItem.Text = "All";
		this.allToolStripMenuItem.Click += new global::System.EventHandler(this.allToolStripMenuItem_Click);
		this.instanceToolStripMenuItem.Name = "instanceToolStripMenuItem";
		this.instanceToolStripMenuItem.Size = new global::System.Drawing.Size(118, 22);
		this.instanceToolStripMenuItem.Text = "Instance";
		this.instanceToolStripMenuItem.Click += new global::System.EventHandler(this.instanceToolStripMenuItem_Click);
		this.uskill3ToolStripMenuItem.Name = "uskill3ToolStripMenuItem";
		this.uskill3ToolStripMenuItem.Size = new global::System.Drawing.Size(118, 22);
		this.uskill3ToolStripMenuItem.Text = "Uskill(3)";
		this.uskill3ToolStripMenuItem.Click += new global::System.EventHandler(this.uskill3ToolStripMenuItem_Click);
		this.pickToolStripMenuItem.Name = "pickToolStripMenuItem";
		this.pickToolStripMenuItem.Size = new global::System.Drawing.Size(118, 22);
		this.pickToolStripMenuItem.Text = "Pick";
		this.pickToolStripMenuItem.Click += new global::System.EventHandler(this.pickToolStripMenuItem_Click);
		this.trapToolStripMenuItem.Name = "trapToolStripMenuItem";
		this.trapToolStripMenuItem.Size = new global::System.Drawing.Size(118, 22);
		this.trapToolStripMenuItem.Text = "Trap";
		this.trapToolStripMenuItem.Click += new global::System.EventHandler(this.trapToolStripMenuItem_Click);
		this.packetItemToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.packetToolStripMenuItem,
			this.thienCoToolStripMenuItem,
			this.trangBiToolStripMenuItem,
			this.shopToolStripMenuItem,
			this.bankToolStripMenuItem,
			this.rideToolStripMenuItem,
			this.lootToolStripMenuItem,
			this.tuiChanNguyenToolStripMenuItem
		});
		this.packetItemToolStripMenuItem.Name = "packetItemToolStripMenuItem";
		this.packetItemToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.packetItemToolStripMenuItem.Text = "PacketItem";
		this.packetToolStripMenuItem.Name = "packetToolStripMenuItem";
		this.packetToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.packetToolStripMenuItem.Text = "Packet";
		this.packetToolStripMenuItem.Click += new global::System.EventHandler(this.packetToolStripMenuItem_Click);
		this.thienCoToolStripMenuItem.Name = "thienCoToolStripMenuItem";
		this.thienCoToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.thienCoToolStripMenuItem.Text = "ThienCo";
		this.thienCoToolStripMenuItem.Click += new global::System.EventHandler(this.thienCoToolStripMenuItem_Click);
		this.trangBiToolStripMenuItem.Name = "trangBiToolStripMenuItem";
		this.trangBiToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.trangBiToolStripMenuItem.Text = "TrangBi";
		this.trangBiToolStripMenuItem.Click += new global::System.EventHandler(this.trangBiToolStripMenuItem_Click);
		this.shopToolStripMenuItem.Name = "shopToolStripMenuItem";
		this.shopToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.shopToolStripMenuItem.Text = "Shop";
		this.shopToolStripMenuItem.Click += new global::System.EventHandler(this.shopToolStripMenuItem_Click);
		this.bankToolStripMenuItem.Name = "bankToolStripMenuItem";
		this.bankToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.bankToolStripMenuItem.Text = "Bank";
		this.bankToolStripMenuItem.Click += new global::System.EventHandler(this.bankToolStripMenuItem_Click);
		this.rideToolStripMenuItem.Name = "rideToolStripMenuItem";
		this.rideToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.rideToolStripMenuItem.Text = "Ride";
		this.rideToolStripMenuItem.Click += new global::System.EventHandler(this.rideToolStripMenuItem_Click);
		this.lootToolStripMenuItem.Name = "lootToolStripMenuItem";
		this.lootToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.lootToolStripMenuItem.Text = "Loot";
		this.lootToolStripMenuItem.Click += new global::System.EventHandler(this.lootToolStripMenuItem_Click);
		this.tuiChanNguyenToolStripMenuItem.Name = "tuiChanNguyenToolStripMenuItem";
		this.tuiChanNguyenToolStripMenuItem.Size = new global::System.Drawing.Size(160, 22);
		this.tuiChanNguyenToolStripMenuItem.Text = "TuiChanNguyen";
		this.tuiChanNguyenToolStripMenuItem.Click += new global::System.EventHandler(this.tuiChanNguyenToolStripMenuItem_Click);
		this.teamToolStripMenuItem.Name = "teamToolStripMenuItem";
		this.teamToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.teamToolStripMenuItem.Text = "Team";
		this.teamToolStripMenuItem.Click += new global::System.EventHandler(this.teamToolStripMenuItem_Click);
		this.questFrameItemToolStripMenuItem.Name = "questFrameItemToolStripMenuItem";
		this.questFrameItemToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.questFrameItemToolStripMenuItem.Text = "QuestFrame";
		this.questFrameItemToolStripMenuItem.Click += new global::System.EventHandler(this.questFrameItemToolStripMenuItem_Click);
		this.gameTaskToolStripMenuItem.Name = "gameTaskToolStripMenuItem";
		this.gameTaskToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.gameTaskToolStripMenuItem.Text = "GameTask";
		this.gameTaskToolStripMenuItem.Click += new global::System.EventHandler(this.gameTaskToolStripMenuItem_Click);
		this.useSkill3ToolStripMenuItem.Name = "useSkill3ToolStripMenuItem";
		this.useSkill3ToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.useSkill3ToolStripMenuItem.Text = "UseSkill(3)";
		this.useSkill3ToolStripMenuItem.Click += new global::System.EventHandler(this.useSkill3ToolStripMenuItem_Click);
		this.doActionToolStripMenuItem.Name = "doActionToolStripMenuItem";
		this.doActionToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.doActionToolStripMenuItem.Text = "DoAction";
		this.doActionToolStripMenuItem.Click += new global::System.EventHandler(this.doActionToolStripMenuItem_Click);
		this.doSubActionToolStripMenuItem.Name = "doSubActionToolStripMenuItem";
		this.doSubActionToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.doSubActionToolStripMenuItem.Text = "DoSubAction";
		this.doSubActionToolStripMenuItem.Click += new global::System.EventHandler(this.doSubActionToolStripMenuItem_Click);
		this.useToolStripMenuItem.Name = "useToolStripMenuItem";
		this.useToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.useToolStripMenuItem.Text = "Use";
		this.useToolStripMenuItem.Click += new global::System.EventHandler(this.useToolStripMenuItem_Click);
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.gameControlToolStripMenuItem.Name = "gameControlToolStripMenuItem";
		this.gameControlToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.gameControlToolStripMenuItem.Text = "GameControl";
		this.gameControlToolStripMenuItem.Click += new global::System.EventHandler(this.gameControlToolStripMenuItem_Click);
		this.tabControlEx1.TabAlignment_0 = global::System.Windows.Forms.TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Controls.Add(this.tabPage3);
		this.tabControlEx1.Controls.Add(this.tabPage4);
		this.tabControlEx1.Controls.Add(this.tabPage5);
		this.tabControlEx1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.tabControlEx1.Location = new global::System.Drawing.Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new global::System.Drawing.Size(583, 418);
		this.tabControlEx1.TabIndex = 0;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new global::System.Drawing.Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage1.Size = new global::System.Drawing.Size(575, 392);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "GameObject";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.splitContainer1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.splitContainer1.Location = new global::System.Drawing.Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.lvObject);
		this.splitContainer1.Panel2.Controls.Add(this.pgGameObject);
		this.splitContainer1.Size = new global::System.Drawing.Size(569, 386);
		this.splitContainer1.SplitterDistance = 291;
		this.splitContainer1.TabIndex = 0;
		this.lvObject.AllowColumnReorder = true;
		this.lvObject.AllowDrop = true;
		this.lvObject.AllowReorder = true;
		this.lvObject.AllowSort = true;
		this.lvObject.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.lvObject.ContextMenuStrip = this.menuGameObject;
		this.lvObject.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.lvObject.DoubleClickActivation = false;
		this.lvObject.FullRowSelect = true;
		this.lvObject.GridLines = true;
		this.lvObject.hideItems = (global::System.Collections.Generic.List<global::System.Windows.Forms.ListViewItem>)componentResourceManager.GetObject("lvObject.hideItems");
		this.lvObject.HideSelection = false;
		this.lvObject.LineColor = global::System.Drawing.Color.Red;
		this.lvObject.Location = new global::System.Drawing.Point(0, 0);
		this.lvObject.Name = "lvObject";
		this.lvObject.Size = new global::System.Drawing.Size(291, 386);
		this.lvObject.TabIndex = 0;
		this.lvObject.UseCompatibleStateImageBehavior = false;
		this.lvObject.View = global::System.Windows.Forms.View.Details;
		this.lvObject.SelectedIndexChanged += new global::System.EventHandler(this.lvObject_SelectedIndexChanged);
		this.columnHeader_0.Text = "ID";
		this.columnHeader_0.Width = 52;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 80;
		this.columnHeader_2.Text = "Info";
		this.columnHeader_2.Width = 113;
		this.pgGameObject.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.pgGameObject.HelpVisible = false;
		this.pgGameObject.LineColor = global::System.Drawing.SystemColors.ControlDark;
		this.pgGameObject.Location = new global::System.Drawing.Point(0, 0);
		this.pgGameObject.Name = "pgGameObject";
		this.pgGameObject.PropertySort = global::System.Windows.Forms.PropertySort.Alphabetical;
		this.pgGameObject.Size = new global::System.Drawing.Size(274, 386);
		this.pgGameObject.TabIndex = 1;
		this.tabPage2.Controls.Add(this.btnSendPacket);
		this.tabPage2.Controls.Add(this.txtPacket);
		this.tabPage2.Controls.Add(this.button1);
		this.tabPage2.Controls.Add(this.btnPush);
		this.tabPage2.Controls.Add(this.txtQuestFrameClick);
		this.tabPage2.Controls.Add(this.txtPushDebugMessage);
		this.tabPage2.Controls.Add(this.btnDoString);
		this.tabPage2.Controls.Add(this.txtDoString);
		this.tabPage2.Controls.Add(this.txtToString);
		this.tabPage2.Location = new global::System.Drawing.Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage2.Size = new global::System.Drawing.Size(575, 392);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "DoString";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.btnSendPacket.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.btnSendPacket.Location = new global::System.Drawing.Point(497, 314);
		this.btnSendPacket.Name = "btnSendPacket";
		this.btnSendPacket.Size = new global::System.Drawing.Size(75, 23);
		this.btnSendPacket.TabIndex = 8;
		this.btnSendPacket.Text = "Send";
		this.btnSendPacket.UseVisualStyleBackColor = true;
		this.btnSendPacket.Click += new global::System.EventHandler(this.btnSendPacket_Click);
		this.txtPacket.Location = new global::System.Drawing.Point(8, 316);
		this.txtPacket.Name = "txtPacket";
		this.txtPacket.Size = new global::System.Drawing.Size(483, 20);
		this.txtPacket.TabIndex = 7;
		this.txtPacket.String_0 = "Packet...";
		this.txtPacket.Color_0 = global::System.Drawing.Color.Gray;
		this.txtPacket.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtPacket.Color_1 = global::System.Drawing.Color.LightGray;
		this.button1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.button1.Location = new global::System.Drawing.Point(497, 289);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(75, 23);
		this.button1.TabIndex = 6;
		this.button1.Text = "Test";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.btnPush.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.btnPush.Location = new global::System.Drawing.Point(174, 258);
		this.btnPush.Name = "btnPush";
		this.btnPush.Size = new global::System.Drawing.Size(75, 23);
		this.btnPush.TabIndex = 5;
		this.btnPush.Text = "Push";
		this.btnPush.UseVisualStyleBackColor = true;
		this.btnPush.Click += new global::System.EventHandler(this.btnPush_Click);
		this.txtQuestFrameClick.Location = new global::System.Drawing.Point(8, 286);
		this.txtQuestFrameClick.Name = "txtQuestFrameClick";
		this.txtQuestFrameClick.Size = new global::System.Drawing.Size(160, 20);
		this.txtQuestFrameClick.TabIndex = 3;
		this.txtQuestFrameClick.String_0 = "QuestFramClick...";
		this.txtQuestFrameClick.Color_0 = global::System.Drawing.Color.Gray;
		this.txtQuestFrameClick.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtQuestFrameClick.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtQuestFrameClick.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.txtQuestFrameClick_KeyDown);
		this.txtPushDebugMessage.Location = new global::System.Drawing.Point(8, 260);
		this.txtPushDebugMessage.Name = "txtPushDebugMessage";
		this.txtPushDebugMessage.Size = new global::System.Drawing.Size(160, 20);
		this.txtPushDebugMessage.TabIndex = 2;
		this.txtPushDebugMessage.String_0 = "PushDebugMessage...";
		this.txtPushDebugMessage.Color_0 = global::System.Drawing.Color.Gray;
		this.txtPushDebugMessage.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtPushDebugMessage.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtPushDebugMessage.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.txtPushDebugMessage_KeyDown);
		this.btnDoString.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.btnDoString.Location = new global::System.Drawing.Point(497, 260);
		this.btnDoString.Name = "btnDoString";
		this.btnDoString.Size = new global::System.Drawing.Size(75, 23);
		this.btnDoString.TabIndex = 1;
		this.btnDoString.Text = "Do";
		this.btnDoString.UseVisualStyleBackColor = true;
		this.btnDoString.Click += new global::System.EventHandler(this.btnDoString_Click);
		this.txtDoString.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.txtDoString.Location = new global::System.Drawing.Point(3, 71);
		this.txtDoString.Multiline = true;
		this.txtDoString.Name = "txtDoString";
		this.txtDoString.Size = new global::System.Drawing.Size(569, 183);
		this.txtDoString.TabIndex = 0;
		this.txtDoString.String_0 = "Lua...";
		this.txtDoString.Color_0 = global::System.Drawing.Color.Gray;
		this.txtDoString.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtDoString.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtToString.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.txtToString.Location = new global::System.Drawing.Point(3, 3);
		this.txtToString.Multiline = true;
		this.txtToString.Name = "txtToString";
		this.txtToString.ReadOnly = true;
		this.txtToString.Size = new global::System.Drawing.Size(569, 68);
		this.txtToString.TabIndex = 4;
		this.txtToString.String_0 = "ToString...";
		this.txtToString.Color_0 = global::System.Drawing.Color.Gray;
		this.txtToString.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtToString.Color_1 = global::System.Drawing.Color.LightGray;
		this.tabPage3.Controls.Add(this.pgTLBB);
		this.tabPage3.Location = new global::System.Drawing.Point(4, 22);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage3.Size = new global::System.Drawing.Size(575, 392);
		this.tabPage3.TabIndex = 2;
		this.tabPage3.Text = "TLBB";
		this.tabPage3.UseVisualStyleBackColor = true;
		this.pgTLBB.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.pgTLBB.HelpVisible = false;
		this.pgTLBB.LineColor = global::System.Drawing.SystemColors.ControlDark;
		this.pgTLBB.Location = new global::System.Drawing.Point(3, 3);
		this.pgTLBB.Name = "pgTLBB";
		this.pgTLBB.PropertySort = global::System.Windows.Forms.PropertySort.Alphabetical;
		this.pgTLBB.Size = new global::System.Drawing.Size(569, 386);
		this.pgTLBB.TabIndex = 2;
		this.tabPage4.Controls.Add(this.panSniff);
		this.tabPage4.Controls.Add(this.txtHex);
		this.tabPage4.Controls.Add(this.btnClearSniff);
		this.tabPage4.Controls.Add(this.btnShowSniff);
		this.tabPage4.Location = new global::System.Drawing.Point(4, 22);
		this.tabPage4.Name = "tabPage4";
		this.tabPage4.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage4.Size = new global::System.Drawing.Size(575, 392);
		this.tabPage4.TabIndex = 3;
		this.tabPage4.Text = "Sniff";
		this.tabPage4.UseVisualStyleBackColor = true;
		this.panSniff.AutoScroll = true;
		this.panSniff.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.panSniff.Location = new global::System.Drawing.Point(3, 3);
		this.panSniff.Name = "panSniff";
		this.panSniff.Size = new global::System.Drawing.Size(569, 223);
		this.panSniff.TabIndex = 8;
		this.txtHex.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.txtHex.Font = new global::System.Drawing.Font("Courier New", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtHex.Location = new global::System.Drawing.Point(3, 226);
		this.txtHex.Multiline = true;
		this.txtHex.Name = "txtHex";
		this.txtHex.ScrollBars = global::System.Windows.Forms.ScrollBars.Both;
		this.txtHex.Size = new global::System.Drawing.Size(569, 117);
		this.txtHex.TabIndex = 9;
		this.txtHex.String_0 = "";
		this.txtHex.Color_0 = global::System.Drawing.Color.Gray;
		this.txtHex.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtHex.Color_1 = global::System.Drawing.Color.LightGray;
		this.btnClearSniff.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.btnClearSniff.Location = new global::System.Drawing.Point(3, 343);
		this.btnClearSniff.Name = "btnClearSniff";
		this.btnClearSniff.Size = new global::System.Drawing.Size(569, 23);
		this.btnClearSniff.TabIndex = 7;
		this.btnClearSniff.Text = "Clear";
		this.btnClearSniff.UseVisualStyleBackColor = true;
		this.btnClearSniff.Click += new global::System.EventHandler(this.btnClearSniff_Click);
		this.btnShowSniff.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.btnShowSniff.Location = new global::System.Drawing.Point(3, 366);
		this.btnShowSniff.Name = "btnShowSniff";
		this.btnShowSniff.Size = new global::System.Drawing.Size(569, 23);
		this.btnShowSniff.TabIndex = 5;
		this.btnShowSniff.Text = "Sniff";
		this.btnShowSniff.UseVisualStyleBackColor = true;
		this.btnShowSniff.Click += new global::System.EventHandler(this.btnShowSniff_Click);
		this.tabPage5.Controls.Add(this.pgGame);
		this.tabPage5.Location = new global::System.Drawing.Point(4, 22);
		this.tabPage5.Name = "tabPage5";
		this.tabPage5.Padding = new global::System.Windows.Forms.Padding(3);
		this.tabPage5.Size = new global::System.Drawing.Size(575, 392);
		this.tabPage5.TabIndex = 4;
		this.tabPage5.Text = "Game";
		this.tabPage5.UseVisualStyleBackColor = true;
		this.pgGame.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.pgGame.HelpVisible = false;
		this.pgGame.LineColor = global::System.Drawing.SystemColors.ControlDark;
		this.pgGame.Location = new global::System.Drawing.Point(3, 3);
		this.pgGame.Name = "pgGame";
		this.pgGame.PropertySort = global::System.Windows.Forms.PropertySort.Alphabetical;
		this.pgGame.Size = new global::System.Drawing.Size(569, 386);
		this.pgGame.TabIndex = 3;
		this.petToolStripMenuItem.Name = "petToolStripMenuItem";
		this.petToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
		this.petToolStripMenuItem.Text = "Pet";
		this.petToolStripMenuItem.Click += new global::System.EventHandler(this.petToolStripMenuItem_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(583, 418);
		base.Controls.Add(this.tabControlEx1);
		base.Name = "DebugEx";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "DebugEx";
		base.Load += new global::System.EventHandler(this.DebugEx_Load);
		this.menuGameObject.ResumeLayout(false);
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.tabPage2.ResumeLayout(false);
		this.tabPage2.PerformLayout();
		this.tabPage3.ResumeLayout(false);
		this.tabPage4.ResumeLayout(false);
		this.tabPage4.PerformLayout();
		this.tabPage5.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000938 RID: 2360
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04000939 RID: 2361
	private global::Control1 tabControlEx1;

	// Token: 0x0400093A RID: 2362
	private global::System.Windows.Forms.TabPage tabPage1;

	// Token: 0x0400093B RID: 2363
	private global::System.Windows.Forms.TabPage tabPage2;

	// Token: 0x0400093C RID: 2364
	private global::System.Windows.Forms.SplitContainer splitContainer1;

	// Token: 0x0400093D RID: 2365
	private global::_i.ListViewEx lvObject;

	// Token: 0x0400093E RID: 2366
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x0400093F RID: 2367
	private global::System.Windows.Forms.ColumnHeader columnHeader_1;

	// Token: 0x04000940 RID: 2368
	private global::System.Windows.Forms.ColumnHeader columnHeader_2;

	// Token: 0x04000941 RID: 2369
	private global::System.Windows.Forms.ContextMenuStrip menuGameObject;

	// Token: 0x04000942 RID: 2370
	private global::System.Windows.Forms.ToolStripMenuItem gameObjectToolStripMenuItem;

	// Token: 0x04000943 RID: 2371
	private global::System.Windows.Forms.ToolStripMenuItem allToolStripMenuItem;

	// Token: 0x04000944 RID: 2372
	private global::System.Windows.Forms.PropertyGrid pgGameObject;

	// Token: 0x04000945 RID: 2373
	private global::System.Windows.Forms.ToolStripMenuItem questFrameItemToolStripMenuItem;

	// Token: 0x04000946 RID: 2374
	private global::System.Windows.Forms.ToolStripMenuItem gameTaskToolStripMenuItem;

	// Token: 0x04000947 RID: 2375
	private global::Class85 txtDoString;

	// Token: 0x04000948 RID: 2376
	private global::System.Windows.Forms.Button btnDoString;

	// Token: 0x04000949 RID: 2377
	private global::Class85 txtPushDebugMessage;

	// Token: 0x0400094A RID: 2378
	private global::Class85 txtQuestFrameClick;

	// Token: 0x0400094B RID: 2379
	private global::Class85 txtToString;

	// Token: 0x0400094C RID: 2380
	private global::System.Windows.Forms.Button btnPush;

	// Token: 0x0400094D RID: 2381
	private global::System.Windows.Forms.ToolStripMenuItem useSkill3ToolStripMenuItem;

	// Token: 0x0400094E RID: 2382
	private global::System.Windows.Forms.TabPage tabPage3;

	// Token: 0x0400094F RID: 2383
	private global::System.Windows.Forms.PropertyGrid pgTLBB;

	// Token: 0x04000950 RID: 2384
	private global::System.Windows.Forms.ToolStripMenuItem packetItemToolStripMenuItem;

	// Token: 0x04000951 RID: 2385
	private global::System.Windows.Forms.ToolStripMenuItem packetToolStripMenuItem;

	// Token: 0x04000952 RID: 2386
	private global::System.Windows.Forms.ToolStripMenuItem trangBiToolStripMenuItem;

	// Token: 0x04000953 RID: 2387
	private global::System.Windows.Forms.ToolStripMenuItem shopToolStripMenuItem;

	// Token: 0x04000954 RID: 2388
	private global::System.Windows.Forms.ToolStripMenuItem bankToolStripMenuItem;

	// Token: 0x04000955 RID: 2389
	private global::System.Windows.Forms.ToolStripMenuItem rideToolStripMenuItem;

	// Token: 0x04000956 RID: 2390
	private global::System.Windows.Forms.ToolStripMenuItem doActionToolStripMenuItem;

	// Token: 0x04000957 RID: 2391
	private global::System.Windows.Forms.ToolStripMenuItem doSubActionToolStripMenuItem;

	// Token: 0x04000958 RID: 2392
	private global::System.Windows.Forms.ToolStripMenuItem useToolStripMenuItem;

	// Token: 0x04000959 RID: 2393
	private global::System.Windows.Forms.Button button1;

	// Token: 0x0400095A RID: 2394
	private global::System.Windows.Forms.ToolStripMenuItem lootToolStripMenuItem;

	// Token: 0x0400095B RID: 2395
	private global::System.Windows.Forms.ToolStripMenuItem thienCoToolStripMenuItem;

	// Token: 0x0400095C RID: 2396
	private global::System.Windows.Forms.ToolStripMenuItem teamToolStripMenuItem;

	// Token: 0x0400095D RID: 2397
	private global::System.Windows.Forms.ToolStripMenuItem instanceToolStripMenuItem;

	// Token: 0x0400095E RID: 2398
	private global::System.Windows.Forms.TabPage tabPage4;

	// Token: 0x0400095F RID: 2399
	private global::Class85 txtHex;

	// Token: 0x04000960 RID: 2400
	private global::System.Windows.Forms.Panel panSniff;

	// Token: 0x04000961 RID: 2401
	private global::System.Windows.Forms.Button btnClearSniff;

	// Token: 0x04000962 RID: 2402
	private global::System.Windows.Forms.Button btnShowSniff;

	// Token: 0x04000963 RID: 2403
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04000964 RID: 2404
	private global::System.Windows.Forms.Button btnSendPacket;

	// Token: 0x04000965 RID: 2405
	private global::Class85 txtPacket;

	// Token: 0x04000966 RID: 2406
	private global::System.Windows.Forms.ToolStripMenuItem tuiChanNguyenToolStripMenuItem;

	// Token: 0x04000967 RID: 2407
	private global::System.Windows.Forms.ToolStripMenuItem uskill3ToolStripMenuItem;

	// Token: 0x04000968 RID: 2408
	private global::System.Windows.Forms.ToolStripMenuItem pickToolStripMenuItem;

	// Token: 0x04000969 RID: 2409
	private global::System.Windows.Forms.ToolStripMenuItem trapToolStripMenuItem;

	// Token: 0x0400096A RID: 2410
	private global::System.Windows.Forms.TabPage tabPage5;

	// Token: 0x0400096B RID: 2411
	private global::System.Windows.Forms.PropertyGrid pgGame;

	// Token: 0x0400096C RID: 2412
	private global::System.Windows.Forms.ToolStripMenuItem gameControlToolStripMenuItem;

	// Token: 0x0400096D RID: 2413
	private global::System.Windows.Forms.ToolStripMenuItem petToolStripMenuItem;
}
