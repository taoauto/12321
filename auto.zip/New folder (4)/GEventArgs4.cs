﻿using System;

// Token: 0x0200004E RID: 78
public class GEventArgs4 : EventArgs
{
	// Token: 0x06000339 RID: 825 RVA: 0x000050FE File Offset: 0x000032FE
	internal GEventArgs4(Class42 class42_0)
	{
		this.enum3_0 = class42_0.Enum3_0;
		this.byte_0 = class42_0.Class30_0.Byte_0;
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00005123 File Offset: 0x00003323
	internal GEventArgs4(Enum3 enum3_1, byte[] byte_1)
	{
		if ((long)byte_1.Length > (long)Class30.ulong_0)
		{
			throw new GException3(GEnum6.TooBig);
		}
		this.enum3_0 = enum3_1;
		this.byte_0 = byte_1;
	}

	// Token: 0x170000DC RID: 220
	// (get) Token: 0x0600033B RID: 827 RVA: 0x0000514E File Offset: 0x0000334E
	internal Enum3 Enum3_0
	{
		get
		{
			return this.enum3_0;
		}
	}

	// Token: 0x170000DD RID: 221
	// (get) Token: 0x0600033C RID: 828 RVA: 0x00005156 File Offset: 0x00003356
	public string String_0
	{
		get
		{
			this.method_0();
			return this.string_0;
		}
	}

	// Token: 0x170000DE RID: 222
	// (get) Token: 0x0600033D RID: 829 RVA: 0x00005164 File Offset: 0x00003364
	public bool Boolean_0
	{
		get
		{
			return this.enum3_0 == Enum3.Binary;
		}
	}

	// Token: 0x170000DF RID: 223
	// (get) Token: 0x0600033E RID: 830 RVA: 0x0000516F File Offset: 0x0000336F
	public bool Boolean_1
	{
		get
		{
			return this.enum3_0 == Enum3.Ping;
		}
	}

	// Token: 0x170000E0 RID: 224
	// (get) Token: 0x0600033F RID: 831 RVA: 0x0000517B File Offset: 0x0000337B
	public bool Boolean_2
	{
		get
		{
			return this.enum3_0 == Enum3.Text;
		}
	}

	// Token: 0x170000E1 RID: 225
	// (get) Token: 0x06000340 RID: 832 RVA: 0x00005186 File Offset: 0x00003386
	public byte[] Byte_0
	{
		get
		{
			this.method_0();
			return this.byte_0;
		}
	}

	// Token: 0x06000341 RID: 833 RVA: 0x0002A700 File Offset: 0x00028900
	private void method_0()
	{
		if (this.bool_0)
		{
			return;
		}
		if (this.enum3_0 == Enum3.Binary)
		{
			this.bool_0 = true;
			return;
		}
		string text;
		if (this.byte_0.smethod_73(out text))
		{
			this.string_0 = text;
		}
		this.bool_0 = true;
	}

	// Token: 0x040001D4 RID: 468
	private string string_0;

	// Token: 0x040001D5 RID: 469
	private bool bool_0;

	// Token: 0x040001D6 RID: 470
	private Enum3 enum3_0;

	// Token: 0x040001D7 RID: 471
	private byte[] byte_0;
}
