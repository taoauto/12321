﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Token: 0x0200032B RID: 811
[CompilerGenerated]
internal sealed class Class448
{
	// Token: 0x06002E5E RID: 11870 RVA: 0x00136DA0 File Offset: 0x00134FA0
	internal static uint smethod_0(string string_0)
	{
		uint num;
		if (string_0 != null)
		{
			num = 2166136261U;
			for (int i = 0; i < string_0.Length; i++)
			{
				num = ((uint)string_0[i] ^ num) * 16777619U;
			}
		}
		return num;
	}

	// Token: 0x04001FB0 RID: 8112 RVA: 0x00002050 File Offset: 0x00000250
	internal static readonly Class448.Struct15 struct15_0;

	// Token: 0x04001FB1 RID: 8113 RVA: 0x00002060 File Offset: 0x00000260
	internal static readonly Class448.Struct13 struct13_0;

	// Token: 0x04001FB2 RID: 8114 RVA: 0x00002070 File Offset: 0x00000270
	internal static readonly Class448.Struct22 struct22_0;

	// Token: 0x04001FB3 RID: 8115 RVA: 0x000020A0 File Offset: 0x000002A0
	internal static readonly Class448.Struct17 struct17_0;

	// Token: 0x04001FB4 RID: 8116 RVA: 0x000020B8 File Offset: 0x000002B8
	internal static readonly Class448.Struct18 struct18_0;

	// Token: 0x04001FB5 RID: 8117 RVA: 0x000020D0 File Offset: 0x000002D0
	internal static readonly Class448.Struct16 struct16_0;

	// Token: 0x04001FB6 RID: 8118 RVA: 0x000020E8 File Offset: 0x000002E8
	internal static readonly Class448.Struct28 struct28_0;

	// Token: 0x04001FB7 RID: 8119 RVA: 0x000025A0 File Offset: 0x000007A0
	internal static readonly Class448.Struct20 struct20_0;

	// Token: 0x04001FB8 RID: 8120 RVA: 0x000025C8 File Offset: 0x000007C8
	internal static readonly Class448.Struct15 struct15_1;

	// Token: 0x04001FB9 RID: 8121 RVA: 0x000025D8 File Offset: 0x000007D8
	internal static readonly Class448.Struct25 struct25_0;

	// Token: 0x04001FBA RID: 8122 RVA: 0x000026B8 File Offset: 0x000008B8
	internal static readonly Class448.Struct15 struct15_2;

	// Token: 0x04001FBB RID: 8123 RVA: 0x000026C8 File Offset: 0x000008C8
	internal static readonly Class448.Struct18 struct18_1;

	// Token: 0x04001FBC RID: 8124 RVA: 0x000026E0 File Offset: 0x000008E0
	internal static readonly Class448.Struct24 struct24_0;

	// Token: 0x04001FBD RID: 8125 RVA: 0x00002748 File Offset: 0x00000948
	internal static readonly Class448.Struct23 struct23_0;

	// Token: 0x04001FBE RID: 8126 RVA: 0x000027A8 File Offset: 0x000009A8
	internal static readonly Class448.Struct27 struct27_0;

	// Token: 0x04001FBF RID: 8127 RVA: 0x00002A08 File Offset: 0x00000C08
	internal static readonly Class448.Struct15 struct15_3;

	// Token: 0x04001FC0 RID: 8128 RVA: 0x00002A18 File Offset: 0x00000C18
	internal static readonly Class448.Struct26 struct26_0;

	// Token: 0x04001FC1 RID: 8129 RVA: 0x00002C18 File Offset: 0x00000E18
	internal static readonly Class448.Struct13 struct13_1;

	// Token: 0x04001FC2 RID: 8130 RVA: 0x00002C28 File Offset: 0x00000E28
	internal static readonly Class448.Struct17 struct17_1;

	// Token: 0x04001FC3 RID: 8131 RVA: 0x00002C40 File Offset: 0x00000E40
	internal static readonly Class448.Struct15 struct15_4;

	// Token: 0x04001FC4 RID: 8132 RVA: 0x00002C50 File Offset: 0x00000E50
	internal static readonly Class448.Struct18 struct18_2;

	// Token: 0x04001FC5 RID: 8133 RVA: 0x00002C68 File Offset: 0x00000E68
	internal static readonly Class448.Struct21 struct21_0;

	// Token: 0x04001FC6 RID: 8134 RVA: 0x00002C98 File Offset: 0x00000E98
	internal static readonly Class448.Struct15 struct15_5;

	// Token: 0x04001FC7 RID: 8135 RVA: 0x00002CA8 File Offset: 0x00000EA8
	internal static readonly Class448.Struct15 struct15_6;

	// Token: 0x04001FC8 RID: 8136 RVA: 0x00002CB8 File Offset: 0x00000EB8
	internal static readonly Class448.Struct15 struct15_7;

	// Token: 0x04001FC9 RID: 8137 RVA: 0x00002CC8 File Offset: 0x00000EC8
	internal static readonly Class448.Struct12 struct12_0;

	// Token: 0x04001FCA RID: 8138 RVA: 0x00002CD0 File Offset: 0x00000ED0
	internal static readonly Class448.Struct13 struct13_2;

	// Token: 0x04001FCB RID: 8139 RVA: 0x00002CE0 File Offset: 0x00000EE0
	internal static readonly Class448.Struct14 struct14_0;

	// Token: 0x04001FCC RID: 8140 RVA: 0x00002CF0 File Offset: 0x00000EF0
	internal static readonly long long_0;

	// Token: 0x04001FCD RID: 8141 RVA: 0x00002CF8 File Offset: 0x00000EF8
	internal static readonly Class448.Struct15 struct15_8;

	// Token: 0x04001FCE RID: 8142 RVA: 0x00002D08 File Offset: 0x00000F08
	internal static readonly Class448.Struct11 struct11_0;

	// Token: 0x04001FCF RID: 8143 RVA: 0x00002D10 File Offset: 0x00000F10
	internal static readonly Class448.Struct15 struct15_9;

	// Token: 0x04001FD0 RID: 8144 RVA: 0x00002D20 File Offset: 0x00000F20
	internal static readonly Class448.Struct15 struct15_10;

	// Token: 0x04001FD1 RID: 8145 RVA: 0x00002D30 File Offset: 0x00000F30
	internal static readonly Class448.Struct17 AA894BEF2B45C6D19E719F4B2DFD97724EA5071F3F8159AB0170BFA60B888267;

	// Token: 0x04001FD2 RID: 8146 RVA: 0x00002D48 File Offset: 0x00000F48
	internal static readonly Class448.Struct18 ABFF6BCB1473FC9D64AA64BD407B5D6A46990D4AB2AE05A0FA7201E16B412CF3;

	// Token: 0x04001FD3 RID: 8147 RVA: 0x00002D60 File Offset: 0x00000F60
	internal static readonly Class448.Struct18 B0D3D49623158B3D3DBE7FBE764E887C51F80DBC879D5BEB6789F104C1F36DE2;

	// Token: 0x04001FD4 RID: 8148 RVA: 0x00002D78 File Offset: 0x00000F78
	internal static readonly Class448.Struct19 BA5BA3BA29C7DA743A43C7575BB59413EA97184D0CE3EFCE9216EA368B667539;

	// Token: 0x04001FD5 RID: 8149 RVA: 0x00002D98 File Offset: 0x00000F98
	internal static readonly Class448.Struct15 BAED642339816AFFB3FE8719792D0E4CE82F12DB72B7373D244EAA65445800FE;

	// Token: 0x04001FD6 RID: 8150 RVA: 0x00002DA8 File Offset: 0x00000FA8
	internal static readonly Class448.Struct15 BB294B12F311072CEDB90F43D89281A278B91A31D361049D99F3503EF8E84047;

	// Token: 0x04001FD7 RID: 8151 RVA: 0x00002DB8 File Offset: 0x00000FB8
	internal static readonly Class448.Struct18 C71936F990256D8CD5112456ECCA6E51B2A0F6577C79F3BF40D0DCF7457BD39C;

	// Token: 0x04001FD8 RID: 8152 RVA: 0x00002DD0 File Offset: 0x00000FD0
	internal static readonly Class448.Struct17 CF7F197B39E44988DECE802975E71FDFAEA29005022395FE2315AA7E7C3548EF;

	// Token: 0x04001FD9 RID: 8153 RVA: 0x00002DE8 File Offset: 0x00000FE8
	internal static readonly Class448.Struct15 DDF6646C598729F1D0EA65F81EBA55574989BD5258D2FA1048FEB3C614B0F258;

	// Token: 0x04001FDA RID: 8154 RVA: 0x00002DF8 File Offset: 0x00000FF8
	internal static readonly Class448.Struct15 E0B1BB6A51A05EC74169F2B1E4085900691DE543244930307AB1B8AB47E2668A;

	// Token: 0x04001FDB RID: 8155 RVA: 0x00002E08 File Offset: 0x00001008
	internal static readonly Class448.Struct15 EFD6B819437BF15E9AAAE771DD943F4008141DD9E93037CD75253F1507ED3E20;

	// Token: 0x0200032C RID: 812
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 5)]
	private struct Struct11
	{
	}

	// Token: 0x0200032D RID: 813
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 6)]
	private struct Struct12
	{
	}

	// Token: 0x0200032E RID: 814
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 12)]
	private struct Struct13
	{
	}

	// Token: 0x0200032F RID: 815
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 14)]
	private struct Struct14
	{
	}

	// Token: 0x02000330 RID: 816
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	private struct Struct15
	{
	}

	// Token: 0x02000331 RID: 817
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 17)]
	private struct Struct16
	{
	}

	// Token: 0x02000332 RID: 818
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	private struct Struct17
	{
	}

	// Token: 0x02000333 RID: 819
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 24)]
	private struct Struct18
	{
	}

	// Token: 0x02000334 RID: 820
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 28)]
	private struct Struct19
	{
	}

	// Token: 0x02000335 RID: 821
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 40)]
	private struct Struct20
	{
	}

	// Token: 0x02000336 RID: 822
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 44)]
	private struct Struct21
	{
	}

	// Token: 0x02000337 RID: 823
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 48)]
	private struct Struct22
	{
	}

	// Token: 0x02000338 RID: 824
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 95)]
	private struct Struct23
	{
	}

	// Token: 0x02000339 RID: 825
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 103)]
	private struct Struct24
	{
	}

	// Token: 0x0200033A RID: 826
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 217)]
	private struct Struct25
	{
	}

	// Token: 0x0200033B RID: 827
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 512)]
	private struct Struct26
	{
	}

	// Token: 0x0200033C RID: 828
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 604)]
	private struct Struct27
	{
	}

	// Token: 0x0200033D RID: 829
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1208)]
	private struct Struct28
	{
	}
}
