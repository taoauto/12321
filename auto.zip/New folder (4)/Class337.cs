﻿using System;

// Token: 0x02000286 RID: 646
internal class Class337
{
	// Token: 0x17000778 RID: 1912
	// (get) Token: 0x06002418 RID: 9240 RVA: 0x0001B896 File Offset: 0x00019A96
	public static string String_0
	{
		get
		{
			return "Trân Long Kỳ Cuộc";
		}
	}

	// Token: 0x040017D4 RID: 6100
	public static int int_0 = 61;

	// Token: 0x040017D5 RID: 6101
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 12349U,
		Int32_0 = 40,
		Int32_1 = 40,
		Int32_2 = Class337.int_0,
		String_2 = "Tế Thánh"
	};
}
