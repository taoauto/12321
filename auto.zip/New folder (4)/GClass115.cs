﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000191 RID: 401
[Serializable]
public class GClass115 : GClass113, IDisposable
{
	// Token: 0x0600124D RID: 4685 RVA: 0x0000E70F File Offset: 0x0000C90F
	public GClass115(byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentException("Unable to iterate a null reference", "iterable");
		}
		this._base = new MemoryStream(byte_0, 0, byte_0.Length, true);
		this._ubuffer = new GClass117(256);
	}

	// Token: 0x0600124E RID: 4686 RVA: 0x0000E74B File Offset: 0x0000C94B
	public void Dispose()
	{
		this.vmethod_4(true);
		GC.SuppressFinalize(this);
	}

	// Token: 0x0600124F RID: 4687 RVA: 0x0000E75A File Offset: 0x0000C95A
	protected virtual void vmethod_4(bool bool_0)
	{
		if (!this._disposed)
		{
			if (bool_0)
			{
				this._ubuffer.Dispose();
				this._base.Dispose();
			}
			this._disposed = true;
		}
	}

	// Token: 0x06001250 RID: 4688 RVA: 0x0000E784 File Offset: 0x0000C984
	protected byte[] method_0()
	{
		return this._base.ToArray();
	}

	// Token: 0x06001251 RID: 4689 RVA: 0x0000E791 File Offset: 0x0000C991
	public bool method_1<T>(out T gparam_0) where T : struct
	{
		return this.method_3<T>(0L, SeekOrigin.Current, out gparam_0);
	}

	// Token: 0x06001252 RID: 4690 RVA: 0x000690CC File Offset: 0x000672CC
	public bool method_2(long long_0, SeekOrigin seekOrigin_0, byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("buffer", "Parameter cannot be null");
		}
		try
		{
			this._base.Seek(long_0, seekOrigin_0);
			this._base.Read(byte_0, 0, byte_0.Length);
		}
		catch (Exception exception_)
		{
			this.vmethod_2(exception_);
			byte_0 = null;
		}
		return byte_0 != null;
	}

	// Token: 0x06001253 RID: 4691 RVA: 0x00069130 File Offset: 0x00067330
	public bool method_3<T>(long long_0, SeekOrigin seekOrigin_0, out T gparam_0) where T : struct
	{
		gparam_0 = default(T);
		bool result;
		try
		{
			this._base.Seek(long_0, seekOrigin_0);
			byte[] array = new byte[Marshal.SizeOf(typeof(T))];
			this._base.Read(array, 0, array.Length);
			if (!this._ubuffer.method_9<T>(array, out gparam_0))
			{
				throw this._ubuffer.vmethod_1();
			}
			result = true;
		}
		catch (Exception exception_)
		{
			result = base.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001254 RID: 4692 RVA: 0x000691B4 File Offset: 0x000673B4
	public bool method_4(long long_0, SeekOrigin seekOrigin_0, out string string_0, int int_0 = -1, Encoding encoding_0 = null)
	{
		string_0 = null;
		byte[] array = new byte[(int_0 > 0) ? int_0 : 64];
		if (encoding_0 == null)
		{
			encoding_0 = Encoding.ASCII;
		}
		bool result;
		try
		{
			this._base.Seek(long_0, seekOrigin_0);
			StringBuilder stringBuilder = new StringBuilder((int_0 > 0) ? int_0 : 260);
			int num = -1;
			int num2 = 0;
			int num3;
			while (num == -1 && (num3 = this._base.Read(array, 0, array.Length)) > 0)
			{
				stringBuilder.Append(encoding_0.GetString(array));
				num = stringBuilder.ToString().IndexOf('\0', num2);
				num2 += num3;
				if (int_0 > 0 && num2 >= int_0)
				{
					break;
				}
			}
			if (num > -1)
			{
				string_0 = stringBuilder.ToString().Substring(0, num);
			}
			else if (num2 >= int_0 && int_0 > 0)
			{
				string_0 = stringBuilder.ToString().Substring(0, int_0);
			}
			result = (string_0 != null);
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001255 RID: 4693 RVA: 0x0000E79D File Offset: 0x0000C99D
	public long method_5(long long_0, SeekOrigin seekOrigin_0)
	{
		return this._base.Seek(long_0, seekOrigin_0);
	}

	// Token: 0x06001256 RID: 4694 RVA: 0x000692B0 File Offset: 0x000674B0
	public bool method_6(long long_0, SeekOrigin seekOrigin_0, byte[] byte_0)
	{
		if (byte_0 == null)
		{
			throw new ArgumentNullException("Parameter 'data' cannot be null");
		}
		bool result;
		try
		{
			this._base.Seek(long_0, seekOrigin_0);
			this._base.Write(byte_0, 0, byte_0.Length);
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x06001257 RID: 4695 RVA: 0x0006930C File Offset: 0x0006750C
	public bool method_7<T>(long long_0, SeekOrigin seekOrigin_0, T gparam_0) where T : struct
	{
		bool result;
		try
		{
			this._base.Seek(long_0, seekOrigin_0);
			byte[] array = null;
			if (!this._ubuffer.method_8<T>(gparam_0, out array))
			{
				throw this._ubuffer.vmethod_1();
			}
			this._base.Write(array, 0, array.Length);
			result = true;
		}
		catch (Exception exception_)
		{
			result = this.vmethod_2(exception_);
		}
		return result;
	}

	// Token: 0x04000A2C RID: 2604
	private MemoryStream _base;

	// Token: 0x04000A2D RID: 2605
	private bool _disposed;

	// Token: 0x04000A2E RID: 2606
	private GClass117 _ubuffer;
}
