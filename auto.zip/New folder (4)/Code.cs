﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001DC RID: 476
public partial class Code : Form
{
	// Token: 0x06001972 RID: 6514 RVA: 0x000127CE File Offset: 0x000109CE
	public Code()
	{
		if (Main.class159_0 != null)
		{
			this.class159_0 = Main.class159_0;
		}
		this.InitializeComponent();
	}

	// Token: 0x06001973 RID: 6515 RVA: 0x000B6BD8 File Offset: 0x000B4DD8
	private void btnCode_Click(object sender, EventArgs e)
	{
		string[] array = this.txtCode.Text.Split(new char[]
		{
			'\n'
		});
		for (int i = 0; i < array.Length; i++)
		{
			string text = array[i].Trim();
			if (text.Length > 5)
			{
				ListViewItem listViewItem = new ListViewItem(text);
				listViewItem.SubItems.Add("wait");
				this.listViewCode.Items.Add(listViewItem);
			}
		}
	}

	// Token: 0x06001974 RID: 6516 RVA: 0x000127EE File Offset: 0x000109EE
	private void Code_Load(object sender, EventArgs e)
	{
		base.Icon = GClass130.Icon_1;
		this.Text = this.class159_0.Class432_0.String_2;
	}

	// Token: 0x06001975 RID: 6517 RVA: 0x000B6C4C File Offset: 0x000B4E4C
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (this.class159_0 == null)
		{
			return;
		}
		bool flag = false;
		foreach (object obj in this.listViewCode.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			string text = listViewItem.Text;
			if (listViewItem.SubItems[1].Text == "wait")
			{
				listViewItem.SubItems[1].Text = "done";
				this.class159_0.method_282("setmetatable(_G, {__index = NewbieCardActivation_Env}); NewUserCard_YDPrize_OpenClick('" + text + "')", false);
				flag = true;
				break;
			}
		}
		if (!flag && (User.string_0 == "tieudattai@yahoo.com" || User.string_0 == "lecaotri@yahoo.com"))
		{
			string str = Code.smethod_0();
			this.class159_0.method_282("setmetatable(_G, {__index = NewbieCardActivation_Env}); NewUserCard_YDPrize_OpenClick('" + str + "')", false);
		}
	}

	// Token: 0x06001976 RID: 6518 RVA: 0x00012811 File Offset: 0x00010A11
	public static string smethod_0()
	{
		return "q0" + Code.smethod_1(16);
	}

	// Token: 0x06001977 RID: 6519 RVA: 0x00012824 File Offset: 0x00010A24
	public static string smethod_1(int int_0)
	{
		return new string(Enumerable.Repeat<string>("qwertyuiopasdfghjklzxcvbnm01234567890012345678900123456789001234567890012345678900123456789001234567890", int_0).Select(new Func<string, char>(Code.Class217.<>9.method_0)).ToArray<char>());
	}

	// Token: 0x06001978 RID: 6520 RVA: 0x0001285F File Offset: 0x00010A5F
	private void numericUpDown2_ValueChanged(object sender, EventArgs e)
	{
		this.timer_0.Interval = 1000 * (int)this.numericUpDown2.Value;
	}

	// Token: 0x06001979 RID: 6521 RVA: 0x00012882 File Offset: 0x00010A82
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000EEF RID: 3823
	private Class159 class159_0;

	// Token: 0x04000EF0 RID: 3824
	private static Random random_0 = new Random();

	// Token: 0x020001DD RID: 477
	[CompilerGenerated]
	[Serializable]
	private sealed class Class217
	{
		// Token: 0x0600197E RID: 6526 RVA: 0x000128B9 File Offset: 0x00010AB9
		internal char method_0(string string_0)
		{
			return string_0[Code.random_0.Next(string_0.Length)];
		}

		// Token: 0x04000EFD RID: 3837
		public static readonly Code.Class217 <>9 = new Code.Class217();

		// Token: 0x04000EFE RID: 3838
		public static Func<string, char> <>9__7_0;
	}
}
