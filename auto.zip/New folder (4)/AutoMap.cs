﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000219 RID: 537
internal class AutoMap : UserControl
{
	// Token: 0x06001CFC RID: 7420 RVA: 0x000D5A5C File Offset: 0x000D3C5C
	public AutoMap(Class159 class159_1)
	{
		AutoMap.Class247 @class = new AutoMap.Class247();
		@class.class159_0 = class159_1;
		base..ctor();
		this.class159_0 = @class.class159_0;
		this.InitializeComponent();
		this.lv.Columns[0].Text = @class.class159_0.Class432_0.string_7 + " [" + @class.class159_0.Class432_0.String_2 + "]";
		this.checkBox1.Checked = @class.class159_0.Boolean_12;
		base.Disposed += @class.method_0;
	}

	// Token: 0x06001CFD RID: 7421 RVA: 0x000D5AFC File Offset: 0x000D3CFC
	private void btnAdd_Click(object sender, EventArgs e)
	{
		string text = ((int)this.class159_0.Single_3).ToString() + "," + ((int)this.class159_0.Single_4).ToString();
		if (this.lv.Items.Count > 0 && this.lv.Items[this.lv.Items.Count - 1].Text == text)
		{
			return;
		}
		ListViewItem value = new ListViewItem(text);
		this.lv.Items.Add(value);
	}

	// Token: 0x06001CFE RID: 7422 RVA: 0x000D5B98 File Offset: 0x000D3D98
	private void btnSave_Click(object sender, EventArgs e)
	{
		string text = string.Empty;
		foreach (object obj in this.lv.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = text + listViewItem.Text + "-";
		}
		text = text.Trim(new char[]
		{
			'-'
		});
		Class415.smethod_4(this.class159_0.Class432_0.UInt32_29.ToString(), text);
	}

	// Token: 0x06001CFF RID: 7423 RVA: 0x000D5C3C File Offset: 0x000D3E3C
	private void AutoMap_Load(object sender, EventArgs e)
	{
		string text = Class415.smethod_5(this.class159_0.Class432_0.UInt32_29.ToString());
		int i;
		if (Class268.Boolean_69)
		{
			i = this.class159_0.Int32_12;
			string str = i.ToString();
			string str2 = ",";
			i = this.class159_0.Int32_13;
			string text2 = str + str2 + i.ToString() + "\r\n";
			string[] array = new string[5];
			array[0] = text2;
			int num = 1;
			i = this.class159_0.Int32_12 - 5;
			array[num] = i.ToString();
			array[2] = ",";
			int num2 = 3;
			i = this.class159_0.Int32_13 + 6;
			array[num2] = i.ToString();
			array[4] = "\r\n";
			text2 = string.Concat(array);
			string[] array2 = new string[5];
			array2[0] = text2;
			int num3 = 1;
			i = this.class159_0.Int32_12 + 5;
			array2[num3] = i.ToString();
			array2[2] = ",";
			int num4 = 3;
			i = this.class159_0.Int32_13 + 6;
			array2[num4] = i.ToString();
			array2[4] = "\r\n";
			text2 = string.Concat(array2);
			string[] array3 = new string[5];
			array3[0] = text2;
			int num5 = 1;
			i = this.class159_0.Int32_12 + 8;
			array3[num5] = i.ToString();
			array3[2] = ",";
			int num6 = 3;
			i = this.class159_0.Int32_13;
			array3[num6] = i.ToString();
			array3[4] = "\r\n";
			text2 = string.Concat(array3);
			string[] array4 = new string[5];
			array4[0] = text2;
			int num7 = 1;
			i = this.class159_0.Int32_12 + 5;
			array4[num7] = i.ToString();
			array4[2] = ",";
			int num8 = 3;
			i = this.class159_0.Int32_13 - 6;
			array4[num8] = i.ToString();
			array4[4] = "\r\n";
			text2 = string.Concat(array4);
			string[] array5 = new string[5];
			array5[0] = text2;
			int num9 = 1;
			i = this.class159_0.Int32_12 - 5;
			array5[num9] = i.ToString();
			array5[2] = ",";
			int num10 = 3;
			i = this.class159_0.Int32_13 - 6;
			array5[num10] = i.ToString();
			array5[4] = "\r\n";
			text2 = string.Concat(array5);
			string[] array6 = new string[5];
			array6[0] = text2;
			int num11 = 1;
			i = this.class159_0.Int32_12 - 8;
			array6[num11] = i.ToString();
			array6[2] = ",";
			int num12 = 3;
			i = this.class159_0.Int32_13;
			array6[num12] = i.ToString();
			array6[4] = "\r\n";
			text2 = string.Concat(array6);
			Clipboard.SetText(text2);
		}
		string[] array7 = text.Split(new char[]
		{
			'-'
		});
		i = 0;
		while (i < array7.Length)
		{
			string text3 = array7[i];
			int num13 = 0;
			int num14 = 0;
			try
			{
				num13 = Class426.smethod_43(text3.Split(new char[]
				{
					','
				})[0]);
				num14 = Class426.smethod_43(text3.Split(new char[]
				{
					','
				})[1]);
				goto IL_2E1;
			}
			catch
			{
				goto IL_2E1;
			}
			goto IL_2A6;
			IL_2D8:
			i++;
			continue;
			IL_2A6:
			if (num14 != 0)
			{
				this.lv.Items.Add(new ListViewItem(num13.ToString() + "," + num14.ToString()));
				goto IL_2D8;
			}
			goto IL_2D8;
			IL_2E1:
			if (num13 != 0)
			{
				goto IL_2A6;
			}
			goto IL_2D8;
		}
	}

	// Token: 0x06001D00 RID: 7424 RVA: 0x000155A3 File Offset: 0x000137A3
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		while (this.lv.SelectedItems.Count > 0)
		{
			this.lv.Items.Remove(this.lv.SelectedItems[0]);
		}
	}

	// Token: 0x06001D01 RID: 7425 RVA: 0x000155DC File Offset: 0x000137DC
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		this.class159_0.Boolean_12 = this.checkBox1.Checked;
	}

	// Token: 0x06001D02 RID: 7426 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06001D03 RID: 7427 RVA: 0x000155F4 File Offset: 0x000137F4
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001D04 RID: 7428 RVA: 0x000D5F40 File Offset: 0x000D4140
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(AutoMap));
		this.btnAdd = new Button();
		this.btnSave = new Button();
		this.mnuDelete = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.checkBox1 = new CheckBox();
		this.button1 = new Button();
		this.tableLayoutPanel1 = new TableLayoutPanel();
		this.lv = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.mnuDelete.SuspendLayout();
		this.tableLayoutPanel1.SuspendLayout();
		base.SuspendLayout();
		this.btnAdd.Dock = DockStyle.Fill;
		this.btnAdd.Location = new Point(87, 3);
		this.btnAdd.Name = "btnAdd";
		this.btnAdd.Size = new Size(78, 21);
		this.btnAdd.TabIndex = 2;
		this.btnAdd.Text = "Thêm Tọa Độ Hiện Tại - Add point";
		this.btnAdd.UseVisualStyleBackColor = true;
		this.btnAdd.Click += this.btnAdd_Click;
		this.btnSave.Dock = DockStyle.Fill;
		this.btnSave.Location = new Point(171, 3);
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new Size(81, 21);
		this.btnSave.TabIndex = 4;
		this.btnSave.Text = "Save";
		this.btnSave.UseVisualStyleBackColor = true;
		this.btnSave.Click += this.btnSave_Click;
		this.mnuDelete.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_0
		});
		this.mnuDelete.Name = "mnuDelete";
		this.mnuDelete.Size = new Size(95, 26);
		this.toolStripMenuItem_0.Name = "xóaToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(94, 22);
		this.toolStripMenuItem_0.Text = "Xóa";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.checkBox1.AutoSize = true;
		this.checkBox1.Location = new Point(3, 3);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new Size(72, 17);
		this.checkBox1.TabIndex = 5;
		this.checkBox1.Text = "Chạy Thử";
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.button1.Dock = DockStyle.Top;
		this.button1.Location = new Point(0, 0);
		this.button1.Name = "button1";
		this.button1.Size = new Size(255, 22);
		this.button1.TabIndex = 6;
		this.button1.Text = "Close";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.tableLayoutPanel1.ColumnCount = 3;
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333f));
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333f));
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333f));
		this.tableLayoutPanel1.Controls.Add(this.checkBox1, 0, 0);
		this.tableLayoutPanel1.Controls.Add(this.btnAdd, 1, 0);
		this.tableLayoutPanel1.Controls.Add(this.btnSave, 2, 0);
		this.tableLayoutPanel1.Dock = DockStyle.Bottom;
		this.tableLayoutPanel1.Location = new Point(0, 412);
		this.tableLayoutPanel1.Name = "tableLayoutPanel1";
		this.tableLayoutPanel1.RowCount = 1;
		this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		this.tableLayoutPanel1.Size = new Size(255, 27);
		this.tableLayoutPanel1.TabIndex = 7;
		this.lv.AllowColumnReorder = true;
		this.lv.AllowDrop = true;
		this.lv.AllowReorder = true;
		this.lv.AllowSort = false;
		this.lv.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lv.ContextMenuStrip = this.mnuDelete;
		this.lv.Dock = DockStyle.Fill;
		this.lv.DoubleClickActivation = false;
		this.lv.FullRowSelect = true;
		this.lv.GridLines = true;
		this.lv.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lv.hideItems");
		this.lv.HideSelection = false;
		this.lv.LineColor = Color.Red;
		this.lv.Location = new Point(0, 22);
		this.lv.Name = "lv";
		this.lv.Size = new Size(255, 390);
		this.lv.TabIndex = 0;
		this.lv.UseCompatibleStateImageBehavior = false;
		this.lv.View = View.Details;
		this.columnHeader_0.Text = "Tọa độ";
		this.columnHeader_0.Width = 218;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lv);
		base.Controls.Add(this.tableLayoutPanel1);
		base.Controls.Add(this.button1);
		base.Name = "AutoMap";
		base.Size = new Size(255, 439);
		base.Load += this.AutoMap_Load;
		this.mnuDelete.ResumeLayout(false);
		this.tableLayoutPanel1.ResumeLayout(false);
		this.tableLayoutPanel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x040011AD RID: 4525
	private Class159 class159_0;

	// Token: 0x040011AE RID: 4526
	private IContainer icontainer_0;

	// Token: 0x040011AF RID: 4527
	private ListViewEx lv;

	// Token: 0x040011B0 RID: 4528
	private Button btnAdd;

	// Token: 0x040011B1 RID: 4529
	private Button btnSave;

	// Token: 0x040011B2 RID: 4530
	private ColumnHeader columnHeader_0;

	// Token: 0x040011B3 RID: 4531
	private ContextMenuStrip mnuDelete;

	// Token: 0x040011B4 RID: 4532
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040011B5 RID: 4533
	private CheckBox checkBox1;

	// Token: 0x040011B6 RID: 4534
	private Button button1;

	// Token: 0x040011B7 RID: 4535
	private TableLayoutPanel tableLayoutPanel1;

	// Token: 0x0200021A RID: 538
	[CompilerGenerated]
	private sealed class Class247
	{
		// Token: 0x06001D06 RID: 7430 RVA: 0x00015613 File Offset: 0x00013813
		internal void method_0(object sender, EventArgs e)
		{
			this.class159_0.Boolean_12 = false;
		}

		// Token: 0x040011B8 RID: 4536
		public Class159 class159_0;
	}
}
