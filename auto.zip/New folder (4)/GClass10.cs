﻿using System;
using System.IO;

// Token: 0x0200001E RID: 30
public class GClass10 : GClass9
{
	// Token: 0x060001BF RID: 447 RVA: 0x00004281 File Offset: 0x00002481
	public GClass10(byte[] byte_1) : this(byte_1, 0, byte_1.Length)
	{
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x00026298 File Offset: 0x00024498
	public GClass10(byte[] byte_1, int int_2, int int_3)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (int_2 < 0)
		{
			throw Class13.smethod_1<int>("offset", 0);
		}
		if (int_2 > byte_1.Length)
		{
			throw Class13.smethod_2<int>("offset", byte_1.Length);
		}
		if (int_3 < 0)
		{
			throw Class13.smethod_1<int>("count", 0);
		}
		if (int_3 > byte_1.Length - int_2)
		{
			throw Class13.smethod_2<int>("count", byte_1.Length - int_2);
		}
		this.byte_0 = byte_1;
		this.int_0 = int_2;
		this.int_1 = int_3;
		this.string_0 = "application/octet-stream";
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x0000428E File Offset: 0x0000248E
	protected GClass10()
	{
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x00004296 File Offset: 0x00002496
	public override long \u206B\u200D\u200D\u200C\u206C\u206F\u202E\u206A\u202A\u206B\u202C\u206B\u202E\u202A\u202C\u200B\u202E\u202D\u206D\u206F\u202B\u200B\u206E\u200E\u200F\u200E\u200F\u202D\u200F\u206C\u206C\u206E\u206E\u202A\u206F\u200E\u206D\u200B\u206E\u206D\u202E()
	{
		return (long)this.byte_0.Length;
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x000042A0 File Offset: 0x000024A0
	public override void \u202B\u202D\u206D\u206A\u202D\u200D\u200C\u202A\u202A\u202B\u200C\u200D\u200E\u200B\u202C\u200C\u200D\u206C\u200F\u200E\u202A\u206D\u200B\u202E\u206B\u200B\u202D\u202A\u206E\u206F\u206D\u200E\u202B\u200D\u202B\u202D\u202D\u202A\u200D\u206F\u202E(Stream stream_0)
	{
		stream_0.Write(this.byte_0, this.int_0, this.int_1);
	}

	// Token: 0x0400010E RID: 270
	protected byte[] byte_0;

	// Token: 0x0400010F RID: 271
	protected int int_0;

	// Token: 0x04000110 RID: 272
	protected int int_1;
}
