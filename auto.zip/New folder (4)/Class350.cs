﻿using System;

// Token: 0x02000296 RID: 662
internal class Class350
{
	// Token: 0x1700078C RID: 1932
	// (get) Token: 0x06002492 RID: 9362 RVA: 0x0001BC83 File Offset: 0x00019E83
	public static string String_0
	{
		get
		{
			return "Đại Lý";
		}
	}

	// Token: 0x06002493 RID: 9363 RVA: 0x0010860C File Offset: 0x0010680C
	public static Class424 smethod_0(int int_1)
	{
		if (int_1 == Class381.int_10)
		{
			return Class350.class424_28;
		}
		if (int_1 == Class381.int_1)
		{
			return Class350.class424_29;
		}
		if (int_1 == Class381.int_7)
		{
			return Class350.class424_30;
		}
		if (int_1 == Class381.int_5)
		{
			return Class350.class424_31;
		}
		if (int_1 == Class381.int_6)
		{
			return Class350.class424_32;
		}
		if (int_1 == Class381.int_8)
		{
			return Class350.class424_33;
		}
		if (int_1 == Class381.int_9)
		{
			return Class350.class424_35;
		}
		if (int_1 == Class381.int_4)
		{
			return Class350.class424_36;
		}
		if (int_1 == Class381.int_2)
		{
			return Class350.class424_37;
		}
		if (int_1 == Class381.int_0)
		{
			return Class350.class424_38;
		}
		if (int_1 == Class381.int_3)
		{
			return Class350.class424_40;
		}
		if (int_1 == Class381.int_11)
		{
			return Class350.class424_39;
		}
		if (int_1 == Class381.int_12)
		{
			return Class350.class424_34;
		}
		return null;
	}

	// Token: 0x04001836 RID: 6198
	public static int int_0 = 2;

	// Token: 0x04001837 RID: 6199
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 165U,
		Int32_0 = 149,
		Int32_1 = 121,
		Int32_2 = Class350.int_0,
		String_2 = "Chúc Phúc Quý"
	};

	// Token: 0x04001838 RID: 6200
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 233U,
		Int32_0 = 206,
		Int32_1 = 53,
		Int32_2 = Class350.int_0,
		String_2 = "Thẩm Minh Lâu"
	};

	// Token: 0x04001839 RID: 6201
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 225U,
		Int32_0 = 293,
		Int32_1 = 92,
		Int32_2 = Class350.int_0,
		String_2 = "Lý Thanh La"
	};

	// Token: 0x0400183A RID: 6202
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 194U,
		Int32_0 = 185,
		Int32_1 = 104,
		Int32_2 = Class350.int_0,
		String_2 = "Chu Thúc Bân"
	};

	// Token: 0x0400183B RID: 6203
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 232U,
		Int32_0 = 211,
		Int32_1 = 51,
		Int32_2 = Class350.int_0,
		String_2 = "Thẩm Hàn Châu"
	};

	// Token: 0x0400183C RID: 6204
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 128U,
		Int32_0 = 68,
		Int32_1 = 178,
		Int32_2 = Class350.int_0,
		String_2 = "Trương Thế Bình"
	};

	// Token: 0x0400183D RID: 6205
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 145U,
		Int32_0 = 78,
		Int32_1 = 136,
		Int32_2 = Class350.int_0,
		String_2 = "Dư Trợ Chi"
	};

	// Token: 0x0400183E RID: 6206
	public static Class424 class424_7 = new Class424
	{
		UInt32_0 = 170U,
		Int32_0 = 242,
		Int32_1 = 31,
		Int32_2 = Class350.int_0,
		String_2 = "Tảo Địa Thần Tăng"
	};

	// Token: 0x0400183F RID: 6207
	public static Class424 class424_8 = new Class424
	{
		UInt32_0 = 118U,
		Int32_0 = 175,
		Int32_1 = 143,
		Int32_2 = Class350.int_0,
		String_2 = "Tôn Bát Gia"
	};

	// Token: 0x04001840 RID: 6208
	public static Class424 class424_9 = new Class424
	{
		UInt32_0 = 170U,
		Int32_0 = 139,
		Int32_1 = 197,
		Int32_2 = Class350.int_0,
		String_2 = "Võ Đồng"
	};

	// Token: 0x04001841 RID: 6209
	public static Class424 class424_10 = new Class424
	{
		UInt32_0 = 97U,
		Int32_0 = 189,
		Int32_1 = 65,
		Int32_2 = Class350.int_0,
		String_2 = "Thẩm Hàm Hương"
	};

	// Token: 0x04001842 RID: 6210
	public static Class424 class424_11 = new Class424
	{
		UInt32_0 = 24U,
		Int32_0 = 160,
		Int32_1 = 123,
		Int32_2 = Class350.int_0,
		String_2 = "Lý Công Bộ"
	};

	// Token: 0x04001843 RID: 6211
	public static Class424 class424_12 = new Class424
	{
		UInt32_0 = 174U,
		Int32_0 = 182,
		Int32_1 = 69,
		Int32_2 = Class350.int_0,
		String_2 = "Ba Cái Lý"
	};

	// Token: 0x04001844 RID: 6212
	public static Class424 class424_13 = new Class424
	{
		UInt32_0 = 173U,
		Int32_0 = 185,
		Int32_1 = 65,
		Int32_2 = Class350.int_0,
		String_2 = "A Lý"
	};

	// Token: 0x04001845 RID: 6213
	public static Class424 class424_14 = new Class424
	{
		UInt32_0 = 21U,
		Int32_0 = 71,
		Int32_1 = 28,
		Int32_2 = Class350.int_0,
		String_2 = "Hoa Hách Cấn"
	};

	// Token: 0x04001846 RID: 6214
	public static Class424 class424_15 = new Class424
	{
		UInt32_0 = 182U,
		Int32_0 = 70,
		Int32_1 = 58,
		Int32_2 = Class350.int_0,
		String_2 = "Chu Đan Thần"
	};

	// Token: 0x04001847 RID: 6215
	public static Class424 class424_16 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 203,
		Int32_1 = 177,
		Int32_2 = Class350.int_0,
		String_2 = "Hầu bàn Chu"
	};

	// Token: 0x04001848 RID: 6216
	public static Class424 class424_17 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 201,
		Int32_1 = 177,
		Int32_2 = Class350.int_0,
		String_2 = "Hầu bàn Chu "
	};

	// Token: 0x04001849 RID: 6217
	public static Class424 class424_18 = new Class424
	{
		UInt32_0 = 35U,
		Int32_0 = 271,
		Int32_1 = 133,
		Int32_2 = Class350.int_0,
		String_2 = "Vân Phiêu Phiêu"
	};

	// Token: 0x0400184A RID: 6218
	public static Class424 class424_19 = new Class424
	{
		UInt32_0 = 166U,
		Int32_0 = 131,
		Int32_1 = 79,
		Int32_2 = Class350.int_0,
		String_2 = "Khô Vinh Đại Sư"
	};

	// Token: 0x0400184B RID: 6219
	public static Class424 class424_20 = new Class424
	{
		UInt32_0 = 138U,
		Int32_0 = 160,
		Int32_1 = 159,
		Int32_2 = Class350.int_0,
		String_2 = "Triệu Thiên Sư"
	};

	// Token: 0x0400184C RID: 6220
	public static Class424 class424_21 = new Class424
	{
		UInt32_0 = 177U,
		Int32_0 = 182,
		Int32_1 = 197,
		Int32_2 = Class350.int_0,
		String_2 = "Cầu Phúc Thiên Quan"
	};

	// Token: 0x0400184D RID: 6221
	public static Class424 class424_22 = new Class424
	{
		UInt32_0 = 163U,
		Int32_0 = 179,
		Int32_1 = 121,
		Int32_2 = Class350.int_0,
		String_2 = "Phạm Thuần Lễ"
	};

	// Token: 0x0400184E RID: 6222
	public static Class424 class424_23 = new Class424
	{
		UInt32_0 = 157U,
		Int32_0 = 181,
		Int32_1 = 139,
		Int32_2 = Class350.int_0,
		String_2 = "Hồng Đại Quý"
	};

	// Token: 0x0400184F RID: 6223
	public static Class424 class424_24 = new Class424
	{
		UInt32_0 = 163U,
		Int32_0 = 94,
		Int32_1 = 201,
		Int32_2 = Class350.int_0,
		String_2 = "Phó Kiếp Sinh"
	};

	// Token: 0x04001850 RID: 6224
	public static Class424 class424_25 = new Class424
	{
		UInt32_0 = 131U,
		Int32_0 = 139,
		Int32_1 = 132,
		Int32_2 = Class350.int_0,
		String_2 = "Nhiếp Chính"
	};

	// Token: 0x04001851 RID: 6225
	public static Class424 class424_26 = new Class424
	{
		UInt32_0 = 12U,
		Int32_0 = 105,
		Int32_1 = 123,
		Int32_2 = Class350.int_0,
		String_2 = "Lô Tam Thất"
	};

	// Token: 0x04001852 RID: 6226
	public static Class424 class424_27 = new Class424
	{
		UInt32_0 = 16U,
		Int32_0 = 71,
		Int32_1 = 18,
		Int32_2 = Class350.int_0,
		String_2 = "Đoàn Chính Thuần"
	};

	// Token: 0x04001853 RID: 6227
	public static Class424 class424_28 = new Class424
	{
		UInt32_0 = 195U,
		Int32_0 = 166,
		Int32_1 = 139,
		Int32_2 = Class350.int_0,
		String_2 = "Đường Dục"
	};

	// Token: 0x04001854 RID: 6228
	public static Class424 class424_29 = new Class424
	{
		UInt32_0 = 29U,
		Int32_0 = 166,
		Int32_1 = 136,
		Int32_2 = Class350.int_0,
		String_2 = "Thạch Bảo"
	};

	// Token: 0x04001855 RID: 6229
	public static Class424 class424_30 = new Class424
	{
		UInt32_0 = 62U,
		Int32_0 = 166,
		Int32_1 = 133,
		Int32_2 = Class350.int_0,
		String_2 = "Trình Thanh Sương"
	};

	// Token: 0x04001856 RID: 6230
	public static Class424 class424_31 = new Class424
	{
		UInt32_0 = 28U,
		Int32_0 = 166,
		Int32_1 = 130,
		Int32_2 = Class350.int_0,
		String_2 = "Hải Phong Tử"
	};

	// Token: 0x04001857 RID: 6231
	public static Class424 class424_32 = new Class424
	{
		UInt32_0 = 95U,
		Int32_0 = 166,
		Int32_1 = 127,
		Int32_2 = Class350.int_0,
		String_2 = "Phá Tham"
	};

	// Token: 0x04001858 RID: 6232
	public static Class424 class424_33 = new Class424
	{
		UInt32_0 = 26U,
		Int32_0 = 166,
		Int32_1 = 124,
		Int32_2 = Class350.int_0,
		String_2 = "Đàm Đài Tử Vũ"
	};

	// Token: 0x04001859 RID: 6233
	public static Class424 class424_34 = new Class424
	{
		UInt32_0 = 231U,
		Int32_0 = 166,
		Int32_1 = 142,
		Int32_2 = Class350.int_0,
		String_2 = "Hoàng Thời Vũ"
	};

	// Token: 0x0400185A RID: 6234
	public static Class424 class424_35 = new Class424
	{
		UInt32_0 = 177U,
		Int32_0 = 154,
		Int32_1 = 138,
		Int32_2 = Class350.int_0,
		String_2 = "Mộ Dung Truyền"
	};

	// Token: 0x0400185B RID: 6235
	public static Class424 class424_36 = new Class424
	{
		UInt32_0 = 64U,
		Int32_0 = 154,
		Int32_1 = 135,
		Int32_2 = Class350.int_0,
		String_2 = "Lộ Tam Nương"
	};

	// Token: 0x0400185C RID: 6236
	public static Class424 class424_37 = new Class424
	{
		UInt32_0 = 27U,
		Int32_0 = 154,
		Int32_1 = 131,
		Int32_2 = Class350.int_0,
		String_2 = "Giản Ninh"
	};

	// Token: 0x0400185D RID: 6237
	public static Class424 class424_38 = new Class424
	{
		UInt32_0 = 25U,
		Int32_0 = 154,
		Int32_1 = 128,
		Int32_2 = Class350.int_0,
		String_2 = "Tuệ Dịch"
	};

	// Token: 0x0400185E RID: 6238
	public static Class424 class424_39 = new Class424
	{
		UInt32_0 = 226U,
		Int32_0 = 154,
		Int32_1 = 142,
		Int32_2 = Class350.int_0,
		String_2 = "Dương Tiệm"
	};

	// Token: 0x0400185F RID: 6239
	public static Class424 class424_40 = new Class424
	{
		UInt32_0 = 30U,
		Int32_0 = 154,
		Int32_1 = 124,
		Int32_2 = Class350.int_0,
		String_2 = "Trương Hoạch"
	};
}
