﻿// Token: 0x020001EB RID: 491
public partial class InputBox : global::System.Windows.Forms.Form
{
	// Token: 0x060019E6 RID: 6630 RVA: 0x000BBE4C File Offset: 0x000BA04C
	private void InitializeComponent()
	{
		this.textBoxEx1 = new global::Class85();
		this.button1 = new global::System.Windows.Forms.Button();
		base.SuspendLayout();
		this.textBoxEx1.Dock = global::System.Windows.Forms.DockStyle.Top;
		this.textBoxEx1.Location = new global::System.Drawing.Point(0, 0);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new global::System.Drawing.Size(398, 20);
		this.textBoxEx1.TabIndex = 0;
		this.textBoxEx1.String_0 = "";
		this.textBoxEx1.Color_0 = global::System.Drawing.Color.Gray;
		this.textBoxEx1.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = global::System.Drawing.Color.LightGray;
		this.button1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.button1.Location = new global::System.Drawing.Point(0, 20);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(398, 20);
		this.button1.TabIndex = 1;
		this.button1.Text = "Ok";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(398, 40);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.textBoxEx1);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "InputBox";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "InputBox";
		base.Load += new global::System.EventHandler(this.InputBox_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000F51 RID: 3921
	private global::Class85 textBoxEx1;

	// Token: 0x04000F52 RID: 3922
	private global::System.Windows.Forms.Button button1;
}
