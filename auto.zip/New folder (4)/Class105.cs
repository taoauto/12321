﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x02000105 RID: 261
internal class Class105
{
	// Token: 0x06000D64 RID: 3428 RVA: 0x00050560 File Offset: 0x0004E760
	public Class105(Keys keys_1, FCTBAction fctbaction_1)
	{
		KeyEventArgs keyEventArgs = new KeyEventArgs(keys_1);
		this.bool_0 = keyEventArgs.Control;
		this.bool_1 = keyEventArgs.Shift;
		this.bool_2 = keyEventArgs.Alt;
		this.Keys_0 = keyEventArgs.KeyCode;
		this.FCTBAction_0 = fctbaction_1;
	}

	// Token: 0x06000D65 RID: 3429 RVA: 0x000505B4 File Offset: 0x0004E7B4
	public Keys method_0()
	{
		Keys keys = this.Keys_0;
		if (this.bool_0)
		{
			keys |= Keys.Control;
		}
		if (this.bool_2)
		{
			keys |= Keys.Alt;
		}
		if (this.bool_1)
		{
			keys |= Keys.Shift;
		}
		return keys;
	}

	// Token: 0x1700038B RID: 907
	// (get) Token: 0x06000D66 RID: 3430 RVA: 0x000505FC File Offset: 0x0004E7FC
	// (set) Token: 0x06000D67 RID: 3431 RVA: 0x00050664 File Offset: 0x0004E864
	public string String_0
	{
		get
		{
			string text = "";
			if (this.bool_0)
			{
				text += "Ctrl + ";
			}
			if (this.bool_1)
			{
				text += "Shift + ";
			}
			if (this.bool_2)
			{
				text += "Alt + ";
			}
			return text.Trim(new char[]
			{
				' ',
				'+'
			});
		}
		set
		{
			if (value == null)
			{
				this.bool_1 = false;
				this.bool_2 = false;
				this.bool_0 = false;
				return;
			}
			this.bool_0 = value.Contains("Ctrl");
			this.bool_1 = value.Contains("Shift");
			this.bool_2 = value.Contains("Alt");
		}
	}

	// Token: 0x1700038C RID: 908
	// (get) Token: 0x06000D68 RID: 3432 RVA: 0x0000B9E4 File Offset: 0x00009BE4
	// (set) Token: 0x06000D69 RID: 3433 RVA: 0x0000B9EC File Offset: 0x00009BEC
	public Keys Keys_0 { get; set; }

	// Token: 0x1700038D RID: 909
	// (get) Token: 0x06000D6A RID: 3434 RVA: 0x0000B9F5 File Offset: 0x00009BF5
	// (set) Token: 0x06000D6B RID: 3435 RVA: 0x0000B9FD File Offset: 0x00009BFD
	public FCTBAction FCTBAction_0 { get; set; }

	// Token: 0x0400069C RID: 1692
	private bool bool_0;

	// Token: 0x0400069D RID: 1693
	private bool bool_1;

	// Token: 0x0400069E RID: 1694
	private bool bool_2;

	// Token: 0x0400069F RID: 1695
	[CompilerGenerated]
	private Keys keys_0;

	// Token: 0x040006A0 RID: 1696
	[CompilerGenerated]
	private FCTBAction fctbaction_0;
}
