﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000303 RID: 771
internal class Class424
{
	// Token: 0x06002C15 RID: 11285 RVA: 0x000203DA File Offset: 0x0001E5DA
	public Class424()
	{
		this.UInt32_0 = 0U;
	}

	// Token: 0x170009FF RID: 2559
	// (get) Token: 0x06002C16 RID: 11286 RVA: 0x0002040A File Offset: 0x0001E60A
	// (set) Token: 0x06002C17 RID: 11287 RVA: 0x00020412 File Offset: 0x0001E612
	public uint UInt32_0 { get; set; }

	// Token: 0x17000A00 RID: 2560
	// (get) Token: 0x06002C18 RID: 11288 RVA: 0x0002041B File Offset: 0x0001E61B
	// (set) Token: 0x06002C19 RID: 11289 RVA: 0x00020423 File Offset: 0x0001E623
	public int Int32_0 { get; set; }

	// Token: 0x17000A01 RID: 2561
	// (get) Token: 0x06002C1A RID: 11290 RVA: 0x0002042C File Offset: 0x0001E62C
	// (set) Token: 0x06002C1B RID: 11291 RVA: 0x00020434 File Offset: 0x0001E634
	public int Int32_1 { get; set; }

	// Token: 0x17000A02 RID: 2562
	// (get) Token: 0x06002C1C RID: 11292 RVA: 0x0002043D File Offset: 0x0001E63D
	// (set) Token: 0x06002C1D RID: 11293 RVA: 0x00020445 File Offset: 0x0001E645
	public int Int32_2 { get; set; }

	// Token: 0x17000A03 RID: 2563
	// (get) Token: 0x06002C1E RID: 11294 RVA: 0x0002044E File Offset: 0x0001E64E
	// (set) Token: 0x06002C1F RID: 11295 RVA: 0x00020456 File Offset: 0x0001E656
	public string String_0 { get; set; } = string.Empty;

	// Token: 0x17000A04 RID: 2564
	// (get) Token: 0x06002C20 RID: 11296 RVA: 0x0002045F File Offset: 0x0001E65F
	// (set) Token: 0x06002C21 RID: 11297 RVA: 0x00020467 File Offset: 0x0001E667
	public string String_1 { get; set; } = "000";

	// Token: 0x17000A05 RID: 2565
	// (get) Token: 0x06002C22 RID: 11298 RVA: 0x00020470 File Offset: 0x0001E670
	// (set) Token: 0x06002C23 RID: 11299 RVA: 0x00020478 File Offset: 0x0001E678
	public string String_2 { get; set; } = string.Empty;

	// Token: 0x04001D4C RID: 7500
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001D4D RID: 7501
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04001D4E RID: 7502
	[CompilerGenerated]
	private int int_1;

	// Token: 0x04001D4F RID: 7503
	[CompilerGenerated]
	private int int_2;

	// Token: 0x04001D50 RID: 7504
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001D51 RID: 7505
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001D52 RID: 7506
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04001D53 RID: 7507
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 191U,
		Int32_0 = 255,
		Int32_1 = 320,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D54 RID: 7508
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 18U,
		Int32_0 = 270,
		Int32_1 = 232,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D55 RID: 7509
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 143U,
		Int32_0 = 249,
		Int32_1 = 172,
		Int32_2 = Class365.Int32_2
	};

	// Token: 0x04001D56 RID: 7510
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 157U,
		Int32_0 = 181,
		Int32_1 = 139,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D57 RID: 7511
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 153U,
		Int32_0 = 172,
		Int32_1 = 122,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D58 RID: 7512
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 366,
		Int32_1 = 228,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D59 RID: 7513
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 21U,
		Int32_0 = 71,
		Int32_1 = 28,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D5A RID: 7514
	public static Class424 class424_7 = new Class424
	{
		UInt32_0 = 138U,
		Int32_0 = 160,
		Int32_1 = 158,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D5B RID: 7515
	public static Class424 class424_8 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 77,
		Int32_1 = 34,
		Int32_2 = Class365.Int32_52
	};

	// Token: 0x04001D5C RID: 7516
	public static Class424 class424_9 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 48,
		Int32_1 = 144,
		Int32_2 = Class365.Int32_51
	};

	// Token: 0x04001D5D RID: 7517
	public static Class424 class424_10 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 95,
		Int32_1 = 75,
		Int32_2 = Class365.Int32_19
	};

	// Token: 0x04001D5E RID: 7518
	public static Class424 class424_11 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 125,
		Int32_1 = 144,
		Int32_2 = Class365.Int32_17
	};

	// Token: 0x04001D5F RID: 7519
	public static Class424 class424_12 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 89,
		Int32_1 = 72,
		Int32_2 = Class365.Int32_12
	};

	// Token: 0x04001D60 RID: 7520
	public static Class424 class424_13 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 91,
		Int32_1 = 44,
		Int32_2 = Class365.Int32_20
	};

	// Token: 0x04001D61 RID: 7521
	public static Class424 class424_14 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 96,
		Int32_1 = 66,
		Int32_2 = Class365.Int32_16
	};

	// Token: 0x04001D62 RID: 7522
	public static Class424 class424_15 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 96,
		Int32_1 = 51,
		Int32_2 = Class365.Int32_18
	};

	// Token: 0x04001D63 RID: 7523
	public static Class424 class424_16 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 77,
		Int32_1 = 85,
		Int32_2 = Class365.Int32_15
	};

	// Token: 0x04001D64 RID: 7524
	public static Class424 class424_17 = new Class424
	{
		UInt32_0 = 11U,
		Int32_0 = 108,
		Int32_1 = 56,
		Int32_2 = Class365.Int32_13
	};

	// Token: 0x04001D65 RID: 7525
	public static Class424 class424_18 = new Class424
	{
		UInt32_0 = 23U,
		Int32_0 = 91,
		Int32_1 = 98,
		Int32_2 = Class365.Int32_14
	};

	// Token: 0x04001D66 RID: 7526
	public static Class424 class424_19 = new Class424
	{
		UInt32_0 = 13176U,
		Int32_0 = 159,
		Int32_1 = 54,
		Int32_2 = Class365.Int32_91
	};

	// Token: 0x04001D67 RID: 7527
	public static Class424 class424_20 = new Class424
	{
		UInt32_0 = 13157U,
		Int32_0 = 124,
		Int32_1 = 86,
		Int32_2 = Class365.Int32_91
	};

	// Token: 0x04001D68 RID: 7528
	public static Class424 class424_21 = new Class424
	{
		UInt32_0 = 13158U,
		Int32_0 = 41,
		Int32_1 = 105,
		Int32_2 = Class365.Int32_91
	};

	// Token: 0x04001D69 RID: 7529
	public static Class424 class424_22 = new Class424
	{
		UInt32_0 = 13159U,
		Int32_0 = 117,
		Int32_1 = 49,
		Int32_2 = Class365.Int32_91
	};

	// Token: 0x04001D6A RID: 7530
	public static Class424 class424_23 = new Class424
	{
		UInt32_0 = 56U,
		Int32_0 = 193,
		Int32_1 = 224,
		Int32_2 = Class365.Int32_86
	};

	// Token: 0x04001D6B RID: 7531
	public static Class424 class424_24 = new Class424
	{
		UInt32_0 = 160U,
		Int32_0 = 223,
		Int32_1 = 138,
		Int32_2 = Class365.Int32_35
	};

	// Token: 0x04001D6C RID: 7532
	public static Class424 class424_25 = new Class424
	{
		UInt32_0 = 173U,
		Int32_0 = 185,
		Int32_1 = 65,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D6D RID: 7533
	public static Class424 class424_26 = new Class424
	{
		UInt32_0 = 174U,
		Int32_0 = 182,
		Int32_1 = 66,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D6E RID: 7534
	public static Class424 class424_27 = new Class424
	{
		UInt32_0 = 24U,
		Int32_0 = 98,
		Int32_1 = 145,
		Int32_2 = Class365.Int32_12
	};

	// Token: 0x04001D6F RID: 7535
	public static Class424 class424_28 = new Class424
	{
		UInt32_0 = 20U,
		Int32_0 = 93,
		Int32_1 = 152,
		Int32_2 = Class365.Int32_14
	};

	// Token: 0x04001D70 RID: 7536
	public static Class424 class424_29 = new Class424
	{
		UInt32_0 = 29U,
		Int32_0 = 95,
		Int32_1 = 161,
		Int32_2 = Class365.Int32_13
	};

	// Token: 0x04001D71 RID: 7537
	public static Class424 class424_30 = new Class424
	{
		UInt32_0 = 21U,
		Int32_0 = 100,
		Int32_1 = 181,
		Int32_2 = Class365.Int32_15
	};

	// Token: 0x04001D72 RID: 7538
	public static Class424 class424_31 = new Class424
	{
		UInt32_0 = 25U,
		Int32_0 = 99,
		Int32_1 = 142,
		Int32_2 = Class365.Int32_16
	};

	// Token: 0x04001D73 RID: 7539
	public static Class424 class424_32 = new Class424
	{
		UInt32_0 = 18U,
		Int32_0 = 44,
		Int32_1 = 125,
		Int32_2 = Class365.Int32_17
	};

	// Token: 0x04001D74 RID: 7540
	public static Class424 class424_33 = new Class424
	{
		UInt32_0 = 29U,
		Int32_0 = 94,
		Int32_1 = 147,
		Int32_2 = Class365.Int32_18
	};

	// Token: 0x04001D75 RID: 7541
	public static Class424 class424_34 = new Class424
	{
		UInt32_0 = 21U,
		Int32_0 = 100,
		Int32_1 = 143,
		Int32_2 = Class365.Int32_19
	};

	// Token: 0x04001D76 RID: 7542
	public static Class424 class424_35 = new Class424
	{
		UInt32_0 = 33U,
		Int32_0 = 96,
		Int32_1 = 148,
		Int32_2 = Class365.Int32_20
	};

	// Token: 0x04001D77 RID: 7543
	public static Class424 class424_36 = new Class424
	{
		UInt32_0 = 7U,
		Int32_0 = 159,
		Int32_1 = 163,
		Int32_2 = Class365.Int32_51
	};

	// Token: 0x04001D78 RID: 7544
	public static Class424 class424_37 = new Class424
	{
		UInt32_0 = 7U,
		Int32_0 = 152,
		Int32_1 = 154,
		Int32_2 = Class365.Int32_52
	};

	// Token: 0x04001D79 RID: 7545
	public static Class424 class424_38 = new Class424
	{
		UInt32_0 = 203U,
		Int32_0 = 273,
		Int32_1 = 242,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D7A RID: 7546
	public static Class424 class424_39 = new Class424
	{
		UInt32_0 = 5120U,
		Int32_0 = 256,
		Int32_1 = 246,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D7B RID: 7547
	public static Class424 class424_40 = new Class424
	{
		UInt32_0 = 12498U,
		Int32_0 = 256,
		Int32_1 = 246,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D7C RID: 7548
	public static Class424 class424_41 = new Class424
	{
		UInt32_0 = 178U,
		Int32_0 = 180,
		Int32_1 = 197,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D7D RID: 7549
	public static Class424 class424_42 = new Class424
	{
		UInt32_0 = 12U,
		Int32_0 = 105,
		Int32_1 = 123,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D7E RID: 7550
	public static Class424 class424_43 = new Class424
	{
		UInt32_0 = 16U,
		Int32_0 = 71,
		Int32_1 = 18,
		Int32_2 = Class365.Int32_3
	};

	// Token: 0x04001D7F RID: 7551
	public static Class424 class424_44 = new Class424
	{
		UInt32_0 = 34U,
		Int32_0 = 176,
		Int32_1 = 192,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001D80 RID: 7552
	public static Class424 class424_45 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 166,
		Int32_1 = 311,
		Int32_2 = Class365.Int32_2
	};

	// Token: 0x04001D81 RID: 7553
	public static Class424 class424_46 = new Class424
	{
		UInt32_0 = 120U,
		Int32_0 = 243,
		Int32_1 = 150,
		Int32_2 = 35
	};

	// Token: 0x04001D82 RID: 7554
	public static Class424 class424_47 = new Class424
	{
		UInt32_0 = 119U,
		Int32_0 = 273,
		Int32_1 = 52,
		Int32_2 = 35
	};

	// Token: 0x04001D83 RID: 7555
	public static Class424 class424_48 = new Class424
	{
		UInt32_0 = 110U,
		Int32_0 = 80,
		Int32_1 = 139,
		Int32_2 = 35
	};

	// Token: 0x04001D84 RID: 7556
	public static Class424 class424_49 = new Class424
	{
		UInt32_0 = 116U,
		Int32_0 = 293,
		Int32_1 = 59,
		Int32_2 = 34
	};

	// Token: 0x04001D85 RID: 7557
	public static Class424 class424_50 = new Class424
	{
		UInt32_0 = 117U,
		Int32_0 = 107,
		Int32_1 = 228,
		Int32_2 = 34
	};

	// Token: 0x04001D86 RID: 7558
	public static Class424 class424_51 = new Class424
	{
		UInt32_0 = 109U,
		Int32_0 = 134,
		Int32_1 = 40,
		Int32_2 = 34
	};

	// Token: 0x04001D87 RID: 7559
	public static Class424 class424_52 = new Class424
	{
		UInt32_0 = 151U,
		Int32_0 = 256,
		Int32_1 = 39,
		Int32_2 = 32
	};

	// Token: 0x04001D88 RID: 7560
	public static Class424 class424_53 = new Class424
	{
		UInt32_0 = 150U,
		Int32_0 = 113,
		Int32_1 = 281,
		Int32_2 = 32
	};

	// Token: 0x04001D89 RID: 7561
	public static Class424 class424_54 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 92,
		Int32_1 = 171,
		Int32_2 = 32
	};

	// Token: 0x04001D8A RID: 7562
	public static Class424 class424_55 = new Class424
	{
		UInt32_0 = 159U,
		Int32_0 = 271,
		Int32_1 = 37,
		Int32_2 = 33
	};

	// Token: 0x04001D8B RID: 7563
	public static Class424 class424_56 = new Class424
	{
		UInt32_0 = 151U,
		Int32_0 = 31,
		Int32_1 = 90,
		Int32_2 = 33
	};

	// Token: 0x04001D8C RID: 7564
	public static Class424 class424_57 = new Class424
	{
		UInt32_0 = 158U,
		Int32_0 = 283,
		Int32_1 = 236,
		Int32_2 = 33
	};

	// Token: 0x04001D8D RID: 7565
	public static Class424 class424_58 = new Class424
	{
		UInt32_0 = 40U,
		Int32_0 = 262,
		Int32_1 = 232,
		Int32_2 = 30
	};

	// Token: 0x04001D8E RID: 7566
	public static Class424 class424_59 = new Class424
	{
		UInt32_0 = 39U,
		Int32_0 = 45,
		Int32_1 = 267,
		Int32_2 = 30
	};

	// Token: 0x04001D8F RID: 7567
	public static Class424 class424_60 = new Class424
	{
		UInt32_0 = 23U,
		Int32_0 = 39,
		Int32_1 = 139,
		Int32_2 = 30
	};

	// Token: 0x04001D90 RID: 7568
	public static Class424 class424_61 = new Class424
	{
		UInt32_0 = 143U,
		Int32_0 = 218,
		Int32_1 = 282,
		Int32_2 = 31
	};

	// Token: 0x04001D91 RID: 7569
	public static Class424 class424_62 = new Class424
	{
		UInt32_0 = 141U,
		Int32_0 = 63,
		Int32_1 = 33,
		Int32_2 = 31
	};

	// Token: 0x04001D92 RID: 7570
	public static Class424 class424_63 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 36,
		Int32_1 = 121,
		Int32_2 = 31
	};

	// Token: 0x04001D93 RID: 7571
	public static Class424 class424_64 = new Class424
	{
		UInt32_0 = 140U,
		Int32_0 = 283,
		Int32_1 = 113,
		Int32_2 = 18
	};

	// Token: 0x04001D94 RID: 7572
	public static Class424 class424_65 = new Class424
	{
		UInt32_0 = 139U,
		Int32_0 = 102,
		Int32_1 = 36,
		Int32_2 = 18
	};

	// Token: 0x04001D95 RID: 7573
	public static Class424 class424_66 = new Class424
	{
		UInt32_0 = 138U,
		Int32_0 = 72,
		Int32_1 = 284,
		Int32_2 = 18
	};

	// Token: 0x04001D96 RID: 7574
	public static Class424 class424_67 = new Class424
	{
		UInt32_0 = 121U,
		Int32_0 = 235,
		Int32_1 = 24,
		Int32_2 = 19
	};

	// Token: 0x04001D97 RID: 7575
	public static Class424 class424_68 = new Class424
	{
		UInt32_0 = 120U,
		Int32_0 = 116,
		Int32_1 = 30,
		Int32_2 = 19
	};

	// Token: 0x04001D98 RID: 7576
	public static Class424 class424_69 = new Class424
	{
		UInt32_0 = 115U,
		Int32_0 = 32,
		Int32_1 = 128,
		Int32_2 = 19
	};

	// Token: 0x04001D99 RID: 7577
	public static Class424 class424_70 = new Class424
	{
		UInt32_0 = 173U,
		Int32_0 = 97,
		Int32_1 = 282,
		Int32_2 = 20
	};

	// Token: 0x04001D9A RID: 7578
	public static Class424 class424_71 = new Class424
	{
		UInt32_0 = 174U,
		Int32_0 = 271,
		Int32_1 = 192,
		Int32_2 = 20
	};

	// Token: 0x04001D9B RID: 7579
	public static Class424 class424_72 = new Class424
	{
		UInt32_0 = 166U,
		Int32_0 = 66,
		Int32_1 = 202,
		Int32_2 = 20
	};

	// Token: 0x04001D9C RID: 7580
	public static Class424 class424_73 = new Class424
	{
		UInt32_0 = 152U,
		Int32_0 = 278,
		Int32_1 = 258,
		Int32_2 = 21
	};

	// Token: 0x04001D9D RID: 7581
	public static Class424 class424_74 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 75,
		Int32_1 = 35,
		Int32_2 = 21
	};

	// Token: 0x04001D9E RID: 7582
	public static Class424 class424_75 = new Class424
	{
		UInt32_0 = 151U,
		Int32_0 = 40,
		Int32_1 = 142,
		Int32_2 = 21
	};

	// Token: 0x04001D9F RID: 7583
	public static Class424 class424_76 = new Class424
	{
		UInt32_0 = 148U,
		Int32_0 = 217,
		Int32_1 = 282,
		Int32_2 = 22
	};

	// Token: 0x04001DA0 RID: 7584
	public static Class424 class424_77 = new Class424
	{
		UInt32_0 = 119U,
		Int32_0 = 39,
		Int32_1 = 63,
		Int32_2 = 22
	};

	// Token: 0x04001DA1 RID: 7585
	public static Class424 class424_78 = new Class424
	{
		UInt32_0 = 147U,
		Int32_0 = 280,
		Int32_1 = 155,
		Int32_2 = 22
	};

	// Token: 0x04001DA2 RID: 7586
	public static Class424 class424_79 = new Class424
	{
		UInt32_0 = 143U,
		Int32_0 = 290,
		Int32_1 = 116,
		Int32_2 = 23
	};

	// Token: 0x04001DA3 RID: 7587
	public static Class424 class424_80 = new Class424
	{
		UInt32_0 = 114U,
		Int32_0 = 28,
		Int32_1 = 54,
		Int32_2 = 23
	};

	// Token: 0x04001DA4 RID: 7588
	public static Class424 class424_81 = new Class424
	{
		UInt32_0 = 144U,
		Int32_0 = 254,
		Int32_1 = 286,
		Int32_2 = 23
	};

	// Token: 0x04001DA5 RID: 7589
	public static Class424 class424_82 = new Class424
	{
		UInt32_0 = 46U,
		Int32_0 = 286,
		Int32_1 = 166,
		Int32_2 = 24
	};

	// Token: 0x04001DA6 RID: 7590
	public static Class424 class424_83 = new Class424
	{
		UInt32_0 = 45U,
		Int32_0 = 173,
		Int32_1 = 284,
		Int32_2 = 24
	};

	// Token: 0x04001DA7 RID: 7591
	public static Class424 class424_84 = new Class424
	{
		UInt32_0 = 43U,
		Int32_0 = 34,
		Int32_1 = 100,
		Int32_2 = 24
	};

	// Token: 0x04001DA8 RID: 7592
	public static Class424 class424_85 = new Class424
	{
		UInt32_0 = 70U,
		Int32_0 = 37,
		Int32_1 = 172,
		Int32_2 = 25
	};

	// Token: 0x04001DA9 RID: 7593
	public static Class424 class424_86 = new Class424
	{
		UInt32_0 = 161U,
		Int32_0 = 295,
		Int32_1 = 154,
		Int32_2 = 25
	};

	// Token: 0x04001DAA RID: 7594
	public static Class424 class424_87 = new Class424
	{
		UInt32_0 = 160U,
		Int32_0 = 146,
		Int32_1 = 285,
		Int32_2 = 25
	};

	// Token: 0x04001DAB RID: 7595
	public static Class424 class424_88 = new Class424
	{
		UInt32_0 = 146U,
		Int32_0 = 227,
		Int32_1 = 37,
		Int32_2 = 26
	};

	// Token: 0x04001DAC RID: 7596
	public static Class424 class424_89 = new Class424
	{
		UInt32_0 = 138U,
		Int32_0 = 278,
		Int32_1 = 281,
		Int32_2 = 26
	};

	// Token: 0x04001DAD RID: 7597
	public static Class424 class424_90 = new Class424
	{
		UInt32_0 = 147U,
		Int32_0 = 45,
		Int32_1 = 178,
		Int32_2 = 26
	};

	// Token: 0x04001DAE RID: 7598
	public static Class424 class424_91 = new Class424
	{
		UInt32_0 = 136U,
		Int32_0 = 33,
		Int32_1 = 251,
		Int32_2 = 27
	};

	// Token: 0x04001DAF RID: 7599
	public static Class424 class424_92 = new Class424
	{
		UInt32_0 = 143U,
		Int32_0 = 178,
		Int32_1 = 38,
		Int32_2 = 27
	};

	// Token: 0x04001DB0 RID: 7600
	public static Class424 class424_93 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 197,
		Int32_1 = 280,
		Int32_2 = 27
	};

	// Token: 0x04001DB1 RID: 7601
	public static Class424 class424_94 = new Class424
	{
		UInt32_0 = 127U,
		Int32_0 = 96,
		Int32_1 = 41,
		Int32_2 = 28
	};

	// Token: 0x04001DB2 RID: 7602
	public static Class424 class424_95 = new Class424
	{
		UInt32_0 = 128U,
		Int32_0 = 273,
		Int32_1 = 242,
		Int32_2 = 28
	};

	// Token: 0x04001DB3 RID: 7603
	public static Class424 class424_96 = new Class424
	{
		UInt32_0 = 120U,
		Int32_0 = 39,
		Int32_1 = 254,
		Int32_2 = 28
	};

	// Token: 0x04001DB4 RID: 7604
	public static Class424 class424_97 = new Class424
	{
		UInt32_0 = 157U,
		Int32_0 = 251,
		Int32_1 = 46,
		Int32_2 = 29
	};

	// Token: 0x04001DB5 RID: 7605
	public static Class424 class424_98 = new Class424
	{
		UInt32_0 = 156U,
		Int32_0 = 38,
		Int32_1 = 251,
		Int32_2 = 29
	};

	// Token: 0x04001DB6 RID: 7606
	public static Class424 class424_99 = new Class424
	{
		UInt32_0 = 117U,
		Int32_0 = 281,
		Int32_1 = 160,
		Int32_2 = 29
	};
}
