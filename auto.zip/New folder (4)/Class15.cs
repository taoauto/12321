﻿using System;
using System.Runtime.InteropServices;
using System.Security;

// Token: 0x0200002B RID: 43
[SuppressUnmanagedCodeSecurity]
internal static class Class15
{
	// Token: 0x060001FA RID: 506
	[DllImport("wininet.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
	internal static extern bool InternetGetConnectedState(ref Class15.Enum0 enum0_0, int int_0);

	// Token: 0x0200002C RID: 44
	[Flags]
	internal enum Enum0
	{
		// Token: 0x04000126 RID: 294
		INTERNET_CONNECTION_MODEM = 1,
		// Token: 0x04000127 RID: 295
		INTERNET_CONNECTION_LAN = 2,
		// Token: 0x04000128 RID: 296
		INTERNET_CONNECTION_PROXY = 4,
		// Token: 0x04000129 RID: 297
		INTERNET_RAS_INSTALLED = 16,
		// Token: 0x0400012A RID: 298
		INTERNET_CONNECTION_OFFLINE = 32,
		// Token: 0x0400012B RID: 299
		INTERNET_CONNECTION_CONFIGURED = 64
	}
}
