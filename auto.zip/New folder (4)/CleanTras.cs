﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using _i;

// Token: 0x0200016A RID: 362
public class CleanTras : UserControl
{
	// Token: 0x0600119F RID: 4511 RVA: 0x0000E13E File Offset: 0x0000C33E
	public CleanTras()
	{
		this.InitializeComponent();
		base.Tag = "Dọn Rác";
	}

	// Token: 0x060011A0 RID: 4512 RVA: 0x0000E157 File Offset: 0x0000C357
	private void CleanTras_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060011A1 RID: 4513 RVA: 0x000621A8 File Offset: 0x000603A8
	private void method_0()
	{
		this.listViewEx1.Items.Clear();
		List<ListViewItem> list = new List<ListViewItem>();
		List<string> list2 = new List<string>();
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			Class159 value = keyValuePair.Value;
			if (value.Class432_0.Boolean_34)
			{
				foreach (Class209 @class in value.Class196_0.IEnumerable_0.Concat(value.Class196_0.IEnumerable_4))
				{
					if ((!(@class.String_1 == "Đơn Đoản") || @class.UInt32_13 != 1U) && !list2.Contains(string.Concat(new string[]
					{
						value.Class432_0.String_2,
						"|",
						@class.String_0,
						"|",
						@class.String_1,
						" => Cấp ",
						@class.UInt32_13.ToString(),
						" | ",
						@class.UInt32_7.ToString(),
						" Sao ",
						@class.UInt32_8.ToString(),
						" Dòng"
					})) && (Class159.hashSet_7.Contains(@class.String_1) || Class159.hashSet_4.Contains(@class.String_1)) && @class.UInt32_7 <= 4U)
					{
						ListViewItem listViewItem = new ListViewItem(value.Class432_0.String_2);
						listViewItem.SubItems.Add(@class.String_0);
						listViewItem.SubItems.Add(string.Concat(new string[]
						{
							@class.String_1,
							" => Cấp ",
							@class.UInt32_13.ToString(),
							" | ",
							@class.UInt32_7.ToString(),
							" Sao ",
							@class.UInt32_8.ToString(),
							" Dòng"
						}));
						list2.Add(string.Concat(new string[]
						{
							value.Class432_0.String_2,
							"|",
							@class.String_0,
							"|",
							@class.String_1,
							" => Cấp ",
							@class.UInt32_13.ToString(),
							" | ",
							@class.UInt32_7.ToString(),
							" Sao ",
							@class.UInt32_8.ToString(),
							" Dòng"
						}));
						listViewItem.Tag = value;
						list.Add(listViewItem);
					}
				}
			}
		}
		this.listViewEx1.Items.AddRange(list.ToArray());
	}

	// Token: 0x060011A2 RID: 4514 RVA: 0x00062508 File Offset: 0x00060708
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		if (MessageBox.Show(this, "Bạn có chắc muốn hủy " + this.listViewEx1.SelectedItems.Count.ToString() + " vật phẩm này chứ", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			new Thread(new ThreadStart(this.method_1)).Start();
		}
	}

	// Token: 0x060011A3 RID: 4515 RVA: 0x00062564 File Offset: 0x00060764
	private void toolStripMenuItem_1_Click(object sender, EventArgs e)
	{
		string text = "";
		List<string> list = new List<string>();
		foreach (object obj in this.listViewEx1.SelectedItems)
		{
			string text2 = ((ListViewItem)obj).SubItems[1].Text;
			if (!list.Contains(text2))
			{
				list.Add(text2);
				text = text + text2 + "\r\n";
			}
		}
		try
		{
			Clipboard.SetText(text);
		}
		catch
		{
		}
	}

	// Token: 0x060011A4 RID: 4516 RVA: 0x0000E15F File Offset: 0x0000C35F
	private void listViewEx1_DoubleClick(object sender, EventArgs e)
	{
		if (this.listViewEx1.SelectedItems.Count > 0)
		{
			(this.listViewEx1.SelectedItems[0].Tag as Class159).method_223();
		}
	}

	// Token: 0x060011A5 RID: 4517 RVA: 0x0000E157 File Offset: 0x0000C357
	private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060011A6 RID: 4518 RVA: 0x00062610 File Offset: 0x00060810
	private void button1_Click(object sender, EventArgs e)
	{
		if (MessageBox.Show(this, "Bạn có chắc muốn hủy " + this.listViewEx1.Items.Count.ToString() + " vật phẩm này chứ", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			new Thread(new ThreadStart(this.method_2)).Start();
		}
	}

	// Token: 0x060011A7 RID: 4519 RVA: 0x0000E194 File Offset: 0x0000C394
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060011A8 RID: 4520 RVA: 0x0006266C File Offset: 0x0006086C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(CleanTras));
		this.listViewEx1 = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.contextMenuStrip1 = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.toolStripMenuItem_1 = new ToolStripMenuItem();
		this.refreshToolStripMenuItem = new ToolStripMenuItem();
		this.button1 = new Button();
		this.contextMenuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.listViewEx1.AllowColumnReorder = true;
		this.listViewEx1.AllowDrop = true;
		this.listViewEx1.AllowReorder = true;
		this.listViewEx1.AllowSort = false;
		this.listViewEx1.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.listViewEx1.ContextMenuStrip = this.contextMenuStrip1;
		this.listViewEx1.Dock = DockStyle.Fill;
		this.listViewEx1.DoubleClickActivation = false;
		this.listViewEx1.FullRowSelect = true;
		this.listViewEx1.GridLines = true;
		this.listViewEx1.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewEx1.hideItems");
		this.listViewEx1.HideSelection = false;
		this.listViewEx1.LineColor = Color.Red;
		this.listViewEx1.Location = new Point(0, 0);
		this.listViewEx1.Name = "listViewEx1";
		this.listViewEx1.Size = new Size(498, 457);
		this.listViewEx1.TabIndex = 2;
		this.listViewEx1.UseCompatibleStateImageBehavior = false;
		this.listViewEx1.View = View.Details;
		this.listViewEx1.DoubleClick += this.listViewEx1_DoubleClick;
		this.columnHeader_0.Text = "Player";
		this.columnHeader_0.Width = 108;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 168;
		this.columnHeader_2.Text = "Lý Do";
		this.columnHeader_2.Width = 178;
		this.contextMenuStrip1.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_0,
			this.toolStripMenuItem_1,
			this.refreshToolStripMenuItem
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new Size(253, 70);
		this.toolStripMenuItem_0.Name = "hủyToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(252, 22);
		this.toolStripMenuItem_0.Text = "Hủy";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.toolStripMenuItem_1.Name = "copyĐểDánVàoDanhSáchHủyToolStripMenuItem";
		this.toolStripMenuItem_1.Size = new Size(252, 22);
		this.toolStripMenuItem_1.Text = "Copy (Để dán vào danh sách hủy)";
		this.toolStripMenuItem_1.Click += this.toolStripMenuItem_1_Click;
		this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
		this.refreshToolStripMenuItem.Size = new Size(252, 22);
		this.refreshToolStripMenuItem.Text = "Refresh";
		this.refreshToolStripMenuItem.Click += this.refreshToolStripMenuItem_Click;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 457);
		this.button1.Name = "button1";
		this.button1.Size = new Size(498, 23);
		this.button1.TabIndex = 3;
		this.button1.Text = "Dọn";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(498, 480);
		base.Controls.Add(this.listViewEx1);
		base.Controls.Add(this.button1);
		base.Name = "CleanTras";
		this.Text = "Dọn Rác";
		base.Load += this.CleanTras_Load;
		this.contextMenuStrip1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x060011A9 RID: 4521 RVA: 0x00062B14 File Offset: 0x00060D14
	[CompilerGenerated]
	private void method_1()
	{
		Thread.CurrentThread.IsBackground = true;
		foreach (object obj in this.listViewEx1.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			string text = listViewItem.SubItems[1].Text;
			Class159 @class = listViewItem.Tag as Class159;
			foreach (Class209 class2 in @class.Class196_0.IEnumerable_0)
			{
				if (class2.String_0 == text && string.Concat(new string[]
				{
					class2.String_1,
					" => Cấp ",
					class2.UInt32_13.ToString(),
					" | ",
					class2.UInt32_7.ToString(),
					" Sao ",
					class2.UInt32_8.ToString(),
					" Dòng"
				}) == listViewItem.SubItems[2].Text)
				{
					@class.method_57((int)class2.UInt32_6, 108);
				}
			}
			foreach (Class209 class3 in @class.Class196_0.IEnumerable_4)
			{
				if (class3.String_0 == text && string.Concat(new string[]
				{
					class3.String_1,
					" => Cấp ",
					class3.UInt32_13.ToString(),
					" | ",
					class3.UInt32_7.ToString(),
					" Sao ",
					class3.UInt32_8.ToString(),
					" Dòng"
				}) == listViewItem.SubItems[2].Text)
				{
					@class.method_255(class3.UInt32_6);
				}
			}
		}
		Thread.Sleep(2000);
		this.method_0();
	}

	// Token: 0x060011AA RID: 4522 RVA: 0x00062DAC File Offset: 0x00060FAC
	[CompilerGenerated]
	private void method_2()
	{
		Thread.CurrentThread.IsBackground = true;
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			string text = listViewItem.SubItems[1].Text;
			Class159 @class = listViewItem.Tag as Class159;
			foreach (Class209 class2 in @class.Class196_0.IEnumerable_0)
			{
				if (class2.String_0 == text && string.Concat(new string[]
				{
					class2.String_1,
					" => Cấp ",
					class2.UInt32_13.ToString(),
					" | ",
					class2.UInt32_7.ToString(),
					" Sao ",
					class2.UInt32_8.ToString(),
					" Dòng"
				}) == listViewItem.SubItems[2].Text)
				{
					@class.method_57((int)class2.UInt32_6, 108);
				}
			}
			foreach (Class209 class3 in @class.Class196_0.IEnumerable_4)
			{
				if (class3.String_0 == text && string.Concat(new string[]
				{
					class3.String_1,
					" => Cấp ",
					class3.UInt32_13.ToString(),
					" | ",
					class3.UInt32_7.ToString(),
					" Sao ",
					class3.UInt32_8.ToString(),
					" Dòng"
				}) == listViewItem.SubItems[2].Text)
				{
					@class.method_255(class3.UInt32_6);
				}
			}
		}
		Thread.Sleep(2000);
		this.method_0();
	}

	// Token: 0x04000914 RID: 2324
	private IContainer icontainer_0;

	// Token: 0x04000915 RID: 2325
	private ListViewEx listViewEx1;

	// Token: 0x04000916 RID: 2326
	private ColumnHeader columnHeader_0;

	// Token: 0x04000917 RID: 2327
	private ColumnHeader columnHeader_1;

	// Token: 0x04000918 RID: 2328
	private ColumnHeader columnHeader_2;

	// Token: 0x04000919 RID: 2329
	private ContextMenuStrip contextMenuStrip1;

	// Token: 0x0400091A RID: 2330
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400091B RID: 2331
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400091C RID: 2332
	private ToolStripMenuItem refreshToolStripMenuItem;

	// Token: 0x0400091D RID: 2333
	private Button button1;
}
