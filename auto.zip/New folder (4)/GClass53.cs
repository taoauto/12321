﻿using System;

// Token: 0x020000BB RID: 187
public class GClass53 : GClass51
{
	// Token: 0x060008DF RID: 2271 RVA: 0x00008C5F File Offset: 0x00006E5F
	public GClass53(string string_6) : base(string_6)
	{
		this.string_5 = this.string_0.ToLower();
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x0003D0C0 File Offset: 0x0003B2C0
	public override GEnum10 \u206A\u200E\u206A\u206E\u200F\u206C\u202D\u200F\u206D\u200E\u200C\u202D\u200D\u202E\u206C\u200B\u200E\u206F\u200D\u202D\u202E\u206A\u206D\u202A\u206E\u202B\u206F\u202D\u200B\u200B\u206D\u206D\u206D\u202D\u202A\u200F\u200C\u202A\u206F\u200D\u202E(string string_6)
	{
		int num = string_6.LastIndexOf('.');
		if (num < 0)
		{
			return GEnum10.Hidden;
		}
		string text = string_6.Substring(num + 1);
		this.string_4 = string_6.Substring(0, num);
		if (text == "")
		{
			return GEnum10.Visible;
		}
		if (this.string_0.StartsWith(text, StringComparison.InvariantCultureIgnoreCase))
		{
			return GEnum10.VisibleAndSelected;
		}
		if (this.string_5.Contains(text.ToLower()))
		{
			return GEnum10.Visible;
		}
		return GEnum10.Hidden;
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x00008C79 File Offset: 0x00006E79
	public override string \u200F\u206C\u202D\u206E\u206B\u200F\u202C\u202E\u200C\u206A\u200E\u206F\u200F\u206A\u200D\u202A\u202B\u206C\u202C\u206D\u202C\u200D\u206E\u206B\u202D\u202A\u206A\u206E\u206C\u206B\u206C\u202A\u200C\u200D\u200F\u206A\u206A\u206F\u206A\u206F\u202E()
	{
		return this.string_4 + "." + this.string_0;
	}

	// Token: 0x0400048C RID: 1164
	private string string_4;

	// Token: 0x0400048D RID: 1165
	private string string_5;
}
