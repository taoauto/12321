﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x020000C6 RID: 198
public class GClass59
{
	// Token: 0x170002AB RID: 683
	// (get) Token: 0x0600098D RID: 2445 RVA: 0x000093F7 File Offset: 0x000075F7
	// (set) Token: 0x0600098E RID: 2446 RVA: 0x000093FF File Offset: 0x000075FF
	public GClass99 GClass99_0 { get; private set; }

	// Token: 0x170002AC RID: 684
	// (get) Token: 0x0600098F RID: 2447 RVA: 0x00009408 File Offset: 0x00007608
	// (set) Token: 0x06000990 RID: 2448 RVA: 0x00009410 File Offset: 0x00007610
	public bool Boolean_0 { get; set; }

	// Token: 0x14000014 RID: 20
	// (add) Token: 0x06000991 RID: 2449 RVA: 0x0003E7C0 File Offset: 0x0003C9C0
	// (remove) Token: 0x06000992 RID: 2450 RVA: 0x0003E7F8 File Offset: 0x0003C9F8
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000993 RID: 2451 RVA: 0x0003E830 File Offset: 0x0003CA30
	public GClass59(GClass99 gclass99_1)
	{
		this.gclass80_0 = new GClass80<GClass61>(GClass59.int_0);
		this.GClass99_0 = gclass99_1;
		this.Boolean_0 = true;
	}

	// Token: 0x06000994 RID: 2452 RVA: 0x0003E894 File Offset: 0x0003CA94
	public virtual void vmethod_0(GClass60 gclass60_0)
	{
		if (this.int_1 > 0)
		{
			return;
		}
		if (gclass60_0.gclass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0 && gclass60_0 is GClass61)
		{
			gclass60_0 = new GClass68((GClass61)gclass60_0);
		}
		if (gclass60_0 is GClass61)
		{
			(gclass60_0 as GClass61).bool_0 = (this.int_2 > 0);
			this.gclass80_0.method_2(gclass60_0 as GClass61);
		}
		try
		{
			gclass60_0.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
		}
		catch (ArgumentOutOfRangeException)
		{
			if (gclass60_0 is GClass61)
			{
				this.gclass80_0.method_0();
			}
		}
		if (!this.Boolean_0)
		{
			this.method_5();
		}
		this.stack_0.Clear();
		this.GClass99_0.FastColoredTextBox_0.method_133();
	}

	// Token: 0x06000995 RID: 2453 RVA: 0x0003E960 File Offset: 0x0003CB60
	public void method_0()
	{
		if (this.gclass80_0.Int32_1 > 0)
		{
			GClass61 gclass = this.gclass80_0.method_0();
			this.method_2();
			try
			{
				gclass.GClass61.\u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E();
			}
			finally
			{
				this.method_1();
			}
			this.stack_0.Push(gclass);
		}
		if (this.gclass80_0.Int32_1 > 0 && this.gclass80_0.method_1().bool_0)
		{
			this.method_0();
		}
		this.GClass99_0.FastColoredTextBox_0.method_133();
	}

	// Token: 0x06000996 RID: 2454 RVA: 0x00009419 File Offset: 0x00007619
	private void method_1()
	{
		this.int_1--;
	}

	// Token: 0x06000997 RID: 2455 RVA: 0x00009429 File Offset: 0x00007629
	private void method_2()
	{
		this.int_1++;
	}

	// Token: 0x06000998 RID: 2456 RVA: 0x00009439 File Offset: 0x00007639
	public void method_3()
	{
		this.int_2--;
		if (this.int_2 == 0 && this.gclass80_0.Int32_1 > 0)
		{
			this.gclass80_0.method_1().bool_0 = false;
		}
	}

	// Token: 0x06000999 RID: 2457 RVA: 0x00009470 File Offset: 0x00007670
	public void method_4()
	{
		this.int_2++;
	}

	// Token: 0x0600099A RID: 2458 RVA: 0x00009480 File Offset: 0x00007680
	internal void method_5()
	{
		this.gclass80_0.method_3();
		this.stack_0.Clear();
		this.GClass99_0.FastColoredTextBox_0.method_133();
	}

	// Token: 0x0600099B RID: 2459 RVA: 0x0003E9F0 File Offset: 0x0003CBF0
	internal void method_6()
	{
		if (this.stack_0.Count == 0)
		{
			return;
		}
		this.method_2();
		GClass61 gclass;
		try
		{
			gclass = this.stack_0.Pop();
			if (this.GClass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0)
			{
				this.GClass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0 = false;
			}
			this.GClass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = gclass.class90_0.GStruct2_0;
			this.GClass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1 = gclass.class90_0.GStruct2_1;
			gclass.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
			this.gclass80_0.method_2(gclass);
		}
		finally
		{
			this.method_1();
		}
		this.eventHandler_0(this, EventArgs.Empty);
		if (gclass.bool_0)
		{
			this.method_6();
		}
		this.GClass99_0.FastColoredTextBox_0.method_133();
	}

	// Token: 0x170002AD RID: 685
	// (get) Token: 0x0600099C RID: 2460 RVA: 0x000094A8 File Offset: 0x000076A8
	public bool Boolean_1
	{
		get
		{
			return this.gclass80_0.Int32_1 > 0;
		}
	}

	// Token: 0x170002AE RID: 686
	// (get) Token: 0x0600099D RID: 2461 RVA: 0x000094B8 File Offset: 0x000076B8
	public bool Boolean_2
	{
		get
		{
			return this.stack_0.Count > 0;
		}
	}

	// Token: 0x040004B8 RID: 1208
	public static int int_0 = 200;

	// Token: 0x040004B9 RID: 1209
	private GClass80<GClass61> gclass80_0;

	// Token: 0x040004BA RID: 1210
	private Stack<GClass61> stack_0 = new Stack<GClass61>();

	// Token: 0x040004BB RID: 1211
	[CompilerGenerated]
	private GClass99 gclass99_0;

	// Token: 0x040004BC RID: 1212
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040004BD RID: 1213
	[CompilerGenerated]
	private EventHandler eventHandler_0 = new EventHandler(GClass59.Class89.<>9.method_0);

	// Token: 0x040004BE RID: 1214
	protected int int_1;

	// Token: 0x040004BF RID: 1215
	private int int_2;

	// Token: 0x020000C7 RID: 199
	[CompilerGenerated]
	[Serializable]
	private sealed class Class89
	{
		// Token: 0x060009A1 RID: 2465 RVA: 0x00002E18 File Offset: 0x00001018
		internal void method_0(object sender, EventArgs e)
		{
		}

		// Token: 0x040004C0 RID: 1216
		public static readonly GClass59.Class89 <>9 = new GClass59.Class89();

		// Token: 0x040004C1 RID: 1217
		public static EventHandler <>9__14_0;
	}
}
