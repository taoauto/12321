﻿using System;

// Token: 0x020000F5 RID: 245
[Flags]
public enum GEnum16 : ushort
{
	// Token: 0x040005ED RID: 1517
	None = 0,
	// Token: 0x040005EE RID: 1518
	Left = 1,
	// Token: 0x040005EF RID: 1519
	Right = 2,
	// Token: 0x040005F0 RID: 1520
	Up = 4,
	// Token: 0x040005F1 RID: 1521
	Down = 8
}
