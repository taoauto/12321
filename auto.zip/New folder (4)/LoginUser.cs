﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Web;
using System.Windows.Forms;
using System.Xml;

// Token: 0x0200021F RID: 543
internal class LoginUser : UserControl
{
	// Token: 0x06001D2A RID: 7466 RVA: 0x0001579D File Offset: 0x0001399D
	public LoginUser()
	{
		this.InitializeComponent();
		base.Load += this.LoginUser_Load;
	}

	// Token: 0x06001D2B RID: 7467 RVA: 0x00002E18 File Offset: 0x00001018
	private void LoginUser_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x06001D2C RID: 7468 RVA: 0x000D74FC File Offset: 0x000D56FC
	private void btnRegisterLogin_Click(object sender, EventArgs e)
	{
		if (!Class426.smethod_72(this.textRegMail.Text) && !Class426.smethod_71(this.textRegPass.Text))
		{
			MessageBox.Show(this, "Vui lòng nhập địa chỉ user hợp lệ", "MicroAuto", MessageBoxButtons.OK);
		}
		else if (this.textRegPass.Text.Length < 6)
		{
			MessageBox.Show(this, "Mật khẩu phải có ít nhất 6 kí tự", "MicroAuto", MessageBoxButtons.OK);
		}
		else if (this.textRegPass.Text != this.textRetypePass.Text)
		{
			MessageBox.Show(this, "Mật khẩu nhập lại không khớp", "MicroAuto", MessageBoxButtons.OK);
		}
		else
		{
			base.Enabled = false;
			this.method_0();
		}
		this.Dock = DockStyle.Fill;
	}

	// Token: 0x170006AF RID: 1711
	// (get) Token: 0x06001D2D RID: 7469 RVA: 0x000157C8 File Offset: 0x000139C8
	// (set) Token: 0x06001D2E RID: 7470 RVA: 0x000157D0 File Offset: 0x000139D0
	public string String_0 { get; set; }

	// Token: 0x170006B0 RID: 1712
	// (get) Token: 0x06001D2F RID: 7471 RVA: 0x000157D9 File Offset: 0x000139D9
	// (set) Token: 0x06001D30 RID: 7472 RVA: 0x000157E1 File Offset: 0x000139E1
	public string String_1 { get; set; }

	// Token: 0x170006B1 RID: 1713
	// (get) Token: 0x06001D31 RID: 7473 RVA: 0x000157EA File Offset: 0x000139EA
	// (set) Token: 0x06001D32 RID: 7474 RVA: 0x000157F1 File Offset: 0x000139F1
	public static bool Boolean_0 { get; set; }

	// Token: 0x06001D33 RID: 7475 RVA: 0x000D75B0 File Offset: 0x000D57B0
	private void method_0()
	{
		base.Enabled = false;
		string text = string.Concat(new string[]
		{
			"cmd=rg&email=",
			HttpUtility.UrlEncode(User.string_0),
			"&loginpass=",
			HttpUtility.UrlEncode(Class426.Class430.smethod_3(this.textRegMail.Text)),
			"&loginemail=",
			HttpUtility.UrlEncode(this.textRegPass.Text),
			"&pass=",
			User.string_1
		});
		Class412 @class = new Class412();
		@class.string_1 = Class387.String_0;
		@class.String_0 = text;
		@class.control_0 = this;
		@class.Event_0 += this.method_1;
		@class.method_0();
	}

	// Token: 0x06001D34 RID: 7476 RVA: 0x000D7668 File Offset: 0x000D5868
	private void method_1(object sender, EventArgs e)
	{
		Class412 @class = (Class412)sender;
		if (@class.Boolean_2)
		{
			this.btnRegisterLogin.Text = "Lỗi " + Class412.int_3.ToString();
			this.method_0();
			return;
		}
		base.Enabled = true;
		MessageBox.Show(this, @class.String_2, "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x06001D35 RID: 7477 RVA: 0x000157F9 File Offset: 0x000139F9
	private void btnLogin_Click(object sender, EventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06001D36 RID: 7478 RVA: 0x000D76C4 File Offset: 0x000D58C4
	private void method_2()
	{
		base.Enabled = false;
		if (this.String_1 == "Offline")
		{
			this.xmlDocument_0 = MicroLogin.xmlDocument_0;
			base.Dispose();
			return;
		}
		try
		{
			this.String_0 = this.textLoginPass.Text;
			this.String_1 = this.textLoginEmail.Text;
			string text = "cmd=rglogin&email=" + HttpUtility.UrlEncode(this.String_1) + "&pass=" + HttpUtility.UrlEncode(Class426.Class430.smethod_3(this.String_0));
			Class412 @class = new Class412();
			@class.Boolean_1 = true;
			@class.string_1 = Class387.String_0;
			@class.String_0 = text;
			@class.control_0 = this;
			@class.Event_0 += this.method_3;
			@class.method_0();
		}
		catch
		{
			base.Enabled = true;
		}
	}

	// Token: 0x06001D37 RID: 7479 RVA: 0x000D77A4 File Offset: 0x000D59A4
	private void method_3(object sender, EventArgs e)
	{
		base.Enabled = true;
		Class412 @class = (Class412)sender;
		if (@class.String_2.Contains("sai email"))
		{
			MessageBox.Show(this, @class.String_2, "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		try
		{
			this.xmlDocument_0.LoadXml(@class.String_2);
		}
		catch
		{
			if (this.xmlDocument_0.SelectSingleNode("/*") == null)
			{
				this.xmlDocument_0.InsertBefore(this.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), this.xmlDocument_0.DocumentElement);
				this.xmlDocument_0.AppendChild(this.xmlDocument_0.CreateNode(XmlNodeType.Element, "Accounts", ""));
			}
		}
		Class268.Class220_0.method_1("MicroLogin", this.String_1, this.String_0);
		Class159.Class220_0.method_1("MicroLogin", this.String_1, this.String_0);
		try
		{
			if (!(Class378.String_0 == "") && File.Exists(Class378.String_0))
			{
				File.Move(Class378.String_0 + "\\WebClient\\webclient.exe", Class378.String_0 + "\\WebClient\\webclientt.exe");
			}
		}
		catch
		{
		}
		base.Dispose();
	}

	// Token: 0x06001D38 RID: 7480 RVA: 0x000D78FC File Offset: 0x000D5AFC
	private void method_4(object sender, LinkLabelLinkClickedEventArgs e)
	{
		string text = "mật khẩu là chìa khóa quan trọng để giải mã dữ liệu được lưu\r\nchính admin cũng không biết mật khẩu của bạn\r\nbạn vui lòng nhớ kỹ thông tin đăng nhập \r\ntrong trường hợp bạn quên mật khẩu\r\nadmin chỉ có thể phục hồi lại được danh sách tên tài khoản\r\ncòn mật khẩu của tài khoản lưu trong dữ liệu bị mã hóa\r\nkhông thể giải mã nếu không có mật khẩu gốc";
		MessageBox.Show(this, text, "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x170006B2 RID: 1714
	// (get) Token: 0x06001D39 RID: 7481 RVA: 0x00015801 File Offset: 0x00013A01
	// (set) Token: 0x06001D3A RID: 7482 RVA: 0x00015808 File Offset: 0x00013A08
	public static bool Boolean_1 { get; set; }

	// Token: 0x06001D3B RID: 7483 RVA: 0x00015810 File Offset: 0x00013A10
	private void LoginUser_Load_1(object sender, EventArgs e)
	{
		if (!LoginUser.Boolean_1)
		{
			LoginUser.Boolean_1 = true;
			this.String_1 = "Offline";
			this.method_2();
		}
	}

	// Token: 0x06001D3C RID: 7484 RVA: 0x00015830 File Offset: 0x00013A30
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		if (this.checkBox1.Checked)
		{
			this.textLoginPass.PasswordChar = '\0';
			return;
		}
		this.textLoginPass.PasswordChar = '*';
	}

	// Token: 0x06001D3D RID: 7485 RVA: 0x000D7920 File Offset: 0x000D5B20
	private void comboBox1_DropDown(object sender, EventArgs e)
	{
		this.comboBox1.Items.Clear();
		foreach (Class219 @class in Class159.Class220_0["MicroLogin"])
		{
			if (Class426.smethod_72(@class.String_0) || Class426.smethod_71(@class.String_0))
			{
				this.comboBox1.Items.Add(@class);
			}
		}
		Class415.String_32 = Class415.String_32.Replace("FFFFFFFF", "FFFF");
		string[] array = Class415.String_32.Replace("FFFF", "\n").Split(new char[]
		{
			'\n'
		});
		for (int i = 0; i < array.Length; i++)
		{
			string text = array[i].Trim();
			if (!Class426.smethod_72(text) && !Class426.smethod_71(text))
			{
				if (!string.IsNullOrEmpty(text))
				{
					Class415.String_32 = Class415.String_32.Replace(text, "");
				}
			}
			else
			{
				this.comboBox1.Items.Add(text);
				Class268.Class220_0.method_1("MicroLogin", text, Class159.Class220_0.method_0("Login", text));
				Class415.String_32 = Class415.String_32.Replace(text, "");
			}
		}
	}

	// Token: 0x06001D3E RID: 7486 RVA: 0x00015859 File Offset: 0x00013A59
	private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.textLoginEmail.Text = this.comboBox1.Text;
		this.textLoginPass.Text = Class268.Class220_0.method_0("MicroLogin", this.textLoginEmail.Text);
	}

	// Token: 0x06001D3F RID: 7487 RVA: 0x00015896 File Offset: 0x00013A96
	private void method_5(object sender, MouseEventArgs e)
	{
		base.Parent.Parent.Dispose();
	}

	// Token: 0x06001D40 RID: 7488 RVA: 0x00002E18 File Offset: 0x00001018
	private void groupBox2_Enter(object sender, EventArgs e)
	{
	}

	// Token: 0x06001D41 RID: 7489 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_6(object sender, EventArgs e)
	{
	}

	// Token: 0x06001D42 RID: 7490 RVA: 0x000158A8 File Offset: 0x00013AA8
	private void LoginUser_Resize(object sender, EventArgs e)
	{
		this.tab.Location = new Point(base.Width / 2 - this.tab.Width / 2, base.Height / 2 - this.tab.Height / 2);
	}

	// Token: 0x06001D43 RID: 7491 RVA: 0x00015896 File Offset: 0x00013A96
	private void label4_Click(object sender, EventArgs e)
	{
		base.Parent.Parent.Dispose();
	}

	// Token: 0x06001D44 RID: 7492 RVA: 0x000158E6 File Offset: 0x00013AE6
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001D45 RID: 7493 RVA: 0x000D7A88 File Offset: 0x000D5C88
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		this.label1 = new Label();
		this.groupBox1 = new GroupBox();
		this.textRetypePass = new Class85();
		this.textRegPass = new Class85();
		this.textRegMail = new Class85();
		this.btnRegisterLogin = new Button();
		this.groupBox2 = new GroupBox();
		this.panel1 = new Panel();
		this.textLoginPass = new Class85();
		this.checkBox1 = new CheckBox();
		this.textLoginEmail = new Class85();
		this.comboBox1 = new ComboBox();
		this.btnLogin = new Button();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.label4 = new Label();
		this.tab = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.tabPage3 = new TabPage();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.panel1.SuspendLayout();
		this.tab.SuspendLayout();
		this.tabPage1.SuspendLayout();
		this.tabPage2.SuspendLayout();
		this.tabPage3.SuspendLayout();
		base.SuspendLayout();
		this.label1.BackColor = Color.White;
		this.label1.Dock = DockStyle.Fill;
		this.label1.Location = new Point(3, 3);
		this.label1.Name = "label1";
		this.label1.Size = new Size(227, 133);
		this.label1.TabIndex = 0;
		this.label1.Text = "Thông tin được lưu trữ \r\nVà mã hóa trực tuyến\r\n\r\nDùng để chia sẻ \r\nVà sử dụng trên nhiều máy tính\r\n";
		this.label1.TextAlign = ContentAlignment.MiddleCenter;
		this.groupBox1.BackColor = Color.White;
		this.groupBox1.Controls.Add(this.textRetypePass);
		this.groupBox1.Controls.Add(this.textRegPass);
		this.groupBox1.Controls.Add(this.textRegMail);
		this.groupBox1.Controls.Add(this.btnRegisterLogin);
		this.groupBox1.Dock = DockStyle.Fill;
		this.groupBox1.Location = new Point(3, 3);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new Size(227, 133);
		this.groupBox1.TabIndex = 58;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Đăng Ký [10k Beri / 1 Tài Khoản]";
		this.textRetypePass.Dock = DockStyle.Top;
		this.textRetypePass.Location = new Point(3, 56);
		this.textRetypePass.Name = "textRetypePass";
		this.textRetypePass.Size = new Size(221, 20);
		this.textRetypePass.TabIndex = 69;
		this.textRetypePass.String_0 = "Confirm Password";
		this.textRetypePass.Color_0 = Color.Gray;
		this.textRetypePass.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textRetypePass.Color_1 = Color.LightGray;
		this.textRegPass.Dock = DockStyle.Top;
		this.textRegPass.Location = new Point(3, 36);
		this.textRegPass.Name = "textRegPass";
		this.textRegPass.Size = new Size(221, 20);
		this.textRegPass.TabIndex = 68;
		this.textRegPass.String_0 = "Password";
		this.textRegPass.Color_0 = Color.Gray;
		this.textRegPass.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textRegPass.Color_1 = Color.LightGray;
		this.textRegMail.Dock = DockStyle.Top;
		this.textRegMail.Location = new Point(3, 16);
		this.textRegMail.Name = "textRegMail";
		this.textRegMail.Size = new Size(221, 20);
		this.textRegMail.TabIndex = 67;
		this.textRegMail.String_0 = "Email | Phone";
		this.textRegMail.Color_0 = Color.Gray;
		this.textRegMail.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textRegMail.Color_1 = Color.LightGray;
		this.btnRegisterLogin.Dock = DockStyle.Bottom;
		this.btnRegisterLogin.Location = new Point(3, 107);
		this.btnRegisterLogin.Name = "btnRegisterLogin";
		this.btnRegisterLogin.Size = new Size(221, 23);
		this.btnRegisterLogin.TabIndex = 58;
		this.btnRegisterLogin.Text = "Đăng Ký";
		this.btnRegisterLogin.UseVisualStyleBackColor = true;
		this.btnRegisterLogin.Click += this.btnRegisterLogin_Click;
		this.groupBox2.BackColor = Color.White;
		this.groupBox2.Controls.Add(this.panel1);
		this.groupBox2.Controls.Add(this.textLoginEmail);
		this.groupBox2.Controls.Add(this.comboBox1);
		this.groupBox2.Controls.Add(this.btnLogin);
		this.groupBox2.Dock = DockStyle.Fill;
		this.groupBox2.Location = new Point(3, 3);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new Size(227, 133);
		this.groupBox2.TabIndex = 59;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "Đăng nhập";
		this.groupBox2.Enter += this.groupBox2_Enter;
		this.panel1.Controls.Add(this.textLoginPass);
		this.panel1.Controls.Add(this.checkBox1);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(3, 57);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(221, 20);
		this.panel1.TabIndex = 66;
		this.textLoginPass.Dock = DockStyle.Fill;
		this.textLoginPass.Location = new Point(0, 0);
		this.textLoginPass.Name = "textLoginPass";
		this.textLoginPass.PasswordChar = '*';
		this.textLoginPass.Size = new Size(206, 20);
		this.textLoginPass.TabIndex = 65;
		this.textLoginPass.String_0 = "Password";
		this.textLoginPass.Color_0 = Color.Gray;
		this.textLoginPass.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textLoginPass.Color_1 = Color.LightGray;
		this.checkBox1.AutoSize = true;
		this.checkBox1.Dock = DockStyle.Right;
		this.checkBox1.Location = new Point(206, 0);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new Size(15, 20);
		this.checkBox1.TabIndex = 60;
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox1.CheckedChanged += this.checkBox1_CheckedChanged;
		this.textLoginEmail.Dock = DockStyle.Top;
		this.textLoginEmail.Location = new Point(3, 37);
		this.textLoginEmail.Name = "textLoginEmail";
		this.textLoginEmail.Size = new Size(221, 20);
		this.textLoginEmail.TabIndex = 64;
		this.textLoginEmail.String_0 = "Email | Phone";
		this.textLoginEmail.Color_0 = Color.Gray;
		this.textLoginEmail.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textLoginEmail.Color_1 = Color.LightGray;
		this.comboBox1.Dock = DockStyle.Top;
		this.comboBox1.FormattingEnabled = true;
		this.comboBox1.Location = new Point(3, 16);
		this.comboBox1.Name = "comboBox1";
		this.comboBox1.Size = new Size(221, 21);
		this.comboBox1.TabIndex = 61;
		this.comboBox1.DropDown += this.comboBox1_DropDown;
		this.comboBox1.SelectedIndexChanged += this.comboBox1_SelectedIndexChanged;
		this.btnLogin.Dock = DockStyle.Bottom;
		this.btnLogin.Location = new Point(3, 107);
		this.btnLogin.Name = "btnLogin";
		this.btnLogin.Size = new Size(221, 23);
		this.btnLogin.TabIndex = 58;
		this.btnLogin.Text = "Đăng Nhập";
		this.btnLogin.UseVisualStyleBackColor = true;
		this.btnLogin.Click += this.btnLogin_Click;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.label4.BackColor = Color.White;
		this.label4.Cursor = Cursors.Hand;
		this.label4.Dock = DockStyle.Right;
		this.label4.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.label4.ForeColor = Color.Black;
		this.label4.Location = new Point(599, 0);
		this.label4.Name = "label4";
		this.label4.Size = new Size(20, 367);
		this.label4.TabIndex = 74;
		this.label4.Text = "x";
		this.label4.TextAlign = ContentAlignment.TopRight;
		this.toolTip_0.SetToolTip(this.label4, "Thoát");
		this.label4.Click += this.label4_Click;
		this.tab.Controls.Add(this.tabPage1);
		this.tab.Controls.Add(this.tabPage2);
		this.tab.Controls.Add(this.tabPage3);
		this.tab.Location = new Point(195, 104);
		this.tab.Name = "tab";
		this.tab.SelectedIndex = 0;
		this.tab.Size = new Size(241, 165);
		this.tab.TabIndex = 61;
		this.tabPage1.Controls.Add(this.groupBox2);
		this.tabPage1.Location = new Point(4, 4);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(233, 139);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Login";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Controls.Add(this.groupBox1);
		this.tabPage2.Location = new Point(4, 4);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(233, 139);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Register";
		this.tabPage2.UseVisualStyleBackColor = true;
		this.tabPage3.Controls.Add(this.label1);
		this.tabPage3.Location = new Point(4, 4);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Padding = new Padding(3);
		this.tabPage3.Size = new Size(233, 139);
		this.tabPage3.TabIndex = 2;
		this.tabPage3.Text = "Help";
		this.tabPage3.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.White;
		base.Controls.Add(this.label4);
		base.Controls.Add(this.tab);
		base.Name = "LoginUser";
		base.Size = new Size(619, 367);
		base.Load += this.LoginUser_Load_1;
		base.Resize += this.LoginUser_Resize;
		this.groupBox1.ResumeLayout(false);
		this.groupBox1.PerformLayout();
		this.groupBox2.ResumeLayout(false);
		this.groupBox2.PerformLayout();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		this.tab.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		this.tabPage2.ResumeLayout(false);
		this.tabPage3.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040011CD RID: 4557
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040011CE RID: 4558
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040011CF RID: 4559
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x040011D0 RID: 4560
	public XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x040011D1 RID: 4561
	[CompilerGenerated]
	private static bool bool_1;

	// Token: 0x040011D2 RID: 4562
	public static List<string> list_0 = new List<string>();

	// Token: 0x040011D3 RID: 4563
	private IContainer icontainer_0;

	// Token: 0x040011D4 RID: 4564
	private Label label1;

	// Token: 0x040011D5 RID: 4565
	private GroupBox groupBox1;

	// Token: 0x040011D6 RID: 4566
	private Button btnRegisterLogin;

	// Token: 0x040011D7 RID: 4567
	private GroupBox groupBox2;

	// Token: 0x040011D8 RID: 4568
	private Button btnLogin;

	// Token: 0x040011D9 RID: 4569
	private ToolTip toolTip_0;

	// Token: 0x040011DA RID: 4570
	private CheckBox checkBox1;

	// Token: 0x040011DB RID: 4571
	private ComboBox comboBox1;

	// Token: 0x040011DC RID: 4572
	private Class85 textLoginPass;

	// Token: 0x040011DD RID: 4573
	private Class85 textLoginEmail;

	// Token: 0x040011DE RID: 4574
	private Control1 tab;

	// Token: 0x040011DF RID: 4575
	private TabPage tabPage1;

	// Token: 0x040011E0 RID: 4576
	private TabPage tabPage2;

	// Token: 0x040011E1 RID: 4577
	private TabPage tabPage3;

	// Token: 0x040011E2 RID: 4578
	private Panel panel1;

	// Token: 0x040011E3 RID: 4579
	private Class85 textRetypePass;

	// Token: 0x040011E4 RID: 4580
	private Class85 textRegPass;

	// Token: 0x040011E5 RID: 4581
	private Class85 textRegMail;

	// Token: 0x040011E6 RID: 4582
	private Label label4;
}
