﻿using System;
using System.Net.Sockets;
using System.Text;

// Token: 0x02000033 RID: 51
public class GClass20 : GClass19
{
	// Token: 0x06000242 RID: 578 RVA: 0x0000485B File Offset: 0x00002A5B
	public GClass20() : this(null)
	{
	}

	// Token: 0x06000243 RID: 579 RVA: 0x00004864 File Offset: 0x00002A64
	public GClass20(string string_3) : this(string_3, 1080)
	{
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00004872 File Offset: 0x00002A72
	public GClass20(string string_3, int int_4) : this(string_3, int_4, string.Empty)
	{
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00004881 File Offset: 0x00002A81
	public GClass20(string string_3, int int_4, string string_4) : base(string_3, int_4, string_4)
	{
		this.genum4_0 = GEnum4.Socks4a;
	}

	// Token: 0x06000246 RID: 582 RVA: 0x00004893 File Offset: 0x00002A93
	public static GClass20 smethod_4(string string_3)
	{
		return GClass16.smethod_0(GEnum4.Socks4a, string_3) as GClass20;
	}

	// Token: 0x06000247 RID: 583 RVA: 0x0002738C File Offset: 0x0002558C
	public static bool smethod_5(string string_3, out GClass20 gclass20_0)
	{
		GClass16 gclass;
		if (GClass16.smethod_1(GEnum4.Socks4a, string_3, out gclass))
		{
			gclass20_0 = (gclass as GClass20);
			return true;
		}
		gclass20_0 = null;
		return false;
	}

	// Token: 0x06000248 RID: 584 RVA: 0x000273B4 File Offset: 0x000255B4
	protected internal override void \u206A\u200C\u206D\u202B\u206F\u206D\u202D\u206F\u200E\u206A\u200D\u206D\u202C\u202E\u202A\u202C\u206F\u206D\u200D\u202C\u206A\u202D\u206C\u206E\u202E\u202A\u202B\u206A\u200B\u206D\u206A\u206B\u202D\u206B\u206D\u200D\u206E\u206B\u206E\u206C\u202E(NetworkStream networkStream_0, byte byte_7, string string_3, int int_4)
	{
		byte[] array = base.method_4(int_4);
		Array array2 = new byte[]
		{
			0,
			0,
			0,
			1
		};
		byte[] array3 = string.IsNullOrEmpty(this.string_1) ? new byte[0] : Encoding.ASCII.GetBytes(this.string_1);
		byte[] bytes = Encoding.ASCII.GetBytes(string_3);
		byte[] array4 = new byte[10 + array3.Length + bytes.Length];
		array4[0] = 4;
		array4[1] = byte_7;
		array.CopyTo(array4, 2);
		array2.CopyTo(array4, 4);
		array3.CopyTo(array4, 8);
		array4[8 + array3.Length] = 0;
		bytes.CopyTo(array4, 9 + array3.Length);
		array4[9 + array3.Length + bytes.Length] = 0;
		networkStream_0.Write(array4, 0, array4.Length);
		byte[] array5 = new byte[8];
		networkStream_0.Read(array5, 0, 8);
		byte b = array5[1];
		if (b != 90)
		{
			base.method_5(b);
		}
	}
}
