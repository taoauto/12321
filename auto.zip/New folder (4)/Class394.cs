﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

// Token: 0x020002C7 RID: 711
internal class Class394
{
	// Token: 0x17000980 RID: 2432
	// (get) Token: 0x06002947 RID: 10567 RVA: 0x0001E56A File Offset: 0x0001C76A
	public IEnumerable<Class393> IEnumerable_0
	{
		get
		{
			return this.list_0.Where(new Func<Class393, bool>(Class394.Class395.<>9.method_0));
		}
	}

	// Token: 0x17000981 RID: 2433
	// (get) Token: 0x06002948 RID: 10568 RVA: 0x0001E596 File Offset: 0x0001C796
	public IEnumerable<Class393> IEnumerable_1
	{
		get
		{
			return this.list_0.Where(new Func<Class393, bool>(this.method_8));
		}
	}

	// Token: 0x17000982 RID: 2434
	// (get) Token: 0x06002949 RID: 10569 RVA: 0x0001E5AF File Offset: 0x0001C7AF
	public IEnumerable<Class393> IEnumerable_2
	{
		get
		{
			return this.list_0.Where(new Func<Class393, bool>(Class394.Class395.<>9.method_1));
		}
	}

	// Token: 0x17000983 RID: 2435
	// (get) Token: 0x0600294A RID: 10570 RVA: 0x0001E5DB File Offset: 0x0001C7DB
	public IEnumerable<Class393> IEnumerable_3
	{
		get
		{
			Class394.Class396 @class = new Class394.Class396(-2);
			@class.class394_0 = this;
			return @class;
		}
	}

	// Token: 0x17000984 RID: 2436
	// (get) Token: 0x0600294B RID: 10571 RVA: 0x0001E5EB File Offset: 0x0001C7EB
	public IEnumerable<Class393> IEnumerable_4
	{
		get
		{
			return this.list_0.Where(new Func<Class393, bool>(Class394.Class395.<>9.method_2));
		}
	}

	// Token: 0x0600294C RID: 10572 RVA: 0x0011BC7C File Offset: 0x00119E7C
	public Class393 method_0(string string_0)
	{
		foreach (Class393 @class in this.list_0)
		{
			if (@class.String_2 == string_0)
			{
				return @class;
			}
		}
		return null;
	}

	// Token: 0x0600294D RID: 10573 RVA: 0x0011BCE0 File Offset: 0x00119EE0
	public bool method_1(string string_0)
	{
		using (List<Class393>.Enumerator enumerator = this.list_0.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.String_3.Contains(string_0.smethod_0()))
				{
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600294E RID: 10574 RVA: 0x0011BD48 File Offset: 0x00119F48
	public bool method_2(string string_0)
	{
		string_0 = string_0.smethod_0();
		using (List<Class393>.Enumerator enumerator = this.list_1.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.String_3.Contains(string_0))
				{
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600294F RID: 10575 RVA: 0x0011BDB0 File Offset: 0x00119FB0
	public List<Class393> method_3(float float_0, float float_1 = -1f, float float_2 = -1f)
	{
		if (float_1 == -1f)
		{
			float_1 = this.class159_0.Single_3;
		}
		if (float_2 == -1f)
		{
			float_2 = this.class159_0.Single_4;
		}
		List<Class393> list = new List<Class393>();
		foreach (Class393 @class in this.list_1)
		{
			if (@class.method_3(float_1, float_2) < float_0)
			{
				list.Add(@class);
			}
		}
		if ((ulong)this.class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_109))
		{
			foreach (Class393 class2 in this.list_0)
			{
				if (class2.method_3(float_1, float_2) < float_0 && class2.UInt32_8 == 12U && class2.Boolean_9)
				{
					list.Add(class2);
				}
			}
		}
		return list;
	}

	// Token: 0x17000985 RID: 2437
	// (get) Token: 0x06002950 RID: 10576 RVA: 0x0011BEBC File Offset: 0x0011A0BC
	public List<Class393> List_0
	{
		get
		{
			List<Class393> list = new List<Class393>();
			foreach (Class393 @class in this.class159_0.Class394_0.list_1)
			{
				if (Class426.smethod_48((double)this.class159_0.Single_3, (double)this.class159_0.Single_4, (double)@class.Single_0, (double)@class.Single_1) < 12f)
				{
					list.Add(@class);
				}
			}
			return list;
		}
	}

	// Token: 0x17000986 RID: 2438
	// (get) Token: 0x06002951 RID: 10577 RVA: 0x0001E617 File Offset: 0x0001C817
	public bool Boolean_0
	{
		get
		{
			return this.class393_2 != null && this.class159_0.Class432_0.string_13.Contains(this.class393_2.String_1);
		}
	}

	// Token: 0x06002952 RID: 10578 RVA: 0x0011BF54 File Offset: 0x0011A154
	public Class394(Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.method_4();
	}

	// Token: 0x17000987 RID: 2439
	// (get) Token: 0x06002953 RID: 10579 RVA: 0x0001E646 File Offset: 0x0001C846
	// (set) Token: 0x06002954 RID: 10580 RVA: 0x0001E64E File Offset: 0x0001C84E
	public List<Class393> List_1 { get; set; } = new List<Class393>();

	// Token: 0x06002955 RID: 10581 RVA: 0x0011BFA0 File Offset: 0x0011A1A0
	public void method_4()
	{
		try
		{
			this.class393_0 = (this.class393_1 = (this.class393_2 = null));
			this.list_0.Clear();
			this.list_2.Clear();
			this.list_1.Clear();
			foreach (uint uint_ in this.method_6(new uint[]
			{
				this.class159_0.Class392_0.UInt32_69[0],
				this.class159_0.Class392_0.UInt32_69[1],
				this.class159_0.Class392_0.UInt32_69[2]
			}))
			{
				Class393 @class = new Class393(this.class159_0, uint_);
				@class = @class.method_1();
				if (@class.String_2 != null)
				{
					this.list_0.Add(@class);
					if (@class.Boolean_7)
					{
						foreach (string text in Class415.String_31.Split(new char[]
						{
							'\n'
						}))
						{
							if (!(text.Trim() == "") && Class426.smethod_57(text) == Class426.smethod_57(@class.String_2) && @class.Boolean_7)
							{
								if (this.class393_0 != null)
								{
									if (@class == this.class393_0)
									{
										goto IL_139;
									}
								}
								this.class393_1 = @class;
								break;
							}
							IL_139:;
						}
					}
					if ((ulong)@class.UInt32_1 == (ulong)((long)this.class159_0.Int32_10))
					{
						this.class393_2 = @class;
					}
					if (@class.String_0 == this.class159_0.Class432_0.String_1 && this.class159_0.Class432_0.Boolean_34)
					{
						this.class393_0 = @class;
						this.class159_0.Class432_0.UInt32_26 = this.class393_0.UInt32_10;
						this.class159_0.UInt32_4 = this.class393_0.UInt32_1;
						this.class159_0.Single_3 = this.class393_0.Single_0;
						this.class159_0.Single_4 = this.class393_0.Single_1;
					}
				}
			}
			this.class159_0.Class432_0.string_13 = "0000000000000000FFFFFFFFFFFFFFFF";
			if (this.class393_0 != null)
			{
				Class432 class432_ = this.class159_0.Class432_0;
				class432_.string_13 += this.class393_0.String_0;
				bool flag = false;
				foreach (Class393 class2 in this.list_0)
				{
					if (class2 != this.class393_0)
					{
						if (AutoPK.String_0 != string.Empty && AutoPK.Boolean_0 && AutoPK.String_0 == class2.String_2)
						{
							this.list_2.Clear();
							this.list_2.Add(class2);
							flag = true;
						}
						if (!string.IsNullOrEmpty(class2.String_2) && this.class159_0.Dictionary_2.ContainsKey(class2.String_2) && class2.Single_2 > 0f && !flag && Class268.bool_97 && (!Main.setting_0.checkSkipMonter.Checked || !Class415.hashSet_1.Contains(class2.String_2)))
						{
							this.list_2.Add(class2);
						}
						if ((double)this.class393_0.Single_2 > 0.3 && this.class393_0.UInt32_12 != 65535U && this.class159_0.Class392_0.UInt32_106 == 1U && Class268.bool_88)
						{
							if (this.class393_0.UInt32_12 == class2.UInt32_12 && class2.Boolean_7 && class2.Single_2 > 0f)
							{
								Class432 class432_2 = this.class159_0.Class432_0;
								class432_2.string_13 += class2.String_0;
							}
						}
						else if (this.class393_0.UInt32_10 != 4294967295U && class2.UInt32_10 == this.class393_0.UInt32_10 && class2.Single_2 > 0f)
						{
							Class432 class432_3 = this.class159_0.Class432_0;
							class432_3.string_13 += class2.String_0;
							if (class2.String_0 == this.class159_0.Class432_0.String_10 && this.class393_1 == null)
							{
								this.class393_1 = class2;
							}
						}
						if (class2.Boolean_6)
						{
							this.list_1.Add(class2);
						}
					}
				}
			}
			this.class393_3 = null;
			if (this.class393_0 != null && (double)this.class393_0.Single_2 < 0.3)
			{
				this.class393_3 = this.class393_0;
			}
			else
			{
				this.class393_3 = this.IEnumerable_3.Where(new Func<Class393, bool>(Class394.Class395.<>9.method_3)).OrderBy(new Func<Class393, float>(Class394.Class395.<>9.method_4)).ThenByDescending(new Func<Class393, bool>(this.method_9)).FirstOrDefault<Class393>();
			}
			if (Class268.bool_74 && this.class393_3 == null)
			{
				this.class393_3 = this.list_0.Where(new Func<Class393, bool>(Class394.Class395.<>9.method_5)).OrderBy(new Func<Class393, float>(Class394.Class395.<>9.method_6)).FirstOrDefault<Class393>();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06002956 RID: 10582 RVA: 0x0011C59C File Offset: 0x0011A79C
	public HashSet<uint> method_5(uint uint_0)
	{
		HashSet<uint> hashSet = new HashSet<uint>();
		this.method_7(uint_0, hashSet);
		return hashSet;
	}

	// Token: 0x06002957 RID: 10583 RVA: 0x0011C5B8 File Offset: 0x0011A7B8
	public HashSet<uint> method_6(uint[] uint_0)
	{
		uint num = this.class159_0.Class405_0.method_20(uint_0);
		if (num > 0U)
		{
			return this.method_5(num);
		}
		return new HashSet<uint>();
	}

	// Token: 0x06002958 RID: 10584 RVA: 0x0011C5E8 File Offset: 0x0011A7E8
	private void method_7(uint uint_0, HashSet<uint> hashSet_0)
	{
		if (uint_0 <= 0U)
		{
			return;
		}
		if (hashSet_0.Count > 5000)
		{
			return;
		}
		if (!hashSet_0.Contains(uint_0))
		{
			hashSet_0.Add(uint_0);
			this.method_7(this.class159_0.Class405_0.method_11(uint_0), hashSet_0);
			this.method_7(this.class159_0.Class405_0.method_11(uint_0 + 4U), hashSet_0);
			this.method_7(this.class159_0.Class405_0.method_11(uint_0 + 8U), hashSet_0);
		}
	}

	// Token: 0x06002959 RID: 10585 RVA: 0x0001E657 File Offset: 0x0001C857
	[CompilerGenerated]
	private bool method_8(Class393 class393_4)
	{
		return class393_4.UInt32_3 == this.class159_0.Class392_0.UInt32_99;
	}

	// Token: 0x0600295A RID: 10586 RVA: 0x0001E671 File Offset: 0x0001C871
	[CompilerGenerated]
	private bool method_9(Class393 class393_4)
	{
		return !this.class159_0.IEnumerable_0.Contains(class393_4.UInt32_1);
	}

	// Token: 0x04001BA8 RID: 7080
	private Class159 class159_0;

	// Token: 0x04001BA9 RID: 7081
	public List<Class393> list_0 = new List<Class393>();

	// Token: 0x04001BAA RID: 7082
	public List<Class393> list_1 = new List<Class393>();

	// Token: 0x04001BAB RID: 7083
	public List<Class393> list_2 = new List<Class393>();

	// Token: 0x04001BAC RID: 7084
	public Class393 class393_0;

	// Token: 0x04001BAD RID: 7085
	public Class393 class393_1;

	// Token: 0x04001BAE RID: 7086
	public Class393 class393_2;

	// Token: 0x04001BAF RID: 7087
	public Class393 class393_3;

	// Token: 0x04001BB0 RID: 7088
	[CompilerGenerated]
	private List<Class393> list_3;

	// Token: 0x020002C8 RID: 712
	[CompilerGenerated]
	[Serializable]
	private sealed class Class395
	{
		// Token: 0x0600295D RID: 10589 RVA: 0x0001E698 File Offset: 0x0001C898
		internal bool method_0(Class393 class393_0)
		{
			return class393_0.Boolean_7;
		}

		// Token: 0x0600295E RID: 10590 RVA: 0x0000E43A File Offset: 0x0000C63A
		internal bool method_1(Class393 class393_0)
		{
			return class393_0.Boolean_10;
		}

		// Token: 0x0600295F RID: 10591 RVA: 0x0001E6A0 File Offset: 0x0001C8A0
		internal bool method_2(Class393 class393_0)
		{
			return class393_0.Boolean_9;
		}

		// Token: 0x06002960 RID: 10592 RVA: 0x0011C668 File Offset: 0x0011A868
		internal bool method_3(Class393 class393_0)
		{
			return class393_0.Single_2 > 0f && !class393_0.List_0.Contains(4638U) && class393_0.Single_2 * 100f <= (float)Class268.int_20 && class393_0.Single_4 < 15f;
		}

		// Token: 0x06002961 RID: 10593 RVA: 0x000114E5 File Offset: 0x0000F6E5
		internal float method_4(Class393 class393_0)
		{
			return class393_0.Single_2;
		}

		// Token: 0x06002962 RID: 10594 RVA: 0x0001E6A8 File Offset: 0x0001C8A8
		internal bool method_5(Class393 class393_0)
		{
			return class393_0.Single_2 > 0f && class393_0.Boolean_8 && class393_0.Single_2 * 100f <= (float)Class268.int_20 && class393_0.Single_4 < 15f;
		}

		// Token: 0x06002963 RID: 10595 RVA: 0x000114E5 File Offset: 0x0000F6E5
		internal float method_6(Class393 class393_0)
		{
			return class393_0.Single_2;
		}

		// Token: 0x04001BB1 RID: 7089
		public static readonly Class394.Class395 <>9 = new Class394.Class395();

		// Token: 0x04001BB2 RID: 7090
		public static Func<Class393, bool> <>9__2_0;

		// Token: 0x04001BB3 RID: 7091
		public static Func<Class393, bool> <>9__6_0;

		// Token: 0x04001BB4 RID: 7092
		public static Func<Class393, bool> <>9__17_0;

		// Token: 0x04001BB5 RID: 7093
		public static Func<Class393, bool> <>9__31_0;

		// Token: 0x04001BB6 RID: 7094
		public static Func<Class393, float> <>9__31_1;

		// Token: 0x04001BB7 RID: 7095
		public static Func<Class393, bool> <>9__31_3;

		// Token: 0x04001BB8 RID: 7096
		public static Func<Class393, float> <>9__31_4;
	}
}
