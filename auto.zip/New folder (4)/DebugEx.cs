﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using _i;

// Token: 0x0200016E RID: 366
internal partial class DebugEx : Form
{
	// Token: 0x170004A5 RID: 1189
	// (get) Token: 0x060011B9 RID: 4537 RVA: 0x0000E297 File Offset: 0x0000C497
	// (set) Token: 0x060011BA RID: 4538 RVA: 0x0000E29F File Offset: 0x0000C49F
	public Class159 Class159_0 { get; set; }

	// Token: 0x060011BB RID: 4539 RVA: 0x0000E2A8 File Offset: 0x0000C4A8
	public DebugEx()
	{
		this.InitializeComponent();
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x00064198 File Offset: 0x00062398
	private void allToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class393 @class in this.Class159_0.Class394_0.list_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_1.ToString());
			listViewItem.SubItems.Add(@class.String_2);
			listViewItem.SubItems.Add(@class.Single_4.ToString());
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x0000E2B6 File Offset: 0x0000C4B6
	private void btnDoString_Click(object sender, EventArgs e)
	{
		Task.Run(new Action(this.method_0));
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x0000E2CA File Offset: 0x0000C4CA
	private void txtPushDebugMessage_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			this.Class159_0.method_282("PushDebugMessage('" + this.txtPushDebugMessage.Text + "')", false);
		}
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x0006425C File Offset: 0x0006245C
	private void questFrameItemToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class388 @class in this.Class159_0.Class389_0.List_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_1.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.UInt32_2.ToString());
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011C0 RID: 4544 RVA: 0x0000E2FC File Offset: 0x0000C4FC
	private void lvObject_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.pgGameObject.SelectedObject = this.lvObject.SelectedItems[0].Tag;
	}

	// Token: 0x060011C1 RID: 4545 RVA: 0x0006431C File Offset: 0x0006251C
	private void DebugEx_Load(object sender, EventArgs e)
	{
		base.Icon = GClass130.Icon_1;
		if (this.Class159_0 != null)
		{
			this.pgTLBB.SelectedObject = this.Class159_0.Class432_0;
			this.pgGame.SelectedObject = this.Class159_0;
			this.Text = this.Class159_0.Class432_0.String_2;
		}
	}

	// Token: 0x060011C2 RID: 4546 RVA: 0x0000E31F File Offset: 0x0000C51F
	private void txtQuestFrameClick_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			this.Class159_0.Class389_0.method_5(this.txtQuestFrameClick.Text);
		}
	}

	// Token: 0x060011C3 RID: 4547 RVA: 0x0006437C File Offset: 0x0006257C
	private void gameTaskToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class421 @class in Class421.smethod_1(this.Class159_0))
		{
			ListViewItem listViewItem = new ListViewItem(@class.int_1.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.Int32_0.ToString());
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011C4 RID: 4548 RVA: 0x0000E347 File Offset: 0x0000C547
	private void btnPush_Click(object sender, EventArgs e)
	{
		this.Class159_0.method_282("PushDebugMessage('" + this.txtPushDebugMessage.Text + "')", false);
	}

	// Token: 0x060011C5 RID: 4549 RVA: 0x00064434 File Offset: 0x00062634
	private void useSkill3ToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (this.lvObject.SelectedItems.Count > 0 && this.lvObject.Tag is Class393)
		{
			this.Class159_0.method_289(3, (this.lvObject.Tag as Class393).UInt32_1);
		}
	}

	// Token: 0x060011C6 RID: 4550 RVA: 0x00064488 File Offset: 0x00062688
	private void bankToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_10)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011C7 RID: 4551 RVA: 0x0006453C File Offset: 0x0006273C
	private void packetToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011C8 RID: 4552 RVA: 0x000645F0 File Offset: 0x000627F0
	private void trangBiToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_6)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011C9 RID: 4553 RVA: 0x000646A4 File Offset: 0x000628A4
	private void shopToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_9)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011CA RID: 4554 RVA: 0x00064758 File Offset: 0x00062958
	private void rideToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_11)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_0.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011CB RID: 4555 RVA: 0x0000E36F File Offset: 0x0000C56F
	private void doActionToolStripMenuItem_Click(object sender, EventArgs e)
	{
		(this.lvObject.SelectedItems[0].Tag as Class209).method_0();
	}

	// Token: 0x060011CC RID: 4556 RVA: 0x0000E391 File Offset: 0x0000C591
	private void doSubActionToolStripMenuItem_Click(object sender, EventArgs e)
	{
		(this.lvObject.SelectedItems[0].Tag as Class209).method_1();
	}

	// Token: 0x060011CD RID: 4557 RVA: 0x0000E3B3 File Offset: 0x0000C5B3
	private void useToolStripMenuItem_Click(object sender, EventArgs e)
	{
		(this.lvObject.SelectedItems[0].Tag as Class209).method_2();
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x00002E18 File Offset: 0x00001018
	private void button1_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060011CF RID: 4559 RVA: 0x0006480C File Offset: 0x00062A0C
	private void lootToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_12)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_0.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x000648C0 File Offset: 0x00062AC0
	private void thienCoToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_4)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011D1 RID: 4561 RVA: 0x00064974 File Offset: 0x00062B74
	private void teamToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		this.Class159_0.Class386_0.method_0();
		this.Class159_0.Class386_0.Int32_0 = 6;
		foreach (Class385 @class in this.Class159_0.Class386_0.List_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.String_1);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011D2 RID: 4562 RVA: 0x00064A34 File Offset: 0x00062C34
	private void instanceToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (this.lvObject.SelectedItems.Count > 0 && this.lvObject.SelectedItems[0].Tag is Class393)
		{
			Class393 @class = this.lvObject.SelectedItems[0].Tag as Class393;
			string text = string.Concat(new string[]
			{
				"public static NPC ",
				Class426.smethod_64(@class.String_2).Replace(" ", ""),
				"  = new NPC()\r\n{\r\n\tId = ",
				@class.UInt32_1.ToString(),
				",\r\n\tX = ",
				@class.Int32_0.ToString(),
				",\r\n\tY = ",
				@class.Int32_1.ToString(),
				",\r\n\tMap = Id,\r\n\tINFOAIM = \"#G",
				this.Class159_0.Class432_0.string_7,
				"#R",
				@class.String_2,
				"#{_INFOAIM",
				@class.Int32_0.ToString(),
				",",
				@class.Int32_1.ToString(),
				",",
				this.Class159_0.Class432_0.UInt32_29.ToString(),
				",",
				@class.String_2,
				"}\"\r\n};"
			});
			MessageBox.Show(this, text, "MicroAuto", MessageBoxButtons.OK);
			Clipboard.SetText(text);
		}
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x00064BCC File Offset: 0x00062DCC
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.btnClearSniff.Text = "Clear (" + this.Class159_0.List_27.Count.ToString() + ")";
	}

	// Token: 0x060011D4 RID: 4564 RVA: 0x00064C0C File Offset: 0x00062E0C
	private void btnShowSniff_Click(object sender, EventArgs e)
	{
		while (this.Class159_0.List_27.Count > 0)
		{
			ByteViewer byteViewer = new ByteViewer();
			byteViewer.SetBytes(this.Class159_0.List_27[0]);
			byteViewer.Dock = DockStyle.Top;
			byteViewer.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			byteViewer.Height = 100;
			byteViewer.MouseClick += this.method_1;
			this.panSniff.Controls.Add(byteViewer);
			this.Class159_0.List_27.RemoveAt(0);
		}
	}

	// Token: 0x060011D5 RID: 4565 RVA: 0x0000E3D5 File Offset: 0x0000C5D5
	private void btnClearSniff_Click(object sender, EventArgs e)
	{
		this.Class159_0.List_27.Clear();
		this.panSniff.Controls.Clear();
	}

	// Token: 0x060011D6 RID: 4566 RVA: 0x0000E3F7 File Offset: 0x0000C5F7
	private void btnSendPacket_Click(object sender, EventArgs e)
	{
		this.Class159_0.method_116(this.txtPacket.Text);
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x00064C98 File Offset: 0x00062E98
	private void tuiChanNguyenToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class209 @class in this.Class159_0.Class196_0.IEnumerable_7)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_0.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011D8 RID: 4568 RVA: 0x00064D4C File Offset: 0x00062F4C
	private void uskill3ToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (this.lvObject.SelectedItems.Count > 0 && this.lvObject.SelectedItems[0].Tag is Class393)
		{
			Class393 @class = this.lvObject.SelectedItems[0].Tag as Class393;
			this.Class159_0.method_289(3, @class.UInt32_1);
		}
	}

	// Token: 0x060011D9 RID: 4569 RVA: 0x00064DB8 File Offset: 0x00062FB8
	private void pickToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (this.lvObject.SelectedItems.Count > 0 && this.lvObject.SelectedItems[0].Tag is Class393)
		{
			Class393 @class = this.lvObject.SelectedItems[0].Tag as Class393;
			this.Class159_0.method_219((int)@class.UInt32_1);
		}
	}

	// Token: 0x060011DA RID: 4570 RVA: 0x00064E24 File Offset: 0x00063024
	private void trapToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class393 @class in this.Class159_0.Class394_0.list_0.Where(new Func<Class393, bool>(DebugEx.Class148.<>9.method_0)))
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_1.ToString());
			listViewItem.SubItems.Add(@class.String_2);
			listViewItem.SubItems.Add(@class.Single_4.ToString());
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x00064F04 File Offset: 0x00063104
	private void gameControlToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class390 @class in Class390.smethod_0(this.Class159_0))
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_3.ToString());
			listViewItem.SubItems.Add(@class.String_0);
			listViewItem.SubItems.Add(@class.UInt32_4.ToString());
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011DC RID: 4572 RVA: 0x00064FBC File Offset: 0x000631BC
	private void petToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.lvObject.Items.Clear();
		foreach (Class237 @class in this.Class159_0.Class432_0.IEnumerable_0)
		{
			ListViewItem listViewItem = new ListViewItem(@class.UInt32_10.ToString());
			listViewItem.SubItems.Add(@class.String_1);
			listViewItem.Tag = @class;
			this.lvObject.Items.Add(listViewItem);
		}
	}

	// Token: 0x060011DD RID: 4573 RVA: 0x0000E40F File Offset: 0x0000C60F
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060011DF RID: 4575 RVA: 0x00066CF4 File Offset: 0x00064EF4
	[CompilerGenerated]
	private void method_0()
	{
		this.Class159_0.method_282(this.txtDoString.Text, false);
		this.txtToString.Text = this.Class159_0.method_396("DebugEx");
		Thread.Sleep(500);
		this.txtToString.Text = this.Class159_0.method_396("DebugEx");
	}

	// Token: 0x060011E0 RID: 4576 RVA: 0x00066D58 File Offset: 0x00064F58
	[CompilerGenerated]
	private void method_1(object sender, MouseEventArgs e)
	{
		ByteViewer byteViewer = sender as ByteViewer;
		this.txtHex.Text = Class265.smethod_0(byteViewer.GetBytes());
	}

	// Token: 0x04000937 RID: 2359
	[CompilerGenerated]
	private Class159 class159_0;

	// Token: 0x0200016F RID: 367
	[CompilerGenerated]
	[Serializable]
	private sealed class Class148
	{
		// Token: 0x060011E3 RID: 4579 RVA: 0x0000E43A File Offset: 0x0000C63A
		internal bool method_0(Class393 class393_0)
		{
			return class393_0.Boolean_10;
		}

		// Token: 0x0400096E RID: 2414
		public static readonly DebugEx.Class148 <>9 = new DebugEx.Class148();

		// Token: 0x0400096F RID: 2415
		public static Func<Class393, bool> <>9__35_0;
	}
}
