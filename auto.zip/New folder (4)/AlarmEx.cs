﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000201 RID: 513
internal partial class AlarmEx : Form
{
	// Token: 0x06001AA8 RID: 6824 RVA: 0x000135CC File Offset: 0x000117CC
	public AlarmEx()
	{
		this.InitializeComponent();
		if (Main.Boolean_16)
		{
			base.Opacity = 0.0;
			return;
		}
		base.Opacity = 75.0;
	}

	// Token: 0x1700066F RID: 1647
	// (get) Token: 0x06001AA9 RID: 6825 RVA: 0x00013600 File Offset: 0x00011800
	public static AlarmEx AlarmEx_0
	{
		get
		{
			if (AlarmEx.alarmEx_0 == null)
			{
				AlarmEx.alarmEx_0 = new AlarmEx();
			}
			return AlarmEx.alarmEx_0;
		}
	}

	// Token: 0x06001AAA RID: 6826 RVA: 0x000C8B38 File Offset: 0x000C6D38
	public static void smethod_0(object object_0)
	{
		AlarmVaoPhai value = new AlarmVaoPhai(object_0 as Class159);
		AlarmEx.AlarmEx_0.Controls.Add(value);
		AlarmEx.AlarmEx_0.Show();
	}

	// Token: 0x06001AAB RID: 6827 RVA: 0x000C8B6C File Offset: 0x000C6D6C
	private void AlarmEx_Load(object sender, EventArgs e)
	{
		Class438.smethod_14(this, Class438.Enum22.BottomLeft);
		base.Location = new Point(base.Location.X, base.Location.Y - 25);
	}

	// Token: 0x06001AAC RID: 6828 RVA: 0x000C8BAC File Offset: 0x000C6DAC
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (Main.Boolean_16)
		{
			base.Opacity = 0.0;
		}
		else
		{
			base.Opacity = 75.0;
		}
		if (AlarmEx.AlarmEx_0.Controls.Count == 0)
		{
			base.Hide();
			return;
		}
		base.Show();
	}

	// Token: 0x06001AAD RID: 6829 RVA: 0x00013618 File Offset: 0x00011818
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x040010AB RID: 4267
	public static AlarmEx alarmEx_0;

	// Token: 0x02000202 RID: 514
	// (Invoke) Token: 0x06001AB0 RID: 6832
	public delegate void Delegate0(Class159 game);
}
