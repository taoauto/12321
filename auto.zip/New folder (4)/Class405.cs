﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x020002E1 RID: 737
internal class Class405
{
	// Token: 0x1700099C RID: 2460
	// (get) Token: 0x06002A1A RID: 10778 RVA: 0x0001ECE0 File Offset: 0x0001CEE0
	// (set) Token: 0x06002A1B RID: 10779 RVA: 0x0001ECE8 File Offset: 0x0001CEE8
	public IntPtr IntPtr_0 { get; set; }

	// Token: 0x1700099D RID: 2461
	// (get) Token: 0x06002A1C RID: 10780 RVA: 0x0001ECF1 File Offset: 0x0001CEF1
	// (set) Token: 0x06002A1D RID: 10781 RVA: 0x0001ECF9 File Offset: 0x0001CEF9
	public int Int32_0 { get; set; }

	// Token: 0x1700099E RID: 2462
	// (get) Token: 0x06002A1E RID: 10782 RVA: 0x0001ED02 File Offset: 0x0001CF02
	// (set) Token: 0x06002A1F RID: 10783 RVA: 0x0001ED0A File Offset: 0x0001CF0A
	public int Int32_1 { get; set; }

	// Token: 0x06002A20 RID: 10784 RVA: 0x0001ED13 File Offset: 0x0001CF13
	public Class405(int int_9)
	{
		this.Int32_0 = int_9;
		this.IntPtr_0 = Class405.OpenProcess(2035711, false, int_9);
	}

	// Token: 0x06002A21 RID: 10785 RVA: 0x0011F74C File Offset: 0x0011D94C
	public static int smethod_0(string string_0)
	{
		if (string_0 == "??")
		{
			return -1;
		}
		int result;
		int.TryParse(string_0, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x06002A22 RID: 10786 RVA: 0x0011F77C File Offset: 0x0011D97C
	public static byte smethod_1(string string_0)
	{
		byte result;
		byte.TryParse(string_0, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x06002A23 RID: 10787 RVA: 0x0011F7A0 File Offset: 0x0011D9A0
	public static byte[] smethod_2(string string_0)
	{
		byte[] array = new byte[string_0.Length / 2];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = Class405.smethod_1(string_0.Substring(i * 2, 2));
		}
		return array;
	}

	// Token: 0x06002A24 RID: 10788 RVA: 0x0011F7DC File Offset: 0x0011D9DC
	public uint method_0(string string_0)
	{
		Process processById = Process.GetProcessById(this.Int32_0);
		for (int i = 0; i < processById.Modules.Count; i++)
		{
			if (processById.Modules[i].ModuleName.ToLower() == string_0.ToLower())
			{
				return (uint)((int)processById.Modules[i].BaseAddress);
			}
		}
		return 0U;
	}

	// Token: 0x06002A25 RID: 10789 RVA: 0x0011F848 File Offset: 0x0011DA48
	public string method_1(string string_0)
	{
		string text = "";
		if (string_0.Length % 2 != 0)
		{
			string_0 = "0" + string_0;
		}
		for (int i = string_0.Length / 2 - 1; i >= 0; i--)
		{
			text += string_0.Substring(i * 2, 2);
		}
		return text;
	}

	// Token: 0x06002A26 RID: 10790 RVA: 0x0011F89C File Offset: 0x0011DA9C
	public static bool smethod_3(byte[] byte_0, int[] int_9, int int_10)
	{
		for (int i = 0; i < int_9.Length; i++)
		{
			if (int_9[i] != -1)
			{
				if (int_9[i] == 257)
				{
					if (byte_0[int_10 + i] == 0)
					{
						return false;
					}
				}
				else if ((int)byte_0[int_10 + i] != int_9[i])
				{
					return false;
				}
			}
		}
		return true;
	}

	// Token: 0x06002A27 RID: 10791 RVA: 0x0011F8E4 File Offset: 0x0011DAE4
	public int method_2(string string_0, string string_1)
	{
		Process processById = Process.GetProcessById(this.Int32_0);
		for (int i = 0; i < processById.Modules.Count; i++)
		{
			if (processById.Modules[i].ModuleName.ToLower().Contains(string_1.ToLower()))
			{
				return this.method_9(string_0, (int)processById.Modules[i].BaseAddress, (int)processById.Modules[i].BaseAddress + processById.Modules[i].ModuleMemorySize, 0);
			}
		}
		return 0;
	}

	// Token: 0x06002A28 RID: 10792 RVA: 0x0011F980 File Offset: 0x0011DB80
	public int method_3(string string_0, string string_1, int int_9)
	{
		Process processById = Process.GetProcessById(this.Int32_0);
		for (int i = 0; i < processById.Modules.Count; i++)
		{
			if (processById.Modules[i].ModuleName.ToLower().Contains(string_1.ToLower()))
			{
				return this.method_9(string_0, (int)processById.Modules[i].BaseAddress + (int_9 - (int)processById.Modules[i].BaseAddress), (int)processById.Modules[i].BaseAddress + processById.Modules[i].ModuleMemorySize, 0);
			}
		}
		return 0;
	}

	// Token: 0x06002A29 RID: 10793 RVA: 0x0011FA34 File Offset: 0x0011DC34
	public int method_4(string string_0, string string_1, int int_9)
	{
		Process processById = Process.GetProcessById(this.Int32_0);
		for (int i = 0; i < processById.Modules.Count; i++)
		{
			if (processById.Modules[i].ModuleName.ToLower() == string_1.ToLower())
			{
				return this.method_9(string_0, (int)processById.Modules[i].BaseAddress, (int)processById.Modules[i].BaseAddress + processById.Modules[i].ModuleMemorySize, int_9);
			}
		}
		return 0;
	}

	// Token: 0x06002A2A RID: 10794 RVA: 0x0001ED34 File Offset: 0x0001CF34
	public int method_5(string string_0)
	{
		return this.method_9(string_0, -1, -1, 0);
	}

	// Token: 0x06002A2B RID: 10795 RVA: 0x0001ED40 File Offset: 0x0001CF40
	public int method_6(string string_0, int int_9)
	{
		return this.method_9(string_0, -1, -1, int_9);
	}

	// Token: 0x06002A2C RID: 10796 RVA: 0x0001ED4C File Offset: 0x0001CF4C
	public int method_7(string string_0, int int_9, int int_10, int int_11)
	{
		return this.method_9(Class265.smethod_17(string_0), int_9, int_10, int_11);
	}

	// Token: 0x06002A2D RID: 10797 RVA: 0x0001ED5E File Offset: 0x0001CF5E
	public int method_8(string string_0)
	{
		return this.method_5(Class265.smethod_17(string_0));
	}

	// Token: 0x06002A2E RID: 10798 RVA: 0x0011FAD0 File Offset: 0x0011DCD0
	public int method_9(string string_0, int int_9, int int_10, int int_11)
	{
		int num = 0;
		int result = 0;
		try
		{
			if (int_9 == -1)
			{
				int_9 = (int)Process.GetProcessById(this.Int32_0).MainModule.BaseAddress;
			}
			if (int_10 == -1)
			{
				int_10 = int_9 + Process.GetProcessById(this.Int32_0).MainModule.ModuleMemorySize;
			}
		}
		catch
		{
			int_9 = 262144;
			int_10 = 8978431;
		}
		if (int_9 == 0 && int_10 == 0)
		{
			int_9 = 0;
			int_10 = int.MaxValue;
		}
		int[] array = Class265.smethod_21(string_0);
		byte[] array2 = new byte[Class405.int_3 + array.Length];
		int num2 = (int_10 - int_9) / Class405.int_3;
		int num3 = (int_10 - int_9) % Class405.int_3;
		for (int i = 0; i < num2; i++)
		{
			Class405.ReadProcessMemory_2(this.IntPtr_0, int_9 + i * Class405.int_3, array2, array2.Length, out this.int_2);
			for (int j = 0; j < Class405.int_3; j++)
			{
				if (Class405.smethod_3(array2, array, j))
				{
					int num4 = j + i * Class405.int_3 + int_9;
					if (num++ >= int_11)
					{
						return num4;
					}
					result = num4;
				}
			}
		}
		if (num3 > 0)
		{
			array2 = new byte[num3 + array.Length];
			Class405.ReadProcessMemory(this.IntPtr_0, int_9 + num2 * Class405.int_3, array2, array2.Length, 0);
			for (int k = 0; k < num3; k++)
			{
				if (Class405.smethod_3(array2, array, k))
				{
					int num4 = k + int_9 + num2 * Class405.int_3;
					if (num++ >= int_11)
					{
						return num4;
					}
					result = num4;
				}
			}
		}
		return result;
	}

	// Token: 0x06002A2F RID: 10799 RVA: 0x0001ED6C File Offset: 0x0001CF6C
	public static int smethod_4(int int_9)
	{
		return (int)Process.GetProcessById(int_9).Modules[0].BaseAddress;
	}

	// Token: 0x06002A30 RID: 10800 RVA: 0x0011FC60 File Offset: 0x0011DE60
	public static int smethod_5(string string_0, int int_9, int int_10, int int_11, int int_12)
	{
		int num = 0;
		int result = 0;
		try
		{
			if (int_9 == -1)
			{
				int_9 = (int)Process.GetProcessById(int_12).MainModule.BaseAddress;
			}
			if (int_10 == -1)
			{
				int_10 = int_9 + Process.GetProcessById(int_12).MainModule.ModuleMemorySize;
			}
		}
		catch
		{
			int_9 = 262144;
			int_10 = 8978431;
		}
		if (int_9 == 0 && int_10 == 0)
		{
			int_9 = 0;
			int_10 = int.MaxValue;
		}
		int[] array = Class265.smethod_21(string_0);
		byte[] array2 = new byte[Class405.int_3 + array.Length];
		int num2 = (int_10 - int_9) / Class405.int_3;
		int num3 = (int_10 - int_9) % Class405.int_3;
		IntPtr intptr_ = Class405.OpenProcess(2035711, false, int_12);
		for (int i = 0; i < num2; i++)
		{
			int num4;
			Class405.ReadProcessMemory_2(intptr_, int_9 + i * Class405.int_3, array2, array2.Length, out num4);
			for (int j = 0; j < Class405.int_3; j++)
			{
				if (Class405.smethod_3(array2, array, j))
				{
					int num5 = j + i * Class405.int_3 + int_9;
					if (num++ >= int_11)
					{
						return num5;
					}
					result = num5;
				}
			}
		}
		if (num3 > 0)
		{
			array2 = new byte[num3 + array.Length];
			Class405.ReadProcessMemory(intptr_, int_9 + num2 * Class405.int_3, array2, array2.Length, 0);
			for (int k = 0; k < num3; k++)
			{
				if (Class405.smethod_3(array2, array, k))
				{
					int num5 = k + int_9 + num2 * Class405.int_3;
					if (num++ >= int_11)
					{
						return num5;
					}
					result = num5;
				}
			}
		}
		return result;
	}

	// Token: 0x06002A31 RID: 10801 RVA: 0x0011FDE8 File Offset: 0x0011DFE8
	public uint[] method_10(uint uint_0, uint[] uint_1)
	{
		uint[] array = new uint[uint_1.Length + 1];
		array[0] = uint_0;
		uint_1.CopyTo(array, 1);
		return array;
	}

	// Token: 0x06002A32 RID: 10802 RVA: 0x0011FE10 File Offset: 0x0011E010
	public uint method_11(uint uint_0)
	{
		byte[] array = new byte[4];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 4, 0);
		return BitConverter.ToUInt32(array, 0);
	}

	// Token: 0x06002A33 RID: 10803 RVA: 0x0011FE3C File Offset: 0x0011E03C
	public uint method_12(uint uint_0)
	{
		byte[] array = new byte[4];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 1, 0);
		return BitConverter.ToUInt32(array, 0);
	}

	// Token: 0x06002A34 RID: 10804 RVA: 0x0011FE68 File Offset: 0x0011E068
	public uint method_13(uint uint_0, uint uint_1)
	{
		uint_0 = this.method_43(uint_0, uint_1);
		byte[] array = new byte[4];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 1, 0);
		return BitConverter.ToUInt32(array, 0);
	}

	// Token: 0x06002A35 RID: 10805 RVA: 0x0011FEA0 File Offset: 0x0011E0A0
	public uint method_14(uint uint_0)
	{
		byte[] array = new byte[4];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 2, 0);
		return BitConverter.ToUInt32(array, 0);
	}

	// Token: 0x06002A36 RID: 10806 RVA: 0x0011FECC File Offset: 0x0011E0CC
	public ulong method_15(uint uint_0)
	{
		byte[] array = new byte[8];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 8, 0);
		return BitConverter.ToUInt64(array, 0);
	}

	// Token: 0x06002A37 RID: 10807 RVA: 0x0011FEF8 File Offset: 0x0011E0F8
	public ulong method_16(uint[] uint_0)
	{
		byte[] array = new byte[8];
		uint uint_ = this.method_44(uint_0);
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_, array, 8, 0);
		return BitConverter.ToUInt64(array, 0);
	}

	// Token: 0x06002A38 RID: 10808 RVA: 0x0001ED89 File Offset: 0x0001CF89
	public uint method_17(uint uint_0, uint uint_1)
	{
		uint_0 = this.method_11(uint_0);
		uint_0 = this.method_11(uint_0 + uint_1);
		return uint_0;
	}

	// Token: 0x06002A39 RID: 10809 RVA: 0x0001EDA0 File Offset: 0x0001CFA0
	public uint method_18(uint uint_0, uint[] uint_1)
	{
		return this.method_20(this.method_10(uint_0, uint_1));
	}

	// Token: 0x06002A3A RID: 10810 RVA: 0x0011FF2C File Offset: 0x0011E12C
	public uint method_19(uint[] uint_0, uint uint_1)
	{
		uint num = this.method_20(uint_0);
		return this.method_11(num + uint_1);
	}

	// Token: 0x06002A3B RID: 10811 RVA: 0x0011FF4C File Offset: 0x0011E14C
	public uint method_20(uint[] uint_0)
	{
		uint num = this.method_11(uint_0[0]);
		for (int i = 1; i < uint_0.Length; i++)
		{
			num = this.method_11(num + uint_0[i]);
		}
		return num;
	}

	// Token: 0x06002A3C RID: 10812 RVA: 0x0011FF80 File Offset: 0x0011E180
	public bool method_21(uint[] uint_0)
	{
		byte[] array = new byte[4];
		int num;
		Class405.ReadProcessMemory_3(this.IntPtr_0, uint_0[0], array, 4, out num);
		uint num2 = BitConverter.ToUInt32(array, 0);
		if (num == 0)
		{
			return false;
		}
		for (int i = 1; i < uint_0.Length - 1; i++)
		{
			num = 0;
			Class405.ReadProcessMemory_3(this.IntPtr_0, num2 + uint_0[i], array, 4, out num);
			if (num == 0)
			{
				return false;
			}
			num2 = BitConverter.ToUInt32(array, 0);
		}
		if (uint_0.Length > 1)
		{
			num = 0;
			Class405.ReadProcessMemory_3(this.IntPtr_0, num2 + uint_0[uint_0.Length - 1], array, 4, out num);
			if (num == 0)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06002A3D RID: 10813 RVA: 0x00120010 File Offset: 0x0011E210
	public float method_22(uint uint_0)
	{
		byte[] array = new byte[4];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 4, 0);
		return BitConverter.ToSingle(array, 0);
	}

	// Token: 0x06002A3E RID: 10814 RVA: 0x0001EDB0 File Offset: 0x0001CFB0
	public float method_23(uint uint_0, uint uint_1)
	{
		return this.method_22(this.method_11(uint_0) + uint_1);
	}

	// Token: 0x06002A3F RID: 10815 RVA: 0x0001EDC1 File Offset: 0x0001CFC1
	public float method_24(uint[] uint_0)
	{
		return this.method_22(this.method_44(uint_0));
	}

	// Token: 0x06002A40 RID: 10816 RVA: 0x0012003C File Offset: 0x0011E23C
	public string method_25(int int_9)
	{
		byte[] array = new byte[500];
		Class405.ReadProcessMemory(this.IntPtr_0, int_9, array, array.Length, 0);
		return Class405.smethod_7(array);
	}

	// Token: 0x06002A41 RID: 10817 RVA: 0x0012006C File Offset: 0x0011E26C
	public string method_26(uint uint_0)
	{
		byte[] byte_ = new byte[500];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, byte_, 500, 0);
		return Class405.smethod_7(byte_);
	}

	// Token: 0x06002A42 RID: 10818 RVA: 0x001200A0 File Offset: 0x0011E2A0
	public string method_27(int int_9, int int_10)
	{
		byte[] byte_ = new byte[int_10];
		Class405.ReadProcessMemory(this.IntPtr_0, int_9, byte_, int_10, 0);
		return Class405.smethod_7(byte_);
	}

	// Token: 0x06002A43 RID: 10819 RVA: 0x001200CC File Offset: 0x0011E2CC
	public string method_28(uint uint_0)
	{
		byte[] byte_ = new byte[60];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, byte_, 60, 0);
		return Class405.smethod_7(byte_);
	}

	// Token: 0x06002A44 RID: 10820 RVA: 0x001200F8 File Offset: 0x0011E2F8
	public byte[] method_29(uint uint_0)
	{
		byte[] array = new byte[60];
		Class405.ReadProcessMemory_1(this.IntPtr_0, uint_0, array, 60, 0);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] == 0)
			{
				Array.Resize<byte>(ref array, i);
				return array;
			}
		}
		return array;
	}

	// Token: 0x06002A45 RID: 10821 RVA: 0x0012013C File Offset: 0x0011E33C
	public string method_30(int int_9)
	{
		byte[] array = new byte[20248];
		Class405.ReadProcessMemory(this.IntPtr_0, int_9, array, array.Length, 0);
		return Class405.smethod_7(array);
	}

	// Token: 0x06002A46 RID: 10822 RVA: 0x0001EDD0 File Offset: 0x0001CFD0
	public string method_31(uint uint_0, uint uint_1)
	{
		return this.method_26(this.method_11(uint_0) + uint_1);
	}

	// Token: 0x06002A47 RID: 10823 RVA: 0x0001EDE1 File Offset: 0x0001CFE1
	public string method_32(uint uint_0, bool bool_0 = false)
	{
		if (this.method_11(uint_0 + 20U) == 15U || bool_0)
		{
			return this.method_28(uint_0);
		}
		return this.method_28(this.method_11(uint_0));
	}

	// Token: 0x06002A48 RID: 10824 RVA: 0x0001EE0A File Offset: 0x0001D00A
	public string method_33(uint uint_0, uint uint_1)
	{
		uint_0 = this.method_11(uint_0) + uint_1;
		return this.method_32(uint_0, false);
	}

	// Token: 0x06002A49 RID: 10825 RVA: 0x0012016C File Offset: 0x0011E36C
	public string method_34(uint[] uint_0)
	{
		uint uint_ = this.method_44(uint_0);
		return this.method_32(uint_, false);
	}

	// Token: 0x06002A4A RID: 10826 RVA: 0x0001EE1F File Offset: 0x0001D01F
	public string method_35(uint[] uint_0)
	{
		return this.method_26(this.method_44(uint_0));
	}

	// Token: 0x06002A4B RID: 10827 RVA: 0x0012018C File Offset: 0x0011E38C
	public void method_36(int int_9, int int_10)
	{
		byte[] bytes = BitConverter.GetBytes(int_10);
		Class405.WriteProcessMemory(this.IntPtr_0, int_9, bytes, 4, 0);
	}

	// Token: 0x06002A4C RID: 10828 RVA: 0x001201B0 File Offset: 0x0011E3B0
	public void method_37(uint uint_0, int int_9)
	{
		byte[] bytes = BitConverter.GetBytes(int_9);
		Class405.WriteProcessMemory_1(this.IntPtr_0, uint_0, bytes, 4, 0);
	}

	// Token: 0x06002A4D RID: 10829 RVA: 0x001201D4 File Offset: 0x0011E3D4
	public void method_38(int int_9, uint uint_0)
	{
		byte[] bytes = BitConverter.GetBytes(uint_0);
		Class405.WriteProcessMemory(this.IntPtr_0, int_9, bytes, 4, 0);
	}

	// Token: 0x06002A4E RID: 10830 RVA: 0x001201F8 File Offset: 0x0011E3F8
	public void method_39(int int_9, uint uint_0, int int_10)
	{
		byte[] bytes = BitConverter.GetBytes(uint_0);
		Class405.WriteProcessMemory(this.IntPtr_0, int_9, bytes, int_10, 0);
	}

	// Token: 0x06002A4F RID: 10831 RVA: 0x0012021C File Offset: 0x0011E41C
	public void method_40(uint uint_0, uint uint_1, int int_9)
	{
		byte[] bytes = BitConverter.GetBytes(uint_1);
		Class405.WriteProcessMemory_1(this.IntPtr_0, uint_0, bytes, int_9, 0);
	}

	// Token: 0x06002A50 RID: 10832 RVA: 0x0001EE2E File Offset: 0x0001D02E
	public void method_41(uint[] uint_0, int int_9)
	{
		this.method_37(this.method_44(uint_0), int_9);
	}

	// Token: 0x06002A51 RID: 10833 RVA: 0x0001EE3E File Offset: 0x0001D03E
	public uint method_42(uint uint_0, uint[] uint_1)
	{
		uint_1[0] = this.method_11(uint_0) + uint_1[0];
		return this.method_44(uint_1);
	}

	// Token: 0x06002A52 RID: 10834 RVA: 0x0001EE55 File Offset: 0x0001D055
	public uint method_43(uint uint_0, uint uint_1)
	{
		return this.method_44(new uint[]
		{
			uint_0,
			uint_1
		});
	}

	// Token: 0x06002A53 RID: 10835 RVA: 0x00120240 File Offset: 0x0011E440
	public uint method_44(uint[] uint_0)
	{
		uint num = this.method_11(uint_0[0]);
		for (int i = 1; i < uint_0.Length - 1; i++)
		{
			num = this.method_11(num + uint_0[i]);
		}
		if (uint_0.Length == 1)
		{
			return num;
		}
		return num + uint_0[uint_0.Length - 1];
	}

	// Token: 0x06002A54 RID: 10836 RVA: 0x00120284 File Offset: 0x0011E484
	public static string smethod_6(int int_9)
	{
		if (int_9 < 256)
		{
			return Class426.char_0[int_9].ToString();
		}
		return ((char)int_9).ToString();
	}

	// Token: 0x06002A55 RID: 10837 RVA: 0x001202B4 File Offset: 0x0011E4B4
	public static string smethod_7(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in byte_0)
		{
			if (c == '\0')
			{
				break;
			}
			stringBuilder.Append(Class426.char_0[(int)c]);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06002A56 RID: 10838 RVA: 0x001202F4 File Offset: 0x0011E4F4
	public static string smethod_8(byte[] byte_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in byte_0)
		{
			if (c != '\0')
			{
				stringBuilder.Append(Class426.char_0[(int)c]);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06002A57 RID: 10839 RVA: 0x00120334 File Offset: 0x0011E534
	public static byte[] smethod_9(byte[] byte_0)
	{
		for (int i = 0; i < byte_0.Length; i++)
		{
			byte_0[i] = Class405.smethod_10((int)byte_0[i]);
		}
		return byte_0;
	}

	// Token: 0x06002A58 RID: 10840 RVA: 0x0012035C File Offset: 0x0011E55C
	public static byte smethod_10(int int_9)
	{
		for (int i = 0; i < 256; i++)
		{
			if ((int)Class426.char_0[i] == int_9)
			{
				return (byte)i;
			}
		}
		return 63;
	}

	// Token: 0x06002A59 RID: 10841 RVA: 0x0001697F File Offset: 0x00014B7F
	public static int smethod_11(float float_0)
	{
		return BitConverter.ToInt32(BitConverter.GetBytes(float_0), 0);
	}

	// Token: 0x06002A5A RID: 10842 RVA: 0x0001EE6B File Offset: 0x0001D06B
	public uint method_45(int int_9)
	{
		return Class405.VirtualAllocEx(this.IntPtr_0, 0, int_9 + 16, 4096U, 64U);
	}

	// Token: 0x06002A5B RID: 10843 RVA: 0x0012038C File Offset: 0x0011E58C
	public int method_46(string string_0)
	{
		byte[] bytes = Encoding.Default.GetBytes(string_0);
		int num = (int)Class405.VirtualAllocEx(this.IntPtr_0, 0, bytes.Length + 16, 4096U, 64U);
		Class405.WriteProcessMemory(this.IntPtr_0, num, bytes, bytes.Length, 0);
		return num;
	}

	// Token: 0x06002A5C RID: 10844 RVA: 0x001203D4 File Offset: 0x0011E5D4
	public int method_47(string string_0, int int_9)
	{
		byte[] bytes = Encoding.Default.GetBytes(string_0);
		Class405.WriteProcessMemory(this.IntPtr_0, int_9, bytes, bytes.Length, 0);
		return int_9;
	}

	// Token: 0x06002A5D RID: 10845 RVA: 0x00120400 File Offset: 0x0011E600
	public static int smethod_12(string string_0, int int_9, int int_10)
	{
		IntPtr intptr_ = Class405.OpenProcess(2035711, false, int_10);
		byte[] bytes = Encoding.Default.GetBytes(string_0);
		Class405.WriteProcessMemory(intptr_, int_9, bytes, bytes.Length, 0);
		return int_9;
	}

	// Token: 0x06002A5E RID: 10846 RVA: 0x00120434 File Offset: 0x0011E634
	public static bool smethod_13(byte[] byte_0, uint uint_0, int int_9)
	{
		IntPtr intptr_ = Class405.OpenProcess(2035711, false, int_9);
		uint enum17_;
		Class405.VirtualProtectEx(intptr_, uint_0, byte_0.Length, Class405.Enum17.PAGE_READWRITE, out enum17_);
		Class405.WriteProcessMemory_1(intptr_, uint_0, byte_0, byte_0.Length, 0);
		uint num;
		return Class405.VirtualProtectEx(intptr_, uint_0, byte_0.Length, (Class405.Enum17)enum17_, out num);
	}

	// Token: 0x06002A5F RID: 10847
	[DllImport("kernel32.dll")]
	private static extern bool VirtualProtectEx(IntPtr intptr_1, uint uint_0, int int_9, Class405.Enum17 enum17_0, out uint uint_1);

	// Token: 0x06002A60 RID: 10848 RVA: 0x00120474 File Offset: 0x0011E674
	public static string smethod_14(int int_9, int int_10)
	{
		IntPtr intptr_ = Class405.OpenProcess(2035711, false, int_10);
		byte[] byte_ = new byte[500];
		Class405.ReadProcessMemory(intptr_, int_9, byte_, 500, 0);
		return Class405.smethod_7(byte_);
	}

	// Token: 0x06002A61 RID: 10849 RVA: 0x001204AC File Offset: 0x0011E6AC
	public static int smethod_15(int int_9, int int_10)
	{
		IntPtr intptr_ = Class405.OpenProcess(2035711, false, int_10);
		byte[] array = new byte[4];
		Class405.ReadProcessMemory(intptr_, int_9, array, 4, 0);
		return BitConverter.ToInt32(array, 0);
	}

	// Token: 0x06002A62 RID: 10850 RVA: 0x001204E0 File Offset: 0x0011E6E0
	public uint method_48(string string_0, uint uint_0)
	{
		string_0 = Class265.smethod_26(string_0);
		byte[] bytes = Encoding.Default.GetBytes(string_0);
		Array.Resize<byte>(ref bytes, bytes.Length + 32);
		Class405.WriteProcessMemory_1(this.IntPtr_0, uint_0, bytes, bytes.Length, 0);
		return uint_0;
	}

	// Token: 0x06002A63 RID: 10851 RVA: 0x0001EE84 File Offset: 0x0001D084
	public void method_49()
	{
		Class405.SetProcessWorkingSetSize(Process.GetProcessById(this.Int32_0).Handle, -1, -1);
	}

	// Token: 0x06002A64 RID: 10852
	[DllImport("kernel32.dll")]
	public static extern IntPtr OpenProcess(int int_9, bool bool_0, int int_10);

	// Token: 0x06002A65 RID: 10853
	[DllImport("kernel32.dll", EntryPoint = "OpenProcess")]
	public static extern IntPtr OpenProcess_1(long long_0, bool bool_0, int int_9);

	// Token: 0x06002A66 RID: 10854
	[DllImport("kernel32.dll")]
	public static extern bool ReadProcessMemory(IntPtr intptr_1, int int_9, byte[] byte_0, int int_10, int int_11);

	// Token: 0x06002A67 RID: 10855
	[DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
	public static extern bool ReadProcessMemory_1(IntPtr intptr_1, uint uint_0, byte[] byte_0, int int_9, int int_10);

	// Token: 0x06002A68 RID: 10856
	[DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
	public static extern bool ReadProcessMemory_2(IntPtr intptr_1, int int_9, byte[] byte_0, int int_10, out int int_11);

	// Token: 0x06002A69 RID: 10857
	[DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
	public static extern bool ReadProcessMemory_3(IntPtr intptr_1, uint uint_0, byte[] byte_0, int int_9, out int int_10);

	// Token: 0x06002A6A RID: 10858
	[DllImport("kernel32.dll")]
	public static extern bool WriteProcessMemory(IntPtr intptr_1, int int_9, byte[] byte_0, int int_10, int int_11);

	// Token: 0x06002A6B RID: 10859
	[DllImport("kernel32.dll", EntryPoint = "WriteProcessMemory")]
	public static extern bool WriteProcessMemory_1(IntPtr intptr_1, uint uint_0, byte[] byte_0, int int_9, int int_10);

	// Token: 0x06002A6C RID: 10860
	[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
	public static extern uint VirtualAllocEx(IntPtr intptr_1, int int_9, int int_10, uint uint_0, uint uint_1);

	// Token: 0x06002A6D RID: 10861
	[DllImport("kernel32.dll")]
	public static extern bool VirtualFreeEx(IntPtr intptr_1, int int_9, int int_10, int int_11);

	// Token: 0x06002A6E RID: 10862
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern bool VirtualProtect(int int_9, uint uint_0, uint uint_1, int int_10);

	// Token: 0x06002A6F RID: 10863
	[DllImport("kernel32.dll")]
	private static extern bool SetProcessWorkingSetSize(IntPtr intptr_1, int int_9, int int_10);

	// Token: 0x06002A70 RID: 10864
	[DllImport("kernel32.dll")]
	public static extern bool FlushInstructionCache(int int_9, int int_10, int int_11);

	// Token: 0x04001C3D RID: 7229
	[CompilerGenerated]
	private IntPtr intptr_0;

	// Token: 0x04001C3E RID: 7230
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04001C3F RID: 7231
	[CompilerGenerated]
	private int int_1;

	// Token: 0x04001C40 RID: 7232
	public int int_2;

	// Token: 0x04001C41 RID: 7233
	public static int int_3 = 20248;

	// Token: 0x04001C42 RID: 7234
	public static int int_4 = 16384;

	// Token: 0x04001C43 RID: 7235
	public static int int_5 = 32768;

	// Token: 0x04001C44 RID: 7236
	public static int int_6 = 8192;

	// Token: 0x04001C45 RID: 7237
	public static int int_7 = 4096;

	// Token: 0x04001C46 RID: 7238
	public static int int_8 = 4;

	// Token: 0x020002E2 RID: 738
	public enum Enum17
	{
		// Token: 0x04001C48 RID: 7240
		PAGE_NOACCESS = 1,
		// Token: 0x04001C49 RID: 7241
		PAGE_READONLY,
		// Token: 0x04001C4A RID: 7242
		PAGE_READWRITE = 4,
		// Token: 0x04001C4B RID: 7243
		PAGE_WRITECOPY = 8,
		// Token: 0x04001C4C RID: 7244
		PAGE_EXECUTE = 16,
		// Token: 0x04001C4D RID: 7245
		PAGE_EXECUTE_READ = 32,
		// Token: 0x04001C4E RID: 7246
		PAGE_EXECUTE_READWRITE = 64,
		// Token: 0x04001C4F RID: 7247
		PAGE_EXECUTE_WRITECOPY = 128,
		// Token: 0x04001C50 RID: 7248
		PAGE_GUARD = 256,
		// Token: 0x04001C51 RID: 7249
		PAGE_NOCACHE = 512,
		// Token: 0x04001C52 RID: 7250
		PAGE_WRITECOMBINE = 1024
	}
}
