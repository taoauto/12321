﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml;
using _i;

// Token: 0x02000236 RID: 566
internal partial class Main : Form
{
	// Token: 0x06001F65 RID: 8037 RVA: 0x000E3E9C File Offset: 0x000E209C
	protected virtual void WndProc(ref Message m)
	{
		if (m.Msg == Class268.int_17)
		{
			int key = (int)m.WParam;
			int item = (int)m.LParam;
			if (Main.dictionary_3.ContainsKey(key))
			{
				Main.dictionary_3[key].List_26.Add(item);
			}
		}
		if (m.Msg == 786)
		{
			int num = (int)m.LParam >> 16 & 65535;
			int num2 = (int)m.LParam & 65535;
			int num3 = m.WParam.ToInt32();
			if (num3 == 1)
			{
				this.method_0();
			}
			if (num3 == 50)
			{
				Main.bool_22 = (this.menuPausedSkill.Checked = !this.menuPausedSkill.Checked);
				if (Main.bool_22)
				{
					new Loader("Tắt Skill").method_1();
				}
				else
				{
					new Loader("Bật Skill").method_1();
				}
			}
			if (num3 == 2)
			{
				foreach (Class159 @class in this.IEnumerable_5)
				{
					if (@class.Class392_0.UInt32_106 != 1U)
					{
						@class.method_209();
					}
					else if (Class438.GetForegroundWindow() == @class.IntPtr_0)
					{
						this.method_33(@class);
						new Loader(@class.Class432_0.String_2 + ": Refresh").method_1();
					}
				}
			}
			if (num3 == 40)
			{
				this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_0));
				new Loader("Refresh").method_1();
			}
			if (num3 == 37)
			{
				Class268.Boolean_31 = !Class268.Boolean_31;
				if (Class268.Boolean_31)
				{
					new Loader("bật").method_1();
				}
				else
				{
					new Loader("tắt").method_1();
				}
			}
			if (num3 == 3)
			{
				foreach (Class159 class2 in this.IEnumerable_4)
				{
					if (Class438.GetForegroundWindow() == class2.IntPtr_0)
					{
						class2.ListViewItem_0.Checked = !class2.ListViewItem_0.Checked;
						if (class2.ListViewItem_0.Checked)
						{
							new Loader(class2.Class432_0.String_2 + ": bật auto").method_1();
						}
						else
						{
							new Loader(class2.Class432_0.String_2 + ": tắt auto").method_1();
						}
					}
				}
			}
			if (num3 == 4)
			{
				base.Activate();
				Class438.smethod_7(base.Handle);
			}
			if (num3 == 5)
			{
				foreach (Class159 class3 in this.IEnumerable_4)
				{
					if (Class438.GetForegroundWindow() == class3.IntPtr_0)
					{
						class3.method_222();
					}
				}
			}
			if (num3 == 6)
			{
				Class268.bool_80 = (this.menuPickItem.Checked = !this.menuPickItem.Checked);
				if (Class268.bool_80)
				{
					new Loader("MicroAuto - bật nhặt đồ").method_1();
					return;
				}
				new Loader("MicroAuto - tắt nhặt đồ").method_1();
				return;
			}
			else
			{
				if (num3 == 8)
				{
					Class159 class4 = this.Class159_0;
					if (class4 != null && class4.Class432_0.Boolean_34 && class4.Class392_0.UInt32_106 == 2U)
					{
						class4.bool_129 = !class4.bool_129;
						if (class4.bool_129)
						{
							this.method_13(class4.Class432_0.String_2 + " - bật chế đồ");
						}
						else
						{
							this.method_13(class4.Class432_0.String_2 + " - tắt chế đồ");
						}
					}
				}
				if (num3 == 9)
				{
					this.method_106(null, null);
					new Loader("Xuống Ngựa").method_1();
				}
				if (num3 == 12)
				{
					foreach (Class159 class5 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class5.IntPtr_0)
						{
							if (class5.int_49 > 0)
							{
								class5.method_282("PushEvent('TOGLE_BIGBANK'); PushEvent('UPDATE_BANK')", false);
								new Loader(class5.Class432_0.String_2 + " - mở rương").method_1();
								break;
							}
							new Loader(class5.Class432_0.String_2 + " - time an toàn").method_1();
							break;
						}
					}
				}
				if (num3 == 13)
				{
					Class268.bool_76 = (this.menuAtkFollowKey.Checked = !this.menuAtkFollowKey.Checked);
					if (Class268.bool_76)
					{
						new Loader("MicroAuto - bật đánh theo key").method_1();
					}
					else
					{
						new Loader("MicroAuto - tắt đánh theo key").method_1();
					}
				}
				if (num3 == 14)
				{
					foreach (Class159 class6 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class6.IntPtr_0)
						{
							class6.method_80();
							break;
						}
					}
				}
				if (num3 == 15)
				{
					foreach (Class159 class7 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class7.IntPtr_0)
						{
							class7.method_81();
							break;
						}
					}
				}
				if (num3 == 16)
				{
					this.IEnumerable_4.smethod_13(new Action<Class159>(Main.Class270.<>9.method_1));
				}
				if (num3 == 17)
				{
					this.method_52();
				}
				if (num3 == 18)
				{
					foreach (Class159 class8 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class8.IntPtr_0)
						{
							this.method_50(class8);
							break;
						}
					}
				}
				if (num3 == 20)
				{
					foreach (Class159 class9 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class9.IntPtr_0)
						{
							if (class9.List_0.Contains(Enum14.LuyenKim))
							{
								class9.method_51(Enum14.LuyenKim);
								new Loader(class9.Class432_0.String_2 + " - tắt luyện kim").method_1();
								break;
							}
							class9.method_48(Enum14.LuyenKim, true);
							new Loader(class9.Class432_0.String_2 + " - bật luyện kim").method_1();
							break;
						}
					}
				}
				if (num3 == 21)
				{
					foreach (Class159 class10 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class10.IntPtr_0)
						{
							if (class10.List_0.Contains(Enum14.BachHoaDuyen))
							{
								class10.method_51(Enum14.BachHoaDuyen);
								new Loader(class10.Class432_0.String_2 + " - tắt bách hoa duyên").method_1();
								break;
							}
							class10.method_48(Enum14.BachHoaDuyen, true);
							new Loader(class10.Class432_0.String_2 + " - bật bách hoa duyên").method_1();
							break;
						}
					}
				}
				if (num3 == 22)
				{
					foreach (Class159 class11 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class11.IntPtr_0)
						{
							if (class11.List_0.Contains(Enum14.TrungAc))
							{
								class11.method_51(Enum14.TrungAc);
								new Loader(class11.Class432_0.String_2 + " - tắt trừng ác").method_1();
							}
							else
							{
								class11.method_48(Enum14.TrungAc, true);
								new Loader(class11.Class432_0.String_2 + " - bật trừng ác").method_1();
							}
							class11.method_389();
							break;
						}
					}
				}
				if (num3 == 24)
				{
					foreach (Class159 class12 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class12.IntPtr_0)
						{
							if (class12.List_0.Contains(Enum14.NhiemVuSuMon))
							{
								class12.method_51(Enum14.NhiemVuSuMon);
								new Loader(class12.Class432_0.String_2 + " - tắt Q sư môn").method_1();
								break;
							}
							class12.method_48(Enum14.NhiemVuSuMon, true);
							new Loader(class12.Class432_0.String_2 + " - bật Q sư môn").method_1();
							break;
						}
					}
				}
				if (num3 == 25)
				{
					foreach (Class159 class13 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class13.IntPtr_0)
						{
							if (class13.List_0.Contains(Enum14.TuBaoBon))
							{
								class13.method_51(Enum14.TuBaoBon);
								new Loader(class13.Class432_0.String_2 + " - tắt tụ bảo bồn").method_1();
								break;
							}
							class13.method_48(Enum14.TuBaoBon, true);
							new Loader(class13.Class432_0.String_2 + " - bật tụ bảo bồn").method_1();
							break;
						}
					}
				}
				if (num3 == 26)
				{
					this.method_105(null, null);
					new Loader("Lên Ngựa").method_1();
				}
				if (num3 == 27)
				{
					foreach (Class159 class14 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class14.IntPtr_0)
						{
							class14.method_224(true);
							break;
						}
					}
				}
				if (num3 == 28)
				{
					foreach (Class159 class15 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class15.IntPtr_0)
						{
							this.method_8(class15);
						}
					}
				}
				if (num3 == 29)
				{
					foreach (Class159 class16 in this.IEnumerable_5)
					{
						if (Class438.GetForegroundWindow() == class16.IntPtr_0)
						{
							if (class16.List_0.Contains(Enum14.NhiemVuThangCap))
							{
								class16.method_51(Enum14.NhiemVuThangCap);
								new Loader(class16.Class432_0.String_2 + " - tắt nhiệm vụ cơ bản").method_1();
							}
							else
							{
								class16.method_48(Enum14.NhiemVuThangCap, true);
								new Loader(class16.Class432_0.String_2 + " - bật nhiệm vụ cơ bản").method_1();
							}
							class16.method_389();
						}
					}
				}
				if (num3 == 31)
				{
					this.method_77();
					foreach (object obj in this.Lv.Items)
					{
						Class159 class17 = (Class159)((ListViewItem)obj).Tag;
						class17.Boolean_51 = true;
						class17.bool_68 = false;
						class17.bool_69 = false;
						class17.bool_67 = false;
						class17.bool_66 = false;
					}
				}
				if (num3 == 32)
				{
					this.method_78(null, null);
				}
				if (num3 == 33)
				{
					Class159 class18 = this.Class159_0;
					if (class18 != null)
					{
						class18.Boolean_73 = !class18.Boolean_73;
						new Loader(class18.Class432_0.String_2 + " - Tuyên chiến " + (class18.Boolean_73 ? "Bật" : "Tắt")).method_1();
					}
				}
				if (num3 == 34)
				{
					Class159 class19 = this.Class159_0;
					if (class19 != null)
					{
						if (class19.List_0.Contains(Enum14.LongPhuMau))
						{
							class19.method_51(Enum14.LongPhuMau);
							new Loader(class19.Class432_0.String_2 + " - tắt lòng phụ mẫu").method_1();
						}
						else
						{
							class19.method_48(Enum14.LongPhuMau, true);
							new Loader(class19.Class432_0.String_2 + " - bật lòng phụ mẫu").method_1();
						}
					}
				}
				if (num3 == 36 && (this.autoPK_0 == null || this.autoPK_0.IsDisposed))
				{
					this.autoPK_0 = new AutoPK();
					this.autoPK_0.Show();
					Class438.smethod_6(this.autoPK_0);
				}
				if (num3 == 51)
				{
					this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_2));
				}
				if (num3 == 52)
				{
					this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_3));
				}
			}
		}
		base.WndProc(ref m);
	}

	// Token: 0x06001F66 RID: 8038
	[DllImport("user32.dll")]
	private static extern bool RegisterHotKey(IntPtr intptr_0, int int_13, int int_14, int int_15);

	// Token: 0x06001F67 RID: 8039
	[DllImport("user32.dll")]
	private static extern bool UnregisterHotKey(IntPtr intptr_0, int int_13);

	// Token: 0x06001F68 RID: 8040 RVA: 0x000E4C78 File Offset: 0x000E2E78
	private void method_0()
	{
		Class268.bool_91 = !Class268.bool_91;
		if (Class268.bool_91)
		{
			this.menuPause.Checked = true;
			base.Icon = GClass130.Icon_2;
			this.notifyIcon_0.Icon = GClass130.Icon_2;
			foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
			{
				Class159 value = keyValuePair.Value;
				if (value.Class432_0.Boolean_34)
				{
					value.method_239((float)(value.Int32_12 + 1), (float)(value.Int32_13 - 1));
				}
			}
			new Loader("MicroAuto: tạm dừng").method_1();
			return;
		}
		this.menuPause.Checked = false;
		base.Icon = GClass130.Icon_1;
		this.notifyIcon_0.Icon = GClass130.Icon_1;
		new Loader("MicroAuto: tiếp tục").method_1();
	}

	// Token: 0x06001F69 RID: 8041 RVA: 0x000E4D78 File Offset: 0x000E2F78
	private void method_1()
	{
		for (int i = 0; i < 100; i++)
		{
			Main.UnregisterHotKey(base.Handle, i);
		}
	}

	// Token: 0x06001F6A RID: 8042 RVA: 0x000E4DA0 File Offset: 0x000E2FA0
	private void method_2()
	{
		Main.RegisterHotKey(base.Handle, 1, 6, Keys.Z.GetHashCode());
		Main.RegisterHotKey(base.Handle, 1, 0, Keys.Pause.GetHashCode());
		Main.RegisterHotKey(base.Handle, 2, 2, Keys.W.GetHashCode());
		Main.RegisterHotKey(base.Handle, 3, 0, Keys.Insert.GetHashCode());
		Main.RegisterHotKey(base.Handle, 3, 6, Keys.X.GetHashCode());
		Main.RegisterHotKey(base.Handle, 4, 0, Keys.Prior.GetHashCode());
		Main.RegisterHotKey(base.Handle, 5, 0, Keys.Next.GetHashCode());
		Main.RegisterHotKey(base.Handle, 13, 2, Keys.Q.GetHashCode());
		Main.RegisterHotKey(base.Handle, 14, 1, Keys.I.GetHashCode());
		Main.RegisterHotKey(base.Handle, 15, 1, Keys.K.GetHashCode());
		Main.RegisterHotKey(base.Handle, 17, 1, Keys.F3.GetHashCode());
		Main.RegisterHotKey(base.Handle, 18, 2, Keys.End.GetHashCode());
		Main.RegisterHotKey(base.Handle, 28, 1, Keys.F2.GetHashCode());
		Main.RegisterHotKey(base.Handle, 31, 2, Keys.P.GetHashCode());
		Main.RegisterHotKey(base.Handle, 32, 2, Keys.O.GetHashCode());
		Main.RegisterHotKey(base.Handle, 36, 2, Keys.I.GetHashCode());
		Main.RegisterHotKey(base.Handle, 37, 6, Keys.G.GetHashCode());
		Main.RegisterHotKey(base.Handle, 20, 2, Keys.L.GetHashCode());
		Main.RegisterHotKey(base.Handle, 21, 2, Keys.H.GetHashCode());
		Main.RegisterHotKey(base.Handle, 22, 2, Keys.T.GetHashCode());
		Main.RegisterHotKey(base.Handle, 27, 2, Keys.Delete.GetHashCode());
		Main.RegisterHotKey(base.Handle, 29, 2, Keys.Y.GetHashCode());
		Main.RegisterHotKey(base.Handle, 24, 2, Keys.M.GetHashCode());
		Main.RegisterHotKey(base.Handle, 26, 2, Keys.U.GetHashCode());
		Main.RegisterHotKey(base.Handle, 9, 2, Keys.D.GetHashCode());
		Main.RegisterHotKey(base.Handle, 40, 1, Keys.W.GetHashCode());
		Main.RegisterHotKey(base.Handle, 16, 2, Keys.Next.GetHashCode());
		Main.RegisterHotKey(base.Handle, 12, 2, Keys.B.GetHashCode());
		Main.RegisterHotKey(base.Handle, 50, 2, Keys.K.GetHashCode());
		Main.RegisterHotKey(base.Handle, 51, 1, Keys.Z.GetHashCode());
		Main.RegisterHotKey(base.Handle, 52, 1, Keys.G.GetHashCode());
	}

	// Token: 0x06001F6B RID: 8043 RVA: 0x0001705F File Offset: 0x0001525F
	private void method_3(object sender, MouseEventArgs e)
	{
		this.bool_0 = false;
	}

	// Token: 0x06001F6C RID: 8044 RVA: 0x00017068 File Offset: 0x00015268
	private void method_4(object sender, MouseEventArgs e)
	{
		this.point_0 = e.Location;
		this.bool_0 = true;
	}

	// Token: 0x06001F6D RID: 8045 RVA: 0x000E5168 File Offset: 0x000E3368
	private void method_5(object sender, MouseEventArgs e)
	{
		if (this.bool_0)
		{
			Point p = new Point(e.X, e.Y);
			Point point = base.PointToScreen(p);
			Point location = new Point(point.X - this.point_0.X, point.Y - this.point_0.Y);
			base.Location = location;
		}
	}

	// Token: 0x06001F6E RID: 8046 RVA: 0x000E51CC File Offset: 0x000E33CC
	protected virtual void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		if (this.bool_2)
		{
			base.Location = new Point(base.Location.X + this.int_0, base.Location.Y);
			if (base.Location.X < 10 || base.Location.X > 1200)
			{
				this.bool_2 = false;
				this.int_0 = -this.int_0;
				return;
			}
			base.Invalidate();
		}
	}

	// Token: 0x06001F6F RID: 8047 RVA: 0x0001707D File Offset: 0x0001527D
	private void method_6(object sender, EventArgs e)
	{
		this.bool_2 = true;
		base.Invalidate();
	}

	// Token: 0x06001F70 RID: 8048 RVA: 0x000E525C File Offset: 0x000E345C
	public Main()
	{
		try
		{
			this.InitializeComponent();
			Main.Main_0 = this;
			try
			{
				Class412.smethod_3();
			}
			catch
			{
			}
			Control.CheckForIllegalCrossThreadCalls = false;
			this.textBoxComment = new TextBox();
			this.textBoxComment.BorderStyle = BorderStyle.FixedSingle;
			this.textBoxComment.Location = new Point(32, 104);
			this.textBoxComment.Multiline = true;
			this.textBoxComment.Name = "textBoxComment";
			this.textBoxComment.Size = new Size(80, 16);
			this.textBoxComment.TabIndex = 3;
			this.textBoxComment.Text = "";
			this.textBoxComment.Visible = false;
			base.Controls.Add(this.textBoxComment);
			this.Lv.DrawColumnHeader += this.Lv_DrawColumnHeader;
			this.Lv.DrawItem += Main.Class270.<>9.method_4;
			this.Lv.DrawSubItem += Main.Class270.<>9.method_5;
			this.Lv.ColumnClick += this.Lv_ColumnClick;
			base.Icon = GClass130.Icon_1;
			this.notifyIcon_0.Icon = GClass130.Icon_1;
			base.Controls.Add(Main.user_0);
			Main.user_0.Disposed += this.method_14;
			Main.user_0.BringToFront();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + ex.StackTrace);
		}
	}

	// Token: 0x06001F71 RID: 8049 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_7(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x17000737 RID: 1847
	// (get) Token: 0x06001F72 RID: 8050 RVA: 0x0001708C File Offset: 0x0001528C
	// (set) Token: 0x06001F73 RID: 8051 RVA: 0x00017094 File Offset: 0x00015294
	private bool Boolean_0 { get; set; }

	// Token: 0x06001F74 RID: 8052 RVA: 0x000E5534 File Offset: 0x000E3734
	private void method_8(Class159 class159_1)
	{
		Main.Class271 @class = new Main.Class271();
		@class.class159_0 = class159_1;
		if (@class.class159_0 == null)
		{
			return;
		}
		if (@class.class159_0.Class432_0.String_2 == "ĐăngNhập")
		{
			return;
		}
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(@class.method_0));
	}

	// Token: 0x17000738 RID: 1848
	// (get) Token: 0x06001F75 RID: 8053 RVA: 0x0001709D File Offset: 0x0001529D
	// (set) Token: 0x06001F76 RID: 8054 RVA: 0x000170A4 File Offset: 0x000152A4
	private static string String_0 { get; set; }

	// Token: 0x06001F77 RID: 8055 RVA: 0x000170AC File Offset: 0x000152AC
	public void method_9(string string_8, string string_9)
	{
		File.Move(string_8, string_9);
	}

	// Token: 0x17000739 RID: 1849
	// (get) Token: 0x06001F78 RID: 8056 RVA: 0x000170B5 File Offset: 0x000152B5
	// (set) Token: 0x06001F79 RID: 8057 RVA: 0x000170BD File Offset: 0x000152BD
	private Dictionary<string, string> Dictionary_0 { get; set; } = new Dictionary<string, string>();

	// Token: 0x1700073A RID: 1850
	// (get) Token: 0x06001F7A RID: 8058 RVA: 0x000170C6 File Offset: 0x000152C6
	// (set) Token: 0x06001F7B RID: 8059 RVA: 0x000170CE File Offset: 0x000152CE
	private bool Boolean_1 { get; set; }

	// Token: 0x1700073B RID: 1851
	// (get) Token: 0x06001F7C RID: 8060 RVA: 0x000170D7 File Offset: 0x000152D7
	// (set) Token: 0x06001F7D RID: 8061 RVA: 0x000170DF File Offset: 0x000152DF
	public bool Boolean_2 { get; set; }

	// Token: 0x1700073C RID: 1852
	// (get) Token: 0x06001F7E RID: 8062 RVA: 0x000170E8 File Offset: 0x000152E8
	// (set) Token: 0x06001F7F RID: 8063 RVA: 0x000170F0 File Offset: 0x000152F0
	public bool Boolean_3 { get; set; }

	// Token: 0x06001F80 RID: 8064 RVA: 0x00002E18 File Offset: 0x00001018
	public void method_10()
	{
	}

	// Token: 0x1700073D RID: 1853
	// (get) Token: 0x06001F81 RID: 8065 RVA: 0x000170F9 File Offset: 0x000152F9
	// (set) Token: 0x06001F82 RID: 8066 RVA: 0x00017101 File Offset: 0x00015301
	public bool Boolean_4 { get; set; }

	// Token: 0x06001F83 RID: 8067 RVA: 0x0001710A File Offset: 0x0001530A
	public void method_11()
	{
		if (this.Boolean_4)
		{
			return;
		}
		this.Boolean_4 = true;
		for (;;)
		{
			Thread.Sleep(500);
		}
	}

	// Token: 0x06001F84 RID: 8068 RVA: 0x000E5590 File Offset: 0x000E3790
	public void method_12()
	{
		if (this.Boolean_1)
		{
			return;
		}
		this.Boolean_1 = true;
		for (;;)
		{
			try
			{
				if (Setting.smethod_0("checkAnGameTime"))
				{
					Class159 @class = this.IEnumerable_5.OrderByDescending(new Func<Class159, double>(Main.Class270.<>9.method_6)).FirstOrDefault<Class159>();
					if (@class != null && @class.stopwatch_14.Elapsed.TotalMinutes > (double)Setting.smethod_1("numberAnGameTime") && Setting.smethod_1("numberAnGameTime") > 0)
					{
						Class438.smethod_17(@class);
						@class.Boolean_69 = true;
					}
				}
				try
				{
					Main.Class272 class2 = new Main.Class272();
					class2.main_0 = this;
					IntPtr intPtr = Class438.FindWindow("#32770", "Microsoft Visual C++ Runtime Library");
					if (intPtr != IntPtr.Zero)
					{
						Class438.smethod_12(intPtr);
					}
					intPtr = Class438.FindWindow("#32770", "TTL3D");
					if (intPtr != IntPtr.Zero)
					{
						Class438.smethod_12(intPtr);
					}
					using (List<KeyValuePair<int, Class159>>.Enumerator enumerator = Main.dictionary_3.Where(new Func<KeyValuePair<int, Class159>, bool>(Main.Class270.<>9.method_7)).ToList<KeyValuePair<int, Class159>>().GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							Main.Class273 class3 = new Main.Class273();
							class3.class272_0 = class2;
							class3.keyValuePair_0 = enumerator.Current;
							try
							{
								class3.keyValuePair_0.Value.method_389();
								goto IL_184;
							}
							catch
							{
								goto IL_184;
							}
							goto IL_152;
							IL_158:
							Main.dictionary_3.Remove(class3.keyValuePair_0.Key);
							this.smethod_20(new Action(class3.method_0));
							continue;
							IL_152:
							Main.class159_0 = null;
							goto IL_158;
							IL_184:
							if (Main.class159_0 == class3.keyValuePair_0.Value)
							{
								goto IL_152;
							}
							goto IL_158;
						}
					}
					class2.int_0 = Process.GetCurrentProcess().SessionId;
					IEnumerable<Process> processesByName = Process.GetProcessesByName("Game");
					Func<Process, bool> predicate;
					if ((predicate = class2.func_0) == null)
					{
						predicate = (class2.func_0 = new Func<Process, bool>(class2.method_0));
					}
					foreach (Process process in processesByName.Where(predicate))
					{
						string text = "";
						Stopwatch.StartNew();
						try
						{
							if (!this.bool_5)
							{
								string fileName = process.MainModule.FileName;
								Class268.String_1 = fileName.Substring(0, fileName.Length - 8);
								try
								{
									File.Delete(Class268.String_1 + "/WebClient/webclient.exe");
								}
								catch
								{
								}
								try
								{
									File.Delete(Class268.String_1 + "/CrashReport.exe");
								}
								catch
								{
								}
								this.bool_5 = true;
							}
						}
						catch
						{
						}
						try
						{
							if (Class438.smethod_4(process.Id, "TianLongBaBu WndClass") == IntPtr.Zero && Class438.smethod_4(process.Id, "knqtiabnclpogbh") == IntPtr.Zero && Class438.smethod_4(process.Id, "#32770") == IntPtr.Zero)
							{
								continue;
							}
						}
						catch
						{
							continue;
						}
						bool flag = false;
						if (this.dictionary_0.ContainsKey(process.Id))
						{
							foreach (KeyValuePair<int, Stopwatch> keyValuePair in this.dictionary_0)
							{
								if (keyValuePair.Key == process.Id && keyValuePair.Value.Elapsed.TotalSeconds > 240.0)
								{
									flag = true;
									try
									{
										Process.GetProcessById(process.Id).Kill();
									}
									catch
									{
									}
								}
							}
						}
						if (!flag)
						{
							try
							{
								Main.Class274 class4 = new Main.Class274();
								class4.class272_0 = class2;
								Class268.UInt32_0 = (uint)Class405.smethod_4(process.Id);
								int num = Class405.smethod_5("A1 ???????? 3BC1 56 57 0F85 ???????? 8B4D", -1, -1, 0, process.Id);
								num = Class405.smethod_15(num + 1, process.Id);
								Class392 class392_;
								if (!Class268.UInt32_0.ToString("X8").Contains("00400000"))
								{
									class392_ = Class392.smethod_1(num.ToString("X7"), Class268.string_1, Class268.UInt32_0);
								}
								else
								{
									class392_ = Class392.smethod_1(num.ToString("X7"), Class268.string_1, 0U);
								}
								class4.class159_0 = new Class159(process, class392_);
								class4.class159_0.String_3 = text;
								class4.class159_0.UInt32_3 = Class268.UInt32_0;
								Main.dictionary_3.Add(process.Id, class4.class159_0);
								class4.class159_0.Event_0 += this.method_22;
								this.smethod_20(new Action(class4.method_0));
							}
							catch
							{
								if (!this.dictionary_0.ContainsKey(process.Id))
								{
									this.dictionary_0.Add(process.Id, Stopwatch.StartNew());
								}
							}
						}
					}
				}
				catch
				{
				}
			}
			catch
			{
			}
			Thread.Sleep(2000);
		}
	}

	// Token: 0x1700073E RID: 1854
	// (get) Token: 0x06001F85 RID: 8069 RVA: 0x000E5BB0 File Offset: 0x000E3DB0
	public Class159 Class159_0
	{
		get
		{
			foreach (Class159 @class in this.IEnumerable_5)
			{
				if (Class438.GetForegroundWindow() == @class.IntPtr_0)
				{
					return @class;
				}
			}
			return null;
		}
	}

	// Token: 0x06001F86 RID: 8070 RVA: 0x00017127 File Offset: 0x00015327
	private void method_13(string string_8)
	{
		new Loader(string_8).method_1();
	}

	// Token: 0x06001F87 RID: 8071 RVA: 0x000E5C10 File Offset: 0x000E3E10
	private void method_14(object sender, EventArgs e)
	{
		this.method_42();
		foreach (object obj in this.menuIcon.Items)
		{
			((ToolStripItem)obj).Visible = true;
		}
		Task.Run(new Action(Main.Class270.<>9.method_8));
		try
		{
			try
			{
				this.ricExit.Text = Class159.Class220_0.method_0("Log", "Exit");
				this.ricXong.Text = Class159.Class220_0.method_0("Log", "Xong");
				this.ricMaTac.Text = Class159.Class220_0.method_0("Log", "MaTac");
				this.ricAcBa.Text = Class159.Class220_0.method_0("Log", "AcBa");
				this.ricExit.smethod_7();
				this.ricXong.smethod_7();
				this.ricMaTac.smethod_7();
				this.ricAcBa.smethod_7();
				this.method_29();
			}
			catch
			{
			}
			this.mainMenu.Visible = true;
			if (Main.user_0.Boolean_0)
			{
				try
				{
					this.method_39();
				}
				catch (Exception ex)
				{
					Main.smethod_1(ex.Message);
				}
				this.method_158();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001F88 RID: 8072 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_15(object sender, WebBrowserDocumentCompletedEventArgs e)
	{
	}

	// Token: 0x06001F89 RID: 8073 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_16(object sender, HtmlElementEventArgs e)
	{
	}

	// Token: 0x06001F8A RID: 8074 RVA: 0x00017134 File Offset: 0x00015334
	private void method_17()
	{
		new Thread(new ThreadStart(this.method_18))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06001F8B RID: 8075 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_18()
	{
	}

	// Token: 0x1700073F RID: 1855
	// (get) Token: 0x06001F8C RID: 8076 RVA: 0x00017153 File Offset: 0x00015353
	// (set) Token: 0x06001F8D RID: 8077 RVA: 0x0001715A File Offset: 0x0001535A
	public static string String_1 { get; set; } = string.Empty;

	// Token: 0x06001F8E RID: 8078 RVA: 0x00017162 File Offset: 0x00015362
	private void method_19(object sender, EventArgs e)
	{
		Class426.smethod_43((sender as Class412).String_2);
	}

	// Token: 0x17000740 RID: 1856
	// (get) Token: 0x06001F8F RID: 8079 RVA: 0x00017175 File Offset: 0x00015375
	public static int Int32_0
	{
		get
		{
			return Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().Where(new Func<KeyValuePair<int, Class159>, bool>(Main.Class270.<>9.method_9)).ToList<KeyValuePair<int, Class159>>().Count;
		}
	}

	// Token: 0x06001F90 RID: 8080 RVA: 0x000E5DAC File Offset: 0x000E3FAC
	private void method_20(Class159 class159_1)
	{
		Main.Class275 @class = new Main.Class275();
		@class.class159_0 = class159_1;
		try
		{
			base.Invoke(new Action(@class.method_0));
		}
		catch
		{
		}
		if (Main.class159_0 == @class.class159_0)
		{
			this.method_30();
		}
	}

	// Token: 0x06001F91 RID: 8081 RVA: 0x000171AF File Offset: 0x000153AF
	private void method_21(Class159 class159_1)
	{
		class159_1.ListViewItem_0.Checked = class159_1.Boolean_3;
	}

	// Token: 0x06001F92 RID: 8082 RVA: 0x000171C2 File Offset: 0x000153C2
	private void method_22(object sender, EventArgs e)
	{
		base.Invoke(new Main.Delegate1(this.method_20), new object[]
		{
			sender as Class159
		});
	}

	// Token: 0x06001F93 RID: 8083 RVA: 0x000171E6 File Offset: 0x000153E6
	private void method_23(object sender, EventArgs e)
	{
		base.Invoke(new Main.Delegate1(this.method_21), new object[]
		{
			sender as Class159
		});
	}

	// Token: 0x06001F94 RID: 8084 RVA: 0x000E5E04 File Offset: 0x000E4004
	private void method_24()
	{
		string text = Class415.smethod_2("User", "HWID");
		if (text.Length == 32 && text != Class403.String_1)
		{
			Class159.Class220_0.method_3("nier.ini");
			Environment.Exit(0);
		}
	}

	// Token: 0x17000741 RID: 1857
	// (get) Token: 0x06001F95 RID: 8085 RVA: 0x0001720A File Offset: 0x0001540A
	// (set) Token: 0x06001F96 RID: 8086 RVA: 0x00017212 File Offset: 0x00015412
	private bool Boolean_5 { get; set; }

	// Token: 0x06001F97 RID: 8087 RVA: 0x000E5E50 File Offset: 0x000E4050
	private string method_25(string string_8)
	{
		if (string_8 != "")
		{
			Match match = Regex.Match(string_8, "://(.+?)/");
			if (match != null)
			{
				return match.ToString().Replace("://", "").Replace("/", "");
			}
		}
		return "";
	}

	// Token: 0x06001F98 RID: 8088 RVA: 0x000E5EA4 File Offset: 0x000E40A4
	private Assembly method_26(object object_0, ResolveEventArgs resolveEventArgs_0)
	{
		Assembly result;
		this.idictionary_0.TryGetValue(resolveEventArgs_0.Name.Split(new char[]
		{
			','
		})[0], out result);
		this.ricExit.Text = resolveEventArgs_0.Name;
		return result;
	}

	// Token: 0x06001F99 RID: 8089 RVA: 0x000E5EEC File Offset: 0x000E40EC
	private void Main_Load(object sender, EventArgs e)
	{
		Control.CheckForIllegalCrossThreadCalls = false;
		this.tabSetting.Controls.Add(Main.setting_0);
		using (IEnumerator enumerator = this.Lv.Columns.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Main.Class276 @class = new Main.Class276();
				@class.main_0 = this;
				@class.columnHeader_0 = (ColumnHeader)enumerator.Current;
				@class.toolStripMenuItem_0 = new ToolStripMenuItem(@class.columnHeader_0.Text.ToString());
				this.menuListView.Items.Add(@class.toolStripMenuItem_0);
				@class.toolStripMenuItem_0.Tag = @class.columnHeader_0;
				@class.toolStripMenuItem_0.Click += @class.method_0;
			}
		}
		foreach (string text in Class159.Class220_0.method_0("Config", "HideCol").Split(new char[]
		{
			','
		}))
		{
			if (text.Length > 0)
			{
				foreach (object obj in this.Lv.Columns)
				{
					ColumnHeader columnHeader = (ColumnHeader)obj;
					if (columnHeader.Index == text.smethod_18())
					{
						columnHeader.Tag = columnHeader.Width;
						columnHeader.Width = 0;
						this.list_6.Add(columnHeader.Index);
					}
				}
			}
		}
		Control.CheckForIllegalCrossThreadCalls = false;
		this.mainMenu.Visible = false;
		this.control_0 = new Control[]
		{
			this.dateTimePicker_0,
			this.comboBox_0,
			this.textBoxComment,
			this.textBox_0,
			this.numericUpDown_0
		};
		this.lvConfig.SubItemClicked += this.lvConfig_SubItemClicked;
		this.lvConfig.Scroll += this.lvConfig_Scroll;
		this.lvConfig.SubItemEndEditing += this.lvConfig_SubItemEndEditing;
		this.lvConfig.AllowReorder = false;
		this.lvConfig.AllowDrop = false;
		this.backgroundWorker_1.RunWorkerAsync();
		this.Text = Class268.String_0;
		this.method_151(null, null);
		string text2 = Class415.String_6;
		try
		{
			bool flag = true;
			do
			{
				flag = false;
				foreach (object obj2 in this.toolStripMenuItem_0.DropDownItems)
				{
					ToolStripItem toolStripItem = (ToolStripItem)obj2;
					if (toolStripItem.Tag != null && !string.IsNullOrEmpty(toolStripItem.Tag.ToString().Trim()))
					{
						toolStripItem.Dispose();
						flag = true;
						break;
					}
				}
			}
			while (flag);
			List<ToolStripMenuItem> list = new List<ToolStripMenuItem>();
			string[] array = Class159.Class220_0.method_0("Item", "DiChuyen").Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text3 = array[i].Trim();
				if (text3.Split(new char[]
				{
					'|'
				}).Length == 3)
				{
					string tag = text3.Split(new char[]
					{
						'|'
					})[0];
					string text4 = text3.Split(new char[]
					{
						'|'
					})[2];
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem();
					toolStripMenuItem.Text = text4;
					toolStripMenuItem.Tag = tag;
					toolStripMenuItem.Click += this.method_102;
					list.Add(toolStripMenuItem);
				}
			}
			if (list.Count > 0)
			{
				this.toolStripMenuItem_0.DropDownItems.Add(new ToolStripSeparator
				{
					Tag = "user"
				});
			}
			ToolStripItemCollection dropDownItems = this.toolStripMenuItem_0.DropDownItems;
			ToolStripItem[] toolStripItems = list.ToArray();
			dropDownItems.AddRange(toolStripItems);
		}
		catch
		{
		}
		foreach (string text5 in Class159.Class220_0.method_0("Logs", "CaptchaHash").Split(new char[]
		{
			'\n'
		}))
		{
			if (!(text5.Trim() == string.Empty))
			{
				Class159.list_1.Add(text5.Trim());
			}
		}
		try
		{
			Main.class330_0 = new Class330
			{
				dateTime_0 = DateTime.Now
			};
			try
			{
				CalendarEx.smethod_0();
			}
			catch
			{
			}
			AlarmEx.AlarmEx_0.Show();
			AlarmEx.AlarmEx_0.Hide();
			TalkChannel.smethod_0();
			try
			{
				int i = Environment.OSVersion.Version.Major;
				string str = i.ToString();
				string str2 = ".";
				i = Environment.OSVersion.Version.Minor;
				str + str2 + i.ToString();
				Main.delegate5_0 = (Main.Delegate5)Class0.smethod_0<Main.Delegate5>(Environment.SystemDirectory + "\\user32.dll", "ChangeWindowMessageFilter");
				Main.delegate5_0(74U, 1);
			}
			catch
			{
			}
			Alan.Alan_0.Controls.Clear();
			Class412 class2 = new Class412();
			class2.string_1 = "http://www.tieudattai.org/remlaw/user.php";
			class2.String_0 = "cmd=time";
			class2.Event_0 += this.method_27;
			class2.Boolean_1 = true;
			class2.control_0 = this;
			class2.Boolean_1 = true;
			class2.method_0();
			if (this.Boolean_5)
			{
				base.Dispose();
				return;
			}
			this.notifyIcon_0.Visible = true;
			Class159.Boolean_0 = true;
			Class159.Boolean_1 = true;
			new Thread(new ThreadStart(this.method_24))
			{
				IsBackground = true
			}.Start();
			if (Class159.Class220_0.method_0("Item", "Publishers") == string.Empty || !Class159.Class220_0.method_0("Item", "Publishers").Contains("40") || Class159.Class220_0.method_0("Item", "Publishers").Contains("Huyền Vũ"))
			{
				Class159.Class220_0.method_1("Item", "Publishers", GClass130.String_7);
			}
			MicroLogin.smethod_0();
			Publisher.smethod_0();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message + ex.StackTrace);
		}
		this.method_32();
	}

	// Token: 0x06001F9A RID: 8090 RVA: 0x0001721B File Offset: 0x0001541B
	private void method_27(object sender, EventArgs e)
	{
		Class268.dateTime_0 = DateTime.ParseExact((sender as Class412).String_2, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
	}

	// Token: 0x06001F9B RID: 8091
	[DllImport("tieudattai.dll")]
	public static extern int GetMSG();

	// Token: 0x06001F9C RID: 8092 RVA: 0x000E65D4 File Offset: 0x000E47D4
	private void checkBanKinh_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_7)
		{
			return;
		}
		Control control = (Control)sender;
		foreach (Class159 @class in this.IEnumerable_3)
		{
			if (control == this.checkChetLenBai)
			{
				@class.Boolean_79 = this.checkChetLenBai.Checked;
			}
			if (control == this.checkChiNhat)
			{
				@class.Boolean_30 = this.checkChiNhat.Checked;
			}
			if (control == this.checkBanKinh)
			{
				if (this.checkBanKinh.Checked)
				{
					@class.Single_1 = (float)@class.Int32_12;
					@class.Single_2 = (float)@class.Int32_13;
					@class.UInt32_6 = @class.Class432_0.UInt32_29;
				}
				else
				{
					@class.Single_1 = (@class.Single_2 = 0f);
				}
			}
			if (control == this.checkQuyCoc)
			{
				@class.bool_23 = this.checkQuyCoc.Checked;
			}
			if (control == this.checkChiDanh)
			{
				@class.Boolean_72 = this.checkChiDanh.Checked;
			}
			if (control == this.checkTimQuai)
			{
				@class.bool_17 = this.checkTimQuai.Checked;
			}
			if (control == this.checkLuaQuai)
			{
				@class.Boolean_17 = this.checkLuaQuai.Checked;
			}
			if (control == this.checkPet)
			{
				@class.bool_19 = this.checkPet.Checked;
			}
			if (control == this.checkHP)
			{
				@class.bool_20 = this.checkHP.Checked;
			}
			if (control == this.checkMP)
			{
				@class.bool_21 = this.checkMP.Checked;
			}
			if (control == this.checkNM)
			{
				@class.bool_22 = this.checkNM.Checked;
			}
			if (control == this.checkKhaiKhoang)
			{
				@class.method_48(Enum14.KhaiKhoang, this.checkKhaiKhoang.Checked);
			}
			if (control == this.checkHaiDuoc)
			{
				@class.method_48(Enum14.HaiDuoc, this.checkHaiDuoc.Checked);
			}
			if (control == this.checkTrongTrot)
			{
				@class.method_48(Enum14.TrongTrot, this.checkTrongTrot.Checked);
			}
			if (control == this.checkThuHoach)
			{
				@class.Boolean_7 = this.checkThuHoach.Checked;
			}
			if (control == this.chkRaoVat)
			{
				@class.bool_24 = this.chkRaoVat.Checked;
			}
		}
	}

	// Token: 0x06001F9D RID: 8093 RVA: 0x000E6820 File Offset: 0x000E4A20
	private void Lv_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.btnCanQuetThuCong.Text = "Càn Quét [##:##]";
		Class159 @class = this.IEnumerable_2.FirstOrDefault<Class159>();
		if (@class != null && Class159.Dictionary_1.ContainsKey(@class.Class432_0.String_2))
		{
			FastTask fastTask = Class159.Dictionary_1[@class.Class432_0.String_2];
			this.btnCanQuetThuCong.Text = string.Concat(new string[]
			{
				"Càn Quét [",
				(fastTask.Int32_0 / 60).ToString(),
				":",
				(fastTask.Int32_0 % 60).ToString(),
				"]"
			});
		}
		if (this.Lv.SelectedItems.Count > 0)
		{
			Main.class159_0 = (Class159)this.Lv.SelectedItems[0].Tag;
			this.txtRao.Text = Main.class159_0.String_8;
			this.method_30();
		}
		this.tabBottom.TabPages[0].Text = Main.class159_0.Class432_0.String_2;
		this.lbExpSpeed.Text = Main.class159_0.String_15;
		this.lblTimeInfo.Text = Main.class159_0.String_16;
		this.lbHoaSpeed.Text = Main.class159_0.String_10;
		this.lbAcBa.Text = Class432.smethod_5(Main.class159_0.Int32_40);
		if (this.lbAcBa.Text.Contains("Không"))
		{
			this.lbAcBa.Text = "LGBT";
		}
		this.lblTrain.Text = (Main.class159_0.String_26 ?? "");
		this.gameInfo.Single_0 = Main.class159_0.Class432_0.UInt32_5 / (Main.class159_0.Class432_0.UInt32_8 + 1U);
		this.gameInfo.Single_1 = Main.class159_0.Class432_0.UInt32_6 / (Main.class159_0.Class432_0.UInt32_9 + 1U);
		this.gameInfo.Single_2 = Main.class159_0.Class432_0.UInt32_11 / (Main.class159_0.Class432_0.UInt32_12 + 1U);
		this.gameInfo.Single_3 = (float)((int)((ulong)(Main.class159_0.Class432_0.UInt32_7 * 100U) / (ulong)((long)Main.class159_0.Class432_0.Int32_2)));
		this.gameInfo.String_0 = string.Concat(new string[]
		{
			Main.class159_0.Class432_0.string_7,
			" [",
			Main.class159_0.Int32_12.ToString(),
			" ",
			Main.class159_0.Int32_13.ToString(),
			"]"
		});
	}

	// Token: 0x17000742 RID: 1858
	// (get) Token: 0x06001F9E RID: 8094 RVA: 0x000E6B10 File Offset: 0x000E4D10
	public IEnumerable<string> IEnumerable_0
	{
		get
		{
			return Main.dictionary_3.Select(new Func<KeyValuePair<int, Class159>, Class159>(Main.Class270.<>9.method_10)).Where(new Func<Class159, bool>(Main.Class270.<>9.method_11)).Select(new Func<Class159, string>(Main.Class270.<>9.method_12));
		}
	}

	// Token: 0x06001F9F RID: 8095 RVA: 0x000E6B90 File Offset: 0x000E4D90
	public void method_28()
	{
		Class159.Class220_0.method_1("Config", "HideCol", string.Join(",", this.list_6.Where(new Func<int, bool>(this.method_182)).Select(new Func<int, string>(Main.Class270.<>9.method_13)).ToArray<string>()));
		Class159.Class220_0.method_1("Log", "Exit", string.Join("\r\n", this.ricExit.Lines.Reverse<string>().Take(1000).Reverse<string>().ToArray<string>()));
		Class159.Class220_0.method_1("Log", "Xong", string.Join("\r\n", this.ricXong.Lines.Reverse<string>().Take(1000).Reverse<string>().ToArray<string>()));
		Class159.Class220_0.method_1("Log", "AcBa", string.Join("\r\n", this.ricAcBa.Lines.Reverse<string>().Take(1000).Reverse<string>().ToArray<string>()));
		Class159.Class220_0.method_1("Log", "MaTac", string.Join("\r\n", this.ricMaTac.Lines.Reverse<string>().Take(1000).Reverse<string>().ToArray<string>()));
		Class159.Class220_0.method_2("Team");
		foreach (KeyValuePair<string, List<string>> keyValuePair in Setting.Dictionary_0)
		{
			Class159.Class220_0.method_1("Team", keyValuePair.Key, string.Join(",", keyValuePair.Value.ToArray()));
		}
		Main.setting_0.method_1();
		foreach (ToolStripMenuItem toolStripMenuItem in this.menuNier.smethod_33())
		{
			try
			{
				Class159.Class220_0.method_1("SettingValue", toolStripMenuItem.GetHashCode().ToString(), toolStripMenuItem.Checked.ToString());
			}
			catch
			{
			}
		}
	}

	// Token: 0x06001FA0 RID: 8096 RVA: 0x000E6E00 File Offset: 0x000E5000
	private void method_29()
	{
		Main.setting_0.method_0();
		foreach (ToolStripMenuItem toolStripMenuItem in this.menuNier.smethod_33())
		{
			try
			{
				string a = Class159.Class220_0.method_0("SettingValue", toolStripMenuItem.GetHashCode().ToString());
				toolStripMenuItem.Checked = (a == "True");
			}
			catch
			{
			}
		}
		try
		{
			foreach (Class219 @class in Class159.Class220_0["Team"])
			{
				Setting.Dictionary_0[@class.String_0] = @class.String_1.Split(new char[]
				{
					','
				}).ToList<string>();
			}
		}
		catch
		{
		}
		this.method_2();
		Class415.smethod_0();
	}

	// Token: 0x06001FA1 RID: 8097 RVA: 0x0001723C File Offset: 0x0001543C
	private void method_30()
	{
		this.timer_5.Stop();
		this.Boolean_7 = true;
		this.timer_5.Start();
	}

	// Token: 0x17000743 RID: 1859
	// (get) Token: 0x06001FA2 RID: 8098 RVA: 0x0001725B File Offset: 0x0001545B
	// (set) Token: 0x06001FA3 RID: 8099 RVA: 0x00017262 File Offset: 0x00015462
	public static Main Main_0 { get; set; }

	// Token: 0x06001FA4 RID: 8100 RVA: 0x000E6F28 File Offset: 0x000E5128
	public static void smethod_0(object object_0)
	{
		Main.Class277 @class = new Main.Class277();
		@class.object_0 = object_0;
		Main.Main_0.Invoke(new Action(@class.method_0));
	}

	// Token: 0x06001FA5 RID: 8101 RVA: 0x00002E18 File Offset: 0x00001018
	public static void smethod_1(object object_0)
	{
	}

	// Token: 0x17000744 RID: 1860
	// (get) Token: 0x06001FA6 RID: 8102 RVA: 0x0001726A File Offset: 0x0001546A
	// (set) Token: 0x06001FA7 RID: 8103 RVA: 0x00017272 File Offset: 0x00015472
	public bool Boolean_6 { get; set; }

	// Token: 0x17000745 RID: 1861
	// (get) Token: 0x06001FA8 RID: 8104 RVA: 0x0001727B File Offset: 0x0001547B
	// (set) Token: 0x06001FA9 RID: 8105 RVA: 0x00017283 File Offset: 0x00015483
	public bool Boolean_7 { get; set; }

	// Token: 0x06001FAA RID: 8106 RVA: 0x0001728C File Offset: 0x0001548C
	private void method_31(object sender, EventArgs e)
	{
		if (this.Lv.SelectedItems.Count == 0)
		{
			return;
		}
		((Class159)this.Lv.SelectedItems[0].Tag).method_223();
	}

	// Token: 0x06001FAB RID: 8107 RVA: 0x000172C1 File Offset: 0x000154C1
	private void menuDebug_Click(object sender, EventArgs e)
	{
		new DebugEx
		{
			TopMost = true,
			Class159_0 = Main.class159_0
		}.Show();
	}

	// Token: 0x06001FAC RID: 8108
	[DllImport("kernel32.dll")]
	private static extern bool SetProcessAffinityMask(IntPtr intptr_0, UIntPtr uintptr_0);

	// Token: 0x06001FAD RID: 8109 RVA: 0x000E6F5C File Offset: 0x000E515C
	private void Main_Resize(object sender, EventArgs e)
	{
		if (base.WindowState == FormWindowState.Maximized)
		{
			base.WindowState = FormWindowState.Normal;
			this.panBottom.Visible = !this.panBottom.Visible;
		}
		else if (base.WindowState == FormWindowState.Minimized)
		{
			this.bool_1 = true;
		}
		else if (base.WindowState == FormWindowState.Normal && this.bool_1)
		{
			this.bool_1 = false;
			this.Refresh();
		}
		this.method_32();
	}

	// Token: 0x06001FAE RID: 8110 RVA: 0x000E6FCC File Offset: 0x000E51CC
	private void method_32()
	{
		int num = 0;
		for (;;)
		{
			IEnumerable<ColumnHeader> source = this.Lv.Columns.Cast<ColumnHeader>();
			Func<ColumnHeader, int> selector;
			if ((selector = Main.Class270.<>9__149_0) == null)
			{
				goto IL_CD;
			}
			IL_1D:
			if (source.Sum(selector) + 60 < base.Width)
			{
				break;
			}
			using (IEnumerator<ColumnHeader> enumerator = this.Lv.Columns.Cast<ColumnHeader>().OrderByDescending(new Func<ColumnHeader, int>(Main.Class270.<>9.method_14)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ColumnHeader columnHeader = enumerator.Current;
					if (columnHeader.Width > 0)
					{
						this.list_1.Add(columnHeader.Index);
						columnHeader.Tag = columnHeader.Width;
						columnHeader.Width = 0;
						this.list_6.Add(columnHeader.Index);
						break;
					}
				}
				goto IL_E9;
			}
			goto IL_CD;
			IL_E9:
			if (num++ > this.Lv.Columns.Count)
			{
				break;
			}
			continue;
			IL_CD:
			selector = (Main.Class270.<>9__149_0 = new Func<ColumnHeader, int>(Main.Class270.<>9.method_15));
			goto IL_1D;
		}
		num = 0;
		for (;;)
		{
			IEnumerable<ColumnHeader> source2 = this.Lv.Columns.Cast<ColumnHeader>();
			Func<ColumnHeader, int> selector2;
			if ((selector2 = Main.Class270.<>9__149_1) == null)
			{
				goto IL_295;
			}
			IL_120:
			if (source2.Sum(selector2) + 60 >= base.Width)
			{
				break;
			}
			using (IEnumerator<ColumnHeader> enumerator = this.Lv.Columns.Cast<ColumnHeader>().OrderBy(new Func<ColumnHeader, int>(Main.Class270.<>9.method_16)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ColumnHeader columnHeader2 = enumerator.Current;
					if (this.list_1.Contains(columnHeader2.Index))
					{
						if (this.Lv.Columns.Cast<ColumnHeader>().Sum(new Func<ColumnHeader, int>(Main.Class270.<>9.method_17)) + 60 >= base.Width)
						{
							break;
						}
						if (columnHeader2.Width == 0 && columnHeader2.Tag != null)
						{
							if (this.Lv.Columns.Cast<ColumnHeader>().Sum(new Func<ColumnHeader, int>(Main.Class270.<>9.method_18)) + 60 + columnHeader2.Tag.ToString().smethod_18() < base.Width)
							{
								this.list_6.Remove(columnHeader2.Index);
								this.list_1.Remove(columnHeader2.Index);
								columnHeader2.Width = columnHeader2.Tag.ToString().smethod_18();
								columnHeader2.Tag = columnHeader2.Width;
								break;
							}
						}
					}
				}
				goto IL_2B1;
			}
			goto IL_295;
			IL_2B1:
			if (num++ > this.Lv.Columns.Count)
			{
				break;
			}
			continue;
			IL_295:
			selector2 = (Main.Class270.<>9__149_1 = new Func<ColumnHeader, int>(Main.Class270.<>9.method_19));
			goto IL_120;
		}
	}

	// Token: 0x06001FAF RID: 8111 RVA: 0x000172DF File Offset: 0x000154DF
	public void method_33(Class159 class159_1)
	{
		class159_1.method_86();
	}

	// Token: 0x06001FB0 RID: 8112 RVA: 0x000172E7 File Offset: 0x000154E7
	private void menuHideGame_Click(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_35))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06001FB1 RID: 8113 RVA: 0x00017306 File Offset: 0x00015506
	private void menuShowGame_Click(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_34))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x06001FB2 RID: 8114 RVA: 0x000E72D8 File Offset: 0x000E54D8
	public void method_34()
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_223();
			Thread.Sleep(500);
		}
	}

	// Token: 0x06001FB3 RID: 8115 RVA: 0x000E7330 File Offset: 0x000E5530
	public void method_35()
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			if (Class438.smethod_8(@class.IntPtr_0))
			{
				@class.method_222();
			}
		}
	}

	// Token: 0x06001FB4 RID: 8116 RVA: 0x000E738C File Offset: 0x000E558C
	public void method_36()
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			if (Class438.smethod_8(@class.IntPtr_0))
			{
				@class.method_223();
				Thread.Sleep(500);
			}
		}
	}

	// Token: 0x06001FB5 RID: 8117 RVA: 0x000E73F0 File Offset: 0x000E55F0
	public void method_37()
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			@class.method_222();
		}
	}

	// Token: 0x06001FB6 RID: 8118 RVA: 0x000E743C File Offset: 0x000E563C
	private void menuExitGame_Click(object sender, EventArgs e)
	{
		if (this.Lv.Items.Count == 0)
		{
			return;
		}
		string text = "Bạn có muốn thoát những game đã chọn?";
		if (this.Lv.SelectedItems.Count == 0)
		{
			text = "Bạn có muốn thoát toàn bộ game?";
		}
		if (MessageBox.Show(this, text, "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.No)
		{
			return;
		}
		try
		{
			foreach (Class159 @class in this.IEnumerable_1)
			{
				@class.method_224(false);
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001FB7 RID: 8119 RVA: 0x000E74DC File Offset: 0x000E56DC
	private void method_38(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_4)
		{
			@class.method_392(true);
		}
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_20));
	}

	// Token: 0x17000746 RID: 1862
	// (get) Token: 0x06001FB8 RID: 8120 RVA: 0x00017325 File Offset: 0x00015525
	// (set) Token: 0x06001FB9 RID: 8121 RVA: 0x0001732C File Offset: 0x0001552C
	public static bool Boolean_8 { get; set; }

	// Token: 0x06001FBA RID: 8122 RVA: 0x000E7558 File Offset: 0x000E5758
	public void menuExit_Click(object sender, EventArgs e)
	{
		Application.Exit();
		Main.bool_15 = false;
		Task.Run(new Action(Main.Class270.<>9.method_21));
		if (!Main.user_0.IsDisposed)
		{
			base.Dispose();
			return;
		}
		new Loader(0, "Đang lưu thiết lập").method_1();
		Main.Boolean_8 = true;
		Task.Run(new Action(this.method_183));
	}

	// Token: 0x06001FBB RID: 8123 RVA: 0x00002E18 File Offset: 0x00001018
	public static void smethod_2(Form form_0)
	{
	}

	// Token: 0x06001FBC RID: 8124 RVA: 0x000E75D0 File Offset: 0x000E57D0
	private void method_39()
	{
		this.panInbox.Controls.Add(new ChatLogs
		{
			Dock = DockStyle.Fill
		});
		if (Main.microLogin_0 == null || Main.microLogin_0.IsDisposed)
		{
			Main.microLogin_0 = new MicroLogin
			{
				Dock = DockStyle.Fill
			};
			this.tabLogin.Controls.Add(new MicroLogin
			{
				Dock = DockStyle.Fill
			});
		}
		try
		{
			MicroLogin.List_0 = Class145.List_0;
		}
		catch
		{
			MicroLogin.List_0 = new List<Class145>();
		}
		Class268.int_17 = Class438.RegisterWindowMessage("WM_SIMPLE_HOOK_WRITE");
		ToolStripItem toolStripItem = this.menuPickItem;
		this.menuItemFillter.Enabled = true;
		toolStripItem.Enabled = true;
		ToolStripItem toolStripItem2 = this.menuFollowKey;
		this.menuAtkFollowKey.Enabled = true;
		toolStripItem2.Enabled = true;
		this.timer_0.Start();
		this.timer_4.Start();
		Class412.int_3 = 0;
		this.thread_0 = new Thread(new ThreadStart(this.method_12))
		{
			IsBackground = true
		};
		new Thread(new ThreadStart(this.method_10))
		{
			IsBackground = true
		}.Start();
		this.thread_0.Start();
		Task.Run(new Action(this.method_11));
	}

	// Token: 0x06001FBD RID: 8125 RVA: 0x000E7718 File Offset: 0x000E5918
	private void Main_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (e.CloseReason != CloseReason.WindowsShutDown && e.CloseReason != CloseReason.ApplicationExitCall)
		{
			if (base.MaximizeBox)
			{
				base.Hide();
				e.Cancel = true;
				return;
			}
			if (!base.MinimizeBox)
			{
				base.MaximizeBox = true;
				base.MinimizeBox = true;
				this.Control_0.Dispose();
				e.Cancel = true;
				return;
			}
		}
		else if (e.CloseReason == CloseReason.WindowsShutDown)
		{
			this.menuExit_Click(null, null);
		}
	}

	// Token: 0x06001FBE RID: 8126 RVA: 0x000E7788 File Offset: 0x000E5988
	private void method_40(object sender, EventArgs e)
	{
		Class159 class159_ = (sender as ToolStripMenuItem).Tag as Class159;
		this.method_8(class159_);
	}

	// Token: 0x06001FBF RID: 8127 RVA: 0x000E77B0 File Offset: 0x000E59B0
	private void method_41(object sender, EventArgs e)
	{
		Class412 @class = sender as Class412;
		if (!@class.Boolean_2 && @class.String_2 != string.Empty && @class.String_2.ToLower().Contains("update") && MessageBox.Show(this, "Đã có phiên bản mới bạn có muốn Update không", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			Process.Start("Update.exe");
			this.menuExit_Click(null, null);
		}
	}

	// Token: 0x06001FC0 RID: 8128 RVA: 0x000E781C File Offset: 0x000E5A1C
	private void method_42()
	{
		Class412 @class = new Class412();
		@class.string_1 = Class387.String_0;
		@class.control_0 = this;
		@class.Boolean_1 = true;
		@class.String_0 = "cmd=userinfo&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + HttpUtility.UrlEncode(User.string_1);
		@class.Event_0 += this.method_43;
		@class.method_0();
	}

	// Token: 0x06001FC1 RID: 8129 RVA: 0x000E7888 File Offset: 0x000E5A88
	private void method_43(object sender, EventArgs e)
	{
		Main.Class278 @class = new Main.Class278();
		@class.main_0 = this;
		try
		{
			Class412 class2 = (Class412)sender;
			if (class2.String_2.ToLower().Contains("dis"))
			{
				if (!Class268.Boolean_69)
				{
					this.menuExit_Click(null, null);
				}
			}
			else
			{
				Class268.Boolean_61 = true;
				Class268.Boolean_40 = true;
				Class268.Boolean_27 = true;
				Class268.Boolean_52 = true;
				Class268.Boolean_70 = true;
				Class268.Boolean_43 = true;
				Class268.Boolean_48 = true;
				Class268.Boolean_1 = true;
				Class268.Boolean_4 = true;
				Class268.Boolean_5 = true;
				Class268.Boolean_6 = true;
				Class268.Boolean_0 = true;
				Class268.Boolean_2 = true;
				Class268.Boolean_3 = true;
				Class268.Boolean_44 = true;
				Class268.Boolean_23 = true;
				Class268.Boolean_24 = true;
				Class268.Boolean_20 = true;
				Class268.Boolean_16 = true;
				Class268.Boolean_13 = true;
				Class268.Boolean_14 = true;
				Class268.Boolean_42 = true;
				Class268.Boolean_8 = true;
				Class268.Boolean_7 = true;
				Class268.Boolean_17 = true;
				Class268.Boolean_22 = true;
				Class268.Boolean_46 = true;
				Class268.Boolean_33 = true;
				Class268.Boolean_85 = true;
				Class268.Boolean_28 = true;
				Class268.Boolean_30 = true;
				Class268.Boolean_32 = true;
				Class268.Boolean_38 = true;
				Class268.Boolean_62 = true;
				Class268.Boolean_56 = true;
				Class268.Boolean_58 = true;
				Class268.Boolean_57 = true;
				Class268.Boolean_54 = true;
				Class268.Boolean_84 = true;
				Class268.Boolean_55 = true;
				Class268.Boolean_63 = true;
				Class268.Boolean_72 = true;
				this.muNhapCode.Visible = Class268.Boolean_72;
				string[] array = class2.String_2.Split(new char[]
				{
					'|'
				});
				User.Int32_1 = int.Parse(array[0]);
				if (User.Int32_1 > 0)
				{
					Class268.Int32_14 = 1;
					this.Text = "MicroAuto " + Class268.String_0 + " - Pro";
				}
				else
				{
					Class268.Int32_14 = 0;
					this.Text = "MicroAuto " + Class268.String_0 + " - Free";
				}
				this.lblBeli.Text = Class426.smethod_14(User.Int32_1) + " Beli";
				Main.string_3 = int.Parse(array[1]).ToString();
				@class.byte_0 = new WebClient().DownloadData("https://img.vietqr.io/image/ACB-158800469-print.png?accountName=NGUYEN%20DUY%20HAI&addInfo=micro" + Main.string_3 + "beli");
				this.smethod_20(new Action(@class.method_0));
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001FC2 RID: 8130 RVA: 0x00017334 File Offset: 0x00015534
	private void notifyIcon_0_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.method_44();
		}
		if (e.Button == MouseButtons.Middle)
		{
			base.Dispose();
		}
	}

	// Token: 0x06001FC3 RID: 8131 RVA: 0x0001735C File Offset: 0x0001555C
	private void method_44()
	{
		Class438.smethod_7(base.Handle);
		base.Activate();
		this.Refresh();
	}

	// Token: 0x06001FC4 RID: 8132 RVA: 0x0001698D File Offset: 0x00014B8D
	public static int smethod_3(bool bool_36)
	{
		if (bool_36)
		{
			return 1;
		}
		return 0;
	}

	// Token: 0x06001FC5 RID: 8133 RVA: 0x000E7ADC File Offset: 0x000E5CDC
	private void method_45(object sender, EventArgs e)
	{
		Class268.bool_80 = (this.menuPickItem.Checked = !this.menuPickItem.Checked);
	}

	// Token: 0x06001FC6 RID: 8134 RVA: 0x000E7B0C File Offset: 0x000E5D0C
	private void method_46(object sender, EventArgs e)
	{
		Class268.bool_75 = (this.menuItemFillter.Checked = !this.menuItemFillter.Checked);
	}

	// Token: 0x06001FC7 RID: 8135 RVA: 0x000E7B3C File Offset: 0x000E5D3C
	private void nudRadius_ValueChanged(object sender, EventArgs e)
	{
		if (this.Boolean_7)
		{
			return;
		}
		if (Main.class159_0.Class432_0.Boolean_29)
		{
			Class268.int_23 = (int)this.nudRadius.Value;
			return;
		}
		Class268.int_22 = (int)this.nudRadius.Value;
	}

	// Token: 0x06001FC8 RID: 8136 RVA: 0x00017375 File Offset: 0x00015575
	private void nudHP_ValueChanged(object sender, EventArgs e)
	{
		Class268.int_18 = (int)this.nudHP.Value;
	}

	// Token: 0x06001FC9 RID: 8137 RVA: 0x0001738C File Offset: 0x0001558C
	private void nudMP_ValueChanged(object sender, EventArgs e)
	{
		Class268.int_19 = (int)this.nudMP.Value;
	}

	// Token: 0x06001FCA RID: 8138 RVA: 0x000173A3 File Offset: 0x000155A3
	private void nudNM_ValueChanged(object sender, EventArgs e)
	{
		Class268.int_20 = (int)this.nudNM.Value;
	}

	// Token: 0x06001FCB RID: 8139 RVA: 0x000173BA File Offset: 0x000155BA
	private void Lv_ItemChecked(object sender, ItemCheckedEventArgs e)
	{
		Class159 @class = e.Item.Tag as Class159;
		@class.Boolean_3 = e.Item.Checked;
		@class.method_389();
	}

	// Token: 0x17000747 RID: 1863
	// (get) Token: 0x06001FCC RID: 8140 RVA: 0x000173E2 File Offset: 0x000155E2
	// (set) Token: 0x06001FCD RID: 8141 RVA: 0x000173E9 File Offset: 0x000155E9
	public static bool Boolean_9 { get; set; }

	// Token: 0x06001FCE RID: 8142 RVA: 0x000E7B90 File Offset: 0x000E5D90
	private void timer_0_Tick(object sender, EventArgs e)
	{
		Class159.Dictionary_1 = Class159.Dictionary_1.Where(new Func<KeyValuePair<string, FastTask>, bool>(Main.Class270.<>9.method_23)).ToDictionary(new Func<KeyValuePair<string, FastTask>, string>(Main.Class270.<>9.method_24), new Func<KeyValuePair<string, FastTask>, FastTask>(Main.Class270.<>9.method_25));
		this.btnCanQuetThuCong.Text = "Càn Quét [##:##]";
		Class159 @class = this.IEnumerable_2.FirstOrDefault<Class159>();
		if (@class != null && Class159.Dictionary_1.ContainsKey(@class.Class432_0.String_2))
		{
			FastTask fastTask = Class159.Dictionary_1[@class.Class432_0.String_2];
			this.btnCanQuetThuCong.Text = string.Concat(new string[]
			{
				"Càn Quét [",
				(fastTask.Int32_0 / 60).ToString(),
				":",
				(fastTask.Int32_0 % 60).ToString(),
				"]"
			});
		}
		try
		{
			Main.Boolean_9 = false;
			Main.Boolean_9 = (Class426.smethod_73(Enum20.VK_LMENU) || Class426.smethod_73(Enum20.VK_RMENU));
		}
		catch
		{
		}
	}

	// Token: 0x06001FCF RID: 8143 RVA: 0x000173F1 File Offset: 0x000155F1
	public void method_47()
	{
		base.Invoke(new Action(this.method_185));
	}

	// Token: 0x06001FD0 RID: 8144 RVA: 0x000E7CF0 File Offset: 0x000E5EF0
	private void method_48()
	{
		this.Lv.Columns[0].Text = "Name [" + this.Lv.Items.Count.ToString() + "]";
		foreach (Class159 @class in this.IEnumerable_4)
		{
			if (@class.Class432_0 != null && @class.ListViewItem_0 != null)
			{
				ListViewItem listViewItem_ = @class.ListViewItem_0;
				if (!@class.Class432_0.Boolean_20)
				{
					@class.bitmap_0 = null;
				}
				if (Class438.smethod_9(@class.IntPtr_0))
				{
					listViewItem_.SubItems[2].ForeColor = SystemColors.WindowText;
					@class.stopwatch_14 = Stopwatch.StartNew();
				}
				else
				{
					@class.Stopwatch_2 = Stopwatch.StartNew();
					listViewItem_.SubItems[2].ForeColor = Color.Red;
				}
				if (Main.dictionary_4.ContainsKey(@class.Class432_0.String_10))
				{
					listViewItem_.SubItems[11].BackColor = Main.dictionary_4[@class.Class432_0.String_10];
				}
				else
				{
					Random random = new Random();
					KnownColor[] array = (KnownColor[])Enum.GetValues(typeof(KnownColor));
					KnownColor knownColor = array[random.Next(array.Length)];
					Color color = Color.FromArgb(Main.random_0.Next(256), Main.random_0.Next(256), Main.random_0.Next(256));
					foreach (KeyValuePair<string, Color> keyValuePair in Main.dictionary_4)
					{
						if (keyValuePair.Value == color || color == Color.Black || color == Color.White)
						{
							return;
						}
					}
					Main.dictionary_4.Add(@class.Class432_0.String_10, color);
				}
				if (@class.Int32_49 > 0)
				{
					listViewItem_.SubItems[7].BackColor = Color.Orange;
				}
				else
				{
					listViewItem_.SubItems[7].BackColor = SystemColors.Window;
				}
				listViewItem_.SubItems[0].Text = @class.Class432_0.String_2;
				listViewItem_.SubItems[1].Text = @class.Class432_0.UInt32_2.ToString();
				listViewItem_.SubItems[2].Text = @class.Class432_0.String_16.Replace(" ", "");
				listViewItem_.SubItems[3].Text = @class.String_18;
				listViewItem_.SubItems[4].Text = @class.Class432_0.UInt32_37.ToString() + "%";
				listViewItem_.SubItems[5].Text = @class.Class432_0.UInt32_39.ToString() + "%";
				listViewItem_.SubItems[6].Text = @class.Class432_0.UInt32_42.ToString() + "%";
				listViewItem_.SubItems[7].Text = string.Format("{0:00}", @class.Class432_0.uint_22 / 60U) + ":" + string.Format("{0:00}", @class.Class432_0.uint_22 % 60U);
				listViewItem_.SubItems[8].Text = string.Format("{0:0.00}%", @class.Class432_0.Single_0);
				listViewItem_.SubItems[9].Text = string.Format("{0:0.00}M", @class.Single_0 / 1000000f);
				listViewItem_.SubItems[10].Text = string.Concat(new string[]
				{
					@class.Class432_0.string_7,
					" [",
					((int)@class.Single_3).ToString(),
					".",
					((int)@class.Single_4).ToString(),
					"]"
				});
				if (@class.Class159_2 != null)
				{
					listViewItem_.SubItems[11].Text = @class.Class159_2.Class432_0.String_2;
				}
				else
				{
					listViewItem_.SubItems[11].Text = @class.Class432_0.String_10;
				}
				listViewItem_.SubItems[12].Text = @class.Class432_0.UInt32_15.ToString();
				listViewItem_.SubItems[13].Text = ((int)(@class.Class432_0.UInt32_16 / 10000U)).ToString();
				if (@class.Class432_0.Boolean_51)
				{
					listViewItem_.SubItems[0].Text = "ChuyểnCảnh";
					listViewItem_.SubItems[0].BackColor = Color.Silver;
				}
				else if (!@class.Class432_0.Boolean_34)
				{
					listViewItem_.SubItems[0].BackColor = Color.Silver;
				}
				else if (@class.Class432_0.bool_2)
				{
					listViewItem_.SubItems[0].BackColor = Color.Red;
				}
				else
				{
					listViewItem_.SubItems[0].BackColor = SystemColors.Window;
				}
				if (@class.Class432_0.UInt32_37 <= 30U)
				{
					listViewItem_.SubItems[4].BackColor = Color.Red;
				}
				else
				{
					listViewItem_.SubItems[4].BackColor = SystemColors.Window;
				}
				if (@class.Class432_0.UInt32_42 == 0U)
				{
					listViewItem_.SubItems[6].BackColor = Color.Red;
				}
				else
				{
					listViewItem_.SubItems[6].BackColor = SystemColors.Window;
				}
				if (@class.Boolean_54)
				{
					listViewItem_.SubItems[8].BackColor = Color.LightBlue;
				}
				else
				{
					listViewItem_.SubItems[8].BackColor = SystemColors.Window;
				}
				if (@class.Class432_0.Boolean_32)
				{
					listViewItem_.SubItems[0].ForeColor = Color.Blue;
				}
				else
				{
					listViewItem_.SubItems[0].ForeColor = SystemColors.WindowText;
				}
			}
		}
		if (Main.class159_0 != null && Main.dictionary_3.ContainsValue(Main.class159_0))
		{
			this.lbExpSpeed.Text = Main.class159_0.String_15;
			this.lblTimeInfo.Text = Main.class159_0.String_16;
			this.lbHoaSpeed.Text = Main.class159_0.String_10;
			if (Main.class159_0.Single_1 > 0f)
			{
				this.lblRadius.Text = string.Concat(new string[]
				{
					"[",
					((int)Main.class159_0.Single_1).ToString(),
					",",
					((int)Main.class159_0.Single_2).ToString(),
					"] (",
					Main.class159_0.Int32_29.ToString(),
					")"
				});
			}
			else
			{
				this.lblRadius.Text = "[0,0] (0)";
			}
			this.lbAcBa.Text = Class432.smethod_5(Main.class159_0.Int32_40);
			if (this.lbAcBa.Text.Contains("Không"))
			{
				this.lbAcBa.Text = "LGBT";
			}
			this.gameInfo.Single_0 = Main.class159_0.Class432_0.UInt32_5 / (Main.class159_0.Class432_0.UInt32_8 + 1U);
			this.gameInfo.Single_1 = Main.class159_0.Class432_0.UInt32_6 / (Main.class159_0.Class432_0.UInt32_9 + 1U);
			this.gameInfo.Single_2 = Main.class159_0.Class432_0.UInt32_11 / (Main.class159_0.Class432_0.UInt32_12 + 1U);
			this.gameInfo.Single_3 = (float)((int)((ulong)(Main.class159_0.Class432_0.UInt32_7 * 100U) / (ulong)((long)Main.class159_0.Class432_0.Int32_2)));
			this.gameInfo.String_0 = string.Concat(new string[]
			{
				Main.class159_0.Class432_0.string_7,
				" [",
				Main.class159_0.Int32_12.ToString(),
				" ",
				Main.class159_0.Int32_13.ToString(),
				"]"
			});
		}
		else if (this.Lv.Items.Count > 0)
		{
			Main.class159_0 = (Class159)this.Lv.Items[0].Tag;
			this.Lv.Items[0].Selected = true;
		}
		this.tabBottom.TabPages[0].Text = Main.class159_0.Class432_0.String_2;
	}

	// Token: 0x06001FD1 RID: 8145 RVA: 0x00002E18 File Offset: 0x00001018
	private void Lv_MouseUp(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001FD2 RID: 8146 RVA: 0x000E868C File Offset: 0x000E688C
	private void listViewSkill_ItemChecked(object sender, ItemCheckedEventArgs e)
	{
		if (this.Boolean_7)
		{
			return;
		}
		ListView listView = sender as ListView;
		listView.ListViewItemSorter = new Class423();
		listView.Sort();
		((Class417)e.Item.Tag).Boolean_1 = e.Item.Checked;
	}

	// Token: 0x06001FD3 RID: 8147 RVA: 0x00017406 File Offset: 0x00015606
	private void btnNM_Click(object sender, EventArgs e)
	{
		this.method_54();
	}

	// Token: 0x06001FD4 RID: 8148 RVA: 0x000E86D8 File Offset: 0x000E68D8
	private void menuListView_Opening(object sender, CancelEventArgs e)
	{
		this.menuRefreshAuto.Text = "Refresh [" + this.IEnumerable_1.Count<Class159>().ToString() + "] [Ctrl + W]";
		if (Main.class159_0 != null)
		{
			this.muChucPhuc.Checked = Main.class159_0.List_0.Contains(Enum14.ChucPhucMaoBut);
		}
		this.menuDebug.Visible = Class268.Boolean_69;
		try
		{
			this.toolStripMenuItem_21.DropDownItems.Clear();
			using (IEnumerator<Class159> enumerator = this.IEnumerable_5.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Main.Class279 @class = new Main.Class279();
					@class.main_0 = this;
					@class.class159_0 = enumerator.Current;
					if (@class.class159_0.Class432_0.Boolean_32)
					{
						ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(@class.class159_0.Class432_0.String_2);
						toolStripMenuItem.Click += @class.method_0;
						this.toolStripMenuItem_21.DropDownItems.Add(toolStripMenuItem);
					}
				}
			}
			this.menuAutoCreateTeam.Checked = CalendarEx.bool_1;
			if (this.List_0.Count != 0 && this.List_0.Count == 1)
			{
				string text = this.List_0[0].Class432_0.String_2;
			}
			this.menuTrieuTap.DropDownItems.Clear();
			List<ToolStripMenuItem> list = new List<ToolStripMenuItem>();
			Main.list_3.Clear();
			foreach (object obj in this.Lv.SelectedItems)
			{
				Class159 class2 = ((ListViewItem)obj).Tag as Class159;
				if (class2.Class432_0.String_2 != "ĐăngNhập")
				{
					ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem();
					toolStripMenuItem2.Text = class2.Class432_0.String_2;
					toolStripMenuItem2.Tag = class2;
					toolStripMenuItem2.Click += this.method_40;
					list.Add(toolStripMenuItem2);
					Main.list_3.Add(class2);
				}
			}
			this.menuCreateTeam.Text = "Tạo Đội Ngũ [" + Main.list_3.Count.ToString() + "]";
			this.menuSetNhom.Text = "Set Nhóm [" + this.IEnumerable_3.Count<Class159>().ToString() + "]";
			if (User.Boolean_1)
			{
				this.menuCreateTeam.Text = "Create Team [" + Main.list_3.Count.ToString() + "]";
				this.muGiaiTan.Text = "Destroy All Team";
				this.toolStripMenuItem_6.Text = "Team";
				this.toolStripMenuItem38.Text = "Feature";
				this.toolStripMenuItem_0.Text = "Move";
				this.toolStripMenuItem_2.Text = "Add Point";
				this.menuSetNhom.Text = "Set Team [" + this.IEnumerable_3.Count<Class159>().ToString() + "]";
				this.muQuanLyNhom.Text = "Manger Team";
				this.menuAutoCreateTeam.Text = "Auto Create Team Via Set";
			}
			if (list.Count > 1)
			{
				ToolStripMenuItem[] array = new ToolStripMenuItem[list.Count];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = list[i];
				}
				ToolStripItemCollection dropDownItems = this.menuTrieuTap.DropDownItems;
				ToolStripItem[] toolStripItems = array;
				dropDownItems.AddRange(toolStripItems);
			}
		}
		catch
		{
		}
		try
		{
			if (this.Lv.PointToClient(Cursor.Position).Y <= 22)
			{
				using (IEnumerator enumerator2 = this.menuListView.Items.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						object obj2 = enumerator2.Current;
						ToolStripItem toolStripItem = (ToolStripItem)obj2;
						if (toolStripItem.Tag == null)
						{
							toolStripItem.Visible = false;
						}
						else if (toolStripItem.Tag.GetType() == typeof(ColumnHeader))
						{
							ColumnHeader columnHeader = toolStripItem.Tag as ColumnHeader;
							if (this.list_6.Contains(columnHeader.Index))
							{
								((ToolStripMenuItem)toolStripItem).Checked = false;
							}
							else
							{
								((ToolStripMenuItem)toolStripItem).Checked = true;
							}
							toolStripItem.Visible = true;
						}
						else
						{
							toolStripItem.Visible = false;
						}
					}
					goto IL_4FE;
				}
			}
			foreach (object obj3 in this.menuListView.Items)
			{
				ToolStripItem toolStripItem2 = (ToolStripItem)obj3;
				if (toolStripItem2.Tag == null)
				{
					toolStripItem2.Visible = true;
				}
				else if (toolStripItem2.Tag.GetType() == typeof(ColumnHeader))
				{
					toolStripItem2.Visible = false;
				}
				else
				{
					toolStripItem2.Visible = true;
				}
			}
			IL_4FE:;
		}
		catch
		{
		}
	}

	// Token: 0x06001FD5 RID: 8149 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_49(object sender, EventArgs e)
	{
	}

	// Token: 0x06001FD6 RID: 8150 RVA: 0x0001740E File Offset: 0x0001560E
	private void timer_1_Tick(object sender, EventArgs e)
	{
		this.method_42();
	}

	// Token: 0x17000748 RID: 1864
	// (get) Token: 0x06001FD7 RID: 8151 RVA: 0x00017416 File Offset: 0x00015616
	// (set) Token: 0x06001FD8 RID: 8152 RVA: 0x0001741D File Offset: 0x0001561D
	public static int Int32_1 { get; set; }

	// Token: 0x06001FD9 RID: 8153 RVA: 0x00017425 File Offset: 0x00015625
	private void btnOpenPass2_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_6 = this.txtPass2.Text;
			Main.class159_0.method_383();
		}
	}

	// Token: 0x06001FDA RID: 8154 RVA: 0x000E8C7C File Offset: 0x000E6E7C
	private void method_50(Class159 class159_1)
	{
		if (!class159_1.Class432_0.Boolean_34)
		{
			return;
		}
		if (!class159_1.Class432_0.Boolean_32)
		{
			class159_1.Class368_0.method_16();
		}
		foreach (object obj in this.Lv.Items)
		{
			Class159 @class = (Class159)((ListViewItem)obj).Tag;
			if (@class != class159_1)
			{
				if (@class.Class432_0.Boolean_34 && @class.Class394_0.class393_0 != null && @class.Class394_0.class393_0.UInt32_10 == 4294967295U)
				{
					@class.method_276(class159_1.Class432_0.Byte_0);
				}
				if (@class.Class432_0.Boolean_34 && @class.Class392_0.UInt32_106 == 1U)
				{
					@class.method_277(class159_1.Class432_0.Byte_0);
				}
			}
		}
	}

	// Token: 0x06001FDB RID: 8155 RVA: 0x00017406 File Offset: 0x00015606
	private void method_51(object sender, EventArgs e)
	{
		this.method_54();
	}

	// Token: 0x06001FDC RID: 8156 RVA: 0x000E8D78 File Offset: 0x000E6F78
	private void method_52()
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			if (@class.Class432_0.Boolean_32)
			{
				foreach (Class159 class2 in @class.List_25)
				{
					if (class2 != @class && class2.Class432_0.Boolean_34)
					{
						class2.method_238((float)((int)@class.Single_3), (float)((int)@class.Single_4), (int)@class.Class432_0.UInt32_29);
					}
				}
			}
		}
	}

	// Token: 0x06001FDD RID: 8157 RVA: 0x000E8E3C File Offset: 0x000E703C
	private void Lv_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Delete)
		{
			this.menuExitGame_Click(null, null);
		}
		if (e.KeyCode == Keys.Next)
		{
			foreach (object obj in this.Lv.SelectedItems)
			{
				((Class159)((ListViewItem)obj).Tag).method_222();
			}
		}
		if (e.KeyCode == Keys.Return && Main.class159_0 != null)
		{
			Main.class159_0.method_223();
		}
		if (e.KeyCode == Keys.A && e.Control)
		{
			this.Lv.smethod_12();
		}
		if (e.KeyCode.ToString() == "BACK")
		{
			this.txtMainSearch.Focus();
			SendKeys.Send("{BACK}");
		}
		string text = this.method_53(e.KeyCode);
		if (new Regex("[a-zA-Z_0-9]{1}").IsMatch(text))
		{
			this.txtMainSearch.Text = this.txtMainSearch.Text + text;
			this.txtMainSearch.Focus();
			this.txtMainSearch.Select(this.txtMainSearch.Text.Length, 0);
		}
	}

	// Token: 0x06001FDE RID: 8158 RVA: 0x000E8F90 File Offset: 0x000E7190
	public string method_53(Keys keys_0)
	{
		byte[] byte_ = new byte[255];
		if (!Main.GetKeyboardState(byte_))
		{
			return "";
		}
		uint uint_ = Main.MapVirtualKey((uint)keys_0, 0U);
		IntPtr keyboardLayout = Main.GetKeyboardLayout(0U);
		StringBuilder stringBuilder = new StringBuilder();
		Main.ToUnicodeEx((uint)keys_0, uint_, byte_, stringBuilder, 5, 0U, keyboardLayout);
		return stringBuilder.ToString();
	}

	// Token: 0x06001FDF RID: 8159
	[DllImport("user32.dll")]
	private static extern bool GetKeyboardState(byte[] byte_1);

	// Token: 0x06001FE0 RID: 8160
	[DllImport("user32.dll")]
	private static extern uint MapVirtualKey(uint uint_1, uint uint_2);

	// Token: 0x06001FE1 RID: 8161
	[DllImport("user32.dll")]
	private static extern IntPtr GetKeyboardLayout(uint uint_1);

	// Token: 0x06001FE2 RID: 8162
	[DllImport("user32.dll")]
	private static extern int ToUnicodeEx(uint uint_1, uint uint_2, byte[] byte_1, [MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder stringBuilder_0, int int_13, uint uint_3, IntPtr intptr_0);

	// Token: 0x06001FE3 RID: 8163 RVA: 0x0001744D File Offset: 0x0001564D
	private void method_54()
	{
		this.method_91(new Buff());
	}

	// Token: 0x06001FE4 RID: 8164 RVA: 0x0001745A File Offset: 0x0001565A
	private void txtRao_TextChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_8 = this.txtRao.Text;
			Main.class159_0.method_389();
		}
	}

	// Token: 0x06001FE5 RID: 8165 RVA: 0x00017482 File Offset: 0x00015682
	private void cboTrongTrot_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_19 = this.cboTrongTrot.SelectedIndex;
		}
	}

	// Token: 0x06001FE6 RID: 8166 RVA: 0x000174A0 File Offset: 0x000156A0
	private void cboThuHoach_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_20 = this.cboThuHoach.SelectedIndex;
		}
	}

	// Token: 0x06001FE7 RID: 8167 RVA: 0x000E8FE0 File Offset: 0x000E71E0
	private void method_55(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_290(22);
		}
	}

	// Token: 0x06001FE8 RID: 8168 RVA: 0x000E9030 File Offset: 0x000E7230
	private void method_56(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_313("PetSkill2_1", uint.MaxValue);
		}
	}

	// Token: 0x06001FE9 RID: 8169 RVA: 0x000E9084 File Offset: 0x000E7284
	private void method_57(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_313("PetSkill2_2", uint.MaxValue);
		}
	}

	// Token: 0x17000749 RID: 1865
	// (get) Token: 0x06001FEA RID: 8170 RVA: 0x000174BE File Offset: 0x000156BE
	public IEnumerable<Class159> IEnumerable_1
	{
		get
		{
			return this.Lv.SelectedItems.Cast<ListViewItem>().Select(new Func<ListViewItem, Class159>(Main.Class270.<>9.method_26));
		}
	}

	// Token: 0x1700074A RID: 1866
	// (get) Token: 0x06001FEB RID: 8171 RVA: 0x000174F4 File Offset: 0x000156F4
	private IEnumerable<Class159> IEnumerable_2
	{
		get
		{
			return this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_27));
		}
	}

	// Token: 0x1700074B RID: 1867
	// (get) Token: 0x06001FEC RID: 8172 RVA: 0x00017520 File Offset: 0x00015720
	public IEnumerable<Class159> IEnumerable_3
	{
		get
		{
			return this.IEnumerable_1.Where(new Func<Class159, bool>(Main.Class270.<>9.method_28));
		}
	}

	// Token: 0x1700074C RID: 1868
	// (get) Token: 0x06001FED RID: 8173 RVA: 0x0001754C File Offset: 0x0001574C
	public IEnumerable<Class159> IEnumerable_4
	{
		get
		{
			return Main.dictionary_3.Select(new Func<KeyValuePair<int, Class159>, Class159>(Main.Class270.<>9.method_29));
		}
	}

	// Token: 0x1700074D RID: 1869
	// (get) Token: 0x06001FEE RID: 8174 RVA: 0x00017577 File Offset: 0x00015777
	public IEnumerable<Class159> IEnumerable_5
	{
		get
		{
			return this.IEnumerable_4.Where(new Func<Class159, bool>(Main.Class270.<>9.method_30));
		}
	}

	// Token: 0x06001FEF RID: 8175 RVA: 0x000E90D8 File Offset: 0x000E72D8
	private void menuResetTime_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			Main.Class280 @class = new Main.Class280();
			@class.class159_0 = (Class159)listViewItem.Tag;
			if (@class.class159_0.Class432_0.Boolean_32)
			{
				@class.class159_0.Boolean_84 = true;
			}
			if (@class.class159_0.Class432_0.UInt32_28 == 10U)
			{
				@class.class159_0.Boolean_85 = true;
			}
			@class.class159_0.Boolean_32 = false;
			if ((ulong)@class.class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_89))
			{
				Task.Run(new Action(@class.method_0));
			}
			else
			{
				@class.class159_0.method_296();
			}
		}
	}

	// Token: 0x06001FF0 RID: 8176 RVA: 0x000175A3 File Offset: 0x000157A3
	private void method_58(object sender, EventArgs e)
	{
		if (Main.class159_0 == null)
		{
			return;
		}
		if (this.trader_0 == null || !this.trader_0.Visible)
		{
			this.trader_0 = new Trader(Main.class159_0);
			this.trader_0.Show(this);
		}
	}

	// Token: 0x06001FF1 RID: 8177 RVA: 0x000175DE File Offset: 0x000157DE
	private void cboHP_SelectedIndexChanged(object sender, EventArgs e)
	{
		Class268.keys_2 = Class426.smethod_23(this.cboHP.Text);
	}

	// Token: 0x06001FF2 RID: 8178 RVA: 0x000E91D0 File Offset: 0x000E73D0
	private void method_59(object sender, EventArgs e)
	{
		TextBox textBox = sender as TextBox;
		if (textBox.Lines.Length > 1000)
		{
			string[] array = new string[1000];
			for (int i = 0; i < 1000; i++)
			{
				array[i] = textBox.Lines[i];
			}
			textBox.Lines = array;
		}
	}

	// Token: 0x06001FF3 RID: 8179 RVA: 0x000E9220 File Offset: 0x000E7420
	public static void smethod_4(object object_0)
	{
		if (Main.Main_0.InvokeRequired)
		{
			Main.Main_0.Invoke(new Main.Delegate2(Main.smethod_4), new object[]
			{
				object_0
			});
			return;
		}
		int num = object_0.ToString().Split(new char[]
		{
			'|'
		}).Length;
		if (!Main.bool_26)
		{
			new SoundPlayer
			{
				Stream = GClass130.UnmanagedMemoryStream_0
			}.Play();
		}
	}

	// Token: 0x06001FF4 RID: 8180 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_60(object sender, EventArgs e)
	{
	}

	// Token: 0x1700074E RID: 1870
	// (get) Token: 0x06001FF5 RID: 8181 RVA: 0x000175F5 File Offset: 0x000157F5
	// (set) Token: 0x06001FF6 RID: 8182 RVA: 0x000175FD File Offset: 0x000157FD
	private bool Boolean_10 { get; set; }

	// Token: 0x06001FF7 RID: 8183 RVA: 0x00017606 File Offset: 0x00015806
	private void Main_Move(object sender, EventArgs e)
	{
		this.Boolean_10 = true;
	}

	// Token: 0x06001FF8 RID: 8184 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_61(object sender, EventArgs e)
	{
	}

	// Token: 0x06001FF9 RID: 8185 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_62(object sender, EventArgs e)
	{
	}

	// Token: 0x06001FFA RID: 8186 RVA: 0x0001760F File Offset: 0x0001580F
	private void method_63(object sender, EventArgs e)
	{
		Class415.smethod_1("User", "Pass", "");
		this.menuExit_Click(null, null);
	}

	// Token: 0x06001FFB RID: 8187 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_64(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001FFC RID: 8188 RVA: 0x0001762D File Offset: 0x0001582D
	private void timer_2_Tick(object sender, EventArgs e)
	{
		if (Class268.Int32_13-- == 1)
		{
			base.Dispose();
		}
	}

	// Token: 0x1700074F RID: 1871
	// (get) Token: 0x06001FFD RID: 8189 RVA: 0x000E9290 File Offset: 0x000E7490
	private List<Class159> List_0
	{
		get
		{
			List<Class159> list = new List<Class159>();
			if (this.Lv.SelectedItems.Count == 0)
			{
				using (IEnumerator enumerator = this.Lv.Items.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						Class159 @class = ((ListViewItem)obj).Tag as Class159;
						if (@class.Class159_2 != null && !list.Contains(@class.Class159_2))
						{
							list.Add(@class.Class159_2);
						}
					}
					return list;
				}
			}
			foreach (object obj2 in this.Lv.SelectedItems)
			{
				Class159 class2 = ((ListViewItem)obj2).Tag as Class159;
				if (class2.Class159_2 != null && !list.Contains(class2.Class159_2))
				{
					list.Add(class2.Class159_2);
				}
			}
			return list;
		}
	}

	// Token: 0x06001FFE RID: 8190 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_65(object sender, EventArgs e)
	{
	}

	// Token: 0x06001FFF RID: 8191 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_66(object sender, EventArgs e)
	{
	}

	// Token: 0x06002000 RID: 8192 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_67(object sender, EventArgs e)
	{
	}

	// Token: 0x06002001 RID: 8193 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_68(object sender, EventArgs e)
	{
	}

	// Token: 0x06002002 RID: 8194 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_69(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06002003 RID: 8195 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_70(object sender, KeyEventArgs e)
	{
	}

	// Token: 0x06002004 RID: 8196 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_71(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06002005 RID: 8197 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_72(object sender, EventArgs e)
	{
	}

	// Token: 0x06002006 RID: 8198 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuIcon_Opening(object sender, CancelEventArgs e)
	{
	}

	// Token: 0x06002007 RID: 8199 RVA: 0x000E93A4 File Offset: 0x000E75A4
	private void method_73()
	{
		foreach (Class145 @class in this.IEnumerable_7)
		{
			if (@class.class159_0 == null)
			{
				@class.String_20 = "Đang chờ...";
			}
			else
			{
				@class.class159_0.method_223();
			}
		}
	}

	// Token: 0x17000750 RID: 1872
	// (get) Token: 0x06002008 RID: 8200 RVA: 0x00017645 File Offset: 0x00015845
	public IEnumerable<ListViewItem> IEnumerable_6
	{
		get
		{
			return new Main.Class281(-2);
		}
	}

	// Token: 0x17000751 RID: 1873
	// (get) Token: 0x06002009 RID: 8201 RVA: 0x0001764E File Offset: 0x0001584E
	public IEnumerable<Class145> IEnumerable_7
	{
		get
		{
			return new Main.Class282(-2);
		}
	}

	// Token: 0x0600200A RID: 8202 RVA: 0x000E940C File Offset: 0x000E760C
	private void cboXuatPet_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (!this.Boolean_7)
		{
			if (this.cboXuatPet.SelectedIndex == -1)
			{
				return;
			}
			if (Main.class159_0 != null)
			{
				try
				{
					Main.class159_0.String_29 = (this.cboXuatPet.SelectedItem as Main.Class269).Int32_0.ToString("X8");
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x0600200B RID: 8203 RVA: 0x00017657 File Offset: 0x00015857
	private void method_74(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.method_313("PetSkill2_2", uint.MaxValue);
		}
	}

	// Token: 0x0600200C RID: 8204 RVA: 0x000E9478 File Offset: 0x000E7678
	private void checkXuatPet_CheckedChanged(object sender, EventArgs e)
	{
		if (!this.Boolean_7 && Main.class159_0 != null)
		{
			Main.class159_0.Boolean_31 = this.checkXuatPet.Checked;
			this.cboXuatPet.Items.Clear();
			Main.Class269 @class = new Main.Class269();
			@class.String_0 = "Không Xuất";
			@class.Int32_0 = 0;
			this.cboXuatPet.Items.Add(@class);
			int num = -1;
			int num2 = 0;
			foreach (KeyValuePair<uint, string> keyValuePair in Main.class159_0.Class432_0.Dictionary_0)
			{
				num2++;
				Main.Class269 class2 = new Main.Class269();
				class2.String_0 = keyValuePair.Value;
				class2.Int32_0 = (int)keyValuePair.Key;
				if (keyValuePair.Key.ToString("X8") == Main.class159_0.String_29)
				{
					num = num2;
				}
				this.cboXuatPet.Items.Add(class2);
			}
			if (num != -1)
			{
				this.cboXuatPet.SelectedIndex = num;
			}
		}
	}

	// Token: 0x0600200D RID: 8205 RVA: 0x0001707D File Offset: 0x0001527D
	private void method_75(object sender, EventArgs e)
	{
		this.bool_2 = true;
		base.Invalidate();
	}

	// Token: 0x0600200E RID: 8206 RVA: 0x000E95AC File Offset: 0x000E77AC
	private void method_76(object sender, EventArgs e)
	{
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_200();
		}
	}

	// Token: 0x0600200F RID: 8207 RVA: 0x000E9604 File Offset: 0x000E7804
	public void method_77()
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			@class.Boolean_66 = false;
			@class.Boolean_67 = false;
		}
	}

	// Token: 0x06002010 RID: 8208 RVA: 0x00017671 File Offset: 0x00015871
	private void method_78(object sender, EventArgs e)
	{
		this.method_79();
	}

	// Token: 0x06002011 RID: 8209 RVA: 0x000E9658 File Offset: 0x000E7858
	private void method_79()
	{
		if (!(Class378.String_0 == "") && File.Exists(Class378.String_0))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = Class378.String_0,
				Arguments = "-fl",
				WorkingDirectory = Path.GetDirectoryName(Class378.String_0)
			});
		}
		else if (!this.bool_20)
		{
			this.bool_20 = true;
			MessageBox.Show(this, "Bạn cần phải chọn đường dẫn game\r\nFile Game.exe nằm trong thư mục Bin của game", "MicroAuto", MessageBoxButtons.OK);
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Game.exe |Game.exe";
			if (openFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				Class378.String_0 = openFileDialog.FileName;
				Process.Start(new ProcessStartInfo
				{
					FileName = Class378.String_0,
					Arguments = "-fl",
					WorkingDirectory = Path.GetDirectoryName(Class378.String_0)
				});
			}
			this.bool_20 = false;
			return;
		}
	}

	// Token: 0x06002012 RID: 8210 RVA: 0x000E9738 File Offset: 0x000E7938
	private static string smethod_5()
	{
		Random random = new Random();
		string text = string.Empty;
		for (int i = 0; i < 1; i++)
		{
			text += random.Next(0, int.MaxValue).ToString("X8");
		}
		return text;
	}

	// Token: 0x06002013 RID: 8211 RVA: 0x00017679 File Offset: 0x00015879
	private void cboNM_SelectedIndexChanged(object sender, EventArgs e)
	{
		Class268.keys_1 = Class426.smethod_23(this.cboNM.Text);
	}

	// Token: 0x06002014 RID: 8212 RVA: 0x00017690 File Offset: 0x00015890
	private void cboBaseSkill_SelectedIndexChanged(object sender, EventArgs e)
	{
		Class268.keys_0 = Class426.smethod_23(this.cboBaseSkill.Text);
	}

	// Token: 0x06002015 RID: 8213 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_80(object sender, EventArgs e)
	{
	}

	// Token: 0x06002016 RID: 8214 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_81(object sender, EventArgs e)
	{
	}

	// Token: 0x06002017 RID: 8215 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_82(object sender, EventArgs e)
	{
	}

	// Token: 0x06002018 RID: 8216 RVA: 0x000E9780 File Offset: 0x000E7980
	private void method_83(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_313("FightSkillXinShou_1", uint.MaxValue);
		}
	}

	// Token: 0x06002019 RID: 8217 RVA: 0x000176A7 File Offset: 0x000158A7
	private void btnAdd_Click(object sender, EventArgs e)
	{
		this.method_91(new FrmLocdoOpt(Main.class159_0));
	}

	// Token: 0x0600201A RID: 8218 RVA: 0x000E97D4 File Offset: 0x000E79D4
	private void method_84(object sender, EventArgs e)
	{
		if (Class268.Int32_17 == 0)
		{
			MessageBox.Show(this, "Chức năng này cần kích hoạt VIP", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		foreach (ListViewItem listViewItem in this.IEnumerable_6)
		{
			Class145 @class = listViewItem.Tag as Class145;
			if (@class.class159_0 == null)
			{
				@class.String_20 = "Đang chờ làm DUA...";
				@class.Boolean_11 = true;
			}
			else
			{
				@class.class159_0.Boolean_116 = true;
			}
		}
	}

	// Token: 0x0600201B RID: 8219 RVA: 0x00002E18 File Offset: 0x00001018
	private void tabLife_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x0600201C RID: 8220 RVA: 0x000176B9 File Offset: 0x000158B9
	private void method_85(object sender, EventArgs e)
	{
		this.timer_3.Start();
		Main.int_9 = Class380.int_1;
	}

	// Token: 0x0600201D RID: 8221 RVA: 0x000E9868 File Offset: 0x000E7A68
	private void timer_3_Tick(object sender, EventArgs e)
	{
		try
		{
			if (Main.int_9 == Class380.int_1)
			{
				foreach (Class159 @class in Main.list_3)
				{
					@class.method_282("Player:LeaveTeam();", false);
				}
				Main.int_9 = Class380.int_52;
			}
			else if (Main.int_9 == Class380.int_52)
			{
				Main.list_3[0].method_282("Player:CreateTeamSelf();", false);
				Main.int_9 = Class380.int_53;
			}
			else if (Main.int_9 == Class380.int_53)
			{
				if (Main.list_3.Count > 1)
				{
					for (int i = 1; i < Main.list_3.Count; i++)
					{
						Main.list_3[i].method_276(Main.list_3[0].Class432_0.Byte_0);
					}
				}
				this.timer_3.Stop();
				Main.int_9 = Class380.int_1;
			}
		}
		catch
		{
		}
	}

	// Token: 0x0600201E RID: 8222 RVA: 0x000176D0 File Offset: 0x000158D0
	private void timer_4_Tick(object sender, EventArgs e)
	{
		Task.Run(new Action(this.method_186));
	}

	// Token: 0x0600201F RID: 8223 RVA: 0x000176E4 File Offset: 0x000158E4
	private void chkMuaNguyenLieu_CheckedChanged(object sender, EventArgs e)
	{
		Class159.Boolean_1 = this.chkMuaNguyenLieu.Checked;
	}

	// Token: 0x06002020 RID: 8224 RVA: 0x000176F6 File Offset: 0x000158F6
	private void chkGiamDinh_CheckedChanged(object sender, EventArgs e)
	{
		Class159.Boolean_0 = this.chkGiamDinh.Checked;
	}

	// Token: 0x06002021 RID: 8225 RVA: 0x00017708 File Offset: 0x00015908
	private void cboLoai_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_91 = this.cboLoai.SelectedIndex;
			Main.class159_0.string_33 = this.cboLoai.Text;
		}
	}

	// Token: 0x06002022 RID: 8226 RVA: 0x0001773B File Offset: 0x0001593B
	private void cboCap_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_92 = this.cboCap.SelectedIndex;
		}
	}

	// Token: 0x06002023 RID: 8227 RVA: 0x00017759 File Offset: 0x00015959
	private void nudStar_ValueChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_94 = (int)this.nudStar.Value;
		}
	}

	// Token: 0x06002024 RID: 8228 RVA: 0x0001777C File Offset: 0x0001597C
	private void nudLine_ValueChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_95 = (int)this.nudLine.Value;
		}
	}

	// Token: 0x06002025 RID: 8229 RVA: 0x0001779F File Offset: 0x0001599F
	private void nudPoint_ValueChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_96 = (int)this.nudPoint.Value;
		}
	}

	// Token: 0x06002026 RID: 8230 RVA: 0x000177C2 File Offset: 0x000159C2
	private void chkAutoDropCraft_CheckedChanged(object sender, EventArgs e)
	{
		Class268.bool_66 = this.chkAutoDropCraft.Checked;
	}

	// Token: 0x06002027 RID: 8231 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_86(object sender, EventArgs e)
	{
	}

	// Token: 0x06002028 RID: 8232 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_87(object sender, EventArgs e)
	{
	}

	// Token: 0x06002029 RID: 8233 RVA: 0x000177D4 File Offset: 0x000159D4
	private void radNoi_CheckedChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_93 = 1;
		}
	}

	// Token: 0x0600202A RID: 8234 RVA: 0x000177E8 File Offset: 0x000159E8
	private void radNgoai_CheckedChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_93 = 2;
		}
	}

	// Token: 0x0600202B RID: 8235 RVA: 0x000177FC File Offset: 0x000159FC
	private void radNoiNgoai_CheckedChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.int_93 = 3;
		}
	}

	// Token: 0x0600202C RID: 8236 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_88(object sender, EventArgs e)
	{
	}

	// Token: 0x0600202D RID: 8237 RVA: 0x000E9980 File Offset: 0x000E7B80
	private void chkStartCraft_CheckedChanged(object sender, EventArgs e)
	{
		if (this.chkStartCraft.Checked)
		{
			if (Class268.Int32_17 == 0)
			{
				MessageBox.Show(this, "Xin lỗi bạn chưa kích hoạt VIP nên không thể sử dụng chức năng này", "MicroAuto", MessageBoxButtons.OK);
				this.chkStartCraft.Checked = false;
				return;
			}
			if (Main.class159_0 != null && Main.class159_0.Class392_0.UInt32_106 != 2U)
			{
				MessageBox.Show(this, "Xin lỗi chức năng này chỉ dành cho TLBB private", "MicroAuto", MessageBoxButtons.OK);
				this.chkStartCraft.Checked = false;
				return;
			}
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.bool_129 = this.chkStartCraft.Checked;
			if (!Main.class159_0.bool_3 && Main.class159_0.bool_129)
			{
				Main.class159_0.method_1();
			}
			Main.class159_0.method_389();
		}
	}

	// Token: 0x0600202E RID: 8238 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_89(object sender, EventArgs e)
	{
	}

	// Token: 0x0600202F RID: 8239 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_90(object sender, EventArgs e)
	{
	}

	// Token: 0x06002030 RID: 8240 RVA: 0x000E9A40 File Offset: 0x000E7C40
	private void numberGiaKNB_ValueChanged(object sender, EventArgs e)
	{
		Main.int_10 = (int)this.numberGiaKNB.Value * 10000;
		Main.class159_0.method_282("PRICE = " + Main.int_10.ToString() + ";", false);
		Main.class159_0.Int32_47 = 4;
		Main.class159_0.int_73 = 0;
	}

	// Token: 0x06002031 RID: 8241 RVA: 0x000E9AA4 File Offset: 0x000E7CA4
	private void checkMuaKNB_CheckedChanged(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.class159_0.method_48(Enum14.AutoBuyKNB, this.checkMuaKNB.Checked);
			Main.class159_0.method_282("PRICE = " + Main.int_10.ToString() + ";", false);
			Main.class159_0.Int32_47 = 4;
			Main.class159_0.int_73 = 0;
		}
	}

	// Token: 0x06002032 RID: 8242 RVA: 0x00017810 File Offset: 0x00015A10
	private void btnTalkChannel_Click(object sender, EventArgs e)
	{
		this.method_91(new TalkChannel());
	}

	// Token: 0x06002033 RID: 8243 RVA: 0x0001781D File Offset: 0x00015A1D
	private void btnOnlyAttack_Click(object sender, EventArgs e)
	{
		this.method_91(new OnlyAttack());
	}

	// Token: 0x17000752 RID: 1874
	// (get) Token: 0x06002034 RID: 8244 RVA: 0x0001782A File Offset: 0x00015A2A
	// (set) Token: 0x06002035 RID: 8245 RVA: 0x00017832 File Offset: 0x00015A32
	private Control Control_0 { get; set; }

	// Token: 0x06002036 RID: 8246 RVA: 0x000E9B0C File Offset: 0x000E7D0C
	public void method_91(Control control_2)
	{
		this.Control_0 = control_2;
		this.Control_0.Disposed += this.method_187;
		this.mainMenu.Visible = false;
		this.Control_0.Dock = DockStyle.Fill;
		this.Container.Controls.Add(this.Control_0);
		this.Control_0.BringToFront();
		this.Text = this.Control_0.Tag.ToString();
	}

	// Token: 0x17000753 RID: 1875
	// (get) Token: 0x06002037 RID: 8247 RVA: 0x0001783B File Offset: 0x00015A3B
	// (set) Token: 0x06002038 RID: 8248 RVA: 0x00017842 File Offset: 0x00015A42
	public static bool Boolean_11 { get; set; }

	// Token: 0x17000754 RID: 1876
	// (get) Token: 0x06002039 RID: 8249 RVA: 0x0001784A File Offset: 0x00015A4A
	// (set) Token: 0x0600203A RID: 8250 RVA: 0x00017851 File Offset: 0x00015A51
	public static bool Boolean_12 { get; set; }

	// Token: 0x0600203B RID: 8251 RVA: 0x00017859 File Offset: 0x00015A59
	private void Lv_DoubleClick(object sender, EventArgs e)
	{
		this.method_31(sender, e);
	}

	// Token: 0x17000755 RID: 1877
	// (get) Token: 0x0600203C RID: 8252 RVA: 0x00017863 File Offset: 0x00015A63
	// (set) Token: 0x0600203D RID: 8253 RVA: 0x0001786A File Offset: 0x00015A6A
	public static bool Boolean_13 { get; set; }

	// Token: 0x0600203E RID: 8254 RVA: 0x00002E18 File Offset: 0x00001018
	private void Lv_ItemCheck(object sender, ItemCheckEventArgs e)
	{
	}

	// Token: 0x0600203F RID: 8255 RVA: 0x000E9B88 File Offset: 0x000E7D88
	private void method_92(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "187,113," + Class365.Int32_45.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "187,113," + Class365.Int32_45.ToString();
		}
	}

	// Token: 0x06002040 RID: 8256 RVA: 0x000E9C30 File Offset: 0x000E7E30
	private void method_93(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "114,122," + Class365.Int32_45.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "114,122," + Class365.Int32_45.ToString();
		}
	}

	// Token: 0x06002041 RID: 8257 RVA: 0x000E9CD8 File Offset: 0x000E7ED8
	private void method_94(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "27,124," + Class365.Int32_45.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "27,124," + Class365.Int32_45.ToString();
		}
	}

	// Token: 0x06002042 RID: 8258 RVA: 0x000E9D80 File Offset: 0x000E7F80
	private void method_95(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "223,225," + Class365.Int32_46.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "223,225," + Class365.Int32_46.ToString();
		}
	}

	// Token: 0x06002043 RID: 8259 RVA: 0x000E9E28 File Offset: 0x000E8028
	private void method_96(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "134,41," + Class365.Int32_46.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "134,41," + Class365.Int32_46.ToString();
		}
	}

	// Token: 0x06002044 RID: 8260 RVA: 0x000E9ED0 File Offset: 0x000E80D0
	private void method_97(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "224,216," + Class365.Int32_47.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "224,216," + Class365.Int32_47.ToString();
		}
	}

	// Token: 0x06002045 RID: 8261 RVA: 0x000E9F78 File Offset: 0x000E8178
	private void method_98(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).String_21 = "31,33," + Class365.Int32_48.ToString();
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = "31,33," + Class365.Int32_48.ToString();
		}
	}

	// Token: 0x06002046 RID: 8262 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_99(object sender, EventArgs e)
	{
	}

	// Token: 0x06002047 RID: 8263 RVA: 0x000EA020 File Offset: 0x000E8220
	private void toolStripMenuItem_1_Click(object sender, EventArgs e)
	{
		using (IEnumerator<Class159> enumerator = this.IEnumerable_3.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Main.Class283 @class = new Main.Class283();
				@class.class159_0 = enumerator.Current;
				Task.Run(new Action(@class.method_0));
			}
		}
	}

	// Token: 0x06002048 RID: 8264 RVA: 0x00017872 File Offset: 0x00015A72
	private void button4_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			this.txtRao.Text = Main.class159_0.String_7;
		}
	}

	// Token: 0x06002049 RID: 8265 RVA: 0x00017890 File Offset: 0x00015A90
	private void method_100(object sender, EventArgs e)
	{
		this.menuExit_Click(null, null);
	}

	// Token: 0x0600204A RID: 8266 RVA: 0x0001789A File Offset: 0x00015A9A
	private void toolStripMenuItem_2_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			this.method_91(new DiChuyen());
			this.Control_0.Disposed += this.method_101;
		}
	}

	// Token: 0x0600204B RID: 8267 RVA: 0x000EA084 File Offset: 0x000E8284
	private void method_101(object sender, EventArgs e)
	{
		try
		{
			bool flag = true;
			do
			{
				flag = false;
				foreach (object obj in this.toolStripMenuItem_0.DropDownItems)
				{
					ToolStripItem toolStripItem = (ToolStripItem)obj;
					if (toolStripItem.Tag != null && !string.IsNullOrEmpty(toolStripItem.Tag.ToString().Trim()))
					{
						toolStripItem.Dispose();
						flag = true;
						break;
					}
				}
			}
			while (flag);
			List<ToolStripMenuItem> list = new List<ToolStripMenuItem>();
			string[] array = Class159.Class220_0.method_0("Item", "DiChuyen").Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Split(new char[]
				{
					'|'
				}).Length == 3)
				{
					string tag = text.Split(new char[]
					{
						'|'
					})[0];
					string text2 = text.Split(new char[]
					{
						'|'
					})[1];
					string text3 = text.Split(new char[]
					{
						'|'
					})[2];
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem();
					toolStripMenuItem.Text = text3;
					toolStripMenuItem.Tag = tag;
					toolStripMenuItem.Click += this.method_102;
					list.Add(toolStripMenuItem);
				}
			}
			if (list.Count > 0)
			{
				this.toolStripMenuItem_0.DropDownItems.Add(new ToolStripSeparator
				{
					Tag = "user"
				});
			}
			ToolStripItemCollection dropDownItems = this.toolStripMenuItem_0.DropDownItems;
			ToolStripItem[] toolStripItems = list.ToArray();
			dropDownItems.AddRange(toolStripItems);
		}
		catch
		{
		}
	}

	// Token: 0x0600204C RID: 8268 RVA: 0x000EA260 File Offset: 0x000E8460
	private void method_102(object sender, EventArgs e)
	{
		try
		{
			string text = (sender as ToolStripMenuItem).Tag.ToString();
			if (text.Split(new char[]
			{
				','
			}).Length == 3)
			{
				foreach (object obj in this.Lv.SelectedItems)
				{
					(((ListViewItem)obj).Tag as Class159).String_21 = text;
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x0600204D RID: 8269 RVA: 0x000178C5 File Offset: 0x00015AC5
	public static void smethod_6()
	{
		new Thread(new ThreadStart(Main.Class270.<>9.method_32)).Start();
	}

	// Token: 0x17000756 RID: 1878
	// (get) Token: 0x0600204E RID: 8270 RVA: 0x000178F0 File Offset: 0x00015AF0
	// (set) Token: 0x0600204F RID: 8271 RVA: 0x000178F7 File Offset: 0x00015AF7
	public static GClass25 GClass25_0 { get; set; }

	// Token: 0x06002050 RID: 8272 RVA: 0x000178FF File Offset: 0x00015AFF
	private void backgroundWorker_1_DoWork(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_47();
			Thread.Sleep(1500);
		}
	}

	// Token: 0x06002051 RID: 8273 RVA: 0x000EA300 File Offset: 0x000E8500
	private static void smethod_7(object sender, GEventArgs3 e)
	{
		try
		{
			Main.String_1 = "Close";
			Main.GClass25_0.Event_2 -= Main.smethod_10;
			Main.GClass25_0.Event_3 -= Main.smethod_9;
			Main.GClass25_0.Event_0 -= Main.smethod_8;
			Main.GClass25_0.Event_1 -= Main.smethod_7;
			Main.GClass25_0.method_72();
		}
		catch
		{
		}
	}

	// Token: 0x06002052 RID: 8274 RVA: 0x000EA300 File Offset: 0x000E8500
	private static void smethod_8(object sender, GEventArgs2 e)
	{
		try
		{
			Main.String_1 = "Close";
			Main.GClass25_0.Event_2 -= Main.smethod_10;
			Main.GClass25_0.Event_3 -= Main.smethod_9;
			Main.GClass25_0.Event_0 -= Main.smethod_8;
			Main.GClass25_0.Event_1 -= Main.smethod_7;
			Main.GClass25_0.method_72();
		}
		catch
		{
		}
	}

	// Token: 0x06002053 RID: 8275 RVA: 0x00017912 File Offset: 0x00015B12
	private static void smethod_9(object sender, EventArgs e)
	{
		Main.String_1 = "Open";
	}

	// Token: 0x06002054 RID: 8276 RVA: 0x0001791E File Offset: 0x00015B1E
	private static void smethod_10(object sender, GEventArgs4 e)
	{
		Main.Class284 @class = new Main.Class284();
		@class.geventArgs4_0 = e;
		new Thread(new ThreadStart(@class.method_0)).Start();
	}

	// Token: 0x06002055 RID: 8277 RVA: 0x00017941 File Offset: 0x00015B41
	private void method_103(object sender, EventArgs e)
	{
		RichTextBox richTextBox = sender as RichTextBox;
		richTextBox.SelectionStart = richTextBox.Text.Length;
		richTextBox.ScrollToCaret();
	}

	// Token: 0x17000757 RID: 1879
	// (get) Token: 0x06002056 RID: 8278 RVA: 0x0001795F File Offset: 0x00015B5F
	// (set) Token: 0x06002057 RID: 8279 RVA: 0x00017966 File Offset: 0x00015B66
	public static string String_2 { get; set; } = string.Empty;

	// Token: 0x17000758 RID: 1880
	// (get) Token: 0x06002058 RID: 8280 RVA: 0x0001796E File Offset: 0x00015B6E
	// (set) Token: 0x06002059 RID: 8281 RVA: 0x00017975 File Offset: 0x00015B75
	public static bool Boolean_14 { get; set; } = true;

	// Token: 0x0600205A RID: 8282 RVA: 0x000EA390 File Offset: 0x000E8590
	private void toolStripMenuItem_3_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			Class159 @class = ((ListViewItem)obj).Tag as Class159;
			@class.String_21 = @class.String_25;
		}
		if (Main.class159_0 != null)
		{
			Main.class159_0.String_21 = Main.class159_0.String_25;
		}
	}

	// Token: 0x0600205B RID: 8283 RVA: 0x000EA418 File Offset: 0x000E8618
	private void toolStripMenuItem_4_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.String_25 = string.Concat(new string[]
			{
				@class.Int32_12.ToString(),
				",",
				@class.Int32_13.ToString(),
				",",
				@class.Class432_0.UInt32_29.ToString()
			});
		}
		this.lblTrain.Text = (Main.class159_0.String_26 ?? "");
	}

	// Token: 0x0600205C RID: 8284 RVA: 0x000EA4D8 File Offset: 0x000E86D8
	private void toolStripMenuItem_5_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).method_48(Enum14.DungThoLinhChau, true);
		}
	}

	// Token: 0x0600205D RID: 8285 RVA: 0x0001797D File Offset: 0x00015B7D
	private void menuTrieuTapNhom_Click(object sender, EventArgs e)
	{
		this.method_52();
	}

	// Token: 0x0600205E RID: 8286 RVA: 0x000EA544 File Offset: 0x000E8744
	private void menuMoiDoi_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null && Main.class159_0.Class432_0.String_2 != "ĐăngNhập")
		{
			if (Main.class159_0.Class432_0.Boolean_32)
			{
				this.method_50(Main.class159_0);
				return;
			}
			Main.class159_0.Class368_0.method_16();
		}
	}

	// Token: 0x0600205F RID: 8287 RVA: 0x00017985 File Offset: 0x00015B85
	private void menuTrieuTap_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			this.method_8(Main.class159_0);
		}
	}

	// Token: 0x06002060 RID: 8288 RVA: 0x000EA5A0 File Offset: 0x000E87A0
	private void menuSetNhom_Click(object sender, EventArgs e)
	{
		if (Main.class159_0.Class432_0.Boolean_34)
		{
			Setting.Dictionary_0[Main.class159_0.Class432_0.String_2] = this.IEnumerable_3.Select(new Func<Class159, string>(Main.Class270.<>9.method_34)).ToList<string>();
		}
	}

	// Token: 0x17000759 RID: 1881
	// (get) Token: 0x06002061 RID: 8289 RVA: 0x00017999 File Offset: 0x00015B99
	// (set) Token: 0x06002062 RID: 8290 RVA: 0x000179A0 File Offset: 0x00015BA0
	public static bool Boolean_15 { get; set; }

	// Token: 0x06002063 RID: 8291 RVA: 0x000179A8 File Offset: 0x00015BA8
	private void menuAutoCreateTeam_Click(object sender, EventArgs e)
	{
		CalendarEx.bool_1 = !CalendarEx.bool_1;
	}

	// Token: 0x06002064 RID: 8292 RVA: 0x000179B7 File Offset: 0x00015BB7
	private void muQuanLyNhom_Click(object sender, EventArgs e)
	{
		this.method_91(new CalendarEx());
	}

	// Token: 0x06002065 RID: 8293 RVA: 0x000179C4 File Offset: 0x00015BC4
	private void menuCreateTeam_Click(object sender, EventArgs e)
	{
		Task.Run(new Action(this.method_188));
	}

	// Token: 0x06002066 RID: 8294 RVA: 0x000EA608 File Offset: 0x000E8808
	public static void smethod_11(List<Class159> list_7)
	{
		Main.Class289 @class = new Main.Class289();
		@class.list_0 = list_7;
		if (@class.list_0.Count > 0)
		{
			@class.list_0.ForEach(new Action<Class159>(@class.method_0));
			Thread.Sleep(2000);
			@class.list_0[0].method_282("Player:CreateTeamSelf();", false);
			Thread.Sleep(500);
			@class.list_0.Skip(1).ToList<Class159>().ForEach(new Action<Class159>(@class.method_1));
			Thread.Sleep(1000);
			@class.list_0[0].method_335(true);
		}
	}

	// Token: 0x06002067 RID: 8295 RVA: 0x000179D8 File Offset: 0x00015BD8
	private void numericUpDown2_ValueChanged(object sender, EventArgs e)
	{
		Main.Int32_2 = (int)this.numericUpDown2.Value;
	}

	// Token: 0x1700075A RID: 1882
	// (get) Token: 0x06002068 RID: 8296 RVA: 0x000179EF File Offset: 0x00015BEF
	// (set) Token: 0x06002069 RID: 8297 RVA: 0x000179F6 File Offset: 0x00015BF6
	public static int Int32_2 { get; set; } = 50;

	// Token: 0x0600206A RID: 8298 RVA: 0x00002E18 File Offset: 0x00001018
	private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
	{
	}

	// Token: 0x0600206B RID: 8299 RVA: 0x000EA6B4 File Offset: 0x000E88B4
	private void muGiaiTan_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			@class.method_282("Player:LeaveTeam(); Player:LeaveRiad();", false);
		}
	}

	// Token: 0x0600206C RID: 8300 RVA: 0x000EA708 File Offset: 0x000E8908
	private void method_104(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Class234 @class = new Class234();
			@class.IEnumerable_0 = Main.class159_0.List_23;
			@class.IEnumerable_1 = Main.class159_0.List_24;
			if (@class.IEnumerable_0.Count<Class159>() <= 0 || @class.IEnumerable_1.Count<Class159>() <= 0)
			{
				Main.Class290 class2 = new Main.Class290();
				foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
				{
					if (@class.IEnumerable_0.Count<Class159>() == 0)
					{
						if ((ulong)keyValuePair.Value.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_49) && keyValuePair.Value.Class159_2 != null)
						{
							@class.IEnumerable_0 = keyValuePair.Value.List_25;
						}
					}
					else if (@class.IEnumerable_1.Count<Class159>() == 0 && (ulong)keyValuePair.Value.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_49) && keyValuePair.Value.Class159_2 != null && !@class.IEnumerable_0.Contains(keyValuePair.Value))
					{
						@class.IEnumerable_1 = keyValuePair.Value.List_25;
						break;
					}
				}
				class2.tabPage_0 = new TabPage("BinhThánh");
				this.tabCanQuet.TabPages.Add(class2.tabPage_0);
				BinhThanh binhThanh = new BinhThanh(@class)
				{
					Dock = DockStyle.Fill
				};
				binhThanh.Disposed += class2.method_0;
				class2.tabPage_0.Controls.Add(binhThanh);
				this.tabCanQuet.Visible = true;
				this.tabCanQuet.BringToFront();
				this.tabCanQuet.SelectedTab = class2.tabPage_0;
			}
		}
	}

	// Token: 0x0600206D RID: 8301 RVA: 0x000EA8D8 File Offset: 0x000E8AD8
	private void method_105(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			@class.method_270();
		}
	}

	// Token: 0x0600206E RID: 8302 RVA: 0x000EA924 File Offset: 0x000E8B24
	private void method_106(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			@class.method_272();
		}
	}

	// Token: 0x0600206F RID: 8303 RVA: 0x000EA970 File Offset: 0x000E8B70
	private void listViewSkill_MouseDown(object sender, MouseEventArgs e)
	{
		ListViewHitTestInfo listViewHitTestInfo = this.listViewSkill.HitTest(e.X, e.Y);
		int index = listViewHitTestInfo.Item.Index;
		int num = listViewHitTestInfo.Item.SubItems.IndexOf(listViewHitTestInfo.SubItem);
		if (num == 1)
		{
			string text = listViewHitTestInfo.Item.SubItems[num].Text;
			Class417 @class = listViewHitTestInfo.Item.Tag as Class417;
			@class.Boolean_0 = !@class.Boolean_0;
			listViewHitTestInfo.Item.SubItems[1].Text = (@class.Boolean_0 ? "X" : "");
		}
	}

	// Token: 0x06002070 RID: 8304 RVA: 0x000179FE File Offset: 0x00015BFE
	private void method_107(object sender, LinkLabelLinkClickedEventArgs e)
	{
		MessageBox.Show(this, "x 1.98 Beri Bet hoặc thua toàn bộ\r\nTỷ lệ ăn thua là 50 50\r\nVí dụ các bạn Bet 100 Beri khi thắng các bạn nhận 198 Beri\r\nKhi thua mất 100 Beri đặt cược\r\nChúc các bạn chơi game BET vui vẻ\r\n", "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x06002071 RID: 8305 RVA: 0x00017A12 File Offset: 0x00015C12
	private void muVoLuongSon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_189));
	}

	// Token: 0x06002072 RID: 8306 RVA: 0x00017A2B File Offset: 0x00015C2B
	private void muKinhHo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_190));
	}

	// Token: 0x06002073 RID: 8307 RVA: 0x00017A44 File Offset: 0x00015C44
	private void muKiemCac_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_191));
	}

	// Token: 0x06002074 RID: 8308 RVA: 0x00017A5D File Offset: 0x00015C5D
	private void muThaiHo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_192));
	}

	// Token: 0x06002075 RID: 8309 RVA: 0x00017A76 File Offset: 0x00015C76
	private void muTungSon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_193));
	}

	// Token: 0x06002076 RID: 8310 RVA: 0x00017A8F File Offset: 0x00015C8F
	private void muDonHoang_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_194));
	}

	// Token: 0x06002077 RID: 8311 RVA: 0x00002E18 File Offset: 0x00001018
	private void muAcBa_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06002078 RID: 8312 RVA: 0x00017AA8 File Offset: 0x00015CA8
	private void muTayHo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_195));
	}

	// Token: 0x06002079 RID: 8313 RVA: 0x00017AC1 File Offset: 0x00015CC1
	private void muNhiHai_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_196));
	}

	// Token: 0x0600207A RID: 8314 RVA: 0x00017ADA File Offset: 0x00015CDA
	private void muNhanNam_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_197));
	}

	// Token: 0x0600207B RID: 8315 RVA: 0x00017AF3 File Offset: 0x00015CF3
	private void muDaTru_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_198));
	}

	// Token: 0x0600207C RID: 8316 RVA: 0x00017B0C File Offset: 0x00015D0C
	private void muKyCuocNhanh_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_199));
	}

	// Token: 0x0600207D RID: 8317 RVA: 0x00017B25 File Offset: 0x00015D25
	private void muKyCuocCham_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_200));
	}

	// Token: 0x0600207E RID: 8318 RVA: 0x00017B3E File Offset: 0x00015D3E
	private void muLauLanTamBaoNhanh_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_201));
	}

	// Token: 0x0600207F RID: 8319 RVA: 0x00017B57 File Offset: 0x00015D57
	private void muLauLanTamBaoCham_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_202));
	}

	// Token: 0x06002080 RID: 8320 RVA: 0x00017B70 File Offset: 0x00015D70
	private void muMongHeo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_203));
	}

	// Token: 0x06002081 RID: 8321 RVA: 0x00017B89 File Offset: 0x00015D89
	private void muThienGiangKyThu_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_204));
	}

	// Token: 0x06002082 RID: 8322 RVA: 0x00017BA2 File Offset: 0x00015DA2
	private void muPhungHoangLangMo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_205));
	}

	// Token: 0x06002083 RID: 8323 RVA: 0x000EAA20 File Offset: 0x000E8C20
	private void leaderToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
	{
		this.method_151(null, null);
		this.muAcTac.Font = new Font(this.muAcTac.Font, FontStyle.Regular);
		this.muAcBa.Font = new Font(this.muAcBa.Font, FontStyle.Regular);
		this.muTangKinhCac.Font = new Font(this.muTangKinhCac.Font, FontStyle.Regular);
		this.muKyCuoc.Font = new Font(this.muKyCuoc.Font, FontStyle.Regular);
		this.muLauLanTamBao.Font = new Font(this.muLauLanTamBao.Font, FontStyle.Regular);
		this.muDaTru.Font = new Font(this.muDaTru.Font, FontStyle.Regular);
		this.muMongHeo.Font = new Font(this.muMongHeo.Font, FontStyle.Regular);
		this.muThienGiangKyThu.Font = new Font(this.muThienGiangKyThu.Font, FontStyle.Regular);
		this.muPhungHoangLangMo.Font = new Font(this.muPhungHoangLangMo.Font, FontStyle.Regular);
		int hour = DateTime.Now.Hour;
		int minute = DateTime.Now.Minute;
		if (hour == 13 || hour == 15 || hour == 17 || hour == 19 || hour == 21 || hour == 2)
		{
			this.muAcTac.Font = new Font(this.muAcTac.Font, FontStyle.Bold);
		}
		if ((hour == 0 || hour == 4 || hour == 10 || hour == 12 || hour == 16 || hour == 20 || hour == 22) && minute <= 30)
		{
			this.muAcBa.Font = new Font(this.muAcBa.Font, FontStyle.Bold);
		}
		if ((hour == 10 && minute >= 45) || (hour == 11 && minute <= 15) || (hour == 16 && minute >= 30) || (hour == 21 && minute >= 30) || (hour == 23 && minute <= 30))
		{
			this.muTangKinhCac.Font = new Font(this.muTangKinhCac.Font, FontStyle.Bold);
		}
		if ((hour == 11 & minute >= 30) || hour == 12 || hour == 13 || (hour == 14 && minute <= 30) || (hour == 20 && minute >= 30) || hour == 21)
		{
			this.muKyCuoc.Font = new Font(this.muKyCuoc.Font, FontStyle.Bold);
		}
		if ((hour == 11 & minute >= 30) || hour == 12 || hour == 13 || (hour == 14 && minute <= 30) || (hour == 19 && minute >= 30) || hour == 20 || hour == 21)
		{
			this.muLauLanTamBao.Font = new Font(this.muLauLanTamBao.Font, FontStyle.Bold);
		}
		if (hour == 14 || hour == 15 || (hour == 16 && minute <= 40) || (hour == 21 && minute >= 30) || hour == 22 || hour == 23)
		{
			this.muDaTru.Font = new Font(this.muDaTru.Font, FontStyle.Bold);
			this.muMongHeo.Font = new Font(this.muMongHeo.Font, FontStyle.Bold);
		}
		if ((hour == 13 && minute >= 30) || (hour == 18 && minute >= 30) || (hour == 19 && minute <= 30) || (hour == 21 && minute >= 45) || (hour == 22 && minute <= 15))
		{
			this.muThienGiangKyThu.Font = new Font(this.muThienGiangKyThu.Font, FontStyle.Bold);
		}
		if (hour == 13 || (hour == 22 && minute >= 30) || (hour == 23 && minute <= 30))
		{
			this.muPhungHoangLangMo.Font = new Font(this.muPhungHoangLangMo.Font, FontStyle.Regular);
		}
		if (this.IEnumerable_2.Count<Class159>() == 0)
		{
			foreach (object obj in this.leaderToolStripMenuItem.DropDownItems)
			{
				if (obj.GetType() == typeof(ToolStripMenuItem))
				{
					((ToolStripMenuItem)obj).Checked = false;
					foreach (object obj2 in ((ToolStripMenuItem)obj).DropDownItems)
					{
						if (obj2.GetType() == typeof(ToolStripMenuItem))
						{
							((ToolStripMenuItem)obj2).Checked = false;
						}
					}
				}
			}
			return;
		}
		Class159 @class = this.IEnumerable_2.FirstOrDefault<Class159>();
		this.toolStripMenuItem_131.Checked = @class.List_0.Contains(Enum14.DatDoiAcBa);
		if (!@class.List_0.Contains(Enum14.DatDoiAcTac))
		{
			ToolStripMenuItem toolStripMenuItem = this.muVoLuongSon;
			ToolStripMenuItem toolStripMenuItem2 = this.muKinhHo;
			ToolStripMenuItem toolStripMenuItem3 = this.muKiemCac;
			ToolStripMenuItem toolStripMenuItem4 = this.muTungSon;
			this.muDonHoang.Checked = false;
			toolStripMenuItem4.Checked = false;
			toolStripMenuItem3.Checked = false;
			toolStripMenuItem2.Checked = false;
			toolStripMenuItem.Checked = false;
			this.muAcTac.Checked = false;
		}
		else
		{
			this.muVoLuongSon.Checked = (@class.Int32_59 == Class365.Int32_9);
			this.muKinhHo.Checked = (@class.Int32_59 == Class365.Int32_8);
			this.muKiemCac.Checked = (@class.Int32_59 == Class365.Int32_10);
			this.muThaiHo.Checked = (@class.Int32_59 == Class365.Int32_7);
			this.muTungSon.Checked = (@class.Int32_59 == Class365.Int32_6);
			this.muDonHoang.Checked = (@class.Int32_59 == Class365.Int32_11);
			this.muAcTac.Checked = true;
		}
		this.toolStripMenuItem_13.Checked = @class.Boolean_111;
		this.mnuKetNghia.Checked = @class.Boolean_81;
		this.muAcBa.Checked = @class.List_0.Contains(Enum14.DatDoiAcBa);
		if (!@class.List_0.Contains(Enum14.DatDoiTangKinhCac))
		{
			ToolStripMenuItem toolStripMenuItem5 = this.muTayHo;
			ToolStripMenuItem toolStripMenuItem6 = this.muNhiHai;
			this.muNhanNam.Checked = false;
			toolStripMenuItem6.Checked = false;
			toolStripMenuItem5.Checked = false;
			this.muTangKinhCac.Checked = false;
		}
		else
		{
			this.muTayHo.Checked = (@class.Int32_60 == Class365.Int32_35);
			this.muNhiHai.Checked = (@class.Int32_60 == Class365.Int32_29);
			this.muNhanNam.Checked = (@class.Int32_60 == Class365.Int32_67);
			this.muTangKinhCac.Checked = true;
		}
		this.muDaTru.Checked = @class.List_0.Contains(Enum14.DatDoiDaTru);
		this.muKyCuoc.Checked = @class.List_0.Contains(Enum14.DatDoiKyCuoc);
		if (this.muKyCuoc.Checked)
		{
			this.muKyCuocCham.Checked = !@class.List_0.Contains(Enum14.KyCuocNhanh);
			this.muKyCuocNhanh.Checked = @class.List_0.Contains(Enum14.KyCuocNhanh);
		}
		else
		{
			ToolStripMenuItem toolStripMenuItem7 = this.muKyCuocCham;
			this.muKyCuocNhanh.Checked = false;
			toolStripMenuItem7.Checked = false;
		}
		this.muLauLanTamBao.Checked = @class.List_0.Contains(Enum14.DatDoiLauLanTamBao);
		if (this.muLauLanTamBao.Checked)
		{
			this.muLauLanTamBaoCham.Checked = !@class.List_0.Contains(Enum14.LauLanTamBaoNhanh);
			this.muLauLanTamBaoNhanh.Checked = @class.List_0.Contains(Enum14.LauLanTamBaoNhanh);
		}
		else
		{
			ToolStripMenuItem toolStripMenuItem8 = this.muLauLanTamBaoCham;
			this.muLauLanTamBaoNhanh.Checked = false;
			toolStripMenuItem8.Checked = false;
		}
		this.muMongHeo.Checked = @class.List_0.Contains(Enum14.DatDoiMongHeo);
		this.muThienGiangKyThu.Checked = @class.List_0.Contains(Enum14.DatDoiThienGiangKyThu);
		this.muPhungHoangLangMo.Checked = @class.List_0.Contains(Enum14.DatDoiPhungHoangLangMo);
		this.muDoanBaoMaTac.Checked = @class.List_0.Contains(Enum14.DatDoiMaTac);
		this.muBaoDoHiem.Checked = @class.List_0.Contains(Enum14.DatDoiBaoDoHiem);
		this.muQuanSonHai.Checked = @class.List_0.Contains(Enum14.DatDoiQuanSonHai);
		this.muTyVo.Checked = @class.List_0.Contains(Enum14.DatDoiTyVo);
		this.muTucCau.Checked = @class.List_0.Contains(Enum14.DatDoiTucCau);
		this.muQ1ToChau.Checked = (@class.Int32_5 == 1);
		this.muQ2ToChau.Checked = (@class.Int32_5 == 2);
		this.muQ12ToChau.Checked = (@class.Int32_5 == 3);
		this.muThuyLao.Checked = @class.Boolean_8;
		this.muPrivate.Checked = (this.muQ1ToChau.Checked || this.muQ2ToChau.Checked || this.muQ12ToChau.Checked || this.muThuyLao.Checked);
	}

	// Token: 0x06002084 RID: 8324 RVA: 0x00017BBB File Offset: 0x00015DBB
	private void muToanBoHangNgay_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_206));
	}

	// Token: 0x06002085 RID: 8325 RVA: 0x00017BD4 File Offset: 0x00015DD4
	private void muLoLyHoa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_207));
	}

	// Token: 0x06002086 RID: 8326 RVA: 0x00017BED File Offset: 0x00015DED
	private void muNhanPhiThuy_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_208));
	}

	// Token: 0x06002087 RID: 8327 RVA: 0x00017C06 File Offset: 0x00015E06
	private void muLuyenKimNhanh_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_209));
	}

	// Token: 0x06002088 RID: 8328 RVA: 0x00017C1F File Offset: 0x00015E1F
	private void muLuyenKimCham_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_210));
	}

	// Token: 0x06002089 RID: 8329 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_108(object sender, EventArgs e)
	{
	}

	// Token: 0x0600208A RID: 8330 RVA: 0x00017C38 File Offset: 0x00015E38
	private void muTrungAc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_211));
	}

	// Token: 0x0600208B RID: 8331 RVA: 0x00017C51 File Offset: 0x00015E51
	private void muCotTruyenToanBo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_212));
	}

	// Token: 0x0600208C RID: 8332 RVA: 0x00017C6A File Offset: 0x00015E6A
	private void muNhiemVuExp_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_213));
	}

	// Token: 0x0600208D RID: 8333 RVA: 0x00017C83 File Offset: 0x00015E83
	private void muNhiemVuKNB_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_214));
	}

	// Token: 0x0600208E RID: 8334 RVA: 0x00017C9C File Offset: 0x00015E9C
	private void muNgoChanNguyen_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_215));
	}

	// Token: 0x0600208F RID: 8335 RVA: 0x00017CB5 File Offset: 0x00015EB5
	private void muChinhTuyen_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_216));
	}

	// Token: 0x06002090 RID: 8336 RVA: 0x00017CCE File Offset: 0x00015ECE
	private void muSuMon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_217));
	}

	// Token: 0x06002091 RID: 8337 RVA: 0x00017CE7 File Offset: 0x00015EE7
	private void muMoBaoTangDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_218));
	}

	// Token: 0x06002092 RID: 8338 RVA: 0x00017D00 File Offset: 0x00015F00
	private void muTuDuong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_219));
	}

	// Token: 0x06002093 RID: 8339 RVA: 0x00017D19 File Offset: 0x00015F19
	private void muPhuMau_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_220));
	}

	// Token: 0x06002094 RID: 8340 RVA: 0x00017D32 File Offset: 0x00015F32
	private void muNhanCon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_221));
	}

	// Token: 0x06002095 RID: 8341 RVA: 0x00017D4B File Offset: 0x00015F4B
	private void muTuBaoBon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_222));
	}

	// Token: 0x06002096 RID: 8342 RVA: 0x00017D64 File Offset: 0x00015F64
	private void muThienKiepLau_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_223));
	}

	// Token: 0x06002097 RID: 8343 RVA: 0x00017D7D File Offset: 0x00015F7D
	private void muTiemNangTan_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_224));
	}

	// Token: 0x06002098 RID: 8344 RVA: 0x00017D96 File Offset: 0x00015F96
	private void muBachHoaDuyen_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_225));
	}

	// Token: 0x06002099 RID: 8345 RVA: 0x00017DAF File Offset: 0x00015FAF
	private void muThanhSangNhatHa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_226));
	}

	// Token: 0x0600209A RID: 8346 RVA: 0x00017DC8 File Offset: 0x00015FC8
	private void muSinhTieu_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_227));
	}

	// Token: 0x0600209B RID: 8347 RVA: 0x00002E18 File Offset: 0x00001018
	private void muLuyenKim_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x0600209C RID: 8348 RVA: 0x000EB2CC File Offset: 0x000E94CC
	private void method_109(object sender, EventArgs e)
	{
		Main.Class291 @class = new Main.Class291();
		@class.toolStripMenuItem_0 = (sender as ToolStripMenuItem);
		this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x0600209D RID: 8349 RVA: 0x000EB304 File Offset: 0x000E9504
	private void dailyToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
	{
		if (Main.class159_0 == null)
		{
			return;
		}
		this.muVanTieu.Checked = (Main.class159_0.Int32_6 != 0);
		this.muVanTieu1.Checked = (Main.class159_0.Int32_6 == 1);
		this.muVanTieu2.Checked = (Main.class159_0.Int32_6 == 2);
		this.muVanTieu3.Checked = (Main.class159_0.Int32_6 == 3);
		this.muVanTieu4.Checked = (Main.class159_0.Int32_6 == 4);
		this.muLoLyHoa.Checked = Main.class159_0.List_0.Contains(Enum14.LoLyHoa);
		this.muVanMay.Checked = Main.class159_0.List_0.Contains(Enum14.ThuTaiVanMay);
		this.muNguyenVong.Checked = Main.class159_0.List_0.Contains(Enum14.NguyenVongThienLinh);
		this.muNhanPhiThuy.Checked = Main.class159_0.List_0.Contains(Enum14.NhanPhiThuy);
		this.muTueHong.Checked = Main.class159_0.List_0.Contains(Enum14.ThienLongTueHong);
		this.muHangNgay.Checked = (this.muVanMay.Checked || this.muLoLyHoa.Checked || this.muNguyenVong.Checked || this.muNhanPhiThuy.Checked || this.muTueHong.Checked);
		this.muTrangSucCuuLe.Checked = Main.class159_0.List_0.Contains(Enum14.TrangSucCuuLe);
		this.muTamKy.Checked = Main.class159_0.List_0.Contains(Enum14.TamKy);
		this.muLuyenKim.Checked = (Main.class159_0.List_0.Contains(Enum14.LuyenKim) || Main.class159_0.List_0.Contains(Enum14.LuyenKimNhanh));
		this.muLuyenKimCham.Checked = Main.class159_0.List_0.Contains(Enum14.LuyenKim);
		this.muLuyenKimNhanh.Checked = Main.class159_0.List_0.Contains(Enum14.LuyenKimNhanh);
		this.muTrungAc.Checked = Main.class159_0.List_0.Contains(Enum14.TrungAc);
		this.muChinhTuyen.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuChinhTuyen);
		this.muVoY.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuVoY);
		this.muCotTruyenToanBo.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuThangCap);
		this.muNhiemVuExp.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuExp);
		this.muNgoChanNguyen.Checked = Main.class159_0.List_0.Contains(Enum14.NgoChanNguyen);
		this.muNhiemVuKNB.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuKNBKhoa);
		this.muCotTruyen.Checked = (this.muNgoChanNguyen.Checked || this.muCotTruyenToanBo.Checked || this.muNhiemVuExp.Checked || this.muNhiemVuKNB.Checked || this.muChinhTuyen.Checked || this.muVoY.Checked);
		this.muSuMon.Checked = Main.class159_0.List_0.Contains(Enum14.NhiemVuSuMon);
		this.muMoBaoTangDo.Checked = Main.class159_0.List_0.Contains(Enum14.MoBaoTangDo);
		this.muTuDuong.Checked = Main.class159_0.List_0.Contains(Enum14.TuDuongCon);
		this.muNhanCon.Checked = Main.class159_0.List_0.Contains(Enum14.NhanCon);
		this.muPhuMau.Checked = Main.class159_0.List_0.Contains(Enum14.LongPhuMau);
		this.muConCai.Checked = (this.muTuDuong.Checked || this.muNhanCon.Checked || this.muPhuMau.Checked);
		this.muTuBaoBon.Checked = Main.class159_0.List_0.Contains(Enum14.TuBaoBon);
		this.muThienKiepLau.Checked = Main.class159_0.List_0.Contains(Enum14.TruAc);
		this.muTiemNangTan.Checked = Main.class159_0.Boolean_90;
		this.muBachHoaDuyen.Checked = Main.class159_0.List_0.Contains(Enum14.BachHoaDuyen);
		this.muThanhSangNhatHa.Checked = Main.class159_0.Boolean_116;
		this.muSinhTieu.Checked = Main.class159_0.List_0.Contains(Enum14.SinhTieu);
		this.muThanKhi9Sao.Checked = Main.class159_0.List_0.Contains(Enum14.ThanKhi9Sao);
		this.muVoTuPho.Checked = Main.class159_0.List_0.Contains(Enum14.VoTuPho);
		this.muDungDoatBaoRuong.Checked = Main.class159_0.List_0.Contains(Enum14.DungDoatBaoRuong);
	}

	// Token: 0x0600209E RID: 8350 RVA: 0x00017DE1 File Offset: 0x00015FE1
	private void muTriLieu_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_228));
	}

	// Token: 0x0600209F RID: 8351 RVA: 0x00017DFA File Offset: 0x00015FFA
	private void muDiBanRac_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_229));
	}

	// Token: 0x060020A0 RID: 8352 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_110(object sender, EventArgs e)
	{
	}

	// Token: 0x060020A1 RID: 8353 RVA: 0x00017E13 File Offset: 0x00016013
	private void muTriLieuBanRacCatDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_35));
	}

	// Token: 0x060020A2 RID: 8354 RVA: 0x000EB7DC File Offset: 0x000E99DC
	private void gameToolStripMenuItem5_Click(object sender, EventArgs e)
	{
		int num = (sender as ToolStripMenuItem).Text.smethod_37();
		for (int i = 0; i < num; i++)
		{
			this.method_79();
		}
	}

	// Token: 0x060020A3 RID: 8355 RVA: 0x000EB80C File Offset: 0x000E9A0C
	private void playerToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
	{
		if (this.IEnumerable_3.Count<Class159>() == 0)
		{
			using (IEnumerator enumerator = this.playerToolStripMenuItem.DropDownItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					if (typeof(ToolStripMenuItem) == obj.GetType())
					{
						(obj as ToolStripMenuItem).Checked = false;
						foreach (object obj2 in (obj as ToolStripMenuItem).DropDownItems)
						{
							if (typeof(ToolStripMenuItem) == obj2.GetType())
							{
								(obj2 as ToolStripMenuItem).Checked = false;
							}
						}
					}
				}
				goto IL_3F9;
			}
		}
		this.muTriLieu.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_36)).Count<Class159>() == 0);
		this.muDiBanRac.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_37)).Count<Class159>() == 0);
		this.muCatDo.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_38)).Count<Class159>() == 0);
		this.muLayDo.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_39)).Count<Class159>() == 0);
		this.muLayDoLayVang.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_40)).Count<Class159>() == 0);
		if (this.muLayDoLayVang.Checked)
		{
			this.muLayDo.Checked = false;
		}
		this.muThuongKho.Checked = (this.muCatDo.Checked || this.muLayDo.Checked || this.muLayDoLayVang.Checked);
		this.muPhanGiaiTrangBijPet.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_41)).Count<Class159>() == 0);
		this.muNhanChienCongKiemChi.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_42)).Count<Class159>() == 0);
		this.muNhanThuongQuanSonHai.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_43)).Count<Class159>() == 0);
		this.muNhanBuaBaoRuong.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_44)).Count<Class159>() == 0);
		this.muNhanLeBao.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_45)).Count<Class159>() == 0);
		this.muNhanBong.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_46)).Count<Class159>() == 0);
		this.muNhanKeoHallowen.Checked = (this.IEnumerable_3.Where(new Func<Class159, bool>(Main.Class270.<>9.method_47)).Count<Class159>() == 0);
		IL_3F9:
		if (Main.class159_0 == null)
		{
			return;
		}
		this.muMua100KimSangDuoc.Checked = Main.class159_0.List_0.Contains(Enum14.Mua100KimSangDuoc);
		this.muLinhLuong.Checked = Main.class159_0.List_0.Contains(Enum14.LinhLuong);
		this.muTuLuyenTheLuc.Checked = Main.class159_0.List_0.Contains(Enum14.TuLuyenTheLuc);
		this.muTuLuyenNoiLuc.Checked = Main.class159_0.List_0.Contains(Enum14.TuLuyenNoiLuc);
		this.muTuLuyenThanPhap.Checked = Main.class159_0.List_0.Contains(Enum14.TuLuyenThanPhap);
		this.muTuLuyenCuongLuc.Checked = Main.class159_0.List_0.Contains(Enum14.TuLuyenCuongLuc);
		this.muDaiLeHungVuong.Checked = Main.class159_0.List_0.Contains(Enum14.DaiLeHungVuong);
		this.muDoi999HoaHong.Checked = Main.class159_0.List_0.Contains(Enum14.Doi999HoaHong);
		this.muNhanx2.Checked = Main.class159_0.List_0.Contains(Enum14.NhanX2);
		this.muDongx2.Checked = Main.class159_0.List_0.Contains(Enum14.DongX2);
		this.muDiMuaNgua.Checked = Main.class159_0.List_0.Contains(Enum14.DiMuaNga);
		this.muCheThanKhi.Checked = Main.class159_0.List_0.Contains(Enum14.CheThanKhi);
		this.muDoiKimTamTy.Checked = Main.class159_0.List_0.Contains(Enum14.DoiKimTamTy);
		this.muGiaoNguHanhPhapThiep.Checked = Main.class159_0.List_0.Contains(Enum14.GiaoNguHanhPhapThiep);
		this.muNopTuViHuyTinh.Checked = Main.class159_0.List_0.Contains(Enum14.NopTuViHuyTinh);
		this.muDoiLoanPhiMatHam.Checked = Main.class159_0.List_0.Contains(Enum14.DoiLoanPhiMatHam);
		this.muDoiChanNguyenLinhPhach.Checked = Main.class159_0.List_0.Contains(Enum14.DoiChanNguyenLinhPhach);
		this.muTangCapTruongThanhLongVan.Checked = Main.class159_0.List_0.Contains(Enum14.TangCapTruongThanhLongVan);
		this.muThanhLyNhiemVu.Checked = Main.class159_0.List_0.Contains(Enum14.ThanhLyNhiemVu);
		this.muDoiTiemNangTan.Checked = Main.class159_0.List_0.Contains(Enum14.DoiTiemNangTan);
		this.muDoiHuyenSacCauThienThai.Checked = Main.class159_0.List_0.Contains(Enum14.DoiHuyenSacCauThienThai);
		this.muSuaVoHon.Checked = Main.class159_0.List_0.Contains(Enum14.SuaVoHon);
		this.muSuaTrangBi.Checked = Main.class159_0.List_0.Contains(Enum14.SuaTrangBi);
		this.muSuaThanKhi.Checked = Main.class159_0.List_0.Contains(Enum14.SuaThanKhi);
		this.muMoShopTrungDo.Checked = Main.class159_0.List_0.Contains(Enum14.MoShopTrungDo);
		this.muMoShopHungBa.Checked = Main.class159_0.List_0.Contains(Enum14.MoShopHungBa);
		this.muMoShopQuyThi.Checked = Main.class159_0.List_0.Contains(Enum14.MoShopQuyThi);
		this.muMoShopBachBaoCac.Checked = Main.class159_0.List_0.Contains(Enum14.MoShopBachBaoCac);
		this.muMoTiemThuoc.Checked = Main.class159_0.List_0.Contains(Enum14.MoTiemThuoc);
		this.muMoShop.Checked = (this.muMoShopBachBaoCac.Checked || this.muMoShopHungBa.Checked || this.muMoShopQuyThi.Checked || this.muMoShopTrungDo.Checked || this.muMoTiemThuoc.Checked);
		this.muHuyVatPhamQuy.Checked = Main.class159_0.List_0.Contains(Enum14.HuyVatPhamQuy);
		this.muTrongHoa.Checked = Main.class159_0.List_0.Contains(Enum14.TrongHoa);
		this.muBonHoa.Checked = Main.class159_0.List_0.Contains(Enum14.BonHoa);
		this.muThuHoach.Checked = Main.class159_0.Boolean_115;
		this.muTuoiHoaHong.Checked = Main.class159_0.Boolean_113;
		this.muNhanQuaBuiHoa.Checked = Main.class159_0.List_0.Contains(Enum14.NhanQuaBuiHoaHong);
		this.muNhanHoaHongLo.Checked = Main.class159_0.List_0.Contains(Enum14.NhanHoaHongLo);
		this.muBHD.Checked = (this.muTrongHoa.Checked || this.muBonHoa.Checked || this.muThuHoach.Checked || this.muTuoiHoaHong.Checked || this.muNhanQuaBuiHoa.Checked || this.muNhanHoaHongLo.Checked);
		this.muNhanDoi.Checked = (this.muNhanx2.Checked || this.muDongx2.Checked || this.muDiMuaNgua.Checked || this.muHuyVatPhamQuy.Checked);
	}

	// Token: 0x060020A4 RID: 8356 RVA: 0x00017E3F File Offset: 0x0001603F
	private void muPhanGiaiTrangBijPet_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_230));
	}

	// Token: 0x060020A5 RID: 8357 RVA: 0x00017E58 File Offset: 0x00016058
	private void muVanMay_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_231));
	}

	// Token: 0x060020A6 RID: 8358 RVA: 0x00017E71 File Offset: 0x00016071
	private void muTueHong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_232));
	}

	// Token: 0x060020A7 RID: 8359 RVA: 0x00017E8A File Offset: 0x0001608A
	private void muNguyenVong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_233));
	}

	// Token: 0x060020A8 RID: 8360 RVA: 0x00017EA3 File Offset: 0x000160A3
	private void btnPk_Click(object sender, EventArgs e)
	{
		this.method_91(new TuyenChien());
	}

	// Token: 0x060020A9 RID: 8361 RVA: 0x00017EB0 File Offset: 0x000160B0
	private void checkTuyenChien_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_7)
		{
			return;
		}
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_234));
	}

	// Token: 0x060020AA RID: 8362 RVA: 0x000EC100 File Offset: 0x000EA300
	private void muTopMost_Click(object sender, EventArgs e)
	{
		base.TopMost = (this.muTopMost.Checked = !this.muTopMost.Checked);
	}

	// Token: 0x060020AB RID: 8363 RVA: 0x00017ED2 File Offset: 0x000160D2
	private void muNhanx2_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_235));
	}

	// Token: 0x060020AC RID: 8364 RVA: 0x00017EEB File Offset: 0x000160EB
	private void muDongx2_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_236));
	}

	// Token: 0x060020AD RID: 8365 RVA: 0x00017F04 File Offset: 0x00016104
	private void muDiMuaNgua_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_237));
	}

	// Token: 0x060020AE RID: 8366 RVA: 0x00017F1D File Offset: 0x0001611D
	private void muHuyVatPhamQuy_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_238));
	}

	// Token: 0x060020AF RID: 8367 RVA: 0x000EC130 File Offset: 0x000EA330
	private void muQ1ToChau_Click(object sender, EventArgs e)
	{
		Main.Class292 @class = new Main.Class292();
		@class.bool_0 = !this.muQ1ToChau.Checked;
		this.IEnumerable_2.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060020B0 RID: 8368 RVA: 0x000EC170 File Offset: 0x000EA370
	private void muQ2ToChau_Click(object sender, EventArgs e)
	{
		Main.Class293 @class = new Main.Class293();
		@class.bool_0 = !this.muQ2ToChau.Checked;
		this.IEnumerable_2.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060020B1 RID: 8369 RVA: 0x000EC1B0 File Offset: 0x000EA3B0
	private void muQ12ToChau_Click(object sender, EventArgs e)
	{
		Main.Class294 @class = new Main.Class294();
		@class.bool_0 = !this.muQ12ToChau.Checked;
		this.IEnumerable_2.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060020B2 RID: 8370 RVA: 0x000EC1F0 File Offset: 0x000EA3F0
	private void muThuyLao_Click(object sender, EventArgs e)
	{
		Main.Class295 @class = new Main.Class295();
		@class.bool_0 = !this.muThuyLao.Checked;
		this.IEnumerable_2.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060020B3 RID: 8371 RVA: 0x00017F36 File Offset: 0x00016136
	private void muCQThuCong_Click(object sender, EventArgs e)
	{
		this.btnCanQuetThuCong_Click(null, null);
	}

	// Token: 0x060020B4 RID: 8372 RVA: 0x00017F40 File Offset: 0x00016140
	private void muCQBinhThanhThuCong_Click(object sender, EventArgs e)
	{
		this.method_104(null, null);
	}

	// Token: 0x060020B5 RID: 8373 RVA: 0x000EC230 File Offset: 0x000EA430
	private void muCQPhucDiaKho_Click(object sender, EventArgs e)
	{
		Main.Class296 @class = new Main.Class296();
		@class.int_0 = Class426.smethod_43((sender as ToolStripMenuItem).Tag.ToString());
		this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060020B6 RID: 8374 RVA: 0x00017F4A File Offset: 0x0001614A
	private void muTrongHoa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_239));
	}

	// Token: 0x060020B7 RID: 8375 RVA: 0x00017F63 File Offset: 0x00016163
	private void muBonHoa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_240));
	}

	// Token: 0x060020B8 RID: 8376 RVA: 0x00017F7C File Offset: 0x0001617C
	private void muThuHoach_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_241));
	}

	// Token: 0x060020B9 RID: 8377 RVA: 0x00017F95 File Offset: 0x00016195
	private void muTuoiHoaHong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_242));
	}

	// Token: 0x060020BA RID: 8378 RVA: 0x00017FAE File Offset: 0x000161AE
	private void muNhanQuaBuiHoa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_243));
	}

	// Token: 0x060020BB RID: 8379 RVA: 0x00017FC7 File Offset: 0x000161C7
	private void muNhanHoaHongLo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_244));
	}

	// Token: 0x060020BC RID: 8380 RVA: 0x00002E18 File Offset: 0x00001018
	private void menuNier_DropDownOpening(object sender, EventArgs e)
	{
	}

	// Token: 0x060020BD RID: 8381 RVA: 0x00017FE0 File Offset: 0x000161E0
	private void method_111(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_48));
	}

	// Token: 0x060020BE RID: 8382 RVA: 0x0001800C File Offset: 0x0001620C
	private void method_112(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_49));
	}

	// Token: 0x060020BF RID: 8383 RVA: 0x00018038 File Offset: 0x00016238
	private void method_113(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_50));
	}

	// Token: 0x060020C0 RID: 8384 RVA: 0x00018064 File Offset: 0x00016264
	private void method_114(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_51));
	}

	// Token: 0x060020C1 RID: 8385 RVA: 0x00018090 File Offset: 0x00016290
	private void method_115(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_52));
	}

	// Token: 0x060020C2 RID: 8386 RVA: 0x000180BC File Offset: 0x000162BC
	private void method_116(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_53));
	}

	// Token: 0x060020C3 RID: 8387 RVA: 0x000180E8 File Offset: 0x000162E8
	private void method_117(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_54));
	}

	// Token: 0x060020C4 RID: 8388 RVA: 0x00018114 File Offset: 0x00016314
	private void method_118(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_55));
	}

	// Token: 0x060020C5 RID: 8389 RVA: 0x00018140 File Offset: 0x00016340
	private void muQuayVeDaiLy_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_56));
	}

	// Token: 0x060020C6 RID: 8390 RVA: 0x0001816C File Offset: 0x0001636C
	private void method_119(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_57));
	}

	// Token: 0x060020C7 RID: 8391 RVA: 0x00018198 File Offset: 0x00016398
	private void method_120(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_58));
	}

	// Token: 0x060020C8 RID: 8392 RVA: 0x000181C4 File Offset: 0x000163C4
	private void method_121(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_59));
	}

	// Token: 0x060020C9 RID: 8393 RVA: 0x000181F0 File Offset: 0x000163F0
	private void method_122(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_60));
	}

	// Token: 0x060020CA RID: 8394 RVA: 0x0001821C File Offset: 0x0001641C
	private void method_123(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_61));
	}

	// Token: 0x060020CB RID: 8395 RVA: 0x000EC278 File Offset: 0x000EA478
	private void muDemBut_Click(object sender, EventArgs e)
	{
		int num = 0;
		int num2 = 0;
		foreach (Class159 @class in this.IEnumerable_3)
		{
			num++;
			foreach (Class209 class2 in @class.Class196_0.IEnumerable_0.Concat(@class.Class196_0.IEnumerable_4))
			{
				if (class2.String_3 == "chucphucmaobut")
				{
					num2 += (int)class2.UInt32_5;
				}
			}
		}
		string text = string.Concat(new string[]
		{
			"Có ",
			num.ToString(),
			" game có ",
			num2.ToString(),
			" bút"
		});
		MessageBox.Show(this, text, "MicroAuto", MessageBoxButtons.OK);
	}

	// Token: 0x060020CC RID: 8396 RVA: 0x00018248 File Offset: 0x00016448
	private void muChucPhuc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_245));
	}

	// Token: 0x060020CD RID: 8397 RVA: 0x00018261 File Offset: 0x00016461
	private void muKetNghia_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_246));
	}

	// Token: 0x060020CE RID: 8398 RVA: 0x0001827A File Offset: 0x0001647A
	private void muChucPhucTuBaoBon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_62));
	}

	// Token: 0x060020CF RID: 8399 RVA: 0x000EC380 File Offset: 0x000EA580
	private void muAutoMap_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.Class298 @class = new Main.Class298();
			AutoMap autoMap = new AutoMap(Main.class159_0)
			{
				Dock = DockStyle.Fill
			};
			@class.tabPage_0 = new TabPage("AutoMap");
			this.tabCanQuet.TabPages.Add(@class.tabPage_0);
			@class.tabPage_0.Controls.Add(autoMap);
			autoMap.Disposed += @class.method_0;
			this.tabCanQuet.Visible = true;
			this.tabCanQuet.BringToFront();
			this.tabCanQuet.SelectedTab = @class.tabPage_0;
		}
	}

	// Token: 0x060020D0 RID: 8400 RVA: 0x000EC420 File Offset: 0x000EA620
	private void method_124(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_226();
		}
	}

	// Token: 0x060020D1 RID: 8401 RVA: 0x000182A6 File Offset: 0x000164A6
	private void muNhapCode_Click(object sender, EventArgs e)
	{
		new Code().Show(this);
	}

	// Token: 0x060020D2 RID: 8402 RVA: 0x000182B3 File Offset: 0x000164B3
	private void method_125(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_37))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x060020D3 RID: 8403 RVA: 0x000182D2 File Offset: 0x000164D2
	private void method_126(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_36))
		{
			IsBackground = true
		}.Start();
	}

	// Token: 0x060020D4 RID: 8404 RVA: 0x000EC46C File Offset: 0x000EA66C
	private void method_127(object sender, EventArgs e)
	{
		if (MessageBox.Show(this, "Bạn có muốn thoát  toàn bộ  Game", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.No)
		{
			return;
		}
		try
		{
			foreach (object obj in this.Lv.Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				Main.Class299 @class = new Main.Class299();
				@class.class159_0 = (listViewItem.Tag as Class159);
				new Thread(new ThreadStart(@class.method_0)).Start();
			}
		}
		catch
		{
		}
	}

	// Token: 0x060020D5 RID: 8405 RVA: 0x000EC518 File Offset: 0x000EA718
	private void refreshToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		foreach (Class159 class159_ in this.IEnumerable_5.ToList<Class159>())
		{
			this.method_33(class159_);
		}
	}

	// Token: 0x060020D6 RID: 8406 RVA: 0x000182F1 File Offset: 0x000164F1
	private void toolStripMenuItem_7_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_63));
	}

	// Token: 0x060020D7 RID: 8407 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_128(object sender, EventArgs e)
	{
	}

	// Token: 0x060020D8 RID: 8408 RVA: 0x000EC574 File Offset: 0x000EA774
	private void method_129(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.method_173();
		}
	}

	// Token: 0x060020D9 RID: 8409 RVA: 0x00018322 File Offset: 0x00016522
	private void toolStripMenuItem_8_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_64));
	}

	// Token: 0x060020DA RID: 8410 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_130(object sender, EventArgs e)
	{
	}

	// Token: 0x060020DB RID: 8411 RVA: 0x00018353 File Offset: 0x00016553
	private void method_131(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_65));
	}

	// Token: 0x060020DC RID: 8412 RVA: 0x00018384 File Offset: 0x00016584
	private void menuPause_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060020DD RID: 8413 RVA: 0x000EC5C0 File Offset: 0x000EA7C0
	private void menuPausedSkill_Click(object sender, EventArgs e)
	{
		Main.bool_22 = (this.menuPausedSkill.Checked = !this.menuPausedSkill.Checked);
	}

	// Token: 0x060020DE RID: 8414 RVA: 0x000E7ADC File Offset: 0x000E5CDC
	private void menuPickItem_Click(object sender, EventArgs e)
	{
		Class268.bool_80 = (this.menuPickItem.Checked = !this.menuPickItem.Checked);
	}

	// Token: 0x060020DF RID: 8415 RVA: 0x000E7B0C File Offset: 0x000E5D0C
	private void menuItemFillter_Click(object sender, EventArgs e)
	{
		Class268.bool_75 = (this.menuItemFillter.Checked = !this.menuItemFillter.Checked);
	}

	// Token: 0x060020E0 RID: 8416 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_132(object sender, EventArgs e)
	{
	}

	// Token: 0x060020E1 RID: 8417 RVA: 0x000EC5F0 File Offset: 0x000EA7F0
	private void menuAtkFollowKey_Click(object sender, EventArgs e)
	{
		Class268.bool_76 = (this.menuAtkFollowKey.Checked = !this.menuAtkFollowKey.Checked);
	}

	// Token: 0x060020E2 RID: 8418 RVA: 0x000EC620 File Offset: 0x000EA820
	private void menuFollowKey_Click(object sender, EventArgs e)
	{
		Class268.bool_83 = (this.menuFollowKey.Checked = !this.menuFollowKey.Checked);
	}

	// Token: 0x060020E3 RID: 8419 RVA: 0x0001838C File Offset: 0x0001658C
	private void autoPKToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (this.autoPK_0 == null || this.autoPK_0.IsDisposed)
		{
			this.autoPK_0 = new AutoPK();
			this.autoPK_0.Show();
			Class438.smethod_6(this.autoPK_0);
		}
	}

	// Token: 0x060020E4 RID: 8420 RVA: 0x000183C4 File Offset: 0x000165C4
	private void method_133(object sender, EventArgs e)
	{
		if (!this.pk_0.Visible)
		{
			this.pk_0 = new Pk();
			this.pk_0.Show(this);
		}
	}

	// Token: 0x060020E5 RID: 8421 RVA: 0x000183EA File Offset: 0x000165EA
	private void method_134(object sender, EventArgs e)
	{
		this.method_77();
	}

	// Token: 0x060020E6 RID: 8422 RVA: 0x000EC650 File Offset: 0x000EA850
	private void method_135(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.Items)
		{
			Class159 @class = (Class159)((ListViewItem)obj).Tag;
			if (@class.Class432_0.Boolean_34)
			{
				if (@class.Class432_0.Boolean_32)
				{
					@class.Boolean_84 = true;
				}
				if (@class.Class432_0.UInt32_28 == 10U)
				{
					@class.Boolean_85 = true;
				}
				@class.Boolean_32 = false;
				@class.method_296();
			}
		}
	}

	// Token: 0x060020E7 RID: 8423 RVA: 0x000183F2 File Offset: 0x000165F2
	private void toolStripMenuItem_9_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_66));
	}

	// Token: 0x060020E8 RID: 8424 RVA: 0x000EC6F8 File Offset: 0x000EA8F8
	private void method_136(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.Items)
		{
			((ListViewItem)obj).Selected = true;
		}
	}

	// Token: 0x060020E9 RID: 8425 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_137(object sender, EventArgs e)
	{
	}

	// Token: 0x060020EA RID: 8426 RVA: 0x00018423 File Offset: 0x00016623
	private void method_138(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_67));
	}

	// Token: 0x060020EB RID: 8427 RVA: 0x0001844F File Offset: 0x0001664F
	private void method_139(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_68));
	}

	// Token: 0x060020EC RID: 8428 RVA: 0x00018480 File Offset: 0x00016680
	private void method_140(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_69));
	}

	// Token: 0x060020ED RID: 8429 RVA: 0x000184B1 File Offset: 0x000166B1
	private void method_141(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_70));
	}

	// Token: 0x060020EE RID: 8430 RVA: 0x000184E2 File Offset: 0x000166E2
	private void method_142(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_71));
	}

	// Token: 0x060020EF RID: 8431 RVA: 0x00018513 File Offset: 0x00016713
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.listViewSkill.method_1(this.txtSearchName.Text);
	}

	// Token: 0x060020F0 RID: 8432 RVA: 0x0001852C File Offset: 0x0001672C
	private void muTrimRam_Click(object sender, EventArgs e)
	{
		this.muTrimRam.Checked = (Main.bool_19 = !this.muTrimRam.Checked);
	}

	// Token: 0x060020F1 RID: 8433 RVA: 0x0001854D File Offset: 0x0001674D
	private void muTrimRam_DropDownOpening(object sender, EventArgs e)
	{
		this.muTrimRam.Checked = Main.bool_19;
	}

	// Token: 0x060020F2 RID: 8434 RVA: 0x000EC758 File Offset: 0x000EA958
	private void timer_5_Tick(object sender, EventArgs e)
	{
		this.Boolean_7 = true;
		try
		{
			if (Main.class159_0.Single_1 > 0f)
			{
				this.lblRadius.Text = string.Concat(new string[]
				{
					"[",
					((int)Main.class159_0.Single_1).ToString(),
					",",
					((int)Main.class159_0.Single_2).ToString(),
					"] (",
					Main.class159_0.Int32_29.ToString(),
					")"
				});
			}
			else
			{
				this.lblRadius.Text = "[0,0] (0)";
			}
			this.method_143();
			this.listViewSkill.method_0();
			this.listViewSkill.ItemChecked -= this.listViewSkill_ItemChecked;
			this.listViewSkill.ListViewItemSorter = null;
			this.listViewSkill.Items.Clear();
			List<ListViewItem> list = new List<ListViewItem>();
			foreach (Class417 @class in Main.class159_0.List_1)
			{
				if (@class.String_0 != "")
				{
					list.Add(new ListViewItem(@class.String_0)
					{
						Tag = @class,
						Text = @class.String_0,
						SubItems = 
						{
							@class.Boolean_0 ? "X" : ""
						},
						Checked = @class.Boolean_1
					});
				}
			}
			this.listViewSkill.Items.AddRange(list.ToArray());
			this.listViewSkill.ListViewItemSorter = new Class423();
			this.listViewSkill.Sort();
			this.listViewSkill.ItemChecked += this.listViewSkill_ItemChecked;
			if (Main.class159_0 != null)
			{
				this.lblTrain.Text = (Main.class159_0.String_26 ?? "");
			}
			if (Main.class159_0 == null)
			{
				return;
			}
			try
			{
				this.lvConfig.Items[0].Checked = Main.class159_0.bool_28;
				this.lvConfig.Items[1].Checked = Main.class159_0.Boolean_5;
				this.lvConfig.Items[2].Checked = Main.class159_0.Boolean_6;
				this.lvConfig.Items[3].Checked = Main.class159_0.Boolean_18;
				this.lvConfig.Items[4].Checked = Main.class159_0.bool_29;
				this.lvConfig.Items[5].Checked = Main.class159_0.Boolean_100;
				for (int i = 0; i < 22; i++)
				{
					this.lvConfig.Items[i + 6].SubItems[1].Text = Main.class159_0.Int32_11[i].ToString();
				}
				for (int j = 0; j < 12; j++)
				{
					this.lvConfig.Items[j + 6].Checked = Main.class159_0.Boolean_15[j];
				}
				for (int k = 0; k < 9; k++)
				{
					this.lvConfig.Items[k + 18].Checked = Main.class159_0.Boolean_14[k + 1];
				}
				this.lvConfig.Items[27].Checked = Main.class159_0.Boolean_14[0];
				this.checkChiDanh.Checked = Main.class159_0.Boolean_72;
				this.checkChiNhat.Checked = Main.class159_0.Boolean_30;
				this.checkQuyCoc.Checked = Main.class159_0.bool_23;
				this.checkMuaKNB.Checked = Main.class159_0.List_0.Contains(Enum14.AutoBuyKNB);
				this.checkChetLenBai.Checked = Main.class159_0.Boolean_79;
				this.txtPass2.Text = Main.class159_0.String_6;
				this.checkTuyenChien.Checked = Main.class159_0.Boolean_73;
				this.checkTimQuai.Checked = Main.class159_0.bool_17;
				this.checkLuaQuai.Checked = Main.class159_0.Boolean_17;
				this.checkPet.Checked = Main.class159_0.bool_19;
				this.checkHP.Checked = Main.class159_0.bool_20;
				this.checkMP.Checked = Main.class159_0.bool_21;
				this.checkNM.Checked = Main.class159_0.bool_22;
				this.chkBinhThanh.Checked = Main.class159_0.List_0.Contains(Enum14.DatDoiBinhThanh);
				if (Main.class159_0.Class432_0.Boolean_29)
				{
					this.nudRadius.Value = Class268.int_23;
				}
				else
				{
					this.nudRadius.Value = Class268.int_22;
				}
				this.chkRaoVat.Checked = Main.class159_0.bool_24;
				this.txtRao.Text = Main.class159_0.String_8;
				this.checkKhaiKhoang.Checked = Main.class159_0.List_0.Contains(Enum14.KhaiKhoang);
				this.checkHaiDuoc.Checked = Main.class159_0.List_0.Contains(Enum14.HaiDuoc);
				this.checkTrongTrot.Checked = Main.class159_0.List_0.Contains(Enum14.TrongTrot);
				this.checkThuHoach.Checked = Main.class159_0.Boolean_7;
				this.cboTrongTrot.SelectedIndex = Main.class159_0.int_19;
				this.cboThuHoach.SelectedIndex = Main.class159_0.int_20;
				this.checkXuatPet.Checked = Main.class159_0.Boolean_31;
				this.cboXuatPet.Items.Clear();
				Main.Class269 class2 = new Main.Class269();
				class2.String_0 = "Không Xuất";
				class2.Int32_0 = 0;
				this.cboXuatPet.Items.Add(class2);
				int num = -1;
				int num2 = 0;
				foreach (KeyValuePair<uint, string> keyValuePair in Main.class159_0.Class432_0.Dictionary_0)
				{
					num2++;
					Main.Class269 class3 = new Main.Class269();
					class3.String_0 = keyValuePair.Value;
					class3.Int32_0 = (int)keyValuePair.Key;
					if (keyValuePair.Key.ToString("X8") == Main.class159_0.String_29)
					{
						num = num2;
					}
					this.cboXuatPet.Items.Add(class3);
				}
				if (num != -1)
				{
					this.cboXuatPet.SelectedIndex = num;
				}
				this.cboLoai.SelectedIndex = Main.class159_0.int_91;
				this.cboCap.SelectedIndex = Main.class159_0.int_92;
				if (Main.class159_0.int_93 == 1)
				{
					this.radNoi.Checked = true;
				}
				else if (Main.class159_0.int_93 == 2)
				{
					this.radNgoai.Checked = true;
				}
				else
				{
					this.radNoiNgoai.Checked = true;
				}
				this.nudStar.Value = Main.class159_0.int_94;
				this.nudLine.Value = Main.class159_0.int_95;
				this.nudPoint.Value = Main.class159_0.int_96;
				this.chkStartCraft.Checked = Main.class159_0.bool_129;
				this.checkBanKinh.Checked = (Main.class159_0.Single_1 != 0f);
				this.numberThuHoaX.Value = Main.class159_0.Int32_68;
				this.numberRadiusThuHoa.Value = Main.class159_0.Int32_69;
			}
			catch
			{
			}
		}
		catch
		{
		}
		this.Boolean_7 = false;
		this.timer_5.Stop();
	}

	// Token: 0x060020F3 RID: 8435 RVA: 0x0001855F File Offset: 0x0001675F
	private void toolStripMenuItem_10_Click(object sender, EventArgs e)
	{
		base.Activate();
		Class438.smethod_7(base.Handle);
	}

	// Token: 0x060020F4 RID: 8436 RVA: 0x00018572 File Offset: 0x00016772
	private void timer_6_Tick(object sender, EventArgs e)
	{
		this.method_143();
	}

	// Token: 0x060020F5 RID: 8437 RVA: 0x000ECFE4 File Offset: 0x000EB1E4
	private void method_143()
	{
		this.Boolean_6 = true;
		if (Main.class159_0 != null)
		{
			this.chkBinhThanh.Checked = Main.class159_0.List_0.Contains(Enum14.DatDoiBinhThanh);
			this.chkKho.Checked = Main.class159_0.List_0.Contains(Enum14.BinhThanhKho);
		}
		else
		{
			this.chkBinhThanh.Checked = false;
			this.chkKho.Checked = false;
		}
		if (this.IEnumerable_2.Count<Class159>() > 0)
		{
			Class159 @class = this.IEnumerable_2.FirstOrDefault<Class159>();
			this.chkPhieuMieuPhong.Checked = @class.List_0.Contains(Enum14.DatDoiPhieuMieuPhong);
			this.chkHuyetChien.Checked = @class.List_0.Contains(Enum14.DatDoiKhieuChienPhieuMieuPhong);
			this.chkYenTuO.Checked = @class.List_0.Contains(Enum14.DatDoiYenTuO);
			this.chkTuTuyetTrang.Checked = @class.List_0.Contains(Enum14.DatDoiTuTuyetTrang);
			this.chkThieuThatSon.Checked = @class.List_0.Contains(Enum14.DatDoiThieuThatSon);
			this.chkSatTinh.Checked = @class.List_0.Contains(Enum14.DatDoiSatTinh);
			this.chkQLauLan.Checked = @class.List_0.Contains(Enum14.DatDoiQ123LauLan);
			this.chkQToChau.Checked = @class.List_0.Contains(Enum14.DatDoiQ123ToChau);
			this.chkPhucDia.Checked = @class.List_0.Contains(Enum14.DatDoiPhucDia);
			this.chkPDKho.Checked = (@class.List_0.Contains(Enum14.DatDoiPhucDia) && @class.List_0.Contains(Enum14.PhucDiaKho));
			this.chkVuongLang.Checked = @class.List_0.Contains(Enum14.DatDoiVuongLang);
			this.chkTamThan.Checked = @class.List_0.Contains(Enum14.DatDoiTamThan);
		}
		else
		{
			this.chkPhieuMieuPhong.Checked = false;
			this.chkHuyetChien.Checked = false;
			this.chkYenTuO.Checked = false;
			this.chkTuTuyetTrang.Checked = false;
			this.chkThieuThatSon.Checked = false;
			this.chkSatTinh.Checked = false;
			this.chkQLauLan.Checked = false;
			this.chkQToChau.Checked = false;
			this.chkPhucDia.Checked = false;
			this.chkPDKho.Checked = false;
			this.chkVuongLang.Checked = false;
			this.chkTamThan.Checked = false;
		}
		this.Boolean_6 = false;
	}

	// Token: 0x060020F6 RID: 8438 RVA: 0x0001857A File Offset: 0x0001677A
	private void chkSatTinh_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_247));
	}

	// Token: 0x060020F7 RID: 8439 RVA: 0x0001859C File Offset: 0x0001679C
	private void chkPhieuMieuPhong_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_248));
	}

	// Token: 0x060020F8 RID: 8440 RVA: 0x000185BE File Offset: 0x000167BE
	private void chkHuyetChien_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_249));
	}

	// Token: 0x060020F9 RID: 8441 RVA: 0x000185E0 File Offset: 0x000167E0
	private void chkYenTuO_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_250));
	}

	// Token: 0x060020FA RID: 8442 RVA: 0x00018602 File Offset: 0x00016802
	private void chkTuTuyetTrang_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_251));
	}

	// Token: 0x060020FB RID: 8443 RVA: 0x00018624 File Offset: 0x00016824
	private void chkThieuThatSon_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_252));
	}

	// Token: 0x060020FC RID: 8444 RVA: 0x00018646 File Offset: 0x00016846
	private void chkPhucDia_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_253));
	}

	// Token: 0x060020FD RID: 8445 RVA: 0x00018668 File Offset: 0x00016868
	private void chkPDKho_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.chkPhucDia.Checked = true;
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_254));
	}

	// Token: 0x060020FE RID: 8446 RVA: 0x00018696 File Offset: 0x00016896
	private void chkQLauLan_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_255));
	}

	// Token: 0x060020FF RID: 8447 RVA: 0x000186B8 File Offset: 0x000168B8
	private void chkQToChau_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_256));
	}

	// Token: 0x06002100 RID: 8448 RVA: 0x000186DA File Offset: 0x000168DA
	private void chkVuongLang_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_257));
	}

	// Token: 0x06002101 RID: 8449 RVA: 0x000186FC File Offset: 0x000168FC
	private void chkTamThan_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_258));
	}

	// Token: 0x06002102 RID: 8450 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_144(object sender, EventArgs e)
	{
	}

	// Token: 0x06002103 RID: 8451 RVA: 0x0001871E File Offset: 0x0001691E
	private void method_145(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_72));
	}

	// Token: 0x06002104 RID: 8452 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_146(object sender, UICuesEventArgs e)
	{
	}

	// Token: 0x06002105 RID: 8453 RVA: 0x000ED23C File Offset: 0x000EB43C
	private void toolStripMenuItem_11_Click(object sender, EventArgs e)
	{
		for (int i = 0; i < 12 - Main.dictionary_3.Count; i++)
		{
			this.method_79();
		}
	}

	// Token: 0x06002106 RID: 8454 RVA: 0x000ED268 File Offset: 0x000EB468
	private void muForceFollow_Click(object sender, EventArgs e)
	{
		Class268.bool_82 = (this.muForceFollow.Checked = !this.muForceFollow.Checked);
	}

	// Token: 0x06002107 RID: 8455 RVA: 0x0001874A File Offset: 0x0001694A
	private void method_147(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_73));
	}

	// Token: 0x06002108 RID: 8456 RVA: 0x00018776 File Offset: 0x00016976
	private void traderToolStripMenuItem_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			new Trader(Main.class159_0).Show(this);
		}
	}

	// Token: 0x06002109 RID: 8457 RVA: 0x0001878F File Offset: 0x0001698F
	private void muDoanBaoMaTac_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_259));
	}

	// Token: 0x1700075B RID: 1883
	// (get) Token: 0x0600210A RID: 8458 RVA: 0x000187A8 File Offset: 0x000169A8
	// (set) Token: 0x0600210B RID: 8459 RVA: 0x000187AF File Offset: 0x000169AF
	public static bool Boolean_16 { get; set; }

	// Token: 0x0600210C RID: 8460 RVA: 0x000ED298 File Offset: 0x000EB498
	private void muMute_Click(object sender, EventArgs e)
	{
		Main.Boolean_16 = (this.muMute.Checked = !this.muMute.Checked);
	}

	// Token: 0x0600210D RID: 8461 RVA: 0x000187B7 File Offset: 0x000169B7
	private void toolStripMenuItem_12_Click(object sender, EventArgs e)
	{
		new FastMove().Show(this);
	}

	// Token: 0x0600210E RID: 8462 RVA: 0x000187C4 File Offset: 0x000169C4
	private void toolStripMenuItem_13_Click(object sender, EventArgs e)
	{
		if (User.string_0 == "hungcatpth0802@gmail.com" || User.string_0 == "lecaotri@yahoo.com")
		{
			this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_260));
		}
	}

	// Token: 0x0600210F RID: 8463 RVA: 0x000ED2C8 File Offset: 0x000EB4C8
	private void toolStripMenuItem_14_Click(object sender, EventArgs e)
	{
		using (IEnumerator<Class159> enumerator = this.IEnumerable_3.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Main.Class300 @class = new Main.Class300();
				@class.class159_0 = enumerator.Current;
				Task.Run(new Action(@class.method_0));
			}
		}
	}

	// Token: 0x06002110 RID: 8464 RVA: 0x000ED32C File Offset: 0x000EB52C
	private void mnuKetNghia_Click(object sender, EventArgs e)
	{
		if (this.Lv.SelectedItems.Count > 1)
		{
			this.timer_3.Start();
			Main.int_9 = Class380.int_1;
			Class268.list_0.Clear();
			foreach (object obj in this.Lv.SelectedItems)
			{
				Class159 @class = (Class159)((ListViewItem)obj).Tag;
				this.mnuKetNghia.Checked = (@class.Boolean_81 = !@class.Boolean_81);
				@class.string_23 = "";
				Class268.list_0.Add(@class.Class432_0.String_2);
			}
			return;
		}
	}

	// Token: 0x06002111 RID: 8465 RVA: 0x000ED404 File Offset: 0x000EB604
	private void mnuKeBaiSudo_Click(object sender, EventArgs e)
	{
		if (this.Lv.SelectedItems.Count > 1)
		{
			this.timer_3.Start();
			Main.int_9 = Class380.int_1;
			Class268.list_1.Clear();
			foreach (object obj in this.Lv.SelectedItems)
			{
				Class159 @class = (Class159)((ListViewItem)obj).Tag;
				this.mnuKeBaiSudo.Checked = (@class.Boolean_82 = !@class.Boolean_82);
				@class.string_24 = "";
				Class268.list_1.Add(@class.Class432_0.String_2);
			}
			return;
		}
	}

	// Token: 0x06002112 RID: 8466 RVA: 0x000ED4DC File Offset: 0x000EB6DC
	private void method_148(object sender, EventArgs e)
	{
		if (User.string_0 == "xuanyen1112@gmail.com" || User.string_0 == "lecaotri@yahoo.com")
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_74));
		}
	}

	// Token: 0x06002113 RID: 8467 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_149(object sender, EventArgs e)
	{
	}

	// Token: 0x06002114 RID: 8468 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_150(object sender, EventArgs e)
	{
	}

	// Token: 0x06002115 RID: 8469 RVA: 0x000ED538 File Offset: 0x000EB738
	private void menuRefreshAuto_Click(object sender, EventArgs e)
	{
		foreach (Class159 class159_ in this.IEnumerable_3)
		{
			this.method_33(class159_);
		}
	}

	// Token: 0x06002116 RID: 8470 RVA: 0x000ED588 File Offset: 0x000EB788
	private void toolStripMenuItem_15_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.SelectedItems)
		{
			(((ListViewItem)obj).Tag as Class159).method_48(Enum14.DungDinhViPhu, true);
		}
	}

	// Token: 0x06002117 RID: 8471 RVA: 0x000187FF File Offset: 0x000169FF
	private void configToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.method_91(new ConfigBossMap());
	}

	// Token: 0x06002118 RID: 8472 RVA: 0x000ED5F4 File Offset: 0x000EB7F4
	private void method_151(object sender, EventArgs e)
	{
		try
		{
			bool flag = true;
			do
			{
				flag = false;
				foreach (object obj in this.bossMapToolStripMenuItem.DropDownItems)
				{
					ToolStripItem toolStripItem = (ToolStripItem)obj;
					if (toolStripItem.Tag != null && !string.IsNullOrEmpty(toolStripItem.Tag.ToString().Trim()))
					{
						toolStripItem.Dispose();
						flag = true;
						break;
					}
				}
			}
			while (flag);
			List<ToolStripMenuItem> list = new List<ToolStripMenuItem>();
			foreach (Class219 @class in Class159.Class220_0["BossMap"])
			{
				int num = -1;
				if (int.TryParse(@class.String_0, out num) && Class363.dictionary_4.ContainsKey(num))
				{
					string text = Class363.dictionary_4[num];
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem();
					toolStripMenuItem.Text = text;
					toolStripMenuItem.Tag = num;
					toolStripMenuItem.Click += this.method_152;
					list.Add(toolStripMenuItem);
				}
			}
			if (list.Count > 0)
			{
				this.bossMapToolStripMenuItem.DropDownItems.Add(new ToolStripSeparator
				{
					Tag = "user"
				});
			}
			ToolStripItemCollection dropDownItems = this.bossMapToolStripMenuItem.DropDownItems;
			ToolStripItem[] toolStripItems = list.ToArray();
			dropDownItems.AddRange(toolStripItems);
		}
		catch
		{
		}
	}

	// Token: 0x06002119 RID: 8473 RVA: 0x000ED7AC File Offset: 0x000EB9AC
	private void method_152(object sender, EventArgs e)
	{
		Main.Class301 @class = new Main.Class301();
		@class.object_0 = sender;
		this.IEnumerable_2.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x0600211A RID: 8474 RVA: 0x000ED7E0 File Offset: 0x000EB9E0
	private void bossMapToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
	{
		foreach (object obj in this.bossMapToolStripMenuItem.DropDownItems)
		{
			if (typeof(ToolStripMenuItem) == obj.GetType())
			{
				ToolStripMenuItem toolStripMenuItem = obj as ToolStripMenuItem;
				if (toolStripMenuItem.Tag != null)
				{
					if (Main.class159_0 != null && Main.class159_0.Int32_46 == Class426.smethod_41(toolStripMenuItem.Tag.ToString()) && Main.class159_0.List_0.Contains(Enum14.DatDoiBossMap))
					{
						toolStripMenuItem.Checked = true;
					}
					else
					{
						toolStripMenuItem.Checked = false;
					}
				}
			}
		}
	}

	// Token: 0x0600211B RID: 8475 RVA: 0x0001880C File Offset: 0x00016A0C
	private void muThanKhi9Sao_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_261));
	}

	// Token: 0x1700075C RID: 1884
	// (get) Token: 0x0600211C RID: 8476 RVA: 0x00018825 File Offset: 0x00016A25
	// (set) Token: 0x0600211D RID: 8477 RVA: 0x0001882C File Offset: 0x00016A2C
	public static bool Boolean_17 { get; set; }

	// Token: 0x0600211E RID: 8478 RVA: 0x000ED8A0 File Offset: 0x000EBAA0
	private void toolStripMenuItem_16_Click(object sender, EventArgs e)
	{
		Main.Boolean_17 = (this.toolStripMenuItem_16.Checked = !this.toolStripMenuItem_16.Checked);
	}

	// Token: 0x0600211F RID: 8479 RVA: 0x000ED8D0 File Offset: 0x000EBAD0
	private void method_153(object sender, EventArgs e)
	{
		Main.Class302 @class = new Main.Class302();
		@class.main_0 = this;
		if (MessageBox.Show(this, "Việc này sẽ tải thiết lập auto trong máy bạn lên máy chủ\r\n=>Ngoại trừ danh sách Login\r\nBạn có đồng ý chứ", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			@class.class412_0 = new Class412();
			@class.class412_0.string_1 = "http://tieudattai.org/remlaw/userconfig.php?cmd=save&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + HttpUtility.UrlEncode(User.string_1);
			@class.class412_0.String_0 = Class159.Class220_0.ToString();
			@class.class412_0.Event_0 += @class.method_0;
			@class.class412_0.method_0();
		}
	}

	// Token: 0x1700075D RID: 1885
	// (get) Token: 0x06002120 RID: 8480 RVA: 0x00018834 File Offset: 0x00016A34
	// (set) Token: 0x06002121 RID: 8481 RVA: 0x0001883B File Offset: 0x00016A3B
	public static bool Boolean_18 { get; set; }

	// Token: 0x06002122 RID: 8482 RVA: 0x00018843 File Offset: 0x00016A43
	private void toolStripMenuItem_17_Click(object sender, EventArgs e)
	{
		this.method_91(new CleanTras());
		Class438.smethod_6(this);
	}

	// Token: 0x06002123 RID: 8483 RVA: 0x000ED970 File Offset: 0x000EBB70
	private void toolStripMenuItem_18_Click(object sender, EventArgs e)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Class159 @class in this.IEnumerable_3)
		{
			if (!dictionary.ContainsKey(@class.Class432_0.String_1))
			{
				dictionary.Add(@class.Class432_0.String_1, @class.Class432_0.String_2);
			}
		}
		if (dictionary.Count != 2)
		{
			MessageBox.Show(this, "Chỉ được chọn 2 nhân vật để set nhóm nhận bóng", "MicroAuto", MessageBoxButtons.OK);
		}
		int num = 1;
		bool flag = false;
		while (!flag)
		{
			flag = true;
			foreach (KeyValuePair<string, string> keyValuePair in CalendarEx.dictionary_1)
			{
				if (keyValuePair.Key == num.ToString())
				{
					num++;
					flag = false;
					break;
				}
			}
		}
		if (!string.IsNullOrEmpty(num.ToString()) && !CalendarEx.dictionary_1.ContainsKey(num.ToString()))
		{
			try
			{
				XmlElement xmlElement = CalendarEx.xmlDocument_0.CreateElement("Ball");
				XmlAttribute xmlAttribute = CalendarEx.xmlDocument_0.CreateAttribute("Name");
				xmlAttribute.Value = num.ToString();
				xmlElement.Attributes.Append(xmlAttribute);
				CalendarEx.xmlDocument_0.SelectSingleNode("/*").AppendChild(xmlElement);
				foreach (KeyValuePair<string, string> keyValuePair2 in dictionary)
				{
					num.ToString();
					XmlNode xmlNode = CalendarEx.xmlDocument_0.SelectSingleNode("//Balls/Ball[@Name=\"" + num.ToString() + "\"]");
					if (xmlNode.Attributes["Member"] == null)
					{
						XmlAttribute xmlAttribute2 = CalendarEx.xmlDocument_0.CreateAttribute("Member");
						xmlAttribute2.Value = keyValuePair2.Key + "-" + keyValuePair2.Value;
						xmlNode.Attributes.Append(xmlAttribute2);
					}
					else if (!xmlNode.Attributes["Member"].Value.Contains(keyValuePair2.Key))
					{
						xmlNode.Attributes["Member"].Value = string.Concat(new string[]
						{
							xmlNode.Attributes["Member"].Value,
							";",
							keyValuePair2.Key,
							"-",
							keyValuePair2.Value
						});
						xmlNode.Attributes["Member"].Value = xmlNode.Attributes["Member"].Value.Trim(new char[]
						{
							';'
						});
					}
					CalendarEx.dictionary_1[num.ToString()] = xmlElement.Attributes["Member"].Value;
					foreach (object obj in CalendarEx.xmlDocument_0.SelectNodes("//Balls/Ball"))
					{
						XmlNode xmlNode2 = (XmlNode)obj;
						if (xmlNode2.Attributes["Name"] == null)
						{
							xmlNode2.ParentNode.RemoveChild(xmlNode2);
						}
						else if (!(xmlNode2.Attributes["Name"].Value == num.ToString()))
						{
							if (xmlNode2.Attributes["Member"] == null)
							{
								CalendarEx.dictionary_1.Remove(xmlNode2.Attributes["Name"].Value);
								xmlNode2.ParentNode.RemoveChild(xmlNode2);
							}
							else
							{
								if (xmlNode2.Attributes["Member"].Value.Contains(keyValuePair2.Key + "-" + keyValuePair2.Value))
								{
									xmlNode2.Attributes["Member"].Value = xmlNode2.Attributes["Member"].Value.Replace(keyValuePair2.Key + "-" + keyValuePair2.Value, "").Trim(new char[]
									{
										';'
									});
								}
								if (xmlNode2.Attributes["Member"].Value.Trim() == string.Empty)
								{
									CalendarEx.dictionary_1.Remove(xmlNode2.Attributes["Name"].Value);
									xmlNode2.ParentNode.RemoveChild(xmlNode2);
								}
							}
						}
					}
				}
				Class159.Class220_0.method_1("Item", "Balls", CalendarEx.xmlDocument_0.OuterXml);
			}
			catch (Exception ex)
			{
				Main.smethod_1(ex.Message);
			}
		}
	}

	// Token: 0x06002124 RID: 8484 RVA: 0x000EDEE4 File Offset: 0x000EC0E4
	private void toolStripMenuItem_130_Click(object sender, EventArgs e)
	{
		Main.Class303 @class = new Main.Class303();
		@class.object_0 = sender;
		this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x06002125 RID: 8485 RVA: 0x000EDF18 File Offset: 0x000EC118
	private void toolStripMenuItem_19_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.Class304 @class = new Main.Class304();
			TuyetGiao tuyetGiao = new TuyetGiao(Main.class159_0)
			{
				Dock = DockStyle.Fill
			};
			@class.tabPage_0 = new TabPage("TuyệtGiao");
			this.tabCanQuet.TabPages.Add(@class.tabPage_0);
			@class.tabPage_0.Controls.Add(tuyetGiao);
			tuyetGiao.Disposed += @class.method_0;
			this.tabCanQuet.Visible = true;
			this.tabCanQuet.BringToFront();
			this.tabCanQuet.SelectedTab = @class.tabPage_0;
		}
	}

	// Token: 0x06002126 RID: 8486 RVA: 0x000EDFB8 File Offset: 0x000EC1B8
	private void timer_7_Tick(object sender, EventArgs e)
	{
		if (Class268.Dictionary_0.Count > 0)
		{
			string text = "";
			foreach (KeyValuePair<string, string> keyValuePair in Class268.Dictionary_0.ToList<KeyValuePair<string, string>>())
			{
				text = string.Concat(new string[]
				{
					text,
					keyValuePair.Key,
					"|",
					keyValuePair.Value,
					"\n"
				});
			}
			Class268.Dictionary_0.Clear();
			text = text.Trim();
			new Class412
			{
				string_1 = "http://45.77.129.211/microauto/captcha.php?cmd=pushcap&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + User.string_1,
				String_0 = text,
				Boolean_4 = true,
				Boolean_1 = true
			}.method_0();
		}
	}

	// Token: 0x06002127 RID: 8487 RVA: 0x00018856 File Offset: 0x00016A56
	private void toolStripMenuItem_20_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_76));
	}

	// Token: 0x06002128 RID: 8488 RVA: 0x00018882 File Offset: 0x00016A82
	private void method_154(object sender, EventArgs e)
	{
		new BoQuaEx().Show(this);
	}

	// Token: 0x1700075E RID: 1886
	// (get) Token: 0x06002129 RID: 8489 RVA: 0x00006FDC File Offset: 0x000051DC
	public static bool Boolean_19
	{
		get
		{
			return false;
		}
	}

	// Token: 0x0600212A RID: 8490 RVA: 0x000EE0A8 File Offset: 0x000EC2A8
	private void method_155(object sender, EventArgs e)
	{
		Main.Class306 @class = new Main.Class306();
		@class.string_0 = "";
		foreach (string text in Class415.String_5.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length >= 3)
			{
				@class.string_0 = @class.string_0 + text.Trim() + "#";
			}
		}
		if (@class.string_0.Length > 3 && Main.Boolean_19)
		{
			Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(@class.method_0));
			return;
		}
		Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(Main.Class270.<>9.method_77));
	}

	// Token: 0x1700075F RID: 1887
	// (get) Token: 0x0600212B RID: 8491 RVA: 0x0001888F File Offset: 0x00016A8F
	// (set) Token: 0x0600212C RID: 8492 RVA: 0x00018896 File Offset: 0x00016A96
	public static string String_3 { get; set; } = "#";

	// Token: 0x0600212D RID: 8493 RVA: 0x000EE178 File Offset: 0x000EC378
	private void method_156(object sender, EventArgs e)
	{
		Main.Class307 @class = new Main.Class307();
		@class.main_0 = this;
		@class.toolStripMenuItem_0 = (sender as ToolStripMenuItem);
		if (Main.String_3 != @class.toolStripMenuItem_0.Tag.ToString())
		{
			Task.Run(new Action(@class.method_0));
		}
	}

	// Token: 0x0600212E RID: 8494 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_157(object sender, EventArgs e)
	{
	}

	// Token: 0x0600212F RID: 8495 RVA: 0x000EE1CC File Offset: 0x000EC3CC
	private void textBoxEx2_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			Main.Class308 @class = new Main.Class308();
			@class.string_0 = (this.textBoxEx2.Text = this.textBoxEx2.Text.Trim());
			if (@class.string_0.Length > 0)
			{
				if (@class.string_0 == "regzing")
				{
					Main.Boolean_18 = true;
					return;
				}
				this.textBoxEx2.Text = "";
				new Thread(new ThreadStart(@class.method_0)).Start();
			}
		}
	}

	// Token: 0x06002130 RID: 8496 RVA: 0x000EE25C File Offset: 0x000EC45C
	private void label7_MouseClick(object sender, MouseEventArgs e)
	{
		Main.Class309 @class = new Main.Class309();
		@class.main_0 = this;
		this.label7.Enabled = false;
		@class.class412_0 = new Class412();
		@class.class412_0.string_1 = "http://tieudattai.org/microauto/user.php?cmd=getold&time=" + HttpUtility.UrlEncode(Main.string_5);
		@class.class412_0.control_0 = this;
		@class.class412_0.Event_0 += @class.method_0;
		@class.class412_0.method_0();
	}

	// Token: 0x06002131 RID: 8497 RVA: 0x000EE2DC File Offset: 0x000EC4DC
	private void lvConfig_ItemChecked(object sender, ItemCheckedEventArgs e)
	{
		Main.Class310 @class = new Main.Class310();
		@class.itemCheckedEventArgs_0 = e;
		if (!this.Boolean_7)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
		}
	}

	// Token: 0x17000760 RID: 1888
	// (get) Token: 0x06002132 RID: 8498 RVA: 0x0001889E File Offset: 0x00016A9E
	// (set) Token: 0x06002133 RID: 8499 RVA: 0x000188A5 File Offset: 0x00016AA5
	public static bool Boolean_20 { get; set; }

	// Token: 0x06002134 RID: 8500 RVA: 0x000EE318 File Offset: 0x000EC518
	private void label5_MouseClick(object sender, MouseEventArgs e)
	{
		Main.Boolean_20 = !Main.Boolean_20;
		if (Main.Boolean_20)
		{
			this.label5.BackColor = Color.Red;
			this.label5.Text = "Mute";
			return;
		}
		this.label5.BackColor = Color.Green;
		this.label5.Text = "Ting";
	}

	// Token: 0x17000761 RID: 1889
	// (get) Token: 0x06002135 RID: 8501 RVA: 0x000188AD File Offset: 0x00016AAD
	// (set) Token: 0x06002136 RID: 8502 RVA: 0x000188B4 File Offset: 0x00016AB4
	public static bool Boolean_21 { get; set; }

	// Token: 0x06002137 RID: 8503 RVA: 0x000EE37C File Offset: 0x000EC57C
	private void method_158()
	{
		Main.Class311 @class = new Main.Class311();
		@class.main_0 = this;
		base.Enabled = false;
		@class.class412_0 = new Class412();
		@class.class412_0.string_1 = Class387.String_0;
		@class.class412_0.String_0 = "cmd=accountinfo&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + HttpUtility.UrlEncode(User.string_1);
		@class.class412_0.control_0 = this;
		@class.class412_0.Boolean_1 = true;
		@class.class412_0.Event_0 += @class.method_0;
		@class.class412_0.method_0();
	}

	// Token: 0x06002138 RID: 8504 RVA: 0x000188BC File Offset: 0x00016ABC
	private void numberThuHoaX_ValueChanged(object sender, EventArgs e)
	{
		if (!this.Boolean_7)
		{
			Main.class159_0.Int32_68 = (int)this.numberThuHoaX.Value;
		}
	}

	// Token: 0x06002139 RID: 8505 RVA: 0x000188E0 File Offset: 0x00016AE0
	private void numberRadiusThuHoa_ValueChanged(object sender, EventArgs e)
	{
		if (!this.Boolean_7)
		{
			Main.class159_0.Int32_69 = (int)this.numberRadiusThuHoa.Value;
		}
	}

	// Token: 0x0600213A RID: 8506 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_159(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x0600213B RID: 8507 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_160(object sender, EventArgs e)
	{
	}

	// Token: 0x17000762 RID: 1890
	// (get) Token: 0x0600213C RID: 8508 RVA: 0x00018904 File Offset: 0x00016B04
	public int Int32_3
	{
		get
		{
			return 10;
		}
	}

	// Token: 0x0600213D RID: 8509 RVA: 0x00018908 File Offset: 0x00016B08
	private void toolStripMenuItem_23_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_83));
	}

	// Token: 0x0600213E RID: 8510 RVA: 0x00018934 File Offset: 0x00016B34
	private void toolStripMenuItem_22_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_84));
	}

	// Token: 0x0600213F RID: 8511 RVA: 0x00018960 File Offset: 0x00016B60
	private void txtMainSearch_TextChanged(object sender, EventArgs e)
	{
		this.Lv.Search(this.txtMainSearch.Text);
	}

	// Token: 0x06002140 RID: 8512 RVA: 0x00018979 File Offset: 0x00016B79
	private void muThanhLyNhiemVu_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_262));
	}

	// Token: 0x06002141 RID: 8513 RVA: 0x00018992 File Offset: 0x00016B92
	private void toolStripMenuItem_24_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_85));
	}

	// Token: 0x06002142 RID: 8514 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_161(object sender, EventArgs e)
	{
	}

	// Token: 0x06002143 RID: 8515 RVA: 0x000189BE File Offset: 0x00016BBE
	private void toolStripMenuItem_25_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_86));
	}

	// Token: 0x06002144 RID: 8516 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_162(object sender, EventArgs e)
	{
	}

	// Token: 0x17000763 RID: 1891
	// (get) Token: 0x06002145 RID: 8517 RVA: 0x000189EA File Offset: 0x00016BEA
	// (set) Token: 0x06002146 RID: 8518 RVA: 0x000189F1 File Offset: 0x00016BF1
	public static bool Boolean_22 { get; set; }

	// Token: 0x06002147 RID: 8519 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_163(object sender, EventArgs e)
	{
	}

	// Token: 0x06002148 RID: 8520 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_164(object sender, EventArgs e)
	{
	}

	// Token: 0x06002149 RID: 8521 RVA: 0x000189F9 File Offset: 0x00016BF9
	private void toolStripMenuItem_34_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_87));
	}

	// Token: 0x0600214A RID: 8522 RVA: 0x00018A2A File Offset: 0x00016C2A
	private void muTucCau_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_263));
	}

	// Token: 0x0600214B RID: 8523 RVA: 0x000EE420 File Offset: 0x000EC620
	private void Lv_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
	{
		if (this.Lv.Columns[e.ColumnIndex].Width == 0 && this.list_6.Contains(e.ColumnIndex))
		{
			e.Cancel = true;
			e.NewWidth = this.Lv.Columns[e.ColumnIndex].Width;
		}
	}

	// Token: 0x0600214C RID: 8524 RVA: 0x000EE488 File Offset: 0x000EC688
	private void selectPathToolStripMenuItem_Click(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = "Game.exe |Game.exe";
		if (openFileDialog.ShowDialog(this) == DialogResult.OK)
		{
			Class378.String_0 = openFileDialog.FileName;
		}
	}

	// Token: 0x0600214D RID: 8525 RVA: 0x000EE4BC File Offset: 0x000EC6BC
	private void method_165(object sender, EventArgs e)
	{
		Main.Class312 @class = new Main.Class312();
		@class.main_0 = this;
		if (MessageBox.Show(this, "Việc này sẽ ghi đè toàn bộ thiết lập cũ có trong máy\r\nBạn có đồng ý chứ", "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			@class.class412_0 = new Class412();
			@class.class412_0.string_1 = "http://tieudattai.org/remlaw/userconfig.php?cmd=load&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + HttpUtility.UrlEncode(User.string_1);
			@class.class412_0.control_0 = this;
			@class.class412_0.Event_0 += @class.method_0;
			@class.class412_0.method_0();
		}
	}

	// Token: 0x0600214E RID: 8526 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_166(object sender, EventArgs e)
	{
	}

	// Token: 0x0600214F RID: 8527 RVA: 0x00018A43 File Offset: 0x00016C43
	private void method_167(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_89));
	}

	// Token: 0x06002150 RID: 8528 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_168(object sender, EventArgs e)
	{
	}

	// Token: 0x06002151 RID: 8529 RVA: 0x000EE554 File Offset: 0x000EC754
	private void toolStripMenuItem_36_Click(object sender, EventArgs e)
	{
		Main.Class313 @class = new Main.Class313();
		if (!Class268.Boolean_3)
		{
			return;
		}
		@class.dictionary_0 = new Dictionary<string, int>();
		foreach (string text in Class415.String_2.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length > 3 && text.Trim().Split(new char[]
			{
				'|'
			}).Length == 2 && !@class.dictionary_0.ContainsKey(text.Trim().Split(new char[]
			{
				'|'
			})[0]) && Class426.smethod_41(text.Trim().Split(new char[]
			{
				'|'
			})[1]) > 0)
			{
				@class.dictionary_0.Add(text.Trim().Split(new char[]
				{
					'|'
				})[0], Class426.smethod_41(text.Trim().Split(new char[]
				{
					'|'
				})[1]));
			}
		}
		if (Main.class159_0 != null)
		{
			Task.Run(new Action(@class.method_0));
		}
	}

	// Token: 0x06002152 RID: 8530 RVA: 0x000EE678 File Offset: 0x000EC878
	private void menuGoTrieuTap_DropDownOpening(object sender, EventArgs e)
	{
		this.menuGoTrieuTap.DropDownItems.Clear();
		foreach (Class159 @class in this.IEnumerable_5)
		{
			ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(@class.Class432_0.String_2);
			toolStripMenuItem.Click += this.toolStripMenuItem_130_Click;
			toolStripMenuItem.Tag = string.Concat(new string[]
			{
				@class.Int32_12.ToString(),
				",",
				@class.Int32_13.ToString(),
				",",
				@class.Class432_0.UInt32_29.ToString()
			});
			this.menuGoTrieuTap.DropDownItems.Add(toolStripMenuItem);
		}
	}

	// Token: 0x06002153 RID: 8531 RVA: 0x00002E18 File Offset: 0x00001018
	private void playerToolStripMenuItem_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06002154 RID: 8532 RVA: 0x00018A74 File Offset: 0x00016C74
	private void muNopTuViHuyTinh_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_264));
	}

	// Token: 0x06002155 RID: 8533 RVA: 0x00018A8D File Offset: 0x00016C8D
	private void muMoShopBachBaoCac_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_265));
	}

	// Token: 0x06002156 RID: 8534 RVA: 0x00018AA6 File Offset: 0x00016CA6
	private void muMoShopTrungDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_266));
	}

	// Token: 0x06002157 RID: 8535 RVA: 0x00018ABF File Offset: 0x00016CBF
	private void muMoShopHungBa_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_267));
	}

	// Token: 0x06002158 RID: 8536 RVA: 0x00018AD8 File Offset: 0x00016CD8
	private void toolStripMenuItem_39_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_92));
	}

	// Token: 0x06002159 RID: 8537 RVA: 0x00018B04 File Offset: 0x00016D04
	private void toolStripMenuItem_40_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_93));
	}

	// Token: 0x0600215A RID: 8538 RVA: 0x00018B30 File Offset: 0x00016D30
	private void toolStripMenuItem_41_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_94));
	}

	// Token: 0x0600215B RID: 8539 RVA: 0x00018B5C File Offset: 0x00016D5C
	private void bangToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_95));
	}

	// Token: 0x0600215C RID: 8540 RVA: 0x00018B88 File Offset: 0x00016D88
	private void toolStripMenuItem_42_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_96));
	}

	// Token: 0x0600215D RID: 8541 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_169(object sender, EventArgs e)
	{
	}

	// Token: 0x0600215E RID: 8542 RVA: 0x00018BB4 File Offset: 0x00016DB4
	private void nudBuffPet_ValueChanged(object sender, EventArgs e)
	{
		Class268.Int32_0 = (int)this.nudBuffPet.Value;
	}

	// Token: 0x0600215F RID: 8543 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_170(object sender, EventArgs e)
	{
	}

	// Token: 0x06002160 RID: 8544 RVA: 0x00018BCB File Offset: 0x00016DCB
	private void method_171(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_97));
	}

	// Token: 0x06002161 RID: 8545 RVA: 0x000EE764 File Offset: 0x000EC964
	private void toolStripMenuItem_43_Click(object sender, EventArgs e)
	{
		Main.Class315 @class = new Main.Class315();
		if (!Class268.Boolean_3)
		{
			return;
		}
		@class.dictionary_0 = new Dictionary<string, int>();
		foreach (string text in Class415.String_2.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length > 3 && text.Trim().Split(new char[]
			{
				'|'
			}).Length == 2 && !@class.dictionary_0.ContainsKey(text.Trim().Split(new char[]
			{
				'|'
			})[0]) && Class426.smethod_41(text.Trim().Split(new char[]
			{
				'|'
			})[1]) > 0)
			{
				@class.dictionary_0.Add(text.Trim().Split(new char[]
				{
					'|'
				})[0], Class426.smethod_41(text.Trim().Split(new char[]
				{
					'|'
				})[1]));
			}
		}
		if (Main.class159_0 != null)
		{
			Task.Run(new Action(@class.method_0));
		}
	}

	// Token: 0x06002162 RID: 8546 RVA: 0x00018BF7 File Offset: 0x00016DF7
	private void muDoiKimTamTy_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_268));
	}

	// Token: 0x06002163 RID: 8547 RVA: 0x00018C10 File Offset: 0x00016E10
	private void muDoi999HoaHong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_269));
	}

	// Token: 0x06002164 RID: 8548 RVA: 0x00018C29 File Offset: 0x00016E29
	private void muDoiLoanPhiMatHam_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_270));
	}

	// Token: 0x06002165 RID: 8549 RVA: 0x00018C42 File Offset: 0x00016E42
	private void muDoiHuyenSacCauThienThai_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_271));
	}

	// Token: 0x06002166 RID: 8550 RVA: 0x00018C5B File Offset: 0x00016E5B
	private void muDoiTiemNangTan_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_272));
	}

	// Token: 0x06002167 RID: 8551 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_172(object sender, EventArgs e)
	{
	}

	// Token: 0x06002168 RID: 8552 RVA: 0x00018C74 File Offset: 0x00016E74
	private void muNhanLeBao_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_273));
	}

	// Token: 0x06002169 RID: 8553 RVA: 0x00018C8D File Offset: 0x00016E8D
	private void muNhanBong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_274));
	}

	// Token: 0x0600216A RID: 8554 RVA: 0x00018CA6 File Offset: 0x00016EA6
	private void muNhanThuongTyVo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_275));
	}

	// Token: 0x0600216B RID: 8555 RVA: 0x00018CBF File Offset: 0x00016EBF
	private void muNhanChienCongKiemChi_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_276));
	}

	// Token: 0x0600216C RID: 8556 RVA: 0x00018CD8 File Offset: 0x00016ED8
	private void method_173(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_98));
	}

	// Token: 0x0600216D RID: 8557 RVA: 0x00018D04 File Offset: 0x00016F04
	private void method_174(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_99));
	}

	// Token: 0x0600216E RID: 8558 RVA: 0x00018D30 File Offset: 0x00016F30
	private void method_175(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_100));
	}

	// Token: 0x0600216F RID: 8559 RVA: 0x00018D5C File Offset: 0x00016F5C
	private void muSuaThanKhi_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_277));
	}

	// Token: 0x06002170 RID: 8560 RVA: 0x00018D75 File Offset: 0x00016F75
	private void muSuaVoHon_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_278));
	}

	// Token: 0x06002171 RID: 8561 RVA: 0x00018D8E File Offset: 0x00016F8E
	private void muSuaTrangBi_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_279));
	}

	// Token: 0x06002172 RID: 8562 RVA: 0x000EE888 File Offset: 0x000ECA88
	private void button15_Click(object sender, EventArgs e)
	{
		if (this.cboTiemNang.SelectedIndex == 0)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_280));
		}
		if (this.cboTiemNang.SelectedIndex == 1)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_281));
		}
		if (this.cboTiemNang.SelectedIndex == 2)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_282));
		}
		if (this.cboTiemNang.SelectedIndex == 3)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_283));
		}
		if (this.cboTiemNang.SelectedIndex == 4)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_284));
		}
	}

	// Token: 0x06002173 RID: 8563 RVA: 0x00018DA7 File Offset: 0x00016FA7
	private void muNhanThuongQuanSonHai_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_285));
	}

	// Token: 0x06002174 RID: 8564 RVA: 0x00018DC0 File Offset: 0x00016FC0
	private void muDoiChanNguyenLinhPhach_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_286));
	}

	// Token: 0x06002175 RID: 8565 RVA: 0x00018DD9 File Offset: 0x00016FD9
	private void muNhanKeoHallowen_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_287));
	}

	// Token: 0x06002176 RID: 8566 RVA: 0x00018DF2 File Offset: 0x00016FF2
	private void toolStripMenuItem_47_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_101));
	}

	// Token: 0x06002177 RID: 8567 RVA: 0x00018E1E File Offset: 0x0001701E
	private void muGiaoNguHanhPhapThiep_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_288));
	}

	// Token: 0x06002178 RID: 8568 RVA: 0x00018E37 File Offset: 0x00017037
	private void muNhanBuaBaoRuong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_289));
	}

	// Token: 0x06002179 RID: 8569 RVA: 0x00018E50 File Offset: 0x00017050
	private void muTuLuyenNoiLuc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_290));
	}

	// Token: 0x0600217A RID: 8570 RVA: 0x00018E69 File Offset: 0x00017069
	private void muTuLuyenTheLuc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_291));
	}

	// Token: 0x0600217B RID: 8571 RVA: 0x00018E82 File Offset: 0x00017082
	private void muTuLuyenThanPhap_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_292));
	}

	// Token: 0x0600217C RID: 8572 RVA: 0x000EE950 File Offset: 0x000ECB50
	private void chkBinhThanh_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		if (!this.Boolean_7)
		{
			if (Main.class159_0 != null)
			{
				Class159 @class = Main.class159_0;
				@class.method_48(Enum14.DatDoiBinhThanh, this.chkBinhThanh.Checked);
				@class.Int32_32 = 0;
				@class.int_54 = -1;
			}
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_293));
		}
	}

	// Token: 0x0600217D RID: 8573 RVA: 0x00018E9B File Offset: 0x0001709B
	private void chkKho_CheckedChanged(object sender, EventArgs e)
	{
		if (this.Boolean_6)
		{
			return;
		}
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_295));
		Main.class159_0.method_48(Enum14.BinhThanhKho, this.chkKho.Checked);
	}

	// Token: 0x0600217E RID: 8574 RVA: 0x00018ED4 File Offset: 0x000170D4
	private void button17_Click(object sender, EventArgs e)
	{
		this.method_91(new ConfigBinhThanh());
	}

	// Token: 0x0600217F RID: 8575 RVA: 0x000EE9B4 File Offset: 0x000ECBB4
	private void toolStripMenuItem_49_Click(object sender, EventArgs e)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Class159 @class in this.IEnumerable_3)
		{
			if (!dictionary.ContainsKey(@class.Class432_0.String_1))
			{
				dictionary.Add(@class.Class432_0.String_1, @class.Class432_0.String_2);
			}
		}
		if (dictionary.Count != 3)
		{
			MessageBox.Show(this, "Chỉ được chọn 3 nhân vật để set nhóm tỷ võ", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		int num = 1;
		bool flag = false;
		while (!flag)
		{
			flag = true;
			foreach (KeyValuePair<string, string> keyValuePair in CalendarEx.dictionary_2)
			{
				if (keyValuePair.Key == num.ToString())
				{
					num++;
					flag = false;
					break;
				}
			}
		}
		if (!string.IsNullOrEmpty(num.ToString()) && !CalendarEx.dictionary_2.ContainsKey(num.ToString()))
		{
			try
			{
				string text = "";
				foreach (KeyValuePair<string, string> keyValuePair2 in dictionary)
				{
					text = text + "[" + keyValuePair2.Value + "]";
				}
				XmlElement xmlElement = CalendarEx.xmlDocument_1.CreateElement("TyVo");
				XmlAttribute xmlAttribute = CalendarEx.xmlDocument_1.CreateAttribute("Name");
				XmlAttribute xmlAttribute2 = CalendarEx.xmlDocument_1.CreateAttribute("Member");
				xmlAttribute.Value = num.ToString();
				xmlAttribute2.Value = text;
				xmlElement.Attributes.Append(xmlAttribute);
				xmlElement.Attributes.Append(xmlAttribute2);
				CalendarEx.xmlDocument_1.SelectSingleNode("/*").AppendChild(xmlElement);
				Class159.Class220_0.method_1("Item", "TyVos", CalendarEx.xmlDocument_1.OuterXml);
				CalendarEx.dictionary_2.Add(num.ToString(), text);
			}
			catch (Exception ex)
			{
				Main.smethod_1(ex.Message);
			}
		}
	}

	// Token: 0x06002180 RID: 8576 RVA: 0x000EEC30 File Offset: 0x000ECE30
	private void toolStripMenuItem_50_Click(object sender, EventArgs e)
	{
		Main.Boolean_15 = (this.toolStripMenuItem_50.Checked = !this.toolStripMenuItem_50.Checked);
	}

	// Token: 0x06002181 RID: 8577 RVA: 0x00018EE1 File Offset: 0x000170E1
	private void muTyVo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_297));
	}

	// Token: 0x06002182 RID: 8578 RVA: 0x00018EFA File Offset: 0x000170FA
	private void toolStripMenuItem_51_Click(object sender, EventArgs e)
	{
		this.IEnumerable_4.smethod_13(new Action<Class159>(Main.Class270.<>9.method_102));
	}

	// Token: 0x06002183 RID: 8579 RVA: 0x00002E18 File Offset: 0x00001018
	private void toolStripMenuItem_53_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06002184 RID: 8580 RVA: 0x00002E18 File Offset: 0x00001018
	private void leaderToolStripMenuItem_EnabledChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06002185 RID: 8581 RVA: 0x000EEC60 File Offset: 0x000ECE60
	private void toolStripMenuItem_54_Click(object sender, EventArgs e)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Class159 @class in this.IEnumerable_3)
		{
			if (!dictionary.ContainsKey(@class.Class432_0.String_1))
			{
				dictionary.Add(@class.Class432_0.String_1, @class.Class432_0.String_2);
			}
		}
		if (dictionary.Count != 12)
		{
			MessageBox.Show(this, "Chỉ được chọn 12 nhân vật để set quân đoàn", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		int num = 1;
		bool flag = false;
		while (!flag)
		{
			flag = true;
			foreach (KeyValuePair<string, string> keyValuePair in CalendarEx.dictionary_3)
			{
				if (keyValuePair.Key == num.ToString())
				{
					num++;
					flag = false;
					break;
				}
			}
		}
		if (!string.IsNullOrEmpty(num.ToString()) && !CalendarEx.dictionary_3.ContainsKey(num.ToString()))
		{
			try
			{
				string text = "";
				foreach (KeyValuePair<string, string> keyValuePair2 in dictionary)
				{
					text = text + "[" + keyValuePair2.Value + "]";
				}
				XmlElement xmlElement = CalendarEx.xmlDocument_2.CreateElement("QuanDoan");
				XmlAttribute xmlAttribute = CalendarEx.xmlDocument_2.CreateAttribute("Name");
				XmlAttribute xmlAttribute2 = CalendarEx.xmlDocument_2.CreateAttribute("Member");
				xmlAttribute.Value = num.ToString();
				xmlAttribute2.Value = text;
				xmlElement.Attributes.Append(xmlAttribute);
				xmlElement.Attributes.Append(xmlAttribute2);
				CalendarEx.xmlDocument_2.SelectSingleNode("/*").AppendChild(xmlElement);
				Class159.Class220_0.method_1("Item", "QuanDoan", CalendarEx.xmlDocument_2.OuterXml);
				CalendarEx.dictionary_3.Add(num.ToString(), text);
			}
			catch (Exception ex)
			{
				Main.smethod_1(ex.Message);
			}
		}
	}

	// Token: 0x06002186 RID: 8582 RVA: 0x00018F26 File Offset: 0x00017126
	private void muTuLuyenTheNoiThan_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_103));
	}

	// Token: 0x17000764 RID: 1892
	// (get) Token: 0x06002187 RID: 8583 RVA: 0x00018F52 File Offset: 0x00017152
	// (set) Token: 0x06002188 RID: 8584 RVA: 0x00018F59 File Offset: 0x00017159
	public static bool Boolean_23 { get; set; }

	// Token: 0x06002189 RID: 8585 RVA: 0x00018F61 File Offset: 0x00017161
	private void muVoY_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_298));
	}

	// Token: 0x0600218A RID: 8586 RVA: 0x00018F7A File Offset: 0x0001717A
	private void muQuanSonHai_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_299));
	}

	// Token: 0x17000765 RID: 1893
	// (get) Token: 0x0600218B RID: 8587 RVA: 0x00018F93 File Offset: 0x00017193
	// (set) Token: 0x0600218C RID: 8588 RVA: 0x00018F9A File Offset: 0x0001719A
	public static int Int32_4 { get; set; }

	// Token: 0x0600218D RID: 8589 RVA: 0x00018FA2 File Offset: 0x000171A2
	private void muVoTuPho_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_300));
	}

	// Token: 0x0600218E RID: 8590 RVA: 0x00018FBB File Offset: 0x000171BB
	private void toolStripMenuItem_136_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_104));
	}

	// Token: 0x0600218F RID: 8591 RVA: 0x00018FE7 File Offset: 0x000171E7
	private void toolStripMenuItem_131_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_301));
	}

	// Token: 0x06002190 RID: 8592 RVA: 0x00019000 File Offset: 0x00017200
	private void toolStripMenuItem_137_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_107));
	}

	// Token: 0x06002191 RID: 8593 RVA: 0x0001902C File Offset: 0x0001722C
	private void toolStripMenuItem_134_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_109));
	}

	// Token: 0x06002192 RID: 8594 RVA: 0x00019058 File Offset: 0x00017258
	private void toolStripMenuItem_140_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_111));
	}

	// Token: 0x06002193 RID: 8595 RVA: 0x00019084 File Offset: 0x00017284
	private void toolStripMenuItem_133_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_113));
	}

	// Token: 0x06002194 RID: 8596 RVA: 0x000190B0 File Offset: 0x000172B0
	private void toolStripMenuItem_132_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_115));
	}

	// Token: 0x06002195 RID: 8597 RVA: 0x000190DC File Offset: 0x000172DC
	private void toolStripMenuItem_141_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_117));
	}

	// Token: 0x06002196 RID: 8598 RVA: 0x00019108 File Offset: 0x00017308
	private void toolStripMenuItem_142_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_119));
	}

	// Token: 0x06002197 RID: 8599 RVA: 0x00019134 File Offset: 0x00017334
	private void toolStripMenuItem_143_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_121));
	}

	// Token: 0x06002198 RID: 8600 RVA: 0x00019160 File Offset: 0x00017360
	private void ngamyToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_123));
	}

	// Token: 0x06002199 RID: 8601 RVA: 0x0001918C File Offset: 0x0001738C
	private void toolStripMenuItem_135_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_125));
	}

	// Token: 0x0600219A RID: 8602 RVA: 0x000191B8 File Offset: 0x000173B8
	private void toolStripMenuItem_138_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_127));
	}

	// Token: 0x0600219B RID: 8603 RVA: 0x000191E4 File Offset: 0x000173E4
	private void toolStripMenuItem_139_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(Main.Class270.<>9.method_129));
	}

	// Token: 0x0600219C RID: 8604 RVA: 0x00019210 File Offset: 0x00017410
	private void muMoShopQuyThi_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_302));
	}

	// Token: 0x0600219D RID: 8605 RVA: 0x00019229 File Offset: 0x00017429
	private void toolStripMenuItem_144_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_131));
	}

	// Token: 0x0600219E RID: 8606 RVA: 0x0001925A File Offset: 0x0001745A
	private void method_176(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_132));
	}

	// Token: 0x0600219F RID: 8607 RVA: 0x00019286 File Offset: 0x00017486
	private void muCatDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_303));
	}

	// Token: 0x060021A0 RID: 8608 RVA: 0x0001929F File Offset: 0x0001749F
	private void toolStripMenuItem_145_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_133));
	}

	// Token: 0x060021A1 RID: 8609 RVA: 0x000192CB File Offset: 0x000174CB
	private void muLayDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_304));
	}

	// Token: 0x060021A2 RID: 8610 RVA: 0x000192E4 File Offset: 0x000174E4
	private void method_177(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_134));
	}

	// Token: 0x060021A3 RID: 8611 RVA: 0x00019310 File Offset: 0x00017510
	private void muTangCapTruongThanhLongVan_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_305));
	}

	// Token: 0x060021A4 RID: 8612 RVA: 0x000EEEE0 File Offset: 0x000ED0E0
	private void cboNgoc_DropDown(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			ComboBox comboBox = sender as ComboBox;
			comboBox.Items.Clear();
			foreach (Class209 @class in Main.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_1.Contains("Thạch"))
				{
					bool flag = false;
					using (IEnumerator enumerator2 = comboBox.Items.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							if (enumerator2.Current.ToString() == @class.String_0)
							{
								flag = true;
							}
						}
					}
					if (!flag)
					{
						comboBox.Items.Add(@class.String_0);
					}
				}
			}
		}
	}

	// Token: 0x060021A5 RID: 8613 RVA: 0x000EEFD0 File Offset: 0x000ED1D0
	private void comboBox2_DropDown(object sender, EventArgs e)
	{
		ComboBox comboBox = sender as ComboBox;
		comboBox.Items.Clear();
		if (Main.class159_0 != null)
		{
			foreach (Class209 @class in Main.class159_0.Class196_0.IEnumerable_0)
			{
				if (Class363.list_0.Contains(@class.String_0))
				{
					bool flag = false;
					using (IEnumerator enumerator2 = comboBox.Items.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							if (enumerator2.Current.ToString() == @class.String_0)
							{
								flag = true;
							}
						}
					}
					if (!flag)
					{
						comboBox.Items.Add(@class.String_0);
					}
				}
			}
		}
	}

	// Token: 0x060021A6 RID: 8614 RVA: 0x000EF0C0 File Offset: 0x000ED2C0
	private void button10_Click(object sender, EventArgs e)
	{
		Main.Class320 @class = new Main.Class320();
		if (Main.class159_0 == null)
		{
			return;
		}
		@class.class159_0 = Main.class159_0;
		try
		{
			string text = this.cboNgoc.Text;
			@class.int_1 = -1;
			@class.int_0 = -1;
			if (!string.IsNullOrEmpty(text))
			{
				foreach (Class209 class2 in @class.class159_0.Class196_0.IEnumerable_0)
				{
					if (class2.String_0 == "Sơ Cấp Bảo Thạch Hợp Thành Phù" && !class2.Boolean_0)
					{
						@class.int_1 = (int)class2.UInt32_6;
					}
					if (class2.String_0 == text)
					{
						@class.int_0 = (int)class2.UInt32_6;
					}
				}
				new Thread(new ThreadStart(@class.method_0)).Start();
			}
		}
		catch
		{
		}
	}

	// Token: 0x060021A7 RID: 8615 RVA: 0x000EF1B8 File Offset: 0x000ED3B8
	private void button18_Click(object sender, EventArgs e)
	{
		Main.Class321 @class = new Main.Class321();
		if (Main.class159_0 == null)
		{
			return;
		}
		@class.class159_0 = Main.class159_0;
		string text = this.comboBox2.Text;
		if (text != "")
		{
			@class.int_0 = -1;
			@class.int_1 = -1;
			foreach (Class209 class2 in @class.class159_0.Class196_0.IEnumerable_0)
			{
				if (class2.String_0 == text)
				{
					@class.int_0 = (int)class2.UInt32_6;
					@class.class159_0.method_410(class2.String_0);
				}
				if (class2.String_0 == "Bảo Thạch Điêu Trác Phù Cấp 3" && !class2.Boolean_0)
				{
					@class.int_1 = (int)class2.UInt32_6;
				}
			}
			if (@class.int_0 != -1 && @class.int_1 != -1)
			{
				Task.Run(new Action(@class.method_0));
			}
		}
	}

	// Token: 0x060021A8 RID: 8616 RVA: 0x00019329 File Offset: 0x00017529
	private void toolStripMenuItem_146_Click(object sender, EventArgs e)
	{
		if (Main.class159_0 != null)
		{
			Main.String_2 = Main.class159_0.Class432_0.String_2;
		}
	}

	// Token: 0x060021A9 RID: 8617 RVA: 0x00019346 File Offset: 0x00017546
	private void toolStripMenuItem_147_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_137));
	}

	// Token: 0x060021AA RID: 8618 RVA: 0x00019372 File Offset: 0x00017572
	private void toolStripMenuItem_148_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_138));
	}

	// Token: 0x060021AB RID: 8619 RVA: 0x000EF2C4 File Offset: 0x000ED4C4
	private void treoShopChoTaToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		if (Main.String_2 == null)
		{
			MessageBox.Show(this, "Cần chọn người gom đồ trước", "MicroAuto", MessageBoxButtons.OK);
			return;
		}
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_139));
	}

	// Token: 0x060021AC RID: 8620 RVA: 0x0001939E File Offset: 0x0001759E
	private void muLayDoLayVang_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_306));
	}

	// Token: 0x060021AD RID: 8621 RVA: 0x000193B7 File Offset: 0x000175B7
	private void chkBanRac_CheckedChanged(object sender, EventArgs e)
	{
		Main.Boolean_11 = this.chkBanRac.Checked;
	}

	// Token: 0x060021AE RID: 8622 RVA: 0x000193C9 File Offset: 0x000175C9
	private void muDaiLeHungVuong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_307));
	}

	// Token: 0x060021AF RID: 8623 RVA: 0x000EF318 File Offset: 0x000ED518
	private void toolStripMenuItem_150_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_5)
		{
			foreach (Class209 class2 in @class.Class196_0.IEnumerable_4.Where(new Func<Class209, bool>(Main.Class270.<>9.method_140)))
			{
				if (class2.String_0 == "Chân Nguyên Linh Phách" || class2.String_0 == "Chân Nguyên Phách" || class2.String_0 == "Chân Nguyên Tinh Phách")
				{
					@class.method_256(class2.UInt32_6);
				}
			}
		}
	}

	// Token: 0x060021B0 RID: 8624 RVA: 0x000EF408 File Offset: 0x000ED608
	private void toolStripMenuItem_162_Click(object sender, EventArgs e)
	{
		Main.Class322 @class = new Main.Class322();
		ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;
		@class.int_0 = Class426.smethod_41(toolStripMenuItem.Text);
		this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060021B1 RID: 8625 RVA: 0x000193E2 File Offset: 0x000175E2
	private void toolStripMenuItem_153_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_141));
	}

	// Token: 0x060021B2 RID: 8626 RVA: 0x0001940E File Offset: 0x0001760E
	private void toolStripMenuItem_154_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_142));
	}

	// Token: 0x060021B3 RID: 8627 RVA: 0x0001943A File Offset: 0x0001763A
	private void toolStripMenuItem_155_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_143));
	}

	// Token: 0x060021B4 RID: 8628 RVA: 0x00019466 File Offset: 0x00017666
	private void toolStripMenuItem_163_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_144));
	}

	// Token: 0x060021B5 RID: 8629 RVA: 0x00019492 File Offset: 0x00017692
	private void muBaoDoHiem_Click(object sender, EventArgs e)
	{
		this.IEnumerable_2.smethod_13(new Action<Class159>(this.method_308));
	}

	// Token: 0x060021B6 RID: 8630 RVA: 0x000194AB File Offset: 0x000176AB
	private void muDungDoatBaoRuong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_310));
	}

	// Token: 0x060021B7 RID: 8631 RVA: 0x000194C4 File Offset: 0x000176C4
	private void muCheThanKhi_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_311));
	}

	// Token: 0x060021B8 RID: 8632 RVA: 0x000194DD File Offset: 0x000176DD
	private void muTuLuyenCuongLuc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_312));
	}

	// Token: 0x060021B9 RID: 8633 RVA: 0x000EF44C File Offset: 0x000ED64C
	private void toolStripMenuItem_170_Click(object sender, EventArgs e)
	{
		Main.Class323 @class = new Main.Class323();
		@class.toolStripMenuItem_0 = (sender as ToolStripMenuItem);
		this.IEnumerable_3.smethod_13(new Action<Class159>(@class.method_0));
	}

	// Token: 0x060021BA RID: 8634 RVA: 0x000194F6 File Offset: 0x000176F6
	private void toolStripMenuItem_171_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_145));
	}

	// Token: 0x060021BB RID: 8635 RVA: 0x00019522 File Offset: 0x00017722
	private void toolStripMenuItem_172_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_146));
	}

	// Token: 0x060021BC RID: 8636 RVA: 0x0001954E File Offset: 0x0001774E
	private void toolStripMenuItem_173_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_147));
	}

	// Token: 0x060021BD RID: 8637 RVA: 0x0001957A File Offset: 0x0001777A
	private void toolStripMenuItem_174_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_148));
	}

	// Token: 0x060021BE RID: 8638 RVA: 0x000195A6 File Offset: 0x000177A6
	private void toolStripMenuItem_176_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_149));
	}

	// Token: 0x060021BF RID: 8639 RVA: 0x000195D2 File Offset: 0x000177D2
	private void toolStripMenuItem_177_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_150));
	}

	// Token: 0x060021C0 RID: 8640 RVA: 0x000195FE File Offset: 0x000177FE
	private void toolStripMenuItem_178_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_151));
	}

	// Token: 0x060021C1 RID: 8641 RVA: 0x0001962A File Offset: 0x0001782A
	private void toolStripMenuItem_179_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_152));
	}

	// Token: 0x060021C2 RID: 8642 RVA: 0x00019656 File Offset: 0x00017856
	private void toolStripMenuItem_180_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_153));
	}

	// Token: 0x060021C3 RID: 8643 RVA: 0x000EC574 File Offset: 0x000EA774
	private void toolStripMenuItem_181_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.method_173();
		}
	}

	// Token: 0x060021C4 RID: 8644 RVA: 0x00019682 File Offset: 0x00017882
	private void toolStripMenuItem_182_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_154));
	}

	// Token: 0x060021C5 RID: 8645 RVA: 0x000196AE File Offset: 0x000178AE
	private void toolStripMenuItem_183_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_155));
	}

	// Token: 0x060021C6 RID: 8646 RVA: 0x00002E18 File Offset: 0x00001018
	private void muVanTieu_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060021C7 RID: 8647 RVA: 0x000196DA File Offset: 0x000178DA
	private void thuPetToolStripMenuItem_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_156));
	}

	// Token: 0x060021C8 RID: 8648 RVA: 0x00019706 File Offset: 0x00017906
	private void toolStripMenuItem_184_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_157));
	}

	// Token: 0x060021C9 RID: 8649 RVA: 0x00019732 File Offset: 0x00017932
	private void toolStripMenuItem_185_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_158));
	}

	// Token: 0x060021CA RID: 8650 RVA: 0x0001975E File Offset: 0x0001795E
	private void toolStripMenuItem_186_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_159));
	}

	// Token: 0x060021CB RID: 8651 RVA: 0x000EC6F8 File Offset: 0x000EA8F8
	private void selectCtrlAToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.Lv.Items)
		{
			((ListViewItem)obj).Selected = true;
		}
	}

	// Token: 0x060021CC RID: 8652 RVA: 0x0001978A File Offset: 0x0001798A
	private void method_178(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_160));
	}

	// Token: 0x060021CD RID: 8653 RVA: 0x000183EA File Offset: 0x000165EA
	private void toolStripMenuItem_187_Click(object sender, EventArgs e)
	{
		this.method_77();
	}

	// Token: 0x060021CE RID: 8654 RVA: 0x000197B6 File Offset: 0x000179B6
	private void toolStripMenuItem_188_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_161));
	}

	// Token: 0x060021CF RID: 8655 RVA: 0x000197E2 File Offset: 0x000179E2
	private void muMoTiemThuoc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_313));
	}

	// Token: 0x060021D0 RID: 8656 RVA: 0x000197FB File Offset: 0x000179FB
	private void muVanTieu1_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_314));
	}

	// Token: 0x060021D1 RID: 8657 RVA: 0x00019814 File Offset: 0x00017A14
	private void muVanTieu2_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_315));
	}

	// Token: 0x060021D2 RID: 8658 RVA: 0x0001982D File Offset: 0x00017A2D
	private void muVanTieu3_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_316));
	}

	// Token: 0x060021D3 RID: 8659 RVA: 0x00019846 File Offset: 0x00017A46
	private void muVanTieu4_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_317));
	}

	// Token: 0x060021D4 RID: 8660 RVA: 0x0001985F File Offset: 0x00017A5F
	private void button3_Click(object sender, EventArgs e)
	{
		this.method_91(new BoQua());
	}

	// Token: 0x060021D5 RID: 8661 RVA: 0x0001986C File Offset: 0x00017A6C
	private void muLinhLuong_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_318));
	}

	// Token: 0x060021D6 RID: 8662 RVA: 0x00019885 File Offset: 0x00017A85
	private void muMua100KimSangDuoc_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_319));
	}

	// Token: 0x060021D7 RID: 8663 RVA: 0x000EF484 File Offset: 0x000ED684
	private void toolStripMenuItem_189_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.method_172();
		}
	}

	// Token: 0x060021D8 RID: 8664 RVA: 0x000EF4D0 File Offset: 0x000ED6D0
	private void muTrangSucCuuLe_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.method_48(Enum14.TrangSucCuuLe, !this.muTrangSucCuuLe.Checked);
		}
	}

	// Token: 0x060021D9 RID: 8665 RVA: 0x000EF52C File Offset: 0x000ED72C
	private void muTamKy_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_3)
		{
			@class.method_48(Enum14.TamKy, !this.muTamKy.Checked);
		}
	}

	// Token: 0x060021DA RID: 8666 RVA: 0x0001989E File Offset: 0x00017A9E
	private void method_179(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_162));
	}

	// Token: 0x060021DB RID: 8667 RVA: 0x000198CA File Offset: 0x00017ACA
	private void muDuaTangBaoDo_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_163));
	}

	// Token: 0x060021DC RID: 8668 RVA: 0x000EF58C File Offset: 0x000ED78C
	private void btnCanQuetThuCong_Click(object sender, EventArgs e)
	{
		Class159 @class = this.IEnumerable_2.FirstOrDefault<Class159>();
		if (@class != null)
		{
			if (!Class159.Dictionary_1.ContainsKey(@class.Class432_0.String_2))
			{
				Main.Class328 class2 = new Main.Class328();
				FastTask fastTask = new FastTask(@class);
				class2.tabPage_0 = new TabPage(@class.Class432_0.String_2);
				this.tabCanQuet.TabPages.Add(class2.tabPage_0);
				fastTask.Dock = DockStyle.Fill;
				class2.tabPage_0.Controls.Add(fastTask);
				fastTask.Disposed += class2.method_0;
				this.tabCanQuet.SelectedTab = class2.tabPage_0;
			}
			else
			{
				foreach (object obj in this.tabCanQuet.TabPages)
				{
					TabPage tabPage = (TabPage)obj;
					if (tabPage.Text == @class.Class432_0.String_2)
					{
						this.tabCanQuet.SelectedTab = tabPage;
						break;
					}
				}
			}
			this.tabCanQuet.Visible = true;
			this.tabCanQuet.BringToFront();
		}
	}

	// Token: 0x060021DD RID: 8669 RVA: 0x000198F6 File Offset: 0x00017AF6
	private void toolStripMenuItem_190_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_164));
	}

	// Token: 0x060021DE RID: 8670 RVA: 0x00019922 File Offset: 0x00017B22
	private void toolStripMenuItem_191_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_165));
	}

	// Token: 0x060021DF RID: 8671 RVA: 0x0001994E File Offset: 0x00017B4E
	private void toolStripMenuItem_192_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_166));
	}

	// Token: 0x060021E0 RID: 8672 RVA: 0x0001997A File Offset: 0x00017B7A
	private void thuPetToolStripMenuItem1_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_167));
	}

	// Token: 0x060021E1 RID: 8673 RVA: 0x000199A6 File Offset: 0x00017BA6
	private void toolStripMenuItem_193_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_168));
	}

	// Token: 0x060021E2 RID: 8674 RVA: 0x000199D2 File Offset: 0x00017BD2
	private void toolStripMenuItem_194_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_169));
	}

	// Token: 0x060021E3 RID: 8675 RVA: 0x000199FE File Offset: 0x00017BFE
	private void toolStripMenuItem_195_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_170));
	}

	// Token: 0x060021E4 RID: 8676 RVA: 0x00019A2A File Offset: 0x00017C2A
	private void toolStripMenuItem_196_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_171));
	}

	// Token: 0x060021E5 RID: 8677 RVA: 0x00019A56 File Offset: 0x00017C56
	private void toolStripMenuItem_197_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_172));
	}

	// Token: 0x060021E6 RID: 8678 RVA: 0x00019A82 File Offset: 0x00017C82
	private void toolStripMenuItem_200_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_173));
	}

	// Token: 0x060021E7 RID: 8679 RVA: 0x00019AAE File Offset: 0x00017CAE
	private void toolStripMenuItem_201_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_174));
	}

	// Token: 0x060021E8 RID: 8680 RVA: 0x000EC420 File Offset: 0x000EA620
	private void toolStripMenuItem_202_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_1)
		{
			@class.method_226();
		}
	}

	// Token: 0x060021E9 RID: 8681 RVA: 0x000EF6C8 File Offset: 0x000ED8C8
	private void tabCanQuet_MouseClick(object sender, MouseEventArgs e)
	{
		try
		{
			if (e.Button == MouseButtons.Left && (sender as Control1).GetTabRect(0).Contains(e.Location))
			{
				this.tabCanQuet.Hide();
			}
		}
		catch
		{
		}
	}

	// Token: 0x060021EA RID: 8682 RVA: 0x000EF720 File Offset: 0x000ED920
	private void tabBottom_MouseClick(object sender, MouseEventArgs e)
	{
		try
		{
			if (e.Button == MouseButtons.Left)
			{
				Control1 control = sender as Control1;
				if (control.GetTabRect(control.TabPages.Count - 1).Contains(e.Location))
				{
					this.tabCanQuet.Visible = true;
					control.SendToBack();
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x060021EB RID: 8683 RVA: 0x00002E18 File Offset: 0x00001018
	private void tabBottom_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x060021EC RID: 8684 RVA: 0x00019ADA File Offset: 0x00017CDA
	private void tabBottom_Selecting(object sender, TabControlCancelEventArgs e)
	{
		if (e.TabPageIndex == this.tabBottom.TabPages.Count - 1)
		{
			e.Cancel = true;
		}
	}

	// Token: 0x060021ED RID: 8685 RVA: 0x00019AFD File Offset: 0x00017CFD
	private void tabCanQuet_Selecting(object sender, TabControlCancelEventArgs e)
	{
		if (e.TabPageIndex == 0)
		{
			e.Cancel = true;
		}
	}

	// Token: 0x060021EE RID: 8686 RVA: 0x000EF78C File Offset: 0x000ED98C
	private void toolStripMenuItem_26_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.Where(new Func<Class159, bool>(Main.Class270.<>9.method_175)).ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_176));
	}

	// Token: 0x060021EF RID: 8687 RVA: 0x00019B0E File Offset: 0x00017D0E
	private void toolStripMenuItem_203_Click(object sender, EventArgs e)
	{
		this.IEnumerable_3.smethod_13(new Action<Class159>(Main.Class270.<>9.method_177));
	}

	// Token: 0x060021F0 RID: 8688 RVA: 0x000EF7EC File Offset: 0x000ED9EC
	private void cboPlayer_DropDown(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		List<string> list = new List<string>();
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_7 && !list.Contains(@class.String_2))
				{
					list.Add(@class.String_2);
				}
			}
		}
		ComboBox.ObjectCollection items = this.cboPlayer.Items;
		object[] items2 = new List<string>
		{
			""
		}.Concat(list).ToArray<string>();
		items.AddRange(items2);
	}

	// Token: 0x060021F1 RID: 8689 RVA: 0x00019B3A File Offset: 0x00017D3A
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		Class415.String_31 = this.cboPlayer.Text;
	}

	// Token: 0x060021F2 RID: 8690 RVA: 0x00019B4C File Offset: 0x00017D4C
	private void toolStripMenuItem_204_Click(object sender, EventArgs e)
	{
		this.IEnumerable_5.smethod_13(new Action<Class159>(Main.Class270.<>9.method_178));
	}

	// Token: 0x060021F3 RID: 8691 RVA: 0x000EF908 File Offset: 0x000EDB08
	private void button13_Click(object sender, EventArgs e)
	{
		foreach (Class159 @class in this.IEnumerable_4)
		{
			@class.method_392(true);
		}
		this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_179));
	}

	// Token: 0x060021F4 RID: 8692 RVA: 0x00002E18 File Offset: 0x00001018
	private void tabLog_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060021F5 RID: 8693 RVA: 0x00002E18 File Offset: 0x00001018
	private void Lv_KeyPress(object sender, KeyPressEventArgs e)
	{
	}

	// Token: 0x060021F6 RID: 8694 RVA: 0x000EF984 File Offset: 0x000EDB84
	private void method_180(object sender, EventArgs e)
	{
		Main.Class329 @class = new Main.Class329();
		@class.main_0 = this;
		MessageBox.Show(this, "Bạn cần phải chọn đường dẫn game\r\nFile Game.exe nằm trong thư mục Bin của game", "MicroAuto", MessageBoxButtons.OK);
		@class.openFileDialog_0 = new OpenFileDialog();
		@class.openFileDialog_0.Filter = "Game.exe |Game.exe";
		if (@class.openFileDialog_0.ShowDialog(this) == DialogResult.OK)
		{
			new Thread(new ThreadStart(@class.method_0)).Start();
		}
	}

	// Token: 0x060021F7 RID: 8695 RVA: 0x00002E18 File Offset: 0x00001018
	private void cboPlayer_DrawItem(object sender, DrawItemEventArgs e)
	{
	}

	// Token: 0x060021F8 RID: 8696 RVA: 0x0001740E File Offset: 0x0001560E
	private void button1_Click(object sender, EventArgs e)
	{
		this.method_42();
	}

	// Token: 0x060021F9 RID: 8697 RVA: 0x00019B78 File Offset: 0x00017D78
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060021FC RID: 8700 RVA: 0x00102F48 File Offset: 0x00101148
	[CompilerGenerated]
	private void Lv_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
	{
		if (e.ColumnIndex == 0)
		{
			e.DrawBackground();
			bool flag = false;
			try
			{
				flag = Convert.ToBoolean(e.Header.Tag);
			}
			catch (Exception)
			{
			}
			CheckBoxRenderer.DrawCheckBox(e.Graphics, new Point(e.Bounds.Left + 4, e.Bounds.Top + 4), flag ? CheckBoxState.CheckedNormal : CheckBoxState.UncheckedNormal);
			string text = this.Lv.Columns[0].Text;
			Font font = this.Lv.Font;
			SolidBrush brush = new SolidBrush(Color.Black);
			float x = (float)(e.Bounds.Left + 18);
			float y = (float)(e.Bounds.Top + 5);
			StringFormat stringFormat = new StringFormat();
			stringFormat.FormatFlags = StringFormatFlags.DisplayFormatControl;
			e.Graphics.DrawString(text, font, brush, x, y, stringFormat);
			return;
		}
		e.DrawDefault = true;
	}

	// Token: 0x060021FD RID: 8701 RVA: 0x0010304C File Offset: 0x0010124C
	[CompilerGenerated]
	private void Lv_ColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column == 0)
		{
			this.Lv.BeginUpdate();
			bool flag = false;
			try
			{
				flag = Convert.ToBoolean(this.Lv.Columns[e.Column].Tag);
			}
			catch (Exception)
			{
			}
			this.Lv.Columns[e.Column].Tag = !flag;
			foreach (object obj in this.Lv.Items)
			{
				((ListViewItem)obj).Checked = !flag;
			}
			this.Lv.EndUpdate();
			this.Lv.Invalidate();
		}
	}

	// Token: 0x060021FE RID: 8702 RVA: 0x00019B97 File Offset: 0x00017D97
	[CompilerGenerated]
	private void lvConfig_SubItemClicked(object sender, ListViewEx.SubItemEventArgs e)
	{
		if (e.SubItem == 1)
		{
			this.lvConfig.StartEditing(this.control_0[2], e.Item, e.SubItem);
		}
	}

	// Token: 0x060021FF RID: 8703 RVA: 0x00019BC1 File Offset: 0x00017DC1
	[CompilerGenerated]
	private void lvConfig_Scroll(object sender, ScrollEventArgs e)
	{
		this.lvConfig.EndEditing(false);
	}

	// Token: 0x06002200 RID: 8704 RVA: 0x00019BCF File Offset: 0x00017DCF
	[CompilerGenerated]
	private void lvConfig_SubItemEndEditing(object sender, ListViewEx.SubItemEndEditingEventArgs e)
	{
		if (!this.Boolean_7)
		{
			this.IEnumerable_3.smethod_13(new Action<Class159>(this.method_181));
		}
	}

	// Token: 0x06002201 RID: 8705 RVA: 0x00103130 File Offset: 0x00101330
	[CompilerGenerated]
	private void method_181(Class159 class159_1)
	{
		for (int i = 0; i < 12; i++)
		{
			class159_1.Int32_11[i] = Class426.smethod_43(this.lvConfig.Items[i + 6].SubItems[1].Text);
			if (class159_1.Int32_11[i] == 0)
			{
				class159_1.Int32_11[i] = 1;
			}
		}
		for (int j = 0; j < 9; j++)
		{
			class159_1.Int32_11[j + 13] = Class426.smethod_43(this.lvConfig.Items[j + 6 + 12].SubItems[1].Text);
			if (class159_1.Int32_11[j + 13] == 0)
			{
				class159_1.Int32_11[j + 13] = 1;
			}
		}
		class159_1.Int32_11[21] = this.lvConfig.Items[27].SubItems[1].Text.smethod_37();
	}

	// Token: 0x06002202 RID: 8706 RVA: 0x00019BF0 File Offset: 0x00017DF0
	[CompilerGenerated]
	private bool method_182(int int_13)
	{
		return !this.list_1.Contains(int_13);
	}

	// Token: 0x06002203 RID: 8707 RVA: 0x0010321C File Offset: 0x0010141C
	[CompilerGenerated]
	private void method_183()
	{
		try
		{
			this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_22));
			if (Main.user_0.IsDisposed)
			{
				this.method_28();
				Class159.Class220_0.method_3("nier.ini");
			}
		}
		catch
		{
		}
		try
		{
			foreach (Class159 @class in this.IEnumerable_4)
			{
				if (@class.Boolean_83 && @class.Int32_57 != 0)
				{
					@class.thread_1.Abort();
					@class.method_156();
				}
			}
		}
		catch
		{
		}
		try
		{
			MicroLogin.smethod_1();
		}
		catch
		{
		}
		try
		{
			if (Class268.Class220_0 != null)
			{
				Class412.smethod_0("https://tieudattai.org/microauto/user.php?cmd=ini&do=save&email=" + HttpUtility.UrlEncode(User.string_0) + "&pass=" + HttpUtility.UrlEncode(User.string_1), "content=" + HttpUtility.UrlEncode(Class268.Class220_0.ToString()), null, true);
			}
		}
		catch
		{
		}
		Main.bool_15 = true;
		base.Invoke(new Action(this.method_184));
	}

	// Token: 0x06002204 RID: 8708 RVA: 0x00103384 File Offset: 0x00101584
	[CompilerGenerated]
	private void method_184()
	{
		try
		{
			base.Dispose();
		}
		catch
		{
		}
	}

	// Token: 0x06002205 RID: 8709 RVA: 0x001033AC File Offset: 0x001015AC
	[CompilerGenerated]
	private void method_185()
	{
		try
		{
			if (Alan.Alan_0.Controls.Count > 0 && !Alan.Alan_0.Visible)
			{
				Class438.smethod_15(Alan.Alan_0);
				Alan.Alan_0.method_1();
			}
			if (Alan.Alan_0.Controls.Count == 0 && Alan.Alan_0.Visible)
			{
				Alan.Alan_0.Hide();
			}
			this.method_48();
		}
		catch
		{
		}
	}

	// Token: 0x06002206 RID: 8710 RVA: 0x00103430 File Offset: 0x00101630
	[CompilerGenerated]
	private void method_186()
	{
		if (Main.user_0.IsDisposed)
		{
			try
			{
				this.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(Main.Class270.<>9.method_31));
				this.method_28();
				Class159.Class220_0.method_3("nier.ini");
			}
			catch
			{
			}
			try
			{
				MicroLogin.smethod_1();
			}
			catch
			{
			}
		}
	}

	// Token: 0x06002207 RID: 8711 RVA: 0x00019C01 File Offset: 0x00017E01
	[CompilerGenerated]
	private void method_187(object sender, EventArgs e)
	{
		this.mainMenu.Visible = true;
	}

	// Token: 0x06002208 RID: 8712 RVA: 0x00019C0F File Offset: 0x00017E0F
	[CompilerGenerated]
	private void method_188()
	{
		Main.smethod_11(this.IEnumerable_3.ToList<Class159>());
	}

	// Token: 0x06002209 RID: 8713 RVA: 0x00019C21 File Offset: 0x00017E21
	[CompilerGenerated]
	private void method_189(Class159 class159_1)
	{
		if (this.muVoLuongSon.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_9;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220A RID: 8714 RVA: 0x00019C4D File Offset: 0x00017E4D
	[CompilerGenerated]
	private void method_190(Class159 class159_1)
	{
		if (this.muKinhHo.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_8;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220B RID: 8715 RVA: 0x00019C79 File Offset: 0x00017E79
	[CompilerGenerated]
	private void method_191(Class159 class159_1)
	{
		if (this.muKiemCac.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_10;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220C RID: 8716 RVA: 0x00019CA5 File Offset: 0x00017EA5
	[CompilerGenerated]
	private void method_192(Class159 class159_1)
	{
		if (this.muThaiHo.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_7;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220D RID: 8717 RVA: 0x00019CD1 File Offset: 0x00017ED1
	[CompilerGenerated]
	private void method_193(Class159 class159_1)
	{
		if (this.muTungSon.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_6;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220E RID: 8718 RVA: 0x00019CFD File Offset: 0x00017EFD
	[CompilerGenerated]
	private void method_194(Class159 class159_1)
	{
		if (this.muDonHoang.Checked)
		{
			class159_1.method_51(Enum14.DatDoiAcTac);
			return;
		}
		class159_1.Int32_59 = Class365.Int32_11;
		class159_1.method_48(Enum14.DatDoiAcTac, true);
	}

	// Token: 0x0600220F RID: 8719 RVA: 0x00019D29 File Offset: 0x00017F29
	[CompilerGenerated]
	private void method_195(Class159 class159_1)
	{
		if (this.muTayHo.Checked)
		{
			class159_1.method_51(Enum14.DatDoiTangKinhCac);
			return;
		}
		class159_1.Int32_60 = Class365.Int32_35;
		class159_1.method_48(Enum14.DatDoiTangKinhCac, true);
	}

	// Token: 0x06002210 RID: 8720 RVA: 0x00019D55 File Offset: 0x00017F55
	[CompilerGenerated]
	private void method_196(Class159 class159_1)
	{
		if (this.muNhiHai.Checked)
		{
			class159_1.method_51(Enum14.DatDoiTangKinhCac);
			return;
		}
		class159_1.Int32_60 = Class365.Int32_29;
		class159_1.method_48(Enum14.DatDoiTangKinhCac, true);
	}

	// Token: 0x06002211 RID: 8721 RVA: 0x00019D81 File Offset: 0x00017F81
	[CompilerGenerated]
	private void method_197(Class159 class159_1)
	{
		if (this.muNhanNam.Checked)
		{
			class159_1.method_51(Enum14.DatDoiTangKinhCac);
			return;
		}
		class159_1.Int32_60 = Class365.Int32_67;
		class159_1.method_48(Enum14.DatDoiTangKinhCac, true);
	}

	// Token: 0x06002212 RID: 8722 RVA: 0x00019DAD File Offset: 0x00017FAD
	[CompilerGenerated]
	private void method_198(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiDaTru, !this.muDaTru.Checked);
	}

	// Token: 0x06002213 RID: 8723 RVA: 0x00019DC5 File Offset: 0x00017FC5
	[CompilerGenerated]
	private void method_199(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiKyCuoc, !this.muKyCuocNhanh.Checked);
		class159_1.method_48(Enum14.KyCuocNhanh, !this.muKyCuocNhanh.Checked);
	}

	// Token: 0x06002214 RID: 8724 RVA: 0x00019DF3 File Offset: 0x00017FF3
	[CompilerGenerated]
	private void method_200(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiKyCuoc, !this.muKyCuocCham.Checked);
		class159_1.method_51(Enum14.KyCuocNhanh);
	}

	// Token: 0x06002215 RID: 8725 RVA: 0x00019E13 File Offset: 0x00018013
	[CompilerGenerated]
	private void method_201(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiLauLanTamBao, !this.muLauLanTamBaoNhanh.Checked);
		class159_1.method_48(Enum14.LauLanTamBaoNhanh, !this.muLauLanTamBaoNhanh.Checked);
	}

	// Token: 0x06002216 RID: 8726 RVA: 0x00019E41 File Offset: 0x00018041
	[CompilerGenerated]
	private void method_202(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiLauLanTamBao, !this.muLauLanTamBaoCham.Checked);
		class159_1.method_51(Enum14.LauLanTamBaoNhanh);
	}

	// Token: 0x06002217 RID: 8727 RVA: 0x00019E61 File Offset: 0x00018061
	[CompilerGenerated]
	private void method_203(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiMongHeo, !this.muMongHeo.Checked);
	}

	// Token: 0x06002218 RID: 8728 RVA: 0x00019E79 File Offset: 0x00018079
	[CompilerGenerated]
	private void method_204(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiThienGiangKyThu, !this.muThienGiangKyThu.Checked);
	}

	// Token: 0x06002219 RID: 8729 RVA: 0x00019E91 File Offset: 0x00018091
	[CompilerGenerated]
	private void method_205(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiPhungHoangLangMo, !this.muPhungHoangLangMo.Checked);
	}

	// Token: 0x0600221A RID: 8730 RVA: 0x001034BC File Offset: 0x001016BC
	[CompilerGenerated]
	private void method_206(Class159 class159_1)
	{
		class159_1.method_48(Enum14.ThuTaiVanMay, !this.muToanBoHangNgay.Checked);
		class159_1.method_48(Enum14.LoLyHoa, !this.muToanBoHangNgay.Checked);
		foreach (Class209 @class in class159_1.Class196_0.IEnumerable_0)
		{
			if (@class.String_3 == "nguyenlinhtuyen" && @class.UInt32_5 >= 5U)
			{
				class159_1.method_48(Enum14.NguyenVongThienLinh, !this.muToanBoHangNgay.Checked);
				break;
			}
		}
	}

	// Token: 0x0600221B RID: 8731 RVA: 0x00019EA9 File Offset: 0x000180A9
	[CompilerGenerated]
	private void method_207(Class159 class159_1)
	{
		class159_1.method_48(Enum14.LoLyHoa, !this.muLoLyHoa.Checked);
	}

	// Token: 0x0600221C RID: 8732 RVA: 0x00019EC1 File Offset: 0x000180C1
	[CompilerGenerated]
	private void method_208(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhanPhiThuy, !this.muNhanPhiThuy.Checked);
	}

	// Token: 0x0600221D RID: 8733 RVA: 0x00019ED9 File Offset: 0x000180D9
	[CompilerGenerated]
	private void method_209(Class159 class159_1)
	{
		class159_1.method_48(Enum14.LuyenKimNhanh, !this.muLuyenKimNhanh.Checked);
		class159_1.method_51(Enum14.LuyenKim);
	}

	// Token: 0x0600221E RID: 8734 RVA: 0x00019EF9 File Offset: 0x000180F9
	[CompilerGenerated]
	private void method_210(Class159 class159_1)
	{
		class159_1.method_48(Enum14.LuyenKim, !this.muLuyenKimCham.Checked);
		class159_1.method_51(Enum14.LuyenKimNhanh);
	}

	// Token: 0x0600221F RID: 8735 RVA: 0x00019F19 File Offset: 0x00018119
	[CompilerGenerated]
	private void method_211(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TrungAc, !this.muTrungAc.Checked);
		class159_1.method_389();
	}

	// Token: 0x06002220 RID: 8736 RVA: 0x00019F37 File Offset: 0x00018137
	[CompilerGenerated]
	private void method_212(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuThangCap, !this.muCotTruyenToanBo.Checked);
		class159_1.method_389();
	}

	// Token: 0x06002221 RID: 8737 RVA: 0x00019F55 File Offset: 0x00018155
	[CompilerGenerated]
	private void method_213(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuExp, !this.muNhiemVuExp.Checked);
	}

	// Token: 0x06002222 RID: 8738 RVA: 0x00019F6D File Offset: 0x0001816D
	[CompilerGenerated]
	private void method_214(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuKNBKhoa, !this.muNhiemVuKNB.Checked);
	}

	// Token: 0x06002223 RID: 8739 RVA: 0x00019F85 File Offset: 0x00018185
	[CompilerGenerated]
	private void method_215(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NgoChanNguyen, !this.muNgoChanNguyen.Checked);
	}

	// Token: 0x06002224 RID: 8740 RVA: 0x00019F9D File Offset: 0x0001819D
	[CompilerGenerated]
	private void method_216(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuChinhTuyen, !this.muChinhTuyen.Checked);
	}

	// Token: 0x06002225 RID: 8741 RVA: 0x00019FB5 File Offset: 0x000181B5
	[CompilerGenerated]
	private void method_217(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuSuMon, !this.muSuMon.Checked);
	}

	// Token: 0x06002226 RID: 8742 RVA: 0x00019FCD File Offset: 0x000181CD
	[CompilerGenerated]
	private void method_218(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoBaoTangDo, !this.muMoBaoTangDo.Checked);
	}

	// Token: 0x06002227 RID: 8743 RVA: 0x00019FE5 File Offset: 0x000181E5
	[CompilerGenerated]
	private void method_219(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuDuongCon, !this.muTuDuong.Checked);
		class159_1.String_12 = "";
	}

	// Token: 0x06002228 RID: 8744 RVA: 0x0001A008 File Offset: 0x00018208
	[CompilerGenerated]
	private void method_220(Class159 class159_1)
	{
		class159_1.method_48(Enum14.LongPhuMau, !this.muPhuMau.Checked);
	}

	// Token: 0x06002229 RID: 8745 RVA: 0x0001A020 File Offset: 0x00018220
	[CompilerGenerated]
	private void method_221(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhanCon, !this.muNhanCon.Checked);
	}

	// Token: 0x0600222A RID: 8746 RVA: 0x0001A038 File Offset: 0x00018238
	[CompilerGenerated]
	private void method_222(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuBaoBon, !this.muTuBaoBon.Checked);
	}

	// Token: 0x0600222B RID: 8747 RVA: 0x0001A050 File Offset: 0x00018250
	[CompilerGenerated]
	private void method_223(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TruAc, !this.muThienKiepLau.Checked);
	}

	// Token: 0x0600222C RID: 8748 RVA: 0x0001A068 File Offset: 0x00018268
	[CompilerGenerated]
	private void method_224(Class159 class159_1)
	{
		class159_1.Boolean_90 = !this.muTiemNangTan.Checked;
		if (class159_1.Boolean_90)
		{
			class159_1.method_305();
		}
	}

	// Token: 0x0600222D RID: 8749 RVA: 0x0001A08C File Offset: 0x0001828C
	[CompilerGenerated]
	private void method_225(Class159 class159_1)
	{
		class159_1.method_48(Enum14.BachHoaDuyen, !this.muBachHoaDuyen.Checked);
	}

	// Token: 0x0600222E RID: 8750 RVA: 0x0001A0A4 File Offset: 0x000182A4
	[CompilerGenerated]
	private void method_226(Class159 class159_1)
	{
		class159_1.Boolean_116 = !this.muThanhSangNhatHa.Checked;
	}

	// Token: 0x0600222F RID: 8751 RVA: 0x0001A0BA File Offset: 0x000182BA
	[CompilerGenerated]
	private void method_227(Class159 class159_1)
	{
		class159_1.method_48(Enum14.SinhTieu, !this.muSinhTieu.Checked);
	}

	// Token: 0x06002230 RID: 8752 RVA: 0x0001A0D2 File Offset: 0x000182D2
	[CompilerGenerated]
	private void method_228(Class159 class159_1)
	{
		if (!this.muTriLieu.Checked)
		{
			class159_1.method_48(Enum14.TriLieu, true);
			return;
		}
		class159_1.method_51(Enum14.TriLieu);
	}

	// Token: 0x06002231 RID: 8753 RVA: 0x0001A0F1 File Offset: 0x000182F1
	[CompilerGenerated]
	private void method_229(Class159 class159_1)
	{
		if (!this.muDiBanRac.Checked)
		{
			class159_1.method_48(Enum14.BanRac, true);
			return;
		}
		class159_1.method_51(Enum14.BanRac);
	}

	// Token: 0x06002232 RID: 8754 RVA: 0x0001A110 File Offset: 0x00018310
	[CompilerGenerated]
	private void method_230(Class159 class159_1)
	{
		if (!this.muPhanGiaiTrangBijPet.Checked)
		{
			class159_1.method_48(Enum14.PhanGiaiTrangBiPet, true);
			return;
		}
		class159_1.method_51(Enum14.PhanGiaiTrangBiPet);
	}

	// Token: 0x06002233 RID: 8755 RVA: 0x0001A12F File Offset: 0x0001832F
	[CompilerGenerated]
	private void method_231(Class159 class159_1)
	{
		class159_1.method_48(Enum14.ThuTaiVanMay, !this.muVanMay.Checked);
	}

	// Token: 0x06002234 RID: 8756 RVA: 0x0001A147 File Offset: 0x00018347
	[CompilerGenerated]
	private void method_232(Class159 class159_1)
	{
		class159_1.method_48(Enum14.ThienLongTueHong, !this.muTueHong.Checked);
	}

	// Token: 0x06002235 RID: 8757 RVA: 0x0001A15F File Offset: 0x0001835F
	[CompilerGenerated]
	private void method_233(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NguyenVongThienLinh, !this.muNguyenVong.Checked);
	}

	// Token: 0x06002236 RID: 8758 RVA: 0x0001A177 File Offset: 0x00018377
	[CompilerGenerated]
	private void method_234(Class159 class159_1)
	{
		class159_1.Boolean_73 = this.checkTuyenChien.Checked;
	}

	// Token: 0x06002237 RID: 8759 RVA: 0x0001A18A File Offset: 0x0001838A
	[CompilerGenerated]
	private void method_235(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhanX2, !this.muNhanx2.Checked);
	}

	// Token: 0x06002238 RID: 8760 RVA: 0x0001A1A2 File Offset: 0x000183A2
	[CompilerGenerated]
	private void method_236(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DongX2, !this.muDongx2.Checked);
	}

	// Token: 0x06002239 RID: 8761 RVA: 0x0001A1BA File Offset: 0x000183BA
	[CompilerGenerated]
	private void method_237(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DiMuaNga, !this.muDiMuaNgua.Checked);
	}

	// Token: 0x0600223A RID: 8762 RVA: 0x0001A1D2 File Offset: 0x000183D2
	[CompilerGenerated]
	private void method_238(Class159 class159_1)
	{
		class159_1.method_48(Enum14.HuyVatPhamQuy, !this.muHuyVatPhamQuy.Checked);
	}

	// Token: 0x0600223B RID: 8763 RVA: 0x0001A1EA File Offset: 0x000183EA
	[CompilerGenerated]
	private void method_239(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TrongHoa, !this.muTrongHoa.Checked);
	}

	// Token: 0x0600223C RID: 8764 RVA: 0x0001A202 File Offset: 0x00018402
	[CompilerGenerated]
	private void method_240(Class159 class159_1)
	{
		class159_1.method_48(Enum14.BonHoa, !this.muBonHoa.Checked);
	}

	// Token: 0x0600223D RID: 8765 RVA: 0x0001A21A File Offset: 0x0001841A
	[CompilerGenerated]
	private void method_241(Class159 class159_1)
	{
		class159_1.Boolean_115 = !this.muThuHoach.Checked;
		class159_1.method_389();
	}

	// Token: 0x0600223E RID: 8766 RVA: 0x0001A236 File Offset: 0x00018436
	[CompilerGenerated]
	private void method_242(Class159 class159_1)
	{
		class159_1.Boolean_113 = !this.muTuoiHoaHong.Checked;
	}

	// Token: 0x0600223F RID: 8767 RVA: 0x0001A24C File Offset: 0x0001844C
	[CompilerGenerated]
	private void method_243(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhanQuaBuiHoaHong, !this.muNhanQuaBuiHoa.Checked);
	}

	// Token: 0x06002240 RID: 8768 RVA: 0x0001A264 File Offset: 0x00018464
	[CompilerGenerated]
	private void method_244(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhanHoaHongLo, !this.muNhanHoaHongLo.Checked);
	}

	// Token: 0x06002241 RID: 8769 RVA: 0x0001A27C File Offset: 0x0001847C
	[CompilerGenerated]
	private void method_245(Class159 class159_1)
	{
		class159_1.method_48(Enum14.ChucPhucMaoBut, !this.muChucPhuc.Checked);
	}

	// Token: 0x06002242 RID: 8770 RVA: 0x0001A294 File Offset: 0x00018494
	[CompilerGenerated]
	private void method_246(Class159 class159_1)
	{
		class159_1.method_278(this.IEnumerable_3.ToList<Class159>());
	}

	// Token: 0x06002243 RID: 8771 RVA: 0x0001A2A7 File Offset: 0x000184A7
	[CompilerGenerated]
	private void method_247(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiSatTinh, this.chkSatTinh.Checked);
	}

	// Token: 0x06002244 RID: 8772 RVA: 0x0001A2BC File Offset: 0x000184BC
	[CompilerGenerated]
	private void method_248(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiPhieuMieuPhong, this.chkPhieuMieuPhong.Checked);
	}

	// Token: 0x06002245 RID: 8773 RVA: 0x0001A2D1 File Offset: 0x000184D1
	[CompilerGenerated]
	private void method_249(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiKhieuChienPhieuMieuPhong, this.chkHuyetChien.Checked);
	}

	// Token: 0x06002246 RID: 8774 RVA: 0x0001A2E6 File Offset: 0x000184E6
	[CompilerGenerated]
	private void method_250(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiYenTuO, this.chkYenTuO.Checked);
	}

	// Token: 0x06002247 RID: 8775 RVA: 0x0001A2FB File Offset: 0x000184FB
	[CompilerGenerated]
	private void method_251(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiTuTuyetTrang, this.chkTuTuyetTrang.Checked);
	}

	// Token: 0x06002248 RID: 8776 RVA: 0x0001A310 File Offset: 0x00018510
	[CompilerGenerated]
	private void method_252(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiThieuThatSon, this.chkThieuThatSon.Checked);
	}

	// Token: 0x06002249 RID: 8777 RVA: 0x0001A325 File Offset: 0x00018525
	[CompilerGenerated]
	private void method_253(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiPhucDia, this.chkPhucDia.Checked);
	}

	// Token: 0x0600224A RID: 8778 RVA: 0x0001A33A File Offset: 0x0001853A
	[CompilerGenerated]
	private void method_254(Class159 class159_1)
	{
		class159_1.method_48(Enum14.PhucDiaKho, this.chkPDKho.Checked);
	}

	// Token: 0x0600224B RID: 8779 RVA: 0x0001A34F File Offset: 0x0001854F
	[CompilerGenerated]
	private void method_255(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiQ123LauLan, this.chkQLauLan.Checked);
	}

	// Token: 0x0600224C RID: 8780 RVA: 0x0001A364 File Offset: 0x00018564
	[CompilerGenerated]
	private void method_256(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiQ123ToChau, this.chkQToChau.Checked);
	}

	// Token: 0x0600224D RID: 8781 RVA: 0x0001A379 File Offset: 0x00018579
	[CompilerGenerated]
	private void method_257(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiVuongLang, this.chkVuongLang.Checked);
	}

	// Token: 0x0600224E RID: 8782 RVA: 0x0001A38E File Offset: 0x0001858E
	[CompilerGenerated]
	private void method_258(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiTamThan, this.chkTamThan.Checked);
	}

	// Token: 0x0600224F RID: 8783 RVA: 0x0001A3A3 File Offset: 0x000185A3
	[CompilerGenerated]
	private void method_259(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiMaTac, !this.muDoanBaoMaTac.Checked);
	}

	// Token: 0x06002250 RID: 8784 RVA: 0x0001A3BB File Offset: 0x000185BB
	[CompilerGenerated]
	private void method_260(Class159 class159_1)
	{
		class159_1.Boolean_111 = !this.toolStripMenuItem_13.Checked;
	}

	// Token: 0x06002251 RID: 8785 RVA: 0x00103568 File Offset: 0x00101768
	[CompilerGenerated]
	private void method_261(Class159 class159_1)
	{
		if (class159_1.Class196_0.IEnumerable_6.Where(new Func<Class209, bool>(Main.Class270.<>9.method_75)).FirstOrDefault<Class209>() != null)
		{
			class159_1.method_48(Enum14.ThanKhi9Sao, !this.muThanKhi9Sao.Checked);
			return;
		}
		class159_1.method_51(Enum14.ThanKhi9Sao);
		class159_1.method_410("Chưa có thần khí 8 sao. Dừng nhiệm vụ");
	}

	// Token: 0x06002252 RID: 8786 RVA: 0x0001A3D1 File Offset: 0x000185D1
	[CompilerGenerated]
	private void method_262(Class159 class159_1)
	{
		class159_1.method_48(Enum14.ThanhLyNhiemVu, !this.muThanhLyNhiemVu.Checked);
	}

	// Token: 0x06002253 RID: 8787 RVA: 0x0001A3E9 File Offset: 0x000185E9
	[CompilerGenerated]
	private void method_263(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiTucCau, !this.muTucCau.Checked);
	}

	// Token: 0x06002254 RID: 8788 RVA: 0x001035D8 File Offset: 0x001017D8
	[CompilerGenerated]
	private void method_264(Class159 class159_1)
	{
		if (class159_1.Class196_0.IEnumerable_0.Concat(class159_1.Class196_0.IEnumerable_4).Where(new Func<Class209, bool>(Main.Class270.<>9.method_90)).Select(new Func<Class209, int>(Main.Class270.<>9.method_91)).Sum() >= 15)
		{
			class159_1.method_48(Enum14.NopTuViHuyTinh, !this.muNopTuViHuyTinh.Checked);
			return;
		}
		class159_1.method_410("Không đủ 15 Tử Vi Huy Tinh. Dừng nộp");
	}

	// Token: 0x06002255 RID: 8789 RVA: 0x0001A401 File Offset: 0x00018601
	[CompilerGenerated]
	private void method_265(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoShopBachBaoCac, !this.muMoShopBachBaoCac.Checked);
	}

	// Token: 0x06002256 RID: 8790 RVA: 0x0001A419 File Offset: 0x00018619
	[CompilerGenerated]
	private void method_266(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoShopTrungDo, !this.muMoShopTrungDo.Checked);
	}

	// Token: 0x06002257 RID: 8791 RVA: 0x0001A431 File Offset: 0x00018631
	[CompilerGenerated]
	private void method_267(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoShopHungBa, !this.muMoShopHungBa.Checked);
	}

	// Token: 0x06002258 RID: 8792 RVA: 0x0001A449 File Offset: 0x00018649
	[CompilerGenerated]
	private void method_268(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DoiKimTamTy, !this.muDoiKimTamTy.Checked);
	}

	// Token: 0x06002259 RID: 8793 RVA: 0x0001A461 File Offset: 0x00018661
	[CompilerGenerated]
	private void method_269(Class159 class159_1)
	{
		class159_1.method_48(Enum14.Doi999HoaHong, !this.muDoi999HoaHong.Checked);
	}

	// Token: 0x0600225A RID: 8794 RVA: 0x0001A479 File Offset: 0x00018679
	[CompilerGenerated]
	private void method_270(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DoiLoanPhiMatHam, !this.muDoiLoanPhiMatHam.Checked);
	}

	// Token: 0x0600225B RID: 8795 RVA: 0x0001A491 File Offset: 0x00018691
	[CompilerGenerated]
	private void method_271(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DoiHuyenSacCauThienThai, !this.muDoiHuyenSacCauThienThai.Checked);
	}

	// Token: 0x0600225C RID: 8796 RVA: 0x0001A4A9 File Offset: 0x000186A9
	[CompilerGenerated]
	private void method_272(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DoiTiemNangTan, !this.muDoiTiemNangTan.Checked);
	}

	// Token: 0x0600225D RID: 8797 RVA: 0x0001A4C1 File Offset: 0x000186C1
	[CompilerGenerated]
	private void method_273(Class159 class159_1)
	{
		if (!this.muNhanLeBao.Checked)
		{
			class159_1.method_48(Enum14.NhanLeBao, true);
			return;
		}
		class159_1.method_51(Enum14.NhanLeBao);
	}

	// Token: 0x0600225E RID: 8798 RVA: 0x0001A4E2 File Offset: 0x000186E2
	[CompilerGenerated]
	private void method_274(Class159 class159_1)
	{
		if (!this.muNhanBong.Checked)
		{
			class159_1.method_48(Enum14.NhanBong, true);
			return;
		}
		class159_1.method_51(Enum14.NhanBong);
	}

	// Token: 0x0600225F RID: 8799 RVA: 0x0001A503 File Offset: 0x00018703
	[CompilerGenerated]
	private void method_275(Class159 class159_1)
	{
		if (!this.muNhanThuongQuanSonHai.Checked)
		{
			class159_1.method_48(Enum14.NhanThuongTyVo, true);
			return;
		}
		class159_1.method_51(Enum14.NhanThuongTyVo);
	}

	// Token: 0x06002260 RID: 8800 RVA: 0x0001A524 File Offset: 0x00018724
	[CompilerGenerated]
	private void method_276(Class159 class159_1)
	{
		if (!this.muNhanChienCongKiemChi.Checked)
		{
			class159_1.method_49(new Enum14[]
			{
				Enum14.NhanChienCong,
				Enum14.NhanKiemChi
			});
			return;
		}
		class159_1.method_50(new Enum14[]
		{
			Enum14.NhanChienCong,
			Enum14.NhanKiemChi
		});
	}

	// Token: 0x06002261 RID: 8801 RVA: 0x0001A55C File Offset: 0x0001875C
	[CompilerGenerated]
	private void method_277(Class159 class159_1)
	{
		class159_1.method_48(Enum14.SuaThanKhi, !this.muSuaThanKhi.Checked);
	}

	// Token: 0x06002262 RID: 8802 RVA: 0x0001A574 File Offset: 0x00018774
	[CompilerGenerated]
	private void method_278(Class159 class159_1)
	{
		class159_1.method_48(Enum14.SuaVoHon, !this.muSuaVoHon.Checked);
	}

	// Token: 0x06002263 RID: 8803 RVA: 0x0001A58C File Offset: 0x0001878C
	[CompilerGenerated]
	private void method_279(Class159 class159_1)
	{
		class159_1.method_48(Enum14.SuaTrangBi, !this.muSuaTrangBi.Checked);
	}

	// Token: 0x06002264 RID: 8804 RVA: 0x00103674 File Offset: 0x00101874
	[CompilerGenerated]
	private void method_280(Class159 class159_1)
	{
		class159_1.method_282("POINT = " + this.nudTangTiemNang.Value.ToString() + "; Player:SendAskManualAttr(0, 0, POINT, 0, 0);", false);
	}

	// Token: 0x06002265 RID: 8805 RVA: 0x001036AC File Offset: 0x001018AC
	[CompilerGenerated]
	private void method_281(Class159 class159_1)
	{
		class159_1.method_282("POINT = " + this.nudTangTiemNang.Value.ToString() + "; Player:SendAskManualAttr(0, 0, 0, 0, POINT);", false);
	}

	// Token: 0x06002266 RID: 8806 RVA: 0x001036E4 File Offset: 0x001018E4
	[CompilerGenerated]
	private void method_282(Class159 class159_1)
	{
		class159_1.method_282("POINT = " + this.nudTangTiemNang.Value.ToString() + "; Player:SendAskManualAttr(0, POINT, 0, 0, 0);", false);
	}

	// Token: 0x06002267 RID: 8807 RVA: 0x0010371C File Offset: 0x0010191C
	[CompilerGenerated]
	private void method_283(Class159 class159_1)
	{
		class159_1.method_282("POINT = " + this.nudTangTiemNang.Value.ToString() + "; Player:SendAskManualAttr(POINT, 0, 0, 0, 0);", false);
	}

	// Token: 0x06002268 RID: 8808 RVA: 0x00103754 File Offset: 0x00101954
	[CompilerGenerated]
	private void method_284(Class159 class159_1)
	{
		class159_1.method_282("POINT = " + this.nudTangTiemNang.Value.ToString() + "; Player:SendAskManualAttr(0, 0, 0 , POINT, 0);", false);
	}

	// Token: 0x06002269 RID: 8809 RVA: 0x0001A5A4 File Offset: 0x000187A4
	[CompilerGenerated]
	private void method_285(Class159 class159_1)
	{
		if (!this.muNhanThuongQuanSonHai.Checked)
		{
			class159_1.method_48(Enum14.NhanThuongQuanSonHai, true);
			return;
		}
		class159_1.method_51(Enum14.NhanThuongQuanSonHai);
	}

	// Token: 0x0600226A RID: 8810 RVA: 0x0001A5C5 File Offset: 0x000187C5
	[CompilerGenerated]
	private void method_286(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DoiChanNguyenLinhPhach, !this.muDoiChanNguyenLinhPhach.Checked);
	}

	// Token: 0x0600226B RID: 8811 RVA: 0x0001A5DD File Offset: 0x000187DD
	[CompilerGenerated]
	private void method_287(Class159 class159_1)
	{
		if (!this.muNhanKeoHallowen.Checked)
		{
			class159_1.method_48(Enum14.NhanKeoHallowen, true);
			return;
		}
		class159_1.method_51(Enum14.NhanKeoHallowen);
	}

	// Token: 0x0600226C RID: 8812 RVA: 0x0001A5FE File Offset: 0x000187FE
	[CompilerGenerated]
	private void method_288(Class159 class159_1)
	{
		class159_1.method_48(Enum14.GiaoNguHanhPhapThiep, !this.muGiaoNguHanhPhapThiep.Checked);
	}

	// Token: 0x0600226D RID: 8813 RVA: 0x0001A616 File Offset: 0x00018816
	[CompilerGenerated]
	private void method_289(Class159 class159_1)
	{
		if (!this.muNhanBuaBaoRuong.Checked)
		{
			class159_1.method_48(Enum14.NhanBuaBaoRuong, true);
			return;
		}
		class159_1.method_51(Enum14.NhanBuaBaoRuong);
	}

	// Token: 0x0600226E RID: 8814 RVA: 0x0001A637 File Offset: 0x00018837
	[CompilerGenerated]
	private void method_290(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuLuyenNoiLuc, !this.muTuLuyenNoiLuc.Checked);
	}

	// Token: 0x0600226F RID: 8815 RVA: 0x0001A64F File Offset: 0x0001884F
	[CompilerGenerated]
	private void method_291(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuLuyenTheLuc, !this.muTuLuyenTheLuc.Checked);
	}

	// Token: 0x06002270 RID: 8816 RVA: 0x0001A667 File Offset: 0x00018867
	[CompilerGenerated]
	private void method_292(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuLuyenThanPhap, !this.muTuLuyenThanPhap.Checked);
	}

	// Token: 0x06002271 RID: 8817 RVA: 0x0001A67F File Offset: 0x0001887F
	[CompilerGenerated]
	private void method_293(Class159 class159_1)
	{
		class159_1.List_8.ForEach(new Action<Class159>(this.method_294));
	}

	// Token: 0x06002272 RID: 8818 RVA: 0x0001A698 File Offset: 0x00018898
	[CompilerGenerated]
	private void method_294(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiBinhThanh, this.chkBinhThanh.Checked);
		class159_1.Int32_32 = 0;
		class159_1.int_54 = -1;
	}

	// Token: 0x06002273 RID: 8819 RVA: 0x0001A6BB File Offset: 0x000188BB
	[CompilerGenerated]
	private void method_295(Class159 class159_1)
	{
		class159_1.List_8.ForEach(new Action<Class159>(this.method_296));
	}

	// Token: 0x06002274 RID: 8820 RVA: 0x0001A6D4 File Offset: 0x000188D4
	[CompilerGenerated]
	private void method_296(Class159 class159_1)
	{
		class159_1.method_48(Enum14.BinhThanhKho, this.chkKho.Checked);
		class159_1.Int32_32 = 0;
	}

	// Token: 0x06002275 RID: 8821 RVA: 0x0001A6F0 File Offset: 0x000188F0
	[CompilerGenerated]
	private void method_297(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiTyVo, !this.muTyVo.Checked);
	}

	// Token: 0x06002276 RID: 8822 RVA: 0x0001A708 File Offset: 0x00018908
	[CompilerGenerated]
	private void method_298(Class159 class159_1)
	{
		class159_1.method_48(Enum14.NhiemVuVoY, !this.muVoY.Checked);
	}

	// Token: 0x06002277 RID: 8823 RVA: 0x0001A720 File Offset: 0x00018920
	[CompilerGenerated]
	private void method_299(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiQuanSonHai, !this.muQuanSonHai.Checked);
		class159_1.int_85 = 0;
	}

	// Token: 0x06002278 RID: 8824 RVA: 0x0001A73F File Offset: 0x0001893F
	[CompilerGenerated]
	private void method_300(Class159 class159_1)
	{
		class159_1.method_48(Enum14.VoTuPho, !this.muVoTuPho.Checked);
	}

	// Token: 0x06002279 RID: 8825 RVA: 0x0010378C File Offset: 0x0010198C
	[CompilerGenerated]
	private void method_301(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiAcBa, !this.toolStripMenuItem_131.Checked);
		if (this.toolStripMenuItem_131.Checked)
		{
			class159_1.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_106));
		}
	}

	// Token: 0x0600227A RID: 8826 RVA: 0x0001A757 File Offset: 0x00018957
	[CompilerGenerated]
	private void method_302(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoShopQuyThi, !this.muMoShopQuyThi.Checked);
	}

	// Token: 0x0600227B RID: 8827 RVA: 0x0001A76F File Offset: 0x0001896F
	[CompilerGenerated]
	private void method_303(Class159 class159_1)
	{
		if (!this.muCatDo.Checked)
		{
			class159_1.method_49(new Enum14[]
			{
				Enum14.CatVang,
				Enum14.CatDo
			});
			return;
		}
		class159_1.method_50(new Enum14[]
		{
			Enum14.CatVang,
			Enum14.CatDo
		});
	}

	// Token: 0x0600227C RID: 8828 RVA: 0x0001A7A7 File Offset: 0x000189A7
	[CompilerGenerated]
	private void method_304(Class159 class159_1)
	{
		if (!this.muLayDo.Checked)
		{
			class159_1.method_48(Enum14.LayDo, true);
		}
		else
		{
			class159_1.method_51(Enum14.LayDo);
		}
		class159_1.method_51(Enum14.LayVang);
	}

	// Token: 0x0600227D RID: 8829 RVA: 0x001037E8 File Offset: 0x001019E8
	[CompilerGenerated]
	private void method_305(Class159 class159_1)
	{
		int num = class159_1.Class196_0.IEnumerable_0.Concat(class159_1.Class196_0.IEnumerable_6).Where(new Func<Class209, bool>(Main.Class270.<>9.method_135)).Count<Class209>();
		if (num > 1)
		{
			class159_1.method_410("Có quá nhiều Long Văn. Không biết nâng cái nào");
			class159_1.method_410("Dừng tăng cấp Long Văn");
			return;
		}
		if (num == 0)
		{
			class159_1.method_410("Không có Long Văn để tăng cấp");
			class159_1.method_410("Dừng tăng cấp Long Văn");
			return;
		}
		if (class159_1.Class196_0.IEnumerable_6.Where(new Func<Class209, bool>(Main.Class270.<>9.method_136)).FirstOrDefault<Class209>() != null)
		{
			class159_1.method_410("Long Văn Đã Đạt Cấp 100");
			class159_1.method_410("Dừng tăng cấp Long Văn");
			return;
		}
		class159_1.method_48(Enum14.TangCapTruongThanhLongVan, !this.muTangCapTruongThanhLongVan.Checked);
	}

	// Token: 0x0600227E RID: 8830 RVA: 0x0001A7CE File Offset: 0x000189CE
	[CompilerGenerated]
	private void method_306(Class159 class159_1)
	{
		if (!this.muLayDoLayVang.Checked)
		{
			class159_1.method_49(new Enum14[]
			{
				Enum14.LayDo,
				Enum14.LayVang
			});
			return;
		}
		class159_1.method_50(new Enum14[]
		{
			Enum14.LayDo,
			Enum14.LayVang
		});
	}

	// Token: 0x0600227F RID: 8831 RVA: 0x0001A806 File Offset: 0x00018A06
	[CompilerGenerated]
	private void method_307(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DaiLeHungVuong, !this.muDaiLeHungVuong.Checked);
	}

	// Token: 0x06002280 RID: 8832 RVA: 0x0001A81E File Offset: 0x00018A1E
	[CompilerGenerated]
	private void method_308(Class159 class159_1)
	{
		class159_1.List_25.ForEach(new Action<Class159>(this.method_309));
	}

	// Token: 0x06002281 RID: 8833 RVA: 0x0001A837 File Offset: 0x00018A37
	[CompilerGenerated]
	private void method_309(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DatDoiBaoDoHiem, !this.muBaoDoHiem.Checked);
	}

	// Token: 0x06002282 RID: 8834 RVA: 0x0001A84F File Offset: 0x00018A4F
	[CompilerGenerated]
	private void method_310(Class159 class159_1)
	{
		class159_1.method_48(Enum14.DungDoatBaoRuong, !this.muDungDoatBaoRuong.Checked);
	}

	// Token: 0x06002283 RID: 8835 RVA: 0x0001A867 File Offset: 0x00018A67
	[CompilerGenerated]
	private void method_311(Class159 class159_1)
	{
		class159_1.method_48(Enum14.CheThanKhi, !this.muCheThanKhi.Checked);
	}

	// Token: 0x06002284 RID: 8836 RVA: 0x0001A87F File Offset: 0x00018A7F
	[CompilerGenerated]
	private void method_312(Class159 class159_1)
	{
		class159_1.method_48(Enum14.TuLuyenCuongLuc, !this.muTuLuyenCuongLuc.Checked);
	}

	// Token: 0x06002285 RID: 8837 RVA: 0x0001A897 File Offset: 0x00018A97
	[CompilerGenerated]
	private void method_313(Class159 class159_1)
	{
		class159_1.method_48(Enum14.MoTiemThuoc, !this.muMoTiemThuoc.Checked);
	}

	// Token: 0x06002286 RID: 8838 RVA: 0x0001A8AF File Offset: 0x00018AAF
	[CompilerGenerated]
	private void method_314(Class159 class159_1)
	{
		if (!this.muVanTieu.Checked)
		{
			class159_1.Int32_6 = 1;
			return;
		}
		class159_1.Int32_6 = 0;
	}

	// Token: 0x06002287 RID: 8839 RVA: 0x0001A8CD File Offset: 0x00018ACD
	[CompilerGenerated]
	private void method_315(Class159 class159_1)
	{
		if (!this.muVanTieu.Checked)
		{
			class159_1.Int32_6 = 2;
			return;
		}
		class159_1.Int32_6 = 0;
	}

	// Token: 0x06002288 RID: 8840 RVA: 0x0001A8EB File Offset: 0x00018AEB
	[CompilerGenerated]
	private void method_316(Class159 class159_1)
	{
		if (!this.muVanTieu.Checked)
		{
			class159_1.Int32_6 = 3;
			return;
		}
		class159_1.Int32_6 = 0;
	}

	// Token: 0x06002289 RID: 8841 RVA: 0x0001A909 File Offset: 0x00018B09
	[CompilerGenerated]
	private void method_317(Class159 class159_1)
	{
		if (!this.muVanTieu.Checked)
		{
			class159_1.Int32_6 = 4;
			return;
		}
		class159_1.Int32_6 = 0;
	}

	// Token: 0x0600228A RID: 8842 RVA: 0x0001A927 File Offset: 0x00018B27
	[CompilerGenerated]
	private void method_318(Class159 class159_1)
	{
		class159_1.method_48(Enum14.LinhLuong, !this.muLinhLuong.Checked);
	}

	// Token: 0x0600228B RID: 8843 RVA: 0x0001A93F File Offset: 0x00018B3F
	[CompilerGenerated]
	private void method_319(Class159 class159_1)
	{
		class159_1.method_48(Enum14.Mua100KimSangDuoc, !this.muMua100KimSangDuoc.Checked);
	}

	// Token: 0x04001396 RID: 5014
	private static string string_0 = string.Empty;

	// Token: 0x04001397 RID: 5015
	public AutoPK autoPK_0;

	// Token: 0x04001398 RID: 5016
	private PictureBox pictureBox_0 = new PictureBox();

	// Token: 0x04001399 RID: 5017
	private Label label_0 = new Label();

	// Token: 0x0400139A RID: 5018
	private Label label_1 = new Label();

	// Token: 0x0400139B RID: 5019
	private Label label_2 = new Label();

	// Token: 0x0400139C RID: 5020
	private bool bool_0;

	// Token: 0x0400139D RID: 5021
	private Point point_0 = new Point(0, 0);

	// Token: 0x0400139E RID: 5022
	public static User user_0 = new User
	{
		Dock = DockStyle.Fill
	};

	// Token: 0x0400139F RID: 5023
	public static Class159 class159_0;

	// Token: 0x040013A0 RID: 5024
	private bool bool_1;

	// Token: 0x040013A1 RID: 5025
	public const uint uint_0 = 74U;

	// Token: 0x040013A2 RID: 5026
	private bool bool_2;

	// Token: 0x040013A3 RID: 5027
	private int int_0 = 1;

	// Token: 0x040013A4 RID: 5028
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x040013A5 RID: 5029
	private Stopwatch stopwatch_0 = Stopwatch.StartNew();

	// Token: 0x040013A6 RID: 5030
	public static bool bool_4 = false;

	// Token: 0x040013A7 RID: 5031
	public static int int_1 = -1;

	// Token: 0x040013A8 RID: 5032
	private Dictionary<int, Stopwatch> dictionary_0 = new Dictionary<int, Stopwatch>();

	// Token: 0x040013A9 RID: 5033
	[CompilerGenerated]
	private static string string_1;

	// Token: 0x040013AA RID: 5034
	private bool bool_5;

	// Token: 0x040013AB RID: 5035
	[CompilerGenerated]
	private Dictionary<string, string> dictionary_1;

	// Token: 0x040013AC RID: 5036
	[CompilerGenerated]
	private bool bool_6;

	// Token: 0x040013AD RID: 5037
	[CompilerGenerated]
	private bool bool_7;

	// Token: 0x040013AE RID: 5038
	[CompilerGenerated]
	private bool bool_8;

	// Token: 0x040013AF RID: 5039
	[CompilerGenerated]
	private bool bool_9;

	// Token: 0x040013B0 RID: 5040
	private Dictionary<uint, Stopwatch> dictionary_2 = new Dictionary<uint, Stopwatch>();

	// Token: 0x040013B1 RID: 5041
	private Thread thread_0;

	// Token: 0x040013B2 RID: 5042
	public static bool bool_10 = false;

	// Token: 0x040013B3 RID: 5043
	[CompilerGenerated]
	private static string string_2;

	// Token: 0x040013B4 RID: 5044
	public static Dictionary<int, Class159> dictionary_3 = new Dictionary<int, Class159>();

	// Token: 0x040013B5 RID: 5045
	[CompilerGenerated]
	private bool bool_11;

	// Token: 0x040013B6 RID: 5046
	private static Main.Delegate5 delegate5_0;

	// Token: 0x040013B7 RID: 5047
	private const int int_2 = 10;

	// Token: 0x040013B8 RID: 5048
	private const int int_3 = 0;

	// Token: 0x040013B9 RID: 5049
	private const int int_4 = 100;

	// Token: 0x040013BA RID: 5050
	private byte[] byte_0 = new byte[4096];

	// Token: 0x040013BB RID: 5051
	private DateTimePicker dateTimePicker_0 = new DateTimePicker();

	// Token: 0x040013BC RID: 5052
	private ComboBox comboBox_0 = new ComboBox();

	// Token: 0x040013BD RID: 5053
	private CheckBox checkBox_0 = new CheckBox();

	// Token: 0x040013BE RID: 5054
	private TextBox textBoxComment = new TextBox();

	// Token: 0x040013BF RID: 5055
	private TextBox textBox_0 = new TextBox();

	// Token: 0x040013C0 RID: 5056
	private NumericUpDown numericUpDown_0 = new NumericUpDown();

	// Token: 0x040013C1 RID: 5057
	private Control[] control_0;

	// Token: 0x040013C2 RID: 5058
	public static Setting setting_0 = new Setting
	{
		Dock = DockStyle.Fill
	};

	// Token: 0x040013C3 RID: 5059
	private readonly IDictionary<string, Assembly> idictionary_0 = new Dictionary<string, Assembly>();

	// Token: 0x040013C4 RID: 5060
	public static Class330 class330_0;

	// Token: 0x040013C5 RID: 5061
	[CompilerGenerated]
	private static Main main_0;

	// Token: 0x040013C6 RID: 5062
	public static List<string> list_0 = new List<string>();

	// Token: 0x040013C7 RID: 5063
	private static HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040013C8 RID: 5064
	[CompilerGenerated]
	private bool bool_12;

	// Token: 0x040013C9 RID: 5065
	[CompilerGenerated]
	private bool bool_13;

	// Token: 0x040013CA RID: 5066
	private List<int> list_1 = new List<int>();

	// Token: 0x040013CB RID: 5067
	[CompilerGenerated]
	private static bool bool_14;

	// Token: 0x040013CC RID: 5068
	public static MicroLogin microLogin_0;

	// Token: 0x040013CD RID: 5069
	public static bool bool_15 = false;

	// Token: 0x040013CE RID: 5070
	public static string string_3 = string.Empty;

	// Token: 0x040013CF RID: 5071
	public static int int_5 = 0;

	// Token: 0x040013D0 RID: 5072
	public static int int_6 = 999999;

	// Token: 0x040013D1 RID: 5073
	private List<Class159> list_2 = new List<Class159>();

	// Token: 0x040013D2 RID: 5074
	[CompilerGenerated]
	private static bool bool_16;

	// Token: 0x040013D3 RID: 5075
	public static Dictionary<string, Color> dictionary_4 = new Dictionary<string, Color>
	{
		{
			"FFFFFFFF",
			Color.Red
		},
		{
			"FFFFFFFFFFFFFFFF",
			Color.Red
		}
	};

	// Token: 0x040013D4 RID: 5076
	private static readonly Random random_0 = new Random();

	// Token: 0x040013D5 RID: 5077
	public static List<Class159> list_3 = new List<Class159>();

	// Token: 0x040013D6 RID: 5078
	[CompilerGenerated]
	private static int int_7;

	// Token: 0x040013D7 RID: 5079
	private Trader trader_0;

	// Token: 0x040013D8 RID: 5080
	private Pk pk_0 = new Pk();

	// Token: 0x040013D9 RID: 5081
	public static bool bool_17 = false;

	// Token: 0x040013DA RID: 5082
	[CompilerGenerated]
	private bool bool_18;

	// Token: 0x040013DB RID: 5083
	public static List<ListViewItem> list_4 = new List<ListViewItem>();

	// Token: 0x040013DC RID: 5084
	public static List<ListViewItem> list_5 = new List<ListViewItem>();

	// Token: 0x040013DD RID: 5085
	public static int int_8 = -1;

	// Token: 0x040013DE RID: 5086
	public static Stopwatch stopwatch_1 = Stopwatch.StartNew();

	// Token: 0x040013DF RID: 5087
	public static bool bool_19 = false;

	// Token: 0x040013E0 RID: 5088
	private bool bool_20;

	// Token: 0x040013E1 RID: 5089
	public static int int_9 = Class380.int_1;

	// Token: 0x040013E2 RID: 5090
	public static bool bool_21 = false;

	// Token: 0x040013E3 RID: 5091
	public static string string_4 = "";

	// Token: 0x040013E4 RID: 5092
	public static bool bool_22;

	// Token: 0x040013E5 RID: 5093
	public static int int_10 = 500000;

	// Token: 0x040013E6 RID: 5094
	[CompilerGenerated]
	private Control control_1;

	// Token: 0x040013E7 RID: 5095
	[CompilerGenerated]
	private static bool bool_23;

	// Token: 0x040013E8 RID: 5096
	[CompilerGenerated]
	private static bool bool_24;

	// Token: 0x040013E9 RID: 5097
	[CompilerGenerated]
	private static bool bool_25;

	// Token: 0x040013EA RID: 5098
	[CompilerGenerated]
	private static GClass25 gclass25_0;

	// Token: 0x040013EB RID: 5099
	private static string string_5 = "";

	// Token: 0x040013EC RID: 5100
	public static bool bool_26 = false;

	// Token: 0x040013ED RID: 5101
	[CompilerGenerated]
	private static string string_6;

	// Token: 0x040013EE RID: 5102
	[CompilerGenerated]
	private static bool bool_27;

	// Token: 0x040013EF RID: 5103
	[CompilerGenerated]
	private static bool bool_28;

	// Token: 0x040013F0 RID: 5104
	[CompilerGenerated]
	private static int int_11;

	// Token: 0x040013F1 RID: 5105
	[CompilerGenerated]
	private static bool bool_29;

	// Token: 0x040013F2 RID: 5106
	[CompilerGenerated]
	private static bool bool_30;

	// Token: 0x040013F3 RID: 5107
	[CompilerGenerated]
	private static bool bool_31;

	// Token: 0x040013F4 RID: 5108
	[CompilerGenerated]
	private static string string_7;

	// Token: 0x040013F5 RID: 5109
	[CompilerGenerated]
	private static bool bool_32;

	// Token: 0x040013F6 RID: 5110
	[CompilerGenerated]
	private static bool bool_33;

	// Token: 0x040013F7 RID: 5111
	[CompilerGenerated]
	private static bool bool_34;

	// Token: 0x040013F8 RID: 5112
	private List<int> list_6 = new List<int>();

	// Token: 0x040013F9 RID: 5113
	[CompilerGenerated]
	private static bool bool_35;

	// Token: 0x040013FA RID: 5114
	[CompilerGenerated]
	private static int int_12;

	// Token: 0x02000237 RID: 567
	// (Invoke) Token: 0x0600228D RID: 8845
	public delegate void Delegate1(Class159 game);

	// Token: 0x02000238 RID: 568
	// (Invoke) Token: 0x06002291 RID: 8849
	public delegate void Delegate2(string log);

	// Token: 0x02000239 RID: 569
	// (Invoke) Token: 0x06002295 RID: 8853
	public delegate void Delegate3(Class159 game);

	// Token: 0x0200023A RID: 570
	// (Invoke) Token: 0x06002299 RID: 8857
	public delegate void Delegate4(List<Class159> games);

	// Token: 0x0200023B RID: 571
	private enum Enum15
	{
		// Token: 0x04001688 RID: 5768
		None,
		// Token: 0x04001689 RID: 5769
		Alt,
		// Token: 0x0400168A RID: 5770
		Control,
		// Token: 0x0400168B RID: 5771
		Shift = 4,
		// Token: 0x0400168C RID: 5772
		WinKey = 8
	}

	// Token: 0x0200023C RID: 572
	private struct Struct3
	{
		// Token: 0x0400168D RID: 5773
		public int int_0;

		// Token: 0x0400168E RID: 5774
		public int int_1;

		// Token: 0x0400168F RID: 5775
		public IntPtr intptr_0;
	}

	// Token: 0x0200023D RID: 573
	// (Invoke) Token: 0x0600229D RID: 8861
	private delegate int Delegate5(uint msg, int flag);

	// Token: 0x0200023E RID: 574
	public class Class269
	{
		// Token: 0x17000766 RID: 1894
		// (get) Token: 0x060022A0 RID: 8864 RVA: 0x0001A957 File Offset: 0x00018B57
		// (set) Token: 0x060022A1 RID: 8865 RVA: 0x0001A95F File Offset: 0x00018B5F
		public string String_0 { get; set; }

		// Token: 0x17000767 RID: 1895
		// (get) Token: 0x060022A2 RID: 8866 RVA: 0x0001A968 File Offset: 0x00018B68
		// (set) Token: 0x060022A3 RID: 8867 RVA: 0x0001A970 File Offset: 0x00018B70
		public int Int32_0 { get; set; }

		// Token: 0x060022A4 RID: 8868 RVA: 0x0001A979 File Offset: 0x00018B79
		public virtual string ToString()
		{
			return this.String_0;
		}

		// Token: 0x04001690 RID: 5776
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04001691 RID: 5777
		[CompilerGenerated]
		private int int_0;
	}

	// Token: 0x0200023F RID: 575
	// (Invoke) Token: 0x060022A7 RID: 8871
	private delegate void Delegate6(string content);

	// Token: 0x02000240 RID: 576
	[CompilerGenerated]
	[Serializable]
	private sealed class Class270
	{
		// Token: 0x060022AC RID: 8876 RVA: 0x000172DF File Offset: 0x000154DF
		internal void method_0(Class159 class159_0)
		{
			class159_0.method_86();
		}

		// Token: 0x060022AD RID: 8877 RVA: 0x0001A98D File Offset: 0x00018B8D
		internal void method_1(Class159 class159_0)
		{
			class159_0.method_222();
		}

		// Token: 0x060022AE RID: 8878 RVA: 0x0001A995 File Offset: 0x00018B95
		internal void method_2(Class159 class159_0)
		{
			class159_0.Class368_0.method_38();
		}

		// Token: 0x060022AF RID: 8879 RVA: 0x0001A9A2 File Offset: 0x00018BA2
		internal void method_3(Class159 class159_0)
		{
			class159_0.method_231();
		}

		// Token: 0x060022B0 RID: 8880 RVA: 0x0001A9AA File Offset: 0x00018BAA
		internal void method_4(object sender, DrawListViewItemEventArgs e)
		{
			e.DrawDefault = true;
		}

		// Token: 0x060022B1 RID: 8881 RVA: 0x0001A9B3 File Offset: 0x00018BB3
		internal void method_5(object sender, DrawListViewSubItemEventArgs e)
		{
			e.DrawDefault = true;
		}

		// Token: 0x060022B2 RID: 8882 RVA: 0x000B19D8 File Offset: 0x000AFBD8
		internal double method_6(Class159 class159_0)
		{
			return class159_0.stopwatch_14.Elapsed.TotalSeconds;
		}

		// Token: 0x060022B3 RID: 8883 RVA: 0x0001A9BC File Offset: 0x00018BBC
		internal bool method_7(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return keyValuePair_0.Value.Process_0.HasExited;
		}

		// Token: 0x060022B4 RID: 8884 RVA: 0x0001A9CF File Offset: 0x00018BCF
		internal void method_8()
		{
			Class415.class220_0 = new Class220(Class412.smethod_1("http://tieudattai.org/map.php", null, true));
		}

		// Token: 0x060022B5 RID: 8885 RVA: 0x001038D4 File Offset: 0x00101AD4
		internal bool method_9(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return keyValuePair_0.Value.Stopwatch_0.Elapsed.TotalSeconds < 120.0 && !keyValuePair_0.Value.Boolean_9 && !keyValuePair_0.Value.Class432_0.Boolean_34;
		}

		// Token: 0x060022B6 RID: 8886 RVA: 0x00015715 File Offset: 0x00013915
		internal Class159 method_10(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return keyValuePair_0.Value;
		}

		// Token: 0x060022B7 RID: 8887 RVA: 0x0001A9E7 File Offset: 0x00018BE7
		internal bool method_11(Class159 class159_0)
		{
			return class159_0.Class432_0.Boolean_34;
		}

		// Token: 0x060022B8 RID: 8888 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_12(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x060022B9 RID: 8889 RVA: 0x00016768 File Offset: 0x00014968
		internal string method_13(int int_0)
		{
			return int_0.ToString();
		}

		// Token: 0x060022BA RID: 8890 RVA: 0x00016486 File Offset: 0x00014686
		internal int method_14(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.DisplayIndex;
		}

		// Token: 0x060022BB RID: 8891 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_15(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x060022BC RID: 8892 RVA: 0x00016486 File Offset: 0x00014686
		internal int method_16(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.DisplayIndex;
		}

		// Token: 0x060022BD RID: 8893 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_17(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x060022BE RID: 8894 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_18(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x060022BF RID: 8895 RVA: 0x0001648E File Offset: 0x0001468E
		internal int method_19(ColumnHeader columnHeader_0)
		{
			return columnHeader_0.Width;
		}

		// Token: 0x060022C0 RID: 8896 RVA: 0x0001A9F4 File Offset: 0x00018BF4
		internal void method_20(Class159 class159_0)
		{
			class159_0.method_83();
		}

		// Token: 0x060022C1 RID: 8897 RVA: 0x0001A9FC File Offset: 0x00018BFC
		internal void method_21()
		{
			Thread.Sleep(10000);
			Application.Exit();
		}

		// Token: 0x060022C2 RID: 8898 RVA: 0x0001AA0D File Offset: 0x00018C0D
		internal void method_22(Class159 class159_0)
		{
			class159_0.method_389();
		}

		// Token: 0x060022C3 RID: 8899 RVA: 0x0001AA15 File Offset: 0x00018C15
		internal bool method_23(KeyValuePair<string, FastTask> keyValuePair_0)
		{
			return !keyValuePair_0.Value.IsDisposed;
		}

		// Token: 0x060022C4 RID: 8900 RVA: 0x0001AA26 File Offset: 0x00018C26
		internal string method_24(KeyValuePair<string, FastTask> keyValuePair_0)
		{
			return keyValuePair_0.Key;
		}

		// Token: 0x060022C5 RID: 8901 RVA: 0x0001AA2F File Offset: 0x00018C2F
		internal FastTask method_25(KeyValuePair<string, FastTask> keyValuePair_0)
		{
			return keyValuePair_0.Value;
		}

		// Token: 0x060022C6 RID: 8902 RVA: 0x0001AA38 File Offset: 0x00018C38
		internal Class159 method_26(ListViewItem listViewItem_0)
		{
			return listViewItem_0.Tag as Class159;
		}

		// Token: 0x060022C7 RID: 8903 RVA: 0x0001AA45 File Offset: 0x00018C45
		internal bool method_27(Class159 class159_0)
		{
			return class159_0.Class432_0.Boolean_32;
		}

		// Token: 0x060022C8 RID: 8904 RVA: 0x0001A9E7 File Offset: 0x00018BE7
		internal bool method_28(Class159 class159_0)
		{
			return class159_0.Class432_0.Boolean_34;
		}

		// Token: 0x060022C9 RID: 8905 RVA: 0x00015715 File Offset: 0x00013915
		internal Class159 method_29(KeyValuePair<int, Class159> keyValuePair_0)
		{
			return keyValuePair_0.Value;
		}

		// Token: 0x060022CA RID: 8906 RVA: 0x0001A9E7 File Offset: 0x00018BE7
		internal bool method_30(Class159 class159_0)
		{
			return class159_0.Class432_0.Boolean_34;
		}

		// Token: 0x060022CB RID: 8907 RVA: 0x0001AA0D File Offset: 0x00018C0D
		internal void method_31(Class159 class159_0)
		{
			class159_0.method_389();
		}

		// Token: 0x060022CC RID: 8908 RVA: 0x0010392C File Offset: 0x00101B2C
		internal void method_32()
		{
			Thread.CurrentThread.IsBackground = true;
			for (;;)
			{
				Thread.CurrentThread.IsBackground = true;
				try
				{
					if (Main.GClass25_0 == null)
					{
						Main.GClass25_0 = new GClass25("wss://tieudattai.org:8443", new string[0]);
						Main.GClass25_0.GClass32_0.RemoteCertificateValidationCallback_0 = new RemoteCertificateValidationCallback(Main.Class270.<>9.method_33);
						Main.GClass25_0.GClass32_0.SslProtocols_0 = (SslProtocols.Ssl2 | SslProtocols.Ssl3 | SslProtocols.Tls);
						Main.GClass25_0.Event_2 += Main.smethod_10;
						Main.GClass25_0.Event_3 += Main.smethod_9;
						Main.GClass25_0.Event_0 += Main.smethod_8;
						Main.GClass25_0.Event_1 += Main.smethod_7;
						Main.GClass25_0.method_82();
						Main.GClass25_0.method_88("email=" + User.string_0 + "&password=" + User.string_1);
					}
					else if (!Main.GClass25_0.method_84())
					{
						Main.String_1 = "Close";
						Main.String_1 = "Opening";
						Main.GClass25_0.Event_2 -= Main.smethod_10;
						Main.GClass25_0.Event_3 -= Main.smethod_9;
						Main.GClass25_0.Event_0 -= Main.smethod_8;
						Main.GClass25_0.Event_1 -= Main.smethod_7;
						Main.GClass25_0 = new GClass25("wss://tieudattai.org:8443", new string[0]);
						Main.GClass25_0.Event_2 += Main.smethod_10;
						Main.GClass25_0.Event_3 += Main.smethod_9;
						Main.GClass25_0.Event_0 += Main.smethod_8;
						Main.GClass25_0.Event_1 += Main.smethod_7;
						Main.GClass25_0.method_82();
						Main.GClass25_0.method_88("email=" + User.string_0 + "&password=" + User.string_1);
					}
				}
				catch
				{
				}
				Thread.Sleep(5000);
			}
		}

		// Token: 0x060022CD RID: 8909 RVA: 0x0000354C File Offset: 0x0000174C
		internal bool method_33(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
		{
			return true;
		}

		// Token: 0x060022CE RID: 8910 RVA: 0x0000DEEA File Offset: 0x0000C0EA
		internal string method_34(Class159 class159_0)
		{
			return class159_0.Class432_0.String_2;
		}

		// Token: 0x060022CF RID: 8911 RVA: 0x0001AA52 File Offset: 0x00018C52
		internal void method_35(Class159 class159_0)
		{
			class159_0.method_49(new Enum14[]
			{
				Enum14.TriLieu,
				Enum14.BanRac,
				Enum14.CatVang,
				Enum14.CatDo
			});
		}

		// Token: 0x060022D0 RID: 8912 RVA: 0x0001AA6B File Offset: 0x00018C6B
		internal bool method_36(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.TriLieu);
		}

		// Token: 0x060022D1 RID: 8913 RVA: 0x0001AA7C File Offset: 0x00018C7C
		internal bool method_37(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.BanRac);
		}

		// Token: 0x060022D2 RID: 8914 RVA: 0x0001AA8D File Offset: 0x00018C8D
		internal bool method_38(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.CatVang) && !class159_0.List_0.Contains(Enum14.CatDo);
		}

		// Token: 0x060022D3 RID: 8915 RVA: 0x0001AAAE File Offset: 0x00018CAE
		internal bool method_39(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.LayDo);
		}

		// Token: 0x060022D4 RID: 8916 RVA: 0x0001AABF File Offset: 0x00018CBF
		internal bool method_40(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.LayDo) || !class159_0.List_0.Contains(Enum14.LayVang);
		}

		// Token: 0x060022D5 RID: 8917 RVA: 0x0001AAE0 File Offset: 0x00018CE0
		internal bool method_41(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.PhanGiaiTrangBiPet);
		}

		// Token: 0x060022D6 RID: 8918 RVA: 0x0001AAF1 File Offset: 0x00018CF1
		internal bool method_42(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanChienCong) || !class159_0.List_0.Contains(Enum14.NhanKiemChi);
		}

		// Token: 0x060022D7 RID: 8919 RVA: 0x0001AB12 File Offset: 0x00018D12
		internal bool method_43(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanThuongQuanSonHai);
		}

		// Token: 0x060022D8 RID: 8920 RVA: 0x0001AB24 File Offset: 0x00018D24
		internal bool method_44(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanBuaBaoRuong);
		}

		// Token: 0x060022D9 RID: 8921 RVA: 0x0001AB36 File Offset: 0x00018D36
		internal bool method_45(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanLeBao);
		}

		// Token: 0x060022DA RID: 8922 RVA: 0x0001AB48 File Offset: 0x00018D48
		internal bool method_46(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanBong);
		}

		// Token: 0x060022DB RID: 8923 RVA: 0x0001AB5A File Offset: 0x00018D5A
		internal bool method_47(Class159 class159_0)
		{
			return !class159_0.List_0.Contains(Enum14.NhanKeoHallowen);
		}

		// Token: 0x060022DC RID: 8924 RVA: 0x00103B80 File Offset: 0x00101D80
		internal void method_48(Class159 class159_0)
		{
			class159_0.String_21 = "187,113," + Class365.Int32_45.ToString();
		}

		// Token: 0x060022DD RID: 8925 RVA: 0x00103BAC File Offset: 0x00101DAC
		internal void method_49(Class159 class159_0)
		{
			class159_0.String_21 = "114,122," + Class365.Int32_45.ToString();
		}

		// Token: 0x060022DE RID: 8926 RVA: 0x00103BD8 File Offset: 0x00101DD8
		internal void method_50(Class159 class159_0)
		{
			class159_0.String_21 = "27,124," + Class365.Int32_45.ToString();
		}

		// Token: 0x060022DF RID: 8927 RVA: 0x00103C04 File Offset: 0x00101E04
		internal void method_51(Class159 class159_0)
		{
			class159_0.String_21 = "223,225," + Class365.Int32_46.ToString();
		}

		// Token: 0x060022E0 RID: 8928 RVA: 0x00103C30 File Offset: 0x00101E30
		internal void method_52(Class159 class159_0)
		{
			class159_0.String_21 = "134,41," + Class365.Int32_46.ToString();
		}

		// Token: 0x060022E1 RID: 8929 RVA: 0x00103C5C File Offset: 0x00101E5C
		internal void method_53(Class159 class159_0)
		{
			class159_0.String_21 = "224,216," + Class365.Int32_47.ToString();
		}

		// Token: 0x060022E2 RID: 8930 RVA: 0x00103C88 File Offset: 0x00101E88
		internal void method_54(Class159 class159_0)
		{
			class159_0.String_21 = "31,33," + Class365.Int32_48.ToString();
		}

		// Token: 0x060022E3 RID: 8931 RVA: 0x00103CB4 File Offset: 0x00101EB4
		internal void method_55(Class159 class159_0)
		{
			class159_0.String_21 = "216,156," + Class365.Int32_44.ToString();
		}

		// Token: 0x060022E4 RID: 8932 RVA: 0x0001AB6C File Offset: 0x00018D6C
		internal void method_56(Class159 class159_0)
		{
			class159_0.method_290(22);
		}

		// Token: 0x060022E5 RID: 8933 RVA: 0x0001AB76 File Offset: 0x00018D76
		internal void method_57(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_1", uint.MaxValue);
		}

		// Token: 0x060022E6 RID: 8934 RVA: 0x0001AB85 File Offset: 0x00018D85
		internal void method_58(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_2", uint.MaxValue);
		}

		// Token: 0x060022E7 RID: 8935 RVA: 0x0001AB94 File Offset: 0x00018D94
		internal void method_59(Class159 class159_0)
		{
			class159_0.method_270();
		}

		// Token: 0x060022E8 RID: 8936 RVA: 0x0001AB9C File Offset: 0x00018D9C
		internal void method_60(Class159 class159_0)
		{
			class159_0.method_272();
		}

		// Token: 0x060022E9 RID: 8937 RVA: 0x0001ABA4 File Offset: 0x00018DA4
		internal void method_61(Class159 class159_0)
		{
			class159_0.method_313("FightSkillXinShou_1", uint.MaxValue);
		}

		// Token: 0x060022EA RID: 8938 RVA: 0x0001ABB3 File Offset: 0x00018DB3
		internal void method_62(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class297
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x060022EB RID: 8939 RVA: 0x0001ABD6 File Offset: 0x00018DD6
		internal void method_63(Class159 class159_0)
		{
			class159_0.method_282("nAgnameNum = Player:GetAgnameNum(); if nAgnameNum > 0 then setmetatable(_G, { __index = Agname_Env}); Player:SetNullAgname(); end for i=1, 10 do if Pet:IsPresent(i-1) then if Pet:GetIsFighting(i-1) then  setmetatable(_G, {__index = PetAgname_Env}); num = Pet:GetTitleNum(i-1);  if num > 0 then  Pet:SetNullCurTitle(i-1);  end end end end", false);
		}

		// Token: 0x060022EC RID: 8940 RVA: 0x0001ABE4 File Offset: 0x00018DE4
		internal void method_64(Class159 class159_0)
		{
			class159_0.method_161();
		}

		// Token: 0x060022ED RID: 8941 RVA: 0x0001A995 File Offset: 0x00018B95
		internal void method_65(Class159 class159_0)
		{
			class159_0.Class368_0.method_38();
		}

		// Token: 0x060022EE RID: 8942 RVA: 0x0001ABEC File Offset: 0x00018DEC
		internal void method_66(Class159 class159_0)
		{
			if (class159_0.Class432_0.UInt32_28 == 9U)
			{
				class159_0.Class368_0.method_24();
			}
		}

		// Token: 0x060022EF RID: 8943 RVA: 0x0001AC08 File Offset: 0x00018E08
		internal void method_67(Class159 class159_0)
		{
			class159_0.method_60();
		}

		// Token: 0x060022F0 RID: 8944 RVA: 0x0001AB94 File Offset: 0x00018D94
		internal void method_68(Class159 class159_0)
		{
			class159_0.method_270();
		}

		// Token: 0x060022F1 RID: 8945 RVA: 0x0001AB9C File Offset: 0x00018D9C
		internal void method_69(Class159 class159_0)
		{
			class159_0.method_272();
		}

		// Token: 0x060022F2 RID: 8946 RVA: 0x0001AB85 File Offset: 0x00018D85
		internal void method_70(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_2", uint.MaxValue);
		}

		// Token: 0x060022F3 RID: 8947 RVA: 0x0001AB76 File Offset: 0x00018D76
		internal void method_71(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_1", uint.MaxValue);
		}

		// Token: 0x060022F4 RID: 8948 RVA: 0x0001AC10 File Offset: 0x00018E10
		internal void method_72(Class159 class159_0)
		{
			class159_0.method_176();
		}

		// Token: 0x060022F5 RID: 8949 RVA: 0x0001AC18 File Offset: 0x00018E18
		internal void method_73(Class159 class159_0)
		{
			class159_0.method_46();
		}

		// Token: 0x060022F6 RID: 8950 RVA: 0x0001AC20 File Offset: 0x00018E20
		internal void method_74(Class159 class159_0)
		{
			class159_0.method_415();
		}

		// Token: 0x060022F7 RID: 8951 RVA: 0x000B17EC File Offset: 0x000AF9EC
		internal bool method_75(Class209 class209_0)
		{
			return Class159.hashSet_4.Contains(class209_0.String_1) && (Class426.smethod_41(class209_0.UInt32_7.ToString().Substring(0, 1)) >= 8 || Class426.smethod_41(class209_0.UInt32_7.ToString()) >= 80);
		}

		// Token: 0x060022F8 RID: 8952 RVA: 0x0001AC28 File Offset: 0x00018E28
		internal void method_76(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class305
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x060022F9 RID: 8953 RVA: 0x0001AC4B File Offset: 0x00018E4B
		internal void method_77(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.method_57(0, 988);
		}

		// Token: 0x060022FA RID: 8954 RVA: 0x0001AC5F File Offset: 0x00018E5F
		internal void method_78(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.Boolean_65 = false;
		}

		// Token: 0x060022FB RID: 8955 RVA: 0x0001AC6E File Offset: 0x00018E6E
		internal bool method_79(TabLogin tabLogin_0)
		{
			return tabLogin_0.Parent.Text != "Offline";
		}

		// Token: 0x060022FC RID: 8956 RVA: 0x0001AC85 File Offset: 0x00018E85
		internal void method_80(TabLogin tabLogin_0)
		{
			tabLogin_0.Parent.Dispose();
			tabLogin_0.Dispose();
		}

		// Token: 0x060022FD RID: 8957 RVA: 0x0001AC98 File Offset: 0x00018E98
		internal bool method_81(TabLogin tabLogin_0)
		{
			return tabLogin_0.Parent.Text == "Offline";
		}

		// Token: 0x060022FE RID: 8958 RVA: 0x00016629 File Offset: 0x00014829
		internal void method_82(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.list_14.Clear();
		}

		// Token: 0x060022FF RID: 8959 RVA: 0x0001ACAF File Offset: 0x00018EAF
		internal void method_83(Class159 class159_0)
		{
			class159_0.method_162();
		}

		// Token: 0x06002300 RID: 8960 RVA: 0x0001ACB7 File Offset: 0x00018EB7
		internal void method_84(Class159 class159_0)
		{
			class159_0.method_160();
		}

		// Token: 0x06002301 RID: 8961 RVA: 0x0001ACBF File Offset: 0x00018EBF
		internal void method_85(Class159 class159_0)
		{
			class159_0.method_147();
		}

		// Token: 0x06002302 RID: 8962 RVA: 0x0001ACC7 File Offset: 0x00018EC7
		internal void method_86(Class159 class159_0)
		{
			class159_0.method_49(new Enum14[]
			{
				Enum14.BanRac,
				Enum14.CatVang,
				Enum14.CatDo
			});
		}

		// Token: 0x06002303 RID: 8963 RVA: 0x0001ACE0 File Offset: 0x00018EE0
		internal void method_87(Class159 class159_0)
		{
			if ((ulong)class159_0.Class432_0.UInt32_29 != (ulong)((long)Class365.Int32_3))
			{
				class159_0.method_271();
			}
		}

		// Token: 0x06002304 RID: 8964 RVA: 0x0001AC5F File Offset: 0x00018E5F
		internal void method_88(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.Boolean_65 = false;
		}

		// Token: 0x06002305 RID: 8965 RVA: 0x0001AA52 File Offset: 0x00018C52
		internal void method_89(Class159 class159_0)
		{
			class159_0.method_49(new Enum14[]
			{
				Enum14.TriLieu,
				Enum14.BanRac,
				Enum14.CatVang,
				Enum14.CatDo
			});
		}

		// Token: 0x06002306 RID: 8966 RVA: 0x0001ACFC File Offset: 0x00018EFC
		internal bool method_90(Class209 class209_0)
		{
			return class209_0.String_0 == "Tử Vi Huy Tinh";
		}

		// Token: 0x06002307 RID: 8967 RVA: 0x00011AF5 File Offset: 0x0000FCF5
		internal int method_91(Class209 class209_0)
		{
			return (int)class209_0.UInt32_5;
		}

		// Token: 0x06002308 RID: 8968 RVA: 0x0001AD0E File Offset: 0x00018F0E
		internal void method_92(Class159 class159_0)
		{
			class159_0.method_282("Player:ChangePVPMode(0);", false);
		}

		// Token: 0x06002309 RID: 8969 RVA: 0x0001AD1C File Offset: 0x00018F1C
		internal void method_93(Class159 class159_0)
		{
			class159_0.method_282("Player:ChangePVPMode(2);", false);
		}

		// Token: 0x0600230A RID: 8970 RVA: 0x0001AD2A File Offset: 0x00018F2A
		internal void method_94(Class159 class159_0)
		{
			class159_0.method_282("Player:ChangePVPMode(3);", false);
		}

		// Token: 0x0600230B RID: 8971 RVA: 0x0001AD38 File Offset: 0x00018F38
		internal void method_95(Class159 class159_0)
		{
			class159_0.method_282("Player:ChangePVPMode(4);", false);
		}

		// Token: 0x0600230C RID: 8972 RVA: 0x0001AD46 File Offset: 0x00018F46
		internal void method_96(Class159 class159_0)
		{
			class159_0.method_282("Player:ChangePVPMode(5);", false);
		}

		// Token: 0x0600230D RID: 8973 RVA: 0x0001AD54 File Offset: 0x00018F54
		internal void method_97(Class159 class159_0)
		{
			Task.Run(new Action(new Main.Class314
			{
				class159_0 = class159_0
			}.method_0));
		}

		// Token: 0x0600230E RID: 8974 RVA: 0x0001AD73 File Offset: 0x00018F73
		internal void method_98(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class316
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x0600230F RID: 8975 RVA: 0x0001AD96 File Offset: 0x00018F96
		internal void method_99(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class317
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002310 RID: 8976 RVA: 0x0001ADB9 File Offset: 0x00018FB9
		internal void method_100(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class318
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002311 RID: 8977 RVA: 0x0001ADDC File Offset: 0x00018FDC
		internal void method_101(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class319
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002312 RID: 8978 RVA: 0x0001ADFF File Offset: 0x00018FFF
		internal void method_102(Class159 class159_0)
		{
			class159_0.method_226();
		}

		// Token: 0x06002313 RID: 8979 RVA: 0x0001AE07 File Offset: 0x00019007
		internal void method_103(Class159 class159_0)
		{
			class159_0.method_49(new Enum14[]
			{
				Enum14.TuLuyenTheLuc,
				Enum14.TuLuyenNoiLuc,
				Enum14.TuLuyenThanPhap
			});
		}

		// Token: 0x06002314 RID: 8980 RVA: 0x0001AE20 File Offset: 0x00019020
		internal void method_104(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_105));
		}

		// Token: 0x06002315 RID: 8981 RVA: 0x0001AE55 File Offset: 0x00019055
		internal void method_105(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_12;
		}

		// Token: 0x06002316 RID: 8982 RVA: 0x0001AE62 File Offset: 0x00019062
		internal void method_106(Class159 class159_0)
		{
			class159_0.method_51(Enum14.DatDoiAcBa);
		}

		// Token: 0x06002317 RID: 8983 RVA: 0x0001AE6C File Offset: 0x0001906C
		internal void method_107(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_108));
		}

		// Token: 0x06002318 RID: 8984 RVA: 0x0001AEA1 File Offset: 0x000190A1
		internal void method_108(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_11;
		}

		// Token: 0x06002319 RID: 8985 RVA: 0x0001AEAE File Offset: 0x000190AE
		internal void method_109(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_110));
		}

		// Token: 0x0600231A RID: 8986 RVA: 0x0001AEE3 File Offset: 0x000190E3
		internal void method_110(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_10;
		}

		// Token: 0x0600231B RID: 8987 RVA: 0x0001AEF0 File Offset: 0x000190F0
		internal void method_111(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_112));
		}

		// Token: 0x0600231C RID: 8988 RVA: 0x0001AF25 File Offset: 0x00019125
		internal void method_112(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_9;
		}

		// Token: 0x0600231D RID: 8989 RVA: 0x0001AF32 File Offset: 0x00019132
		internal void method_113(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_114));
		}

		// Token: 0x0600231E RID: 8990 RVA: 0x0001AF67 File Offset: 0x00019167
		internal void method_114(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_5;
		}

		// Token: 0x0600231F RID: 8991 RVA: 0x0001AF74 File Offset: 0x00019174
		internal void method_115(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_116));
		}

		// Token: 0x06002320 RID: 8992 RVA: 0x0001AFA9 File Offset: 0x000191A9
		internal void method_116(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_8;
		}

		// Token: 0x06002321 RID: 8993 RVA: 0x0001AFB6 File Offset: 0x000191B6
		internal void method_117(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_118));
		}

		// Token: 0x06002322 RID: 8994 RVA: 0x0001AFEB File Offset: 0x000191EB
		internal void method_118(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_0;
		}

		// Token: 0x06002323 RID: 8995 RVA: 0x0001AFF8 File Offset: 0x000191F8
		internal void method_119(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_120));
		}

		// Token: 0x06002324 RID: 8996 RVA: 0x0001B02D File Offset: 0x0001922D
		internal void method_120(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_7;
		}

		// Token: 0x06002325 RID: 8997 RVA: 0x0001B03A File Offset: 0x0001923A
		internal void method_121(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_122));
		}

		// Token: 0x06002326 RID: 8998 RVA: 0x0001B06F File Offset: 0x0001926F
		internal void method_122(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_6;
		}

		// Token: 0x06002327 RID: 8999 RVA: 0x0001B07C File Offset: 0x0001927C
		internal void method_123(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_124));
		}

		// Token: 0x06002328 RID: 9000 RVA: 0x0001B0B1 File Offset: 0x000192B1
		internal void method_124(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_4;
		}

		// Token: 0x06002329 RID: 9001 RVA: 0x0001B0BE File Offset: 0x000192BE
		internal void method_125(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_126));
		}

		// Token: 0x0600232A RID: 9002 RVA: 0x0001B0F3 File Offset: 0x000192F3
		internal void method_126(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_3;
		}

		// Token: 0x0600232B RID: 9003 RVA: 0x0001B100 File Offset: 0x00019300
		internal void method_127(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_128));
		}

		// Token: 0x0600232C RID: 9004 RVA: 0x0001B135 File Offset: 0x00019335
		internal void method_128(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_1;
		}

		// Token: 0x0600232D RID: 9005 RVA: 0x0001B142 File Offset: 0x00019342
		internal void method_129(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiAcBa, true);
			class159_0.List_25.ForEach(new Action<Class159>(Main.Class270.<>9.method_130));
		}

		// Token: 0x0600232E RID: 9006 RVA: 0x0001B177 File Offset: 0x00019377
		internal void method_130(Class159 class159_0)
		{
			class159_0.Int32_40 = Class381.int_2;
		}

		// Token: 0x0600232F RID: 9007 RVA: 0x0001B184 File Offset: 0x00019384
		internal void method_131(Class159 class159_0)
		{
			class159_0.method_282("setmetatable(_G, {__index = ChatFrame_Env }); Chat_ChangeTabIndex(2); ", false);
		}

		// Token: 0x06002330 RID: 9008 RVA: 0x00103CE0 File Offset: 0x00101EE0
		internal void method_132(Class159 class159_0)
		{
			class159_0.method_282("Clear_XSCRIPT( )\r\n\t\tSet_XSCRIPT_Function_Name( 'DoMoneyToJiaozi' )\r\n\r\n        Set_XSCRIPT_ScriptID(800119)\r\n\r\n        Set_XSCRIPT_Parameter(0, " + class159_0.Class432_0.UInt32_16.ToString() + ")\r\n\r\n        Set_XSCRIPT_ParamCount(1)\r\n\r\n    Send_XSCRIPT()", false);
		}

		// Token: 0x06002331 RID: 9009 RVA: 0x0001B192 File Offset: 0x00019392
		internal void method_133(Class159 class159_0)
		{
			if (class159_0.int_49 > 0)
			{
				class159_0.method_282("PushEvent('TOGLE_BIGBANK'); PushEvent('UPDATE_BANK')", false);
			}
		}

		// Token: 0x06002332 RID: 9010 RVA: 0x00103D18 File Offset: 0x00101F18
		internal void method_134(Class159 class159_0)
		{
			class159_0.method_282("Clear_XSCRIPT()\r\n\t\t\t                Set_XSCRIPT_Function_Name( 'MartialLastDayMonsterReward' )\r\n                            Set_XSCRIPT_ScriptID(507010)\r\n                            Set_XSCRIPT_Parameter(0, 1)\r\n                            Set_XSCRIPT_ParamCount(1)\r\n                            Send_XSCRIPT()", false);
			for (int i = 0; i < 10; i++)
			{
				class159_0.method_282("Clear_XSCRIPT()\r\n                                Set_XSCRIPT_Function_Name('AddAttr')\r\n                                Set_XSCRIPT_ScriptID(507010)\r\n                                Send_XSCRIPT()", false);
			}
		}

		// Token: 0x06002333 RID: 9011 RVA: 0x000111BA File Offset: 0x0000F3BA
		internal bool method_135(Class209 class209_0)
		{
			return class209_0.String_1 == "Long Văn";
		}

		// Token: 0x06002334 RID: 9012 RVA: 0x0001B1A9 File Offset: 0x000193A9
		internal bool method_136(Class209 class209_0)
		{
			return class209_0.String_0 == "Long Văn" && class209_0.Int32_0 >= 100;
		}

		// Token: 0x06002335 RID: 9013 RVA: 0x0001B1CC File Offset: 0x000193CC
		internal void method_137(Class159 class159_0)
		{
			class159_0.method_51(Enum14.GomKNB);
			class159_0.method_51(Enum14.GomVang);
			class159_0.method_48(Enum14.GomDo, true);
			class159_0.method_51(Enum14.DuaBaoDoHiem);
			class159_0.method_51(Enum14.DuaTangBaoDo);
		}

		// Token: 0x06002336 RID: 9014 RVA: 0x0001B1FD File Offset: 0x000193FD
		internal void method_138(Class159 class159_0)
		{
			class159_0.method_51(Enum14.GomKNB);
			class159_0.method_48(Enum14.GomVang, true);
			class159_0.method_48(Enum14.GomDo, true);
			class159_0.method_51(Enum14.DuaBaoDoHiem);
			class159_0.method_51(Enum14.DuaTangBaoDo);
		}

		// Token: 0x06002337 RID: 9015 RVA: 0x0001B22F File Offset: 0x0001942F
		internal void method_139(Class159 class159_0)
		{
			class159_0.method_48(Enum14.GomDoKNB, true);
		}

		// Token: 0x06002338 RID: 9016 RVA: 0x0001118C File Offset: 0x0000F38C
		internal bool method_140(Class209 class209_0)
		{
			return class209_0.Boolean_0;
		}

		// Token: 0x06002339 RID: 9017 RVA: 0x0001B23A File Offset: 0x0001943A
		internal void method_141(Class159 class159_0)
		{
			class159_0.method_48(Enum14.HopDienTich, true);
			class159_0.Int32_50 = 1;
		}

		// Token: 0x0600233A RID: 9018 RVA: 0x0001B24C File Offset: 0x0001944C
		internal void method_142(Class159 class159_0)
		{
			class159_0.method_48(Enum14.HopDienTich, true);
			class159_0.Int32_50 = 2;
		}

		// Token: 0x0600233B RID: 9019 RVA: 0x0001B25E File Offset: 0x0001945E
		internal void method_143(Class159 class159_0)
		{
			class159_0.method_48(Enum14.HopDienTich, true);
			class159_0.Int32_50 = 3;
		}

		// Token: 0x0600233C RID: 9020 RVA: 0x0001B270 File Offset: 0x00019470
		internal void method_144(Class159 class159_0)
		{
			class159_0.method_51(Enum14.GomKNB);
			class159_0.method_51(Enum14.GomVang);
			class159_0.method_48(Enum14.GomDo, true);
			class159_0.method_48(Enum14.DuaBaoDoHiem, true);
			class159_0.method_51(Enum14.DuaTangBaoDo);
		}

		// Token: 0x0600233D RID: 9021 RVA: 0x00103D18 File Offset: 0x00101F18
		internal void method_145(Class159 class159_0)
		{
			class159_0.method_282("Clear_XSCRIPT()\r\n\t\t\t                Set_XSCRIPT_Function_Name( 'MartialLastDayMonsterReward' )\r\n                            Set_XSCRIPT_ScriptID(507010)\r\n                            Set_XSCRIPT_Parameter(0, 1)\r\n                            Set_XSCRIPT_ParamCount(1)\r\n                            Send_XSCRIPT()", false);
			for (int i = 0; i < 10; i++)
			{
				class159_0.method_282("Clear_XSCRIPT()\r\n                                Set_XSCRIPT_Function_Name('AddAttr')\r\n                                Set_XSCRIPT_ScriptID(507010)\r\n                                Send_XSCRIPT()", false);
			}
		}

		// Token: 0x0600233E RID: 9022 RVA: 0x00103CE0 File Offset: 0x00101EE0
		internal void method_146(Class159 class159_0)
		{
			class159_0.method_282("Clear_XSCRIPT( )\r\n\t\tSet_XSCRIPT_Function_Name( 'DoMoneyToJiaozi' )\r\n\r\n        Set_XSCRIPT_ScriptID(800119)\r\n\r\n        Set_XSCRIPT_Parameter(0, " + class159_0.Class432_0.UInt32_16.ToString() + ")\r\n\r\n        Set_XSCRIPT_ParamCount(1)\r\n\r\n    Send_XSCRIPT()", false);
		}

		// Token: 0x0600233F RID: 9023 RVA: 0x0001B2A2 File Offset: 0x000194A2
		internal void method_147(Class159 class159_0)
		{
			Task.Run(new Action(new Main.Class324
			{
				class159_0 = class159_0
			}.method_0));
		}

		// Token: 0x06002340 RID: 9024 RVA: 0x0001B2C1 File Offset: 0x000194C1
		internal void method_148(Class159 class159_0)
		{
			class159_0.method_364();
		}

		// Token: 0x06002341 RID: 9025 RVA: 0x0001B2C9 File Offset: 0x000194C9
		internal void method_149(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class325
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002342 RID: 9026 RVA: 0x0001B2EC File Offset: 0x000194EC
		internal void method_150(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class326
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002343 RID: 9027 RVA: 0x0001B30F File Offset: 0x0001950F
		internal void method_151(Class159 class159_0)
		{
			new Thread(new ThreadStart(new Main.Class327
			{
				class159_0 = class159_0
			}.method_0)).Start();
		}

		// Token: 0x06002344 RID: 9028 RVA: 0x0001AC18 File Offset: 0x00018E18
		internal void method_152(Class159 class159_0)
		{
			class159_0.method_46();
		}

		// Token: 0x06002345 RID: 9029 RVA: 0x0001AC08 File Offset: 0x00018E08
		internal void method_153(Class159 class159_0)
		{
			class159_0.method_60();
		}

		// Token: 0x06002346 RID: 9030 RVA: 0x0001B332 File Offset: 0x00019532
		internal void method_154(Class159 class159_0)
		{
			class159_0.Boolean_44 = true;
			class159_0.Boolean_45 = true;
		}

		// Token: 0x06002347 RID: 9031 RVA: 0x0001B342 File Offset: 0x00019542
		internal void method_155(Class159 class159_0)
		{
			class159_0.Boolean_44 = true;
			class159_0.Boolean_45 = false;
		}

		// Token: 0x06002348 RID: 9032 RVA: 0x0001B352 File Offset: 0x00019552
		internal void method_156(Class159 class159_0)
		{
			class159_0.method_314();
		}

		// Token: 0x06002349 RID: 9033 RVA: 0x0001AB94 File Offset: 0x00018D94
		internal void method_157(Class159 class159_0)
		{
			class159_0.method_270();
		}

		// Token: 0x0600234A RID: 9034 RVA: 0x0001AB9C File Offset: 0x00018D9C
		internal void method_158(Class159 class159_0)
		{
			class159_0.method_272();
		}

		// Token: 0x0600234B RID: 9035 RVA: 0x0001A995 File Offset: 0x00018B95
		internal void method_159(Class159 class159_0)
		{
			class159_0.Class368_0.method_38();
		}

		// Token: 0x0600234C RID: 9036 RVA: 0x0001B35A File Offset: 0x0001955A
		internal void method_160(Class159 class159_0)
		{
			class159_0.method_220();
		}

		// Token: 0x0600234D RID: 9037 RVA: 0x0001AB76 File Offset: 0x00018D76
		internal void method_161(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_1", uint.MaxValue);
		}

		// Token: 0x0600234E RID: 9038 RVA: 0x0001B362 File Offset: 0x00019562
		internal void method_162(Class159 class159_0)
		{
			class159_0.method_282("maxNum = GuiShiUI:LuaFnGetClueCount()\r\n                                                        for index = 1, maxNum do\r\n                                                            clueID = GuiShiUI:LuaFnGetClueID(index - 1)\r\n                                                            if nil ~= clueID and clueID > 0 then\r\n                                                                clueID, clueName, clueDesc, clueQual, clueFunc, vilaidType, viladTime = GuiShiUI:LuaFnGetXianSuoDataFromTable(clueID)\r\n                                                                if clueName ~= 'Tầm Kỳ' then\r\n                                                                    Clear_XSCRIPT()\r\n                                                                    Set_XSCRIPT_Function_Name( 'SaleXiansuo')\r\n                                                                    Set_XSCRIPT_ScriptID( 893197 )\r\n                                                                    Set_XSCRIPT_Parameter( 0, index - 1 )\r\n                                                                    Set_XSCRIPT_Parameter( 1,0 )\r\n                                                                    Set_XSCRIPT_ParamCount( 2 )\r\n                                                                    Send_XSCRIPT()\r\n                                                                end\r\n                                                            end\r\n                                                        end\r\n                                                        ", false);
		}

		// Token: 0x0600234F RID: 9039 RVA: 0x0001B370 File Offset: 0x00019570
		internal void method_163(Class159 class159_0)
		{
			class159_0.method_51(Enum14.GomVang);
			class159_0.method_51(Enum14.GomKNB);
			class159_0.method_48(Enum14.GomDo, true);
			class159_0.method_51(Enum14.DuaBaoDoHiem);
			class159_0.method_48(Enum14.DuaTangBaoDo, true);
		}

		// Token: 0x06002350 RID: 9040 RVA: 0x0001AB94 File Offset: 0x00018D94
		internal void method_164(Class159 class159_0)
		{
			class159_0.method_270();
		}

		// Token: 0x06002351 RID: 9041 RVA: 0x0001AB9C File Offset: 0x00018D9C
		internal void method_165(Class159 class159_0)
		{
			class159_0.method_272();
		}

		// Token: 0x06002352 RID: 9042 RVA: 0x0001AB76 File Offset: 0x00018D76
		internal void method_166(Class159 class159_0)
		{
			class159_0.method_313("PetSkill2_1", uint.MaxValue);
		}

		// Token: 0x06002353 RID: 9043 RVA: 0x0001B352 File Offset: 0x00019552
		internal void method_167(Class159 class159_0)
		{
			class159_0.method_314();
		}

		// Token: 0x06002354 RID: 9044 RVA: 0x0001B3A2 File Offset: 0x000195A2
		internal void method_168(Class159 class159_0)
		{
			class159_0.method_48(Enum14.NangTamPhap, true);
			class159_0.method_48(Enum14.Quyen3Len30, true);
		}

		// Token: 0x06002355 RID: 9045 RVA: 0x0001B3B6 File Offset: 0x000195B6
		internal void method_169(Class159 class159_0)
		{
			class159_0.Boolean_43 = true;
		}

		// Token: 0x06002356 RID: 9046 RVA: 0x0001B3BF File Offset: 0x000195BF
		internal void method_170(Class159 class159_0)
		{
			class159_0.Int32_36 = 1;
		}

		// Token: 0x06002357 RID: 9047 RVA: 0x0001B3C8 File Offset: 0x000195C8
		internal void method_171(Class159 class159_0)
		{
			class159_0.Int32_36 = 4;
		}

		// Token: 0x06002358 RID: 9048 RVA: 0x0001B3D1 File Offset: 0x000195D1
		internal void method_172(Class159 class159_0)
		{
			class159_0.Int32_36 = 10;
		}

		// Token: 0x06002359 RID: 9049 RVA: 0x0001B3DB File Offset: 0x000195DB
		internal void method_173(Class159 class159_0)
		{
			class159_0.Int32_36 = 2;
		}

		// Token: 0x0600235A RID: 9050 RVA: 0x0001B3E4 File Offset: 0x000195E4
		internal void method_174(Class159 class159_0)
		{
			class159_0.method_48(Enum14.GomKNB, true);
			class159_0.method_48(Enum14.GomDo, true);
			class159_0.method_51(Enum14.DuaBaoDoHiem);
			class159_0.method_51(Enum14.DuaTangBaoDo);
			class159_0.method_51(Enum14.GomVang);
		}

		// Token: 0x0600235B RID: 9051 RVA: 0x0001AA45 File Offset: 0x00018C45
		internal bool method_175(Class159 class159_0)
		{
			return class159_0.Class432_0.Boolean_32;
		}

		// Token: 0x0600235C RID: 9052 RVA: 0x00012BF8 File Offset: 0x00010DF8
		internal void method_176(Class159 class159_0)
		{
			class159_0.method_223();
		}

		// Token: 0x0600235D RID: 9053 RVA: 0x0001A98D File Offset: 0x00018B8D
		internal void method_177(Class159 class159_0)
		{
			class159_0.method_222();
		}

		// Token: 0x0600235E RID: 9054 RVA: 0x0001B362 File Offset: 0x00019562
		internal void method_178(Class159 class159_0)
		{
			class159_0.method_282("maxNum = GuiShiUI:LuaFnGetClueCount()\r\n                                                        for index = 1, maxNum do\r\n                                                            clueID = GuiShiUI:LuaFnGetClueID(index - 1)\r\n                                                            if nil ~= clueID and clueID > 0 then\r\n                                                                clueID, clueName, clueDesc, clueQual, clueFunc, vilaidType, viladTime = GuiShiUI:LuaFnGetXianSuoDataFromTable(clueID)\r\n                                                                if clueName ~= 'Tầm Kỳ' then\r\n                                                                    Clear_XSCRIPT()\r\n                                                                    Set_XSCRIPT_Function_Name( 'SaleXiansuo')\r\n                                                                    Set_XSCRIPT_ScriptID( 893197 )\r\n                                                                    Set_XSCRIPT_Parameter( 0, index - 1 )\r\n                                                                    Set_XSCRIPT_Parameter( 1,0 )\r\n                                                                    Set_XSCRIPT_ParamCount( 2 )\r\n                                                                    Send_XSCRIPT()\r\n                                                                end\r\n                                                            end\r\n                                                        end\r\n                                                        ", false);
		}

		// Token: 0x0600235F RID: 9055 RVA: 0x0001A9F4 File Offset: 0x00018BF4
		internal void method_179(Class159 class159_0)
		{
			class159_0.method_83();
		}

		// Token: 0x04001692 RID: 5778
		public static readonly Main.Class270 <>9 = new Main.Class270();

		// Token: 0x04001693 RID: 5779
		public static Action<Class159> <>9__1_0;

		// Token: 0x04001694 RID: 5780
		public static Action<Class159> <>9__1_1;

		// Token: 0x04001695 RID: 5781
		public static Action<Class159> <>9__1_2;

		// Token: 0x04001696 RID: 5782
		public static Action<Class159> <>9__1_3;

		// Token: 0x04001697 RID: 5783
		public static DrawListViewItemEventHandler <>9__31_1;

		// Token: 0x04001698 RID: 5784
		public static DrawListViewSubItemEventHandler <>9__31_2;

		// Token: 0x04001699 RID: 5785
		public static Func<Class159, double> <>9__71_0;

		// Token: 0x0400169A RID: 5786
		public static Func<KeyValuePair<int, Class159>, bool> <>9__71_1;

		// Token: 0x0400169B RID: 5787
		public static Action <>9__77_0;

		// Token: 0x0400169C RID: 5788
		public static Func<KeyValuePair<int, Class159>, bool> <>9__89_0;

		// Token: 0x0400169D RID: 5789
		public static Func<KeyValuePair<int, Class159>, Class159> <>9__123_0;

		// Token: 0x0400169E RID: 5790
		public static Func<Class159, bool> <>9__123_1;

		// Token: 0x0400169F RID: 5791
		public static Func<Class159, string> <>9__123_2;

		// Token: 0x040016A0 RID: 5792
		public static Func<int, string> <>9__124_1;

		// Token: 0x040016A1 RID: 5793
		public static Func<ColumnHeader, int> <>9__149_2;

		// Token: 0x040016A2 RID: 5794
		public static Func<ColumnHeader, int> <>9__149_0;

		// Token: 0x040016A3 RID: 5795
		public static Func<ColumnHeader, int> <>9__149_3;

		// Token: 0x040016A4 RID: 5796
		public static Func<ColumnHeader, int> <>9__149_4;

		// Token: 0x040016A5 RID: 5797
		public static Func<ColumnHeader, int> <>9__149_5;

		// Token: 0x040016A6 RID: 5798
		public static Func<ColumnHeader, int> <>9__149_1;

		// Token: 0x040016A7 RID: 5799
		public static Action<Class159> <>9__158_0;

		// Token: 0x040016A8 RID: 5800
		public static Action <>9__163_0;

		// Token: 0x040016A9 RID: 5801
		public static Action<Class159> <>9__163_2;

		// Token: 0x040016AA RID: 5802
		public static Func<KeyValuePair<string, FastTask>, bool> <>9__191_0;

		// Token: 0x040016AB RID: 5803
		public static Func<KeyValuePair<string, FastTask>, string> <>9__191_1;

		// Token: 0x040016AC RID: 5804
		public static Func<KeyValuePair<string, FastTask>, FastTask> <>9__191_2;

		// Token: 0x040016AD RID: 5805
		public static Func<ListViewItem, Class159> <>9__225_0;

		// Token: 0x040016AE RID: 5806
		public static Func<Class159, bool> <>9__227_0;

		// Token: 0x040016AF RID: 5807
		public static Func<Class159, bool> <>9__229_0;

		// Token: 0x040016B0 RID: 5808
		public static Func<KeyValuePair<int, Class159>, Class159> <>9__231_0;

		// Token: 0x040016B1 RID: 5809
		public static Func<Class159, bool> <>9__233_0;

		// Token: 0x040016B2 RID: 5810
		public static Action<Class159> <>9__296_1;

		// Token: 0x040016B3 RID: 5811
		public static RemoteCertificateValidationCallback <>9__356_1;

		// Token: 0x040016B4 RID: 5812
		public static ThreadStart <>9__356_0;

		// Token: 0x040016B5 RID: 5813
		public static Func<Class159, string> <>9__383_0;

		// Token: 0x040016B6 RID: 5814
		public static Action<Class159> <>9__452_0;

		// Token: 0x040016B7 RID: 5815
		public static Func<Class159, bool> <>9__454_0;

		// Token: 0x040016B8 RID: 5816
		public static Func<Class159, bool> <>9__454_1;

		// Token: 0x040016B9 RID: 5817
		public static Func<Class159, bool> <>9__454_2;

		// Token: 0x040016BA RID: 5818
		public static Func<Class159, bool> <>9__454_3;

		// Token: 0x040016BB RID: 5819
		public static Func<Class159, bool> <>9__454_4;

		// Token: 0x040016BC RID: 5820
		public static Func<Class159, bool> <>9__454_5;

		// Token: 0x040016BD RID: 5821
		public static Func<Class159, bool> <>9__454_6;

		// Token: 0x040016BE RID: 5822
		public static Func<Class159, bool> <>9__454_7;

		// Token: 0x040016BF RID: 5823
		public static Func<Class159, bool> <>9__454_8;

		// Token: 0x040016C0 RID: 5824
		public static Func<Class159, bool> <>9__454_9;

		// Token: 0x040016C1 RID: 5825
		public static Func<Class159, bool> <>9__454_10;

		// Token: 0x040016C2 RID: 5826
		public static Func<Class159, bool> <>9__454_11;

		// Token: 0x040016C3 RID: 5827
		public static Action<Class159> <>9__480_0;

		// Token: 0x040016C4 RID: 5828
		public static Action<Class159> <>9__481_0;

		// Token: 0x040016C5 RID: 5829
		public static Action<Class159> <>9__482_0;

		// Token: 0x040016C6 RID: 5830
		public static Action<Class159> <>9__483_0;

		// Token: 0x040016C7 RID: 5831
		public static Action<Class159> <>9__484_0;

		// Token: 0x040016C8 RID: 5832
		public static Action<Class159> <>9__485_0;

		// Token: 0x040016C9 RID: 5833
		public static Action<Class159> <>9__486_0;

		// Token: 0x040016CA RID: 5834
		public static Action<Class159> <>9__487_0;

		// Token: 0x040016CB RID: 5835
		public static Action<Class159> <>9__488_0;

		// Token: 0x040016CC RID: 5836
		public static Action<Class159> <>9__489_0;

		// Token: 0x040016CD RID: 5837
		public static Action<Class159> <>9__490_0;

		// Token: 0x040016CE RID: 5838
		public static Action<Class159> <>9__491_0;

		// Token: 0x040016CF RID: 5839
		public static Action<Class159> <>9__492_0;

		// Token: 0x040016D0 RID: 5840
		public static Action<Class159> <>9__493_0;

		// Token: 0x040016D1 RID: 5841
		public static Action<Class159> <>9__497_0;

		// Token: 0x040016D2 RID: 5842
		public static Action<Class159> <>9__505_0;

		// Token: 0x040016D3 RID: 5843
		public static Action<Class159> <>9__508_0;

		// Token: 0x040016D4 RID: 5844
		public static Action<Class159> <>9__510_0;

		// Token: 0x040016D5 RID: 5845
		public static Action<Class159> <>9__522_0;

		// Token: 0x040016D6 RID: 5846
		public static Action<Class159> <>9__525_0;

		// Token: 0x040016D7 RID: 5847
		public static Action<Class159> <>9__526_0;

		// Token: 0x040016D8 RID: 5848
		public static Action<Class159> <>9__527_0;

		// Token: 0x040016D9 RID: 5849
		public static Action<Class159> <>9__528_0;

		// Token: 0x040016DA RID: 5850
		public static Action<Class159> <>9__529_0;

		// Token: 0x040016DB RID: 5851
		public static Action<Class159> <>9__550_0;

		// Token: 0x040016DC RID: 5852
		public static Action<Class159> <>9__554_0;

		// Token: 0x040016DD RID: 5853
		public static Action<Class159> <>9__567_0;

		// Token: 0x040016DE RID: 5854
		public static Func<Class209, bool> <>9__576_1;

		// Token: 0x040016DF RID: 5855
		public static Action<Class159> <>9__592_0;

		// Token: 0x040016E0 RID: 5856
		public static Action<KeyValuePair<int, Class159>> <>9__596_1;

		// Token: 0x040016E1 RID: 5857
		public static Action<KeyValuePair<int, Class159>> <>9__601_1;

		// Token: 0x040016E2 RID: 5858
		public static Func<TabLogin, bool> <>9__601_2;

		// Token: 0x040016E3 RID: 5859
		public static Action<TabLogin> <>9__601_3;

		// Token: 0x040016E4 RID: 5860
		public static Func<TabLogin, bool> <>9__601_4;

		// Token: 0x040016E5 RID: 5861
		public static Action<KeyValuePair<int, Class159>> <>9__601_5;

		// Token: 0x040016E6 RID: 5862
		public static Action<Class159> <>9__622_0;

		// Token: 0x040016E7 RID: 5863
		public static Action<Class159> <>9__623_0;

		// Token: 0x040016E8 RID: 5864
		public static Action<Class159> <>9__626_0;

		// Token: 0x040016E9 RID: 5865
		public static Action<Class159> <>9__628_0;

		// Token: 0x040016EA RID: 5866
		public static Action<Class159> <>9__636_0;

		// Token: 0x040016EB RID: 5867
		public static Action<KeyValuePair<int, Class159>> <>9__641_1;

		// Token: 0x040016EC RID: 5868
		public static Action<Class159> <>9__643_0;

		// Token: 0x040016ED RID: 5869
		public static Func<Class209, bool> <>9__648_1;

		// Token: 0x040016EE RID: 5870
		public static Func<Class209, int> <>9__648_2;

		// Token: 0x040016EF RID: 5871
		public static Action<Class159> <>9__652_0;

		// Token: 0x040016F0 RID: 5872
		public static Action<Class159> <>9__653_0;

		// Token: 0x040016F1 RID: 5873
		public static Action<Class159> <>9__654_0;

		// Token: 0x040016F2 RID: 5874
		public static Action<Class159> <>9__655_0;

		// Token: 0x040016F3 RID: 5875
		public static Action<Class159> <>9__656_0;

		// Token: 0x040016F4 RID: 5876
		public static Action<Class159> <>9__660_0;

		// Token: 0x040016F5 RID: 5877
		public static Action<Class159> <>9__672_0;

		// Token: 0x040016F6 RID: 5878
		public static Action<Class159> <>9__673_0;

		// Token: 0x040016F7 RID: 5879
		public static Action<Class159> <>9__674_0;

		// Token: 0x040016F8 RID: 5880
		public static Action<Class159> <>9__682_0;

		// Token: 0x040016F9 RID: 5881
		public static Action<Class159> <>9__694_0;

		// Token: 0x040016FA RID: 5882
		public static Action<Class159> <>9__698_0;

		// Token: 0x040016FB RID: 5883
		public static Action<Class159> <>9__710_1;

		// Token: 0x040016FC RID: 5884
		public static Action<Class159> <>9__710_0;

		// Token: 0x040016FD RID: 5885
		public static Action<Class159> <>9__711_1;

		// Token: 0x040016FE RID: 5886
		public static Action<Class159> <>9__712_1;

		// Token: 0x040016FF RID: 5887
		public static Action<Class159> <>9__712_0;

		// Token: 0x04001700 RID: 5888
		public static Action<Class159> <>9__713_1;

		// Token: 0x04001701 RID: 5889
		public static Action<Class159> <>9__713_0;

		// Token: 0x04001702 RID: 5890
		public static Action<Class159> <>9__714_1;

		// Token: 0x04001703 RID: 5891
		public static Action<Class159> <>9__714_0;

		// Token: 0x04001704 RID: 5892
		public static Action<Class159> <>9__715_1;

		// Token: 0x04001705 RID: 5893
		public static Action<Class159> <>9__715_0;

		// Token: 0x04001706 RID: 5894
		public static Action<Class159> <>9__716_1;

		// Token: 0x04001707 RID: 5895
		public static Action<Class159> <>9__716_0;

		// Token: 0x04001708 RID: 5896
		public static Action<Class159> <>9__717_1;

		// Token: 0x04001709 RID: 5897
		public static Action<Class159> <>9__717_0;

		// Token: 0x0400170A RID: 5898
		public static Action<Class159> <>9__718_1;

		// Token: 0x0400170B RID: 5899
		public static Action<Class159> <>9__718_0;

		// Token: 0x0400170C RID: 5900
		public static Action<Class159> <>9__719_1;

		// Token: 0x0400170D RID: 5901
		public static Action<Class159> <>9__719_0;

		// Token: 0x0400170E RID: 5902
		public static Action<Class159> <>9__720_1;

		// Token: 0x0400170F RID: 5903
		public static Action<Class159> <>9__720_0;

		// Token: 0x04001710 RID: 5904
		public static Action<Class159> <>9__721_1;

		// Token: 0x04001711 RID: 5905
		public static Action<Class159> <>9__721_0;

		// Token: 0x04001712 RID: 5906
		public static Action<Class159> <>9__722_1;

		// Token: 0x04001713 RID: 5907
		public static Action<Class159> <>9__722_0;

		// Token: 0x04001714 RID: 5908
		public static Action<Class159> <>9__723_1;

		// Token: 0x04001715 RID: 5909
		public static Action<Class159> <>9__723_0;

		// Token: 0x04001716 RID: 5910
		public static Action<Class159> <>9__725_0;

		// Token: 0x04001717 RID: 5911
		public static Action<Class159> <>9__726_0;

		// Token: 0x04001718 RID: 5912
		public static Action<Class159> <>9__728_0;

		// Token: 0x04001719 RID: 5913
		public static Action<Class159> <>9__730_0;

		// Token: 0x0400171A RID: 5914
		public static Func<Class209, bool> <>9__731_1;

		// Token: 0x0400171B RID: 5915
		public static Func<Class209, bool> <>9__731_2;

		// Token: 0x0400171C RID: 5916
		public static Action<Class159> <>9__737_0;

		// Token: 0x0400171D RID: 5917
		public static Action<Class159> <>9__738_0;

		// Token: 0x0400171E RID: 5918
		public static Action<Class159> <>9__739_0;

		// Token: 0x0400171F RID: 5919
		public static Func<Class209, bool> <>9__743_0;

		// Token: 0x04001720 RID: 5920
		public static Action<Class159> <>9__745_0;

		// Token: 0x04001721 RID: 5921
		public static Action<Class159> <>9__746_0;

		// Token: 0x04001722 RID: 5922
		public static Action<Class159> <>9__747_0;

		// Token: 0x04001723 RID: 5923
		public static Action<Class159> <>9__748_0;

		// Token: 0x04001724 RID: 5924
		public static Action<Class159> <>9__754_0;

		// Token: 0x04001725 RID: 5925
		public static Action<Class159> <>9__755_0;

		// Token: 0x04001726 RID: 5926
		public static Action<Class159> <>9__756_0;

		// Token: 0x04001727 RID: 5927
		public static Action<Class159> <>9__757_0;

		// Token: 0x04001728 RID: 5928
		public static Action<Class159> <>9__758_0;

		// Token: 0x04001729 RID: 5929
		public static Action<Class159> <>9__759_0;

		// Token: 0x0400172A RID: 5930
		public static Action<Class159> <>9__760_0;

		// Token: 0x0400172B RID: 5931
		public static Action<Class159> <>9__761_0;

		// Token: 0x0400172C RID: 5932
		public static Action<Class159> <>9__762_0;

		// Token: 0x0400172D RID: 5933
		public static Action<Class159> <>9__764_0;

		// Token: 0x0400172E RID: 5934
		public static Action<Class159> <>9__765_0;

		// Token: 0x0400172F RID: 5935
		public static Action<Class159> <>9__767_0;

		// Token: 0x04001730 RID: 5936
		public static Action<Class159> <>9__768_0;

		// Token: 0x04001731 RID: 5937
		public static Action<Class159> <>9__769_0;

		// Token: 0x04001732 RID: 5938
		public static Action<Class159> <>9__770_0;

		// Token: 0x04001733 RID: 5939
		public static Action<Class159> <>9__772_0;

		// Token: 0x04001734 RID: 5940
		public static Action<Class159> <>9__774_0;

		// Token: 0x04001735 RID: 5941
		public static Action<Class159> <>9__786_0;

		// Token: 0x04001736 RID: 5942
		public static Action<Class159> <>9__787_0;

		// Token: 0x04001737 RID: 5943
		public static Action<Class159> <>9__789_0;

		// Token: 0x04001738 RID: 5944
		public static Action<Class159> <>9__790_0;

		// Token: 0x04001739 RID: 5945
		public static Action<Class159> <>9__791_0;

		// Token: 0x0400173A RID: 5946
		public static Action<Class159> <>9__792_0;

		// Token: 0x0400173B RID: 5947
		public static Action<Class159> <>9__793_0;

		// Token: 0x0400173C RID: 5948
		public static Action<Class159> <>9__794_0;

		// Token: 0x0400173D RID: 5949
		public static Action<Class159> <>9__795_0;

		// Token: 0x0400173E RID: 5950
		public static Action<Class159> <>9__796_0;

		// Token: 0x0400173F RID: 5951
		public static Action<Class159> <>9__797_0;

		// Token: 0x04001740 RID: 5952
		public static Action<Class159> <>9__798_0;

		// Token: 0x04001741 RID: 5953
		public static Action<Class159> <>9__799_0;

		// Token: 0x04001742 RID: 5954
		public static Func<Class159, bool> <>9__806_0;

		// Token: 0x04001743 RID: 5955
		public static Action<Class159> <>9__806_1;

		// Token: 0x04001744 RID: 5956
		public static Action<Class159> <>9__807_0;

		// Token: 0x04001745 RID: 5957
		public static Action<Class159> <>9__810_0;

		// Token: 0x04001746 RID: 5958
		public static Action<Class159> <>9__811_0;
	}

	// Token: 0x02000241 RID: 577
	[CompilerGenerated]
	private sealed class Class271
	{
		// Token: 0x06002361 RID: 9057 RVA: 0x0001B416 File Offset: 0x00019616
		internal void method_0(Class159 class159_1)
		{
			if (class159_1.Class432_0.Boolean_34)
			{
				class159_1.method_238((float)((int)this.class159_0.Single_3), (float)((int)this.class159_0.Single_4), (int)this.class159_0.Class432_0.UInt32_29);
			}
		}

		// Token: 0x04001747 RID: 5959
		public Class159 class159_0;
	}

	// Token: 0x02000242 RID: 578
	[CompilerGenerated]
	private sealed class Class272
	{
		// Token: 0x06002363 RID: 9059 RVA: 0x0001B455 File Offset: 0x00019655
		internal bool method_0(Process process_0)
		{
			return process_0.SessionId == this.int_0 && !process_0.HasExited && process_0.HandleCount > 0 && !Main.dictionary_3.ContainsKey(process_0.Id);
		}

		// Token: 0x04001748 RID: 5960
		public int int_0;

		// Token: 0x04001749 RID: 5961
		public Main main_0;

		// Token: 0x0400174A RID: 5962
		public Func<Process, bool> func_0;
	}

	// Token: 0x02000243 RID: 579
	[CompilerGenerated]
	private sealed class Class273
	{
		// Token: 0x06002365 RID: 9061 RVA: 0x00103D4C File Offset: 0x00101F4C
		internal void method_0()
		{
			try
			{
				this.class272_0.main_0.Lv.dicHides.Remove(this.keyValuePair_0.Value.ListViewItem_0);
				this.class272_0.main_0.Lv.hideItems.Remove(this.keyValuePair_0.Value.ListViewItem_0);
			}
			catch
			{
			}
			try
			{
				this.keyValuePair_0.Value.ListViewItem_0.Remove();
			}
			catch
			{
			}
			if (Class268.bool_84 && this.class272_0.main_0.Lv.Items.Count == 0)
			{
				new ShutDown();
			}
		}

		// Token: 0x0400174B RID: 5963
		public KeyValuePair<int, Class159> keyValuePair_0;

		// Token: 0x0400174C RID: 5964
		public Main.Class272 class272_0;
	}

	// Token: 0x02000244 RID: 580
	[CompilerGenerated]
	private sealed class Class274
	{
		// Token: 0x06002367 RID: 9063 RVA: 0x00103E14 File Offset: 0x00102014
		internal void method_0()
		{
			ListViewItem listViewItem = new ListViewItem(new string[]
			{
				"ĐăngNhập",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				" ",
				"",
				"",
				"",
				"",
				""
			})
			{
				UseItemStyleForSubItems = false
			};
			listViewItem.Tag = this.class159_0;
			this.class159_0.ListViewItem_0 = listViewItem;
			listViewItem.Checked = true;
			this.class272_0.main_0.Lv.Items.Add(listViewItem);
		}

		// Token: 0x0400174D RID: 5965
		public Class159 class159_0;

		// Token: 0x0400174E RID: 5966
		public Main.Class272 class272_0;
	}

	// Token: 0x02000245 RID: 581
	[CompilerGenerated]
	private sealed class Class275
	{
		// Token: 0x06002369 RID: 9065 RVA: 0x0001B48B File Offset: 0x0001968B
		internal void method_0()
		{
			this.class159_0.ListViewItem_0.Checked = this.class159_0.Boolean_3;
		}

		// Token: 0x0400174F RID: 5967
		public Class159 class159_0;
	}

	// Token: 0x02000246 RID: 582
	[CompilerGenerated]
	private sealed class Class276
	{
		// Token: 0x0600236B RID: 9067 RVA: 0x00103F90 File Offset: 0x00102190
		internal void method_0(object sender, EventArgs e)
		{
			this.toolStripMenuItem_0.Checked = !this.toolStripMenuItem_0.Checked;
			if (!this.toolStripMenuItem_0.Checked)
			{
				this.columnHeader_0.Tag = this.columnHeader_0.Width;
				this.columnHeader_0.Width = 0;
				this.main_0.list_6.Add(this.columnHeader_0.Index);
				return;
			}
			this.main_0.list_1.Remove(this.columnHeader_0.Index);
			this.main_0.list_6.Remove(this.columnHeader_0.Index);
			this.columnHeader_0.Width = this.columnHeader_0.Tag.ToString().smethod_18();
			this.columnHeader_0.Tag = this.columnHeader_0.Width;
		}

		// Token: 0x04001750 RID: 5968
		public ColumnHeader columnHeader_0;

		// Token: 0x04001751 RID: 5969
		public ToolStripMenuItem toolStripMenuItem_0;

		// Token: 0x04001752 RID: 5970
		public Main main_0;
	}

	// Token: 0x02000247 RID: 583
	[CompilerGenerated]
	private sealed class Class277
	{
		// Token: 0x0600236D RID: 9069 RVA: 0x0010407C File Offset: 0x0010227C
		internal void method_0()
		{
			if (this.object_0.ToString().Contains("Thoát"))
			{
				Main.Main_0.ricExit.Text = Main.Main_0.ricExit.Text.Trim() + "\r\n" + this.object_0.ToString();
				Main.Main_0.ricExit.smethod_7();
			}
			if (this.object_0.ToString().Contains("Xong"))
			{
				Main.Main_0.ricXong.Text = Main.Main_0.ricXong.Text.Trim() + "\r\n" + this.object_0.ToString();
				Main.Main_0.ricXong.smethod_7();
			}
			if (this.object_0.ToString().Contains("Mã Tặc"))
			{
				Main.Main_0.ricMaTac.Text = Main.Main_0.ricMaTac.Text.Trim() + "\r\n" + this.object_0.ToString();
				Main.Main_0.ricMaTac.smethod_7();
			}
			if (this.object_0.ToString().Contains("Ác Bá"))
			{
				Main.Main_0.ricAcBa.Text = Main.Main_0.ricAcBa.Text.Trim() + "\r\n" + this.object_0.ToString();
				Main.Main_0.ricAcBa.smethod_7();
			}
		}

		// Token: 0x04001753 RID: 5971
		public object object_0;
	}

	// Token: 0x02000248 RID: 584
	[CompilerGenerated]
	private sealed class Class278
	{
		// Token: 0x0600236F RID: 9071 RVA: 0x0001B4A8 File Offset: 0x000196A8
		internal void method_0()
		{
			this.main_0.picBank.Image = Image.FromStream(new MemoryStream(this.byte_0));
		}

		// Token: 0x04001754 RID: 5972
		public Main main_0;

		// Token: 0x04001755 RID: 5973
		public byte[] byte_0;
	}

	// Token: 0x02000249 RID: 585
	[CompilerGenerated]
	private sealed class Class279
	{
		// Token: 0x06002371 RID: 9073 RVA: 0x00104204 File Offset: 0x00102404
		internal void method_0(object sender, EventArgs e)
		{
			IEnumerable<Class159> ienumerable_ = this.main_0.IEnumerable_3;
			Action<Class159> action;
			if ((action = this.action_0) == null)
			{
				action = (this.action_0 = new Action<Class159>(this.method_1));
			}
			ienumerable_.smethod_13(action);
		}

		// Token: 0x06002372 RID: 9074 RVA: 0x0001B4CA File Offset: 0x000196CA
		internal void method_1(Class159 class159_1)
		{
			class159_1.method_276(this.class159_0.Class432_0.Byte_0);
		}

		// Token: 0x04001756 RID: 5974
		public Class159 class159_0;

		// Token: 0x04001757 RID: 5975
		public Main main_0;

		// Token: 0x04001758 RID: 5976
		public Action<Class159> action_0;
	}

	// Token: 0x0200024A RID: 586
	[CompilerGenerated]
	private sealed class Class280
	{
		// Token: 0x06002374 RID: 9076 RVA: 0x0001B4E2 File Offset: 0x000196E2
		internal void method_0()
		{
			Thread.Sleep(30000);
			this.class159_0.method_296();
		}

		// Token: 0x04001759 RID: 5977
		public Class159 class159_0;
	}

	// Token: 0x0200024D RID: 589
	[CompilerGenerated]
	private sealed class Class283
	{
		// Token: 0x06002386 RID: 9094 RVA: 0x0001B54D File Offset: 0x0001974D
		internal void method_0()
		{
			this.class159_0.method_311(false);
		}

		// Token: 0x04001760 RID: 5984
		public Class159 class159_0;
	}

	// Token: 0x0200024E RID: 590
	[CompilerGenerated]
	private sealed class Class284
	{
		// Token: 0x06002388 RID: 9096 RVA: 0x0010432C File Offset: 0x0010252C
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			if (this.geventArgs4_0.String_0.Split(new char[]
			{
				'|'
			}).Length == 6)
			{
				Stopwatch.StartNew();
				try
				{
					Main.Class285 @class = new Main.Class285();
					string string_ = this.geventArgs4_0.String_0;
					@class.string_0 = string_.Split(new char[]
					{
						'|'
					})[0];
					@class.int_3 = string_.Split(new char[]
					{
						'|'
					})[1].smethod_37();
					@class.int_0 = string_.Split(new char[]
					{
						'|'
					})[2].smethod_37();
					@class.int_1 = string_.Split(new char[]
					{
						'|'
					})[3].smethod_37();
					@class.int_2 = string_.Split(new char[]
					{
						'|'
					})[4].smethod_37();
					IEnumerable<Class145> list_ = MicroLogin.List_0;
					Func<Class145, bool> predicate;
					if ((predicate = @class.func_0) == null)
					{
						predicate = (@class.func_0 = new Func<Class145, bool>(@class.method_0));
					}
					using (IEnumerator<Class145> enumerator = list_.Where(predicate).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							Main.Class286 class2 = new Main.Class286();
							class2.class285_0 = @class;
							class2.class145_0 = enumerator.Current;
							Main.Main_0.smethod_20(new Action(class2.method_0));
						}
					}
					foreach (TabLogin tabLogin in TabLogin.List_0)
					{
						IEnumerable<Class145> list_2 = tabLogin.List_1;
						Func<Class145, bool> predicate2;
						if ((predicate2 = @class.func_1) == null)
						{
							predicate2 = (@class.func_1 = new Func<Class145, bool>(@class.method_1));
						}
						using (IEnumerator<Class145> enumerator = list_2.Where(predicate2).GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								Main.Class287 class3 = new Main.Class287();
								class3.class285_0 = @class;
								class3.class145_0 = enumerator.Current;
								Main.Main_0.smethod_20(new Action(class3.method_0));
							}
						}
					}
					return;
				}
				catch
				{
					return;
				}
			}
			Main.Class288 class4 = new Main.Class288();
			class4.string_0 = Class426.smethod_13(this.geventArgs4_0.String_0, "@", ":");
			string text = Class426.smethod_13(this.geventArgs4_0.String_0, "[", "]");
			class4.string_1 = this.geventArgs4_0.String_0;
			bool flag = false;
			if (text != null && text.Length == 19)
			{
				class4.string_1 = this.geventArgs4_0.String_0.Replace("[" + text + "]", "");
				if (Main.string_5 == "")
				{
					Main.string_5 = text;
				}
			}
			if (class4.string_0 != null && class4.string_0.Length > 0)
			{
				class4.richTextBox_0 = Main.Main_0.ricChat;
				if (!flag)
				{
					try
					{
						Main.Main_0.Invoke(new Action(class4.method_0));
						goto IL_31E;
					}
					catch
					{
						goto IL_31E;
					}
				}
				try
				{
					Main.Main_0.Invoke(new Action(class4.method_1));
				}
				catch
				{
				}
			}
			IL_31E:
			if (!Main.Boolean_20)
			{
				Class407.smethod_1();
			}
		}

		// Token: 0x04001761 RID: 5985
		public GEventArgs4 geventArgs4_0;
	}

	// Token: 0x0200024F RID: 591
	[CompilerGenerated]
	private sealed class Class285
	{
		// Token: 0x0600238A RID: 9098 RVA: 0x0001B55B File Offset: 0x0001975B
		internal bool method_0(Class145 class145_0)
		{
			return class145_0.String_9 == this.string_0;
		}

		// Token: 0x0600238B RID: 9099 RVA: 0x0001B55B File Offset: 0x0001975B
		internal bool method_1(Class145 class145_0)
		{
			return class145_0.String_9 == this.string_0;
		}

		// Token: 0x04001762 RID: 5986
		public string string_0;

		// Token: 0x04001763 RID: 5987
		public int int_0;

		// Token: 0x04001764 RID: 5988
		public int int_1;

		// Token: 0x04001765 RID: 5989
		public int int_2;

		// Token: 0x04001766 RID: 5990
		public int int_3;

		// Token: 0x04001767 RID: 5991
		public Func<Class145, bool> func_0;

		// Token: 0x04001768 RID: 5992
		public Func<Class145, bool> func_1;
	}

	// Token: 0x02000250 RID: 592
	[CompilerGenerated]
	private sealed class Class286
	{
		// Token: 0x0600238D RID: 9101 RVA: 0x001046F8 File Offset: 0x001028F8
		internal void method_0()
		{
			try
			{
				this.class145_0.String_16 = this.class285_0.int_0.ToString();
				this.class145_0.String_17 = this.class285_0.int_1.ToString();
				this.class145_0.String_18 = this.class285_0.int_2.ToString();
				this.class145_0.String_14 = this.class285_0.int_3.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x04001769 RID: 5993
		public Class145 class145_0;

		// Token: 0x0400176A RID: 5994
		public Main.Class285 class285_0;
	}

	// Token: 0x02000251 RID: 593
	[CompilerGenerated]
	private sealed class Class287
	{
		// Token: 0x0600238F RID: 9103 RVA: 0x00104788 File Offset: 0x00102988
		internal void method_0()
		{
			try
			{
				this.class145_0.String_16 = this.class285_0.int_0.ToString();
				this.class145_0.String_17 = this.class285_0.int_1.ToString();
				this.class145_0.String_18 = this.class285_0.int_2.ToString();
				this.class145_0.String_14 = this.class285_0.int_3.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x0400176B RID: 5995
		public Class145 class145_0;

		// Token: 0x0400176C RID: 5996
		public Main.Class285 class285_0;
	}

	// Token: 0x02000252 RID: 594
	[CompilerGenerated]
	private sealed class Class288
	{
		// Token: 0x06002391 RID: 9105 RVA: 0x00104818 File Offset: 0x00102A18
		internal void method_0()
		{
			this.richTextBox_0.Text = this.richTextBox_0.Text.Trim();
			this.richTextBox_0.AppendText(Environment.NewLine);
			this.richTextBox_0.AppendText("#" + this.string_0 + ": ");
			this.richTextBox_0.AppendText(this.string_1.Replace("@" + this.string_0 + ":", "").Replace("#", "").Replace(":", ""));
			string text = this.richTextBox_0.Text;
			this.richTextBox_0.Text = string.Empty;
			this.richTextBox_0.Text = text;
			GClass127.smethod_3(ref this.richTextBox_0, "#", ":", Color.BlueViolet);
			this.richTextBox_0.smethod_7();
		}

		// Token: 0x06002392 RID: 9106 RVA: 0x0010490C File Offset: 0x00102B0C
		internal void method_1()
		{
			this.richTextBox_0.smethod_6(this.string_0 + ": ", Color.Gray);
			this.richTextBox_0.smethod_6(this.string_1.Replace("@" + this.string_0 + ":", ""), Color.BlueViolet);
			this.richTextBox_0.AppendText(Environment.NewLine);
			this.richTextBox_0.smethod_7();
		}

		// Token: 0x0400176D RID: 5997
		public string string_0;

		// Token: 0x0400176E RID: 5998
		public string string_1;

		// Token: 0x0400176F RID: 5999
		public RichTextBox richTextBox_0;
	}

	// Token: 0x02000253 RID: 595
	[CompilerGenerated]
	private sealed class Class289
	{
		// Token: 0x06002394 RID: 9108 RVA: 0x0001B56E File Offset: 0x0001976E
		internal void method_0(Class159 class159_0)
		{
			if (class159_0 != this.list_0[0] || !class159_0.Class432_0.Boolean_32)
			{
				class159_0.method_282("Player:LeaveTeam();", false);
			}
		}

		// Token: 0x06002395 RID: 9109 RVA: 0x0001B598 File Offset: 0x00019798
		internal void method_1(Class159 class159_0)
		{
			class159_0.method_276(this.list_0[0].Class432_0.Byte_0);
		}

		// Token: 0x04001770 RID: 6000
		public List<Class159> list_0;
	}

	// Token: 0x02000254 RID: 596
	[CompilerGenerated]
	private sealed class Class290
	{
		// Token: 0x06002397 RID: 9111 RVA: 0x0001B5B6 File Offset: 0x000197B6
		internal void method_0(object sender, EventArgs e)
		{
			this.tabPage_0.Dispose();
		}

		// Token: 0x04001771 RID: 6001
		public TabPage tabPage_0;
	}

	// Token: 0x02000255 RID: 597
	[CompilerGenerated]
	private sealed class Class291
	{
		// Token: 0x06002399 RID: 9113 RVA: 0x0001B5C3 File Offset: 0x000197C3
		internal void method_0(Class159 class159_0)
		{
			class159_0.method_48(Enum14.NangTamPhap, true);
			class159_0.Int32_58 = Class426.smethod_41(this.toolStripMenuItem_0.Text);
		}

		// Token: 0x04001772 RID: 6002
		public ToolStripMenuItem toolStripMenuItem_0;
	}

	// Token: 0x02000256 RID: 598
	[CompilerGenerated]
	private sealed class Class292
	{
		// Token: 0x0600239B RID: 9115 RVA: 0x0001B5E4 File Offset: 0x000197E4
		internal void method_0(Class159 class159_0)
		{
			if (this.bool_0)
			{
				class159_0.Int32_5 = 1;
				return;
			}
			class159_0.Int32_5 = 0;
		}

		// Token: 0x04001773 RID: 6003
		public bool bool_0;
	}

	// Token: 0x02000257 RID: 599
	[CompilerGenerated]
	private sealed class Class293
	{
		// Token: 0x0600239D RID: 9117 RVA: 0x0001B5FD File Offset: 0x000197FD
		internal void method_0(Class159 class159_0)
		{
			if (this.bool_0)
			{
				class159_0.Int32_5 = 2;
				return;
			}
			class159_0.Int32_5 = 0;
		}

		// Token: 0x04001774 RID: 6004
		public bool bool_0;
	}

	// Token: 0x02000258 RID: 600
	[CompilerGenerated]
	private sealed class Class294
	{
		// Token: 0x0600239F RID: 9119 RVA: 0x0001B616 File Offset: 0x00019816
		internal void method_0(Class159 class159_0)
		{
			if (this.bool_0)
			{
				class159_0.Int32_5 = 3;
				return;
			}
			class159_0.Int32_5 = 0;
		}

		// Token: 0x04001775 RID: 6005
		public bool bool_0;
	}

	// Token: 0x02000259 RID: 601
	[CompilerGenerated]
	private sealed class Class295
	{
		// Token: 0x060023A1 RID: 9121 RVA: 0x0001B62F File Offset: 0x0001982F
		internal void method_0(Class159 class159_0)
		{
			if (this.bool_0)
			{
				class159_0.Boolean_8 = true;
				return;
			}
			class159_0.Boolean_8 = false;
		}

		// Token: 0x04001776 RID: 6006
		public bool bool_0;
	}

	// Token: 0x0200025A RID: 602
	[CompilerGenerated]
	private sealed class Class296
	{
		// Token: 0x060023A3 RID: 9123 RVA: 0x0001B648 File Offset: 0x00019848
		internal void method_0(Class159 class159_0)
		{
			class159_0.Int32_38 = this.int_0;
		}

		// Token: 0x04001777 RID: 6007
		public int int_0;
	}

	// Token: 0x0200025B RID: 603
	[CompilerGenerated]
	private sealed class Class297
	{
		// Token: 0x060023A5 RID: 9125 RVA: 0x0001B656 File Offset: 0x00019856
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			this.class159_0.method_82();
		}

		// Token: 0x04001778 RID: 6008
		public Class159 class159_0;
	}

	// Token: 0x0200025C RID: 604
	[CompilerGenerated]
	private sealed class Class298
	{
		// Token: 0x060023A7 RID: 9127 RVA: 0x0001B66E File Offset: 0x0001986E
		internal void method_0(object sender, EventArgs e)
		{
			this.tabPage_0.Dispose();
		}

		// Token: 0x04001779 RID: 6009
		public TabPage tabPage_0;
	}

	// Token: 0x0200025D RID: 605
	[CompilerGenerated]
	private sealed class Class299
	{
		// Token: 0x060023A9 RID: 9129 RVA: 0x0010498C File Offset: 0x00102B8C
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			Control main_ = Main.Main_0;
			Action method;
			if ((method = this.action_0) == null)
			{
				method = (this.action_0 = new Action(this.method_1));
			}
			main_.Invoke(method);
		}

		// Token: 0x060023AA RID: 9130 RVA: 0x0001B67B File Offset: 0x0001987B
		internal void method_1()
		{
			this.class159_0.method_224(true);
		}

		// Token: 0x0400177A RID: 6010
		public Class159 class159_0;

		// Token: 0x0400177B RID: 6011
		public Action action_0;
	}

	// Token: 0x0200025E RID: 606
	[CompilerGenerated]
	private sealed class Class300
	{
		// Token: 0x060023AC RID: 9132 RVA: 0x0001B689 File Offset: 0x00019889
		internal void method_0()
		{
			this.class159_0.method_311(true);
		}

		// Token: 0x0400177C RID: 6012
		public Class159 class159_0;
	}

	// Token: 0x0200025F RID: 607
	[CompilerGenerated]
	private sealed class Class301
	{
		// Token: 0x060023AE RID: 9134 RVA: 0x001049D0 File Offset: 0x00102BD0
		internal void method_0(Class159 class159_0)
		{
			class159_0.method_48(Enum14.DatDoiBossMap, !((ToolStripMenuItem)this.object_0).Checked);
			class159_0.Int32_46 = Class426.smethod_41(((ToolStripMenuItem)this.object_0).Tag.ToString());
			class159_0.int_21 = 0;
		}

		// Token: 0x0400177D RID: 6013
		public object object_0;
	}

	// Token: 0x02000260 RID: 608
	[CompilerGenerated]
	private sealed class Class302
	{
		// Token: 0x060023B0 RID: 9136 RVA: 0x0001B697 File Offset: 0x00019897
		internal void method_0(object sender, EventArgs e)
		{
			MessageBox.Show(this.main_0, this.class412_0.String_2, "MicroAuto", MessageBoxButtons.OK);
		}

		// Token: 0x0400177E RID: 6014
		public Main main_0;

		// Token: 0x0400177F RID: 6015
		public Class412 class412_0;
	}

	// Token: 0x02000261 RID: 609
	[CompilerGenerated]
	private sealed class Class303
	{
		// Token: 0x060023B2 RID: 9138 RVA: 0x0001B6B6 File Offset: 0x000198B6
		internal void method_0(Class159 class159_0)
		{
			class159_0.String_21 = (((ToolStripMenuItem)this.object_0).Tag as string);
		}

		// Token: 0x04001780 RID: 6016
		public object object_0;
	}

	// Token: 0x02000262 RID: 610
	[CompilerGenerated]
	private sealed class Class304
	{
		// Token: 0x060023B4 RID: 9140 RVA: 0x0001B6D3 File Offset: 0x000198D3
		internal void method_0(object sender, EventArgs e)
		{
			this.tabPage_0.Dispose();
		}

		// Token: 0x04001781 RID: 6017
		public TabPage tabPage_0;
	}

	// Token: 0x02000263 RID: 611
	[CompilerGenerated]
	private sealed class Class305
	{
		// Token: 0x060023B6 RID: 9142 RVA: 0x00104A20 File Offset: 0x00102C20
		internal void method_0()
		{
			for (int i = 0; i < 5; i++)
			{
				int num = i + 1;
				Thread.CurrentThread.IsBackground = true;
				uint num2 = 0U;
				int j = 0;
				while (j < 5)
				{
					bool flag = false;
					using (IEnumerator<Class209> enumerator = this.class159_0.Class196_0.IEnumerable_0.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							Class209 @class = enumerator.Current;
							if (@class.String_3.Contains("tanquyen"))
							{
								@class.method_2();
								Thread.Sleep(500);
								this.class159_0.method_282("setmetatable(_G, {__index = Attainment_Env}); if this:IsVisible() then Attainment_ChooseAttr(" + (num - 1).ToString() + "); end", false);
								Thread.Sleep(500);
								flag = true;
								if (num2 != @class.UInt32_5)
								{
									num2 = @class.UInt32_5;
									j = 0;
									break;
								}
								IL_C2:
								goto IL_E2;
							}
						}
						goto IL_C2;
					}
					IL_D0:
					j++;
					continue;
					IL_E2:
					if (flag)
					{
						goto IL_D0;
					}
					break;
				}
			}
		}

		// Token: 0x04001782 RID: 6018
		public Class159 class159_0;
	}

	// Token: 0x02000264 RID: 612
	[CompilerGenerated]
	private sealed class Class306
	{
		// Token: 0x060023B8 RID: 9144 RVA: 0x00104B28 File Offset: 0x00102D28
		internal void method_0(KeyValuePair<int, Class159> keyValuePair_0)
		{
			int int_ = keyValuePair_0.Value.Class405_0.method_46(this.string_0);
			keyValuePair_0.Value.method_57(1, 988);
			keyValuePair_0.Value.method_57(int_, 987);
		}

		// Token: 0x04001783 RID: 6019
		public string string_0;
	}

	// Token: 0x02000265 RID: 613
	[CompilerGenerated]
	private sealed class Class307
	{
		// Token: 0x060023BA RID: 9146 RVA: 0x00104B74 File Offset: 0x00102D74
		internal void method_0()
		{
			try
			{
				MicroLogin.smethod_1();
				this.main_0.method_28();
				Main.String_3 = this.toolStripMenuItem_0.Tag.ToString();
				Class415.smethod_12();
				this.main_0.method_14(null, null);
				Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(Main.Class270.<>9.method_78));
				TabLogin.List_0.Where(new Func<TabLogin, bool>(Main.Class270.<>9.method_79)).ToList<TabLogin>().ForEach(new Action<TabLogin>(Main.Class270.<>9.method_80));
				TabLogin.List_0 = TabLogin.List_0.Where(new Func<TabLogin, bool>(Main.Class270.<>9.method_81)).ToList<TabLogin>();
				Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(Main.Class270.<>9.method_82));
				CalendarEx.smethod_0();
			}
			catch
			{
			}
		}

		// Token: 0x04001784 RID: 6020
		public Main main_0;

		// Token: 0x04001785 RID: 6021
		public ToolStripMenuItem toolStripMenuItem_0;
	}

	// Token: 0x02000266 RID: 614
	[CompilerGenerated]
	private sealed class Class308
	{
		// Token: 0x060023BC RID: 9148 RVA: 0x00104CC0 File Offset: 0x00102EC0
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			try
			{
				Main.GClass25_0.method_88(this.string_0);
			}
			catch
			{
			}
		}

		// Token: 0x04001786 RID: 6022
		public string string_0;
	}

	// Token: 0x02000267 RID: 615
	[CompilerGenerated]
	private sealed class Class309
	{
		// Token: 0x060023BE RID: 9150 RVA: 0x00104D00 File Offset: 0x00102F00
		internal void method_0(object sender, EventArgs e)
		{
			string text = this.class412_0.String_2.Split(new char[]
			{
				'\n'
			})[0];
			if (text.Length == 19)
			{
				Main.string_5 = text;
			}
			this.class412_0.String_2 = this.class412_0.String_2.Replace(Main.string_5, "").Trim();
			string text2 = this.class412_0.String_2 + "\r\n" + this.main_0.ricChat.Text.Trim();
			this.main_0.ricChat.Text = string.Empty;
			this.main_0.ricChat.Text = text2;
			GClass127.smethod_3(ref this.main_0.ricChat, "#", ":", Color.BlueViolet);
			this.main_0.label7.Enabled = true;
		}

		// Token: 0x04001787 RID: 6023
		public Class412 class412_0;

		// Token: 0x04001788 RID: 6024
		public Main main_0;
	}

	// Token: 0x02000268 RID: 616
	[CompilerGenerated]
	private sealed class Class310
	{
		// Token: 0x060023C0 RID: 9152 RVA: 0x00104DE8 File Offset: 0x00102FE8
		internal void method_0(Class159 class159_0)
		{
			if (class159_0 != null)
			{
				int index = this.itemCheckedEventArgs_0.Item.Index;
				if (index == 0)
				{
					class159_0.bool_28 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				if (index == 1)
				{
					class159_0.Boolean_5 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				if (index == 2)
				{
					class159_0.Boolean_6 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				if (index == 3)
				{
					class159_0.Boolean_18 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				if (index == 4)
				{
					class159_0.bool_29 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				if (index == 5)
				{
					class159_0.Boolean_100 = this.itemCheckedEventArgs_0.Item.Checked;
				}
				for (int i = 0; i < 12; i++)
				{
					if (index == i + 6)
					{
						class159_0.Boolean_15[i] = this.itemCheckedEventArgs_0.Item.Checked;
					}
				}
				for (int j = 0; j < 9; j++)
				{
					if (index == j + 18)
					{
						class159_0.Boolean_14[j + 1] = this.itemCheckedEventArgs_0.Item.Checked;
					}
				}
				if (index == 27)
				{
					class159_0.Boolean_14[0] = this.itemCheckedEventArgs_0.Item.Checked;
				}
				class159_0.method_389();
			}
		}

		// Token: 0x04001789 RID: 6025
		public ItemCheckedEventArgs itemCheckedEventArgs_0;
	}

	// Token: 0x02000269 RID: 617
	[CompilerGenerated]
	private sealed class Class311
	{
		// Token: 0x060023C2 RID: 9154 RVA: 0x0001B6E0 File Offset: 0x000198E0
		internal void method_0(object sender, EventArgs e)
		{
			this.main_0.Enabled = true;
			string string_ = this.class412_0.String_2;
		}

		// Token: 0x0400178A RID: 6026
		public Main main_0;

		// Token: 0x0400178B RID: 6027
		public Class412 class412_0;
	}

	// Token: 0x0200026A RID: 618
	[CompilerGenerated]
	private sealed class Class312
	{
		// Token: 0x060023C4 RID: 9156 RVA: 0x00104F24 File Offset: 0x00103124
		internal void method_0(object sender, EventArgs e)
		{
			if (this.class412_0.String_2 == string.Empty)
			{
				MessageBox.Show(this.main_0, "Thiết Lập Rỗng!!!", "MicroAuto", MessageBoxButtons.OK);
				return;
			}
			Class159.Class220_0 = new Class220(this.class412_0.String_2);
			Class415.smethod_12();
			this.main_0.method_14(null, null);
			Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(Main.Class270.<>9.method_88));
			CalendarEx.smethod_0();
			MessageBox.Show(this.main_0, "Tải thiết lập từ máy chủ về thành công!!!", "MicroAuto", MessageBoxButtons.OK);
		}

		// Token: 0x0400178C RID: 6028
		public Main main_0;

		// Token: 0x0400178D RID: 6029
		public Class412 class412_0;
	}

	// Token: 0x0200026B RID: 619
	[CompilerGenerated]
	private sealed class Class313
	{
		// Token: 0x060023C6 RID: 9158 RVA: 0x00104FD4 File Offset: 0x001031D4
		internal void method_0()
		{
			foreach (Class209 @class in Main.class159_0.Class196_0.IEnumerable_8)
			{
				if (this.dictionary_0.ContainsKey(@class.String_0))
				{
					int num = this.dictionary_0[@class.String_0] * 100;
					Main.class159_0.method_312(@class.String_2, @class.UInt32_3);
					Thread.Sleep(1000);
					Main.class159_0.method_282("PlayerShop:UpStall('item'," + ((long)num * (long)((ulong)@class.UInt32_5)).ToString() + ");", false);
					Thread.Sleep(1000);
					Main.class159_0.method_410("Đã treo " + @class.String_0 + " giá " + ((long)this.dictionary_0[@class.String_0] * (long)((ulong)@class.UInt32_5)).ToString());
				}
			}
			Main.class159_0.method_410("Treo xong rổi nhá");
		}

		// Token: 0x0400178E RID: 6030
		public Dictionary<string, int> dictionary_0;
	}

	// Token: 0x0200026C RID: 620
	[CompilerGenerated]
	private sealed class Class314
	{
		// Token: 0x060023C8 RID: 9160 RVA: 0x001050FC File Offset: 0x001032FC
		internal void method_0()
		{
			for (int i = 0; i < 10; i++)
			{
				this.class159_0.method_282("setmetatable(_G, {__index = SelfJunXian_Env}); SelfJunXian_EquipHXYLevelup(); ", false);
			}
		}

		// Token: 0x0400178F RID: 6031
		public Class159 class159_0;
	}

	// Token: 0x0200026D RID: 621
	[CompilerGenerated]
	private sealed class Class315
	{
		// Token: 0x060023CA RID: 9162 RVA: 0x00105128 File Offset: 0x00103328
		internal void method_0()
		{
			foreach (Class209 @class in Main.class159_0.Class196_0.IEnumerable_0)
			{
				if (this.dictionary_0.ContainsKey(@class.String_0))
				{
					int num = this.dictionary_0[@class.String_0] * 100;
					@class.method_1();
					Thread.Sleep(1000);
					Main.class159_0.method_282("StallSale:ReferItemPrice(" + ((long)num * (long)((ulong)@class.UInt32_5)).ToString() + ");", false);
					Thread.Sleep(1000);
					Main.class159_0.method_410("Đã treo " + @class.String_0 + " giá " + ((long)this.dictionary_0[@class.String_0] * (long)((ulong)@class.UInt32_5)).ToString());
					Main.class159_0.method_282("setmetatable(_G, {__index = InputMoney_Env});  this:Hide();", false);
					Thread.Sleep(350);
				}
			}
			Main.class159_0.method_410("Treo xong rổi nhá");
		}

		// Token: 0x04001790 RID: 6032
		public Dictionary<string, int> dictionary_0;
	}

	// Token: 0x0200026E RID: 622
	[CompilerGenerated]
	private sealed class Class316
	{
		// Token: 0x060023CC RID: 9164 RVA: 0x0010525C File Offset: 0x0010345C
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(1); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x04001791 RID: 6033
		public Class159 class159_0;
	}

	// Token: 0x0200026F RID: 623
	[CompilerGenerated]
	private sealed class Class317
	{
		// Token: 0x060023CE RID: 9166 RVA: 0x00105308 File Offset: 0x00103508
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(2); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x04001792 RID: 6034
		public Class159 class159_0;
	}

	// Token: 0x02000270 RID: 624
	[CompilerGenerated]
	private sealed class Class318
	{
		// Token: 0x060023D0 RID: 9168 RVA: 0x001053B4 File Offset: 0x001035B4
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(3); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x04001793 RID: 6035
		public Class159 class159_0;
	}

	// Token: 0x02000271 RID: 625
	[CompilerGenerated]
	private sealed class Class319
	{
		// Token: 0x060023D2 RID: 9170 RVA: 0x00105460 File Offset: 0x00103660
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			if (this.class159_0.Class432_0.Boolean_30)
			{
				this.class159_0.method_272();
				Thread.Sleep(1000);
			}
			foreach (Class159 @class in this.class159_0.List_25)
			{
				if (!(@class.Class432_0.String_1 == this.class159_0.Class432_0.String_1))
				{
					this.class159_0.method_242(@class.UInt32_4);
					Thread.Sleep(1000);
					this.class159_0.method_313("EUicons_6", uint.MaxValue);
					Thread.Sleep(1000);
				}
			}
			this.class159_0.method_351(Class360.class424_1);
			Thread.Sleep(1000);
			this.class159_0.Class389_0.method_5("#{WSTGY_111012_01}");
			Thread.Sleep(1000);
			this.class159_0.Class389_0.method_5("#{WSTGY_111012_08}");
			Thread.Sleep(1000);
			this.class159_0.Class368_0.method_34();
			Thread.Sleep(1000);
			this.class159_0.Class368_0.method_33();
		}

		// Token: 0x04001794 RID: 6036
		public Class159 class159_0;
	}

	// Token: 0x02000272 RID: 626
	[CompilerGenerated]
	private sealed class Class320
	{
		// Token: 0x060023D4 RID: 9172 RVA: 0x001055C4 File Offset: 0x001037C4
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			if (this.int_0 != -1 && this.int_1 != -1)
			{
				this.class159_0.method_282("local theAction,bLocked = PlayerPackage:EnumItem('material', " + (this.int_0 - 30).ToString() + ");\r\n                                        NGOCVAL = theAction:GetDefineID();", false);
				this.class159_0.method_282("LifeAbility:Do_Combine(NGOCVAL," + this.int_1.ToString() + ",0,100)", false);
				Thread.Sleep(100);
				this.class159_0.method_282("LifeAbility:Do_Combine(NGOCVAL," + this.int_1.ToString() + ",0,100)", false);
				Thread.Sleep(300);
				this.class159_0.method_282("setmetatable(_G, {__index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
			}
		}

		// Token: 0x04001795 RID: 6037
		public Class159 class159_0;

		// Token: 0x04001796 RID: 6038
		public int int_0;

		// Token: 0x04001797 RID: 6039
		public int int_1;
	}

	// Token: 0x02000273 RID: 627
	[CompilerGenerated]
	private sealed class Class321
	{
		// Token: 0x060023D6 RID: 9174 RVA: 0x00105690 File Offset: 0x00103890
		internal void method_0()
		{
			Class159 @class = this.class159_0;
			string[] array = new string[5];
			array[0] = "Clear_XSCRIPT(); Set_XSCRIPT_Function_Name('OnGemCarve'); Set_XSCRIPT_ScriptID(800117); Set_XSCRIPT_Parameter(0, ";
			array[1] = this.int_0.ToString();
			array[2] = "); Set_XSCRIPT_Parameter(1, ";
			int num = 3;
			int num2 = this.int_1;
			array[num] = num2.ToString();
			array[4] = "); Set_XSCRIPT_Parameter(2, 134); Set_XSCRIPT_ParamCount(3); Send_XSCRIPT(); ";
			@class.method_282(string.Concat(array), false);
		}

		// Token: 0x04001798 RID: 6040
		public Class159 class159_0;

		// Token: 0x04001799 RID: 6041
		public int int_0;

		// Token: 0x0400179A RID: 6042
		public int int_1;
	}

	// Token: 0x02000274 RID: 628
	[CompilerGenerated]
	private sealed class Class322
	{
		// Token: 0x060023D8 RID: 9176 RVA: 0x0001B6FA File Offset: 0x000198FA
		internal void method_0(Class159 class159_0)
		{
			class159_0.method_48(Enum14.HopVoHon, true);
			class159_0.Int32_51 = this.int_0 - 1;
		}

		// Token: 0x0400179B RID: 6043
		public int int_0;
	}

	// Token: 0x02000275 RID: 629
	[CompilerGenerated]
	private sealed class Class323
	{
		// Token: 0x060023DA RID: 9178 RVA: 0x0001B713 File Offset: 0x00019913
		internal void method_0(Class159 class159_0)
		{
			class159_0.method_48(Enum14.NangTamPhap, true);
			class159_0.method_51(Enum14.Quyen3Len30);
			class159_0.Int32_58 = Class426.smethod_41(this.toolStripMenuItem_0.Text);
		}

		// Token: 0x0400179C RID: 6044
		public ToolStripMenuItem toolStripMenuItem_0;
	}

	// Token: 0x02000276 RID: 630
	[CompilerGenerated]
	private sealed class Class324
	{
		// Token: 0x060023DC RID: 9180 RVA: 0x001056EC File Offset: 0x001038EC
		internal void method_0()
		{
			for (int i = 0; i < 10; i++)
			{
				this.class159_0.method_282("setmetatable(_G, {__index = SelfJunXian_Env}); SelfJunXian_EquipHXYLevelup(); ", false);
			}
		}

		// Token: 0x0400179D RID: 6045
		public Class159 class159_0;
	}

	// Token: 0x02000277 RID: 631
	[CompilerGenerated]
	private sealed class Class325
	{
		// Token: 0x060023DE RID: 9182 RVA: 0x00105718 File Offset: 0x00103918
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(1); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x0400179E RID: 6046
		public Class159 class159_0;
	}

	// Token: 0x02000278 RID: 632
	[CompilerGenerated]
	private sealed class Class326
	{
		// Token: 0x060023E0 RID: 9184 RVA: 0x001057C4 File Offset: 0x001039C4
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(2); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x0400179F RID: 6047
		public Class159 class159_0;
	}

	// Token: 0x02000279 RID: 633
	[CompilerGenerated]
	private sealed class Class327
	{
		// Token: 0x060023E2 RID: 9186 RVA: 0x00105870 File Offset: 0x00103A70
		internal void method_0()
		{
			Thread.CurrentThread.IsBackground = true;
			foreach (Class209 @class in this.class159_0.Class196_0.IEnumerable_0)
			{
				if (@class.String_3 == "quavuuoc")
				{
					@class.method_2();
					Thread.Sleep(1000);
					break;
				}
			}
			this.class159_0.method_282("setmetatable(_G, {__index = HuoyueWeeklyGift_Env}); if this:IsVisible() then HuoyueWeeklyGift_Select(3); end ", false);
			Thread.Sleep(1000);
			this.class159_0.method_282("setmetatable(_G, { __index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click(); end", false);
		}

		// Token: 0x040017A0 RID: 6048
		public Class159 class159_0;
	}

	// Token: 0x0200027A RID: 634
	[CompilerGenerated]
	private sealed class Class328
	{
		// Token: 0x060023E4 RID: 9188 RVA: 0x0001B73C File Offset: 0x0001993C
		internal void method_0(object sender, EventArgs e)
		{
			this.tabPage_0.Dispose();
		}

		// Token: 0x040017A1 RID: 6049
		public TabPage tabPage_0;
	}

	// Token: 0x0200027B RID: 635
	[CompilerGenerated]
	private sealed class Class329
	{
		// Token: 0x060023E6 RID: 9190 RVA: 0x0010591C File Offset: 0x00103B1C
		internal void method_0()
		{
			try
			{
				while (Process.GetProcessesByName("Game").Length != 0)
				{
					try
					{
						Process.GetProcessesByName("Game")[0].Kill();
					}
					catch
					{
					}
					Thread.Sleep(100);
				}
				string text = Class412.smethod_1("http://tieudattai.org/gamehex.php", null, false);
				byte[] array = File.ReadAllBytes(this.openFileDialog_0.FileName);
				foreach (string text2 in text.Split(new char[]
				{
					'\n'
				}))
				{
					try
					{
						string text3 = text2.Trim();
						int num = Class426.smethod_43(text3.Split(new char[]
						{
							':'
						})[0]);
						int num2 = Class265.smethod_20(text3.Split(new char[]
						{
							':'
						})[1].Substring(0, text3.Split(new char[]
						{
							':'
						})[1].IndexOf("=>")));
						int num3 = Class265.smethod_20(text3.Substring(text3.IndexOf("=>") + 2));
						if ((int)array[num] == num2)
						{
							array[num] = (byte)num3;
						}
					}
					catch
					{
					}
				}
				File.WriteAllBytes(this.openFileDialog_0.FileName, array);
				MessageBox.Show(this.main_0, "Vá xong rồi nhé", "MicroAuto", MessageBoxButtons.OK);
			}
			catch
			{
				MessageBox.Show(this.main_0, "Có lỗi xảy ra vui lòng thử lại hoặc reset máy", "MicroAuto", MessageBoxButtons.OK);
			}
		}

		// Token: 0x040017A2 RID: 6050
		public OpenFileDialog openFileDialog_0;

		// Token: 0x040017A3 RID: 6051
		public Main main_0;
	}
}
