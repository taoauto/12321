﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200017E RID: 382
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct7
{
	// Token: 0x040009A4 RID: 2468
	public ushort e_magic;

	// Token: 0x040009A5 RID: 2469
	public ushort e_cblp;

	// Token: 0x040009A6 RID: 2470
	public ushort e_cp;

	// Token: 0x040009A7 RID: 2471
	public ushort e_crlc;

	// Token: 0x040009A8 RID: 2472
	public ushort e_cparhdr;

	// Token: 0x040009A9 RID: 2473
	public ushort e_minalloc;

	// Token: 0x040009AA RID: 2474
	public ushort e_maxalloc;

	// Token: 0x040009AB RID: 2475
	public ushort e_ss;

	// Token: 0x040009AC RID: 2476
	public ushort e_sp;

	// Token: 0x040009AD RID: 2477
	public ushort e_csum;

	// Token: 0x040009AE RID: 2478
	public ushort e_ip;

	// Token: 0x040009AF RID: 2479
	public ushort e_cs;

	// Token: 0x040009B0 RID: 2480
	public ushort e_lfarlc;

	// Token: 0x040009B1 RID: 2481
	public ushort e_ovno;

	// Token: 0x040009B2 RID: 2482
	public ushort e_res_0;

	// Token: 0x040009B3 RID: 2483
	public ushort e_res_1;

	// Token: 0x040009B4 RID: 2484
	public ushort e_res_2;

	// Token: 0x040009B5 RID: 2485
	public ushort e_res_3;

	// Token: 0x040009B6 RID: 2486
	public ushort e_oemid;

	// Token: 0x040009B7 RID: 2487
	public ushort e_oeminfo;

	// Token: 0x040009B8 RID: 2488
	public ushort e_res2_0;

	// Token: 0x040009B9 RID: 2489
	public ushort e_res2_1;

	// Token: 0x040009BA RID: 2490
	public ushort e_res2_2;

	// Token: 0x040009BB RID: 2491
	public ushort e_res2_3;

	// Token: 0x040009BC RID: 2492
	public ushort e_res2_4;

	// Token: 0x040009BD RID: 2493
	public ushort e_res2_5;

	// Token: 0x040009BE RID: 2494
	public ushort e_res2_6;

	// Token: 0x040009BF RID: 2495
	public ushort e_res2_7;

	// Token: 0x040009C0 RID: 2496
	public ushort e_res2_8;

	// Token: 0x040009C1 RID: 2497
	public ushort e_res2_9;

	// Token: 0x040009C2 RID: 2498
	public uint e_lfanew;
}
