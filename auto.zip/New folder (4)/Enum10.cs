﻿using System;

// Token: 0x0200015F RID: 351
internal enum Enum10
{
	// Token: 0x04000878 RID: 2168
	Idle,
	// Token: 0x04000879 RID: 2169
	Connecting,
	// Token: 0x0400087A RID: 2170
	Downloading,
	// Token: 0x0400087B RID: 2171
	Paused,
	// Token: 0x0400087C RID: 2172
	Finished,
	// Token: 0x0400087D RID: 2173
	Error
}
