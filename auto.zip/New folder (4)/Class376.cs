﻿using System;

// Token: 0x020002B2 RID: 690
internal class Class376
{
	// Token: 0x1700084A RID: 2122
	// (get) Token: 0x06002677 RID: 9847 RVA: 0x0001CB5F File Offset: 0x0001AD5F
	public static string String_0
	{
		get
		{
			return "Tinh Túc Hải";
		}
	}

	// Token: 0x040019DD RID: 6621
	public static int int_0 = 16;

	// Token: 0x040019DE RID: 6622
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 8U,
		Int32_0 = 98,
		Int32_1 = 47,
		Int32_2 = Class376.int_0,
		String_2 = "Thiên Ưng Tử"
	};

	// Token: 0x040019DF RID: 6623
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 96,
		Int32_1 = 75,
		Int32_2 = Class376.int_0,
		String_2 = "Hàn Thế Trung"
	};

	// Token: 0x040019E0 RID: 6624
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 96,
		Int32_1 = 93,
		Int32_2 = Class376.int_0,
		String_2 = "Vương Ngạn"
	};

	// Token: 0x040019E1 RID: 6625
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 87,
		Int32_1 = 70,
		Int32_2 = Class376.int_0,
		String_2 = "Thi Toàn"
	};
}
