﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x020002C6 RID: 710
internal class Class393
{
	// Token: 0x1700094A RID: 2378
	// (get) Token: 0x060028E6 RID: 10470 RVA: 0x0001E0F2 File Offset: 0x0001C2F2
	// (set) Token: 0x060028E7 RID: 10471 RVA: 0x0001E0FA File Offset: 0x0001C2FA
	public Class159 Class159_0 { get; set; }

	// Token: 0x1700094B RID: 2379
	// (get) Token: 0x060028E8 RID: 10472 RVA: 0x0001E103 File Offset: 0x0001C303
	// (set) Token: 0x060028E9 RID: 10473 RVA: 0x0001E10B File Offset: 0x0001C30B
	private Class405 Class405_0 { get; set; }

	// Token: 0x1700094C RID: 2380
	// (get) Token: 0x060028EA RID: 10474 RVA: 0x0001E114 File Offset: 0x0001C314
	// (set) Token: 0x060028EB RID: 10475 RVA: 0x0001E11C File Offset: 0x0001C31C
	private Class392 Class392_0 { get; set; }

	// Token: 0x1700094D RID: 2381
	// (get) Token: 0x060028EC RID: 10476 RVA: 0x0001E125 File Offset: 0x0001C325
	// (set) Token: 0x060028ED RID: 10477 RVA: 0x0001E12D File Offset: 0x0001C32D
	public uint UInt32_0 { get; set; }

	// Token: 0x1700094E RID: 2382
	// (get) Token: 0x060028EE RID: 10478 RVA: 0x0001E136 File Offset: 0x0001C336
	// (set) Token: 0x060028EF RID: 10479 RVA: 0x0001E13E File Offset: 0x0001C33E
	public uint UInt32_1 { get; set; }

	// Token: 0x1700094F RID: 2383
	// (get) Token: 0x060028F0 RID: 10480 RVA: 0x0001E147 File Offset: 0x0001C347
	// (set) Token: 0x060028F1 RID: 10481 RVA: 0x0001E14F File Offset: 0x0001C34F
	public uint UInt32_2 { get; set; }

	// Token: 0x17000950 RID: 2384
	// (get) Token: 0x060028F2 RID: 10482 RVA: 0x0001E158 File Offset: 0x0001C358
	// (set) Token: 0x060028F3 RID: 10483 RVA: 0x0001E160 File Offset: 0x0001C360
	public uint UInt32_3 { get; set; }

	// Token: 0x17000951 RID: 2385
	// (get) Token: 0x060028F4 RID: 10484 RVA: 0x0001E169 File Offset: 0x0001C369
	// (set) Token: 0x060028F5 RID: 10485 RVA: 0x0001E171 File Offset: 0x0001C371
	public float Single_0 { get; set; }

	// Token: 0x17000952 RID: 2386
	// (get) Token: 0x060028F6 RID: 10486 RVA: 0x0001E17A File Offset: 0x0001C37A
	// (set) Token: 0x060028F7 RID: 10487 RVA: 0x0001E182 File Offset: 0x0001C382
	public float Single_1 { get; set; }

	// Token: 0x17000953 RID: 2387
	// (get) Token: 0x060028F8 RID: 10488 RVA: 0x0011AA40 File Offset: 0x00118C40
	public List<uint> List_0
	{
		get
		{
			if (this.list_0 == null)
			{
				this.list_0 = new List<uint>();
				foreach (uint num in this.HashSet_0)
				{
					this.list_0.Add(this.Class159_0.Class405_0.method_11(num + 16U));
				}
			}
			return this.list_0;
		}
	}

	// Token: 0x17000954 RID: 2388
	// (get) Token: 0x060028F9 RID: 10489 RVA: 0x0001E18B File Offset: 0x0001C38B
	// (set) Token: 0x060028FA RID: 10490 RVA: 0x0001E193 File Offset: 0x0001C393
	public uint UInt32_4 { get; set; }

	// Token: 0x17000955 RID: 2389
	// (get) Token: 0x060028FB RID: 10491 RVA: 0x0001E19C File Offset: 0x0001C39C
	// (set) Token: 0x060028FC RID: 10492 RVA: 0x0001E1A4 File Offset: 0x0001C3A4
	public uint UInt32_5 { get; set; }

	// Token: 0x17000956 RID: 2390
	// (get) Token: 0x060028FD RID: 10493 RVA: 0x0001E1AD File Offset: 0x0001C3AD
	// (set) Token: 0x060028FE RID: 10494 RVA: 0x0001E1B5 File Offset: 0x0001C3B5
	public uint UInt32_6 { get; set; }

	// Token: 0x17000957 RID: 2391
	// (get) Token: 0x060028FF RID: 10495 RVA: 0x0001E1BE File Offset: 0x0001C3BE
	// (set) Token: 0x06002900 RID: 10496 RVA: 0x0001E1C6 File Offset: 0x0001C3C6
	public uint UInt32_7 { get; set; }

	// Token: 0x17000958 RID: 2392
	// (get) Token: 0x06002901 RID: 10497 RVA: 0x0001E1CF File Offset: 0x0001C3CF
	// (set) Token: 0x06002902 RID: 10498 RVA: 0x0001E1D7 File Offset: 0x0001C3D7
	public float Single_2 { get; set; }

	// Token: 0x17000959 RID: 2393
	// (get) Token: 0x06002903 RID: 10499 RVA: 0x0001E1E0 File Offset: 0x0001C3E0
	// (set) Token: 0x06002904 RID: 10500 RVA: 0x0001E1E8 File Offset: 0x0001C3E8
	public float Single_3 { get; set; }

	// Token: 0x1700095A RID: 2394
	// (get) Token: 0x06002905 RID: 10501 RVA: 0x0001E1F1 File Offset: 0x0001C3F1
	// (set) Token: 0x06002906 RID: 10502 RVA: 0x0001E1F9 File Offset: 0x0001C3F9
	public string String_0 { get; set; }

	// Token: 0x1700095B RID: 2395
	// (get) Token: 0x06002907 RID: 10503 RVA: 0x0001E202 File Offset: 0x0001C402
	// (set) Token: 0x06002908 RID: 10504 RVA: 0x0001E20A File Offset: 0x0001C40A
	public string String_1 { get; set; }

	// Token: 0x1700095C RID: 2396
	// (get) Token: 0x06002909 RID: 10505 RVA: 0x0001E213 File Offset: 0x0001C413
	// (set) Token: 0x0600290A RID: 10506 RVA: 0x0001E21B File Offset: 0x0001C41B
	public string String_2 { get; set; }

	// Token: 0x1700095D RID: 2397
	// (get) Token: 0x0600290B RID: 10507 RVA: 0x0001E224 File Offset: 0x0001C424
	// (set) Token: 0x0600290C RID: 10508 RVA: 0x0001E22C File Offset: 0x0001C42C
	public byte[] Byte_0 { get; set; }

	// Token: 0x1700095E RID: 2398
	// (get) Token: 0x0600290D RID: 10509 RVA: 0x0001E235 File Offset: 0x0001C435
	public string String_3
	{
		get
		{
			if (this.string_3 == null)
			{
				this.string_3 = Class426.smethod_57(this.String_2);
			}
			return this.string_3;
		}
	}

	// Token: 0x1700095F RID: 2399
	// (get) Token: 0x0600290E RID: 10510 RVA: 0x0001E256 File Offset: 0x0001C456
	// (set) Token: 0x0600290F RID: 10511 RVA: 0x0001E25E File Offset: 0x0001C45E
	public uint UInt32_8 { get; set; }

	// Token: 0x17000960 RID: 2400
	// (get) Token: 0x06002910 RID: 10512 RVA: 0x0001E267 File Offset: 0x0001C467
	// (set) Token: 0x06002911 RID: 10513 RVA: 0x0001E26F File Offset: 0x0001C46F
	public string String_4 { get; set; }

	// Token: 0x17000961 RID: 2401
	// (get) Token: 0x06002912 RID: 10514 RVA: 0x0001E278 File Offset: 0x0001C478
	// (set) Token: 0x06002913 RID: 10515 RVA: 0x0001E280 File Offset: 0x0001C480
	public uint UInt32_9 { get; set; }

	// Token: 0x17000962 RID: 2402
	// (get) Token: 0x06002914 RID: 10516 RVA: 0x0001E289 File Offset: 0x0001C489
	// (set) Token: 0x06002915 RID: 10517 RVA: 0x0001E291 File Offset: 0x0001C491
	public uint UInt32_10 { get; set; }

	// Token: 0x17000963 RID: 2403
	// (get) Token: 0x06002916 RID: 10518 RVA: 0x0001E29A File Offset: 0x0001C49A
	// (set) Token: 0x06002917 RID: 10519 RVA: 0x0001E2A2 File Offset: 0x0001C4A2
	public string String_5 { get; set; }

	// Token: 0x17000964 RID: 2404
	// (get) Token: 0x06002918 RID: 10520 RVA: 0x0001E2AB File Offset: 0x0001C4AB
	// (set) Token: 0x06002919 RID: 10521 RVA: 0x0001E2B3 File Offset: 0x0001C4B3
	public uint UInt32_11 { get; set; }

	// Token: 0x17000965 RID: 2405
	// (get) Token: 0x0600291A RID: 10522 RVA: 0x0001E2BC File Offset: 0x0001C4BC
	// (set) Token: 0x0600291B RID: 10523 RVA: 0x0001E2C4 File Offset: 0x0001C4C4
	public uint UInt32_12 { get; set; }

	// Token: 0x17000966 RID: 2406
	// (get) Token: 0x0600291C RID: 10524 RVA: 0x0001E2CD File Offset: 0x0001C4CD
	public float Single_4
	{
		get
		{
			return Class426.smethod_48((double)this.Class159_0.Single_3, (double)this.Class159_0.Single_4, (double)this.Single_0, (double)this.Single_1);
		}
	}

	// Token: 0x17000967 RID: 2407
	// (get) Token: 0x0600291D RID: 10525 RVA: 0x0001E2FA File Offset: 0x0001C4FA
	// (set) Token: 0x0600291E RID: 10526 RVA: 0x0001E302 File Offset: 0x0001C502
	public float Single_5 { get; set; }

	// Token: 0x17000968 RID: 2408
	// (get) Token: 0x0600291F RID: 10527 RVA: 0x0001E30B File Offset: 0x0001C50B
	// (set) Token: 0x06002920 RID: 10528 RVA: 0x0001E32C File Offset: 0x0001C52C
	public int Int32_0
	{
		get
		{
			if (this.int_1 != -1)
			{
				return this.int_1;
			}
			return (int)Math.Round((double)this.Single_0, 0, MidpointRounding.AwayFromZero);
		}
		set
		{
			this.int_1 = value;
		}
	}

	// Token: 0x17000969 RID: 2409
	// (get) Token: 0x06002921 RID: 10529 RVA: 0x0001E335 File Offset: 0x0001C535
	// (set) Token: 0x06002922 RID: 10530 RVA: 0x0001E356 File Offset: 0x0001C556
	public int Int32_1
	{
		get
		{
			if (this.int_0 != -1)
			{
				return this.int_0;
			}
			return (int)Math.Round((double)this.Single_1, 0, MidpointRounding.AwayFromZero);
		}
		set
		{
			this.int_0 = value;
		}
	}

	// Token: 0x1700096A RID: 2410
	// (get) Token: 0x06002923 RID: 10531 RVA: 0x0011AAC8 File Offset: 0x00118CC8
	public string String_6
	{
		get
		{
			return this.Int32_0.ToString() + "," + this.Int32_1.ToString();
		}
	}

	// Token: 0x1700096B RID: 2411
	// (get) Token: 0x06002924 RID: 10532 RVA: 0x0011AAFC File Offset: 0x00118CFC
	public bool Boolean_0
	{
		get
		{
			if (Main.setting_0.checkSkipMonter.Checked && Class415.hashSet_1.Contains(this.String_2))
			{
				return false;
			}
			if (!Class268.Boolean_69 && (ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_3))
			{
				if (!Class268.Boolean_9)
				{
					return false;
				}
				if (Class426.smethod_48((double)this.Int32_0, (double)this.Int32_1, (double)Class268.Int32_2, (double)Class268.Int32_3) > 20f)
				{
					return false;
				}
			}
			return this.UInt32_3 == this.Class159_0.Class392_0.UInt32_44;
		}
	}

	// Token: 0x1700096C RID: 2412
	// (get) Token: 0x06002925 RID: 10533 RVA: 0x0011AB9C File Offset: 0x00118D9C
	public bool Boolean_1
	{
		get
		{
			return (!Main.setting_0.checkSkipMonter.Checked || !Class415.hashSet_1.Contains(this.String_2)) && this.UInt32_3 == this.Class159_0.Class392_0.UInt32_44;
		}
	}

	// Token: 0x1700096D RID: 2413
	// (get) Token: 0x06002926 RID: 10534 RVA: 0x0001E35F File Offset: 0x0001C55F
	public bool Boolean_2
	{
		get
		{
			return !Class415.hashSet_1.Contains(this.String_2) && this.Boolean_1 && (Class426.smethod_28(this.String_2) != -1 || Class159.Boolean_2);
		}
	}

	// Token: 0x1700096E RID: 2414
	// (get) Token: 0x06002927 RID: 10535 RVA: 0x0001E397 File Offset: 0x0001C597
	public string String_7
	{
		get
		{
			return Class426.Class430.smethod_3(this.String_2).Substring(0, 3);
		}
	}

	// Token: 0x1700096F RID: 2415
	// (get) Token: 0x06002928 RID: 10536 RVA: 0x0001E3AB File Offset: 0x0001C5AB
	public bool Boolean_3
	{
		get
		{
			return !Class415.hashSet_1.Contains(this.String_2) && this.Boolean_1 && (Class426.smethod_29(this.String_2) != -1 || Class159.Boolean_2);
		}
	}

	// Token: 0x17000970 RID: 2416
	// (get) Token: 0x06002929 RID: 10537 RVA: 0x0001E3E3 File Offset: 0x0001C5E3
	public bool Boolean_4
	{
		get
		{
			return this.UInt32_1 == this.Class159_0.UInt32_4;
		}
	}

	// Token: 0x17000971 RID: 2417
	// (get) Token: 0x0600292A RID: 10538 RVA: 0x0001E3FB File Offset: 0x0001C5FB
	public bool Boolean_5
	{
		get
		{
			return this.UInt32_3 == this.Class159_0.Class392_0.UInt32_99;
		}
	}

	// Token: 0x0600292B RID: 10539 RVA: 0x0011ABEC File Offset: 0x00118DEC
	public bool method_0()
	{
		if (this.Single_2 <= 0f)
		{
			return false;
		}
		if (Class363.hashSet_8.Contains(this.String_2))
		{
			return false;
		}
		if (this.Class159_0.Single_1 > 0f && this.Class159_0.Class432_0.UInt32_29 == this.Class159_0.UInt32_6)
		{
			int num = Class268.int_23;
			if (this.Class159_0.Class432_0.Boolean_28)
			{
				num = Class268.int_22;
			}
			if (this.method_3(this.Class159_0.Single_1, this.Class159_0.Single_2) > (float)num)
			{
				return false;
			}
		}
		if (((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_49) || (ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_95)) && this.Single_4 > 20f)
		{
			return false;
		}
		if (this.Class159_0.List_0.Contains(Enum14.TrangSucCuuLe) && this.String_2 != "Cửu Lê Chiến Sĩ")
		{
			return false;
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_104))
		{
			if (this.Class159_0.Int32_13 > 210)
			{
				return false;
			}
			if (Setting.smethod_0("checkNeBinh") && this.String_2 == "Huyết chú vu cổ")
			{
				return false;
			}
			if ((this.String_2 == "Tinh Túc Đệ Tử" || this.String_2 == "Tinh túc môn đồ") && this.Single_4 > 12f)
			{
				return false;
			}
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_98) && this.String_2 == "Tinh La Võ Sĩ")
		{
			return true;
		}
		if (this.Class159_0.Int32_6 != 0)
		{
			return false;
		}
		if (Main.setting_0.checkSkipMonter.Checked && Class415.hashSet_1.Contains(this.String_2))
		{
			return false;
		}
		if (this.String_5.Contains("#{PTFB"))
		{
			if (this.UInt32_4 != 2U)
			{
				if (this.UInt32_4 != 7U)
				{
					if (this.UInt32_4 == 0U)
					{
						return false;
					}
					goto IL_20E;
				}
			}
			return true;
		}
		IL_20E:
		if (this.Class159_0.List_0.Contains(Enum14.DatDoiBinhThanh) && new List<string>
		{
			"Trúc Đồng Tâm-Trắng",
			"Trúc Đồng Tâm-Lục",
			"Trúc Đồng Tâm-Tím",
			"Trúc Đồng Tâm-Vàng",
			"Trúc Đồng Tâm-Đỏ",
			"Trúc Đồng Tâm-Lam",
			"Phong Lôi Đàn"
		}.Contains(this.String_2))
		{
			return false;
		}
		if (this.Class159_0.Class432_0.UInt32_2 < 10U && this.String_5.Trim() != "" && this.Class159_0.Class392_0.UInt32_106 == 1U)
		{
			return false;
		}
		Class159 class159_ = this.Class159_0.Class159_2;
		if (class159_ != null && class159_.List_0.Contains(Enum14.DatDoiBaoDoHiem) && this.String_2 != "Đoạt Bảo Mã Tặc Đầu Lĩnh")
		{
			return false;
		}
		if (this.UInt32_8 == 4294967295U)
		{
			return false;
		}
		if (class159_ != null && class159_.List_0.Contains(Enum14.DatDoiMaTac) && this.String_2 != "Đoạt Bảo Mã Tặc")
		{
			return false;
		}
		if (class159_ != null && class159_.List_0.Contains(Enum14.DatDoiBossMap) && !Class415.HashSet_1.Contains(this.String_2))
		{
			return false;
		}
		if (this.String_2 == "Rương bảo vật")
		{
			return false;
		}
		if (this.String_2 == "Tình Báo Thám Tử" || this.String_2 == "Mật Tín Thám Tử")
		{
			return false;
		}
		if (this.String_2 == "Tuần La Sĩ Binh" || this.String_2.Contains(" Môn "))
		{
			return true;
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_146) && this.String_2.Contains(" "))
		{
			return true;
		}
		if (this.Class159_0.Class432_0.UInt32_29 <= 2U)
		{
			return false;
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_41) && !this.Class159_0.bool_107 && Class426.smethod_57(this.String_2) == "nguytongquandothong")
		{
			return false;
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_42) && !this.Class159_0.bool_107 && Class426.smethod_57(this.String_2) == "honghungvuong")
		{
			return false;
		}
		if (this.Class159_0.List_0.Contains(Enum14.NhiemVuSuMon) && this.String_3 == "hodaothanthu")
		{
			return false;
		}
		if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_110))
		{
			if (this.UInt32_8 == 16U)
			{
				return false;
			}
			if (this.UInt32_8 == 12U)
			{
				return false;
			}
			if (this.UInt32_8 == 53U)
			{
				return false;
			}
			if (this.UInt32_8 == 54U)
			{
				return false;
			}
			if (this.UInt32_8 > 37U)
			{
				return true;
			}
		}
		if (this.Single_2 > 0f)
		{
			uint uint32_ = this.UInt32_8;
			if (this.UInt32_8 >= 16U && this.UInt32_8 != 32U && this.UInt32_8 != 21U && this.UInt32_8 != 22U && this.UInt32_8 != 19U && this.UInt32_8 != 37U && this.UInt32_8 <= 40U)
			{
				if ((ulong)this.Class159_0.Class432_0.UInt32_29 == (ulong)((long)Class365.Int32_101))
				{
					if (this.String_2.Contains("Tháp"))
					{
						return false;
					}
					if (this.String_2.Contains("Tower"))
					{
						return false;
					}
				}
				return !Class426.smethod_57(this.String_2).Contains("tieulang") && (!this.String_2.Contains("Niên Thú") || this.Class159_0.Class432_0.UInt32_29 == 547U) && !Main.Boolean_17 && (!this.Class159_0.Boolean_72 || Class415.hashSet_2.Contains(this.String_2));
			}
		}
		return false;
	}

	// Token: 0x17000972 RID: 2418
	// (get) Token: 0x0600292C RID: 10540 RVA: 0x0001E415 File Offset: 0x0001C615
	// (set) Token: 0x0600292D RID: 10541 RVA: 0x0001E41D File Offset: 0x0001C61D
	public bool Boolean_6 { get; set; }

	// Token: 0x17000973 RID: 2419
	// (get) Token: 0x0600292E RID: 10542 RVA: 0x0011B214 File Offset: 0x00119414
	public bool Boolean_7
	{
		get
		{
			if (this.UInt32_8 >= 1U && this.UInt32_8 <= 9U)
			{
				return true;
			}
			if (this.UInt32_8 != 32U && this.UInt32_8 != 37U && this.UInt32_8 != 53U)
			{
				if (this.UInt32_8 != 54U)
				{
					return false;
				}
			}
			return true;
		}
	}

	// Token: 0x17000974 RID: 2420
	// (get) Token: 0x0600292F RID: 10543 RVA: 0x0001E426 File Offset: 0x0001C626
	public bool Boolean_8
	{
		get
		{
			return this.String_4 == "40600000" && this.String_0.Contains("FFFFFFFF") && this.UInt32_8 == uint.MaxValue;
		}
	}

	// Token: 0x17000975 RID: 2421
	// (get) Token: 0x06002930 RID: 10544 RVA: 0x0011B264 File Offset: 0x00119464
	public bool Boolean_9
	{
		get
		{
			return this.String_4 == "3FE66666" || this.String_4 == "3F4CCCCD" || this.String_2 == "Trương Sĩ Tâm" || this.String_2.Trim() == "Khô Vinh Đại Sư";
		}
	}

	// Token: 0x17000976 RID: 2422
	// (get) Token: 0x06002931 RID: 10545 RVA: 0x0001E458 File Offset: 0x0001C658
	// (set) Token: 0x06002932 RID: 10546 RVA: 0x0001E460 File Offset: 0x0001C660
	public int Int32_2 { get; set; }

	// Token: 0x17000977 RID: 2423
	// (get) Token: 0x06002933 RID: 10547 RVA: 0x0001E469 File Offset: 0x0001C669
	// (set) Token: 0x06002934 RID: 10548 RVA: 0x0001E471 File Offset: 0x0001C671
	public string String_8 { get; set; }

	// Token: 0x17000978 RID: 2424
	// (get) Token: 0x06002935 RID: 10549 RVA: 0x0001E47A File Offset: 0x0001C67A
	public HashSet<uint> HashSet_0
	{
		get
		{
			return this.method_4(this.Class405_0.method_11(this.UInt32_2 + this.Class159_0.Class392_0.UInt32_30));
		}
	}

	// Token: 0x17000979 RID: 2425
	// (get) Token: 0x06002936 RID: 10550 RVA: 0x0001E4A4 File Offset: 0x0001C6A4
	// (set) Token: 0x06002937 RID: 10551 RVA: 0x0001E4AC File Offset: 0x0001C6AC
	public bool Boolean_10 { get; set; }

	// Token: 0x1700097A RID: 2426
	// (get) Token: 0x06002938 RID: 10552 RVA: 0x0001E4B5 File Offset: 0x0001C6B5
	// (set) Token: 0x06002939 RID: 10553 RVA: 0x0001E4BD File Offset: 0x0001C6BD
	public Stopwatch Stopwatch_0 { get; set; } = Stopwatch.StartNew();

	// Token: 0x1700097B RID: 2427
	// (get) Token: 0x0600293A RID: 10554 RVA: 0x0001E4C6 File Offset: 0x0001C6C6
	// (set) Token: 0x0600293B RID: 10555 RVA: 0x0001E4CE File Offset: 0x0001C6CE
	private uint UInt32_13 { get; set; }

	// Token: 0x0600293C RID: 10556 RVA: 0x0011B2C4 File Offset: 0x001194C4
	public Class393(Class159 class159_1, uint uint_14)
	{
		this.Class159_0 = class159_1;
		this.Class405_0 = class159_1.Class405_0;
		this.Class392_0 = class159_1.Class392_0;
		this.UInt32_13 = uint_14;
		this.UInt32_1 = this.Class405_0.method_11(uint_14 + this.Class392_0.UInt32_70);
	}

	// Token: 0x1700097C RID: 2428
	// (get) Token: 0x0600293D RID: 10557 RVA: 0x0001E4D7 File Offset: 0x0001C6D7
	public bool Boolean_11
	{
		get
		{
			return !string.IsNullOrEmpty(this.String_2) && (this.UInt32_4 == 5U && Class415.String_0.Contains(this.String_2));
		}
	}

	// Token: 0x0600293E RID: 10558 RVA: 0x0011B334 File Offset: 0x00119534
	public Class393 method_1()
	{
		uint uint32_ = this.UInt32_13;
		Class159 @class = this.Class159_0;
		this.UInt32_0 = uint32_;
		this.UInt32_7 = @class.Class405_0.method_18(uint32_ + this.Class392_0.UInt32_71, this.Class392_0.UInt32_74);
		this.UInt32_2 = this.Class405_0.method_11(uint32_ + this.Class392_0.UInt32_71);
		this.UInt32_3 = this.Class405_0.method_11(this.UInt32_2);
		if (this.Class392_0.UInt32_106 == 1U)
		{
			if (!this.Boolean_1 && this.UInt32_3 != 9655616U && this.UInt32_3 != 9655664U && this.UInt32_3 != 9516368U && this.UInt32_3 != this.Class392_0.UInt32_99 && this.UInt32_3 != this.Class159_0.UInt32_3 + 8560284U && this.UInt32_3 != this.Class159_0.UInt32_3 + 7688868U)
			{
				if (this.UInt32_3 != this.Class159_0.UInt32_3 + 7688884U)
				{
					this.Single_0 = this.Class405_0.method_22(this.UInt32_2 + this.Class392_0.UInt32_72);
					this.Single_1 = this.Class405_0.method_22(this.UInt32_2 + this.Class392_0.UInt32_73);
					goto IL_1E6;
				}
			}
			this.Single_0 = this.Class405_0.method_22(this.UInt32_2 + 44U);
			this.Single_1 = this.Class405_0.method_22(this.UInt32_2 + 52U);
		}
		else
		{
			this.Single_0 = this.Class405_0.method_22(this.UInt32_2 + this.Class392_0.UInt32_72);
			this.Single_1 = this.Class405_0.method_22(this.UInt32_2 + this.Class392_0.UInt32_73);
		}
		IL_1E6:
		uint uint32_2 = this.UInt32_1;
		if ((int)this.Single_0 > 0 && (int)this.Single_1 > 0)
		{
			if (this.Class392_0.UInt32_106 == 1U)
			{
				this.UInt32_4 = this.Class405_0.method_11(this.UInt32_2 + 424U);
			}
			else
			{
				this.UInt32_4 = this.Class405_0.method_11(this.UInt32_2 + 344U);
			}
			this.UInt32_5 = this.Class405_0.method_11(this.UInt32_2 + this.Class392_0.UInt32_31);
			this.UInt32_6 = this.Class405_0.method_11(this.UInt32_2 + this.Class392_0.UInt32_32);
			byte[] array = new byte[this.Class392_0.UInt32_84 + 4U];
			Class405.ReadProcessMemory_1(@class.Class405_0.IntPtr_0, this.UInt32_7, array, array.Length, 0);
			this.Single_2 = BitConverter.ToSingle(array, (int)this.Class392_0.UInt32_75);
			this.Single_3 = BitConverter.ToSingle(array, (int)this.Class392_0.UInt32_76);
			if (this.Class392_0.UInt32_106 == 1U)
			{
				this.String_0 = BitConverter.ToInt64(array, (int)this.Class392_0.UInt32_77).ToString("X8");
			}
			else
			{
				this.String_0 = BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_77).ToString("X8");
			}
			if (this.Class392_0.UInt32_106 == 1U)
			{
				this.String_1 = BitConverter.ToInt64(array, (int)this.Class392_0.UInt32_78).ToString("X8");
			}
			else
			{
				this.String_1 = BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_78).ToString("X8");
			}
			this.UInt32_8 = (uint)BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_81);
			this.String_4 = BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_82).ToString("X8");
			this.UInt32_9 = (uint)BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_83);
			this.UInt32_10 = (uint)BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_84);
			this.String_5 = this.Class405_0.method_32(this.UInt32_7 + this.Class392_0.UInt32_80, false).Trim();
			this.UInt32_11 = (uint)BitConverter.ToInt32(array, (int)this.Class392_0.UInt32_85);
			uint num = this.Class392_0.UInt32_33;
			if (this.UInt32_3 == 9655616U || this.UInt32_3 == 9655664U || this.UInt32_3 == 9516368U || @class.Class392_0.UInt32_106 == 1U || this.UInt32_3 == this.Class392_0.UInt32_99 || this.UInt32_3 == 9518440U)
			{
				num = 256U;
			}
			if (this.String_2 == null)
			{
				if (!this.Boolean_1 && this.UInt32_3 != 9655616U && this.UInt32_3 != 9655664U && this.UInt32_3 != 9516368U && this.UInt32_3 != this.Class392_0.UInt32_99 && this.UInt32_3 != this.Class159_0.UInt32_3 + 8560284U && this.UInt32_3 != this.Class159_0.UInt32_3 + 7688868U)
				{
					if (this.UInt32_3 != this.Class159_0.UInt32_3 + 7688884U)
					{
						this.String_2 = this.Class405_0.method_32(this.UInt32_7 + this.Class392_0.UInt32_79, false).Trim();
						if (string.IsNullOrEmpty(this.String_2.Trim()))
						{
							this.String_2 = this.Class405_0.method_32(this.UInt32_7 + this.Class392_0.UInt32_79, true).Trim();
							goto IL_63B;
						}
						goto IL_63B;
					}
				}
				if (this.UInt32_3 == this.Class159_0.UInt32_3 + 7688868U || this.UInt32_3 == this.Class159_0.UInt32_3 + 7688884U)
				{
					num = 260U;
					this.Boolean_10 = true;
				}
				Class405 class2 = @class.Class405_0;
				uint[] array2 = new uint[3];
				array2[0] = this.UInt32_2 + num;
				array2[1] = 4U;
				this.String_2 = class2.method_35(array2).Trim();
			}
			IL_63B:
			this.UInt32_12 = this.Class405_0.method_14(this.UInt32_7 + 11200U);
			this.Int32_2 = (int)this.Class405_0.method_11(this.UInt32_7 + this.Class392_0.UInt32_9);
			this.String_8 = this.Class405_0.method_26(this.UInt32_7 + this.Class392_0.UInt32_17);
			if (this.String_2.Contains("Công Tôn Thắng") || this.String_2 == "Định Hải Thần Châm phòng thủ" || this.String_2 == "Tru Tiên Trận Phòng" || this.String_2 == "Đào Hoa Trận Phòng" || this.String_2 == "Bát Trận Đồ Phòng" || this.String_2 == "Bộ Bộ Sinh Hoa")
			{
				this.Boolean_10 = false;
			}
			if (Class363.hashSet_7.Contains(this.String_2) || this.String_2.Contains("Thập Bộ Nhất Sát"))
			{
				this.Boolean_10 = true;
			}
			this.Boolean_6 = this.method_0();
		}
		return this;
	}

	// Token: 0x0600293F RID: 10559 RVA: 0x0011BA8C File Offset: 0x00119C8C
	public float method_2(string string_7)
	{
		float num = 0f;
		float num2 = 0f;
		if (string_7.Split(new char[]
		{
			','
		}).Length >= 2)
		{
			num = (float)Class426.smethod_43(string_7.Split(new char[]
			{
				','
			})[0]);
			num2 = (float)Class426.smethod_43(string_7.Split(new char[]
			{
				','
			})[1]);
		}
		return (float)Math.Sqrt(Math.Pow((double)(num - this.Single_0), 2.0) + Math.Pow((double)(num2 - this.Single_1), 2.0));
	}

	// Token: 0x06002940 RID: 10560 RVA: 0x0001E506 File Offset: 0x0001C706
	public float method_3(float float_5, float float_6)
	{
		return (float)Math.Sqrt(Math.Pow((double)(float_5 - this.Single_0), 2.0) + Math.Pow((double)(float_6 - this.Single_1), 2.0));
	}

	// Token: 0x06002941 RID: 10561 RVA: 0x0011BB24 File Offset: 0x00119D24
	public HashSet<uint> method_4(uint uint_14)
	{
		HashSet<uint> hashSet = new HashSet<uint>();
		this.method_5(uint_14, hashSet);
		hashSet.Remove(uint_14);
		return hashSet;
	}

	// Token: 0x1700097D RID: 2429
	// (get) Token: 0x06002942 RID: 10562 RVA: 0x0001E53D File Offset: 0x0001C73D
	public bool Boolean_12
	{
		get
		{
			return Class393.hashSet_0.Contains((int)this.UInt32_1);
		}
	}

	// Token: 0x1700097E RID: 2430
	// (get) Token: 0x06002943 RID: 10563 RVA: 0x0011BB48 File Offset: 0x00119D48
	public double Double_0
	{
		get
		{
			string key = this.Int32_0.ToString() + "," + this.Int32_1.ToString();
			if (!Class393.dictionary_0.ContainsKey(key))
			{
				Class393.dictionary_0.Add(key, Class426.Int32_0);
			}
			return (double)Class393.dictionary_0[key];
		}
	}

	// Token: 0x1700097F RID: 2431
	// (get) Token: 0x06002944 RID: 10564 RVA: 0x0011BBA8 File Offset: 0x00119DA8
	public int Int32_3
	{
		get
		{
			string key = this.Int32_0.ToString() + "," + this.Int32_1.ToString();
			if (!Class393.dictionary_0.ContainsKey(key))
			{
				return 0;
			}
			return Class426.Int32_0 - Class393.dictionary_0[key];
		}
	}

	// Token: 0x06002945 RID: 10565 RVA: 0x0011BBFC File Offset: 0x00119DFC
	private void method_5(uint uint_14, HashSet<uint> hashSet_1)
	{
		if (uint_14 <= 0U)
		{
			return;
		}
		if (hashSet_1.Count > 200)
		{
			return;
		}
		if (!hashSet_1.Contains(uint_14))
		{
			hashSet_1.Add(uint_14);
			this.method_5(this.Class159_0.Class405_0.method_11(uint_14), hashSet_1);
			this.method_5(this.Class159_0.Class405_0.method_11(uint_14 + 4U), hashSet_1);
			this.method_5(this.Class159_0.Class405_0.method_11(uint_14 + 8U), hashSet_1);
		}
	}

	// Token: 0x04001B81 RID: 7041
	[CompilerGenerated]
	private Class159 class159_0;

	// Token: 0x04001B82 RID: 7042
	[CompilerGenerated]
	private Class405 class405_0;

	// Token: 0x04001B83 RID: 7043
	[CompilerGenerated]
	private Class392 class392_0;

	// Token: 0x04001B84 RID: 7044
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001B85 RID: 7045
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001B86 RID: 7046
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04001B87 RID: 7047
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04001B88 RID: 7048
	[CompilerGenerated]
	private float float_0;

	// Token: 0x04001B89 RID: 7049
	[CompilerGenerated]
	private float float_1;

	// Token: 0x04001B8A RID: 7050
	public List<uint> list_0;

	// Token: 0x04001B8B RID: 7051
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04001B8C RID: 7052
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04001B8D RID: 7053
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04001B8E RID: 7054
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04001B8F RID: 7055
	[CompilerGenerated]
	private float float_2;

	// Token: 0x04001B90 RID: 7056
	[CompilerGenerated]
	private float float_3;

	// Token: 0x04001B91 RID: 7057
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001B92 RID: 7058
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001B93 RID: 7059
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04001B94 RID: 7060
	[CompilerGenerated]
	private byte[] byte_0;

	// Token: 0x04001B95 RID: 7061
	private string string_3;

	// Token: 0x04001B96 RID: 7062
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04001B97 RID: 7063
	[CompilerGenerated]
	private string string_4;

	// Token: 0x04001B98 RID: 7064
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x04001B99 RID: 7065
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x04001B9A RID: 7066
	[CompilerGenerated]
	private string string_5;

	// Token: 0x04001B9B RID: 7067
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x04001B9C RID: 7068
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x04001B9D RID: 7069
	[CompilerGenerated]
	private float float_4;

	// Token: 0x04001B9E RID: 7070
	private int int_0 = -1;

	// Token: 0x04001B9F RID: 7071
	private int int_1 = -1;

	// Token: 0x04001BA0 RID: 7072
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04001BA1 RID: 7073
	[CompilerGenerated]
	private int int_2;

	// Token: 0x04001BA2 RID: 7074
	[CompilerGenerated]
	private string string_6;

	// Token: 0x04001BA3 RID: 7075
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x04001BA4 RID: 7076
	[CompilerGenerated]
	private Stopwatch stopwatch_0;

	// Token: 0x04001BA5 RID: 7077
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x04001BA6 RID: 7078
	public static Dictionary<string, int> dictionary_0 = new Dictionary<string, int>();

	// Token: 0x04001BA7 RID: 7079
	public static HashSet<int> hashSet_0 = new HashSet<int>();
}
