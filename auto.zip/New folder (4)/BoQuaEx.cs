﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020001D4 RID: 468
internal partial class BoQuaEx : Form
{
	// Token: 0x0600193F RID: 6463 RVA: 0x000125EA File Offset: 0x000107EA
	public BoQuaEx()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001940 RID: 6464 RVA: 0x000125F8 File Offset: 0x000107F8
	private void BoQuaEx_Load(object sender, EventArgs e)
	{
		base.Icon = GClass130.Icon_1;
		this.txtBoQua.Text = Class415.String_5;
	}

	// Token: 0x06001941 RID: 6465 RVA: 0x00002E18 File Offset: 0x00001018
	private void txtBoQua_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001942 RID: 6466 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0(object sender, EventArgs e)
	{
	}

	// Token: 0x06001943 RID: 6467 RVA: 0x000B5010 File Offset: 0x000B3210
	private void BoQuaEx_FormClosing(object sender, FormClosingEventArgs e)
	{
		BoQuaEx.Class213 @class = new BoQuaEx.Class213();
		Class415.String_5 = this.txtBoQua.Text;
		@class.string_0 = "";
		foreach (string text in Class415.String_5.Split(new char[]
		{
			'\n'
		}))
		{
			if (text.Trim().Length >= 3)
			{
				@class.string_0 = @class.string_0 + text.Trim() + "#";
			}
		}
		if (@class.string_0.Length > 3)
		{
			Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(@class.method_0));
			return;
		}
		Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(@class.method_1));
	}

	// Token: 0x06001944 RID: 6468 RVA: 0x00012615 File Offset: 0x00010815
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000EC9 RID: 3785
	private IContainer icontainer_0;

	// Token: 0x020001D5 RID: 469
	[CompilerGenerated]
	private sealed class Class213
	{
		// Token: 0x06001947 RID: 6471 RVA: 0x000B5260 File Offset: 0x000B3460
		internal void method_0(KeyValuePair<int, Class159> keyValuePair_0)
		{
			int int_ = keyValuePair_0.Value.Class405_0.method_46(this.string_0);
			keyValuePair_0.Value.method_57(1, 988);
			keyValuePair_0.Value.method_57(int_, 987);
		}

		// Token: 0x06001948 RID: 6472 RVA: 0x000B52AC File Offset: 0x000B34AC
		internal void method_1(KeyValuePair<int, Class159> keyValuePair_0)
		{
			int int_ = keyValuePair_0.Value.Class405_0.method_46(this.string_0);
			keyValuePair_0.Value.method_57(0, 988);
			keyValuePair_0.Value.method_57(int_, 987);
		}

		// Token: 0x04000ECB RID: 3787
		public string string_0;
	}
}
