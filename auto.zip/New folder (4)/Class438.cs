﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

// Token: 0x02000316 RID: 790
internal class Class438
{
	// Token: 0x06002DC0 RID: 11712
	[DllImport("user32.dll", SetLastError = true)]
	public static extern bool SetWindowPos(IntPtr intptr_0, IntPtr intptr_1, int int_2, int int_3, int int_4, int int_5, int int_6);

	// Token: 0x06002DC1 RID: 11713
	[DllImport("user32.dll", EntryPoint = "SetWindowPos", SetLastError = true)]
	public static extern bool SetWindowPos_1(IntPtr intptr_0, IntPtr intptr_1, int int_2, int int_3, int int_4, int int_5, long long_0);

	// Token: 0x06002DC2 RID: 11714 RVA: 0x000215E9 File Offset: 0x0001F7E9
	public static void smethod_0(IntPtr intptr_0)
	{
		if (Class438.IsWindowVisible(intptr_0))
		{
			Class438.ShowWindow_1(intptr_0, Class438.Enum23.ShowMinNoActivate);
			Class438.ShowWindow_1(intptr_0, Class438.Enum23.Hide);
		}
	}

	// Token: 0x06002DC3 RID: 11715 RVA: 0x00133FF4 File Offset: 0x001321F4
	public static void smethod_1(IntPtr intptr_0)
	{
		Class438.SetWindowLong(intptr_0, -16, 8388608);
		Class438.smethod_11(intptr_0);
	}

	// Token: 0x06002DC4 RID: 11716 RVA: 0x00134018 File Offset: 0x00132218
	public static void smethod_2(IntPtr intptr_0, bool bool_0)
	{
		int windowLong = Class438.GetWindowLong(intptr_0, -16);
		if (!bool_0)
		{
			Class438.SetWindowLong(intptr_0, -16, (int)((long)windowLong & (long)((ulong)-12582913) & (long)((ulong)-65537) & (long)((ulong)-131073) & (long)((ulong)-524289) & (long)((ulong)-262145)));
		}
		else
		{
			Class438.SetWindowLong(intptr_0, -16, (int)((long)windowLong | 12582912L | 65536L | 131072L | 524288L | 262144L));
		}
		Class438.SetWindowPos(intptr_0, Class438.Class440.intptr_1, 0, 0, 0, 0, Class438.Class439.int_12 | Class438.Class439.int_7);
	}

	// Token: 0x06002DC5 RID: 11717 RVA: 0x00021603 File Offset: 0x0001F803
	public static void smethod_3(IntPtr intptr_0, Class438.Struct10 struct10_0)
	{
		Class438.smethod_7(intptr_0);
	}

	// Token: 0x17000AA1 RID: 2721
	// (get) Token: 0x06002DC6 RID: 11718 RVA: 0x0002160B File Offset: 0x0001F80B
	public static IEnumerable<IntPtr> IEnumerable_0
	{
		get
		{
			return new Class438.Class442(-2);
		}
	}

	// Token: 0x17000AA2 RID: 2722
	// (get) Token: 0x06002DC7 RID: 11719 RVA: 0x00021614 File Offset: 0x0001F814
	// (set) Token: 0x06002DC8 RID: 11720 RVA: 0x0002161B File Offset: 0x0001F81B
	public static List<IntPtr> List_0 { get; set; } = new List<IntPtr>();

	// Token: 0x06002DC9 RID: 11721 RVA: 0x001340AC File Offset: 0x001322AC
	public static IntPtr smethod_4(int int_2, string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder(100);
		foreach (IntPtr intPtr in Class438.IEnumerable_0)
		{
			Class438.GetClassName(intPtr, stringBuilder, 100);
			if (stringBuilder.ToString().IndexOf(string_0) != -1 || (stringBuilder.ToString().Length == 15 && string_0.Length == 15))
			{
				int num;
				Class438.GetWindowThreadProcessId(intPtr, out num);
				if (num == int_2)
				{
					return intPtr;
				}
			}
		}
		return IntPtr.Zero;
	}

	// Token: 0x06002DCA RID: 11722 RVA: 0x00134148 File Offset: 0x00132348
	public static IntPtr smethod_5(string string_0, string string_1)
	{
		IntPtr window = Class438.GetWindow(Class438.GetForegroundWindow(), Class438.Enum24.GW_HWNDFIRST);
		StringBuilder stringBuilder = new StringBuilder(100);
		StringBuilder stringBuilder2 = new StringBuilder(100);
		while (window != IntPtr.Zero)
		{
			Class438.GetClassName(window, stringBuilder, 100);
			Class438.GetWindowText(window, stringBuilder2, 100);
			if (stringBuilder.ToString().IndexOf(string_0) != -1 && stringBuilder2.ToString().IndexOf(string_1) != -1)
			{
				return window;
			}
			window = Class438.GetWindow(window, Class438.Enum24.GW_HWNDNEXT);
		}
		return IntPtr.Zero;
	}

	// Token: 0x06002DCB RID: 11723 RVA: 0x00021623 File Offset: 0x0001F823
	public static void smethod_6(Form form_0)
	{
		form_0.Show();
		Class438.smethod_7(form_0.Handle);
		form_0.Activate();
		form_0.Refresh();
	}

	// Token: 0x06002DCC RID: 11724 RVA: 0x001341C4 File Offset: 0x001323C4
	public static void smethod_7(IntPtr intptr_0)
	{
		Class438.Struct10 @struct;
		Class438.GetWindowRect(intptr_0, out @struct);
		bool flag = @struct.int_0 == -32000;
		if (!Class438.IsWindowVisible(intptr_0))
		{
			Class438.ShowWindow_1(intptr_0, Class438.Enum23.Show);
		}
		if (flag)
		{
			Class438.ShowWindow_1(intptr_0, Class438.Enum23.Restore);
		}
		if (Class438.GetForegroundWindow() != intptr_0)
		{
			Class438.SetForegroundWindow(intptr_0);
		}
	}

	// Token: 0x06002DCD RID: 11725 RVA: 0x00021642 File Offset: 0x0001F842
	public static bool smethod_8(IntPtr intptr_0)
	{
		return Class438.IsWindowVisible(intptr_0) || Class438.smethod_10(intptr_0);
	}

	// Token: 0x06002DCE RID: 11726 RVA: 0x00021654 File Offset: 0x0001F854
	public static bool smethod_9(IntPtr intptr_0)
	{
		return !Class438.smethod_10(intptr_0) && Class438.IsWindowVisible(intptr_0);
	}

	// Token: 0x06002DCF RID: 11727 RVA: 0x00134218 File Offset: 0x00132418
	public static bool smethod_10(IntPtr intptr_0)
	{
		Class438.Struct10 @struct;
		Class438.GetWindowRect(intptr_0, out @struct);
		return @struct.int_0 == -32000;
	}

	// Token: 0x06002DD0 RID: 11728 RVA: 0x00021666 File Offset: 0x0001F866
	public static void smethod_11(IntPtr intptr_0)
	{
		Class438.ShowWindow_1(intptr_0, Class438.Enum23.Hide);
	}

	// Token: 0x17000AA3 RID: 2723
	// (get) Token: 0x06002DD1 RID: 11729 RVA: 0x0013423C File Offset: 0x0013243C
	public static int Int32_0
	{
		get
		{
			return Screen.PrimaryScreen.Bounds.Width;
		}
	}

	// Token: 0x17000AA4 RID: 2724
	// (get) Token: 0x06002DD2 RID: 11730 RVA: 0x0013425C File Offset: 0x0013245C
	public static int Int32_1
	{
		get
		{
			return Screen.PrimaryScreen.Bounds.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom);
		}
	}

	// Token: 0x06002DD3 RID: 11731 RVA: 0x00021670 File Offset: 0x0001F870
	public static void smethod_12(IntPtr intptr_0)
	{
		Class438.PostMessage(intptr_0, 16, 0, 0);
	}

	// Token: 0x06002DD4 RID: 11732 RVA: 0x001342A4 File Offset: 0x001324A4
	public static void smethod_13(Form form_0, Class438.Enum22 enum22_0, int int_2, int int_3)
	{
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		switch (enum22_0)
		{
		case Class438.Enum22.TopLeft:
			form_0.Location = new Point(0, 0);
			return;
		case Class438.Enum22.TopRight:
			form_0.Location = new Point(width - int_2, 0);
			return;
		case Class438.Enum22.BottomRight:
			form_0.Location = new Point(width - int_2, height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.BottomLeft:
			form_0.Location = new Point(0, height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.Center:
			form_0.Location = new Point((width - int_2) / 2, (height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		case Class438.Enum22.None:
			form_0.Location = new Point(-1000, -1000);
			return;
		case Class438.Enum22.TopCenter:
			form_0.Location = new Point((width - int_2) / 2, 0);
			return;
		case Class438.Enum22.RightCenter:
			form_0.Location = new Point(width - int_2, (height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		case Class438.Enum22.BottomCenter:
			form_0.Location = new Point((width - int_2) / 2, height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.LeftCenter:
			form_0.Location = new Point(0, (height - int_3 - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		default:
			return;
		}
	}

	// Token: 0x06002DD5 RID: 11733 RVA: 0x001344A4 File Offset: 0x001326A4
	public static void smethod_14(Form form_0, Class438.Enum22 enum22_0)
	{
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		switch (enum22_0)
		{
		case Class438.Enum22.TopLeft:
			form_0.Location = new Point(0, 0);
			return;
		case Class438.Enum22.TopRight:
			form_0.Location = new Point(width - form_0.Width, 0);
			return;
		case Class438.Enum22.BottomRight:
			form_0.Location = new Point(width - form_0.Width, height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.BottomLeft:
			form_0.Location = new Point(0, height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.Center:
			form_0.Location = new Point((width - form_0.Width) / 2, (height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		case Class438.Enum22.None:
			form_0.Location = new Point(-1000, -1000);
			return;
		case Class438.Enum22.TopCenter:
			form_0.Location = new Point((width - form_0.Width) / 2, 0);
			return;
		case Class438.Enum22.RightCenter:
			form_0.Location = new Point(width - form_0.Width, (height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		case Class438.Enum22.BottomCenter:
			form_0.Location = new Point((width - form_0.Width) / 2, height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom));
			return;
		case Class438.Enum22.LeftCenter:
			form_0.Location = new Point(0, (height - form_0.Height - (Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom)) / 2);
			return;
		default:
			return;
		}
	}

	// Token: 0x06002DD6 RID: 11734 RVA: 0x001346E0 File Offset: 0x001328E0
	public static void smethod_15(Form form_0)
	{
		if (form_0.WindowState == FormWindowState.Minimized)
		{
			Class438.SetWindowPos_2(form_0.Handle.ToInt32(), -1, form_0.Left, form_0.Top, form_0.Width, form_0.Height, 16U);
		}
		Class438.ShowWindow(form_0.Handle, 4);
	}

	// Token: 0x06002DD7 RID: 11735 RVA: 0x00134734 File Offset: 0x00132934
	public static void smethod_16(Class159 class159_0)
	{
		if (class159_0.Int32_3 == 0)
		{
			Class438.SetWindowPos(class159_0.IntPtr_0, IntPtr.Zero, 20, 20, 1030, 797, Class438.Class439.int_13 | 16);
		}
		else
		{
			Class438.SetWindowPos(class159_0.IntPtr_0, IntPtr.Zero, class159_0.Int32_3, class159_0.Int32_4, class159_0.Int32_1, class159_0.Int32_2, Class438.Class439.int_13 | 16);
		}
		Class438.ShowWindow(class159_0.IntPtr_0, 4);
	}

	// Token: 0x06002DD8 RID: 11736 RVA: 0x001347B0 File Offset: 0x001329B0
	public static void smethod_17(Class159 class159_0)
	{
		if (Class438.smethod_10(class159_0.IntPtr_0))
		{
			if (class159_0.Int32_3 == 0)
			{
				Class438.SetWindowPos(class159_0.IntPtr_0, IntPtr.Zero, 20, 20, 1030, 797, Class438.Class439.int_13 | 16);
			}
			else
			{
				Class438.SetWindowPos(class159_0.IntPtr_0, IntPtr.Zero, class159_0.Int32_3, class159_0.Int32_4, class159_0.Int32_1, class159_0.Int32_2, Class438.Class439.int_13 | 16);
			}
		}
		Class438.ShowWindow(class159_0.IntPtr_0, 4);
	}

	// Token: 0x06002DD9 RID: 11737
	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr intptr_0, int int_2);

	// Token: 0x06002DDA RID: 11738
	[DllImport("user32.dll", EntryPoint = "SetWindowPos")]
	private static extern bool SetWindowPos_2(int int_2, int int_3, int int_4, int int_5, int int_6, int int_7, uint uint_1);

	// Token: 0x06002DDB RID: 11739
	[DllImport("user32.dll", SetLastError = true)]
	public static extern IntPtr FindWindow(string string_0, string string_1);

	// Token: 0x06002DDC RID: 11740
	[DllImport("user32.dll")]
	public static extern IntPtr SetParent(IntPtr intptr_0, IntPtr intptr_1);

	// Token: 0x06002DDD RID: 11741
	[DllImport("user32.dll", EntryPoint = "ShowWindow")]
	public static extern bool ShowWindow_1(IntPtr intptr_0, Class438.Enum23 enum23_0);

	// Token: 0x06002DDE RID: 11742
	[DllImport("user32.dll")]
	public static extern bool PostMessage(IntPtr intptr_0, int int_2, int int_3, int int_4);

	// Token: 0x06002DDF RID: 11743
	[DllImport("user32.dll")]
	public static extern IntPtr SendMessage(IntPtr intptr_0, int int_2, int int_3, int int_4);

	// Token: 0x06002DE0 RID: 11744
	[DllImport("user32.dll")]
	private static extern bool BringWindowToTop(IntPtr intptr_0);

	// Token: 0x06002DE1 RID: 11745
	[DllImport("user32.dll")]
	public static extern bool IsWindowVisible(IntPtr intptr_0);

	// Token: 0x06002DE2 RID: 11746
	[DllImport("user32.dll")]
	public static extern bool GetWindowRect(IntPtr intptr_0, out Class438.Struct10 struct10_0);

	// Token: 0x06002DE3 RID: 11747
	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr GetWindow(IntPtr intptr_0, Class438.Enum24 enum24_0);

	// Token: 0x06002DE4 RID: 11748
	[DllImport("user32.dll")]
	public static extern int SetWindowText(IntPtr intptr_0, string string_0);

	// Token: 0x06002DE5 RID: 11749
	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr intptr_0, out int int_2);

	// Token: 0x06002DE6 RID: 11750
	[DllImport("user32.dll")]
	public static extern IntPtr GetForegroundWindow();

	// Token: 0x06002DE7 RID: 11751
	[DllImport("user32.dll")]
	private static extern int GetClassName(IntPtr intptr_0, StringBuilder stringBuilder_0, int int_2);

	// Token: 0x06002DE8 RID: 11752
	[DllImport("user32.dll")]
	private static extern int GetWindowText(IntPtr intptr_0, StringBuilder stringBuilder_0, int int_2);

	// Token: 0x06002DE9 RID: 11753
	[DllImport("user32.dll")]
	public static extern bool SetForegroundWindow(IntPtr intptr_0);

	// Token: 0x06002DEA RID: 11754
	[DllImport("user32.dll")]
	public static extern bool EnableWindow(IntPtr intptr_0, bool bool_0);

	// Token: 0x06002DEB RID: 11755
	[DllImport("user32.dll")]
	public static extern bool ShowWindowAsync(IntPtr intptr_0, Class438.Enum23 enum23_0);

	// Token: 0x06002DEC RID: 11756
	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, ExactSpelling = true, SetLastError = true)]
	public static extern void MoveWindow(IntPtr intptr_0, int int_2, int int_3, int int_4, int int_5, bool bool_0);

	// Token: 0x06002DED RID: 11757
	[DllImport("user32.dll")]
	public static extern int GetWindowLong(IntPtr intptr_0, int int_2);

	// Token: 0x06002DEE RID: 11758
	[DllImport("user32.dll")]
	public static extern int SetWindowLong(IntPtr intptr_0, int int_2, int int_3);

	// Token: 0x06002DEF RID: 11759
	[DllImport("user32.dll")]
	public static extern int RegisterWindowMessage(string string_0);

	// Token: 0x04001F05 RID: 7941
	[CompilerGenerated]
	private static List<IntPtr> list_0;

	// Token: 0x04001F06 RID: 7942
	private const int int_0 = 4;

	// Token: 0x04001F07 RID: 7943
	private const int int_1 = -1;

	// Token: 0x04001F08 RID: 7944
	private const uint uint_0 = 16U;

	// Token: 0x02000317 RID: 791
	public enum Enum21
	{
		// Token: 0x04001F0A RID: 7946
		HWND_TOP,
		// Token: 0x04001F0B RID: 7947
		HWND_BOTTOM,
		// Token: 0x04001F0C RID: 7948
		HWND_TOPMOST = -1,
		// Token: 0x04001F0D RID: 7949
		HWND_NOTOPMOST = -2
	}

	// Token: 0x02000318 RID: 792
	public class Class439
	{
		// Token: 0x04001F0E RID: 7950
		public static int int_0 = 16384;

		// Token: 0x04001F0F RID: 7951
		public static int int_1 = 8192;

		// Token: 0x04001F10 RID: 7952
		public static int int_2 = 32;

		// Token: 0x04001F11 RID: 7953
		public static int int_3 = 32;

		// Token: 0x04001F12 RID: 7954
		public static int int_4 = 128;

		// Token: 0x04001F13 RID: 7955
		public static int int_5 = 16;

		// Token: 0x04001F14 RID: 7956
		public static int int_6 = 256;

		// Token: 0x04001F15 RID: 7957
		public static int int_7 = 2;

		// Token: 0x04001F16 RID: 7958
		public static int int_8 = 512;

		// Token: 0x04001F17 RID: 7959
		public static int int_9 = 8;

		// Token: 0x04001F18 RID: 7960
		public static int int_10 = 512;

		// Token: 0x04001F19 RID: 7961
		public static int int_11 = 1024;

		// Token: 0x04001F1A RID: 7962
		public static int int_12 = 1;

		// Token: 0x04001F1B RID: 7963
		public static int int_13 = 4;

		// Token: 0x04001F1C RID: 7964
		public static int int_14 = 64;
	}

	// Token: 0x02000319 RID: 793
	public class Class440
	{
		// Token: 0x04001F1D RID: 7965
		public static IntPtr intptr_0 = (IntPtr)1;

		// Token: 0x04001F1E RID: 7966
		public static IntPtr intptr_1 = (IntPtr)(-2);

		// Token: 0x04001F1F RID: 7967
		public static IntPtr intptr_2 = (IntPtr)0;

		// Token: 0x04001F20 RID: 7968
		public static IntPtr intptr_3 = (IntPtr)(-1);
	}

	// Token: 0x0200031A RID: 794
	public static class Class441
	{
		// Token: 0x04001F21 RID: 7969
		public const uint uint_0 = 0U;

		// Token: 0x04001F22 RID: 7970
		public const uint uint_1 = 2147483648U;

		// Token: 0x04001F23 RID: 7971
		public const uint uint_2 = 1073741824U;

		// Token: 0x04001F24 RID: 7972
		public const uint uint_3 = 536870912U;

		// Token: 0x04001F25 RID: 7973
		public const uint uint_4 = 268435456U;

		// Token: 0x04001F26 RID: 7974
		public const uint uint_5 = 134217728U;

		// Token: 0x04001F27 RID: 7975
		public const uint uint_6 = 67108864U;

		// Token: 0x04001F28 RID: 7976
		public const uint uint_7 = 33554432U;

		// Token: 0x04001F29 RID: 7977
		public const uint uint_8 = 16777216U;

		// Token: 0x04001F2A RID: 7978
		public const uint uint_9 = 12582912U;

		// Token: 0x04001F2B RID: 7979
		public const int int_0 = 8388608;

		// Token: 0x04001F2C RID: 7980
		public const uint uint_10 = 4194304U;

		// Token: 0x04001F2D RID: 7981
		public const uint uint_11 = 2097152U;

		// Token: 0x04001F2E RID: 7982
		public const uint uint_12 = 1048576U;

		// Token: 0x04001F2F RID: 7983
		public const uint uint_13 = 524288U;

		// Token: 0x04001F30 RID: 7984
		public const uint uint_14 = 262144U;

		// Token: 0x04001F31 RID: 7985
		public const uint uint_15 = 131072U;

		// Token: 0x04001F32 RID: 7986
		public const uint uint_16 = 65536U;

		// Token: 0x04001F33 RID: 7987
		public const uint uint_17 = 131072U;

		// Token: 0x04001F34 RID: 7988
		public const uint uint_18 = 65536U;

		// Token: 0x04001F35 RID: 7989
		public const uint uint_19 = 0U;

		// Token: 0x04001F36 RID: 7990
		public const uint uint_20 = 536870912U;

		// Token: 0x04001F37 RID: 7991
		public const uint uint_21 = 262144U;

		// Token: 0x04001F38 RID: 7992
		public const uint uint_22 = 13565952U;

		// Token: 0x04001F39 RID: 7993
		public const uint uint_23 = 13565952U;

		// Token: 0x04001F3A RID: 7994
		public const uint uint_24 = 2156396544U;

		// Token: 0x04001F3B RID: 7995
		public const uint uint_25 = 1073741824U;

		// Token: 0x04001F3C RID: 7996
		public const uint uint_26 = 1U;

		// Token: 0x04001F3D RID: 7997
		public const uint uint_27 = 4U;

		// Token: 0x04001F3E RID: 7998
		public const uint uint_28 = 8U;

		// Token: 0x04001F3F RID: 7999
		public const uint uint_29 = 16U;

		// Token: 0x04001F40 RID: 8000
		public const uint uint_30 = 32U;

		// Token: 0x04001F41 RID: 8001
		public const uint uint_31 = 64U;

		// Token: 0x04001F42 RID: 8002
		public const uint uint_32 = 128U;

		// Token: 0x04001F43 RID: 8003
		public const uint uint_33 = 256U;

		// Token: 0x04001F44 RID: 8004
		public const uint uint_34 = 512U;

		// Token: 0x04001F45 RID: 8005
		public const uint uint_35 = 1024U;

		// Token: 0x04001F46 RID: 8006
		public const uint uint_36 = 4096U;

		// Token: 0x04001F47 RID: 8007
		public const uint uint_37 = 0U;

		// Token: 0x04001F48 RID: 8008
		public const uint uint_38 = 8192U;

		// Token: 0x04001F49 RID: 8009
		public const uint uint_39 = 0U;

		// Token: 0x04001F4A RID: 8010
		public const uint uint_40 = 16384U;

		// Token: 0x04001F4B RID: 8011
		public const uint uint_41 = 0U;

		// Token: 0x04001F4C RID: 8012
		public const uint uint_42 = 65536U;

		// Token: 0x04001F4D RID: 8013
		public const uint uint_43 = 131072U;

		// Token: 0x04001F4E RID: 8014
		public const uint uint_44 = 262144U;

		// Token: 0x04001F4F RID: 8015
		public const uint uint_45 = 768U;

		// Token: 0x04001F50 RID: 8016
		public const uint uint_46 = 392U;

		// Token: 0x04001F51 RID: 8017
		public const uint uint_47 = 524288U;

		// Token: 0x04001F52 RID: 8018
		public const uint uint_48 = 1048576U;

		// Token: 0x04001F53 RID: 8019
		public const uint uint_49 = 4194304U;

		// Token: 0x04001F54 RID: 8020
		public const uint uint_50 = 33554432U;

		// Token: 0x04001F55 RID: 8021
		public const uint uint_51 = 134217728U;
	}

	// Token: 0x0200031B RID: 795
	public enum Enum22 : byte
	{
		// Token: 0x04001F57 RID: 8023
		TopLeft,
		// Token: 0x04001F58 RID: 8024
		TopRight,
		// Token: 0x04001F59 RID: 8025
		BottomRight,
		// Token: 0x04001F5A RID: 8026
		BottomLeft,
		// Token: 0x04001F5B RID: 8027
		Center,
		// Token: 0x04001F5C RID: 8028
		None,
		// Token: 0x04001F5D RID: 8029
		TopCenter,
		// Token: 0x04001F5E RID: 8030
		RightCenter,
		// Token: 0x04001F5F RID: 8031
		BottomCenter,
		// Token: 0x04001F60 RID: 8032
		LeftCenter
	}

	// Token: 0x0200031C RID: 796
	public enum Enum23 : uint
	{
		// Token: 0x04001F62 RID: 8034
		Hide,
		// Token: 0x04001F63 RID: 8035
		ShowNormal,
		// Token: 0x04001F64 RID: 8036
		ShowMinimized,
		// Token: 0x04001F65 RID: 8037
		ShowMaximized,
		// Token: 0x04001F66 RID: 8038
		Maximize = 3U,
		// Token: 0x04001F67 RID: 8039
		ShowNormalNoActivate,
		// Token: 0x04001F68 RID: 8040
		Show,
		// Token: 0x04001F69 RID: 8041
		Minimize,
		// Token: 0x04001F6A RID: 8042
		ShowMinNoActivate,
		// Token: 0x04001F6B RID: 8043
		ShowNoActivate,
		// Token: 0x04001F6C RID: 8044
		Restore,
		// Token: 0x04001F6D RID: 8045
		ShowDefault,
		// Token: 0x04001F6E RID: 8046
		ForceMinimized
	}

	// Token: 0x0200031D RID: 797
	public struct Struct10
	{
		// Token: 0x04001F6F RID: 8047
		public int int_0;

		// Token: 0x04001F70 RID: 8048
		public int int_1;

		// Token: 0x04001F71 RID: 8049
		public int int_2;

		// Token: 0x04001F72 RID: 8050
		public int int_3;
	}

	// Token: 0x0200031E RID: 798
	private enum Enum24 : uint
	{
		// Token: 0x04001F74 RID: 8052
		GW_HWNDFIRST,
		// Token: 0x04001F75 RID: 8053
		GW_HWNDLAST,
		// Token: 0x04001F76 RID: 8054
		GW_HWNDNEXT,
		// Token: 0x04001F77 RID: 8055
		GW_HWNDPREV,
		// Token: 0x04001F78 RID: 8056
		GW_OWNER,
		// Token: 0x04001F79 RID: 8057
		GW_CHILD,
		// Token: 0x04001F7A RID: 8058
		GW_ENABLEDPOPUP
	}
}
