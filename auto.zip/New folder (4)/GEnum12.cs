﻿using System;

// Token: 0x020000EE RID: 238
public enum GEnum12
{
	// Token: 0x040005D8 RID: 1496
	ChangedRange,
	// Token: 0x040005D9 RID: 1497
	VisibleRange,
	// Token: 0x040005DA RID: 1498
	AllTextRange
}
