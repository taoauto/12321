﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020001F2 RID: 498
public class Setting : UserControl
{
	// Token: 0x17000648 RID: 1608
	// (get) Token: 0x06001A0C RID: 6668 RVA: 0x00012E18 File Offset: 0x00011018
	// (set) Token: 0x06001A0D RID: 6669 RVA: 0x00012E1F File Offset: 0x0001101F
	public static Dictionary<string, List<string>> Dictionary_0 { get; set; } = new Dictionary<string, List<string>>();

	// Token: 0x17000649 RID: 1609
	// (get) Token: 0x06001A0E RID: 6670 RVA: 0x00012E27 File Offset: 0x00011027
	// (set) Token: 0x06001A0F RID: 6671 RVA: 0x00012E2E File Offset: 0x0001102E
	public static Dictionary<string, List<string>> Dictionary_1 { get; set; } = new Dictionary<string, List<string>>();

	// Token: 0x1700064A RID: 1610
	// (get) Token: 0x06001A10 RID: 6672 RVA: 0x00012E36 File Offset: 0x00011036
	public static IEnumerable<string> IEnumerable_0
	{
		get
		{
			return Setting.Dictionary_0.Values.Select(new Func<List<string>, string>(Setting.Class231.<>9.method_0));
		}
	}

	// Token: 0x1700064B RID: 1611
	// (get) Token: 0x06001A11 RID: 6673 RVA: 0x00012E66 File Offset: 0x00011066
	// (set) Token: 0x06001A12 RID: 6674 RVA: 0x00012E6D File Offset: 0x0001106D
	public static string String_0 { get; set; } = string.Empty;

	// Token: 0x1700064C RID: 1612
	// (get) Token: 0x06001A13 RID: 6675 RVA: 0x00012E75 File Offset: 0x00011075
	// (set) Token: 0x06001A14 RID: 6676 RVA: 0x00012E7C File Offset: 0x0001107C
	public static string String_1 { get; set; } = string.Empty;

	// Token: 0x1700064D RID: 1613
	// (get) Token: 0x06001A15 RID: 6677 RVA: 0x00012E84 File Offset: 0x00011084
	// (set) Token: 0x06001A16 RID: 6678 RVA: 0x00012E8B File Offset: 0x0001108B
	public static string String_2 { get; set; } = string.Empty;

	// Token: 0x1700064E RID: 1614
	// (get) Token: 0x06001A17 RID: 6679 RVA: 0x00012E93 File Offset: 0x00011093
	// (set) Token: 0x06001A18 RID: 6680 RVA: 0x00012E9A File Offset: 0x0001109A
	public static string String_3 { get; set; } = string.Empty;

	// Token: 0x1700064F RID: 1615
	// (get) Token: 0x06001A19 RID: 6681 RVA: 0x00012EA2 File Offset: 0x000110A2
	// (set) Token: 0x06001A1A RID: 6682 RVA: 0x00012EA9 File Offset: 0x000110A9
	public static string String_4 { get; set; } = string.Empty;

	// Token: 0x17000650 RID: 1616
	// (get) Token: 0x06001A1B RID: 6683 RVA: 0x00012EB1 File Offset: 0x000110B1
	// (set) Token: 0x06001A1C RID: 6684 RVA: 0x00012EB8 File Offset: 0x000110B8
	public static string String_5 { get; set; } = string.Empty;

	// Token: 0x17000651 RID: 1617
	// (get) Token: 0x06001A1D RID: 6685 RVA: 0x00012EC0 File Offset: 0x000110C0
	// (set) Token: 0x06001A1E RID: 6686 RVA: 0x00012EC7 File Offset: 0x000110C7
	public static string String_6 { get; set; } = string.Empty;

	// Token: 0x17000652 RID: 1618
	// (get) Token: 0x06001A1F RID: 6687 RVA: 0x00012ECF File Offset: 0x000110CF
	// (set) Token: 0x06001A20 RID: 6688 RVA: 0x00012ED6 File Offset: 0x000110D6
	public static string String_7 { get; set; } = string.Empty;

	// Token: 0x17000653 RID: 1619
	// (get) Token: 0x06001A21 RID: 6689 RVA: 0x00012EDE File Offset: 0x000110DE
	// (set) Token: 0x06001A22 RID: 6690 RVA: 0x00012EE5 File Offset: 0x000110E5
	public static string String_8 { get; set; } = string.Empty;

	// Token: 0x17000654 RID: 1620
	// (get) Token: 0x06001A23 RID: 6691 RVA: 0x00012EED File Offset: 0x000110ED
	// (set) Token: 0x06001A24 RID: 6692 RVA: 0x00012EF4 File Offset: 0x000110F4
	public static string String_9 { get; set; } = string.Empty;

	// Token: 0x17000655 RID: 1621
	// (get) Token: 0x06001A25 RID: 6693 RVA: 0x00012EFC File Offset: 0x000110FC
	// (set) Token: 0x06001A26 RID: 6694 RVA: 0x00012F03 File Offset: 0x00011103
	public static Dictionary<string, bool> Dictionary_2 { get; set; } = new Dictionary<string, bool>();

	// Token: 0x17000656 RID: 1622
	// (get) Token: 0x06001A27 RID: 6695 RVA: 0x00012F0B File Offset: 0x0001110B
	// (set) Token: 0x06001A28 RID: 6696 RVA: 0x00012F12 File Offset: 0x00011112
	public static Dictionary<string, int> Dictionary_3 { get; set; } = new Dictionary<string, int>();

	// Token: 0x06001A29 RID: 6697 RVA: 0x00012F1A File Offset: 0x0001111A
	public static bool smethod_0(string string_10)
	{
		return Setting.Dictionary_2.ContainsKey(string_10) && Setting.Dictionary_2[string_10];
	}

	// Token: 0x06001A2A RID: 6698 RVA: 0x00012F36 File Offset: 0x00011136
	public static int smethod_1(string string_10)
	{
		if (!Setting.Dictionary_3.ContainsKey(string_10))
		{
			return -1;
		}
		return Setting.Dictionary_3[string_10];
	}

	// Token: 0x06001A2B RID: 6699 RVA: 0x00012F52 File Offset: 0x00011152
	public Setting()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001A2C RID: 6700 RVA: 0x000BDA4C File Offset: 0x000BBC4C
	public void method_0()
	{
		using (IEnumerator<Control> enumerator = this.smethod_32().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Setting.Class232 @class = new Setting.Class232();
				@class.control_0 = enumerator.Current;
				try
				{
					string text = Class159.Class220_0.method_0("SettingValue", @class.control_0.Name.ToString());
					if (!string.IsNullOrEmpty(text))
					{
						if (@class.control_0.GetType() == typeof(NumericUpDown))
						{
							((NumericUpDown)@class.control_0).Value = text.smethod_18();
						}
						if (@class.control_0.GetType() == typeof(Class85))
						{
							((Class85)@class.control_0).Text = text;
							Setting.Dictionary_3[@class.control_0.Name] = ((Class85)@class.control_0).Text.smethod_37();
						}
						if (@class.control_0.GetType() == typeof(ComboBox))
						{
							((ComboBox)@class.control_0).SelectedIndex = text.smethod_18();
						}
						if (@class.control_0.GetType() == typeof(CheckBox))
						{
							((CheckBox)@class.control_0).Checked = (text == "True");
							Setting.Dictionary_2[@class.control_0.Name] = ((CheckBox)@class.control_0).Checked;
							((CheckBox)@class.control_0).CheckedChanged += @class.method_0;
						}
						if (@class.control_0.GetType() == typeof(Control0))
						{
							Setting.Dictionary_3[@class.control_0.Name] = ((Control0)@class.control_0).Int32_1.smethod_8();
							((Control0)@class.control_0).Int32_1 = text.smethod_18();
							((Control0)@class.control_0).Event_0 += @class.method_1;
						}
					}
				}
				catch
				{
				}
			}
		}
	}

	// Token: 0x06001A2D RID: 6701 RVA: 0x000BDCB0 File Offset: 0x000BBEB0
	public void method_1()
	{
		foreach (Control control in this.smethod_32())
		{
			try
			{
				if (control.GetType() == typeof(NumericUpDown))
				{
					Class159.Class220_0.method_1("SettingValue", control.Name, ((NumericUpDown)control).Value.ToString());
				}
				if (control.GetType() == typeof(Class85))
				{
					Class159.Class220_0.method_1("SettingValue", control.Name, ((Class85)control).Text.ToString());
				}
				if (control.GetType() == typeof(ComboBox))
				{
					Class159.Class220_0.method_1("SettingValue", control.Name, ((ComboBox)control).SelectedIndex.ToString());
				}
				if (control.GetType() == typeof(CheckBox))
				{
					Class159.Class220_0.method_1("SettingValue", control.Name, ((CheckBox)control).Checked.ToString());
				}
				if (control.GetType() == typeof(Control0))
				{
					Class159.Class220_0.method_1("SettingValue", control.Name, ((Control0)control).Int32_1.ToString());
				}
			}
			catch
			{
			}
		}
	}

	// Token: 0x06001A2E RID: 6702 RVA: 0x000BDE60 File Offset: 0x000BC060
	private void btnClose_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.panGameItem.Controls)
		{
			Control control = (Control)obj;
			if (control != sender)
			{
				control.Dispose();
			}
		}
		this.panGameItem.SendToBack();
		Control control2 = this.panel1;
		this.panel2.Visible = true;
		control2.Visible = true;
	}

	// Token: 0x06001A2F RID: 6703 RVA: 0x000BDEE8 File Offset: 0x000BC0E8
	private void method_2(UserControl userControl_0)
	{
		Control control = this.panel1;
		this.panel2.Visible = false;
		control.Visible = false;
		this.panGameItem.Visible = true;
		this.panGameItem.Dock = DockStyle.Fill;
		this.panGameItem.BringToFront();
		this.panGameItem.Controls.Add(userControl_0);
		userControl_0.Dock = DockStyle.Fill;
		userControl_0.BringToFront();
	}

	// Token: 0x06001A30 RID: 6704 RVA: 0x00012F60 File Offset: 0x00011160
	private void btnDropItemEx_Click(object sender, EventArgs e)
	{
		Main.Main_0.method_91(new DropItem());
	}

	// Token: 0x06001A31 RID: 6705 RVA: 0x00002E18 File Offset: 0x00001018
	private void checkExitSleepTime_CheckedChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A32 RID: 6706 RVA: 0x00012F71 File Offset: 0x00011171
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A33 RID: 6707 RVA: 0x000BDF50 File Offset: 0x000BC150
	private void InitializeComponent()
	{
		this.tabSettingChild = new Control1();
		this.tabSettingBachHoaDuyen = new TabPage();
		this.splitContainer4 = new SplitContainer();
		this.groupBox8 = new GroupBox();
		this.label7 = new Label();
		this.label5 = new Label();
		this.textBox25 = new TextBox();
		this.textBox26 = new TextBox();
		this.textBox27 = new TextBox();
		this.numerBachHoaDuyenTime = new TextBox();
		this.textBox29 = new TextBox();
		this.chkBonPhan = new CheckBox();
		this.chkTrongBon = new CheckBox();
		this.groupBox9 = new GroupBox();
		this.textBox19 = new TextBox();
		this.textBox20 = new TextBox();
		this.textBox21 = new TextBox();
		this.textBox22 = new TextBox();
		this.textBox23 = new TextBox();
		this.textBox24 = new TextBox();
		this.textBox15 = new TextBox();
		this.textBox16 = new TextBox();
		this.textBox17 = new TextBox();
		this.textBox18 = new TextBox();
		this.label28 = new Label();
		this.label30 = new Label();
		this.label32 = new Label();
		this.label33 = new Label();
		this.label34 = new Label();
		this.label35 = new Label();
		this.label36 = new Label();
		this.label37 = new Label();
		this.label38 = new Label();
		this.label39 = new Label();
		this.chkLimitBienThan = new CheckBox();
		this.label40 = new Label();
		this.chkBonHoaAll = new CheckBox();
		this.label41 = new Label();
		this.chkHuyDanhQuai = new CheckBox();
		this.chkHuyThaiHo = new CheckBox();
		this.IsHyHuu = new CheckBox();
		this.tabSettingChung = new TabPage();
		this.panel2 = new Panel();
		this.checkTriLieuMP = new CheckBox();
		this.label1 = new Label();
		this.numberTriLieuHP = new TextBox();
		this.numberAnGameTime = new TextBox();
		this.numberDungCHT = new TextBox();
		this.numberThangCap = new TextBox();
		this.numberAlarmHP = new TextBox();
		this.numberSuaTrangBi = new TextBox();
		this.numberChuyenMatac = new TextBox();
		this.numberThuPet = new TextBox();
		this.numberTangQuanSonHai = new TextBox();
		this.numberTamXa = new TextBox();
		this.numberNhiemVuCap = new TextBox();
		this.checkDungXaPhu = new CheckBox();
		this.checkDiCoNhanh = new CheckBox();
		this.checkBaoTangDoThongMinh = new CheckBox();
		this.label17 = new Label();
		this.checkLuuTrangThai = new CheckBox();
		this.checkPhuBanDuNguoi = new CheckBox();
		this.label2 = new Label();
		this.label14 = new Label();
		this.label16 = new Label();
		this.checkAlarmHP = new CheckBox();
		this.checkTriLieuHP = new CheckBox();
		this.checkThangCap = new CheckBox();
		this.label25 = new Label();
		this.label13 = new Label();
		this.checkAnGameTime = new CheckBox();
		this.panel1 = new Panel();
		this.checkNotUseShortcutKey = new CheckBox();
		this.checkSkipMonter = new CheckBox();
		this.checkAlarmInbox = new CheckBox();
		this.checkNotUseRide = new CheckBox();
		this.checkMuteInbox = new CheckBox();
		this.btnBoQua = new Button();
		this.button6 = new Button();
		this.checkAccept = new CheckBox();
		this.checkBuyItem = new CheckBox();
		this.btnAutoAccept = new Button();
		this.btnGomDo = new Button();
		this.checkUseCalender = new CheckBox();
		this.checkAntiCaptcha = new CheckBox();
		this.checkDropItem = new CheckBox();
		this.checkAcceptAll = new CheckBox();
		this.btnAutoBuy = new Button();
		this.button1 = new Button();
		this.btnUseItem = new Button();
		this.button8 = new Button();
		this.checkUseItem = new CheckBox();
		this.checkNemBienThan = new CheckBox();
		this.checkSellItem = new CheckBox();
		this.btnCatDo = new Button();
		this.btnDropItemEx = new Button();
		this.btnSellItemEx = new Button();
		this.checkBankItem = new CheckBox();
		this.panGameItem = new Panel();
		this.btnClose = new Button();
		this.tabSettingTuDong = new TabPage();
		this.flowLayoutPanel2 = new FlowLayoutPanel();
		this.checkCongTheLuc = new CheckBox();
		this.checkCongDiemPet = new CheckBox();
		this.checkCatDoDayTayNai = new CheckBox();
		this.checkBanDoDayTayNai = new CheckBox();
		this.checkDungx2 = new CheckBox();
		this.checkMuax2 = new CheckBox();
		this.checkNhanx2LuyenCap = new CheckBox();
		this.checkThuTieuDatTai = new CheckBox();
		this.checkToDoiGanNhau = new CheckBox();
		this.checkXuatPetManNhat = new CheckBox();
		this.checkXuongNgua = new CheckBox();
		this.checkXepTayNai = new CheckBox();
		this.checkAutoShutDown = new CheckBox();
		this.checkTuKeoDoi = new CheckBox();
		this.grShutDown = new GClass106();
		this.label3 = new Label();
		this.textBox31 = new TextBox();
		this.textBox30 = new TextBox();
		this.groupBox20 = new GroupBox();
		this.flowLayoutPanel5 = new FlowLayoutPanel();
		this.groupBox7 = new GroupBox();
		this.checkKhiBanRac = new CheckBox();
		this.checkKhiDungDo = new CheckBox();
		this.checkKhiGomDo = new CheckBox();
		this.checkKhiPhanGiai = new CheckBox();
		this.checkKhiCatDo = new CheckBox();
		this.checkDatSkillF1 = new CheckBox();
		this.checkDatAnToan = new CheckBox();
		this.checkResetCanQuet = new CheckBox();
		this.checkHoTro = new CheckBox();
		this.checkDungSkillPet = new CheckBox();
		this.checkChucPhuc = new CheckBox();
		this.checkDiemDanh = new CheckBox();
		this.checkHoiSinh = new CheckBox();
		this.checkNgamyHoiSinh = new CheckBox();
		this.checkDauThai = new CheckBox();
		this.tabSettingTuyChon = new TabPage();
		this.flowLayoutPanel4 = new FlowLayoutPanel();
		this.groupBox11 = new GroupBox();
		this.cboMapDua = new ComboBox();
		this.groupBox12 = new GroupBox();
		this.cboMenpai = new ComboBox();
		this.groupBox5 = new GroupBox();
		this.textBox37 = new TextBox();
		this.textBox36 = new TextBox();
		this.btnBuyDaiLy = new Button();
		this.label8 = new Label();
		this.label6 = new Label();
		this.groupBox4 = new GroupBox();
		this.textBox35 = new TextBox();
		this.textBox34 = new TextBox();
		this.textBox33 = new TextBox();
		this.label15 = new Label();
		this.groupBox6 = new GroupBox();
		this.numberDelay = new Control0();
		this.chkCanQuetx2 = new CheckBox();
		this.chkHold = new CheckBox();
		this.chkAutoResetTime = new CheckBox();
		this.flowLayoutPanel3 = new FlowLayoutPanel();
		this.groupBox19 = new GroupBox();
		this.checkUseSelectServer = new CheckBox();
		this.checkLuonAnGame = new CheckBox();
		this.checkKhongChiemManHinh = new CheckBox();
		this.groupBox18 = new GroupBox();
		this.checkBuffPet = new CheckBox();
		this.checkBuffQuanDoan = new CheckBox();
		this.groupBox16 = new GroupBox();
		this.checkNeBinh = new CheckBox();
		this.checkBossCuoi = new CheckBox();
		this.groupBox17 = new GroupBox();
		this.checkAlarmPk = new CheckBox();
		this.checkDanhTra = new CheckBox();
		this.checkPKNgaMy = new CheckBox();
		this.groupBox10 = new GroupBox();
		this.label4 = new Label();
		this.chkHuyBatPet = new CheckBox();
		this.checkKhongDungDongMon = new CheckBox();
		this.numberMaxSuMon = new TextBox();
		this.tabSettingLogin = new TabPage();
		this.splitContainer2 = new SplitContainer();
		this.groupBox21 = new GroupBox();
		this.textBox8 = new TextBox();
		this.textBox9 = new TextBox();
		this.textBox10 = new TextBox();
		this.textBox11 = new TextBox();
		this.label9 = new Label();
		this.chkExitPK = new CheckBox();
		this.chkExitCaptcha = new CheckBox();
		this.chkExitDead = new CheckBox();
		this.btnSleepTime = new Button();
		this.checkNotOutKey = new CheckBox();
		this.checkExitSleepTime = new CheckBox();
		this.checkExitLogin = new CheckBox();
		this.checkExitOnline = new CheckBox();
		this.label20 = new Label();
		this.checkExitIdle = new CheckBox();
		this.label31 = new Label();
		this.checkExitLevel = new CheckBox();
		this.groupBox22 = new GroupBox();
		this.checkChayBachHoaDuyen = new CheckBox();
		this.chkAutoCreatePlayer = new CheckBox();
		this.checkChayTrungAc = new CheckBox();
		this.textBox13 = new TextBox();
		this.checkNotOutXong = new CheckBox();
		this.label42 = new Label();
		this.checkAutoLogin = new CheckBox();
		this.checkKhongChonMayChu = new CheckBox();
		this.groupBox24 = new GroupBox();
		this.numberMoCachNhau = new TextBox();
		this.numberMoGameDongThoi = new TextBox();
		this.numberMoGameToiDa = new TextBox();
		this.label43 = new Label();
		this.label44 = new Label();
		this.label45 = new Label();
		this.label46 = new Label();
		this.tabSettingBachHoaDuyen.SuspendLayout();
		this.splitContainer4.Panel1.SuspendLayout();
		this.splitContainer4.SuspendLayout();
		this.groupBox8.SuspendLayout();
		this.groupBox9.SuspendLayout();
		this.tabSettingChung.SuspendLayout();
		this.panel2.SuspendLayout();
		this.panel1.SuspendLayout();
		this.panGameItem.SuspendLayout();
		this.tabSettingTuDong.SuspendLayout();
		this.flowLayoutPanel2.SuspendLayout();
		this.grShutDown.SuspendLayout();
		this.groupBox20.SuspendLayout();
		this.flowLayoutPanel5.SuspendLayout();
		this.groupBox7.SuspendLayout();
		this.tabSettingTuyChon.SuspendLayout();
		this.flowLayoutPanel4.SuspendLayout();
		this.groupBox11.SuspendLayout();
		this.groupBox12.SuspendLayout();
		this.groupBox5.SuspendLayout();
		this.groupBox4.SuspendLayout();
		this.groupBox6.SuspendLayout();
		this.flowLayoutPanel3.SuspendLayout();
		this.groupBox19.SuspendLayout();
		this.groupBox18.SuspendLayout();
		this.groupBox16.SuspendLayout();
		this.groupBox17.SuspendLayout();
		this.groupBox10.SuspendLayout();
		this.tabSettingLogin.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.groupBox21.SuspendLayout();
		this.groupBox22.SuspendLayout();
		this.groupBox24.SuspendLayout();
		base.SuspendLayout();
		this.tabSettingChild.Dock = DockStyle.Fill;
		this.tabSettingChild.Location = new Point(0, 0);
		this.tabSettingChild.Name = "tabSettingChild";
		this.tabSettingChild.SelectedIndex = 0;
		this.tabSettingChild.Size = new Size(499, 456);
		this.tabSettingChild.TabIndex = 1;
		this.tabSettingChild.TabStop = false;
		this.tabSettingChild.Controls.Add(this.tabSettingChung);
		this.tabSettingChild.Controls.Add(this.tabSettingTuDong);
		this.tabSettingChild.Controls.Add(this.tabSettingTuyChon);
		this.tabSettingChild.Controls.Add(this.tabSettingBachHoaDuyen);
		this.tabSettingChild.Controls.Add(this.tabSettingLogin);
		this.tabSettingBachHoaDuyen.Controls.Add(this.splitContainer4);
		this.tabSettingBachHoaDuyen.Location = new Point(4, 4);
		this.tabSettingBachHoaDuyen.Name = "tabSettingBachHoaDuyen";
		this.tabSettingBachHoaDuyen.Padding = new Padding(3);
		this.tabSettingBachHoaDuyen.Size = new Size(491, 430);
		this.tabSettingBachHoaDuyen.TabIndex = 3;
		this.tabSettingBachHoaDuyen.Text = "Hoa";
		this.tabSettingBachHoaDuyen.UseVisualStyleBackColor = true;
		this.splitContainer4.Dock = DockStyle.Fill;
		this.splitContainer4.Location = new Point(3, 3);
		this.splitContainer4.Name = "splitContainer4";
		this.splitContainer4.Panel1.Controls.Add(this.groupBox8);
		this.splitContainer4.Size = new Size(485, 424);
		this.splitContainer4.SplitterDistance = 299;
		this.splitContainer4.TabIndex = 0;
		this.groupBox8.Controls.Add(this.label7);
		this.groupBox8.Controls.Add(this.label5);
		this.groupBox8.Controls.Add(this.textBox25);
		this.groupBox8.Controls.Add(this.textBox26);
		this.groupBox8.Controls.Add(this.textBox27);
		this.groupBox8.Controls.Add(this.numerBachHoaDuyenTime);
		this.groupBox8.Controls.Add(this.textBox29);
		this.groupBox8.Controls.Add(this.chkBonPhan);
		this.groupBox8.Controls.Add(this.chkTrongBon);
		this.groupBox8.Controls.Add(this.groupBox9);
		this.groupBox8.Controls.Add(this.chkLimitBienThan);
		this.groupBox8.Controls.Add(this.label40);
		this.groupBox8.Controls.Add(this.chkBonHoaAll);
		this.groupBox8.Controls.Add(this.label41);
		this.groupBox8.Controls.Add(this.chkHuyDanhQuai);
		this.groupBox8.Controls.Add(this.chkHuyThaiHo);
		this.groupBox8.Controls.Add(this.IsHyHuu);
		this.groupBox8.Dock = DockStyle.Fill;
		this.groupBox8.Location = new Point(0, 0);
		this.groupBox8.Name = "groupBox8";
		this.groupBox8.Size = new Size(299, 424);
		this.groupBox8.TabIndex = 313;
		this.groupBox8.TabStop = false;
		this.groupBox8.Text = "Bách Hoa Duyên";
		this.label7.AutoSize = true;
		this.label7.Location = new Point(6, 46);
		this.label7.Name = "label7";
		this.label7.Size = new Size(88, 13);
		this.label7.TabIndex = 393;
		this.label7.Text = "Thời Gian Tối Đa";
		this.label5.AutoSize = true;
		this.label5.Location = new Point(6, 20);
		this.label5.Name = "label5";
		this.label5.Size = new Size(62, 13);
		this.label5.TabIndex = 392;
		this.label5.Text = "Làm Tối Đa";
		this.textBox25.Location = new Point(122, 212);
		this.textBox25.Name = "textBox25";
		this.textBox25.Size = new Size(46, 20);
		this.textBox25.TabIndex = 391;
		this.textBox26.Location = new Point(122, 186);
		this.textBox26.Name = "textBox26";
		this.textBox26.Size = new Size(46, 20);
		this.textBox26.TabIndex = 390;
		this.textBox27.Location = new Point(122, 160);
		this.textBox27.Name = "textBox27";
		this.textBox27.Size = new Size(46, 20);
		this.textBox27.TabIndex = 389;
		this.numerBachHoaDuyenTime.Location = new Point(122, 43);
		this.numerBachHoaDuyenTime.Name = "numerBachHoaDuyenTime";
		this.numerBachHoaDuyenTime.Size = new Size(46, 20);
		this.numerBachHoaDuyenTime.TabIndex = 388;
		this.textBox29.Location = new Point(122, 17);
		this.textBox29.Name = "textBox29";
		this.textBox29.Size = new Size(46, 20);
		this.textBox29.TabIndex = 387;
		this.chkBonPhan.AutoSize = true;
		this.chkBonPhan.Location = new Point(6, 162);
		this.chkBonPhan.Name = "chkBonPhan";
		this.chkBonPhan.Size = new Size(108, 17);
		this.chkBonPhan.TabIndex = 299;
		this.chkBonPhan.TabStop = false;
		this.chkBonPhan.Text = "Bón Phân Tối Đa";
		this.chkBonPhan.UseVisualStyleBackColor = true;
		this.chkTrongBon.AutoSize = true;
		this.chkTrongBon.Location = new Point(6, 188);
		this.chkTrongBon.Name = "chkTrongBon";
		this.chkTrongBon.Size = new Size(112, 17);
		this.chkTrongBon.TabIndex = 302;
		this.chkTrongBon.TabStop = false;
		this.chkTrongBon.Text = "Trồng Hoa Tối Đa";
		this.chkTrongBon.UseVisualStyleBackColor = true;
		this.groupBox9.Controls.Add(this.textBox19);
		this.groupBox9.Controls.Add(this.textBox20);
		this.groupBox9.Controls.Add(this.textBox21);
		this.groupBox9.Controls.Add(this.textBox22);
		this.groupBox9.Controls.Add(this.textBox23);
		this.groupBox9.Controls.Add(this.textBox24);
		this.groupBox9.Controls.Add(this.textBox15);
		this.groupBox9.Controls.Add(this.textBox16);
		this.groupBox9.Controls.Add(this.textBox17);
		this.groupBox9.Controls.Add(this.textBox18);
		this.groupBox9.Controls.Add(this.label28);
		this.groupBox9.Controls.Add(this.label30);
		this.groupBox9.Controls.Add(this.label32);
		this.groupBox9.Controls.Add(this.label33);
		this.groupBox9.Controls.Add(this.label34);
		this.groupBox9.Controls.Add(this.label35);
		this.groupBox9.Controls.Add(this.label36);
		this.groupBox9.Controls.Add(this.label37);
		this.groupBox9.Controls.Add(this.label38);
		this.groupBox9.Controls.Add(this.label39);
		this.groupBox9.Dock = DockStyle.Bottom;
		this.groupBox9.Location = new Point(3, 263);
		this.groupBox9.Name = "groupBox9";
		this.groupBox9.Size = new Size(293, 158);
		this.groupBox9.TabIndex = 310;
		this.groupBox9.TabStop = false;
		this.groupBox9.Text = "Trồng Hoa";
		this.textBox19.Location = new Point(109, 124);
		this.textBox19.Name = "textBox19";
		this.textBox19.Size = new Size(46, 20);
		this.textBox19.TabIndex = 399;
		this.textBox20.Location = new Point(110, 99);
		this.textBox20.Name = "textBox20";
		this.textBox20.Size = new Size(46, 20);
		this.textBox20.TabIndex = 398;
		this.textBox21.Location = new Point(110, 76);
		this.textBox21.Name = "textBox21";
		this.textBox21.Size = new Size(46, 20);
		this.textBox21.TabIndex = 397;
		this.textBox22.Location = new Point(110, 50);
		this.textBox22.Name = "textBox22";
		this.textBox22.Size = new Size(46, 20);
		this.textBox22.TabIndex = 396;
		this.textBox23.Location = new Point(109, 24);
		this.textBox23.Name = "textBox23";
		this.textBox23.Size = new Size(46, 20);
		this.textBox23.TabIndex = 395;
		this.textBox24.Location = new Point(38, 124);
		this.textBox24.Name = "textBox24";
		this.textBox24.Size = new Size(46, 20);
		this.textBox24.TabIndex = 394;
		this.textBox15.Location = new Point(39, 99);
		this.textBox15.Name = "textBox15";
		this.textBox15.Size = new Size(46, 20);
		this.textBox15.TabIndex = 393;
		this.textBox16.Location = new Point(39, 76);
		this.textBox16.Name = "textBox16";
		this.textBox16.Size = new Size(46, 20);
		this.textBox16.TabIndex = 392;
		this.textBox17.Location = new Point(39, 50);
		this.textBox17.Name = "textBox17";
		this.textBox17.Size = new Size(46, 20);
		this.textBox17.TabIndex = 391;
		this.textBox18.Location = new Point(38, 24);
		this.textBox18.Name = "textBox18";
		this.textBox18.Size = new Size(46, 20);
		this.textBox18.TabIndex = 390;
		this.label28.AutoSize = true;
		this.label28.Location = new Point(11, 127);
		this.label28.Name = "label28";
		this.label28.Size = new Size(21, 13);
		this.label28.TabIndex = 305;
		this.label28.Text = "x5:";
		this.label30.AutoSize = true;
		this.label30.Location = new Point(11, 102);
		this.label30.Name = "label30";
		this.label30.Size = new Size(21, 13);
		this.label30.TabIndex = 301;
		this.label30.Text = "x4:";
		this.label32.AutoSize = true;
		this.label32.Location = new Point(90, 127);
		this.label32.Name = "label32";
		this.label32.Size = new Size(13, 13);
		this.label32.TabIndex = 308;
		this.label32.Text = "+";
		this.label33.AutoSize = true;
		this.label33.Location = new Point(11, 79);
		this.label33.Name = "label33";
		this.label33.Size = new Size(21, 13);
		this.label33.TabIndex = 297;
		this.label33.Text = "x3:";
		this.label34.AutoSize = true;
		this.label34.Location = new Point(11, 53);
		this.label34.Name = "label34";
		this.label34.Size = new Size(21, 13);
		this.label34.TabIndex = 293;
		this.label34.Text = "x2:";
		this.label35.AutoSize = true;
		this.label35.Location = new Point(90, 27);
		this.label35.Name = "label35";
		this.label35.Size = new Size(13, 13);
		this.label35.TabIndex = 283;
		this.label35.Text = "+";
		this.label36.AutoSize = true;
		this.label36.Location = new Point(11, 27);
		this.label36.Name = "label36";
		this.label36.Size = new Size(21, 13);
		this.label36.TabIndex = 280;
		this.label36.Text = "x1:";
		this.label37.AutoSize = true;
		this.label37.Location = new Point(90, 102);
		this.label37.Name = "label37";
		this.label37.Size = new Size(13, 13);
		this.label37.TabIndex = 304;
		this.label37.Text = "+";
		this.label38.AutoSize = true;
		this.label38.Location = new Point(90, 53);
		this.label38.Name = "label38";
		this.label38.Size = new Size(13, 13);
		this.label38.TabIndex = 296;
		this.label38.Text = "+";
		this.label39.AutoSize = true;
		this.label39.Location = new Point(90, 79);
		this.label39.Name = "label39";
		this.label39.Size = new Size(13, 13);
		this.label39.TabIndex = 300;
		this.label39.Text = "+";
		this.chkLimitBienThan.AutoSize = true;
		this.chkLimitBienThan.Location = new Point(6, 214);
		this.chkLimitBienThan.Name = "chkLimitBienThan";
		this.chkLimitBienThan.Size = new Size(110, 17);
		this.chkLimitBienThan.TabIndex = 305;
		this.chkLimitBienThan.TabStop = false;
		this.chkLimitBienThan.Text = "Biến Thân Tối Đa";
		this.chkLimitBienThan.UseVisualStyleBackColor = true;
		this.label40.AutoSize = true;
		this.label40.Location = new Point(174, 20);
		this.label40.Name = "label40";
		this.label40.Size = new Size(13, 13);
		this.label40.TabIndex = 267;
		this.label40.Text = "v";
		this.chkBonHoaAll.AutoSize = true;
		this.chkBonHoaAll.Location = new Point(6, 139);
		this.chkBonHoaAll.Name = "chkBonHoaAll";
		this.chkBonHoaAll.Size = new Size(112, 17);
		this.chkBonHoaAll.TabIndex = 284;
		this.chkBonHoaAll.TabStop = false;
		this.chkBonHoaAll.Text = "Bón Hoa Toàn Bộ";
		this.chkBonHoaAll.UseVisualStyleBackColor = true;
		this.label41.AutoSize = true;
		this.label41.Location = new Point(174, 46);
		this.label41.Name = "label41";
		this.label41.Size = new Size(15, 13);
		this.label41.TabIndex = 270;
		this.label41.Text = "m";
		this.chkHuyDanhQuai.AutoSize = true;
		this.chkHuyDanhQuai.Location = new Point(6, 70);
		this.chkHuyDanhQuai.Name = "chkHuyDanhQuai";
		this.chkHuyDanhQuai.Size = new Size(148, 17);
		this.chkHuyDanhQuai.TabIndex = 271;
		this.chkHuyDanhQuai.TabStop = false;
		this.chkHuyDanhQuai.Text = "Hủy Nhiệm Vụ Đánh Quái";
		this.chkHuyDanhQuai.UseVisualStyleBackColor = true;
		this.chkHuyThaiHo.AutoSize = true;
		this.chkHuyThaiHo.Location = new Point(6, 93);
		this.chkHuyThaiHo.Name = "chkHuyThaiHo";
		this.chkHuyThaiHo.Size = new Size(135, 17);
		this.chkHuyThaiHo.TabIndex = 272;
		this.chkHuyThaiHo.TabStop = false;
		this.chkHuyThaiHo.Text = "Hủy Nhiệm Vụ Thái Hồ";
		this.chkHuyThaiHo.UseVisualStyleBackColor = true;
		this.IsHyHuu.AutoSize = true;
		this.IsHyHuu.Location = new Point(6, 116);
		this.IsHyHuu.Name = "IsHyHuu";
		this.IsHyHuu.Size = new Size(139, 17);
		this.IsHyHuu.TabIndex = 273;
		this.IsHyHuu.TabStop = false;
		this.IsHyHuu.Text = "Hủy Nhiệm Vụ Bồn Hoa";
		this.IsHyHuu.UseVisualStyleBackColor = true;
		this.tabSettingChung.Controls.Add(this.panel2);
		this.tabSettingChung.Controls.Add(this.panel1);
		this.tabSettingChung.Controls.Add(this.panGameItem);
		this.tabSettingChung.Location = new Point(4, 4);
		this.tabSettingChung.Name = "tabSettingChung";
		this.tabSettingChung.Padding = new Padding(3);
		this.tabSettingChung.Size = new Size(491, 430);
		this.tabSettingChung.TabIndex = 0;
		this.tabSettingChung.Text = "Chung";
		this.tabSettingChung.UseVisualStyleBackColor = true;
		this.panel2.Controls.Add(this.checkTriLieuMP);
		this.panel2.Controls.Add(this.label1);
		this.panel2.Controls.Add(this.numberTriLieuHP);
		this.panel2.Controls.Add(this.numberAnGameTime);
		this.panel2.Controls.Add(this.numberDungCHT);
		this.panel2.Controls.Add(this.numberThangCap);
		this.panel2.Controls.Add(this.numberAlarmHP);
		this.panel2.Controls.Add(this.numberSuaTrangBi);
		this.panel2.Controls.Add(this.numberChuyenMatac);
		this.panel2.Controls.Add(this.numberThuPet);
		this.panel2.Controls.Add(this.numberTangQuanSonHai);
		this.panel2.Controls.Add(this.numberTamXa);
		this.panel2.Controls.Add(this.numberNhiemVuCap);
		this.panel2.Controls.Add(this.checkDungXaPhu);
		this.panel2.Controls.Add(this.checkDiCoNhanh);
		this.panel2.Controls.Add(this.checkBaoTangDoThongMinh);
		this.panel2.Controls.Add(this.label17);
		this.panel2.Controls.Add(this.checkLuuTrangThai);
		this.panel2.Controls.Add(this.checkPhuBanDuNguoi);
		this.panel2.Controls.Add(this.label2);
		this.panel2.Controls.Add(this.label14);
		this.panel2.Controls.Add(this.label16);
		this.panel2.Controls.Add(this.checkAlarmHP);
		this.panel2.Controls.Add(this.checkTriLieuHP);
		this.panel2.Controls.Add(this.checkThangCap);
		this.panel2.Controls.Add(this.label25);
		this.panel2.Controls.Add(this.label13);
		this.panel2.Controls.Add(this.checkAnGameTime);
		this.panel2.Dock = DockStyle.Fill;
		this.panel2.Location = new Point(166, 3);
		this.panel2.Name = "panel2";
		this.panel2.Size = new Size(322, 424);
		this.panel2.TabIndex = 13;
		this.checkTriLieuMP.AutoSize = true;
		this.checkTriLieuMP.Location = new Point(9, 255);
		this.checkTriLieuMP.Margin = new Padding(2);
		this.checkTriLieuMP.Name = "checkTriLieuMP";
		this.checkTriLieuMP.Size = new Size(138, 17);
		this.checkTriLieuMP.TabIndex = 372;
		this.checkTriLieuMP.TabStop = false;
		this.checkTriLieuMP.Text = "Trị Liệu Khi Còn 5% Khí";
		this.checkTriLieuMP.UseVisualStyleBackColor = true;
		this.label1.AutoSize = true;
		this.label1.Location = new Point(6, 142);
		this.label1.Name = "label1";
		this.label1.Size = new Size(113, 13);
		this.label1.TabIndex = 371;
		this.label1.Text = "Dùng CHT Khi HP Pet";
		this.numberTriLieuHP.Location = new Point(138, 232);
		this.numberTriLieuHP.Name = "numberTriLieuHP";
		this.numberTriLieuHP.Size = new Size(46, 20);
		this.numberTriLieuHP.TabIndex = 370;
		this.numberAnGameTime.Location = new Point(138, 208);
		this.numberAnGameTime.Name = "numberAnGameTime";
		this.numberAnGameTime.Size = new Size(46, 20);
		this.numberAnGameTime.TabIndex = 369;
		this.numberDungCHT.Location = new Point(138, 139);
		this.numberDungCHT.Name = "numberDungCHT";
		this.numberDungCHT.Size = new Size(46, 20);
		this.numberDungCHT.TabIndex = 368;
		this.numberThangCap.Location = new Point(138, 186);
		this.numberThangCap.Name = "numberThangCap";
		this.numberThangCap.Size = new Size(46, 20);
		this.numberThangCap.TabIndex = 367;
		this.numberAlarmHP.Location = new Point(138, 165);
		this.numberAlarmHP.Name = "numberAlarmHP";
		this.numberAlarmHP.Size = new Size(46, 20);
		this.numberAlarmHP.TabIndex = 366;
		this.numberSuaTrangBi.Location = new Point(138, 117);
		this.numberSuaTrangBi.Name = "numberSuaTrangBi";
		this.numberSuaTrangBi.Size = new Size(46, 20);
		this.numberSuaTrangBi.TabIndex = 365;
		this.numberChuyenMatac.Location = new Point(138, 93);
		this.numberChuyenMatac.Name = "numberChuyenMatac";
		this.numberChuyenMatac.Size = new Size(46, 20);
		this.numberChuyenMatac.TabIndex = 364;
		this.numberThuPet.Location = new Point(138, 70);
		this.numberThuPet.Name = "numberThuPet";
		this.numberThuPet.Size = new Size(46, 20);
		this.numberThuPet.TabIndex = 363;
		this.numberTangQuanSonHai.Location = new Point(138, 47);
		this.numberTangQuanSonHai.Name = "numberTangQuanSonHai";
		this.numberTangQuanSonHai.Size = new Size(46, 20);
		this.numberTangQuanSonHai.TabIndex = 362;
		this.numberTamXa.Location = new Point(138, 24);
		this.numberTamXa.Name = "numberTamXa";
		this.numberTamXa.Size = new Size(46, 20);
		this.numberTamXa.TabIndex = 361;
		this.numberNhiemVuCap.Location = new Point(138, 3);
		this.numberNhiemVuCap.Name = "numberNhiemVuCap";
		this.numberNhiemVuCap.Size = new Size(46, 20);
		this.numberNhiemVuCap.TabIndex = 360;
		this.checkDungXaPhu.AutoSize = true;
		this.checkDungXaPhu.Location = new Point(9, 339);
		this.checkDungXaPhu.Margin = new Padding(2);
		this.checkDungXaPhu.Name = "checkDungXaPhu";
		this.checkDungXaPhu.Size = new Size(154, 17);
		this.checkDungXaPhu.TabIndex = 333;
		this.checkDungXaPhu.TabStop = false;
		this.checkDungXaPhu.Text = "Dùng Xa Phu Dịch Chuyển";
		this.checkDungXaPhu.UseVisualStyleBackColor = true;
		this.checkDiCoNhanh.AutoSize = true;
		this.checkDiCoNhanh.Location = new Point(9, 297);
		this.checkDiCoNhanh.Margin = new Padding(2);
		this.checkDiCoNhanh.Name = "checkDiCoNhanh";
		this.checkDiCoNhanh.Size = new Size(175, 17);
		this.checkDiCoNhanh.TabIndex = 355;
		this.checkDiCoNhanh.TabStop = false;
		this.checkDiCoNhanh.Text = "Đi Cờ Lâu Lan Tầm Bảo Nhanh";
		this.checkDiCoNhanh.UseVisualStyleBackColor = true;
		this.checkBaoTangDoThongMinh.AutoSize = true;
		this.checkBaoTangDoThongMinh.Location = new Point(9, 276);
		this.checkBaoTangDoThongMinh.Margin = new Padding(2);
		this.checkBaoTangDoThongMinh.Name = "checkBaoTangDoThongMinh";
		this.checkBaoTangDoThongMinh.Size = new Size(150, 17);
		this.checkBaoTangDoThongMinh.TabIndex = 344;
		this.checkBaoTangDoThongMinh.TabStop = false;
		this.checkBaoTangDoThongMinh.Text = "Bảo Tàng Đồ Thông Minh";
		this.checkBaoTangDoThongMinh.UseVisualStyleBackColor = true;
		this.label17.AutoSize = true;
		this.label17.Location = new Point(6, 4);
		this.label17.Name = "label17";
		this.label17.Size = new Size(107, 13);
		this.label17.TabIndex = 336;
		this.label17.Text = "Làm Nhiệm Vụ Cấp >";
		this.checkLuuTrangThai.AutoSize = true;
		this.checkLuuTrangThai.Location = new Point(9, 360);
		this.checkLuuTrangThai.Margin = new Padding(2);
		this.checkLuuTrangThai.Name = "checkLuuTrangThai";
		this.checkLuuTrangThai.Size = new Size(147, 17);
		this.checkLuuTrangThai.TabIndex = 359;
		this.checkLuuTrangThai.TabStop = false;
		this.checkLuuTrangThai.Text = "Lưu Trạng Thái Nhân Vật";
		this.checkLuuTrangThai.UseVisualStyleBackColor = true;
		this.checkPhuBanDuNguoi.AutoSize = true;
		this.checkPhuBanDuNguoi.Location = new Point(9, 318);
		this.checkPhuBanDuNguoi.Margin = new Padding(2);
		this.checkPhuBanDuNguoi.Name = "checkPhuBanDuNguoi";
		this.checkPhuBanDuNguoi.Size = new Size(164, 17);
		this.checkPhuBanDuNguoi.TabIndex = 350;
		this.checkPhuBanDuNguoi.TabStop = false;
		this.checkPhuBanDuNguoi.Text = "Chỉ Đi Phụ Bản Khi Đủ Người";
		this.checkPhuBanDuNguoi.UseVisualStyleBackColor = true;
		this.label2.AutoSize = true;
		this.label2.Location = new Point(6, 120);
		this.label2.Name = "label2";
		this.label2.Size = new Size(108, 13);
		this.label2.TabIndex = 358;
		this.label2.Text = "Sửa Trang Bị Độ Bền";
		this.label14.AutoSize = true;
		this.label14.Location = new Point(6, 27);
		this.label14.Name = "label14";
		this.label14.Size = new Size(44, 13);
		this.label14.TabIndex = 347;
		this.label14.Text = "Tầm Xa";
		this.label16.AutoSize = true;
		this.label16.Location = new Point(6, 73);
		this.label16.Name = "label16";
		this.label16.Size = new Size(85, 13);
		this.label16.TabIndex = 339;
		this.label16.Text = "Thu Pet Khi Cấp";
		this.checkAlarmHP.AutoSize = true;
		this.checkAlarmHP.Location = new Point(9, 167);
		this.checkAlarmHP.Name = "checkAlarmHP";
		this.checkAlarmHP.Size = new Size(90, 17);
		this.checkAlarmHP.TabIndex = 342;
		this.checkAlarmHP.TabStop = false;
		this.checkAlarmHP.Text = "Báo Khi HP <";
		this.checkAlarmHP.UseVisualStyleBackColor = true;
		this.checkTriLieuHP.AutoSize = true;
		this.checkTriLieuHP.Location = new Point(9, 233);
		this.checkTriLieuHP.Name = "checkTriLieuHP";
		this.checkTriLieuHP.Size = new Size(97, 17);
		this.checkTriLieuHP.TabIndex = 344;
		this.checkTriLieuHP.TabStop = false;
		this.checkTriLieuHP.Text = "Trị Liệu Khi HP";
		this.checkTriLieuHP.UseVisualStyleBackColor = true;
		this.checkThangCap.AutoSize = true;
		this.checkThangCap.Location = new Point(9, 188);
		this.checkThangCap.Name = "checkThangCap";
		this.checkThangCap.Size = new Size(121, 17);
		this.checkThangCap.TabIndex = 202;
		this.checkThangCap.TabStop = false;
		this.checkThangCap.Text = "Thăng Cấp Khi Lv <";
		this.checkThangCap.UseVisualStyleBackColor = true;
		this.label25.AutoSize = true;
		this.label25.Location = new Point(6, 96);
		this.label25.Name = "label25";
		this.label25.Size = new Size(105, 13);
		this.label25.TabIndex = 355;
		this.label25.Text = "Chuyển Mã Tặc Sau";
		this.label13.AutoSize = true;
		this.label13.Location = new Point(6, 50);
		this.label13.Name = "label13";
		this.label13.Size = new Size(102, 13);
		this.label13.TabIndex = 323;
		this.label13.Text = "Quan Sơn Hải Tầng";
		this.checkAnGameTime.AutoSize = true;
		this.checkAnGameTime.Location = new Point(9, 210);
		this.checkAnGameTime.Name = "checkAnGameTime";
		this.checkAnGameTime.Size = new Size(105, 17);
		this.checkAnGameTime.TabIndex = 346;
		this.checkAnGameTime.TabStop = false;
		this.checkAnGameTime.Text = "Ẩn Game Tối Đa";
		this.checkAnGameTime.UseVisualStyleBackColor = true;
		this.panel1.Controls.Add(this.checkNotUseShortcutKey);
		this.panel1.Controls.Add(this.checkSkipMonter);
		this.panel1.Controls.Add(this.checkAlarmInbox);
		this.panel1.Controls.Add(this.checkNotUseRide);
		this.panel1.Controls.Add(this.checkMuteInbox);
		this.panel1.Controls.Add(this.btnBoQua);
		this.panel1.Controls.Add(this.button6);
		this.panel1.Controls.Add(this.checkAccept);
		this.panel1.Controls.Add(this.checkBuyItem);
		this.panel1.Controls.Add(this.btnAutoAccept);
		this.panel1.Controls.Add(this.btnGomDo);
		this.panel1.Controls.Add(this.checkUseCalender);
		this.panel1.Controls.Add(this.checkAntiCaptcha);
		this.panel1.Controls.Add(this.checkDropItem);
		this.panel1.Controls.Add(this.checkAcceptAll);
		this.panel1.Controls.Add(this.btnAutoBuy);
		this.panel1.Controls.Add(this.button1);
		this.panel1.Controls.Add(this.btnUseItem);
		this.panel1.Controls.Add(this.button8);
		this.panel1.Controls.Add(this.checkUseItem);
		this.panel1.Controls.Add(this.checkNemBienThan);
		this.panel1.Controls.Add(this.checkSellItem);
		this.panel1.Controls.Add(this.btnCatDo);
		this.panel1.Controls.Add(this.btnDropItemEx);
		this.panel1.Controls.Add(this.btnSellItemEx);
		this.panel1.Controls.Add(this.checkBankItem);
		this.panel1.Dock = DockStyle.Left;
		this.panel1.Location = new Point(3, 3);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(163, 424);
		this.panel1.TabIndex = 0;
		this.checkNotUseShortcutKey.AutoSize = true;
		this.checkNotUseShortcutKey.Location = new Point(3, 371);
		this.checkNotUseShortcutKey.Margin = new Padding(2);
		this.checkNotUseShortcutKey.Name = "checkNotUseShortcutKey";
		this.checkNotUseShortcutKey.Size = new Size(133, 17);
		this.checkNotUseShortcutKey.TabIndex = 367;
		this.checkNotUseShortcutKey.TabStop = false;
		this.checkNotUseShortcutKey.Text = "Không Dùng Phím Tắt";
		this.checkNotUseShortcutKey.UseVisualStyleBackColor = true;
		this.checkSkipMonter.AutoSize = true;
		this.checkSkipMonter.Location = new Point(3, 174);
		this.checkSkipMonter.Name = "checkSkipMonter";
		this.checkSkipMonter.Size = new Size(87, 17);
		this.checkSkipMonter.TabIndex = 211;
		this.checkSkipMonter.TabStop = false;
		this.checkSkipMonter.Text = "Bỏ Qua Quái";
		this.checkSkipMonter.UseVisualStyleBackColor = true;
		this.checkAlarmInbox.AutoSize = true;
		this.checkAlarmInbox.Location = new Point(3, 308);
		this.checkAlarmInbox.Margin = new Padding(2);
		this.checkAlarmInbox.Name = "checkAlarmInbox";
		this.checkAlarmInbox.Size = new Size(118, 17);
		this.checkAlarmInbox.TabIndex = 345;
		this.checkAlarmInbox.TabStop = false;
		this.checkAlarmInbox.Text = "Báo Inbox, Ác Bá...";
		this.checkAlarmInbox.UseVisualStyleBackColor = true;
		this.checkNotUseRide.AutoSize = true;
		this.checkNotUseRide.Location = new Point(3, 350);
		this.checkNotUseRide.Margin = new Padding(2);
		this.checkNotUseRide.Name = "checkNotUseRide";
		this.checkNotUseRide.Size = new Size(115, 17);
		this.checkNotUseRide.TabIndex = 366;
		this.checkNotUseRide.TabStop = false;
		this.checkNotUseRide.Text = "Không Dùng Ngựa";
		this.checkNotUseRide.UseVisualStyleBackColor = true;
		this.checkMuteInbox.AutoSize = true;
		this.checkMuteInbox.Location = new Point(3, 329);
		this.checkMuteInbox.Margin = new Padding(2);
		this.checkMuteInbox.Name = "checkMuteInbox";
		this.checkMuteInbox.Size = new Size(111, 17);
		this.checkMuteInbox.TabIndex = 281;
		this.checkMuteInbox.TabStop = false;
		this.checkMuteInbox.Text = "Tắt Âm Báo Inbox";
		this.checkMuteInbox.UseVisualStyleBackColor = true;
		this.btnBoQua.Location = new Point(95, 170);
		this.btnBoQua.Name = "btnBoQua";
		this.btnBoQua.Size = new Size(22, 22);
		this.btnBoQua.TabIndex = 212;
		this.btnBoQua.TabStop = false;
		this.btnBoQua.Text = "+";
		this.btnBoQua.UseVisualStyleBackColor = true;
		this.button6.Location = new Point(3, 27);
		this.button6.Name = "button6";
		this.button6.Size = new Size(114, 23);
		this.button6.TabIndex = 247;
		this.button6.TabStop = false;
		this.button6.Text = "Lấy Đồ";
		this.button6.UseVisualStyleBackColor = true;
		this.checkAccept.AutoSize = true;
		this.checkAccept.Location = new Point(3, 243);
		this.checkAccept.Name = "checkAccept";
		this.checkAccept.Size = new Size(62, 17);
		this.checkAccept.TabIndex = 216;
		this.checkAccept.TabStop = false;
		this.checkAccept.Text = "Đồng Ý";
		this.checkAccept.UseVisualStyleBackColor = true;
		this.checkBuyItem.AutoSize = true;
		this.checkBuyItem.Location = new Point(3, 127);
		this.checkBuyItem.Name = "checkBuyItem";
		this.checkBuyItem.Size = new Size(64, 17);
		this.checkBuyItem.TabIndex = 245;
		this.checkBuyItem.TabStop = false;
		this.checkBuyItem.Text = "Mua Đồ";
		this.checkBuyItem.UseVisualStyleBackColor = true;
		this.btnAutoAccept.Location = new Point(95, 239);
		this.btnAutoAccept.Name = "btnAutoAccept";
		this.btnAutoAccept.Size = new Size(22, 22);
		this.btnAutoAccept.TabIndex = 217;
		this.btnAutoAccept.TabStop = false;
		this.btnAutoAccept.Text = "+";
		this.btnAutoAccept.UseVisualStyleBackColor = true;
		this.btnGomDo.Location = new Point(3, 4);
		this.btnGomDo.Name = "btnGomDo";
		this.btnGomDo.Size = new Size(114, 23);
		this.btnGomDo.TabIndex = 254;
		this.btnGomDo.TabStop = false;
		this.btnGomDo.Text = "Gom Đồ";
		this.btnGomDo.UseVisualStyleBackColor = true;
		this.checkUseCalender.AutoSize = true;
		this.checkUseCalender.Location = new Point(3, 197);
		this.checkUseCalender.Name = "checkUseCalender";
		this.checkUseCalender.Size = new Size(65, 17);
		this.checkUseCalender.TabIndex = 236;
		this.checkUseCalender.TabStop = false;
		this.checkUseCalender.Text = "Bật Lịch";
		this.checkUseCalender.UseVisualStyleBackColor = true;
		this.checkAntiCaptcha.AutoSize = true;
		this.checkAntiCaptcha.Location = new Point(3, 287);
		this.checkAntiCaptcha.Margin = new Padding(2);
		this.checkAntiCaptcha.Name = "checkAntiCaptcha";
		this.checkAntiCaptcha.Size = new Size(91, 17);
		this.checkAntiCaptcha.TabIndex = 341;
		this.checkAntiCaptcha.TabStop = false;
		this.checkAntiCaptcha.Text = "Vượt Captcha";
		this.checkAntiCaptcha.UseVisualStyleBackColor = true;
		this.checkDropItem.AutoSize = true;
		this.checkDropItem.Location = new Point(3, 56);
		this.checkDropItem.Name = "checkDropItem";
		this.checkDropItem.Size = new Size(62, 17);
		this.checkDropItem.TabIndex = 204;
		this.checkDropItem.TabStop = false;
		this.checkDropItem.Text = "Hủy Đồ";
		this.checkDropItem.UseVisualStyleBackColor = true;
		this.checkAcceptAll.AutoSize = true;
		this.checkAcceptAll.Location = new Point(3, 266);
		this.checkAcceptAll.Margin = new Padding(2);
		this.checkAcceptAll.Name = "checkAcceptAll";
		this.checkAcceptAll.Size = new Size(96, 17);
		this.checkAcceptAll.TabIndex = 218;
		this.checkAcceptAll.TabStop = false;
		this.checkAcceptAll.Text = "Đồng Ý Tất cả";
		this.checkAcceptAll.UseVisualStyleBackColor = true;
		this.btnAutoBuy.Location = new Point(95, 123);
		this.btnAutoBuy.Name = "btnAutoBuy";
		this.btnAutoBuy.Size = new Size(22, 22);
		this.btnAutoBuy.TabIndex = 246;
		this.btnAutoBuy.TabStop = false;
		this.btnAutoBuy.Text = "+";
		this.btnAutoBuy.UseVisualStyleBackColor = true;
		this.button1.Location = new Point(95, 193);
		this.button1.Name = "button1";
		this.button1.Size = new Size(22, 22);
		this.button1.TabIndex = 183;
		this.button1.TabStop = false;
		this.button1.Text = "+";
		this.button1.UseVisualStyleBackColor = true;
		this.btnUseItem.Location = new Point(95, 99);
		this.btnUseItem.Name = "btnUseItem";
		this.btnUseItem.Size = new Size(22, 22);
		this.btnUseItem.TabIndex = 252;
		this.btnUseItem.TabStop = false;
		this.btnUseItem.Text = "+";
		this.btnUseItem.UseVisualStyleBackColor = true;
		this.button8.Location = new Point(95, 216);
		this.button8.Name = "button8";
		this.button8.Size = new Size(22, 22);
		this.button8.TabIndex = 311;
		this.button8.TabStop = false;
		this.button8.Text = "+";
		this.button8.UseVisualStyleBackColor = true;
		this.checkUseItem.AutoSize = true;
		this.checkUseItem.Location = new Point(3, 103);
		this.checkUseItem.Name = "checkUseItem";
		this.checkUseItem.Size = new Size(69, 17);
		this.checkUseItem.TabIndex = 251;
		this.checkUseItem.TabStop = false;
		this.checkUseItem.Text = "Dùng Đồ";
		this.checkUseItem.UseVisualStyleBackColor = true;
		this.checkNemBienThan.AutoSize = true;
		this.checkNemBienThan.Location = new Point(3, 220);
		this.checkNemBienThan.Name = "checkNemBienThan";
		this.checkNemBienThan.Size = new Size(75, 17);
		this.checkNemBienThan.TabIndex = 310;
		this.checkNemBienThan.TabStop = false;
		this.checkNemBienThan.Text = "Biến Thân";
		this.checkNemBienThan.UseVisualStyleBackColor = true;
		this.checkSellItem.AutoSize = true;
		this.checkSellItem.Location = new Point(3, 80);
		this.checkSellItem.Name = "checkSellItem";
		this.checkSellItem.Size = new Size(62, 17);
		this.checkSellItem.TabIndex = 229;
		this.checkSellItem.TabStop = false;
		this.checkSellItem.Text = "Bán Đồ";
		this.checkSellItem.UseVisualStyleBackColor = true;
		this.btnCatDo.Location = new Point(95, 147);
		this.btnCatDo.Name = "btnCatDo";
		this.btnCatDo.Size = new Size(22, 22);
		this.btnCatDo.TabIndex = 240;
		this.btnCatDo.TabStop = false;
		this.btnCatDo.Text = "+";
		this.btnCatDo.UseVisualStyleBackColor = true;
		this.btnDropItemEx.Location = new Point(95, 52);
		this.btnDropItemEx.Name = "btnDropItemEx";
		this.btnDropItemEx.Size = new Size(22, 22);
		this.btnDropItemEx.TabIndex = 232;
		this.btnDropItemEx.TabStop = false;
		this.btnDropItemEx.Text = "+";
		this.btnDropItemEx.UseVisualStyleBackColor = true;
		this.btnDropItemEx.Click += this.btnDropItemEx_Click;
		this.btnSellItemEx.Location = new Point(95, 76);
		this.btnSellItemEx.Name = "btnSellItemEx";
		this.btnSellItemEx.Size = new Size(22, 22);
		this.btnSellItemEx.TabIndex = 233;
		this.btnSellItemEx.TabStop = false;
		this.btnSellItemEx.Text = "+";
		this.btnSellItemEx.UseVisualStyleBackColor = true;
		this.checkBankItem.AutoSize = true;
		this.checkBankItem.Location = new Point(3, 151);
		this.checkBankItem.Name = "checkBankItem";
		this.checkBankItem.Size = new Size(59, 17);
		this.checkBankItem.TabIndex = 224;
		this.checkBankItem.TabStop = false;
		this.checkBankItem.Text = "Cất Đồ";
		this.checkBankItem.UseVisualStyleBackColor = true;
		this.panGameItem.Controls.Add(this.btnClose);
		this.panGameItem.Dock = DockStyle.Fill;
		this.panGameItem.Location = new Point(3, 3);
		this.panGameItem.Name = "panGameItem";
		this.panGameItem.Size = new Size(485, 424);
		this.panGameItem.TabIndex = 14;
		this.panGameItem.Visible = false;
		this.btnClose.Dock = DockStyle.Bottom;
		this.btnClose.Location = new Point(0, 401);
		this.btnClose.Name = "btnClose";
		this.btnClose.Size = new Size(485, 23);
		this.btnClose.TabIndex = 0;
		this.btnClose.Text = "Close";
		this.btnClose.UseVisualStyleBackColor = true;
		this.btnClose.Click += this.btnClose_Click;
		this.tabSettingTuDong.Controls.Add(this.flowLayoutPanel2);
		this.tabSettingTuDong.Controls.Add(this.groupBox20);
		this.tabSettingTuDong.Location = new Point(4, 4);
		this.tabSettingTuDong.Name = "tabSettingTuDong";
		this.tabSettingTuDong.Padding = new Padding(3);
		this.tabSettingTuDong.Size = new Size(491, 430);
		this.tabSettingTuDong.TabIndex = 1;
		this.tabSettingTuDong.Text = "Tự Động";
		this.tabSettingTuDong.UseVisualStyleBackColor = true;
		this.flowLayoutPanel2.Controls.Add(this.checkCongTheLuc);
		this.flowLayoutPanel2.Controls.Add(this.checkCongDiemPet);
		this.flowLayoutPanel2.Controls.Add(this.checkCatDoDayTayNai);
		this.flowLayoutPanel2.Controls.Add(this.checkBanDoDayTayNai);
		this.flowLayoutPanel2.Controls.Add(this.checkDungx2);
		this.flowLayoutPanel2.Controls.Add(this.checkMuax2);
		this.flowLayoutPanel2.Controls.Add(this.checkNhanx2LuyenCap);
		this.flowLayoutPanel2.Controls.Add(this.checkThuTieuDatTai);
		this.flowLayoutPanel2.Controls.Add(this.checkToDoiGanNhau);
		this.flowLayoutPanel2.Controls.Add(this.checkXuatPetManNhat);
		this.flowLayoutPanel2.Controls.Add(this.checkXuongNgua);
		this.flowLayoutPanel2.Controls.Add(this.checkXepTayNai);
		this.flowLayoutPanel2.Controls.Add(this.checkAutoShutDown);
		this.flowLayoutPanel2.Controls.Add(this.checkTuKeoDoi);
		this.flowLayoutPanel2.Controls.Add(this.grShutDown);
		this.flowLayoutPanel2.Dock = DockStyle.Left;
		this.flowLayoutPanel2.Location = new Point(194, 3);
		this.flowLayoutPanel2.Name = "flowLayoutPanel2";
		this.flowLayoutPanel2.Size = new Size(182, 424);
		this.flowLayoutPanel2.TabIndex = 364;
		this.checkCongTheLuc.AutoSize = true;
		this.checkCongTheLuc.Location = new Point(2, 2);
		this.checkCongTheLuc.Margin = new Padding(2);
		this.checkCongTheLuc.Name = "checkCongTheLuc";
		this.checkCongTheLuc.Size = new Size(121, 17);
		this.checkCongTheLuc.TabIndex = 351;
		this.checkCongTheLuc.TabStop = false;
		this.checkCongTheLuc.Text = "Cộng Điểm Thể Lực";
		this.checkCongTheLuc.UseVisualStyleBackColor = true;
		this.checkCongDiemPet.AutoSize = true;
		this.checkCongDiemPet.Location = new Point(2, 23);
		this.checkCongDiemPet.Margin = new Padding(2);
		this.checkCongDiemPet.Name = "checkCongDiemPet";
		this.checkCongDiemPet.Size = new Size(97, 17);
		this.checkCongDiemPet.TabIndex = 354;
		this.checkCongDiemPet.TabStop = false;
		this.checkCongDiemPet.Text = "Cộng Điểm Pet";
		this.checkCongDiemPet.UseVisualStyleBackColor = true;
		this.checkCatDoDayTayNai.AutoSize = true;
		this.checkCatDoDayTayNai.Location = new Point(2, 44);
		this.checkCatDoDayTayNai.Margin = new Padding(2);
		this.checkCatDoDayTayNai.Name = "checkCatDoDayTayNai";
		this.checkCatDoDayTayNai.Size = new Size(139, 17);
		this.checkCatDoDayTayNai.TabIndex = 359;
		this.checkCatDoDayTayNai.TabStop = false;
		this.checkCatDoDayTayNai.Text = "Cất Đồ Khi Đầy Tay Nải";
		this.checkCatDoDayTayNai.UseVisualStyleBackColor = true;
		this.checkBanDoDayTayNai.AutoSize = true;
		this.checkBanDoDayTayNai.Location = new Point(2, 65);
		this.checkBanDoDayTayNai.Margin = new Padding(2);
		this.checkBanDoDayTayNai.Name = "checkBanDoDayTayNai";
		this.checkBanDoDayTayNai.Size = new Size(142, 17);
		this.checkBanDoDayTayNai.TabIndex = 345;
		this.checkBanDoDayTayNai.TabStop = false;
		this.checkBanDoDayTayNai.Text = "Bán Đồ Khi Đầy Tay Nải";
		this.checkBanDoDayTayNai.UseVisualStyleBackColor = true;
		this.checkDungx2.AutoSize = true;
		this.checkDungx2.Location = new Point(2, 86);
		this.checkDungx2.Margin = new Padding(2);
		this.checkDungx2.Name = "checkDungx2";
		this.checkDungx2.Size = new Size(118, 17);
		this.checkDungx2.TabIndex = 346;
		this.checkDungx2.TabStop = false;
		this.checkDungx2.Text = "Dùng x2 Khi Hết x2";
		this.checkDungx2.UseVisualStyleBackColor = true;
		this.checkMuax2.AutoSize = true;
		this.checkMuax2.Location = new Point(2, 107);
		this.checkMuax2.Margin = new Padding(2);
		this.checkMuax2.Name = "checkMuax2";
		this.checkMuax2.Size = new Size(113, 17);
		this.checkMuax2.TabIndex = 348;
		this.checkMuax2.TabStop = false;
		this.checkMuax2.Text = "Mua x2 Khi Hết x2";
		this.checkMuax2.UseVisualStyleBackColor = true;
		this.checkNhanx2LuyenCap.AutoSize = true;
		this.checkNhanx2LuyenCap.Location = new Point(2, 128);
		this.checkNhanx2LuyenCap.Margin = new Padding(2);
		this.checkNhanx2LuyenCap.Name = "checkNhanx2LuyenCap";
		this.checkNhanx2LuyenCap.Size = new Size(162, 17);
		this.checkNhanx2LuyenCap.TabIndex = 349;
		this.checkNhanx2LuyenCap.TabStop = false;
		this.checkNhanx2LuyenCap.Text = "Nhận x2 Khi Làm Cốt Truyện";
		this.checkNhanx2LuyenCap.UseVisualStyleBackColor = true;
		this.checkThuTieuDatTai.AutoSize = true;
		this.checkThuTieuDatTai.Location = new Point(2, 149);
		this.checkThuTieuDatTai.Margin = new Padding(2);
		this.checkThuTieuDatTai.Name = "checkThuTieuDatTai";
		this.checkThuTieuDatTai.Size = new Size(167, 17);
		this.checkThuTieuDatTai.TabIndex = 331;
		this.checkThuTieuDatTai.TabStop = false;
		this.checkThuTieuDatTai.Text = "Thu Pet tieudattai Khi Hồi Khí";
		this.checkThuTieuDatTai.UseVisualStyleBackColor = true;
		this.checkToDoiGanNhau.AutoSize = true;
		this.checkToDoiGanNhau.Location = new Point(2, 170);
		this.checkToDoiGanNhau.Margin = new Padding(2);
		this.checkToDoiGanNhau.Name = "checkToDoiGanNhau";
		this.checkToDoiGanNhau.Size = new Size(110, 17);
		this.checkToDoiGanNhau.TabIndex = 343;
		this.checkToDoiGanNhau.TabStop = false;
		this.checkToDoiGanNhau.Text = "Tổ Đội Gần Nhau";
		this.checkToDoiGanNhau.UseVisualStyleBackColor = true;
		this.checkXuatPetManNhat.AutoSize = true;
		this.checkXuatPetManNhat.Location = new Point(2, 191);
		this.checkXuatPetManNhat.Margin = new Padding(2);
		this.checkXuatPetManNhat.Name = "checkXuatPetManNhat";
		this.checkXuatPetManNhat.Size = new Size(123, 17);
		this.checkXuatPetManNhat.TabIndex = 351;
		this.checkXuatPetManNhat.TabStop = false;
		this.checkXuatPetManNhat.Text = "Xuất Pet Mạnh Nhất";
		this.checkXuatPetManNhat.UseVisualStyleBackColor = true;
		this.checkXuongNgua.AutoSize = true;
		this.checkXuongNgua.Location = new Point(2, 212);
		this.checkXuongNgua.Margin = new Padding(2);
		this.checkXuongNgua.Name = "checkXuongNgua";
		this.checkXuongNgua.Size = new Size(161, 17);
		this.checkXuongNgua.TabIndex = 353;
		this.checkXuongNgua.TabStop = false;
		this.checkXuongNgua.Text = "Xuống Ngựa Khi Đứng Im 6s";
		this.checkXuongNgua.UseVisualStyleBackColor = true;
		this.checkXepTayNai.AutoSize = true;
		this.checkXepTayNai.Location = new Point(2, 233);
		this.checkXepTayNai.Margin = new Padding(2);
		this.checkXepTayNai.Name = "checkXepTayNai";
		this.checkXepTayNai.Size = new Size(107, 17);
		this.checkXepTayNai.TabIndex = 338;
		this.checkXepTayNai.TabStop = false;
		this.checkXepTayNai.Text = "Sắp Xếp Tay Nải";
		this.checkXepTayNai.UseVisualStyleBackColor = true;
		this.checkAutoShutDown.AutoSize = true;
		this.checkAutoShutDown.Location = new Point(2, 254);
		this.checkAutoShutDown.Margin = new Padding(2);
		this.checkAutoShutDown.Name = "checkAutoShutDown";
		this.checkAutoShutDown.Size = new Size(156, 17);
		this.checkAutoShutDown.TabIndex = 328;
		this.checkAutoShutDown.TabStop = false;
		this.checkAutoShutDown.Text = "Tắt Máy Sau Khi Hết Game";
		this.checkAutoShutDown.UseVisualStyleBackColor = true;
		this.checkTuKeoDoi.AutoSize = true;
		this.checkTuKeoDoi.Location = new Point(2, 275);
		this.checkTuKeoDoi.Margin = new Padding(2);
		this.checkTuKeoDoi.Name = "checkTuKeoDoi";
		this.checkTuKeoDoi.Size = new Size(139, 17);
		this.checkTuKeoDoi.TabIndex = 361;
		this.checkTuKeoDoi.TabStop = false;
		this.checkTuKeoDoi.Text = "Kéo Đội Khi Đi Phụ Bản";
		this.checkTuKeoDoi.UseVisualStyleBackColor = true;
		this.grShutDown.Boolean_0 = false;
		this.grShutDown.CheckState_0 = CheckState.Unchecked;
		this.grShutDown.Controls.Add(this.label3);
		this.grShutDown.Controls.Add(this.textBox31);
		this.grShutDown.Controls.Add(this.textBox30);
		this.grShutDown.Dock = DockStyle.Bottom;
		this.grShutDown.Location = new Point(3, 297);
		this.grShutDown.Name = "grShutDown";
		this.grShutDown.Size = new Size(169, 41);
		this.grShutDown.TabIndex = 359;
		this.grShutDown.TabStop = false;
		this.grShutDown.Text = "Tắt Máy Vào";
		this.label3.AutoSize = true;
		this.label3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.label3.Location = new Point(79, 18);
		this.label3.Name = "label3";
		this.label3.Size = new Size(11, 13);
		this.label3.TabIndex = 367;
		this.label3.Text = ":";
		this.textBox31.Location = new Point(93, 15);
		this.textBox31.Name = "textBox31";
		this.textBox31.Size = new Size(70, 20);
		this.textBox31.TabIndex = 366;
		this.textBox30.Location = new Point(6, 15);
		this.textBox30.Name = "textBox30";
		this.textBox30.Size = new Size(70, 20);
		this.textBox30.TabIndex = 365;
		this.groupBox20.Controls.Add(this.flowLayoutPanel5);
		this.groupBox20.Dock = DockStyle.Left;
		this.groupBox20.Location = new Point(3, 3);
		this.groupBox20.Name = "groupBox20";
		this.groupBox20.Size = new Size(191, 424);
		this.groupBox20.TabIndex = 355;
		this.groupBox20.TabStop = false;
		this.groupBox20.Text = "Khuyên Dùng";
		this.flowLayoutPanel5.Controls.Add(this.groupBox7);
		this.flowLayoutPanel5.Controls.Add(this.checkDatSkillF1);
		this.flowLayoutPanel5.Controls.Add(this.checkDatAnToan);
		this.flowLayoutPanel5.Controls.Add(this.checkResetCanQuet);
		this.flowLayoutPanel5.Controls.Add(this.checkHoTro);
		this.flowLayoutPanel5.Controls.Add(this.checkDungSkillPet);
		this.flowLayoutPanel5.Controls.Add(this.checkChucPhuc);
		this.flowLayoutPanel5.Controls.Add(this.checkDiemDanh);
		this.flowLayoutPanel5.Controls.Add(this.checkHoiSinh);
		this.flowLayoutPanel5.Controls.Add(this.checkNgamyHoiSinh);
		this.flowLayoutPanel5.Controls.Add(this.checkDauThai);
		this.flowLayoutPanel5.Dock = DockStyle.Fill;
		this.flowLayoutPanel5.Location = new Point(3, 16);
		this.flowLayoutPanel5.Name = "flowLayoutPanel5";
		this.flowLayoutPanel5.Size = new Size(185, 405);
		this.flowLayoutPanel5.TabIndex = 0;
		this.groupBox7.Controls.Add(this.checkKhiBanRac);
		this.groupBox7.Controls.Add(this.checkKhiDungDo);
		this.groupBox7.Controls.Add(this.checkKhiGomDo);
		this.groupBox7.Controls.Add(this.checkKhiPhanGiai);
		this.groupBox7.Controls.Add(this.checkKhiCatDo);
		this.groupBox7.Location = new Point(3, 3);
		this.groupBox7.Name = "groupBox7";
		this.groupBox7.Size = new Size(169, 133);
		this.groupBox7.TabIndex = 320;
		this.groupBox7.TabStop = false;
		this.groupBox7.Text = "Lấy Đồ Trong Túi Thiên Cơ";
		this.checkKhiBanRac.AutoSize = true;
		this.checkKhiBanRac.Location = new Point(6, 19);
		this.checkKhiBanRac.Name = "checkKhiBanRac";
		this.checkKhiBanRac.Size = new Size(86, 17);
		this.checkKhiBanRac.TabIndex = 315;
		this.checkKhiBanRac.TabStop = false;
		this.checkKhiBanRac.Text = "Khi Bán Rác";
		this.checkKhiBanRac.UseVisualStyleBackColor = true;
		this.checkKhiDungDo.AutoSize = true;
		this.checkKhiDungDo.Location = new Point(6, 111);
		this.checkKhiDungDo.Name = "checkKhiDungDo";
		this.checkKhiDungDo.Size = new Size(87, 17);
		this.checkKhiDungDo.TabIndex = 319;
		this.checkKhiDungDo.TabStop = false;
		this.checkKhiDungDo.Text = "Khi Dùng Đồ";
		this.checkKhiDungDo.UseVisualStyleBackColor = true;
		this.checkKhiGomDo.AutoSize = true;
		this.checkKhiGomDo.Location = new Point(6, 42);
		this.checkKhiGomDo.Name = "checkKhiGomDo";
		this.checkKhiGomDo.Size = new Size(83, 17);
		this.checkKhiGomDo.TabIndex = 316;
		this.checkKhiGomDo.TabStop = false;
		this.checkKhiGomDo.Text = "Khi Gom Đồ";
		this.checkKhiGomDo.UseVisualStyleBackColor = true;
		this.checkKhiPhanGiai.AutoSize = true;
		this.checkKhiPhanGiai.Location = new Point(6, 88);
		this.checkKhiPhanGiai.Name = "checkKhiPhanGiai";
		this.checkKhiPhanGiai.Size = new Size(152, 17);
		this.checkKhiPhanGiai.TabIndex = 318;
		this.checkKhiPhanGiai.TabStop = false;
		this.checkKhiPhanGiai.Text = "Khi Phân Giải Trang Bị Pet";
		this.checkKhiPhanGiai.UseVisualStyleBackColor = true;
		this.checkKhiCatDo.AutoSize = true;
		this.checkKhiCatDo.Location = new Point(6, 65);
		this.checkKhiCatDo.Name = "checkKhiCatDo";
		this.checkKhiCatDo.Size = new Size(161, 17);
		this.checkKhiCatDo.TabIndex = 317;
		this.checkKhiCatDo.TabStop = false;
		this.checkKhiCatDo.Text = "Khi Cất Đồ Vào Thương Khố";
		this.checkKhiCatDo.UseVisualStyleBackColor = true;
		this.checkDatSkillF1.AutoSize = true;
		this.checkDatSkillF1.Location = new Point(2, 141);
		this.checkDatSkillF1.Margin = new Padding(2);
		this.checkDatSkillF1.Name = "checkDatSkillF1";
		this.checkDatSkillF1.Size = new Size(140, 17);
		this.checkDatSkillF1.TabIndex = 332;
		this.checkDatSkillF1.TabStop = false;
		this.checkDatSkillF1.Text = "Đặt Skill Cơ Bản Vào F1";
		this.checkDatSkillF1.UseVisualStyleBackColor = true;
		this.checkDatAnToan.AutoSize = true;
		this.checkDatAnToan.Location = new Point(2, 162);
		this.checkDatAnToan.Margin = new Padding(2);
		this.checkDatAnToan.Name = "checkDatAnToan";
		this.checkDatAnToan.Size = new Size(170, 17);
		this.checkDatAnToan.TabIndex = 341;
		this.checkDatAnToan.TabStop = false;
		this.checkDatAnToan.Text = "Đặt Thời Gian An Toàn 1 Phút";
		this.checkDatAnToan.UseVisualStyleBackColor = true;
		this.checkResetCanQuet.AutoSize = true;
		this.checkResetCanQuet.Location = new Point(2, 183);
		this.checkResetCanQuet.Margin = new Padding(2);
		this.checkResetCanQuet.Name = "checkResetCanQuet";
		this.checkResetCanQuet.Size = new Size(152, 17);
		this.checkResetCanQuet.TabIndex = 350;
		this.checkResetCanQuet.TabStop = false;
		this.checkResetCanQuet.Text = "Chạy Lại Càn Quét Vào 0h";
		this.checkResetCanQuet.UseVisualStyleBackColor = true;
		this.checkHoTro.AutoSize = true;
		this.checkHoTro.Location = new Point(2, 204);
		this.checkHoTro.Margin = new Padding(2);
		this.checkHoTro.Name = "checkHoTro";
		this.checkHoTro.Size = new Size(105, 17);
		this.checkHoTro.TabIndex = 362;
		this.checkHoTro.TabStop = false;
		this.checkHoTro.Text = "Né Bẫy Phụ Bản";
		this.checkHoTro.UseVisualStyleBackColor = true;
		this.checkDungSkillPet.AutoSize = true;
		this.checkDungSkillPet.Location = new Point(2, 225);
		this.checkDungSkillPet.Margin = new Padding(2);
		this.checkDungSkillPet.Name = "checkDungSkillPet";
		this.checkDungSkillPet.Size = new Size(93, 17);
		this.checkDungSkillPet.TabIndex = 335;
		this.checkDungSkillPet.TabStop = false;
		this.checkDungSkillPet.Text = "Dùng Skill Pet";
		this.checkDungSkillPet.UseVisualStyleBackColor = true;
		this.checkChucPhuc.AutoSize = true;
		this.checkChucPhuc.Location = new Point(2, 246);
		this.checkChucPhuc.Margin = new Padding(2);
		this.checkChucPhuc.Name = "checkChucPhuc";
		this.checkChucPhuc.Size = new Size(125, 17);
		this.checkChucPhuc.TabIndex = 352;
		this.checkChucPhuc.TabStop = false;
		this.checkChucPhuc.Text = "Chúc Phúc Hảo Hữu";
		this.checkChucPhuc.UseVisualStyleBackColor = true;
		this.checkDiemDanh.AutoSize = true;
		this.checkDiemDanh.Location = new Point(2, 267);
		this.checkDiemDanh.Margin = new Padding(2);
		this.checkDiemDanh.Name = "checkDiemDanh";
		this.checkDiemDanh.Size = new Size(79, 17);
		this.checkDiemDanh.TabIndex = 354;
		this.checkDiemDanh.TabStop = false;
		this.checkDiemDanh.Text = "Điểm Danh";
		this.checkDiemDanh.UseVisualStyleBackColor = true;
		this.checkHoiSinh.AutoSize = true;
		this.checkHoiSinh.Location = new Point(85, 267);
		this.checkHoiSinh.Margin = new Padding(2);
		this.checkHoiSinh.Name = "checkHoiSinh";
		this.checkHoiSinh.Size = new Size(66, 17);
		this.checkHoiSinh.TabIndex = 329;
		this.checkHoiSinh.TabStop = false;
		this.checkHoiSinh.Text = "Hồi Sinh";
		this.checkHoiSinh.UseVisualStyleBackColor = true;
		this.checkNgamyHoiSinh.AutoSize = true;
		this.checkNgamyHoiSinh.Location = new Point(2, 288);
		this.checkNgamyHoiSinh.Margin = new Padding(2);
		this.checkNgamyHoiSinh.Name = "checkNgamyHoiSinh";
		this.checkNgamyHoiSinh.Size = new Size(154, 17);
		this.checkNgamyHoiSinh.TabIndex = 330;
		this.checkNgamyHoiSinh.TabStop = false;
		this.checkNgamyHoiSinh.Text = "Nga My Hồi Sinh Đồng Đội";
		this.checkNgamyHoiSinh.UseVisualStyleBackColor = true;
		this.checkDauThai.AutoSize = true;
		this.checkDauThai.Location = new Point(2, 309);
		this.checkDauThai.Margin = new Padding(2);
		this.checkDauThai.Name = "checkDauThai";
		this.checkDauThai.Size = new Size(70, 17);
		this.checkDauThai.TabIndex = 268;
		this.checkDauThai.TabStop = false;
		this.checkDauThai.Text = "Đầu Thai";
		this.checkDauThai.UseVisualStyleBackColor = true;
		this.tabSettingTuyChon.Controls.Add(this.flowLayoutPanel4);
		this.tabSettingTuyChon.Controls.Add(this.flowLayoutPanel3);
		this.tabSettingTuyChon.Location = new Point(4, 4);
		this.tabSettingTuyChon.Name = "tabSettingTuyChon";
		this.tabSettingTuyChon.Padding = new Padding(3);
		this.tabSettingTuyChon.Size = new Size(491, 430);
		this.tabSettingTuyChon.TabIndex = 2;
		this.tabSettingTuyChon.Text = "Tùy Chọn";
		this.tabSettingTuyChon.UseVisualStyleBackColor = true;
		this.flowLayoutPanel4.Controls.Add(this.groupBox11);
		this.flowLayoutPanel4.Controls.Add(this.groupBox12);
		this.flowLayoutPanel4.Controls.Add(this.groupBox5);
		this.flowLayoutPanel4.Controls.Add(this.groupBox4);
		this.flowLayoutPanel4.Controls.Add(this.groupBox6);
		this.flowLayoutPanel4.Controls.Add(this.chkCanQuetx2);
		this.flowLayoutPanel4.Controls.Add(this.chkHold);
		this.flowLayoutPanel4.Controls.Add(this.chkAutoResetTime);
		this.flowLayoutPanel4.Dock = DockStyle.Left;
		this.flowLayoutPanel4.Location = new Point(156, 3);
		this.flowLayoutPanel4.Name = "flowLayoutPanel4";
		this.flowLayoutPanel4.Padding = new Padding(3, 0, 0, 0);
		this.flowLayoutPanel4.Size = new Size(234, 424);
		this.flowLayoutPanel4.TabIndex = 344;
		this.groupBox11.Controls.Add(this.cboMapDua);
		this.groupBox11.Location = new Point(6, 3);
		this.groupBox11.Name = "groupBox11";
		this.groupBox11.Size = new Size(195, 44);
		this.groupBox11.TabIndex = 359;
		this.groupBox11.TabStop = false;
		this.groupBox11.Text = "Dưa Hấu";
		this.cboMapDua.Dock = DockStyle.Fill;
		this.cboMapDua.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboMapDua.FormattingEnabled = true;
		this.cboMapDua.Items.AddRange(new object[]
		{
			"Tây Hồ",
			"Nhĩ Hải",
			"Map Gần Bang"
		});
		this.cboMapDua.Location = new Point(3, 16);
		this.cboMapDua.Name = "cboMapDua";
		this.cboMapDua.Size = new Size(189, 21);
		this.cboMapDua.TabIndex = 332;
		this.cboMapDua.TabStop = false;
		this.groupBox12.Controls.Add(this.cboMenpai);
		this.groupBox12.Location = new Point(6, 53);
		this.groupBox12.Name = "groupBox12";
		this.groupBox12.Size = new Size(195, 44);
		this.groupBox12.TabIndex = 360;
		this.groupBox12.TabStop = false;
		this.groupBox12.Text = "Tự Vào Phái";
		this.cboMenpai.Dock = DockStyle.Fill;
		this.cboMenpai.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboMenpai.FormattingEnabled = true;
		this.cboMenpai.Items.AddRange(new object[]
		{
			"Thiếu Lâm",
			"Minh Giáo",
			"Cái Bang",
			"Võ Đang (Đánh Xa)",
			"Nga My (Đánh Xa)",
			"Tinh Túc (Đánh Xa)",
			"Thiên Long (Đánh Xa)",
			"Thiên Sơn",
			"Tiêu Dao (Đánh Xa)",
			"Mộ Dung",
			"Đường Môn (Đánh Xa)",
			"Quỷ Cốc",
			"Đào Hoa",
			"Để Tôi Tự Vào"
		});
		this.cboMenpai.Location = new Point(3, 16);
		this.cboMenpai.Name = "cboMenpai";
		this.cboMenpai.Size = new Size(189, 21);
		this.cboMenpai.TabIndex = 331;
		this.cboMenpai.TabStop = false;
		this.groupBox5.Controls.Add(this.textBox37);
		this.groupBox5.Controls.Add(this.textBox36);
		this.groupBox5.Controls.Add(this.btnBuyDaiLy);
		this.groupBox5.Controls.Add(this.label8);
		this.groupBox5.Controls.Add(this.label6);
		this.groupBox5.Location = new Point(6, 103);
		this.groupBox5.Name = "groupBox5";
		this.groupBox5.Size = new Size(195, 44);
		this.groupBox5.TabIndex = 312;
		this.groupBox5.TabStop = false;
		this.groupBox5.Text = "Mở Hộp Tại Đại Lý";
		this.textBox37.Location = new Point(92, 15);
		this.textBox37.Name = "textBox37";
		this.textBox37.Size = new Size(46, 20);
		this.textBox37.TabIndex = 367;
		this.textBox36.Location = new Point(22, 15);
		this.textBox36.Name = "textBox36";
		this.textBox36.Size = new Size(46, 20);
		this.textBox36.TabIndex = 366;
		this.btnBuyDaiLy.Location = new Point(142, 13);
		this.btnBuyDaiLy.Name = "btnBuyDaiLy";
		this.btnBuyDaiLy.Size = new Size(48, 23);
		this.btnBuyDaiLy.TabIndex = 48;
		this.btnBuyDaiLy.TabStop = false;
		this.btnBuyDaiLy.Text = "Mua";
		this.btnBuyDaiLy.UseVisualStyleBackColor = true;
		this.label8.AutoSize = true;
		this.label8.Location = new Point(74, 18);
		this.label8.Name = "label8";
		this.label8.Size = new Size(12, 13);
		this.label8.TabIndex = 47;
		this.label8.Text = "y";
		this.label6.AutoSize = true;
		this.label6.Location = new Point(10, 18);
		this.label6.Name = "label6";
		this.label6.Size = new Size(12, 13);
		this.label6.TabIndex = 46;
		this.label6.Text = "x";
		this.groupBox4.Controls.Add(this.textBox35);
		this.groupBox4.Controls.Add(this.textBox34);
		this.groupBox4.Controls.Add(this.textBox33);
		this.groupBox4.Controls.Add(this.label15);
		this.groupBox4.Location = new Point(6, 153);
		this.groupBox4.Name = "groupBox4";
		this.groupBox4.Size = new Size(195, 44);
		this.groupBox4.TabIndex = 343;
		this.groupBox4.TabStop = false;
		this.groupBox4.Text = "Thổi Bóng";
		this.textBox35.Location = new Point(144, 16);
		this.textBox35.Name = "textBox35";
		this.textBox35.Size = new Size(46, 20);
		this.textBox35.TabIndex = 368;
		this.textBox34.Location = new Point(74, 16);
		this.textBox34.Name = "textBox34";
		this.textBox34.Size = new Size(46, 20);
		this.textBox34.TabIndex = 367;
		this.textBox33.Location = new Point(22, 16);
		this.textBox33.Name = "textBox33";
		this.textBox33.Size = new Size(46, 20);
		this.textBox33.TabIndex = 366;
		this.label15.AutoSize = true;
		this.label15.Location = new Point(126, 19);
		this.label15.Name = "label15";
		this.label15.Size = new Size(12, 13);
		this.label15.TabIndex = 289;
		this.label15.Text = "x";
		this.groupBox6.Controls.Add(this.numberDelay);
		this.groupBox6.Location = new Point(6, 203);
		this.groupBox6.Name = "groupBox6";
		this.groupBox6.Size = new Size(195, 48);
		this.groupBox6.TabIndex = 347;
		this.groupBox6.TabStop = false;
		this.groupBox6.Text = "Tốc Độ Auto";
		this.numberDelay.BackColor = Color.Transparent;
		this.numberDelay.Color_4 = Color.Red;
		this.numberDelay.Size_1 = new Size(8, 8);
		this.numberDelay.Dock = DockStyle.Fill;
		this.numberDelay.UInt32_1 = 5U;
		this.numberDelay.Location = new Point(3, 16);
		this.numberDelay.Int32_3 = 3000;
		this.numberDelay.Int32_2 = 50;
		this.numberDelay.Name = "numberDelay";
		this.numberDelay.Size = new Size(189, 29);
		this.numberDelay.UInt32_0 = 1U;
		this.numberDelay.TabIndex = 31;
		this.numberDelay.TabStop = false;
		this.numberDelay.Text = "colorSlider1";
		this.numberDelay.Size_0 = new Size(8, 8);
		this.numberDelay.Int32_1 = 700;
		this.chkCanQuetx2.AutoSize = true;
		this.chkCanQuetx2.Location = new Point(5, 256);
		this.chkCanQuetx2.Margin = new Padding(2);
		this.chkCanQuetx2.Name = "chkCanQuetx2";
		this.chkCanQuetx2.Size = new Size(85, 17);
		this.chkCanQuetx2.TabIndex = 342;
		this.chkCanQuetx2.TabStop = false;
		this.chkCanQuetx2.Text = "Càn Quét x2";
		this.chkCanQuetx2.UseVisualStyleBackColor = true;
		this.chkHold.AutoSize = true;
		this.chkHold.Location = new Point(5, 277);
		this.chkHold.Margin = new Padding(2);
		this.chkHold.Name = "chkHold";
		this.chkHold.Size = new Size(191, 17);
		this.chkHold.TabIndex = 330;
		this.chkHold.TabStop = false;
		this.chkHold.Text = "Đứng Im Khi Thổ Linh Châu Về Bãi";
		this.chkHold.UseVisualStyleBackColor = true;
		this.chkAutoResetTime.AutoSize = true;
		this.chkAutoResetTime.Location = new Point(5, 298);
		this.chkAutoResetTime.Margin = new Padding(2);
		this.chkAutoResetTime.Name = "chkAutoResetTime";
		this.chkAutoResetTime.Size = new Size(80, 17);
		this.chkAutoResetTime.TabIndex = 327;
		this.chkAutoResetTime.TabStop = false;
		this.chkAutoResetTime.Text = "Reset Time";
		this.chkAutoResetTime.UseVisualStyleBackColor = true;
		this.flowLayoutPanel3.Controls.Add(this.groupBox19);
		this.flowLayoutPanel3.Controls.Add(this.groupBox18);
		this.flowLayoutPanel3.Controls.Add(this.groupBox16);
		this.flowLayoutPanel3.Controls.Add(this.groupBox17);
		this.flowLayoutPanel3.Controls.Add(this.groupBox10);
		this.flowLayoutPanel3.Dock = DockStyle.Left;
		this.flowLayoutPanel3.Location = new Point(3, 3);
		this.flowLayoutPanel3.Name = "flowLayoutPanel3";
		this.flowLayoutPanel3.Size = new Size(153, 424);
		this.flowLayoutPanel3.TabIndex = 361;
		this.groupBox19.Controls.Add(this.checkUseSelectServer);
		this.groupBox19.Controls.Add(this.checkLuonAnGame);
		this.groupBox19.Controls.Add(this.checkKhongChiemManHinh);
		this.groupBox19.Location = new Point(0, 0);
		this.groupBox19.Margin = new Padding(0);
		this.groupBox19.Name = "groupBox19";
		this.groupBox19.Padding = new Padding(0);
		this.groupBox19.Size = new Size(147, 79);
		this.groupBox19.TabIndex = 362;
		this.groupBox19.TabStop = false;
		this.groupBox19.Text = "Game";
		this.checkUseSelectServer.AutoSize = true;
		this.checkUseSelectServer.Location = new Point(2, 36);
		this.checkUseSelectServer.Margin = new Padding(2);
		this.checkUseSelectServer.Name = "checkUseSelectServer";
		this.checkUseSelectServer.Size = new Size(125, 17);
		this.checkUseSelectServer.TabIndex = 326;
		this.checkUseSelectServer.TabStop = false;
		this.checkUseSelectServer.Text = "Dùng Chọn Máy Chủ";
		this.checkUseSelectServer.UseVisualStyleBackColor = true;
		this.checkLuonAnGame.AutoSize = true;
		this.checkLuonAnGame.Location = new Point(2, 15);
		this.checkLuonAnGame.Margin = new Padding(2);
		this.checkLuonAnGame.Name = "checkLuonAnGame";
		this.checkLuonAnGame.Size = new Size(66, 17);
		this.checkLuonAnGame.TabIndex = 326;
		this.checkLuonAnGame.TabStop = false;
		this.checkLuonAnGame.Text = "Luôn Ẩn";
		this.checkLuonAnGame.UseVisualStyleBackColor = true;
		this.checkKhongChiemManHinh.AutoSize = true;
		this.checkKhongChiemManHinh.Location = new Point(2, 57);
		this.checkKhongChiemManHinh.Margin = new Padding(2);
		this.checkKhongChiemManHinh.Name = "checkKhongChiemManHinh";
		this.checkKhongChiemManHinh.Size = new Size(138, 17);
		this.checkKhongChiemManHinh.TabIndex = 360;
		this.checkKhongChiemManHinh.TabStop = false;
		this.checkKhongChiemManHinh.Text = "Không Chiếm Màn Hình";
		this.checkKhongChiemManHinh.UseVisualStyleBackColor = true;
		this.groupBox18.Controls.Add(this.checkBuffPet);
		this.groupBox18.Controls.Add(this.checkBuffQuanDoan);
		this.groupBox18.Location = new Point(0, 79);
		this.groupBox18.Margin = new Padding(0);
		this.groupBox18.Name = "groupBox18";
		this.groupBox18.Padding = new Padding(0);
		this.groupBox18.Size = new Size(148, 59);
		this.groupBox18.TabIndex = 345;
		this.groupBox18.TabStop = false;
		this.groupBox18.Text = "Ngamy";
		this.checkBuffPet.AutoSize = true;
		this.checkBuffPet.Location = new Point(2, 15);
		this.checkBuffPet.Margin = new Padding(2);
		this.checkBuffPet.Name = "checkBuffPet";
		this.checkBuffPet.Size = new Size(64, 17);
		this.checkBuffPet.TabIndex = 336;
		this.checkBuffPet.TabStop = false;
		this.checkBuffPet.Text = "Buff Pet";
		this.checkBuffPet.UseVisualStyleBackColor = true;
		this.checkBuffQuanDoan.AutoSize = true;
		this.checkBuffQuanDoan.Location = new Point(2, 36);
		this.checkBuffQuanDoan.Margin = new Padding(2);
		this.checkBuffQuanDoan.Name = "checkBuffQuanDoan";
		this.checkBuffQuanDoan.Size = new Size(103, 17);
		this.checkBuffQuanDoan.TabIndex = 334;
		this.checkBuffQuanDoan.TabStop = false;
		this.checkBuffQuanDoan.Text = "Buff Quân Đoàn";
		this.checkBuffQuanDoan.UseVisualStyleBackColor = true;
		this.groupBox16.Controls.Add(this.checkNeBinh);
		this.groupBox16.Controls.Add(this.checkBossCuoi);
		this.groupBox16.Location = new Point(0, 138);
		this.groupBox16.Margin = new Padding(0);
		this.groupBox16.Name = "groupBox16";
		this.groupBox16.Padding = new Padding(0);
		this.groupBox16.Size = new Size(148, 59);
		this.groupBox16.TabIndex = 361;
		this.groupBox16.TabStop = false;
		this.groupBox16.Text = "Thiếu Thất Sơn";
		this.checkNeBinh.AutoSize = true;
		this.checkNeBinh.Location = new Point(2, 15);
		this.checkNeBinh.Margin = new Padding(2);
		this.checkNeBinh.Name = "checkNeBinh";
		this.checkNeBinh.Size = new Size(64, 17);
		this.checkNeBinh.TabIndex = 353;
		this.checkNeBinh.TabStop = false;
		this.checkNeBinh.Text = "Né Bình";
		this.checkNeBinh.UseVisualStyleBackColor = true;
		this.checkBossCuoi.AutoSize = true;
		this.checkBossCuoi.Location = new Point(2, 36);
		this.checkBossCuoi.Margin = new Padding(2);
		this.checkBossCuoi.Name = "checkBossCuoi";
		this.checkBossCuoi.Size = new Size(89, 17);
		this.checkBossCuoi.TabIndex = 341;
		this.checkBossCuoi.TabStop = false;
		this.checkBossCuoi.Text = "Bỏ Boss Cuối";
		this.checkBossCuoi.UseVisualStyleBackColor = true;
		this.groupBox17.Controls.Add(this.checkAlarmPk);
		this.groupBox17.Controls.Add(this.checkDanhTra);
		this.groupBox17.Controls.Add(this.checkPKNgaMy);
		this.groupBox17.Location = new Point(0, 197);
		this.groupBox17.Margin = new Padding(0);
		this.groupBox17.Name = "groupBox17";
		this.groupBox17.Padding = new Padding(0);
		this.groupBox17.Size = new Size(148, 81);
		this.groupBox17.TabIndex = 345;
		this.groupBox17.TabStop = false;
		this.groupBox17.Text = "PK";
		this.checkAlarmPk.AutoSize = true;
		this.checkAlarmPk.Location = new Point(2, 15);
		this.checkAlarmPk.Margin = new Padding(2);
		this.checkAlarmPk.Name = "checkAlarmPk";
		this.checkAlarmPk.Size = new Size(74, 17);
		this.checkAlarmPk.TabIndex = 338;
		this.checkAlarmPk.TabStop = false;
		this.checkAlarmPk.Text = "Báo Động";
		this.checkAlarmPk.UseVisualStyleBackColor = true;
		this.checkDanhTra.AutoSize = true;
		this.checkDanhTra.Location = new Point(2, 36);
		this.checkDanhTra.Margin = new Padding(2);
		this.checkDanhTra.Name = "checkDanhTra";
		this.checkDanhTra.Size = new Size(71, 17);
		this.checkDanhTra.TabIndex = 337;
		this.checkDanhTra.TabStop = false;
		this.checkDanhTra.Text = "Đánh Trả";
		this.checkDanhTra.UseVisualStyleBackColor = true;
		this.checkPKNgaMy.AutoSize = true;
		this.checkPKNgaMy.Location = new Point(2, 57);
		this.checkPKNgaMy.Margin = new Padding(2);
		this.checkPKNgaMy.Name = "checkPKNgaMy";
		this.checkPKNgaMy.Size = new Size(104, 17);
		this.checkPKNgaMy.TabIndex = 339;
		this.checkPKNgaMy.TabStop = false;
		this.checkPKNgaMy.Text = "Ưu Tiên Nga My";
		this.checkPKNgaMy.UseVisualStyleBackColor = true;
		this.groupBox10.Controls.Add(this.label4);
		this.groupBox10.Controls.Add(this.chkHuyBatPet);
		this.groupBox10.Controls.Add(this.checkKhongDungDongMon);
		this.groupBox10.Controls.Add(this.numberMaxSuMon);
		this.groupBox10.Location = new Point(0, 278);
		this.groupBox10.Margin = new Padding(0);
		this.groupBox10.Name = "groupBox10";
		this.groupBox10.Padding = new Padding(0);
		this.groupBox10.Size = new Size(148, 393);
		this.groupBox10.TabIndex = 281;
		this.groupBox10.TabStop = false;
		this.groupBox10.Text = "Sư Môn";
		this.label4.AutoSize = true;
		this.label4.Location = new Point(0, 58);
		this.label4.Name = "label4";
		this.label4.Size = new Size(62, 13);
		this.label4.TabIndex = 367;
		this.label4.Text = "Làm Tối Đa";
		this.chkHuyBatPet.AutoSize = true;
		this.chkHuyBatPet.Location = new Point(2, 15);
		this.chkHuyBatPet.Margin = new Padding(2);
		this.chkHuyBatPet.Name = "chkHuyBatPet";
		this.chkHuyBatPet.Size = new Size(94, 17);
		this.chkHuyBatPet.TabIndex = 29;
		this.chkHuyBatPet.TabStop = false;
		this.chkHuyBatPet.Text = "Hủy Q Bắt Pet";
		this.chkHuyBatPet.UseVisualStyleBackColor = true;
		this.checkKhongDungDongMon.AutoSize = true;
		this.checkKhongDungDongMon.Location = new Point(1, 36);
		this.checkKhongDungDongMon.Margin = new Padding(2);
		this.checkKhongDungDongMon.Name = "checkKhongDungDongMon";
		this.checkKhongDungDongMon.Size = new Size(139, 17);
		this.checkKhongDungDongMon.TabIndex = 244;
		this.checkKhongDungDongMon.TabStop = false;
		this.checkKhongDungDongMon.Text = "Không Dùng Đồng Môn";
		this.checkKhongDungDongMon.UseVisualStyleBackColor = true;
		this.numberMaxSuMon.Location = new Point(68, 55);
		this.numberMaxSuMon.Name = "numberMaxSuMon";
		this.numberMaxSuMon.Size = new Size(46, 20);
		this.numberMaxSuMon.TabIndex = 366;
		this.tabSettingLogin.Controls.Add(this.splitContainer2);
		this.tabSettingLogin.Location = new Point(4, 4);
		this.tabSettingLogin.Name = "tabSettingLogin";
		this.tabSettingLogin.Padding = new Padding(3);
		this.tabSettingLogin.Size = new Size(491, 430);
		this.tabSettingLogin.TabIndex = 4;
		this.tabSettingLogin.Text = "Login";
		this.tabSettingLogin.UseVisualStyleBackColor = true;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.Location = new Point(3, 3);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Panel1.Controls.Add(this.groupBox21);
		this.splitContainer2.Panel2.Controls.Add(this.groupBox22);
		this.splitContainer2.Panel2.Controls.Add(this.groupBox24);
		this.splitContainer2.Size = new Size(485, 424);
		this.splitContainer2.SplitterDistance = 231;
		this.splitContainer2.TabIndex = 332;
		this.splitContainer2.TabStop = false;
		this.groupBox21.Controls.Add(this.textBox8);
		this.groupBox21.Controls.Add(this.textBox9);
		this.groupBox21.Controls.Add(this.textBox10);
		this.groupBox21.Controls.Add(this.textBox11);
		this.groupBox21.Controls.Add(this.label9);
		this.groupBox21.Controls.Add(this.chkExitPK);
		this.groupBox21.Controls.Add(this.chkExitCaptcha);
		this.groupBox21.Controls.Add(this.chkExitDead);
		this.groupBox21.Controls.Add(this.btnSleepTime);
		this.groupBox21.Controls.Add(this.checkNotOutKey);
		this.groupBox21.Controls.Add(this.checkExitSleepTime);
		this.groupBox21.Controls.Add(this.checkExitLogin);
		this.groupBox21.Controls.Add(this.checkExitOnline);
		this.groupBox21.Controls.Add(this.label20);
		this.groupBox21.Controls.Add(this.checkExitIdle);
		this.groupBox21.Controls.Add(this.label31);
		this.groupBox21.Controls.Add(this.checkExitLevel);
		this.groupBox21.Dock = DockStyle.Fill;
		this.groupBox21.Location = new Point(0, 0);
		this.groupBox21.Name = "groupBox21";
		this.groupBox21.Size = new Size(231, 424);
		this.groupBox21.TabIndex = 324;
		this.groupBox21.TabStop = false;
		this.groupBox21.Text = "Thoát Game Khi";
		this.textBox8.Location = new Point(97, 86);
		this.textBox8.Name = "textBox8";
		this.textBox8.Size = new Size(46, 20);
		this.textBox8.TabIndex = 369;
		this.textBox9.Location = new Point(96, 63);
		this.textBox9.Name = "textBox9";
		this.textBox9.Size = new Size(46, 20);
		this.textBox9.TabIndex = 368;
		this.textBox10.Location = new Point(96, 40);
		this.textBox10.Name = "textBox10";
		this.textBox10.Size = new Size(46, 20);
		this.textBox10.TabIndex = 367;
		this.textBox11.Location = new Point(96, 17);
		this.textBox11.Name = "textBox11";
		this.textBox11.Size = new Size(46, 20);
		this.textBox11.TabIndex = 366;
		this.label9.AutoSize = true;
		this.label9.Location = new Point(148, 20);
		this.label9.Name = "label9";
		this.label9.Size = new Size(15, 13);
		this.label9.TabIndex = 339;
		this.label9.Text = "m";
		this.chkExitPK.AutoSize = true;
		this.chkExitPK.Location = new Point(3, 111);
		this.chkExitPK.Name = "chkExitPK";
		this.chkExitPK.Size = new Size(85, 17);
		this.chkExitPK.TabIndex = 337;
		this.chkExitPK.TabStop = false;
		this.chkExitPK.Text = "Bị Tấn Công";
		this.chkExitPK.UseVisualStyleBackColor = true;
		this.chkExitCaptcha.AutoSize = true;
		this.chkExitCaptcha.Location = new Point(3, 156);
		this.chkExitCaptcha.Name = "chkExitCaptcha";
		this.chkExitCaptcha.Size = new Size(136, 17);
		this.chkExitCaptcha.TabIndex = 336;
		this.chkExitCaptcha.TabStop = false;
		this.chkExitCaptcha.Text = "Không Trả Lời Captcha";
		this.chkExitCaptcha.UseVisualStyleBackColor = true;
		this.chkExitDead.AutoSize = true;
		this.chkExitDead.Location = new Point(3, 133);
		this.chkExitDead.Name = "chkExitDead";
		this.chkExitDead.Size = new Size(67, 17);
		this.chkExitDead.TabIndex = 338;
		this.chkExitDead.TabStop = false;
		this.chkExitDead.Text = "Tử Vong";
		this.chkExitDead.UseVisualStyleBackColor = true;
		this.btnSleepTime.Location = new Point(96, 173);
		this.btnSleepTime.Name = "btnSleepTime";
		this.btnSleepTime.Size = new Size(47, 26);
		this.btnSleepTime.TabIndex = 331;
		this.btnSleepTime.TabStop = false;
		this.btnSleepTime.Text = "+";
		this.btnSleepTime.UseVisualStyleBackColor = true;
		this.checkNotOutKey.AutoSize = true;
		this.checkNotOutKey.Location = new Point(3, 201);
		this.checkNotOutKey.Name = "checkNotOutKey";
		this.checkNotOutKey.Size = new Size(98, 17);
		this.checkNotOutKey.TabIndex = 323;
		this.checkNotOutKey.TabStop = false;
		this.checkNotOutKey.Text = "Không Out Key";
		this.checkNotOutKey.UseVisualStyleBackColor = true;
		this.checkExitSleepTime.AutoSize = true;
		this.checkExitSleepTime.Location = new Point(3, 179);
		this.checkExitSleepTime.Name = "checkExitSleepTime";
		this.checkExitSleepTime.Size = new Size(74, 17);
		this.checkExitSleepTime.TabIndex = 324;
		this.checkExitSleepTime.TabStop = false;
		this.checkExitSleepTime.Text = "Time Nghỉ";
		this.checkExitSleepTime.UseVisualStyleBackColor = true;
		this.checkExitSleepTime.CheckedChanged += this.checkExitSleepTime_CheckedChanged;
		this.checkExitLogin.AutoSize = true;
		this.checkExitLogin.Location = new Point(3, 65);
		this.checkExitLogin.Name = "checkExitLogin";
		this.checkExitLogin.Size = new Size(75, 17);
		this.checkExitLogin.TabIndex = 317;
		this.checkExitLogin.TabStop = false;
		this.checkExitLogin.Text = "Login Quá";
		this.checkExitLogin.UseVisualStyleBackColor = true;
		this.checkExitOnline.AutoSize = true;
		this.checkExitOnline.Location = new Point(3, 19);
		this.checkExitOnline.Name = "checkExitOnline";
		this.checkExitOnline.Size = new Size(81, 17);
		this.checkExitOnline.TabIndex = 295;
		this.checkExitOnline.TabStop = false;
		this.checkExitOnline.Text = "Online Trên";
		this.checkExitOnline.UseVisualStyleBackColor = true;
		this.label20.AutoSize = true;
		this.label20.Location = new Point(148, 43);
		this.label20.Name = "label20";
		this.label20.Size = new Size(15, 13);
		this.label20.TabIndex = 297;
		this.label20.Text = "m";
		this.checkExitIdle.AutoSize = true;
		this.checkExitIdle.Location = new Point(3, 42);
		this.checkExitIdle.Name = "checkExitIdle";
		this.checkExitIdle.Size = new Size(91, 17);
		this.checkExitIdle.TabIndex = 314;
		this.checkExitIdle.TabStop = false;
		this.checkExitIdle.Text = "Đứng Im Trên";
		this.checkExitIdle.UseVisualStyleBackColor = true;
		this.label31.AutoSize = true;
		this.label31.Location = new Point(148, 66);
		this.label31.Name = "label31";
		this.label31.Size = new Size(15, 13);
		this.label31.TabIndex = 316;
		this.label31.Text = "m";
		this.checkExitLevel.AutoSize = true;
		this.checkExitLevel.Location = new Point(3, 88);
		this.checkExitLevel.Name = "checkExitLevel";
		this.checkExitLevel.Size = new Size(65, 17);
		this.checkExitLevel.TabIndex = 71;
		this.checkExitLevel.TabStop = false;
		this.checkExitLevel.Text = "Đạt Cấp";
		this.checkExitLevel.UseVisualStyleBackColor = true;
		this.groupBox22.Controls.Add(this.checkChayBachHoaDuyen);
		this.groupBox22.Controls.Add(this.chkAutoCreatePlayer);
		this.groupBox22.Controls.Add(this.checkChayTrungAc);
		this.groupBox22.Controls.Add(this.textBox13);
		this.groupBox22.Controls.Add(this.checkNotOutXong);
		this.groupBox22.Controls.Add(this.label42);
		this.groupBox22.Controls.Add(this.checkAutoLogin);
		this.groupBox22.Controls.Add(this.checkKhongChonMayChu);
		this.groupBox22.Dock = DockStyle.Fill;
		this.groupBox22.Location = new Point(0, 0);
		this.groupBox22.Name = "groupBox22";
		this.groupBox22.Size = new Size(250, 244);
		this.groupBox22.TabIndex = 329;
		this.groupBox22.TabStop = false;
		this.groupBox22.Text = "Option";
		this.checkChayBachHoaDuyen.AutoSize = true;
		this.checkChayBachHoaDuyen.Location = new Point(7, 111);
		this.checkChayBachHoaDuyen.Name = "checkChayBachHoaDuyen";
		this.checkChayBachHoaDuyen.Size = new Size(132, 17);
		this.checkChayBachHoaDuyen.TabIndex = 309;
		this.checkChayBachHoaDuyen.TabStop = false;
		this.checkChayBachHoaDuyen.Text = "Chạy BHD Vào 12 Giờ";
		this.checkChayBachHoaDuyen.UseVisualStyleBackColor = true;
		this.chkAutoCreatePlayer.AutoSize = true;
		this.chkAutoCreatePlayer.Location = new Point(7, 133);
		this.chkAutoCreatePlayer.Margin = new Padding(2);
		this.chkAutoCreatePlayer.Name = "chkAutoCreatePlayer";
		this.chkAutoCreatePlayer.Size = new Size(139, 17);
		this.chkAutoCreatePlayer.TabIndex = 328;
		this.chkAutoCreatePlayer.TabStop = false;
		this.chkAutoCreatePlayer.Text = "Tạo Player Khi Chưa Có";
		this.chkAutoCreatePlayer.UseVisualStyleBackColor = true;
		this.checkChayTrungAc.AutoSize = true;
		this.checkChayTrungAc.Location = new Point(7, 88);
		this.checkChayTrungAc.Name = "checkChayTrungAc";
		this.checkChayTrungAc.Size = new Size(153, 17);
		this.checkChayTrungAc.TabIndex = 324;
		this.checkChayTrungAc.TabStop = false;
		this.checkChayTrungAc.Text = "Chạy Trừng Ác Vào 12 Giờ";
		this.checkChayTrungAc.UseVisualStyleBackColor = true;
		this.textBox13.Location = new Point(120, 17);
		this.textBox13.Name = "textBox13";
		this.textBox13.Size = new Size(46, 20);
		this.textBox13.TabIndex = 370;
		this.checkNotOutXong.AutoSize = true;
		this.checkNotOutXong.Location = new Point(7, 65);
		this.checkNotOutXong.Name = "checkNotOutXong";
		this.checkNotOutXong.Size = new Size(154, 17);
		this.checkNotOutXong.TabIndex = 323;
		this.checkNotOutXong.TabStop = false;
		this.checkNotOutXong.Text = "Không Out Game Khi Xong";
		this.checkNotOutXong.UseVisualStyleBackColor = true;
		this.label42.AutoSize = true;
		this.label42.Location = new Point(166, 18);
		this.label42.Name = "label42";
		this.label42.Size = new Size(12, 13);
		this.label42.TabIndex = 322;
		this.label42.Text = "s";
		this.checkAutoLogin.AutoSize = true;
		this.checkAutoLogin.Location = new Point(7, 19);
		this.checkAutoLogin.Name = "checkAutoLogin";
		this.checkAutoLogin.Size = new Size(107, 17);
		this.checkAutoLogin.TabIndex = 290;
		this.checkAutoLogin.TabStop = false;
		this.checkAutoLogin.Text = "Tự Login Lại Sau";
		this.checkAutoLogin.UseVisualStyleBackColor = true;
		this.checkKhongChonMayChu.AutoSize = true;
		this.checkKhongChonMayChu.Location = new Point(7, 42);
		this.checkKhongChonMayChu.Name = "checkKhongChonMayChu";
		this.checkKhongChonMayChu.Size = new Size(130, 17);
		this.checkKhongChonMayChu.TabIndex = 291;
		this.checkKhongChonMayChu.TabStop = false;
		this.checkKhongChonMayChu.Text = "Không Chọn Máy Chủ";
		this.checkKhongChonMayChu.UseVisualStyleBackColor = true;
		this.groupBox24.Controls.Add(this.numberMoCachNhau);
		this.groupBox24.Controls.Add(this.numberMoGameDongThoi);
		this.groupBox24.Controls.Add(this.numberMoGameToiDa);
		this.groupBox24.Controls.Add(this.label43);
		this.groupBox24.Controls.Add(this.label44);
		this.groupBox24.Controls.Add(this.label45);
		this.groupBox24.Controls.Add(this.label46);
		this.groupBox24.Dock = DockStyle.Bottom;
		this.groupBox24.Location = new Point(0, 244);
		this.groupBox24.Name = "groupBox24";
		this.groupBox24.Size = new Size(250, 180);
		this.groupBox24.TabIndex = 327;
		this.groupBox24.TabStop = false;
		this.groupBox24.Text = "Mở Game";
		this.numberMoCachNhau.Location = new Point(77, 67);
		this.numberMoCachNhau.Name = "numberMoCachNhau";
		this.numberMoCachNhau.Size = new Size(46, 20);
		this.numberMoCachNhau.TabIndex = 373;
		this.numberMoGameDongThoi.Location = new Point(77, 41);
		this.numberMoGameDongThoi.Name = "numberMoGameDongThoi";
		this.numberMoGameDongThoi.Size = new Size(46, 20);
		this.numberMoGameDongThoi.TabIndex = 372;
		this.numberMoGameToiDa.Location = new Point(77, 18);
		this.numberMoGameToiDa.Name = "numberMoGameToiDa";
		this.numberMoGameToiDa.Size = new Size(46, 20);
		this.numberMoGameToiDa.TabIndex = 371;
		this.label43.AutoSize = true;
		this.label43.Location = new Point(7, 21);
		this.label43.Name = "label43";
		this.label43.Size = new Size(39, 13);
		this.label43.TabIndex = 50;
		this.label43.Text = "Tối Đa";
		this.label44.AutoSize = true;
		this.label44.Location = new Point(7, 47);
		this.label44.Name = "label44";
		this.label44.Size = new Size(57, 13);
		this.label44.TabIndex = 317;
		this.label44.Text = "Đồng Thời";
		this.label45.AutoSize = true;
		this.label45.Location = new Point(127, 70);
		this.label45.Name = "label45";
		this.label45.Size = new Size(12, 13);
		this.label45.TabIndex = 322;
		this.label45.Text = "s";
		this.label46.AutoSize = true;
		this.label46.Location = new Point(7, 70);
		this.label46.Name = "label46";
		this.label46.Size = new Size(61, 13);
		this.label46.TabIndex = 320;
		this.label46.Text = "Cách Nhau";
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabSettingChild);
		base.Name = "Setting";
		base.Size = new Size(499, 456);
		this.tabSettingBachHoaDuyen.ResumeLayout(false);
		this.splitContainer4.Panel1.ResumeLayout(false);
		this.splitContainer4.ResumeLayout(false);
		this.groupBox8.ResumeLayout(false);
		this.groupBox8.PerformLayout();
		this.groupBox9.ResumeLayout(false);
		this.groupBox9.PerformLayout();
		this.tabSettingChung.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel2.PerformLayout();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		this.panGameItem.ResumeLayout(false);
		this.tabSettingTuDong.ResumeLayout(false);
		this.flowLayoutPanel2.ResumeLayout(false);
		this.flowLayoutPanel2.PerformLayout();
		this.grShutDown.ResumeLayout(false);
		this.grShutDown.PerformLayout();
		this.groupBox20.ResumeLayout(false);
		this.flowLayoutPanel5.ResumeLayout(false);
		this.flowLayoutPanel5.PerformLayout();
		this.groupBox7.ResumeLayout(false);
		this.groupBox7.PerformLayout();
		this.tabSettingTuyChon.ResumeLayout(false);
		this.flowLayoutPanel4.ResumeLayout(false);
		this.flowLayoutPanel4.PerformLayout();
		this.groupBox11.ResumeLayout(false);
		this.groupBox12.ResumeLayout(false);
		this.groupBox5.ResumeLayout(false);
		this.groupBox5.PerformLayout();
		this.groupBox4.ResumeLayout(false);
		this.groupBox4.PerformLayout();
		this.groupBox6.ResumeLayout(false);
		this.flowLayoutPanel3.ResumeLayout(false);
		this.groupBox19.ResumeLayout(false);
		this.groupBox19.PerformLayout();
		this.groupBox18.ResumeLayout(false);
		this.groupBox18.PerformLayout();
		this.groupBox16.ResumeLayout(false);
		this.groupBox16.PerformLayout();
		this.groupBox17.ResumeLayout(false);
		this.groupBox17.PerformLayout();
		this.groupBox10.ResumeLayout(false);
		this.groupBox10.PerformLayout();
		this.tabSettingLogin.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.groupBox21.ResumeLayout(false);
		this.groupBox21.PerformLayout();
		this.groupBox22.ResumeLayout(false);
		this.groupBox22.PerformLayout();
		this.groupBox24.ResumeLayout(false);
		this.groupBox24.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04000F74 RID: 3956
	[CompilerGenerated]
	private static Dictionary<string, List<string>> dictionary_0;

	// Token: 0x04000F75 RID: 3957
	[CompilerGenerated]
	private static Dictionary<string, List<string>> dictionary_1;

	// Token: 0x04000F76 RID: 3958
	[CompilerGenerated]
	private static string string_0;

	// Token: 0x04000F77 RID: 3959
	[CompilerGenerated]
	private static string string_1;

	// Token: 0x04000F78 RID: 3960
	[CompilerGenerated]
	private static string string_2;

	// Token: 0x04000F79 RID: 3961
	[CompilerGenerated]
	private static string string_3;

	// Token: 0x04000F7A RID: 3962
	[CompilerGenerated]
	private static string string_4;

	// Token: 0x04000F7B RID: 3963
	[CompilerGenerated]
	private static string string_5;

	// Token: 0x04000F7C RID: 3964
	[CompilerGenerated]
	private static string string_6;

	// Token: 0x04000F7D RID: 3965
	[CompilerGenerated]
	private static string string_7;

	// Token: 0x04000F7E RID: 3966
	[CompilerGenerated]
	private static string string_8;

	// Token: 0x04000F7F RID: 3967
	[CompilerGenerated]
	private static string string_9;

	// Token: 0x04000F80 RID: 3968
	[CompilerGenerated]
	private static Dictionary<string, bool> dictionary_2;

	// Token: 0x04000F81 RID: 3969
	[CompilerGenerated]
	private static Dictionary<string, int> dictionary_3;

	// Token: 0x04000F82 RID: 3970
	private IContainer icontainer_0;

	// Token: 0x04000F83 RID: 3971
	private Control1 tabSettingChild;

	// Token: 0x04000F84 RID: 3972
	private TabPage tabSettingChung;

	// Token: 0x04000F85 RID: 3973
	private Panel panel1;

	// Token: 0x04000F86 RID: 3974
	public CheckBox checkSkipMonter;

	// Token: 0x04000F87 RID: 3975
	public CheckBox checkAlarmInbox;

	// Token: 0x04000F88 RID: 3976
	public CheckBox checkMuteInbox;

	// Token: 0x04000F89 RID: 3977
	private Button btnBoQua;

	// Token: 0x04000F8A RID: 3978
	private Button button6;

	// Token: 0x04000F8B RID: 3979
	public CheckBox checkAccept;

	// Token: 0x04000F8C RID: 3980
	public CheckBox checkBuyItem;

	// Token: 0x04000F8D RID: 3981
	private Button btnAutoAccept;

	// Token: 0x04000F8E RID: 3982
	private Button btnGomDo;

	// Token: 0x04000F8F RID: 3983
	public CheckBox checkUseCalender;

	// Token: 0x04000F90 RID: 3984
	public CheckBox checkAntiCaptcha;

	// Token: 0x04000F91 RID: 3985
	public CheckBox checkDropItem;

	// Token: 0x04000F92 RID: 3986
	public CheckBox checkAcceptAll;

	// Token: 0x04000F93 RID: 3987
	private Button btnAutoBuy;

	// Token: 0x04000F94 RID: 3988
	private Button button1;

	// Token: 0x04000F95 RID: 3989
	private Button btnUseItem;

	// Token: 0x04000F96 RID: 3990
	private Button button8;

	// Token: 0x04000F97 RID: 3991
	public CheckBox checkUseItem;

	// Token: 0x04000F98 RID: 3992
	public CheckBox checkNemBienThan;

	// Token: 0x04000F99 RID: 3993
	public CheckBox checkSellItem;

	// Token: 0x04000F9A RID: 3994
	private Button btnCatDo;

	// Token: 0x04000F9B RID: 3995
	private Button btnDropItemEx;

	// Token: 0x04000F9C RID: 3996
	private Button btnSellItemEx;

	// Token: 0x04000F9D RID: 3997
	public CheckBox checkBankItem;

	// Token: 0x04000F9E RID: 3998
	private TabPage tabSettingTuDong;

	// Token: 0x04000F9F RID: 3999
	private FlowLayoutPanel flowLayoutPanel2;

	// Token: 0x04000FA0 RID: 4000
	private CheckBox checkCongTheLuc;

	// Token: 0x04000FA1 RID: 4001
	private CheckBox checkCongDiemPet;

	// Token: 0x04000FA2 RID: 4002
	private CheckBox checkCatDoDayTayNai;

	// Token: 0x04000FA3 RID: 4003
	private CheckBox checkBanDoDayTayNai;

	// Token: 0x04000FA4 RID: 4004
	private CheckBox checkDungx2;

	// Token: 0x04000FA5 RID: 4005
	private CheckBox checkMuax2;

	// Token: 0x04000FA6 RID: 4006
	private CheckBox checkNhanx2LuyenCap;

	// Token: 0x04000FA7 RID: 4007
	private CheckBox checkDauThai;

	// Token: 0x04000FA8 RID: 4008
	private CheckBox checkThuTieuDatTai;

	// Token: 0x04000FA9 RID: 4009
	private CheckBox checkToDoiGanNhau;

	// Token: 0x04000FAA RID: 4010
	private CheckBox checkXuatPetManNhat;

	// Token: 0x04000FAB RID: 4011
	private CheckBox checkXuongNgua;

	// Token: 0x04000FAC RID: 4012
	private CheckBox checkXepTayNai;

	// Token: 0x04000FAD RID: 4013
	private CheckBox checkAutoShutDown;

	// Token: 0x04000FAE RID: 4014
	private CheckBox checkTuKeoDoi;

	// Token: 0x04000FAF RID: 4015
	private GroupBox groupBox20;

	// Token: 0x04000FB0 RID: 4016
	private FlowLayoutPanel flowLayoutPanel5;

	// Token: 0x04000FB1 RID: 4017
	private GroupBox groupBox7;

	// Token: 0x04000FB2 RID: 4018
	private CheckBox checkKhiBanRac;

	// Token: 0x04000FB3 RID: 4019
	private CheckBox checkKhiDungDo;

	// Token: 0x04000FB4 RID: 4020
	private CheckBox checkKhiGomDo;

	// Token: 0x04000FB5 RID: 4021
	private CheckBox checkKhiPhanGiai;

	// Token: 0x04000FB6 RID: 4022
	private CheckBox checkKhiCatDo;

	// Token: 0x04000FB7 RID: 4023
	private CheckBox checkDatSkillF1;

	// Token: 0x04000FB8 RID: 4024
	private CheckBox checkDatAnToan;

	// Token: 0x04000FB9 RID: 4025
	private CheckBox checkResetCanQuet;

	// Token: 0x04000FBA RID: 4026
	private CheckBox checkHoTro;

	// Token: 0x04000FBB RID: 4027
	private CheckBox checkDungSkillPet;

	// Token: 0x04000FBC RID: 4028
	private CheckBox checkChucPhuc;

	// Token: 0x04000FBD RID: 4029
	private CheckBox checkDiemDanh;

	// Token: 0x04000FBE RID: 4030
	private CheckBox checkHoiSinh;

	// Token: 0x04000FBF RID: 4031
	private CheckBox checkNgamyHoiSinh;

	// Token: 0x04000FC0 RID: 4032
	private GClass106 grShutDown;

	// Token: 0x04000FC1 RID: 4033
	private TabPage tabSettingLogin;

	// Token: 0x04000FC2 RID: 4034
	private SplitContainer splitContainer2;

	// Token: 0x04000FC3 RID: 4035
	private GroupBox groupBox21;

	// Token: 0x04000FC4 RID: 4036
	private Label label9;

	// Token: 0x04000FC5 RID: 4037
	private CheckBox chkExitPK;

	// Token: 0x04000FC6 RID: 4038
	private CheckBox chkExitCaptcha;

	// Token: 0x04000FC7 RID: 4039
	private CheckBox chkExitDead;

	// Token: 0x04000FC8 RID: 4040
	private Button btnSleepTime;

	// Token: 0x04000FC9 RID: 4041
	private CheckBox checkNotOutKey;

	// Token: 0x04000FCA RID: 4042
	private CheckBox checkExitSleepTime;

	// Token: 0x04000FCB RID: 4043
	private CheckBox checkExitLogin;

	// Token: 0x04000FCC RID: 4044
	private CheckBox checkExitOnline;

	// Token: 0x04000FCD RID: 4045
	private Label label20;

	// Token: 0x04000FCE RID: 4046
	private CheckBox checkExitIdle;

	// Token: 0x04000FCF RID: 4047
	private Label label31;

	// Token: 0x04000FD0 RID: 4048
	private CheckBox checkExitLevel;

	// Token: 0x04000FD1 RID: 4049
	private GroupBox groupBox22;

	// Token: 0x04000FD2 RID: 4050
	private CheckBox checkChayBachHoaDuyen;

	// Token: 0x04000FD3 RID: 4051
	private CheckBox chkAutoCreatePlayer;

	// Token: 0x04000FD4 RID: 4052
	private CheckBox checkChayTrungAc;

	// Token: 0x04000FD5 RID: 4053
	private CheckBox checkNotOutXong;

	// Token: 0x04000FD6 RID: 4054
	private Label label42;

	// Token: 0x04000FD7 RID: 4055
	private CheckBox checkAutoLogin;

	// Token: 0x04000FD8 RID: 4056
	private CheckBox checkKhongChonMayChu;

	// Token: 0x04000FD9 RID: 4057
	private GroupBox groupBox24;

	// Token: 0x04000FDA RID: 4058
	private Label label43;

	// Token: 0x04000FDB RID: 4059
	private Label label44;

	// Token: 0x04000FDC RID: 4060
	private Label label45;

	// Token: 0x04000FDD RID: 4061
	private Label label46;

	// Token: 0x04000FDE RID: 4062
	private TabPage tabSettingTuyChon;

	// Token: 0x04000FDF RID: 4063
	private FlowLayoutPanel flowLayoutPanel4;

	// Token: 0x04000FE0 RID: 4064
	private GroupBox groupBox11;

	// Token: 0x04000FE1 RID: 4065
	private ComboBox cboMapDua;

	// Token: 0x04000FE2 RID: 4066
	private GroupBox groupBox12;

	// Token: 0x04000FE3 RID: 4067
	private ComboBox cboMenpai;

	// Token: 0x04000FE4 RID: 4068
	private GroupBox groupBox5;

	// Token: 0x04000FE5 RID: 4069
	private Button btnBuyDaiLy;

	// Token: 0x04000FE6 RID: 4070
	private Label label8;

	// Token: 0x04000FE7 RID: 4071
	private Label label6;

	// Token: 0x04000FE8 RID: 4072
	private GroupBox groupBox4;

	// Token: 0x04000FE9 RID: 4073
	private Label label15;

	// Token: 0x04000FEA RID: 4074
	private GroupBox groupBox6;

	// Token: 0x04000FEB RID: 4075
	private Control0 numberDelay;

	// Token: 0x04000FEC RID: 4076
	private CheckBox chkCanQuetx2;

	// Token: 0x04000FED RID: 4077
	private CheckBox chkHold;

	// Token: 0x04000FEE RID: 4078
	private CheckBox chkAutoResetTime;

	// Token: 0x04000FEF RID: 4079
	private FlowLayoutPanel flowLayoutPanel3;

	// Token: 0x04000FF0 RID: 4080
	private GroupBox groupBox19;

	// Token: 0x04000FF1 RID: 4081
	private CheckBox checkUseSelectServer;

	// Token: 0x04000FF2 RID: 4082
	private CheckBox checkLuonAnGame;

	// Token: 0x04000FF3 RID: 4083
	private CheckBox checkKhongChiemManHinh;

	// Token: 0x04000FF4 RID: 4084
	private GroupBox groupBox18;

	// Token: 0x04000FF5 RID: 4085
	private CheckBox checkBuffPet;

	// Token: 0x04000FF6 RID: 4086
	private CheckBox checkBuffQuanDoan;

	// Token: 0x04000FF7 RID: 4087
	private GroupBox groupBox16;

	// Token: 0x04000FF8 RID: 4088
	private CheckBox checkNeBinh;

	// Token: 0x04000FF9 RID: 4089
	private CheckBox checkBossCuoi;

	// Token: 0x04000FFA RID: 4090
	private GroupBox groupBox17;

	// Token: 0x04000FFB RID: 4091
	private CheckBox checkAlarmPk;

	// Token: 0x04000FFC RID: 4092
	private CheckBox checkDanhTra;

	// Token: 0x04000FFD RID: 4093
	private CheckBox checkPKNgaMy;

	// Token: 0x04000FFE RID: 4094
	private GroupBox groupBox10;

	// Token: 0x04000FFF RID: 4095
	private CheckBox chkHuyBatPet;

	// Token: 0x04001000 RID: 4096
	private CheckBox checkKhongDungDongMon;

	// Token: 0x04001001 RID: 4097
	private TabPage tabSettingBachHoaDuyen;

	// Token: 0x04001002 RID: 4098
	private SplitContainer splitContainer4;

	// Token: 0x04001003 RID: 4099
	private GroupBox groupBox8;

	// Token: 0x04001004 RID: 4100
	private CheckBox chkBonPhan;

	// Token: 0x04001005 RID: 4101
	private CheckBox chkTrongBon;

	// Token: 0x04001006 RID: 4102
	private GroupBox groupBox9;

	// Token: 0x04001007 RID: 4103
	private Label label28;

	// Token: 0x04001008 RID: 4104
	private Label label30;

	// Token: 0x04001009 RID: 4105
	private Label label32;

	// Token: 0x0400100A RID: 4106
	private Label label33;

	// Token: 0x0400100B RID: 4107
	private Label label34;

	// Token: 0x0400100C RID: 4108
	private Label label35;

	// Token: 0x0400100D RID: 4109
	private Label label36;

	// Token: 0x0400100E RID: 4110
	private Label label37;

	// Token: 0x0400100F RID: 4111
	private Label label38;

	// Token: 0x04001010 RID: 4112
	private Label label39;

	// Token: 0x04001011 RID: 4113
	private CheckBox chkLimitBienThan;

	// Token: 0x04001012 RID: 4114
	private Label label40;

	// Token: 0x04001013 RID: 4115
	private CheckBox chkBonHoaAll;

	// Token: 0x04001014 RID: 4116
	private Label label41;

	// Token: 0x04001015 RID: 4117
	private CheckBox chkHuyDanhQuai;

	// Token: 0x04001016 RID: 4118
	private CheckBox chkHuyThaiHo;

	// Token: 0x04001017 RID: 4119
	private CheckBox IsHyHuu;

	// Token: 0x04001018 RID: 4120
	private TextBox textBox8;

	// Token: 0x04001019 RID: 4121
	private TextBox textBox9;

	// Token: 0x0400101A RID: 4122
	private TextBox textBox10;

	// Token: 0x0400101B RID: 4123
	private TextBox textBox11;

	// Token: 0x0400101C RID: 4124
	private TextBox numberMoGameDongThoi;

	// Token: 0x0400101D RID: 4125
	private TextBox numberMoGameToiDa;

	// Token: 0x0400101E RID: 4126
	private TextBox textBox13;

	// Token: 0x0400101F RID: 4127
	private TextBox numberMoCachNhau;

	// Token: 0x04001020 RID: 4128
	private Label label3;

	// Token: 0x04001021 RID: 4129
	private TextBox textBox31;

	// Token: 0x04001022 RID: 4130
	private TextBox textBox30;

	// Token: 0x04001023 RID: 4131
	private TextBox numberMaxSuMon;

	// Token: 0x04001024 RID: 4132
	private TextBox textBox37;

	// Token: 0x04001025 RID: 4133
	private TextBox textBox36;

	// Token: 0x04001026 RID: 4134
	private TextBox textBox35;

	// Token: 0x04001027 RID: 4135
	private TextBox textBox34;

	// Token: 0x04001028 RID: 4136
	private TextBox textBox33;

	// Token: 0x04001029 RID: 4137
	private TextBox textBox25;

	// Token: 0x0400102A RID: 4138
	private TextBox textBox26;

	// Token: 0x0400102B RID: 4139
	private TextBox textBox27;

	// Token: 0x0400102C RID: 4140
	private TextBox numerBachHoaDuyenTime;

	// Token: 0x0400102D RID: 4141
	private TextBox textBox29;

	// Token: 0x0400102E RID: 4142
	private TextBox textBox19;

	// Token: 0x0400102F RID: 4143
	private TextBox textBox20;

	// Token: 0x04001030 RID: 4144
	private TextBox textBox21;

	// Token: 0x04001031 RID: 4145
	private TextBox textBox22;

	// Token: 0x04001032 RID: 4146
	private TextBox textBox23;

	// Token: 0x04001033 RID: 4147
	private TextBox textBox24;

	// Token: 0x04001034 RID: 4148
	private TextBox textBox15;

	// Token: 0x04001035 RID: 4149
	private TextBox textBox16;

	// Token: 0x04001036 RID: 4150
	private TextBox textBox17;

	// Token: 0x04001037 RID: 4151
	private TextBox textBox18;

	// Token: 0x04001038 RID: 4152
	private CheckBox checkNotUseRide;

	// Token: 0x04001039 RID: 4153
	private CheckBox checkNotUseShortcutKey;

	// Token: 0x0400103A RID: 4154
	private Panel panel2;

	// Token: 0x0400103B RID: 4155
	private TextBox numberSuaTrangBi;

	// Token: 0x0400103C RID: 4156
	private TextBox numberChuyenMatac;

	// Token: 0x0400103D RID: 4157
	private TextBox numberThuPet;

	// Token: 0x0400103E RID: 4158
	private TextBox numberTangQuanSonHai;

	// Token: 0x0400103F RID: 4159
	private TextBox numberTamXa;

	// Token: 0x04001040 RID: 4160
	private TextBox numberNhiemVuCap;

	// Token: 0x04001041 RID: 4161
	private CheckBox checkDungXaPhu;

	// Token: 0x04001042 RID: 4162
	private CheckBox checkDiCoNhanh;

	// Token: 0x04001043 RID: 4163
	private CheckBox checkBaoTangDoThongMinh;

	// Token: 0x04001044 RID: 4164
	private Label label17;

	// Token: 0x04001045 RID: 4165
	private CheckBox checkLuuTrangThai;

	// Token: 0x04001046 RID: 4166
	private CheckBox checkPhuBanDuNguoi;

	// Token: 0x04001047 RID: 4167
	private Label label2;

	// Token: 0x04001048 RID: 4168
	private Label label14;

	// Token: 0x04001049 RID: 4169
	private Label label16;

	// Token: 0x0400104A RID: 4170
	private CheckBox checkAlarmHP;

	// Token: 0x0400104B RID: 4171
	private CheckBox checkTriLieuHP;

	// Token: 0x0400104C RID: 4172
	private CheckBox checkThangCap;

	// Token: 0x0400104D RID: 4173
	private Label label25;

	// Token: 0x0400104E RID: 4174
	private Label label13;

	// Token: 0x0400104F RID: 4175
	private CheckBox checkAnGameTime;

	// Token: 0x04001050 RID: 4176
	private Panel panGameItem;

	// Token: 0x04001051 RID: 4177
	private Button btnClose;

	// Token: 0x04001052 RID: 4178
	private TextBox numberTriLieuHP;

	// Token: 0x04001053 RID: 4179
	private TextBox numberAnGameTime;

	// Token: 0x04001054 RID: 4180
	private TextBox numberDungCHT;

	// Token: 0x04001055 RID: 4181
	private TextBox numberThangCap;

	// Token: 0x04001056 RID: 4182
	private TextBox numberAlarmHP;

	// Token: 0x04001057 RID: 4183
	private Label label1;

	// Token: 0x04001058 RID: 4184
	private Label label4;

	// Token: 0x04001059 RID: 4185
	private Label label7;

	// Token: 0x0400105A RID: 4186
	private Label label5;

	// Token: 0x0400105B RID: 4187
	private CheckBox checkTriLieuMP;

	// Token: 0x020001F3 RID: 499
	[CompilerGenerated]
	[Serializable]
	private sealed class Class231
	{
		// Token: 0x06001A37 RID: 6711 RVA: 0x00012F9C File Offset: 0x0001119C
		internal string method_0(List<string> list_0)
		{
			return list_0.FirstOrDefault<string>();
		}

		// Token: 0x0400105C RID: 4188
		public static readonly Setting.Class231 <>9 = new Setting.Class231();

		// Token: 0x0400105D RID: 4189
		public static Func<List<string>, string> <>9__9_0;
	}

	// Token: 0x020001F4 RID: 500
	[CompilerGenerated]
	private sealed class Class232
	{
		// Token: 0x06001A39 RID: 6713 RVA: 0x00012FA4 File Offset: 0x000111A4
		internal void method_0(object sender, EventArgs e)
		{
			Setting.Dictionary_2[this.control_0.Name] = ((CheckBox)this.control_0).Checked;
		}

		// Token: 0x06001A3A RID: 6714 RVA: 0x00012FCB File Offset: 0x000111CB
		internal void method_1(object sender, EventArgs e)
		{
			Setting.Dictionary_3[this.control_0.Name] = ((Control0)this.control_0).Int32_1.smethod_8();
		}

		// Token: 0x0400105E RID: 4190
		public Control control_0;
	}
}
