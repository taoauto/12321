﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x020002F4 RID: 756
internal class Class415
{
	// Token: 0x170009B8 RID: 2488
	// (get) Token: 0x06002B33 RID: 11059 RVA: 0x001258C8 File Offset: 0x00123AC8
	// (set) Token: 0x06002B34 RID: 11060 RVA: 0x0001F4EC File Offset: 0x0001D6EC
	public static HashSet<string> HashSet_0
	{
		get
		{
			if (Class415.hashSet_0 == null)
			{
				Class415.hashSet_0 = new HashSet<string>(Class159.Class220_0.method_0("Buff", "All").Split(new char[]
				{
					'\n'
				}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_0)).Where(new Func<string, bool>(Class415.Class416.<>9.method_1)));
			}
			return Class415.hashSet_0;
		}
		set
		{
			Class415.hashSet_0 = value;
		}
	}

	// Token: 0x170009B9 RID: 2489
	// (get) Token: 0x06002B35 RID: 11061 RVA: 0x0001F4F4 File Offset: 0x0001D6F4
	// (set) Token: 0x06002B36 RID: 11062 RVA: 0x0001F50A File Offset: 0x0001D70A
	public static string String_0
	{
		get
		{
			return Class159.Class220_0.method_0("Buff", "BienThan");
		}
		set
		{
			Class159.Class220_0.method_1("Buff", "BienThan", value);
		}
	}

	// Token: 0x170009BA RID: 2490
	// (get) Token: 0x06002B37 RID: 11063 RVA: 0x0012595C File Offset: 0x00123B5C
	// (set) Token: 0x06002B38 RID: 11064 RVA: 0x001259D8 File Offset: 0x00123BD8
	public static string String_1
	{
		get
		{
			if (Class415.string_1 == null)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (string str in Class415.HashSet_0)
				{
					stringBuilder.AppendLine(str + "-");
				}
				Class415.string_1 = stringBuilder.ToString();
			}
			return Class415.string_1;
		}
		set
		{
			Class415.HashSet_0 = new HashSet<string>();
			StringBuilder stringBuilder = new StringBuilder();
			string[] array = value.Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (!text.Contains("-") && !text.Contains(" ") && !string.IsNullOrEmpty(text) && !Class415.HashSet_0.Contains(text))
				{
					Class415.HashSet_0.Add(text);
					stringBuilder.AppendLine(text);
				}
			}
			Class415.string_1 = stringBuilder.ToString();
			Class159.Class220_0.method_1("Buff", "All", Class415.string_1);
		}
	}

	// Token: 0x170009BB RID: 2491
	// (get) Token: 0x06002B39 RID: 11065 RVA: 0x0001F521 File Offset: 0x0001D721
	// (set) Token: 0x06002B3A RID: 11066 RVA: 0x0001F548 File Offset: 0x0001D748
	public static string String_2
	{
		get
		{
			if (Class415.string_2 == null)
			{
				Class415.string_2 = Class159.Class220_0.method_0("Buff", "SellItemPS");
			}
			return Class415.string_2;
		}
		set
		{
			Class415.string_2 = value;
			Class159.Class220_0.method_1("Buff", "SellItemPS", value);
		}
	}

	// Token: 0x170009BC RID: 2492
	// (get) Token: 0x06002B3B RID: 11067 RVA: 0x0001F565 File Offset: 0x0001D765
	// (set) Token: 0x06002B3C RID: 11068 RVA: 0x0001F58C File Offset: 0x0001D78C
	public static string String_3
	{
		get
		{
			if (Class415.string_3 == null)
			{
				Class415.string_3 = Class159.Class220_0.method_0("Buy", "All");
			}
			return Class415.string_3;
		}
		set
		{
			Class415.string_3 = value;
			Class159.Class220_0.method_1("Buy", "All", Class415.string_3);
			Class415.hashSet_3 = null;
		}
	}

	// Token: 0x06002B3D RID: 11069 RVA: 0x00125A88 File Offset: 0x00123C88
	public static void smethod_0()
	{
		Class415.hashSet_1 = new HashSet<string>(Class415.String_4.Split(new char[]
		{
			'\n'
		}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_2)).Where(new Func<string, bool>(Class415.Class416.<>9.method_3)));
		Class415.hashSet_2 = new HashSet<string>(Class415.String_7.Split(new char[]
		{
			'\n'
		}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_4)).Where(new Func<string, bool>(Class415.Class416.<>9.method_5)));
		Class415.hashSet_7 = new HashSet<string>(Class415.String_28.Split(new char[]
		{
			'\n'
		}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_6)).Where(new Func<string, bool>(Class415.Class416.<>9.method_7)));
		Class415.hashSet_9 = new HashSet<string>(Class415.String_30.Split(new char[]
		{
			'\n'
		}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_8)).Where(new Func<string, bool>(Class415.Class416.<>9.method_9)));
		Class415.hashSet_8 = new HashSet<string>(Class415.String_29.Split(new char[]
		{
			'\n'
		}).ToList<string>().Select(new Func<string, string>(Class415.Class416.<>9.method_10)).Where(new Func<string, bool>(Class415.Class416.<>9.method_11)));
	}

	// Token: 0x170009BD RID: 2493
	// (get) Token: 0x06002B3E RID: 11070 RVA: 0x0001F5B3 File Offset: 0x0001D7B3
	// (set) Token: 0x06002B3F RID: 11071 RVA: 0x0001F5DA File Offset: 0x0001D7DA
	public static string String_4
	{
		get
		{
			if (Class415.string_4 == null)
			{
				Class415.string_4 = Class159.Class220_0.method_0("Item", "BoQua");
			}
			return Class415.string_4;
		}
		set
		{
			Class415.string_4 = value;
			Class159.Class220_0.method_1("Item", "BoQua", Class415.string_4);
		}
	}

	// Token: 0x170009BE RID: 2494
	// (get) Token: 0x06002B40 RID: 11072 RVA: 0x0001F5FB File Offset: 0x0001D7FB
	// (set) Token: 0x06002B41 RID: 11073 RVA: 0x0001F622 File Offset: 0x0001D822
	public static string String_5
	{
		get
		{
			if (Class415.string_5 == null)
			{
				Class415.string_5 = Class159.Class220_0.method_0("Item", "BoQuaEx");
			}
			return Class415.string_5;
		}
		set
		{
			Class415.string_5 = value;
			Class159.Class220_0.method_1("Item", "BoQuaEx", Class415.string_5);
		}
	}

	// Token: 0x170009BF RID: 2495
	// (get) Token: 0x06002B42 RID: 11074 RVA: 0x0001F643 File Offset: 0x0001D843
	// (set) Token: 0x06002B43 RID: 11075 RVA: 0x0001F64A File Offset: 0x0001D84A
	public static HashSet<string> HashSet_1 { get; set; } = new HashSet<string>();

	// Token: 0x170009C0 RID: 2496
	// (get) Token: 0x06002B44 RID: 11076 RVA: 0x00125CB4 File Offset: 0x00123EB4
	// (set) Token: 0x06002B45 RID: 11077 RVA: 0x00125D2C File Offset: 0x00123F2C
	public static string String_6
	{
		get
		{
			if (Class415.string_6 == null)
			{
				Class415.string_6 = Class159.Class220_0.method_0("BossMAP", "Only");
				string[] array = Class415.string_6.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string item = array[i].Trim();
					if (!Class415.HashSet_1.Contains(item))
					{
						Class415.HashSet_1.Add(item);
					}
				}
			}
			return Class415.string_6;
		}
		set
		{
			Class415.string_6 = value;
			Class415.HashSet_1.Clear();
			string[] array = Class415.string_6.Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string item = array[i].Trim();
				if (!Class415.HashSet_1.Contains(item))
				{
					Class415.HashSet_1.Add(item);
				}
			}
			Class159.Class220_0.method_1("BossMAP", "Only", Class415.string_6);
		}
	}

	// Token: 0x170009C1 RID: 2497
	// (get) Token: 0x06002B46 RID: 11078 RVA: 0x0001F652 File Offset: 0x0001D852
	// (set) Token: 0x06002B47 RID: 11079 RVA: 0x0001F679 File Offset: 0x0001D879
	public static string String_7
	{
		get
		{
			if (Class415.string_7 == null)
			{
				Class415.string_7 = Class159.Class220_0.method_0("Item", "OnlyAttack");
			}
			return Class415.string_7;
		}
		set
		{
			Class415.string_7 = value;
			Class159.Class220_0.method_1("Item", "OnlyAttack", Class415.string_7);
		}
	}

	// Token: 0x170009C2 RID: 2498
	// (get) Token: 0x06002B48 RID: 11080 RVA: 0x0001F69A File Offset: 0x0001D89A
	// (set) Token: 0x06002B49 RID: 11081 RVA: 0x0001F6C1 File Offset: 0x0001D8C1
	public static string String_8
	{
		get
		{
			if (Class415.string_8 == null)
			{
				Class415.string_8 = Class159.Class220_0.method_0("Item", "DropName");
			}
			return Class415.string_8;
		}
		set
		{
			Class415.string_8 = value;
			Class159.Class220_0.method_1("Item", "DropName", Class415.string_8);
		}
	}

	// Token: 0x170009C3 RID: 2499
	// (get) Token: 0x06002B4A RID: 11082 RVA: 0x0001F6E2 File Offset: 0x0001D8E2
	// (set) Token: 0x06002B4B RID: 11083 RVA: 0x0001F709 File Offset: 0x0001D909
	public static string String_9
	{
		get
		{
			if (Class415.string_9 == null)
			{
				Class415.string_9 = Class159.Class220_0.method_0("Item", "DropType");
			}
			return Class415.string_9;
		}
		set
		{
			Class415.string_9 = value;
			Class159.Class220_0.method_1("Item", "DropType", Class415.string_9);
		}
	}

	// Token: 0x170009C4 RID: 2500
	// (get) Token: 0x06002B4C RID: 11084 RVA: 0x0001F72A File Offset: 0x0001D92A
	// (set) Token: 0x06002B4D RID: 11085 RVA: 0x0001F751 File Offset: 0x0001D951
	public static string String_10
	{
		get
		{
			if (Class415.string_10 == null)
			{
				Class415.string_10 = Class159.Class220_0.method_0("Item", "CatThienCoName");
			}
			return Class415.string_10;
		}
		set
		{
			Class415.string_10 = value;
			Class159.Class220_0.method_1("Item", "CatThienCoName", Class415.string_10);
		}
	}

	// Token: 0x170009C5 RID: 2501
	// (get) Token: 0x06002B4E RID: 11086 RVA: 0x0001F772 File Offset: 0x0001D972
	// (set) Token: 0x06002B4F RID: 11087 RVA: 0x0001F799 File Offset: 0x0001D999
	public static string String_11
	{
		get
		{
			if (Class415.string_11 == null)
			{
				Class415.string_11 = Class159.Class220_0.method_0("Item", "CatThienCoType");
			}
			return Class415.string_11;
		}
		set
		{
			Class415.string_11 = value;
			Class159.Class220_0.method_1("Item", "CatThienCoType", Class415.string_11);
		}
	}

	// Token: 0x170009C6 RID: 2502
	// (get) Token: 0x06002B50 RID: 11088 RVA: 0x0001F7BA File Offset: 0x0001D9BA
	// (set) Token: 0x06002B51 RID: 11089 RVA: 0x0001F7E1 File Offset: 0x0001D9E1
	public static string String_12
	{
		get
		{
			if (Class415.string_12 == null)
			{
				Class415.string_12 = Class159.Class220_0.method_0("Item", "BankName");
			}
			return Class415.string_12;
		}
		set
		{
			Class415.string_12 = value;
			Class159.Class220_0.method_1("Item", "BankName", Class415.string_12);
		}
	}

	// Token: 0x170009C7 RID: 2503
	// (get) Token: 0x06002B52 RID: 11090 RVA: 0x0001F802 File Offset: 0x0001DA02
	// (set) Token: 0x06002B53 RID: 11091 RVA: 0x0001F829 File Offset: 0x0001DA29
	public static string String_13
	{
		get
		{
			if (Class415.string_13 == null)
			{
				Class415.string_13 = Class159.Class220_0.method_0("Item", "BankType");
			}
			return Class415.string_13;
		}
		set
		{
			Class415.string_13 = value;
			Class159.Class220_0.method_1("Item", "BankType", Class415.string_13);
		}
	}

	// Token: 0x170009C8 RID: 2504
	// (get) Token: 0x06002B54 RID: 11092 RVA: 0x0001F84A File Offset: 0x0001DA4A
	// (set) Token: 0x06002B55 RID: 11093 RVA: 0x0001F871 File Offset: 0x0001DA71
	public static string String_14
	{
		get
		{
			if (Class415.string_14 == null)
			{
				Class415.string_14 = Class159.Class220_0.method_0("Item", "LayName");
			}
			return Class415.string_14;
		}
		set
		{
			Class415.string_14 = value;
			Class159.Class220_0.method_1("Item", "LayName", Class415.string_14);
		}
	}

	// Token: 0x170009C9 RID: 2505
	// (get) Token: 0x06002B56 RID: 11094 RVA: 0x0001F892 File Offset: 0x0001DA92
	// (set) Token: 0x06002B57 RID: 11095 RVA: 0x0001F8B9 File Offset: 0x0001DAB9
	public static string String_15
	{
		get
		{
			if (Class415.string_15 == null)
			{
				Class415.string_15 = Class159.Class220_0.method_0("Item", "LayType");
			}
			return Class415.string_15;
		}
		set
		{
			Class415.string_15 = value;
			Class159.Class220_0.method_1("Item", "LayType", Class415.string_15);
		}
	}

	// Token: 0x170009CA RID: 2506
	// (get) Token: 0x06002B58 RID: 11096 RVA: 0x0001F8DA File Offset: 0x0001DADA
	// (set) Token: 0x06002B59 RID: 11097 RVA: 0x0001F901 File Offset: 0x0001DB01
	public static string String_16
	{
		get
		{
			if (Class415.string_16 == null)
			{
				Class415.string_16 = Class159.Class220_0.method_0("Item", "UseName");
			}
			return Class415.string_16;
		}
		set
		{
			Class415.string_16 = value;
			Class159.Class220_0.method_1("Item", "UseName", Class415.string_16);
		}
	}

	// Token: 0x170009CB RID: 2507
	// (get) Token: 0x06002B5A RID: 11098 RVA: 0x0001F922 File Offset: 0x0001DB22
	// (set) Token: 0x06002B5B RID: 11099 RVA: 0x0001F949 File Offset: 0x0001DB49
	public static string String_17
	{
		get
		{
			if (Class415.string_17 == null)
			{
				Class415.string_17 = Class159.Class220_0.method_0("Item", "UseType");
			}
			return Class415.string_17;
		}
		set
		{
			Class415.string_17 = value;
			Class159.Class220_0.method_1("Item", "UseType", Class415.string_17);
		}
	}

	// Token: 0x170009CC RID: 2508
	// (get) Token: 0x06002B5C RID: 11100 RVA: 0x0001F96A File Offset: 0x0001DB6A
	// (set) Token: 0x06002B5D RID: 11101 RVA: 0x0001F991 File Offset: 0x0001DB91
	public static string String_18
	{
		get
		{
			if (Class415.string_18 == null)
			{
				Class415.string_18 = Class159.Class220_0.method_0("Item", "LayThienCoName");
			}
			return Class415.string_18;
		}
		set
		{
			Class415.string_18 = value;
			Class159.Class220_0.method_1("Item", "LayThienCoName", Class415.string_18);
		}
	}

	// Token: 0x170009CD RID: 2509
	// (get) Token: 0x06002B5E RID: 11102 RVA: 0x0001F9B2 File Offset: 0x0001DBB2
	// (set) Token: 0x06002B5F RID: 11103 RVA: 0x0001F9D9 File Offset: 0x0001DBD9
	public static string String_19
	{
		get
		{
			if (Class415.string_19 == null)
			{
				Class415.string_19 = Class159.Class220_0.method_0("Item", "LayThienCoType");
			}
			return Class415.string_19;
		}
		set
		{
			Class415.string_19 = value;
			Class159.Class220_0.method_1("Item", "LayThienCoType", Class415.string_19);
		}
	}

	// Token: 0x170009CE RID: 2510
	// (get) Token: 0x06002B60 RID: 11104 RVA: 0x0001F9FA File Offset: 0x0001DBFA
	// (set) Token: 0x06002B61 RID: 11105 RVA: 0x0001FA21 File Offset: 0x0001DC21
	public static string String_20
	{
		get
		{
			if (Class415.string_20 == null)
			{
				Class415.string_20 = Class159.Class220_0.method_0("Item", "GomKNBName");
			}
			return Class415.string_20;
		}
		set
		{
			Class415.string_20 = value;
			Class159.Class220_0.method_1("Item", "GomKNBName", Class415.string_20);
		}
	}

	// Token: 0x170009CF RID: 2511
	// (get) Token: 0x06002B62 RID: 11106 RVA: 0x0001FA42 File Offset: 0x0001DC42
	// (set) Token: 0x06002B63 RID: 11107 RVA: 0x0001FA69 File Offset: 0x0001DC69
	public static string String_21
	{
		get
		{
			if (Class415.string_21 == null)
			{
				Class415.string_21 = Class159.Class220_0.method_0("Item", "GomKNBType");
			}
			return Class415.string_21;
		}
		set
		{
			Class415.string_21 = value;
			Class159.Class220_0.method_1("Item", "GomKNBType", Class415.string_21);
		}
	}

	// Token: 0x170009D0 RID: 2512
	// (get) Token: 0x06002B64 RID: 11108 RVA: 0x0001FA8A File Offset: 0x0001DC8A
	// (set) Token: 0x06002B65 RID: 11109 RVA: 0x0001FAB1 File Offset: 0x0001DCB1
	public static string String_22
	{
		get
		{
			if (Class415.string_22 == null)
			{
				Class415.string_22 = Class159.Class220_0.method_0("Item", "GomName");
			}
			return Class415.string_22;
		}
		set
		{
			Class415.string_22 = value;
			Class159.Class220_0.method_1("Item", "GomName", Class415.string_22);
		}
	}

	// Token: 0x170009D1 RID: 2513
	// (get) Token: 0x06002B66 RID: 11110 RVA: 0x0001FAD2 File Offset: 0x0001DCD2
	// (set) Token: 0x06002B67 RID: 11111 RVA: 0x0001FAF9 File Offset: 0x0001DCF9
	public static string String_23
	{
		get
		{
			if (Class415.string_23 == null)
			{
				Class415.string_23 = Class159.Class220_0.method_0("Item", "GomType");
			}
			return Class415.string_23;
		}
		set
		{
			Class415.string_23 = value;
			Class159.Class220_0.method_1("Item", "GomType", Class415.string_23);
		}
	}

	// Token: 0x170009D2 RID: 2514
	// (get) Token: 0x06002B68 RID: 11112 RVA: 0x00125DA8 File Offset: 0x00123FA8
	public static HashSet<string> HashSet_2
	{
		get
		{
			if (Class415.hashSet_5 == null)
			{
				Class415.hashSet_5 = new HashSet<string>();
				string[] array = Class415.String_24.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string text = array[i].Trim();
					if (!string.IsNullOrEmpty(text.Trim()) && !Class415.hashSet_5.Contains(text))
					{
						Class415.hashSet_5.Add(text);
					}
				}
			}
			return Class415.hashSet_5;
		}
	}

	// Token: 0x170009D3 RID: 2515
	// (get) Token: 0x06002B69 RID: 11113 RVA: 0x00125E20 File Offset: 0x00124020
	public static HashSet<string> HashSet_3
	{
		get
		{
			if (Class415.hashSet_6 == null)
			{
				Class415.hashSet_6 = new HashSet<string>();
				string[] array = Class415.String_25.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string text = array[i].Trim();
					if (!string.IsNullOrEmpty(text.Trim()) && !Class415.hashSet_6.Contains(text))
					{
						Class415.hashSet_6.Add(text);
					}
				}
			}
			return Class415.hashSet_6;
		}
	}

	// Token: 0x170009D4 RID: 2516
	// (get) Token: 0x06002B6A RID: 11114 RVA: 0x0001FB1A File Offset: 0x0001DD1A
	// (set) Token: 0x06002B6B RID: 11115 RVA: 0x0001FB41 File Offset: 0x0001DD41
	public static string String_24
	{
		get
		{
			if (Class415.string_24 == null)
			{
				Class415.string_24 = Class159.Class220_0.method_0("Item", "SellName");
			}
			return Class415.string_24;
		}
		set
		{
			Class415.string_24 = value;
			Class159.Class220_0.method_1("Item", "SellName", Class415.string_24);
			Class415.hashSet_5 = null;
		}
	}

	// Token: 0x170009D5 RID: 2517
	// (get) Token: 0x06002B6C RID: 11116 RVA: 0x0001FB68 File Offset: 0x0001DD68
	// (set) Token: 0x06002B6D RID: 11117 RVA: 0x0001FB8F File Offset: 0x0001DD8F
	public static string String_25
	{
		get
		{
			if (Class415.string_25 == null)
			{
				Class415.string_25 = Class159.Class220_0.method_0("Item", "SellType");
			}
			return Class415.string_25;
		}
		set
		{
			Class415.string_25 = value;
			Class159.Class220_0.method_1("Item", "SellType", Class415.string_25);
			Class415.hashSet_6 = null;
		}
	}

	// Token: 0x170009D6 RID: 2518
	// (get) Token: 0x06002B6E RID: 11118 RVA: 0x0001FBB6 File Offset: 0x0001DDB6
	// (set) Token: 0x06002B6F RID: 11119 RVA: 0x0001FBDD File Offset: 0x0001DDDD
	public static string String_26
	{
		get
		{
			if (Class415.string_26 == null)
			{
				Class415.string_26 = Class159.Class220_0.method_0("Item", "SellDinhSan");
			}
			return Class415.string_26;
		}
		set
		{
			Class415.string_26 = value;
			Class159.Class220_0.method_1("Item", "SellDinhSan", value);
		}
	}

	// Token: 0x170009D7 RID: 2519
	// (get) Token: 0x06002B70 RID: 11120 RVA: 0x0001FBFA File Offset: 0x0001DDFA
	// (set) Token: 0x06002B71 RID: 11121 RVA: 0x0001FC21 File Offset: 0x0001DE21
	public static string String_27
	{
		get
		{
			if (Class415.string_27 == null)
			{
				Class415.string_27 = Class159.Class220_0.method_0("Item", "DropDinhSan");
			}
			return Class415.string_27;
		}
		set
		{
			Class415.string_27 = value;
			Class159.Class220_0.method_1("Item", "DropDinhSan", value);
		}
	}

	// Token: 0x170009D8 RID: 2520
	// (get) Token: 0x06002B72 RID: 11122 RVA: 0x0001FC3E File Offset: 0x0001DE3E
	// (set) Token: 0x06002B73 RID: 11123 RVA: 0x0001FC65 File Offset: 0x0001DE65
	public static string String_28
	{
		get
		{
			if (Class415.string_28 == null)
			{
				Class415.string_28 = Class159.Class220_0.method_0("Item", "PkName");
			}
			return Class415.string_28;
		}
		set
		{
			Class415.string_28 = value;
			Class159.Class220_0.method_1("Item", "PkName", Class415.string_28);
		}
	}

	// Token: 0x170009D9 RID: 2521
	// (get) Token: 0x06002B74 RID: 11124 RVA: 0x0001FC86 File Offset: 0x0001DE86
	// (set) Token: 0x06002B75 RID: 11125 RVA: 0x0001FCAD File Offset: 0x0001DEAD
	public static string String_29
	{
		get
		{
			if (Class415.string_29 == null)
			{
				Class415.string_29 = Class159.Class220_0.method_0("Item", "PkGuild");
			}
			return Class415.string_29;
		}
		set
		{
			Class415.string_29 = value;
			Class159.Class220_0.method_1("Item", "PkGuild", Class415.string_29);
		}
	}

	// Token: 0x170009DA RID: 2522
	// (get) Token: 0x06002B76 RID: 11126 RVA: 0x0001FCCE File Offset: 0x0001DECE
	// (set) Token: 0x06002B77 RID: 11127 RVA: 0x0001FCF5 File Offset: 0x0001DEF5
	public static string String_30
	{
		get
		{
			if (Class415.string_30 == null)
			{
				Class415.string_30 = Class159.Class220_0.method_0("Item", "PkIgnore");
			}
			return Class415.string_30;
		}
		set
		{
			Class415.string_30 = value;
			Class159.Class220_0.method_1("Item", "PkIgnore", Class415.string_30);
		}
	}

	// Token: 0x170009DB RID: 2523
	// (get) Token: 0x06002B78 RID: 11128 RVA: 0x0001FD16 File Offset: 0x0001DF16
	// (set) Token: 0x06002B79 RID: 11129 RVA: 0x0001FD3D File Offset: 0x0001DF3D
	public static string String_31
	{
		get
		{
			if (Class415.string_31 == null)
			{
				Class415.string_31 = Class159.Class220_0.method_0("Item", "Leader");
			}
			return Class415.string_31;
		}
		set
		{
			Class415.string_31 = value;
			Class159.Class220_0.method_1("Item", "Leader", Class415.string_31);
		}
	}

	// Token: 0x170009DC RID: 2524
	// (get) Token: 0x06002B7A RID: 11130 RVA: 0x0001FD5E File Offset: 0x0001DF5E
	// (set) Token: 0x06002B7B RID: 11131 RVA: 0x0001FD85 File Offset: 0x0001DF85
	public static string String_32
	{
		get
		{
			if (Class415.string_32 == null)
			{
				Class415.string_32 = Class159.Class220_0.method_0("Item", "LoginInfo");
			}
			return Class415.string_32;
		}
		set
		{
			Class415.string_32 = value;
			Class159.Class220_0.method_1("Item", "LoginInfo", Class415.string_32);
		}
	}

	// Token: 0x06002B7C RID: 11132 RVA: 0x0001FDA6 File Offset: 0x0001DFA6
	public static void smethod_1(string string_33, string string_34, string string_35)
	{
		Class159.Class220_0.method_1(string_33, string_34, string_35);
	}

	// Token: 0x06002B7D RID: 11133 RVA: 0x0001FDB5 File Offset: 0x0001DFB5
	public static string smethod_2(string string_33, string string_34)
	{
		return Class159.Class220_0.method_0(string_33, string_34);
	}

	// Token: 0x06002B7E RID: 11134 RVA: 0x00125E98 File Offset: 0x00124098
	public static int[] smethod_3(string string_33)
	{
		int[] result;
		try
		{
			string_33 = string_33.ToUpper();
			if (!Class415.string_0.Contains("@" + string_33 + ":"))
			{
				result = new int[1];
			}
			else
			{
				string_33 = Class415.string_0.Substring(Class415.string_0.IndexOf("@" + string_33 + ":") + ("@" + string_33 + ":").Length);
				string_33 = string_33.Substring(0, string_33.IndexOf("#"));
				result = Class415.smethod_10(string_33);
			}
		}
		catch
		{
			result = new int[1];
		}
		return result;
	}

	// Token: 0x06002B7F RID: 11135 RVA: 0x0001FDC3 File Offset: 0x0001DFC3
	public static void smethod_4(string string_33, string string_34)
	{
		Class159.Class220_0.method_1("MAP", string_33, string_34);
	}

	// Token: 0x06002B80 RID: 11136 RVA: 0x00125F48 File Offset: 0x00124148
	public static string smethod_5(string string_33)
	{
		string text = Class159.Class220_0.method_0("MAP", string_33);
		if (text == string.Empty)
		{
			text = Class415.class220_0.method_0("MAP", string_33);
		}
		return text;
	}

	// Token: 0x06002B81 RID: 11137 RVA: 0x0001FDD6 File Offset: 0x0001DFD6
	public static void smethod_6(string string_33, string string_34)
	{
		Class159.Class220_0.method_1("BossMap", string_33, string_34);
	}

	// Token: 0x06002B82 RID: 11138 RVA: 0x00125F88 File Offset: 0x00124188
	public static string smethod_7(string string_33)
	{
		string text = Class159.Class220_0.method_0("BossMAP", string_33);
		if (text == string.Empty)
		{
			text = Class415.class220_0.method_0("BossMap", string_33);
		}
		return text;
	}

	// Token: 0x06002B83 RID: 11139 RVA: 0x0001FDE9 File Offset: 0x0001DFE9
	public static void smethod_8(string string_33, string string_34)
	{
		Class159.Class220_0.method_1("WAY", string_33, string_34);
	}

	// Token: 0x06002B84 RID: 11140 RVA: 0x0001FDFC File Offset: 0x0001DFFC
	public static string smethod_9(string string_33)
	{
		string_33 = Class159.Class220_0.method_0("WAY", string_33);
		return string_33;
	}

	// Token: 0x06002B85 RID: 11141 RVA: 0x00125FC8 File Offset: 0x001241C8
	public static int[] smethod_10(string string_33)
	{
		string[] array = string_33.Split(new char[]
		{
			','
		});
		int[] array2 = new int[array.Length];
		for (int i = 0; i < array2.Length; i++)
		{
			array2[i] = Class415.smethod_11(array[i]);
		}
		return array2;
	}

	// Token: 0x06002B86 RID: 11142 RVA: 0x0012600C File Offset: 0x0012420C
	public static int smethod_11(string string_33)
	{
		int result = 0;
		int.TryParse(string_33, out result);
		return result;
	}

	// Token: 0x06002B87 RID: 11143 RVA: 0x00126028 File Offset: 0x00124228
	public static void smethod_12()
	{
		Class415.string_10 = (Class415.string_11 = null);
		Class415.hashSet_0 = null;
		Class415.string_1 = null;
		Class415.hashSet_3 = null;
		Class415.string_3 = null;
		Class415.string_4 = null;
		Class415.string_5 = null;
		Class415.string_6 = null;
		Class415.string_7 = null;
		Class415.string_8 = null;
		Class415.string_9 = null;
		Class415.string_12 = null;
		Class415.string_13 = null;
		Class415.string_14 = null;
		Class415.string_15 = null;
		Class415.string_16 = null;
		Class415.string_17 = null;
		Class415.string_18 = null;
		Class415.string_19 = null;
		Class415.string_20 = null;
		Class415.string_21 = null;
		Class415.string_22 = null;
		Class415.string_23 = null;
		Class415.hashSet_5 = null;
		Class415.hashSet_6 = null;
		Class415.string_24 = null;
		Class415.string_25 = null;
		Class415.string_28 = null;
		Class415.string_29 = null;
		Class415.string_30 = null;
		Class415.string_31 = null;
		Class415.string_32 = null;
	}

	// Token: 0x04001CCD RID: 7373
	public static Class220 class220_0 = new Class220(GClass130.String_6);

	// Token: 0x04001CCE RID: 7374
	public static string string_0 = string.Empty;

	// Token: 0x04001CCF RID: 7375
	public static HashSet<string> hashSet_0;

	// Token: 0x04001CD0 RID: 7376
	public static string string_1;

	// Token: 0x04001CD1 RID: 7377
	public static HashSet<string> hashSet_1 = new HashSet<string>();

	// Token: 0x04001CD2 RID: 7378
	public static HashSet<string> hashSet_2 = new HashSet<string>();

	// Token: 0x04001CD3 RID: 7379
	public static HashSet<string> hashSet_3;

	// Token: 0x04001CD4 RID: 7380
	public static string string_2;

	// Token: 0x04001CD5 RID: 7381
	public static string string_3;

	// Token: 0x04001CD6 RID: 7382
	private static string string_4;

	// Token: 0x04001CD7 RID: 7383
	private static string string_5;

	// Token: 0x04001CD8 RID: 7384
	private static string string_6;

	// Token: 0x04001CD9 RID: 7385
	[CompilerGenerated]
	private static HashSet<string> hashSet_4;

	// Token: 0x04001CDA RID: 7386
	public static string string_7;

	// Token: 0x04001CDB RID: 7387
	public static string string_8;

	// Token: 0x04001CDC RID: 7388
	public static string string_9;

	// Token: 0x04001CDD RID: 7389
	public static string string_10;

	// Token: 0x04001CDE RID: 7390
	public static string string_11;

	// Token: 0x04001CDF RID: 7391
	public static string string_12;

	// Token: 0x04001CE0 RID: 7392
	public static string string_13;

	// Token: 0x04001CE1 RID: 7393
	public static string string_14;

	// Token: 0x04001CE2 RID: 7394
	public static string string_15;

	// Token: 0x04001CE3 RID: 7395
	public static string string_16;

	// Token: 0x04001CE4 RID: 7396
	public static string string_17;

	// Token: 0x04001CE5 RID: 7397
	public static string string_18;

	// Token: 0x04001CE6 RID: 7398
	public static string string_19;

	// Token: 0x04001CE7 RID: 7399
	public static string string_20;

	// Token: 0x04001CE8 RID: 7400
	public static string string_21;

	// Token: 0x04001CE9 RID: 7401
	public static string string_22;

	// Token: 0x04001CEA RID: 7402
	public static string string_23;

	// Token: 0x04001CEB RID: 7403
	public static HashSet<string> hashSet_5;

	// Token: 0x04001CEC RID: 7404
	public static HashSet<string> hashSet_6;

	// Token: 0x04001CED RID: 7405
	public static string string_24;

	// Token: 0x04001CEE RID: 7406
	public static string string_25;

	// Token: 0x04001CEF RID: 7407
	private static string string_26;

	// Token: 0x04001CF0 RID: 7408
	private static string string_27;

	// Token: 0x04001CF1 RID: 7409
	public static string string_28;

	// Token: 0x04001CF2 RID: 7410
	public static HashSet<string> hashSet_7 = new HashSet<string>();

	// Token: 0x04001CF3 RID: 7411
	public static string string_29;

	// Token: 0x04001CF4 RID: 7412
	public static HashSet<string> hashSet_8 = new HashSet<string>();

	// Token: 0x04001CF5 RID: 7413
	public static string string_30;

	// Token: 0x04001CF6 RID: 7414
	public static HashSet<string> hashSet_9 = new HashSet<string>();

	// Token: 0x04001CF7 RID: 7415
	private static string string_31;

	// Token: 0x04001CF8 RID: 7416
	private static string string_32;

	// Token: 0x020002F5 RID: 757
	[CompilerGenerated]
	[Serializable]
	private sealed class Class416
	{
		// Token: 0x06002B8C RID: 11148 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_0(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B8D RID: 11149 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_1(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x06002B8E RID: 11150 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_2(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B8F RID: 11151 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_3(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x06002B90 RID: 11152 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_4(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B91 RID: 11153 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_5(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x06002B92 RID: 11154 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_6(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B93 RID: 11155 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_7(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x06002B94 RID: 11156 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_8(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B95 RID: 11157 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_9(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x06002B96 RID: 11158 RVA: 0x00011A24 File Offset: 0x0000FC24
		internal string method_10(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002B97 RID: 11159 RVA: 0x00011A2C File Offset: 0x0000FC2C
		internal bool method_11(string string_0)
		{
			return string_0.Length > 1;
		}

		// Token: 0x04001CF9 RID: 7417
		public static readonly Class415.Class416 <>9 = new Class415.Class416();

		// Token: 0x04001CFA RID: 7418
		public static Func<string, string> <>9__4_0;

		// Token: 0x04001CFB RID: 7419
		public static Func<string, bool> <>9__4_1;

		// Token: 0x04001CFC RID: 7420
		public static Func<string, string> <>9__24_0;

		// Token: 0x04001CFD RID: 7421
		public static Func<string, bool> <>9__24_1;

		// Token: 0x04001CFE RID: 7422
		public static Func<string, string> <>9__24_2;

		// Token: 0x04001CFF RID: 7423
		public static Func<string, bool> <>9__24_3;

		// Token: 0x04001D00 RID: 7424
		public static Func<string, string> <>9__24_4;

		// Token: 0x04001D01 RID: 7425
		public static Func<string, bool> <>9__24_5;

		// Token: 0x04001D02 RID: 7426
		public static Func<string, string> <>9__24_6;

		// Token: 0x04001D03 RID: 7427
		public static Func<string, bool> <>9__24_7;

		// Token: 0x04001D04 RID: 7428
		public static Func<string, string> <>9__24_8;

		// Token: 0x04001D05 RID: 7429
		public static Func<string, bool> <>9__24_9;
	}
}
