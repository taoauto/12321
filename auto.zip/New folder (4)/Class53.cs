﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000072 RID: 114
internal class Class53<T> : GClass29 where T : GClass27
{
	// Token: 0x06000520 RID: 1312 RVA: 0x0000653E File Offset: 0x0000473E
	internal Class53(string string_1, Func<T> func_1, GClass24 gclass24_1) : this(string_1, func_1, null, gclass24_1)
	{
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0000654A File Offset: 0x0000474A
	internal Class53(string string_1, Func<T> func_1, Action<T> action_0, GClass24 gclass24_1) : base(string_1, gclass24_1)
	{
		this.func_0 = this.method_3(func_1, action_0);
	}

	// Token: 0x17000155 RID: 341
	// (get) Token: 0x06000522 RID: 1314 RVA: 0x00006563 File Offset: 0x00004763
	public override Type \u200B\u206C\u200D\u206D\u206C\u202D\u202E\u206E\u202C\u206E\u206B\u206B\u202D\u200B\u200E\u206E\u200E\u200E\u206C\u200C\u206A\u202B\u202B\u202C\u202D\u200E\u202B\u206B\u206D\u200F\u200C\u202D\u206F\u202B\u206F\u200D\u200C\u200B\u202C\u200E\u202E
	{
		get
		{
			return typeof(T);
		}
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x00031030 File Offset: 0x0002F230
	private Func<T> method_3(Func<T> func_1, Action<T> action_0)
	{
		Class53<T>.Class54 @class = new Class53<T>.Class54();
		@class.func_0 = func_1;
		@class.action_0 = action_0;
		if (@class.action_0 == null)
		{
			return @class.func_0;
		}
		return new Func<T>(@class.method_0);
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0000656F File Offset: 0x0000476F
	protected override GClass27 \u202A\u200C\u206D\u200B\u206E\u202A\u202C\u206D\u202B\u206F\u206D\u206E\u200F\u206A\u200D\u202C\u200B\u200E\u200E\u200B\u202B\u202E\u200D\u200D\u202C\u206D\u200E\u200B\u206E\u200D\u202D\u206D\u206C\u200D\u206E\u202D\u202C\u202E\u206C\u202A\u202E()
	{
		return this.func_0();
	}

	// Token: 0x040002A5 RID: 677
	private Func<T> func_0;

	// Token: 0x02000073 RID: 115
	[CompilerGenerated]
	private sealed class Class54
	{
		// Token: 0x06000526 RID: 1318 RVA: 0x0003106C File Offset: 0x0002F26C
		internal T method_0()
		{
			T t = this.func_0();
			this.action_0(t);
			return t;
		}

		// Token: 0x040002A6 RID: 678
		public Func<T> func_0;

		// Token: 0x040002A7 RID: 679
		public Action<T> action_0;
	}
}
