﻿using System;
using System.Collections.Generic;

// Token: 0x020000C2 RID: 194
public class GClass57 : GClass56
{
	// Token: 0x06000969 RID: 2409 RVA: 0x000091CC File Offset: 0x000073CC
	public GClass57(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
		fastColoredTextBox_1.Event_16 += this.vmethod_1;
		fastColoredTextBox_1.Event_17 += this.vmethod_0;
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x0003E300 File Offset: 0x0003C500
	protected virtual void vmethod_0(object sender, GEventArgs10 e)
	{
		for (int i = 0; i < this.Count; i++)
		{
			if (this.list_0[i].Int32_0 >= e.Int32_0)
			{
				if (this.list_0[i].Int32_0 >= e.Int32_0 + e.Int32_1)
				{
					this.list_0[i].Int32_0 = this.list_0[i].Int32_0 - e.Int32_1;
				}
				else
				{
					bool flag = e.Int32_0 <= 0;
					using (List<GClass58>.Enumerator enumerator = this.list_0.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (enumerator.Current.Int32_0 == e.Int32_0 - 1)
							{
								flag = true;
							}
						}
					}
					if (flag)
					{
						this.list_0.RemoveAt(i);
						i--;
					}
					else
					{
						this.list_0[i].Int32_0 = e.Int32_0 - 1;
					}
				}
			}
		}
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x0003E418 File Offset: 0x0003C618
	protected virtual void vmethod_1(object sender, GEventArgs9 e)
	{
		for (int i = 0; i < this.Count; i++)
		{
			if (this.list_0[i].Int32_0 >= e.Int32_0)
			{
				this.list_0[i].Int32_0 = this.list_0[i].Int32_0 + e.Int32_1;
			}
			else if (this.list_0[i].Int32_0 == e.Int32_0 - 1 && e.Int32_1 == 1 && this.fastColoredTextBox_0[e.Int32_0 - 1].Int32_2 == this.fastColoredTextBox_0[e.Int32_0 - 1].Count)
			{
				this.list_0[i].Int32_0 = this.list_0[i].Int32_0 + e.Int32_1;
			}
		}
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x0000920C File Offset: 0x0000740C
	public virtual void Dispose()
	{
		this.fastColoredTextBox_0.Event_16 -= this.vmethod_1;
		this.fastColoredTextBox_0.Event_17 -= this.vmethod_0;
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x0000923E File Offset: 0x0000743E
	public virtual IEnumerator<GClass58> GetEnumerator()
	{
		GClass57.Class88 @class = new GClass57.Class88(0);
		@class.gclass57_0 = this;
		return @class;
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x0000924D File Offset: 0x0000744D
	public override void \u202B\u206E\u202B\u202C\u200F\u200D\u206D\u206D\u202E\u202E\u202C\u202B\u200C\u202B\u206A\u206A\u202E\u202E\u202D\u200E\u206A\u202E\u200C\u206A\u206B\u202B\u202B\u202A\u206E\u200F\u202C\u202B\u202A\u200C\u206D\u206D\u206A\u202D\u206E\u206C\u202E(int int_1, string string_0)
	{
		this.Add(new GClass58(this.fastColoredTextBox_0, string_0 ?? ("Bookmark " + this.int_0.ToString()), int_1));
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x0000927B File Offset: 0x0000747B
	public override void \u202B\u206E\u202B\u202C\u200F\u200D\u206D\u206D\u202E\u202E\u202C\u202B\u200C\u202B\u206A\u206A\u202E\u202E\u202D\u200E\u206A\u202E\u200C\u206A\u206B\u202B\u202B\u202A\u206E\u200F\u202C\u202B\u202A\u200C\u206D\u206D\u206A\u202D\u206E\u206C\u202E(int int_1)
	{
		this.Add(new GClass58(this.fastColoredTextBox_0, "Bookmark " + this.int_0.ToString(), int_1));
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x000092A4 File Offset: 0x000074A4
	public virtual void Clear()
	{
		this.list_0.Clear();
		this.int_0 = 0;
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x0003E500 File Offset: 0x0003C700
	public virtual void Add(GClass58 item)
	{
		using (List<GClass58>.Enumerator enumerator = this.list_0.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.Int32_0 == item.Int32_0)
				{
					return;
				}
			}
		}
		this.list_0.Add(item);
		this.int_0++;
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x000092B8 File Offset: 0x000074B8
	public virtual bool Contains(GClass58 item)
	{
		return this.list_0.Contains(item);
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x0003E584 File Offset: 0x0003C784
	public override bool \u206B\u206C\u200F\u206F\u200F\u202D\u202C\u200F\u200C\u206B\u202C\u200C\u200C\u200B\u206D\u206F\u206A\u206C\u200C\u200E\u200E\u206C\u200E\u206D\u206F\u202D\u202A\u200C\u200B\u202E\u206E\u206D\u202A\u200E\u202A\u202A\u200C\u206B\u206C\u202E\u202E(int int_1)
	{
		using (List<GClass58>.Enumerator enumerator = this.list_0.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.Int32_0 == int_1)
				{
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x000092C6 File Offset: 0x000074C6
	public virtual void CopyTo(GClass58[] array, int arrayIndex)
	{
		this.list_0.CopyTo(array, arrayIndex);
	}

	// Token: 0x170002A3 RID: 675
	// (get) Token: 0x06000975 RID: 2421 RVA: 0x000092D5 File Offset: 0x000074D5
	public virtual int Count
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x170002A4 RID: 676
	// (get) Token: 0x06000976 RID: 2422 RVA: 0x00006FDC File Offset: 0x000051DC
	public virtual bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x000092E2 File Offset: 0x000074E2
	public virtual bool Remove(GClass58 item)
	{
		this.fastColoredTextBox_0.method_4();
		return this.list_0.Remove(item);
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x0003E5E4 File Offset: 0x0003C7E4
	public override bool \u202E\u200F\u206E\u200D\u202D\u202A\u200B\u202A\u200E\u202B\u202C\u206B\u206D\u200C\u200D\u202E\u206B\u206C\u206C\u200D\u206C\u206E\u202A\u206E\u200F\u202E\u206B\u206F\u206B\u206A\u200E\u202C\u200E\u202D\u200C\u202A\u200C\u200B\u206E\u200F\u202E(int int_1)
	{
		bool result = false;
		for (int i = 0; i < this.Count; i++)
		{
			if (this.list_0[i].Int32_0 == int_1)
			{
				this.list_0.RemoveAt(i);
				i--;
				result = true;
			}
		}
		this.fastColoredTextBox_0.method_4();
		return result;
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x000092FB File Offset: 0x000074FB
	public override GClass58 \u202E\u206A\u206E\u200F\u206A\u206B\u200D\u202E\u200D\u206F\u206E\u202A\u200C\u202B\u202E\u202D\u206B\u200E\u206F\u200C\u200C\u200F\u206B\u200F\u200F\u206C\u206B\u206F\u202A\u202B\u206B\u200C\u202D\u206A\u202B\u200D\u200D\u202A\u206F\u202D\u202E(int int_1)
	{
		return this.list_0[int_1];
	}

	// Token: 0x040004AB RID: 1195
	protected FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040004AC RID: 1196
	protected List<GClass58> list_0 = new List<GClass58>();

	// Token: 0x040004AD RID: 1197
	protected int int_0;
}
