﻿using System;
using System.Diagnostics;
using System.IO;

// Token: 0x0200004B RID: 75
public class GClass24
{
	// Token: 0x06000327 RID: 807 RVA: 0x00005018 File Offset: 0x00003218
	public GClass24() : this(GEnum7.Error, null, null)
	{
	}

	// Token: 0x06000328 RID: 808 RVA: 0x00005023 File Offset: 0x00003223
	public GClass24(GEnum7 genum7_1) : this(genum7_1, null, null)
	{
	}

	// Token: 0x06000329 RID: 809 RVA: 0x0000502E File Offset: 0x0000322E
	public GClass24(GEnum7 genum7_1, string string_1, Action<GClass23, string> action_1)
	{
		this.genum7_0 = genum7_1;
		this.string_0 = string_1;
		this.action_0 = (action_1 ?? new Action<GClass23, string>(GClass24.smethod_0));
		this.object_0 = new object();
	}

	// Token: 0x170000D9 RID: 217
	// (get) Token: 0x0600032A RID: 810 RVA: 0x0000506A File Offset: 0x0000326A
	// (set) Token: 0x0600032B RID: 811 RVA: 0x0002A4C4 File Offset: 0x000286C4
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			object obj = this.object_0;
			lock (obj)
			{
				this.string_0 = value;
				this.method_6(string.Format("The current path to the log file has been changed to {0}.", this.string_0));
			}
		}
	}

	// Token: 0x170000DA RID: 218
	// (get) Token: 0x0600032C RID: 812 RVA: 0x00005074 File Offset: 0x00003274
	// (set) Token: 0x0600032D RID: 813 RVA: 0x0002A520 File Offset: 0x00028720
	public GEnum7 GEnum7_0
	{
		get
		{
			return this.genum7_0;
		}
		set
		{
			object obj = this.object_0;
			lock (obj)
			{
				this.genum7_0 = value;
				this.method_6(string.Format("The current logging level has been changed to {0}.", this.genum7_0));
			}
		}
	}

	// Token: 0x170000DB RID: 219
	// (get) Token: 0x0600032E RID: 814 RVA: 0x0000507E File Offset: 0x0000327E
	// (set) Token: 0x0600032F RID: 815 RVA: 0x0002A580 File Offset: 0x00028780
	public Action<GClass23, string> Action_0
	{
		get
		{
			return this.action_0;
		}
		set
		{
			object obj = this.object_0;
			lock (obj)
			{
				this.action_0 = (value ?? new Action<GClass23, string>(GClass24.smethod_0));
				this.method_6("The current output action has been changed.");
			}
		}
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0002A5DC File Offset: 0x000287DC
	private static void smethod_0(GClass23 gclass23_0, string string_1)
	{
		string text = gclass23_0.ToString();
		Console.WriteLine(text);
		if (string_1 != null && string_1.Length > 0)
		{
			GClass24.smethod_1(text, string_1);
		}
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0002A60C File Offset: 0x0002880C
	private void method_0(string string_1, GEnum7 genum7_1)
	{
		object obj = this.object_0;
		lock (obj)
		{
			if (this.genum7_0 <= genum7_1)
			{
				try
				{
					GClass23 gclass = new GClass23(genum7_1, new StackFrame(2, true), string_1);
					this.action_0(gclass, this.string_0);
				}
				catch (Exception ex)
				{
					GClass23 gclass = new GClass23(GEnum7.Fatal, new StackFrame(0, true), ex.Message);
					Console.WriteLine(gclass.ToString());
				}
			}
		}
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0002A6A8 File Offset: 0x000288A8
	private static void smethod_1(string string_1, string string_2)
	{
		using (StreamWriter streamWriter = new StreamWriter(string_2, true))
		{
			using (TextWriter textWriter = TextWriter.Synchronized(streamWriter))
			{
				textWriter.WriteLine(string_1);
			}
		}
	}

	// Token: 0x06000333 RID: 819 RVA: 0x00005086 File Offset: 0x00003286
	public void method_1(string string_1)
	{
		if (this.genum7_0 > GEnum7.Debug)
		{
			return;
		}
		this.method_0(string_1, GEnum7.Debug);
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0000509C File Offset: 0x0000329C
	public void method_2(string string_1)
	{
		if (this.genum7_0 > GEnum7.Error)
		{
			return;
		}
		this.method_0(string_1, GEnum7.Error);
	}

	// Token: 0x06000335 RID: 821 RVA: 0x000050B2 File Offset: 0x000032B2
	public void method_3(string string_1)
	{
		this.method_0(string_1, GEnum7.Fatal);
	}

	// Token: 0x06000336 RID: 822 RVA: 0x000050BC File Offset: 0x000032BC
	public void method_4(string string_1)
	{
		if (this.genum7_0 > GEnum7.Info)
		{
			return;
		}
		this.method_0(string_1, GEnum7.Info);
	}

	// Token: 0x06000337 RID: 823 RVA: 0x000050D2 File Offset: 0x000032D2
	public void method_5(string string_1)
	{
		if (this.genum7_0 > GEnum7.Trace)
		{
			return;
		}
		this.method_0(string_1, GEnum7.Trace);
	}

	// Token: 0x06000338 RID: 824 RVA: 0x000050E8 File Offset: 0x000032E8
	public void method_6(string string_1)
	{
		if (this.genum7_0 > GEnum7.Warn)
		{
			return;
		}
		this.method_0(string_1, GEnum7.Warn);
	}

	// Token: 0x040001C6 RID: 454
	private volatile string string_0;

	// Token: 0x040001C7 RID: 455
	private volatile GEnum7 genum7_0;

	// Token: 0x040001C8 RID: 456
	private Action<GClass23, string> action_0;

	// Token: 0x040001C9 RID: 457
	private object object_0;
}
