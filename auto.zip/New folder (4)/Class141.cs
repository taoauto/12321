﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

// Token: 0x0200015D RID: 349
[Serializable]
internal class Class141
{
	// Token: 0x06001090 RID: 4240 RVA: 0x0000D69E File Offset: 0x0000B89E
	public static Class141 smethod_0(string string_0)
	{
		return new Class141
		{
			String_0 = string_0
		};
	}

	// Token: 0x06001091 RID: 4241 RVA: 0x0005BB00 File Offset: 0x00059D00
	public static Class141[] smethod_1(string[] string_0)
	{
		List<Class141> list = new List<Class141>();
		for (int i = 0; i < string_0.Length; i++)
		{
			if (Class141.smethod_3(string_0[i]))
			{
				list.Add(Class141.smethod_0(string_0[i]));
			}
		}
		return list.ToArray();
	}

	// Token: 0x06001092 RID: 4242 RVA: 0x0000D6AC File Offset: 0x0000B8AC
	public static Class141 smethod_2(string string_0, bool bool_0, string string_1, string string_2)
	{
		return new Class141
		{
			String_0 = string_0,
			Boolean_0 = bool_0,
			String_1 = string_1,
			String_2 = string_2
		};
	}

	// Token: 0x17000443 RID: 1091
	// (get) Token: 0x06001093 RID: 4243 RVA: 0x0000D6CF File Offset: 0x0000B8CF
	// (set) Token: 0x06001094 RID: 4244 RVA: 0x0000D6D7 File Offset: 0x0000B8D7
	public string String_0
	{
		get
		{
			return this.url;
		}
		set
		{
			this.url = value;
			this.method_1();
		}
	}

	// Token: 0x17000444 RID: 1092
	// (get) Token: 0x06001095 RID: 4245 RVA: 0x0000D6E6 File Offset: 0x0000B8E6
	// (set) Token: 0x06001096 RID: 4246 RVA: 0x0000D6EE File Offset: 0x0000B8EE
	public bool Boolean_0
	{
		get
		{
			return this.authenticate;
		}
		set
		{
			this.authenticate = value;
		}
	}

	// Token: 0x17000445 RID: 1093
	// (get) Token: 0x06001097 RID: 4247 RVA: 0x0000D6F7 File Offset: 0x0000B8F7
	// (set) Token: 0x06001098 RID: 4248 RVA: 0x0000D6FF File Offset: 0x0000B8FF
	public string String_1
	{
		get
		{
			return this.login;
		}
		set
		{
			this.login = value;
		}
	}

	// Token: 0x17000446 RID: 1094
	// (get) Token: 0x06001099 RID: 4249 RVA: 0x0000D708 File Offset: 0x0000B908
	// (set) Token: 0x0600109A RID: 4250 RVA: 0x0000D710 File Offset: 0x0000B910
	public string String_2
	{
		get
		{
			return this.password;
		}
		set
		{
			this.password = value;
		}
	}

	// Token: 0x17000447 RID: 1095
	// (get) Token: 0x0600109B RID: 4251 RVA: 0x0000D719 File Offset: 0x0000B919
	// (set) Token: 0x0600109C RID: 4252 RVA: 0x0000D736 File Offset: 0x0000B936
	public string String_3
	{
		get
		{
			if (this.protocolProviderType == null)
			{
				return null;
			}
			return this.protocolProviderType.AssemblyQualifiedName;
		}
		set
		{
			if (value == null)
			{
				this.method_1();
				return;
			}
			this.protocolProviderType = Type.GetType(value);
		}
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x0000D74E File Offset: 0x0000B94E
	public Interface5 method_0(Class130 class130_0)
	{
		return this.method_2(class130_0);
	}

	// Token: 0x0600109E RID: 4254 RVA: 0x0000D757 File Offset: 0x0000B957
	public void method_1()
	{
		this.provider = null;
		if (!string.IsNullOrEmpty(this.String_0))
		{
			this.protocolProviderType = Class133.smethod_3(this.String_0);
		}
	}

	// Token: 0x0600109F RID: 4255 RVA: 0x0000D77E File Offset: 0x0000B97E
	public Interface5 method_2(Class130 class130_0)
	{
		if (this.protocolProviderType == null)
		{
			this.method_1();
		}
		if (this.provider == null)
		{
			this.provider = Class133.smethod_4(this.protocolProviderType, class130_0);
		}
		return this.provider;
	}

	// Token: 0x060010A0 RID: 4256 RVA: 0x0000D7B4 File Offset: 0x0000B9B4
	public Class141 method_3()
	{
		return (Class141)base.MemberwiseClone();
	}

	// Token: 0x060010A1 RID: 4257 RVA: 0x0000D7C1 File Offset: 0x0000B9C1
	public virtual string ToString()
	{
		return this.String_0;
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x0000D7C9 File Offset: 0x0000B9C9
	public static bool smethod_3(string string_0)
	{
		return Regex.Match(string_0, "(?<Protocol>\\w+):\\/\\/(?<Domain>[\\w.]+\\/?)\\S*").ToString() != string.Empty;
	}

	// Token: 0x04000861 RID: 2145
	private string url;

	// Token: 0x04000862 RID: 2146
	private bool authenticate;

	// Token: 0x04000863 RID: 2147
	private string login;

	// Token: 0x04000864 RID: 2148
	private string password;

	// Token: 0x04000865 RID: 2149
	private Type protocolProviderType;

	// Token: 0x04000866 RID: 2150
	private Interface5 provider;
}
