﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

// Token: 0x02000089 RID: 137
internal sealed class Class68
{
	// Token: 0x06000649 RID: 1609 RVA: 0x0003544C File Offset: 0x0003364C
	internal Class68(IPEndPoint ipendPoint_1, bool bool_1, string string_1, GClass44 gclass44_1, bool bool_2)
	{
		if (bool_1)
		{
			X509Certificate2 x509Certificate = Class68.smethod_2(ipendPoint_1.Port, string_1, gclass44_1.X509Certificate2_0);
			if (x509Certificate == null)
			{
				throw new ArgumentException("No server certificate could be found.");
			}
			this.bool_0 = true;
			this.gclass44_0 = new GClass44(gclass44_1);
			this.gclass44_0.X509Certificate2_0 = x509Certificate;
		}
		this.ipendPoint_0 = ipendPoint_1;
		this.dictionary_0 = new Dictionary<Class74, GClass37>();
		this.dictionary_1 = new Dictionary<Class70, Class70>();
		this.object_0 = ((ICollection)this.dictionary_1).SyncRoot;
		this.socket_0 = new Socket(ipendPoint_1.Address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
		if (bool_2)
		{
			this.socket_0.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
		}
		this.socket_0.Bind(ipendPoint_1);
		this.socket_0.Listen(500);
		this.socket_0.BeginAccept(new AsyncCallback(Class68.smethod_3), this);
	}

	// Token: 0x1700019E RID: 414
	// (get) Token: 0x0600064A RID: 1610 RVA: 0x0000711D File Offset: 0x0000531D
	public IPAddress IPAddress_0
	{
		get
		{
			return this.ipendPoint_0.Address;
		}
	}

	// Token: 0x1700019F RID: 415
	// (get) Token: 0x0600064B RID: 1611 RVA: 0x0000712A File Offset: 0x0000532A
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x170001A0 RID: 416
	// (get) Token: 0x0600064C RID: 1612 RVA: 0x00007132 File Offset: 0x00005332
	public int Int32_0
	{
		get
		{
			return this.ipendPoint_0.Port;
		}
	}

	// Token: 0x170001A1 RID: 417
	// (get) Token: 0x0600064D RID: 1613 RVA: 0x0000713F File Offset: 0x0000533F
	public GClass44 GClass44_0
	{
		get
		{
			return this.gclass44_0;
		}
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00035538 File Offset: 0x00033738
	private static void smethod_0(List<Class74> list_2, Class74 class74_0)
	{
		string string_ = class74_0.String_2;
		using (List<Class74>.Enumerator enumerator = list_2.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.String_2 == string_)
				{
					string text = "The prefix is already in use.";
					throw new GException5(87, text);
				}
			}
		}
		list_2.Add(class74_0);
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x000355AC File Offset: 0x000337AC
	private static RSACryptoServiceProvider smethod_1(string string_1)
	{
		byte[] array = null;
		using (FileStream fileStream = File.Open(string_1, FileMode.Open, FileAccess.Read, FileShare.Read))
		{
			array = new byte[fileStream.Length];
			fileStream.Read(array, 0, array.Length);
		}
		RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
		rsacryptoServiceProvider.ImportCspBlob(array);
		return rsacryptoServiceProvider;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00035608 File Offset: 0x00033808
	private static X509Certificate2 smethod_2(int int_0, string string_1, X509Certificate2 x509Certificate2_0)
	{
		if (string_1 == null || string_1.Length == 0)
		{
			string_1 = Class68.string_0;
		}
		try
		{
			string text = Path.Combine(string_1, string.Format("{0}.cer", int_0));
			string text2 = Path.Combine(string_1, string.Format("{0}.key", int_0));
			if (File.Exists(text) && File.Exists(text2))
			{
				return new X509Certificate2(text)
				{
					PrivateKey = Class68.smethod_1(text2)
				};
			}
		}
		catch
		{
		}
		return x509Certificate2_0;
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x00035694 File Offset: 0x00033894
	private void method_0()
	{
		if (this.dictionary_0.Count > 0)
		{
			return;
		}
		List<Class74> list = this.list_1;
		if (list != null && list.Count > 0)
		{
			return;
		}
		list = this.list_0;
		if (list != null && list.Count > 0)
		{
			return;
		}
		Class69.smethod_3(this.ipendPoint_0);
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x000356E4 File Offset: 0x000338E4
	private static void smethod_3(IAsyncResult iasyncResult_0)
	{
		Class68 @class = (Class68)iasyncResult_0.AsyncState;
		Socket socket = null;
		try
		{
			socket = @class.socket_0.EndAccept(iasyncResult_0);
		}
		catch (SocketException)
		{
		}
		catch (ObjectDisposedException)
		{
			return;
		}
		try
		{
			@class.socket_0.BeginAccept(new AsyncCallback(Class68.smethod_3), @class);
		}
		catch
		{
			if (socket != null)
			{
				socket.Close();
			}
			return;
		}
		if (socket == null)
		{
			return;
		}
		Class68.smethod_4(socket, @class);
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00035770 File Offset: 0x00033970
	private static void smethod_4(Socket socket_1, Class68 class68_0)
	{
		Class70 @class = null;
		try
		{
			@class = new Class70(socket_1, class68_0);
			object obj = class68_0.object_0;
			lock (obj)
			{
				class68_0.dictionary_1[@class] = @class;
			}
			@class.method_11();
		}
		catch
		{
			if (@class != null)
			{
				@class.method_10(true);
			}
			else
			{
				socket_1.Close();
			}
		}
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x000357EC File Offset: 0x000339EC
	private static bool smethod_5(List<Class74> list_2, Class74 class74_0)
	{
		string string_ = class74_0.String_2;
		int count = list_2.Count;
		for (int i = 0; i < count; i++)
		{
			if (list_2[i].String_2 == string_)
			{
				list_2.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x00035834 File Offset: 0x00033A34
	private static GClass37 smethod_6(string string_1, List<Class74> list_2)
	{
		if (list_2 == null)
		{
			return null;
		}
		GClass37 result = null;
		int num = -1;
		foreach (Class74 @class in list_2)
		{
			string string_2 = @class.String_2;
			int length = string_2.Length;
			if (length >= num && string_1.StartsWith(string_2))
			{
				num = length;
				result = @class.GClass37_0;
			}
		}
		return result;
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x000358B0 File Offset: 0x00033AB0
	internal static bool smethod_7(int int_0, string string_1)
	{
		if (string_1 == null || string_1.Length == 0)
		{
			string_1 = Class68.string_0;
		}
		string path = Path.Combine(string_1, string.Format("{0}.cer", int_0));
		string path2 = Path.Combine(string_1, string.Format("{0}.key", int_0));
		return File.Exists(path) && File.Exists(path2);
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x0003590C File Offset: 0x00033B0C
	internal void method_1(Class70 class70_0)
	{
		object obj = this.object_0;
		lock (obj)
		{
			this.dictionary_1.Remove(class70_0);
		}
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00035954 File Offset: 0x00033B54
	internal bool method_2(Uri uri_0, out GClass37 gclass37_0)
	{
		gclass37_0 = null;
		if (uri_0 == null)
		{
			return false;
		}
		string host = uri_0.Host;
		bool flag = Uri.CheckHostName(host) == UriHostNameType.Dns;
		string b = uri_0.Port.ToString();
		string text = Class78.smethod_25(uri_0.AbsolutePath);
		string text2 = (text[text.Length - 1] != '/') ? (text + "/") : text;
		if (host != null && host.Length > 0)
		{
			int num = -1;
			foreach (Class74 @class in this.dictionary_0.Keys)
			{
				if (flag)
				{
					string text3 = @class.String_0;
					if (Uri.CheckHostName(text3) == UriHostNameType.Dns && text3 != host)
					{
						continue;
					}
				}
				if (!(@class.String_3 != b))
				{
					string string_ = @class.String_2;
					int length = string_.Length;
					if (length >= num && (text.StartsWith(string_) || text2.StartsWith(string_)))
					{
						num = length;
						gclass37_0 = this.dictionary_0[@class];
					}
				}
			}
			if (num != -1)
			{
				return true;
			}
		}
		List<Class74> list_ = this.list_1;
		gclass37_0 = Class68.smethod_6(text, list_);
		if (gclass37_0 == null && text2 != text)
		{
			gclass37_0 = Class68.smethod_6(text2, list_);
		}
		if (gclass37_0 != null)
		{
			return true;
		}
		list_ = this.list_0;
		gclass37_0 = Class68.smethod_6(text, list_);
		if (gclass37_0 == null && text2 != text)
		{
			gclass37_0 = Class68.smethod_6(text2, list_);
		}
		return gclass37_0 != null;
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00035AF4 File Offset: 0x00033CF4
	public void method_3(Class74 class74_0)
	{
		if (class74_0.String_0 == "*")
		{
			List<Class74> list;
			List<Class74> list2;
			do
			{
				list = this.list_1;
				list2 = ((list != null) ? new List<Class74>(list) : new List<Class74>());
				Class68.smethod_0(list2, class74_0);
			}
			while (Interlocked.CompareExchange<List<Class74>>(ref this.list_1, list2, list) != list);
			return;
		}
		if (class74_0.String_0 == "+")
		{
			List<Class74> list;
			List<Class74> list2;
			do
			{
				list = this.list_0;
				list2 = ((list != null) ? new List<Class74>(list) : new List<Class74>());
				Class68.smethod_0(list2, class74_0);
			}
			while (Interlocked.CompareExchange<List<Class74>>(ref this.list_0, list2, list) != list);
			return;
		}
		Dictionary<Class74, GClass37> dictionary;
		Dictionary<Class74, GClass37> dictionary2;
		do
		{
			dictionary = this.dictionary_0;
			if (dictionary.ContainsKey(class74_0))
			{
				goto Block_8;
			}
			dictionary2 = new Dictionary<Class74, GClass37>(dictionary);
			dictionary2[class74_0] = class74_0.GClass37_0;
		}
		while (Interlocked.CompareExchange<Dictionary<Class74, GClass37>>(ref this.dictionary_0, dictionary2, dictionary) != dictionary);
		return;
		Block_8:
		if (dictionary[class74_0] != class74_0.GClass37_0)
		{
			string text = string.Format("There is another listener for {0}.", class74_0);
			throw new GException5(87, text);
		}
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00035BF0 File Offset: 0x00033DF0
	public void method_4()
	{
		this.socket_0.Close();
		Class70[] array = null;
		object obj = this.object_0;
		lock (obj)
		{
			if (this.dictionary_1.Count == 0)
			{
				return;
			}
			Dictionary<Class70, Class70>.KeyCollection keys = this.dictionary_1.Keys;
			array = new Class70[keys.Count];
			keys.CopyTo(array, 0);
			this.dictionary_1.Clear();
		}
		for (int i = array.Length - 1; i >= 0; i--)
		{
			array[i].method_10(true);
		}
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x00035C88 File Offset: 0x00033E88
	public void method_5(Class74 class74_0)
	{
		if (class74_0.String_0 == "*")
		{
			List<Class74> list;
			List<Class74> list2;
			do
			{
				list = this.list_1;
				if (list == null)
				{
					break;
				}
				list2 = new List<Class74>(list);
				if (!Class68.smethod_5(list2, class74_0))
				{
					break;
				}
			}
			while (Interlocked.CompareExchange<List<Class74>>(ref this.list_1, list2, list) != list);
			this.method_0();
			return;
		}
		if (class74_0.String_0 == "+")
		{
			List<Class74> list;
			List<Class74> list2;
			do
			{
				list = this.list_0;
				if (list == null)
				{
					break;
				}
				list2 = new List<Class74>(list);
				if (!Class68.smethod_5(list2, class74_0))
				{
					break;
				}
			}
			while (Interlocked.CompareExchange<List<Class74>>(ref this.list_0, list2, list) != list);
			this.method_0();
			return;
		}
		Dictionary<Class74, GClass37> dictionary;
		Dictionary<Class74, GClass37> dictionary2;
		do
		{
			dictionary = this.dictionary_0;
			if (!dictionary.ContainsKey(class74_0))
			{
				break;
			}
			dictionary2 = new Dictionary<Class74, GClass37>(dictionary);
			dictionary2.Remove(class74_0);
		}
		while (Interlocked.CompareExchange<Dictionary<Class74, GClass37>>(ref this.dictionary_0, dictionary2, dictionary) != dictionary);
		this.method_0();
	}

	// Token: 0x04000307 RID: 775
	private List<Class74> list_0;

	// Token: 0x04000308 RID: 776
	private static readonly string string_0 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

	// Token: 0x04000309 RID: 777
	private IPEndPoint ipendPoint_0;

	// Token: 0x0400030A RID: 778
	private Dictionary<Class74, GClass37> dictionary_0;

	// Token: 0x0400030B RID: 779
	private bool bool_0;

	// Token: 0x0400030C RID: 780
	private Socket socket_0;

	// Token: 0x0400030D RID: 781
	private GClass44 gclass44_0;

	// Token: 0x0400030E RID: 782
	private List<Class74> list_1;

	// Token: 0x0400030F RID: 783
	private Dictionary<Class70, Class70> dictionary_1;

	// Token: 0x04000310 RID: 784
	private object object_0;
}
