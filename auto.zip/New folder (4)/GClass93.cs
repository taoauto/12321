﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;

// Token: 0x02000127 RID: 295
public class GClass93 : GClass87
{
	// Token: 0x170003DB RID: 987
	// (get) Token: 0x06000ED6 RID: 3798 RVA: 0x0000C88D File Offset: 0x0000AA8D
	// (set) Token: 0x06000ED7 RID: 3799 RVA: 0x0000C895 File Offset: 0x0000AA95
	private Pen Pen_0 { get; set; }

	// Token: 0x06000ED8 RID: 3800 RVA: 0x0000C89E File Offset: 0x0000AA9E
	public GClass93(int int_0, Color color_0)
	{
		this.Pen_0 = new Pen(Color.FromArgb(int_0, color_0));
	}

	// Token: 0x06000ED9 RID: 3801 RVA: 0x000563A8 File Offset: 0x000545A8
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		Size size = GClass87.smethod_0(gclass86_0);
		Point point_ = new Point(point_0.X, point_0.Y + size.Height - 1);
		Point point_2 = new Point(point_0.X + size.Width, point_0.Y + size.Height - 1);
		this.method_0(graphics_0, point_, point_2);
	}

	// Token: 0x06000EDA RID: 3802 RVA: 0x0005640C File Offset: 0x0005460C
	private void method_0(Graphics graphics_0, Point point_0, Point point_1)
	{
		if (point_1.X - point_0.X < 2)
		{
			graphics_0.DrawLine(this.Pen_0, point_0, point_1);
			return;
		}
		int num = -1;
		List<Point> list = new List<Point>();
		for (int i = point_0.X; i <= point_1.X; i += 2)
		{
			list.Add(new Point(i, point_0.Y + num));
			num = -num;
		}
		graphics_0.DrawLines(this.Pen_0, list.ToArray());
	}

	// Token: 0x06000EDB RID: 3803 RVA: 0x0000C8B8 File Offset: 0x0000AAB8
	public virtual void Dispose()
	{
		base.Dispose();
		if (this.Pen_0 != null)
		{
			this.Pen_0.Dispose();
		}
	}

	// Token: 0x04000766 RID: 1894
	[CompilerGenerated]
	private Pen pen_0;
}
