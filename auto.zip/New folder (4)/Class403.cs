﻿using System;
using System.Management;
using System.Security.Cryptography;
using System.Text;

// Token: 0x020002D4 RID: 724
internal class Class403
{
	// Token: 0x060029A7 RID: 10663 RVA: 0x0011D544 File Offset: 0x0011B744
	public static string smethod_0()
	{
		if (string.IsNullOrEmpty(Class403.string_0))
		{
			Class403.string_0 = Class403.smethod_9(string.Concat(new string[]
			{
				"CPU >> ",
				Class403.String_2,
				"\nBIOS >> ",
				Class403.smethod_5(),
				"\nBASE >> ",
				Class403.smethod_7()
			}));
		}
		return Class403.string_0;
	}

	// Token: 0x1700098B RID: 2443
	// (get) Token: 0x060029A8 RID: 10664 RVA: 0x0011D5A8 File Offset: 0x0011B7A8
	public static string String_0
	{
		get
		{
			Class403.string_1 = Class415.smethod_2("User", "HWID");
			if (Class403.string_1.Length == 32)
			{
				return Class403.string_1;
			}
			if (Class403.string_1 == "")
			{
				Class403.string_1 = Class403.smethod_9(Class403.smethod_0());
				Class415.smethod_1("User", "HWID", Class403.string_1);
			}
			return Class403.string_1;
		}
	}

	// Token: 0x1700098C RID: 2444
	// (get) Token: 0x060029A9 RID: 10665 RVA: 0x0011D618 File Offset: 0x0011B818
	public static string String_1
	{
		get
		{
			string text = Class403.smethod_9(Class403.smethod_0());
			Class415.smethod_1("User", "HWID", text);
			return text;
		}
	}

	// Token: 0x060029AA RID: 10666 RVA: 0x0011D644 File Offset: 0x0011B844
	private static string smethod_1(string string_2)
	{
		byte[] array = MD5.Create().ComputeHash(Encoding.Default.GetBytes(string_2));
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < array.Length; i++)
		{
			stringBuilder.Append(array[i].ToString("x2"));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060029AB RID: 10667 RVA: 0x0001E91C File Offset: 0x0001CB1C
	public static string smethod_2()
	{
		return Class403.smethod_3("Win32_NetworkAdapterConfiguration", "MACAddress", "IPEnabled");
	}

	// Token: 0x1700098D RID: 2445
	// (get) Token: 0x060029AC RID: 10668 RVA: 0x0011D69C File Offset: 0x0011B89C
	public static string String_2
	{
		get
		{
			string text = Class403.smethod_4("Win32_Processor", "UniqueId");
			if (text == "")
			{
				text = Class403.smethod_4("Win32_Processor", "ProcessorId");
				if (text == "")
				{
					text = Class403.smethod_4("Win32_Processor", "Name");
					if (text == "")
					{
						text = Class403.smethod_4("Win32_Processor", "Manufacturer");
					}
					text += Class403.smethod_4("Win32_Processor", "MaxClockSpeed");
				}
			}
			return text;
		}
	}

	// Token: 0x060029AD RID: 10669 RVA: 0x0011D728 File Offset: 0x0011B928
	private static string smethod_3(string string_2, string string_3, string string_4)
	{
		string text = "";
		foreach (ManagementBaseObject managementBaseObject in new ManagementClass(string_2).GetInstances())
		{
			ManagementObject managementObject = (ManagementObject)managementBaseObject;
			if (managementObject[string_4].ToString() == "True" && text == "")
			{
				try
				{
					text = managementObject[string_3].ToString();
					break;
				}
				catch
				{
				}
			}
		}
		return text;
	}

	// Token: 0x060029AE RID: 10670 RVA: 0x0011D7C4 File Offset: 0x0011B9C4
	private static string smethod_4(string string_2, string string_3)
	{
		string text = "";
		foreach (ManagementBaseObject managementBaseObject in new ManagementClass(string_2).GetInstances())
		{
			ManagementObject managementObject = (ManagementObject)managementBaseObject;
			if (text == "")
			{
				try
				{
					text = managementObject[string_3].ToString();
					break;
				}
				catch
				{
				}
			}
		}
		return text;
	}

	// Token: 0x060029AF RID: 10671 RVA: 0x0011D848 File Offset: 0x0011BA48
	private static string smethod_5()
	{
		return string.Concat(new string[]
		{
			Class403.smethod_4("Win32_BIOS", "Manufacturer"),
			Class403.smethod_4("Win32_BIOS", "SMBIOSBIOSVersion"),
			Class403.smethod_4("Win32_BIOS", "IdentificationCode"),
			Class403.smethod_4("Win32_BIOS", "SerialNumber"),
			Class403.smethod_4("Win32_BIOS", "ReleaseDate"),
			Class403.smethod_4("Win32_BIOS", "Version")
		});
	}

	// Token: 0x060029B0 RID: 10672 RVA: 0x0011D8CC File Offset: 0x0011BACC
	public static string smethod_6()
	{
		return Class403.smethod_4("Win32_DiskDrive", "Model") + Class403.smethod_4("Win32_DiskDrive", "Manufacturer") + Class403.smethod_4("Win32_DiskDrive", "Signature") + Class403.smethod_4("Win32_DiskDrive", "TotalHeads");
	}

	// Token: 0x060029B1 RID: 10673 RVA: 0x0011D91C File Offset: 0x0011BB1C
	private static string smethod_7()
	{
		return Class403.smethod_4("Win32_BaseBoard", "Model") + Class403.smethod_4("Win32_BaseBoard", "Manufacturer") + Class403.smethod_4("Win32_BaseBoard", "Name") + Class403.smethod_4("Win32_BaseBoard", "SerialNumber");
	}

	// Token: 0x060029B2 RID: 10674 RVA: 0x0001E932 File Offset: 0x0001CB32
	private static string smethod_8()
	{
		return Class403.smethod_4("Win32_VideoController", "DriverVersion") + Class403.smethod_4("Win32_VideoController", "Name");
	}

	// Token: 0x060029B3 RID: 10675 RVA: 0x0011D96C File Offset: 0x0011BB6C
	private static string smethod_9(string string_2)
	{
		HashAlgorithm hashAlgorithm = new MD5CryptoServiceProvider();
		byte[] bytes = new ASCIIEncoding().GetBytes(string_2);
		return Class403.smethod_10(hashAlgorithm.ComputeHash(bytes));
	}

	// Token: 0x060029B4 RID: 10676 RVA: 0x0011D998 File Offset: 0x0011BB98
	public static string smethod_10(byte[] byte_0)
	{
		string text = string.Empty;
		foreach (byte b in byte_0)
		{
			int num = (int)(b & 15);
			int num2 = b >> 4 & 15;
			if (num2 > 9)
			{
				text += ((char)(num2 - 10 + 65)).ToString();
			}
			else
			{
				text += num2.ToString();
			}
			if (num > 9)
			{
				text += ((char)(num - 10 + 65)).ToString();
			}
			else
			{
				text += num.ToString();
			}
		}
		return text;
	}

	// Token: 0x04001BE4 RID: 7140
	private static string string_0 = string.Empty;

	// Token: 0x04001BE5 RID: 7141
	private static string string_1 = "";
}
