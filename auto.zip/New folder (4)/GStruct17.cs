﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200018F RID: 399
[Serializable]
[StructLayout(LayoutKind.Explicit)]
public struct GStruct17
{
	// Token: 0x04000A27 RID: 2599
	[FieldOffset(0)]
	public uint AddressOfData;

	// Token: 0x04000A28 RID: 2600
	[FieldOffset(0)]
	public uint ForwarderString;

	// Token: 0x04000A29 RID: 2601
	[FieldOffset(0)]
	public uint Function;

	// Token: 0x04000A2A RID: 2602
	[FieldOffset(0)]
	public uint Ordinal;
}
