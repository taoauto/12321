﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Configuration;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

// Token: 0x02000147 RID: 327
internal class Class131
{
	// Token: 0x06000FF9 RID: 4089 RVA: 0x0000D2BE File Offset: 0x0000B4BE
	public static void smethod_0()
	{
		Class131.smethod_2();
		ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback(Class131.smethod_1));
	}

	// Token: 0x06000FFA RID: 4090 RVA: 0x0000354C File Offset: 0x0000174C
	private static bool smethod_1(object object_0, X509Certificate x509Certificate_0, X509Chain x509Chain_0, SslPolicyErrors sslPolicyErrors_0)
	{
		return true;
	}

	// Token: 0x06000FFB RID: 4091 RVA: 0x0005A790 File Offset: 0x00058990
	public static bool smethod_2()
	{
		Assembly assembly = Assembly.GetAssembly(typeof(SettingsSection));
		if (assembly != null)
		{
			Type type = assembly.GetType("System.Net.Configuration.SettingsSectionInternal");
			if (type != null)
			{
				object obj = type.InvokeMember("Section", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetProperty, null, null, new object[0]);
				if (obj != null)
				{
					FieldInfo field = type.GetField("useUnsafeHeaderParsing", BindingFlags.Instance | BindingFlags.NonPublic);
					if (field != null)
					{
						field.SetValue(obj, true);
						return true;
					}
				}
			}
		}
		return false;
	}

	// Token: 0x1700041D RID: 1053
	// (get) Token: 0x06000FFC RID: 4092 RVA: 0x0005A810 File Offset: 0x00058A10
	public static Class131 Class131_0
	{
		get
		{
			if (!Class131.bool_0)
			{
				Class131.bool_0 = true;
				Class131.smethod_0();
				Class133.smethod_0("http", typeof(Class136));
				Class133.smethod_0("https", typeof(Class136));
				Class133.smethod_0("ftp", typeof(Class135));
				Class131.list_0 = new List<Interface0>();
				Class131.list_0.Add(new Class137());
			}
			if (Class131.class131_0 == null)
			{
				Class131.class131_0 = new Class131();
			}
			return Class131.class131_0;
		}
	}

	// Token: 0x14000040 RID: 64
	// (add) Token: 0x06000FFD RID: 4093 RVA: 0x0005A89C File Offset: 0x00058A9C
	// (remove) Token: 0x06000FFE RID: 4094 RVA: 0x0005A8D4 File Offset: 0x00058AD4
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000041 RID: 65
	// (add) Token: 0x06000FFF RID: 4095 RVA: 0x0005A90C File Offset: 0x00058B0C
	// (remove) Token: 0x06001000 RID: 4096 RVA: 0x0005A944 File Offset: 0x00058B44
	public event EventHandler Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000042 RID: 66
	// (add) Token: 0x06001001 RID: 4097 RVA: 0x0005A97C File Offset: 0x00058B7C
	// (remove) Token: 0x06001002 RID: 4098 RVA: 0x0005A9B4 File Offset: 0x00058BB4
	public event EventHandler<EventArgs1> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_2;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_2;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000043 RID: 67
	// (add) Token: 0x06001003 RID: 4099 RVA: 0x0005A9EC File Offset: 0x00058BEC
	// (remove) Token: 0x06001004 RID: 4100 RVA: 0x0005AA24 File Offset: 0x00058C24
	public event EventHandler<EventArgs1> Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_3;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_3;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000044 RID: 68
	// (add) Token: 0x06001005 RID: 4101 RVA: 0x0005AA5C File Offset: 0x00058C5C
	// (remove) Token: 0x06001006 RID: 4102 RVA: 0x0005AA94 File Offset: 0x00058C94
	public event EventHandler<EventArgs1> Event_4
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_4;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs1> eventHandler = this.eventHandler_4;
			EventHandler<EventArgs1> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs1> value2 = (EventHandler<EventArgs1>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs1>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1700041E RID: 1054
	// (get) Token: 0x06001007 RID: 4103 RVA: 0x0000D2E6 File Offset: 0x0000B4E6
	public ReadOnlyCollection<Class130> ReadOnlyCollection_0
	{
		get
		{
			return this.list_1.AsReadOnly();
		}
	}

	// Token: 0x1700041F RID: 1055
	// (get) Token: 0x06001008 RID: 4104 RVA: 0x0005AACC File Offset: 0x00058CCC
	public double Double_0
	{
		get
		{
			double num = 0.0;
			using (this.method_1(false))
			{
				for (int i = 0; i < this.ReadOnlyCollection_0.Count; i++)
				{
					if (this.ReadOnlyCollection_0[i].GEnum21_0 == GEnum21.Working)
					{
						num += this.ReadOnlyCollection_0[i].Double_1;
					}
				}
			}
			return num;
		}
	}

	// Token: 0x17000420 RID: 1056
	// (get) Token: 0x06001009 RID: 4105 RVA: 0x0000D2F3 File Offset: 0x0000B4F3
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x0600100A RID: 4106 RVA: 0x0005AB48 File Offset: 0x00058D48
	private void method_0(object sender, EventArgs e)
	{
		Class130 @class = (Class130)sender;
		if (@class.GEnum21_0 == GEnum21.Ended || @class.GEnum21_0 == GEnum21.EndedWithError)
		{
			this.vmethod_2((Class130)sender);
		}
	}

	// Token: 0x0600100B RID: 4107 RVA: 0x0000D2FB File Offset: 0x0000B4FB
	public IDisposable method_1(bool bool_1)
	{
		if (bool_1)
		{
			return this.class126_0.method_1();
		}
		return this.class126_0.method_0();
	}

	// Token: 0x0600100C RID: 4108 RVA: 0x0000D317 File Offset: 0x0000B517
	public void method_2(int int_1)
	{
		this.method_3(this.list_1[int_1]);
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x0005AB7C File Offset: 0x00058D7C
	public void method_3(Class130 class130_0)
	{
		if (class130_0.GEnum21_0 != GEnum21.NeedToPrepare || class130_0.GEnum21_0 != GEnum21.Ended || class130_0.GEnum21_0 != GEnum21.Paused)
		{
			class130_0.method_6();
		}
		using (this.method_1(true))
		{
			this.list_1.Remove(class130_0);
		}
		this.vmethod_4(class130_0);
	}

	// Token: 0x0600100E RID: 4110 RVA: 0x0005ABE4 File Offset: 0x00058DE4
	public void method_4()
	{
		using (this.method_1(true))
		{
			for (int i = this.list_1.Count - 1; i >= 0; i--)
			{
				if (this.list_1[i].GEnum21_0 == GEnum21.Ended)
				{
					Class130 class130_ = this.list_1[i];
					this.list_1.RemoveAt(i);
					this.vmethod_4(class130_);
				}
			}
		}
	}

	// Token: 0x0600100F RID: 4111 RVA: 0x0005AC64 File Offset: 0x00058E64
	public void method_5()
	{
		using (this.method_1(false))
		{
			for (int i = 0; i < this.ReadOnlyCollection_0.Count; i++)
			{
				this.ReadOnlyCollection_0[i].method_6();
			}
		}
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x0005ACBC File Offset: 0x00058EBC
	public Class130 method_6(Class141 class141_0, Class141[] class141_1, string string_0, int int_1, bool bool_1)
	{
		Class130 @class = new Class130(class141_0, class141_1, string_0, int_1);
		this.method_8(@class, bool_1);
		return @class;
	}

	// Token: 0x06001011 RID: 4113 RVA: 0x0005ACE0 File Offset: 0x00058EE0
	public Class130 method_7(Class141 class141_0, Class141[] class141_1, string string_0, List<Class142> list_2, Class140 class140_0, int int_1, bool bool_1, DateTime dateTime_0)
	{
		Class130 @class = new Class130(class141_0, class141_1, string_0, list_2, class140_0, int_1, dateTime_0);
		this.method_8(@class, bool_1);
		return @class;
	}

	// Token: 0x06001012 RID: 4114 RVA: 0x0005AD08 File Offset: 0x00058F08
	public void method_8(Class130 class130_0, bool bool_1)
	{
		class130_0.Event_2 += this.method_0;
		using (this.method_1(true))
		{
			this.list_1.Add(class130_0);
		}
		this.vmethod_3(class130_0, bool_1);
		if (bool_1)
		{
			class130_0.method_7();
		}
	}

	// Token: 0x06001013 RID: 4115 RVA: 0x0000D32B File Offset: 0x0000B52B
	public virtual void vmethod_0()
	{
		this.int_0++;
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, EventArgs.Empty);
		}
	}

	// Token: 0x06001014 RID: 4116 RVA: 0x0000D354 File Offset: 0x0000B554
	public virtual void vmethod_1()
	{
		this.int_0--;
		if (this.eventHandler_1 != null)
		{
			this.eventHandler_1(this, EventArgs.Empty);
		}
	}

	// Token: 0x06001015 RID: 4117 RVA: 0x0000D37D File Offset: 0x0000B57D
	protected virtual void vmethod_2(Class130 class130_0)
	{
		if (this.eventHandler_2 != null)
		{
			this.eventHandler_2(this, new EventArgs1(class130_0));
		}
	}

	// Token: 0x06001016 RID: 4118 RVA: 0x0000D399 File Offset: 0x0000B599
	protected virtual void vmethod_3(Class130 class130_0, bool bool_1)
	{
		if (this.eventHandler_3 != null)
		{
			this.eventHandler_3(this, new EventArgs1(class130_0, bool_1));
		}
	}

	// Token: 0x06001017 RID: 4119 RVA: 0x0000D3B6 File Offset: 0x0000B5B6
	protected virtual void vmethod_4(Class130 class130_0)
	{
		if (this.eventHandler_4 != null)
		{
			this.eventHandler_4(this, new EventArgs1(class130_0));
		}
	}

	// Token: 0x06001018 RID: 4120 RVA: 0x0005AD68 File Offset: 0x00058F68
	public void method_9(int int_1, bool bool_1)
	{
		if (bool_1)
		{
			this.method_10(int_1);
			return;
		}
		using (this.method_1(true))
		{
			this.method_10(int_1);
		}
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x0005ADAC File Offset: 0x00058FAC
	private void method_10(int int_1)
	{
		int count = this.list_1.Count;
		Class130 item = this.list_1[int_1];
		Class130 item2 = this.list_1[int_1 - 1];
		this.list_1.RemoveAt(int_1);
		this.list_1.RemoveAt(int_1 - 1);
		this.list_1.Insert(int_1 - 1, item);
		this.list_1.Insert(int_1, item2);
	}

	// Token: 0x0400083D RID: 2109
	private static Class131 class131_0;

	// Token: 0x0400083E RID: 2110
	private static List<Interface0> list_0;

	// Token: 0x0400083F RID: 2111
	private static bool bool_0;

	// Token: 0x04000840 RID: 2112
	private List<Class130> list_1 = new List<Class130>();

	// Token: 0x04000841 RID: 2113
	private int int_0;

	// Token: 0x04000842 RID: 2114
	private Class126 class126_0 = new Class126();

	// Token: 0x04000843 RID: 2115
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04000844 RID: 2116
	[CompilerGenerated]
	private EventHandler eventHandler_1;

	// Token: 0x04000845 RID: 2117
	[CompilerGenerated]
	private EventHandler<EventArgs1> eventHandler_2;

	// Token: 0x04000846 RID: 2118
	[CompilerGenerated]
	private EventHandler<EventArgs1> eventHandler_3;

	// Token: 0x04000847 RID: 2119
	[CompilerGenerated]
	private EventHandler<EventArgs1> eventHandler_4;
}
