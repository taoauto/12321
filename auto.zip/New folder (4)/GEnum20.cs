﻿using System;

// Token: 0x0200012E RID: 302
public enum GEnum20
{
	// Token: 0x040007E4 RID: 2020
	Custom,
	// Token: 0x040007E5 RID: 2021
	CSharp,
	// Token: 0x040007E6 RID: 2022
	VB,
	// Token: 0x040007E7 RID: 2023
	HTML,
	// Token: 0x040007E8 RID: 2024
	XML,
	// Token: 0x040007E9 RID: 2025
	SQL,
	// Token: 0x040007EA RID: 2026
	PHP,
	// Token: 0x040007EB RID: 2027
	JS,
	// Token: 0x040007EC RID: 2028
	Lua,
	// Token: 0x040007ED RID: 2029
	JSON
}
