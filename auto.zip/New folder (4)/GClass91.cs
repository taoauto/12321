﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;

// Token: 0x02000125 RID: 293
public class GClass91 : GClass87
{
	// Token: 0x170003DA RID: 986
	// (get) Token: 0x06000ECF RID: 3791 RVA: 0x0000C857 File Offset: 0x0000AA57
	// (set) Token: 0x06000ED0 RID: 3792 RVA: 0x0000C85F File Offset: 0x0000AA5F
	public Brush Brush_0 { get; set; }

	// Token: 0x06000ED1 RID: 3793 RVA: 0x0000C868 File Offset: 0x0000AA68
	public GClass91(Brush brush_1)
	{
		this.Brush_0 = brush_1;
		this.GClass87.\u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E = true;
	}

	// Token: 0x06000ED2 RID: 3794 RVA: 0x0005622C File Offset: 0x0005442C
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		if (this.Brush_0 != null)
		{
			Rectangle rect = new Rectangle(point_0.X, point_0.Y, (gclass86_0.GStruct2_1.int_0 - gclass86_0.GStruct2_0.int_0) * gclass86_0.fastColoredTextBox_0.Int32_4, gclass86_0.fastColoredTextBox_0.Int32_2);
			if (rect.Width == 0)
			{
				return;
			}
			graphics_0.FillRectangle(this.Brush_0, rect);
		}
	}

	// Token: 0x06000ED3 RID: 3795 RVA: 0x0005629C File Offset: 0x0005449C
	public override string \u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E()
	{
		string text = "";
		if (this.Brush_0 is SolidBrush)
		{
			string text2 = GClass72.smethod_0((this.Brush_0 as SolidBrush).Color);
			if (text2 != "")
			{
				text = text + "background-color:" + text2 + ";";
			}
		}
		return text;
	}

	// Token: 0x04000764 RID: 1892
	[CompilerGenerated]
	private Brush brush_0;
}
