﻿using System;

// Token: 0x0200006D RID: 109
internal enum Enum5
{
	// Token: 0x0400027E RID: 638
	Ready,
	// Token: 0x0400027F RID: 639
	Start,
	// Token: 0x04000280 RID: 640
	ShuttingDown,
	// Token: 0x04000281 RID: 641
	Stop
}
