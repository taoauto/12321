﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000311 RID: 785
internal partial class Trader : Form
{
	// Token: 0x06002D6D RID: 11629 RVA: 0x00130CA0 File Offset: 0x0012EEA0
	public Trader(Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.InitializeComponent();
		base.Icon = GClass130.Icon_1;
		this.Text = class159_1.Class432_0.String_15 + " - " + class159_1.Class432_0.UInt32_33.ToString();
	}

	// Token: 0x06002D6E RID: 11630 RVA: 0x00130CFC File Offset: 0x0012EEFC
	private void nudCityId_ValueChanged(object sender, EventArgs e)
	{
		this.txtCodeTN.Text = string.Concat(new string[]
		{
			"@way,",
			this.cboCity.Text,
			",",
			this.cboRefCity.Text,
			",",
			this.cboIdxCity.Text,
			",",
			this.cboIdxRefCity.Text,
			",",
			this.nudCityId.Value.ToString(),
			",",
			this.nudRefCityId.Value.ToString(),
			",",
			this.nudCityClick1.Value.ToString(),
			",",
			this.nudCityClick2.Value.ToString(),
			",",
			this.nudRefCityClick1.Value.ToString(),
			",",
			this.nudRefCityClick2.Value.ToString()
		});
	}

	// Token: 0x06002D6F RID: 11631 RVA: 0x00130E38 File Offset: 0x0012F038
	private void btnGetThanh_Click(object sender, EventArgs e)
	{
		string s = Class426.smethod_30(this.class159_0.Class432_0.UInt32_29);
		this.cboCity.SelectedIndex = this.cboCity.FindString(s);
	}

	// Token: 0x06002D70 RID: 11632 RVA: 0x00130E74 File Offset: 0x0012F074
	private void btnGetThanhTT_Click(object sender, EventArgs e)
	{
		string s = Class426.smethod_30(this.class159_0.Class432_0.UInt32_29);
		this.cboRefCity.SelectedIndex = this.cboRefCity.FindString(s);
	}

	// Token: 0x06002D71 RID: 11633 RVA: 0x000212D8 File Offset: 0x0001F4D8
	private void btnGetMyCityID_Click(object sender, EventArgs e)
	{
		if (this.class159_0.Class432_0.UInt32_29 >= 500U)
		{
			this.nudCityId.Value = this.class159_0.Class432_0.UInt32_29;
		}
	}

	// Token: 0x06002D72 RID: 11634 RVA: 0x00130EB0 File Offset: 0x0012F0B0
	private void btnSaveWay_Click(object sender, EventArgs e)
	{
		Class415.smethod_8(this.class159_0.Class432_0.UInt32_33.ToString(), this.txtCodeTN.Text);
		this.class159_0.method_384(this.txtCodeTN.Text);
	}

	// Token: 0x06002D73 RID: 11635 RVA: 0x00130EFC File Offset: 0x0012F0FC
	private void Trader_Load(object sender, EventArgs e)
	{
		this.txtCodeTN.Text = Class415.smethod_9(this.class159_0.Class432_0.UInt32_33.ToString());
	}

	// Token: 0x06002D74 RID: 11636 RVA: 0x00021311 File Offset: 0x0001F511
	private void btnGo_Click(object sender, EventArgs e)
	{
		this.class159_0.method_282("AutoTN = '@go';", false);
	}

	// Token: 0x06002D75 RID: 11637 RVA: 0x00021324 File Offset: 0x0001F524
	private void btnGetTTCityID_Click(object sender, EventArgs e)
	{
		if (this.class159_0.Class432_0.UInt32_29 >= 500U)
		{
			this.nudRefCityId.Value = this.class159_0.Class432_0.UInt32_29;
		}
	}

	// Token: 0x06002D76 RID: 11638 RVA: 0x0002135D File Offset: 0x0001F55D
	private void btnBack_Click(object sender, EventArgs e)
	{
		this.class159_0.method_282("AutoTN = '@bk';", false);
	}

	// Token: 0x06002D77 RID: 11639 RVA: 0x00021370 File Offset: 0x0001F570
	private void btnStop_Click(object sender, EventArgs e)
	{
		this.class159_0.method_282("AutoTN = '@st';", false);
	}

	// Token: 0x06002D78 RID: 11640 RVA: 0x00021383 File Offset: 0x0001F583
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001EBE RID: 7870
	private Class159 class159_0;

	// Token: 0x04001EBF RID: 7871
	private IContainer icontainer_0;
}
