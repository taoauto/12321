﻿using System;

// Token: 0x020002AF RID: 687
internal class Class373
{
	// Token: 0x17000847 RID: 2119
	// (get) Token: 0x0600266E RID: 9838 RVA: 0x0001CB4A File Offset: 0x0001AD4A
	public static string String_0
	{
		get
		{
			return "Thiên Sơn";
		}
	}

	// Token: 0x040019CE RID: 6606
	public static int int_0 = 17;

	// Token: 0x040019CF RID: 6607
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 39,
		Int32_1 = 71,
		Int32_2 = Class373.int_0,
		String_2 = "Nhậm Phi Hồng"
	};

	// Token: 0x040019D0 RID: 6608
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 92,
		Int32_1 = 45,
		Int32_2 = Class373.int_0,
		String_2 = "Mai Kiếm"
	};

	// Token: 0x040019D1 RID: 6609
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 95,
		Int32_1 = 61,
		Int32_2 = Class373.int_0,
		String_2 = "Phù Mẫn Nghi"
	};

	// Token: 0x040019D2 RID: 6610
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 13U,
		Int32_0 = 89,
		Int32_1 = 45,
		Int32_2 = Class373.int_0,
		String_2 = "Lan Kiếm"
	};
}
