﻿using System;
using System.Collections.Generic;
using System.Text;

// Token: 0x02000020 RID: 32
public class GClass11 : GClass10
{
	// Token: 0x060001C5 RID: 453 RVA: 0x0002639C File Offset: 0x0002459C
	public GClass11(IEnumerable<KeyValuePair<string, string>> ienumerable_0, bool bool_0 = false, Encoding encoding_0 = null)
	{
		if (ienumerable_0 == null)
		{
			throw new ArgumentNullException("content");
		}
		string s = GClass6.smethod_2(ienumerable_0, bool_0, encoding_0);
		this.byte_0 = Encoding.ASCII.GetBytes(s);
		this.int_0 = 0;
		this.int_1 = this.byte_0.Length;
		this.string_0 = "application/x-www-form-urlencoded";
	}
}
