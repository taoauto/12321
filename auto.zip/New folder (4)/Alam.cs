﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020001FE RID: 510
internal class Alam : UserControl
{
	// Token: 0x06001A8C RID: 6796 RVA: 0x000133E7 File Offset: 0x000115E7
	public Alam()
	{
		this.InitializeComponent();
		base.Disposed += this.Alam_Disposed;
	}

	// Token: 0x06001A8D RID: 6797 RVA: 0x000C80A4 File Offset: 0x000C62A4
	public Alam(Class159 class159_1, string string_0, int int_1)
	{
		if (int_1 > 0 && MicroLogin.Boolean_11 && !string_0.Contains("kết nối"))
		{
			int_1 = 0;
		}
		this.InitializeComponent();
		base.Disposed += this.Alam_Disposed;
		this.class159_0 = class159_1;
		if (class159_1.Class432_0.String_2 != "ĐăngNhập")
		{
			this.lblCharName.Text = class159_1.Class432_0.String_2;
		}
		else
		{
			this.lblCharName.Text = class159_1.String_5;
		}
		this.lblAlarm.Text = string_0;
		if (int_1 > 0)
		{
			this.int_0 = int_1;
			this.lblExit.Text = string.Format("{0:0}:{1:00}", int_1 / 60, int_1 % 60);
			this.timer_0.Start();
		}
		else
		{
			this.lblExit.Text = "";
		}
		this.lblMute.Visible = Class268.bool_79;
	}

	// Token: 0x06001A8E RID: 6798 RVA: 0x00002E18 File Offset: 0x00001018
	private void Alam_Disposed(object sender, EventArgs e)
	{
	}

	// Token: 0x06001A8F RID: 6799 RVA: 0x000C819C File Offset: 0x000C639C
	private void timer_1_Tick(object sender, EventArgs e)
	{
		this.lblMute.Visible = Class268.bool_79;
		if (this.lblAlarm.Text.Contains("huyệt mộ") && (ulong)this.class159_0.Class432_0.UInt32_29 != (ulong)((long)Class365.Int32_102))
		{
			base.Dispose();
		}
	}

	// Token: 0x06001A90 RID: 6800 RVA: 0x000C81F0 File Offset: 0x000C63F0
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (this.class159_0.Class432_0.Boolean_18)
		{
			base.Dispose();
			return;
		}
		if (this.lblAlarm.Text.Contains("đầy tay nải") && (!this.class159_0.Class432_0.Boolean_5 || !this.class159_0.Class432_0.Boolean_6))
		{
			base.Dispose();
		}
		int num = this.int_0;
		this.int_0 = num - 1;
		if (num < 3)
		{
			if (this.int_0 <= 0)
			{
				base.Dispose();
			}
			if (Class268.Boolean_66 && !this.lblAlarm.Text.Contains("đơ BHD") && !this.lblAlarm.Text.Contains("mất kết nối"))
			{
				if (!this.class159_0.Class432_0.Boolean_34)
				{
					goto IL_103;
				}
				try
				{
					this.class159_0.method_282("COUNT = nil;", false);
					this.class159_0.method_226();
					goto IL_103;
				}
				catch
				{
					goto IL_103;
				}
			}
			try
			{
				Process.GetProcessById(this.class159_0.Int32_7).Kill();
			}
			catch
			{
			}
		}
		IL_103:
		this.lblExit.Text = string.Format("{0:0}:{1:00}", this.int_0 / 60, this.int_0 % 60);
	}

	// Token: 0x06001A91 RID: 6801 RVA: 0x00013407 File Offset: 0x00011607
	private void lblAlarm_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.class159_0.method_223();
		}
	}

	// Token: 0x06001A92 RID: 6802 RVA: 0x00013407 File Offset: 0x00011607
	private void lblCharName_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.class159_0.method_223();
		}
	}

	// Token: 0x06001A93 RID: 6803 RVA: 0x000C8350 File Offset: 0x000C6550
	private void lblExit_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left && MessageBox.Show(this, "Bạn có muốn thoát " + this.class159_0.Class432_0.String_2, "MicroAuto", MessageBoxButtons.YesNo) == DialogResult.Yes)
		{
			this.class159_0.method_224(true);
		}
	}

	// Token: 0x06001A94 RID: 6804 RVA: 0x00013421 File Offset: 0x00011621
	private void lblClose_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			base.Dispose();
		}
	}

	// Token: 0x06001A95 RID: 6805 RVA: 0x00013436 File Offset: 0x00011636
	private void lblMute_MouseClick(object sender, MouseEventArgs e)
	{
		Class268.bool_79 = !Class268.bool_79;
		this.lblMute.Visible = Class268.bool_79;
		if (Class268.bool_79)
		{
			Class407.smethod_7();
			return;
		}
		Class407.smethod_4();
	}

	// Token: 0x06001A96 RID: 6806 RVA: 0x00013436 File Offset: 0x00011636
	private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
	{
		Class268.bool_79 = !Class268.bool_79;
		this.lblMute.Visible = Class268.bool_79;
		if (Class268.bool_79)
		{
			Class407.smethod_7();
			return;
		}
		Class407.smethod_4();
	}

	// Token: 0x06001A97 RID: 6807 RVA: 0x00013467 File Offset: 0x00011667
	private void Alam_Load(object sender, EventArgs e)
	{
		if (!Class268.bool_79)
		{
			Class407.smethod_4();
		}
		this.lblMute.Visible = Class268.bool_79;
		base.Height = 25;
	}

	// Token: 0x06001A98 RID: 6808 RVA: 0x0001348D File Offset: 0x0001168D
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A99 RID: 6809 RVA: 0x000C83A0 File Offset: 0x000C65A0
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Alam));
		this.lblClose = new Label();
		this.lblExit = new Label();
		this.lblAlarm = new Label();
		this.lblCharName = new Label();
		this.timer_0 = new Timer(this.icontainer_0);
		this.lblMute = new Label();
		this.pictureBox1 = new PictureBox();
		this.timer_1 = new Timer(this.icontainer_0);
		((ISupportInitialize)this.pictureBox1).BeginInit();
		base.SuspendLayout();
		this.lblClose.BackColor = Color.Silver;
		this.lblClose.Cursor = Cursors.Hand;
		this.lblClose.Dock = DockStyle.Left;
		this.lblClose.Location = new Point(310, 0);
		this.lblClose.Name = "lblClose";
		this.lblClose.Size = new Size(20, 30);
		this.lblClose.TabIndex = 10;
		this.lblClose.Text = " ";
		this.lblClose.TextAlign = ContentAlignment.MiddleCenter;
		this.lblClose.MouseClick += this.lblClose_MouseClick;
		this.lblExit.BackColor = Color.FromArgb(224, 224, 224);
		this.lblExit.Cursor = Cursors.Hand;
		this.lblExit.Dock = DockStyle.Left;
		this.lblExit.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.lblExit.ForeColor = Color.Green;
		this.lblExit.Location = new Point(270, 0);
		this.lblExit.Name = "lblExit";
		this.lblExit.Size = new Size(40, 30);
		this.lblExit.TabIndex = 12;
		this.lblExit.Text = "0:00";
		this.lblExit.TextAlign = ContentAlignment.MiddleCenter;
		this.lblExit.MouseClick += this.lblExit_MouseClick;
		this.lblAlarm.Cursor = Cursors.Hand;
		this.lblAlarm.Dock = DockStyle.Left;
		this.lblAlarm.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.lblAlarm.ForeColor = Color.Red;
		this.lblAlarm.Location = new Point(120, 0);
		this.lblAlarm.Name = "lblAlarm";
		this.lblAlarm.Size = new Size(150, 30);
		this.lblAlarm.TabIndex = 11;
		this.lblAlarm.Text = "Đang có câu hỏi";
		this.lblAlarm.TextAlign = ContentAlignment.MiddleLeft;
		this.lblAlarm.MouseClick += this.lblAlarm_MouseClick;
		this.lblCharName.Cursor = Cursors.Hand;
		this.lblCharName.Dock = DockStyle.Left;
		this.lblCharName.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.lblCharName.ForeColor = Color.Green;
		this.lblCharName.Location = new Point(0, 0);
		this.lblCharName.Name = "lblCharName";
		this.lblCharName.Size = new Size(120, 30);
		this.lblCharName.TabIndex = 9;
		this.lblCharName.Text = "LUCDINHPHONG";
		this.lblCharName.TextAlign = ContentAlignment.MiddleCenter;
		this.lblCharName.MouseClick += this.lblCharName_MouseClick;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += this.timer_0_Tick;
		this.lblMute.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
		this.lblMute.BackColor = Color.Red;
		this.lblMute.Cursor = Cursors.Hand;
		this.lblMute.ForeColor = Color.Red;
		this.lblMute.Location = new Point(339, 9);
		this.lblMute.Name = "lblMute";
		this.lblMute.Size = new Size(21, 10);
		this.lblMute.TabIndex = 14;
		this.lblMute.Text = "label1";
		this.lblMute.Visible = false;
		this.lblMute.MouseClick += this.lblMute_MouseClick;
		this.pictureBox1.Cursor = Cursors.Hand;
		this.pictureBox1.Dock = DockStyle.Right;
		this.pictureBox1.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
		this.pictureBox1.Location = new Point(330, 0);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new Size(30, 30);
		this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
		this.pictureBox1.TabIndex = 13;
		this.pictureBox1.TabStop = false;
		this.pictureBox1.MouseClick += this.pictureBox1_MouseClick;
		this.timer_1.Enabled = true;
		this.timer_1.Interval = 1000;
		this.timer_1.Tick += this.timer_1_Tick;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lblClose);
		base.Controls.Add(this.lblExit);
		base.Controls.Add(this.lblAlarm);
		base.Controls.Add(this.lblCharName);
		base.Controls.Add(this.lblMute);
		base.Controls.Add(this.pictureBox1);
		base.Name = "Alam";
		base.Size = new Size(360, 30);
		base.Load += this.Alam_Load;
		((ISupportInitialize)this.pictureBox1).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x0400109B RID: 4251
	private Class159 class159_0;

	// Token: 0x0400109C RID: 4252
	private int int_0;

	// Token: 0x0400109D RID: 4253
	private IContainer icontainer_0;

	// Token: 0x0400109E RID: 4254
	private Label lblClose;

	// Token: 0x0400109F RID: 4255
	private Label lblExit;

	// Token: 0x040010A0 RID: 4256
	private Label lblAlarm;

	// Token: 0x040010A1 RID: 4257
	private Label lblCharName;

	// Token: 0x040010A2 RID: 4258
	private Timer timer_0;

	// Token: 0x040010A3 RID: 4259
	private Label lblMute;

	// Token: 0x040010A4 RID: 4260
	private PictureBox pictureBox1;

	// Token: 0x040010A5 RID: 4261
	private Timer timer_1;
}
