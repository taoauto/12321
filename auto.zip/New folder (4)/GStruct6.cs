﻿using System;

// Token: 0x0200017D RID: 381
[Serializable]
public struct GStruct6
{
	// Token: 0x040009A2 RID: 2466
	public uint VirtualAddress;

	// Token: 0x040009A3 RID: 2467
	public uint Size;
}
