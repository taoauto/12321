﻿using System;
using System.Collections;
using System.Collections.Generic;

// Token: 0x0200010C RID: 268
public class GClass83 : IEnumerable<string>, ICollection<string>, IEnumerable, IList<string>
{
	// Token: 0x06000DA2 RID: 3490 RVA: 0x0000BC8A File Offset: 0x00009E8A
	public GClass83(IList<GClass81> ilist_1)
	{
		this.ilist_0 = ilist_1;
	}

	// Token: 0x06000DA3 RID: 3491 RVA: 0x00050974 File Offset: 0x0004EB74
	public int IndexOf(string item)
	{
		for (int i = 0; i < this.ilist_0.Count; i++)
		{
			if (this.ilist_0[i].String_2 == item)
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x000096BD File Offset: 0x000078BD
	public void Insert(int index, string item)
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000DA5 RID: 3493 RVA: 0x000096BD File Offset: 0x000078BD
	public void RemoveAt(int index)
	{
		throw new NotImplementedException();
	}

	// Token: 0x1700039F RID: 927
	public string this[int index]
	{
		get
		{
			return this.ilist_0[index].String_2;
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x06000DA8 RID: 3496 RVA: 0x000096BD File Offset: 0x000078BD
	public void Add(string item)
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000DA9 RID: 3497 RVA: 0x000096BD File Offset: 0x000078BD
	public void Clear()
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000DAA RID: 3498 RVA: 0x000509B4 File Offset: 0x0004EBB4
	public bool Contains(string item)
	{
		for (int i = 0; i < this.ilist_0.Count; i++)
		{
			if (this.ilist_0[i].String_2 == item)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000DAB RID: 3499 RVA: 0x000509F4 File Offset: 0x0004EBF4
	public void CopyTo(string[] array, int arrayIndex)
	{
		for (int i = 0; i < this.ilist_0.Count; i++)
		{
			array[i + arrayIndex] = this.ilist_0[i].String_2;
		}
	}

	// Token: 0x170003A0 RID: 928
	// (get) Token: 0x06000DAC RID: 3500 RVA: 0x0000BCAC File Offset: 0x00009EAC
	public int Count
	{
		get
		{
			return this.ilist_0.Count;
		}
	}

	// Token: 0x170003A1 RID: 929
	// (get) Token: 0x06000DAD RID: 3501 RVA: 0x0000354C File Offset: 0x0000174C
	public bool IsReadOnly
	{
		get
		{
			return true;
		}
	}

	// Token: 0x06000DAE RID: 3502 RVA: 0x000096BD File Offset: 0x000078BD
	public bool Remove(string item)
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000DAF RID: 3503 RVA: 0x0000BCB9 File Offset: 0x00009EB9
	public IEnumerator<string> GetEnumerator()
	{
		GClass83.Class106 @class = new GClass83.Class106(0);
		@class.gclass83_0 = this;
		return @class;
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x0000BCC8 File Offset: 0x00009EC8
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	// Token: 0x040006B9 RID: 1721
	private IList<GClass81> ilist_0;
}
