﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000135 RID: 309
public class GClass101
{
	// Token: 0x06000F92 RID: 3986 RVA: 0x0000CE9B File Offset: 0x0000B09B
	public GClass101(Rectangle rectangle_1)
	{
		this.rectangle_0 = rectangle_1;
	}

	// Token: 0x06000F93 RID: 3987 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Pen pen_0)
	{
	}

	// Token: 0x17000404 RID: 1028
	// (get) Token: 0x06000F94 RID: 3988 RVA: 0x0000CEAA File Offset: 0x0000B0AA
	public virtual Cursor Cursor_0
	{
		get
		{
			return Cursors.Hand;
		}
	}

	// Token: 0x04000804 RID: 2052
	public readonly Rectangle rectangle_0;
}
