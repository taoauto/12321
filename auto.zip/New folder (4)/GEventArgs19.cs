﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000FA RID: 250
public class GEventArgs19 : EventArgs
{
	// Token: 0x17000370 RID: 880
	// (get) Token: 0x06000CED RID: 3309 RVA: 0x0000B4DE File Offset: 0x000096DE
	// (set) Token: 0x06000CEE RID: 3310 RVA: 0x0000B4E6 File Offset: 0x000096E6
	public string String_0 { get; private set; }

	// Token: 0x17000371 RID: 881
	// (get) Token: 0x06000CEF RID: 3311 RVA: 0x0000B4EF File Offset: 0x000096EF
	// (set) Token: 0x06000CF0 RID: 3312 RVA: 0x0000B4F7 File Offset: 0x000096F7
	public int Int32_0 { get; private set; }

	// Token: 0x17000372 RID: 882
	// (get) Token: 0x06000CF1 RID: 3313 RVA: 0x0000B500 File Offset: 0x00009700
	// (set) Token: 0x06000CF2 RID: 3314 RVA: 0x0000B508 File Offset: 0x00009708
	public string String_1 { get; private set; }

	// Token: 0x17000373 RID: 883
	// (get) Token: 0x06000CF3 RID: 3315 RVA: 0x0000B511 File Offset: 0x00009711
	// (set) Token: 0x06000CF4 RID: 3316 RVA: 0x0000B519 File Offset: 0x00009719
	public string String_2 { get; set; }

	// Token: 0x06000CF5 RID: 3317 RVA: 0x0000B522 File Offset: 0x00009722
	public GEventArgs19(string string_3, int int_1, string string_4)
	{
		this.String_0 = string_3;
		this.Int32_0 = int_1;
		this.String_1 = string_4;
		this.String_2 = string_4;
	}

	// Token: 0x04000615 RID: 1557
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000616 RID: 1558
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000617 RID: 1559
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04000618 RID: 1560
	[CompilerGenerated]
	private string string_2;
}
