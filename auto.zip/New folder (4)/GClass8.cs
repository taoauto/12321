﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

// Token: 0x02000014 RID: 20
public sealed class GClass8
{
	// Token: 0x17000077 RID: 119
	// (get) Token: 0x0600012E RID: 302 RVA: 0x00003D70 File Offset: 0x00001F70
	// (set) Token: 0x0600012F RID: 303 RVA: 0x00003D78 File Offset: 0x00001F78
	public bool Boolean_0 { get; private set; }

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x06000130 RID: 304 RVA: 0x00003D81 File Offset: 0x00001F81
	// (set) Token: 0x06000131 RID: 305 RVA: 0x00003D89 File Offset: 0x00001F89
	public bool Boolean_1 { get; private set; }

	// Token: 0x17000079 RID: 121
	// (get) Token: 0x06000132 RID: 306 RVA: 0x00003D92 File Offset: 0x00001F92
	public bool Boolean_2
	{
		get
		{
			return this.GEnum3_0 == GEnum3.OK;
		}
	}

	// Token: 0x1700007A RID: 122
	// (get) Token: 0x06000133 RID: 307 RVA: 0x00024758 File Offset: 0x00022958
	public bool Boolean_3
	{
		get
		{
			int num = (int)this.GEnum3_0;
			return (num >= 300 && num < 400) || this.dictionary_0.ContainsKey("Location") || this.dictionary_0.ContainsKey("Redirect-Location");
		}
	}

	// Token: 0x1700007B RID: 123
	// (get) Token: 0x06000134 RID: 308 RVA: 0x00003DA1 File Offset: 0x00001FA1
	// (set) Token: 0x06000135 RID: 309 RVA: 0x00003DA9 File Offset: 0x00001FA9
	public int Int32_0 { get; internal set; }

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x06000136 RID: 310 RVA: 0x00003DB2 File Offset: 0x00001FB2
	// (set) Token: 0x06000137 RID: 311 RVA: 0x00003DBA File Offset: 0x00001FBA
	public Uri Uri_0 { get; private set; }

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x06000138 RID: 312 RVA: 0x00003DC3 File Offset: 0x00001FC3
	// (set) Token: 0x06000139 RID: 313 RVA: 0x00003DCB File Offset: 0x00001FCB
	public GEnum2 GEnum2_0 { get; private set; }

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x0600013A RID: 314 RVA: 0x00003DD4 File Offset: 0x00001FD4
	// (set) Token: 0x0600013B RID: 315 RVA: 0x00003DDC File Offset: 0x00001FDC
	public Version Version_0 { get; private set; }

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x0600013C RID: 316 RVA: 0x00003DE5 File Offset: 0x00001FE5
	// (set) Token: 0x0600013D RID: 317 RVA: 0x00003DED File Offset: 0x00001FED
	public GEnum3 GEnum3_0 { get; private set; }

	// Token: 0x17000080 RID: 128
	// (get) Token: 0x0600013E RID: 318 RVA: 0x00003DF6 File Offset: 0x00001FF6
	// (set) Token: 0x0600013F RID: 319 RVA: 0x00003DFE File Offset: 0x00001FFE
	public Uri Uri_1 { get; private set; }

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x06000140 RID: 320 RVA: 0x00003E07 File Offset: 0x00002007
	// (set) Token: 0x06000141 RID: 321 RVA: 0x00003E0F File Offset: 0x0000200F
	public Encoding Encoding_0 { get; private set; }

	// Token: 0x17000082 RID: 130
	// (get) Token: 0x06000142 RID: 322 RVA: 0x00003E18 File Offset: 0x00002018
	// (set) Token: 0x06000143 RID: 323 RVA: 0x00003E20 File Offset: 0x00002020
	public int Int32_1 { get; private set; }

	// Token: 0x17000083 RID: 131
	// (get) Token: 0x06000144 RID: 324 RVA: 0x00003E29 File Offset: 0x00002029
	// (set) Token: 0x06000145 RID: 325 RVA: 0x00003E31 File Offset: 0x00002031
	public string String_0 { get; private set; }

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x06000146 RID: 326 RVA: 0x00003E3A File Offset: 0x0000203A
	public string String_1
	{
		get
		{
			return this["Location"];
		}
	}

	// Token: 0x17000085 RID: 133
	// (get) Token: 0x06000147 RID: 327 RVA: 0x00003E47 File Offset: 0x00002047
	// (set) Token: 0x06000148 RID: 328 RVA: 0x00003E4F File Offset: 0x0000204F
	public GClass5 GClass5_0 { get; private set; }

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x06000149 RID: 329 RVA: 0x00003E58 File Offset: 0x00002058
	// (set) Token: 0x0600014A RID: 330 RVA: 0x00003E60 File Offset: 0x00002060
	public int? Nullable_0 { get; private set; }

	// Token: 0x17000087 RID: 135
	// (get) Token: 0x0600014B RID: 331 RVA: 0x00003E69 File Offset: 0x00002069
	// (set) Token: 0x0600014C RID: 332 RVA: 0x00003E71 File Offset: 0x00002071
	public int? Nullable_1 { get; private set; }

	// Token: 0x17000088 RID: 136
	public string this[string string_1]
	{
		get
		{
			if (string_1 == null)
			{
				throw new ArgumentNullException("headerName");
			}
			if (string_1.Length == 0)
			{
				throw Class13.smethod_0("headerName");
			}
			string empty;
			if (!this.dictionary_0.TryGetValue(string_1, out empty))
			{
				empty = string.Empty;
			}
			return empty;
		}
	}

	// Token: 0x17000089 RID: 137
	public string this[GEnum1 genum1_0]
	{
		get
		{
			return this[GClass6.dictionary_0[genum1_0]];
		}
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00003E8D File Offset: 0x0000208D
	internal GClass8(GClass7 gclass7_1)
	{
		this.gclass7_0 = gclass7_1;
		this.Int32_1 = -1;
		this.String_0 = string.Empty;
	}

	// Token: 0x06000150 RID: 336 RVA: 0x000247F0 File Offset: 0x000229F0
	public byte[] method_0()
	{
		if (this.Boolean_0)
		{
			throw new InvalidOperationException(Class2.String_31);
		}
		if (this.Boolean_1)
		{
			return new byte[0];
		}
		MemoryStream memoryStream = new MemoryStream((this.Int32_1 == -1) ? 0 : this.Int32_1);
		try
		{
			foreach (GClass8.Class4 @class in this.method_15())
			{
				memoryStream.Write(@class.Byte_0, 0, @class.Int32_0);
			}
		}
		catch (Exception ex)
		{
			this.Boolean_0 = true;
			if (!(ex is IOException) && !(ex is InvalidOperationException))
			{
				throw;
			}
			throw this.method_33(Class2.String_18, ex);
		}
		if (this.method_23())
		{
			this.gclass7_0.Dispose();
		}
		this.Boolean_1 = true;
		return memoryStream.ToArray();
	}

	// Token: 0x06000151 RID: 337 RVA: 0x000248DC File Offset: 0x00022ADC
	public string ToString()
	{
		if (this.Boolean_0)
		{
			throw new InvalidOperationException(Class2.String_31);
		}
		if (this.Boolean_1)
		{
			return string.Empty;
		}
		MemoryStream memoryStream = new MemoryStream((this.Int32_1 == -1) ? 0 : this.Int32_1);
		try
		{
			foreach (GClass8.Class4 @class in this.method_15())
			{
				memoryStream.Write(@class.Byte_0, 0, @class.Int32_0);
			}
		}
		catch (Exception ex)
		{
			this.Boolean_0 = true;
			if (!(ex is IOException) && !(ex is InvalidOperationException))
			{
				throw;
			}
			throw this.method_33(Class2.String_18, ex);
		}
		if (this.method_23())
		{
			this.gclass7_0.Dispose();
		}
		this.Boolean_1 = true;
		return this.Encoding_0.GetString(memoryStream.GetBuffer(), 0, (int)memoryStream.Length);
	}

	// Token: 0x06000152 RID: 338 RVA: 0x000249D8 File Offset: 0x00022BD8
	public void method_1(string string_1)
	{
		if (this.Boolean_0)
		{
			throw new InvalidOperationException(Class2.String_31);
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (this.Boolean_1)
		{
			return;
		}
		try
		{
			using (FileStream fileStream = new FileStream(string_1, FileMode.Create))
			{
				foreach (GClass8.Class4 @class in this.method_15())
				{
					fileStream.Write(@class.Byte_0, 0, @class.Int32_0);
				}
			}
		}
		catch (ArgumentException exception_)
		{
			throw Class13.smethod_3("path", exception_);
		}
		catch (NotSupportedException exception_2)
		{
			throw Class13.smethod_3("path", exception_2);
		}
		catch (Exception ex)
		{
			this.Boolean_0 = true;
			if (!(ex is IOException) && !(ex is InvalidOperationException))
			{
				throw;
			}
			throw this.method_33(Class2.String_18, ex);
		}
		if (this.method_23())
		{
			this.gclass7_0.Dispose();
		}
		this.Boolean_1 = true;
	}

	// Token: 0x06000153 RID: 339 RVA: 0x00024B04 File Offset: 0x00022D04
	public MemoryStream method_2()
	{
		if (this.Boolean_0)
		{
			throw new InvalidOperationException(Class2.String_31);
		}
		if (this.Boolean_1)
		{
			return null;
		}
		MemoryStream memoryStream = new MemoryStream((this.Int32_1 == -1) ? 0 : this.Int32_1);
		try
		{
			foreach (GClass8.Class4 @class in this.method_15())
			{
				memoryStream.Write(@class.Byte_0, 0, @class.Int32_0);
			}
		}
		catch (Exception ex)
		{
			this.Boolean_0 = true;
			if (!(ex is IOException) && !(ex is InvalidOperationException))
			{
				throw;
			}
			throw this.method_33(Class2.String_18, ex);
		}
		if (this.method_23())
		{
			this.gclass7_0.Dispose();
		}
		this.Boolean_1 = true;
		memoryStream.Position = 0L;
		return memoryStream;
	}

	// Token: 0x06000154 RID: 340 RVA: 0x00024BEC File Offset: 0x00022DEC
	public void method_3()
	{
		if (this.Boolean_0)
		{
			throw new InvalidOperationException(Class2.String_31);
		}
		if (this.Boolean_1)
		{
			return;
		}
		if (this.method_23())
		{
			this.gclass7_0.Dispose();
		}
		else
		{
			try
			{
				foreach (GClass8.Class4 @class in this.method_15())
				{
				}
			}
			catch (Exception ex)
			{
				this.Boolean_0 = true;
				if (!(ex is IOException) && !(ex is InvalidOperationException))
				{
					throw;
				}
				throw this.method_33(Class2.String_18, ex);
			}
		}
		this.Boolean_1 = true;
	}

	// Token: 0x06000155 RID: 341 RVA: 0x00003ECA File Offset: 0x000020CA
	public bool method_4(string string_1)
	{
		return this.GClass5_0 != null && this.GClass5_0.ContainsKey(string_1);
	}

	// Token: 0x06000156 RID: 342 RVA: 0x00003EE2 File Offset: 0x000020E2
	public bool method_5(string string_1)
	{
		return this.gclass5_0.ContainsKey(string_1);
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00024CA4 File Offset: 0x00022EA4
	public string method_6(string string_1)
	{
		string empty;
		if (!this.gclass5_0.TryGetValue(string_1, out empty))
		{
			empty = string.Empty;
		}
		return empty;
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00003EF0 File Offset: 0x000020F0
	public Dictionary<string, string>.Enumerator method_7()
	{
		return this.gclass5_0.GetEnumerator();
	}

	// Token: 0x06000159 RID: 345 RVA: 0x00003EFD File Offset: 0x000020FD
	public bool method_8(string string_1)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("headerName");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("headerName");
		}
		return this.dictionary_0.ContainsKey(string_1);
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00003F2C File Offset: 0x0000212C
	public bool method_9(GEnum1 genum1_0)
	{
		return this.method_8(GClass6.dictionary_0[genum1_0]);
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00003F3F File Offset: 0x0000213F
	public Dictionary<string, string>.Enumerator method_10()
	{
		return this.dictionary_0.GetEnumerator();
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00024CC8 File Offset: 0x00022EC8
	internal long method_11(GEnum2 genum2_1)
	{
		this.GEnum2_0 = genum2_1;
		this.Uri_0 = this.gclass7_0.Uri_1;
		this.Boolean_0 = false;
		this.Boolean_1 = false;
		this.Nullable_0 = null;
		this.Nullable_1 = null;
		this.dictionary_0.Clear();
		this.gclass5_0.Clear();
		if (this.gclass7_0.GClass5_0 != null && !this.gclass7_0.GClass5_0.Boolean_0)
		{
			this.GClass5_0 = this.gclass7_0.GClass5_0;
		}
		else
		{
			this.GClass5_0 = new GClass5(false);
		}
		if (this.class5_0 == null)
		{
			this.class5_0 = new GClass8.Class5(this.gclass7_0.TcpClient_0.ReceiveBufferSize);
		}
		this.class5_0.method_0(this.gclass7_0.Stream_0);
		try
		{
			this.method_12();
			this.method_14();
			this.Uri_1 = this.method_26();
			this.Encoding_0 = this.method_27();
			this.Int32_1 = this.method_28();
			this.String_0 = this.method_29();
			this.Nullable_0 = this.method_24();
			this.Nullable_1 = this.method_25();
		}
		catch (Exception ex)
		{
			this.Boolean_0 = true;
			if (ex is IOException)
			{
				throw this.method_33(Class2.String_19, ex);
			}
			throw;
		}
		if (this.Int32_1 == 0 || this.GEnum2_0 == GEnum2.HEAD || this.GEnum3_0 == GEnum3.Continue || this.GEnum3_0 == GEnum3.NoContent || this.GEnum3_0 == GEnum3.NotModified)
		{
			this.Boolean_1 = true;
		}
		long num = (long)this.class5_0.Int32_1;
		if (this.Int32_1 > 0)
		{
			num += (long)this.Int32_1;
		}
		return num;
	}

	// Token: 0x0600015D RID: 349 RVA: 0x00024E88 File Offset: 0x00023088
	private void method_12()
	{
		string text;
		do
		{
			text = this.class5_0.method_1();
			if (text.Length == 0)
			{
				goto IL_23;
			}
		}
		while (text == "\r\n");
		string text2 = text.smethod_5("HTTP/", " ", StringComparison.Ordinal);
		string text3 = text.smethod_5(" ", " ", StringComparison.Ordinal);
		if (text3.Length == 0)
		{
			text3 = text.smethod_5(" ", "\r\n", StringComparison.Ordinal);
		}
		if (text2.Length == 0 || text3.Length == 0)
		{
			throw this.method_33(Class2.String_23, null);
		}
		this.Version_0 = new Version(text2);
		this.GEnum3_0 = (GEnum3)Enum.Parse(typeof(GEnum3), text3);
		return;
		IL_23:
		GException1 gexception = this.method_33(Class2.String_23, null);
		gexception.Boolean_0 = true;
		throw gexception;
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00024F50 File Offset: 0x00023150
	private void method_13(string string_1)
	{
		if (string_1.Length == 0)
		{
			return;
		}
		int num = string_1.IndexOf(';');
		int num2 = string_1.IndexOf('=');
		if (num2 == -1)
		{
			string string_2 = string.Format(Class2.String_28, string_1, this.Uri_0.Host);
			throw this.method_33(string_2, null);
		}
		string key = string_1.Substring(0, num2);
		string text;
		if (num == -1)
		{
			text = string_1.Substring(num2 + 1);
		}
		else
		{
			text = string_1.Substring(num2 + 1, num - num2 - 1);
			int num3 = string_1.IndexOf("expires=");
			if (num3 != -1)
			{
				int num4 = string_1.IndexOf(';', num3);
				num3 += 8;
				string s;
				if (num4 == -1)
				{
					s = string_1.Substring(num3);
				}
				else
				{
					s = string_1.Substring(num3, num4 - num3);
				}
				DateTime t;
				if (DateTime.TryParse(s, out t) && t < DateTime.Now)
				{
					this.GClass5_0.Remove(key);
				}
			}
		}
		if (text.Length != 0 && !text.Equals("deleted", StringComparison.OrdinalIgnoreCase))
		{
			this.GClass5_0[key] = text;
		}
		else
		{
			this.GClass5_0.Remove(key);
		}
		this.gclass5_0[key] = string_1;
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00025070 File Offset: 0x00023270
	private void method_14()
	{
		string text;
		for (;;)
		{
			text = this.class5_0.method_1();
			if (text == "\r\n")
			{
				return;
			}
			int num = text.IndexOf(':');
			if (num == -1)
			{
				break;
			}
			string text2 = text.Substring(0, num);
			string text3 = text.Substring(num + 1).Trim(new char[]
			{
				' ',
				'\t',
				'\r',
				'\n'
			});
			if (text2.Equals("Set-Cookie", StringComparison.OrdinalIgnoreCase))
			{
				this.method_13(text3);
			}
			else
			{
				this.dictionary_0[text2] = text3;
			}
		}
		string string_ = string.Format(Class2.String_29, text, this.Uri_0.Host);
		throw this.method_33(string_, null);
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00003F4C File Offset: 0x0000214C
	private IEnumerable<GClass8.Class4> method_15()
	{
		if (this.dictionary_0.ContainsKey("Content-Encoding"))
		{
			return this.method_17();
		}
		return this.method_16();
	}

	// Token: 0x06000161 RID: 353 RVA: 0x0002511C File Offset: 0x0002331C
	private IEnumerable<GClass8.Class4> method_16()
	{
		if (this.dictionary_0.ContainsKey("Transfer-Encoding"))
		{
			return this.method_20();
		}
		if (this.Int32_1 != -1)
		{
			return this.method_19(this.Int32_1);
		}
		return this.method_18(this.gclass7_0.Stream_0);
	}

	// Token: 0x06000162 RID: 354 RVA: 0x0002516C File Offset: 0x0002336C
	private IEnumerable<GClass8.Class4> method_17()
	{
		if (this.dictionary_0.ContainsKey("Transfer-Encoding"))
		{
			return this.method_22();
		}
		if (this.Int32_1 != -1)
		{
			return this.method_21(this.Int32_1);
		}
		GClass8.Stream1 stream_ = new GClass8.Stream1(this.gclass7_0.Stream_0, this.class5_0);
		return this.method_18(this.method_31(stream_));
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00003F6D File Offset: 0x0000216D
	private IEnumerable<GClass8.Class4> method_18(Stream stream_0)
	{
		GClass8.Class6 @class = new GClass8.Class6(-2);
		@class.gclass8_0 = this;
		@class.stream_1 = stream_0;
		return @class;
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00003F84 File Offset: 0x00002184
	private IEnumerable<GClass8.Class4> method_19(int int_2)
	{
		GClass8.Class7 @class = new GClass8.Class7(-2);
		@class.gclass8_0 = this;
		@class.int_3 = int_2;
		return @class;
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00003F9B File Offset: 0x0000219B
	private IEnumerable<GClass8.Class4> method_20()
	{
		GClass8.Class8 @class = new GClass8.Class8(-2);
		@class.gclass8_0 = this;
		return @class;
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00003FAB File Offset: 0x000021AB
	private IEnumerable<GClass8.Class4> method_21(int int_2)
	{
		GClass8.Class9 @class = new GClass8.Class9(-2);
		@class.gclass8_0 = this;
		@class.int_3 = int_2;
		return @class;
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00003FC2 File Offset: 0x000021C2
	private IEnumerable<GClass8.Class4> method_22()
	{
		GClass8.Class10 @class = new GClass8.Class10(-2);
		@class.gclass8_0 = this;
		return @class;
	}

	// Token: 0x06000168 RID: 360 RVA: 0x000251CC File Offset: 0x000233CC
	private bool method_23()
	{
		return (this.dictionary_0.ContainsKey("Connection") && this.dictionary_0["Connection"].Equals("close", StringComparison.OrdinalIgnoreCase)) || (this.dictionary_0.ContainsKey("Proxy-Connection") && this.dictionary_0["Proxy-Connection"].Equals("close", StringComparison.OrdinalIgnoreCase));
	}

	// Token: 0x06000169 RID: 361 RVA: 0x0002523C File Offset: 0x0002343C
	private int? method_24()
	{
		if (!this.dictionary_0.ContainsKey("Keep-Alive"))
		{
			return null;
		}
		string input = this.dictionary_0["Keep-Alive"];
		Match match = GClass8.regex_0.Match(input);
		if (match.Success)
		{
			return new int?(int.Parse(match.Groups["value"].Value) * 1000);
		}
		return null;
	}

	// Token: 0x0600016A RID: 362 RVA: 0x000252BC File Offset: 0x000234BC
	private int? method_25()
	{
		if (!this.dictionary_0.ContainsKey("Keep-Alive"))
		{
			return null;
		}
		string input = this.dictionary_0["Keep-Alive"];
		Match match = GClass8.regex_1.Match(input);
		if (match.Success)
		{
			return new int?(int.Parse(match.Groups["value"].Value));
		}
		return null;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00025334 File Offset: 0x00023534
	private Uri method_26()
	{
		string text;
		if (!this.dictionary_0.TryGetValue("Location", out text))
		{
			this.dictionary_0.TryGetValue("Redirect-Location", out text);
		}
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		Uri result;
		Uri.TryCreate(this.gclass7_0.Uri_1, text, out result);
		return result;
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00025388 File Offset: 0x00023588
	private Encoding method_27()
	{
		if (!this.dictionary_0.ContainsKey("Content-Type"))
		{
			return this.gclass7_0.Encoding_0 ?? Encoding.Default;
		}
		string input = this.dictionary_0["Content-Type"];
		Match match = GClass8.regex_2.Match(input);
		if (!match.Success)
		{
			return this.gclass7_0.Encoding_0 ?? Encoding.Default;
		}
		Group group = match.Groups["value"];
		Encoding result;
		try
		{
			result = Encoding.GetEncoding(group.Value);
		}
		catch
		{
			result = (this.gclass7_0.Encoding_0 ?? Encoding.Default);
		}
		return result;
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00025440 File Offset: 0x00023640
	private int method_28()
	{
		if (this.dictionary_0.ContainsKey("Content-Length"))
		{
			int result;
			int.TryParse(this.dictionary_0["Content-Length"], out result);
			return result;
		}
		return -1;
	}

	// Token: 0x0600016E RID: 366 RVA: 0x0002547C File Offset: 0x0002367C
	private string method_29()
	{
		if (this.dictionary_0.ContainsKey("Content-Type"))
		{
			string text = this.dictionary_0["Content-Type"];
			int num = text.IndexOf(';');
			if (num != -1)
			{
				text = text.Substring(0, num);
			}
			return text;
		}
		return string.Empty;
	}

	// Token: 0x0600016F RID: 367 RVA: 0x000254CC File Offset: 0x000236CC
	private void method_30()
	{
		int num = 0;
		int num2 = (this.gclass7_0.TcpClient_0.ReceiveTimeout < 10) ? 10 : this.gclass7_0.TcpClient_0.ReceiveTimeout;
		while (!this.gclass7_0.NetworkStream_0.DataAvailable)
		{
			if (num >= num2)
			{
				throw this.method_33(Class2.String_26, null);
			}
			num += 10;
			Thread.Sleep(10);
		}
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00025538 File Offset: 0x00023738
	private Stream method_31(Stream stream_0)
	{
		string text = this.dictionary_0["Content-Encoding"].ToLower();
		if (text == "gzip")
		{
			return new GZipStream(stream_0, CompressionMode.Decompress, true);
		}
		if (!(text == "deflate"))
		{
			throw new InvalidOperationException(string.Format(Class2.String_32, text));
		}
		return new DeflateStream(stream_0, CompressionMode.Decompress, true);
	}

	// Token: 0x06000171 RID: 369 RVA: 0x00025598 File Offset: 0x00023798
	private bool method_32(byte[] byte_2, int int_2, byte[] byte_3)
	{
		int num = int_2 - byte_3.Length + 1;
		for (int i = 0; i < num; i++)
		{
			for (int j = 0; j < byte_3.Length; j++)
			{
				char c = (char)byte_2[j + i];
				if (char.IsLetter(c))
				{
					c = char.ToLower(c);
				}
				if ((byte)c != byte_3[j])
				{
					break;
				}
				if (j == byte_3.Length - 1)
				{
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000172 RID: 370 RVA: 0x00003FD2 File Offset: 0x000021D2
	private GException1 method_33(string string_1, Exception exception_0 = null)
	{
		return new GException1(string.Format(string_1, this.Uri_0.Host), GEnum0.ReceiveFailure, GEnum3.None, exception_0);
	}

	// Token: 0x04000083 RID: 131
	private static readonly byte[] byte_0 = Encoding.ASCII.GetBytes("<html");

	// Token: 0x04000084 RID: 132
	private static readonly byte[] byte_1 = Encoding.ASCII.GetBytes("</html>");

	// Token: 0x04000085 RID: 133
	private static readonly Regex regex_0 = new Regex("timeout(|\\s+)=(|\\s+)(?<value>\\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	// Token: 0x04000086 RID: 134
	private static readonly Regex regex_1 = new Regex("max(|\\s+)=(|\\s+)(?<value>\\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	// Token: 0x04000087 RID: 135
	private static readonly Regex regex_2 = new Regex("charset(|\\s+)=(|\\s+)(?<value>[a-z,0-9,-]+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	// Token: 0x04000088 RID: 136
	private readonly GClass7 gclass7_0;

	// Token: 0x04000089 RID: 137
	private GClass8.Class5 class5_0;

	// Token: 0x0400008A RID: 138
	private readonly Dictionary<string, string> dictionary_0 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	// Token: 0x0400008B RID: 139
	private readonly GClass5 gclass5_0 = new GClass5(false);

	// Token: 0x0400008C RID: 140
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x0400008D RID: 141
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x0400008E RID: 142
	[CompilerGenerated]
	private int int_0;

	// Token: 0x0400008F RID: 143
	[CompilerGenerated]
	private Uri uri_0;

	// Token: 0x04000090 RID: 144
	[CompilerGenerated]
	private GEnum2 genum2_0;

	// Token: 0x04000091 RID: 145
	[CompilerGenerated]
	private Version version_0;

	// Token: 0x04000092 RID: 146
	[CompilerGenerated]
	private GEnum3 genum3_0;

	// Token: 0x04000093 RID: 147
	[CompilerGenerated]
	private Uri uri_1;

	// Token: 0x04000094 RID: 148
	[CompilerGenerated]
	private Encoding encoding_0;

	// Token: 0x04000095 RID: 149
	[CompilerGenerated]
	private int int_1;

	// Token: 0x04000096 RID: 150
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000097 RID: 151
	[CompilerGenerated]
	private GClass5 gclass5_1;

	// Token: 0x04000098 RID: 152
	[CompilerGenerated]
	private int? nullable_0;

	// Token: 0x04000099 RID: 153
	[CompilerGenerated]
	private int? nullable_1;

	// Token: 0x02000015 RID: 21
	private sealed class Class4
	{
		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000174 RID: 372 RVA: 0x00003FED File Offset: 0x000021ED
		// (set) Token: 0x06000175 RID: 373 RVA: 0x00003FF5 File Offset: 0x000021F5
		public int Int32_0 { get; set; }

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000176 RID: 374 RVA: 0x00003FFE File Offset: 0x000021FE
		// (set) Token: 0x06000177 RID: 375 RVA: 0x00004006 File Offset: 0x00002206
		public byte[] Byte_0 { get; set; }

		// Token: 0x0400009A RID: 154
		[CompilerGenerated]
		private int int_0;

		// Token: 0x0400009B RID: 155
		[CompilerGenerated]
		private byte[] byte_0;
	}

	// Token: 0x02000016 RID: 22
	private sealed class Class5
	{
		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000179 RID: 377 RVA: 0x0000400F File Offset: 0x0000220F
		public bool Boolean_0
		{
			get
			{
				return this.Int32_0 - this.Int32_1 != 0;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600017A RID: 378 RVA: 0x00004021 File Offset: 0x00002221
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00004029 File Offset: 0x00002229
		public int Int32_0 { get; private set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600017C RID: 380 RVA: 0x00004032 File Offset: 0x00002232
		// (set) Token: 0x0600017D RID: 381 RVA: 0x0000403A File Offset: 0x0000223A
		public int Int32_1 { get; private set; }

		// Token: 0x0600017E RID: 382 RVA: 0x00004043 File Offset: 0x00002243
		public Class5(int int_5)
		{
			this.int_1 = int_5;
			this.byte_0 = new byte[this.int_1];
		}

		// Token: 0x0600017F RID: 383 RVA: 0x00004073 File Offset: 0x00002273
		public void method_0(Stream stream_1)
		{
			this.stream_0 = stream_1;
			this.int_2 = 0;
			this.Int32_0 = 0;
			this.Int32_1 = 0;
		}

		// Token: 0x06000180 RID: 384 RVA: 0x00025658 File Offset: 0x00023858
		public string method_1()
		{
			this.int_2 = 0;
			for (;;)
			{
				if (this.Int32_1 == this.Int32_0)
				{
					this.Int32_1 = 0;
					this.Int32_0 = this.stream_0.Read(this.byte_0, 0, this.int_1);
					if (this.Int32_0 == 0)
					{
						break;
					}
				}
				byte[] array = this.byte_0;
				int int32_ = this.Int32_1;
				this.Int32_1 = int32_ + 1;
				byte b = array[int32_];
				byte[] array2 = this.byte_1;
				int32_ = this.int_2;
				this.int_2 = int32_ + 1;
				array2[int32_] = b;
				if (b == 10)
				{
					break;
				}
				if (this.int_2 == this.byte_1.Length)
				{
					byte[] array3 = new byte[this.byte_1.Length * 2];
					this.byte_1.CopyTo(array3, 0);
					this.byte_1 = array3;
				}
			}
			return Encoding.ASCII.GetString(this.byte_1, 0, this.int_2);
		}

		// Token: 0x06000181 RID: 385 RVA: 0x0002573C File Offset: 0x0002393C
		public int method_2(byte[] byte_2, int int_5, int int_6)
		{
			int num = this.Int32_0 - this.Int32_1;
			if (num > int_6)
			{
				num = int_6;
			}
			Array.Copy(this.byte_0, this.Int32_1, byte_2, int_5, num);
			this.Int32_1 += num;
			return num;
		}

		// Token: 0x0400009C RID: 156
		private const int int_0 = 1000;

		// Token: 0x0400009D RID: 157
		private Stream stream_0;

		// Token: 0x0400009E RID: 158
		private byte[] byte_0;

		// Token: 0x0400009F RID: 159
		private int int_1;

		// Token: 0x040000A0 RID: 160
		private int int_2;

		// Token: 0x040000A1 RID: 161
		private byte[] byte_1 = new byte[1000];

		// Token: 0x040000A2 RID: 162
		[CompilerGenerated]
		private int int_3;

		// Token: 0x040000A3 RID: 163
		[CompilerGenerated]
		private int int_4;
	}

	// Token: 0x02000017 RID: 23
	private sealed class Stream1 : Stream
	{
		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00004091 File Offset: 0x00002291
		// (set) Token: 0x06000183 RID: 387 RVA: 0x00004099 File Offset: 0x00002299
		public int Int32_0 { get; private set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000184 RID: 388 RVA: 0x000040A2 File Offset: 0x000022A2
		// (set) Token: 0x06000185 RID: 389 RVA: 0x000040AA File Offset: 0x000022AA
		public int Int32_1 { get; set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000186 RID: 390 RVA: 0x000040B3 File Offset: 0x000022B3
		// (set) Token: 0x06000187 RID: 391 RVA: 0x000040BB File Offset: 0x000022BB
		public int Int32_2 { get; set; }

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000188 RID: 392 RVA: 0x000040C4 File Offset: 0x000022C4
		public bool CanRead
		{
			get
			{
				return this.stream_0.CanRead;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000189 RID: 393 RVA: 0x000040D1 File Offset: 0x000022D1
		public bool CanSeek
		{
			get
			{
				return this.stream_0.CanSeek;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600018A RID: 394 RVA: 0x000040DE File Offset: 0x000022DE
		public bool CanTimeout
		{
			get
			{
				return this.stream_0.CanTimeout;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600018B RID: 395 RVA: 0x000040EB File Offset: 0x000022EB
		public bool CanWrite
		{
			get
			{
				return this.stream_0.CanWrite;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600018C RID: 396 RVA: 0x000040F8 File Offset: 0x000022F8
		public long Length
		{
			get
			{
				return this.stream_0.Length;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600018D RID: 397 RVA: 0x00004105 File Offset: 0x00002305
		// (set) Token: 0x0600018E RID: 398 RVA: 0x00004112 File Offset: 0x00002312
		public long Position
		{
			get
			{
				return this.stream_0.Position;
			}
			set
			{
				this.stream_0.Position = value;
			}
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00004120 File Offset: 0x00002320
		public Stream1(Stream stream_1, GClass8.Class5 class5_1)
		{
			this.stream_0 = stream_1;
			this.class5_0 = class5_1;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00004136 File Offset: 0x00002336
		public void Flush()
		{
			this.stream_0.Flush();
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00004143 File Offset: 0x00002343
		public void SetLength(long value)
		{
			this.stream_0.SetLength(value);
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00004151 File Offset: 0x00002351
		public long Seek(long offset, SeekOrigin origin)
		{
			return this.stream_0.Seek(offset, origin);
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00025780 File Offset: 0x00023980
		public int Read(byte[] buffer, int offset, int count)
		{
			if (this.Int32_2 != 0)
			{
				int num = this.Int32_2 - this.Int32_1;
				if (num == 0)
				{
					return 0;
				}
				if (num > buffer.Length)
				{
					num = buffer.Length;
				}
				if (this.class5_0.Boolean_0)
				{
					this.Int32_0 = this.class5_0.method_2(buffer, offset, num);
				}
				else
				{
					this.Int32_0 = this.stream_0.Read(buffer, offset, num);
				}
			}
			else if (this.class5_0.Boolean_0)
			{
				this.Int32_0 = this.class5_0.method_2(buffer, offset, count);
			}
			else
			{
				this.Int32_0 = this.stream_0.Read(buffer, offset, count);
			}
			this.Int32_1 += this.Int32_0;
			return this.Int32_0;
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00004160 File Offset: 0x00002360
		public void Write(byte[] buffer, int offset, int count)
		{
			this.stream_0.Write(buffer, offset, count);
		}

		// Token: 0x040000A4 RID: 164
		private Stream stream_0;

		// Token: 0x040000A5 RID: 165
		private GClass8.Class5 class5_0;

		// Token: 0x040000A6 RID: 166
		[CompilerGenerated]
		private int int_0;

		// Token: 0x040000A7 RID: 167
		[CompilerGenerated]
		private int int_1;

		// Token: 0x040000A8 RID: 168
		[CompilerGenerated]
		private int int_2;
	}
}
