﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000167 RID: 359
public class GameInfo : UserControl
{
	// Token: 0x06001169 RID: 4457 RVA: 0x0000DEF7 File Offset: 0x0000C0F7
	public GameInfo()
	{
		this.InitializeComponent();
	}

	// Token: 0x1700049D RID: 1181
	// (set) Token: 0x0600116A RID: 4458 RVA: 0x0000DF05 File Offset: 0x0000C105
	public float Single_0
	{
		set
		{
			this.picHP.Width = (int)((float)this.picHP.Parent.Width * value);
		}
	}

	// Token: 0x1700049E RID: 1182
	// (set) Token: 0x0600116B RID: 4459 RVA: 0x0000DF26 File Offset: 0x0000C126
	public string String_0
	{
		set
		{
			this.label1.Text = value;
		}
	}

	// Token: 0x1700049F RID: 1183
	// (set) Token: 0x0600116C RID: 4460 RVA: 0x0000DF34 File Offset: 0x0000C134
	public float Single_1
	{
		set
		{
			this.picMP.Width = (int)((float)this.picMP.Parent.Width * value);
		}
	}

	// Token: 0x170004A0 RID: 1184
	// (set) Token: 0x0600116D RID: 4461 RVA: 0x0000DF55 File Offset: 0x0000C155
	public float Single_2
	{
		set
		{
			this.picPet.Width = (int)((float)this.picPet.Parent.Width * value);
		}
	}

	// Token: 0x170004A1 RID: 1185
	// (set) Token: 0x0600116E RID: 4462 RVA: 0x0000DF76 File Offset: 0x0000C176
	public float Single_3
	{
		set
		{
			this.picExp.Width = (int)((float)this.picExp.Parent.Width * value);
		}
	}

	// Token: 0x0600116F RID: 4463 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0(object sender, EventArgs e)
	{
	}

	// Token: 0x06001170 RID: 4464 RVA: 0x0000DF97 File Offset: 0x0000C197
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001171 RID: 4465 RVA: 0x0005DF2C File Offset: 0x0005C12C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		this.splitContainer1 = new SplitContainer();
		this.splitContainer2 = new SplitContainer();
		this.panel1 = new Panel();
		this.picHP = new PictureBox();
		this.pictureBox3 = new PictureBox();
		this.picMP = new PictureBox();
		this.splitContainer3 = new SplitContainer();
		this.picPet = new PictureBox();
		this.pictureBox10 = new PictureBox();
		this.picExp = new PictureBox();
		this.pictureBox14 = new PictureBox();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.panel2 = new Panel();
		this.label1 = new Label();
		this.pictureBox1 = new PictureBox();
		this.label2 = new Label();
		this.label3 = new Label();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.panel1.SuspendLayout();
		((ISupportInitialize)this.picHP).BeginInit();
		((ISupportInitialize)this.pictureBox3).BeginInit();
		((ISupportInitialize)this.picMP).BeginInit();
		this.splitContainer3.Panel1.SuspendLayout();
		this.splitContainer3.Panel2.SuspendLayout();
		this.splitContainer3.SuspendLayout();
		((ISupportInitialize)this.picPet).BeginInit();
		((ISupportInitialize)this.pictureBox10).BeginInit();
		((ISupportInitialize)this.picExp).BeginInit();
		((ISupportInitialize)this.pictureBox14).BeginInit();
		this.panel2.SuspendLayout();
		((ISupportInitialize)this.pictureBox1).BeginInit();
		base.SuspendLayout();
		this.splitContainer1.BackColor = Color.Black;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.IsSplitterFixed = true;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
		this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
		this.splitContainer1.Size = new Size(462, 18);
		this.splitContainer1.SplitterDistance = 220;
		this.splitContainer1.SplitterWidth = 1;
		this.splitContainer1.TabIndex = 1;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.IsSplitterFixed = true;
		this.splitContainer2.Location = new Point(0, 0);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Orientation = Orientation.Horizontal;
		this.splitContainer2.Panel1.Controls.Add(this.panel1);
		this.splitContainer2.Panel1MinSize = 2;
		this.splitContainer2.Panel2.Controls.Add(this.label2);
		this.splitContainer2.Panel2.Controls.Add(this.picMP);
		this.splitContainer2.Panel2MinSize = 2;
		this.splitContainer2.Size = new Size(220, 18);
		this.splitContainer2.SplitterDistance = 7;
		this.splitContainer2.SplitterWidth = 1;
		this.splitContainer2.TabIndex = 0;
		this.panel1.Controls.Add(this.label3);
		this.panel1.Controls.Add(this.picHP);
		this.panel1.Controls.Add(this.pictureBox3);
		this.panel1.Dock = DockStyle.Fill;
		this.panel1.Location = new Point(0, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(220, 7);
		this.panel1.TabIndex = 2;
		this.picHP.Dock = DockStyle.Left;
		this.picHP.Image = GClass130.Bitmap_2;
		this.picHP.Location = new Point(0, 0);
		this.picHP.Name = "picHP";
		this.picHP.Size = new Size(80, 7);
		this.picHP.SizeMode = PictureBoxSizeMode.StretchImage;
		this.picHP.TabIndex = 1;
		this.picHP.TabStop = false;
		this.pictureBox3.Dock = DockStyle.Fill;
		this.pictureBox3.Image = GClass130.Bitmap_5;
		this.pictureBox3.Location = new Point(0, 0);
		this.pictureBox3.Name = "pictureBox3";
		this.pictureBox3.Size = new Size(220, 7);
		this.pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
		this.pictureBox3.TabIndex = 0;
		this.pictureBox3.TabStop = false;
		this.picMP.Dock = DockStyle.Left;
		this.picMP.Image = GClass130.Bitmap_6;
		this.picMP.Location = new Point(0, 0);
		this.picMP.Name = "picMP";
		this.picMP.Size = new Size(80, 10);
		this.picMP.SizeMode = PictureBoxSizeMode.StretchImage;
		this.picMP.TabIndex = 4;
		this.picMP.TabStop = false;
		this.splitContainer3.Dock = DockStyle.Fill;
		this.splitContainer3.IsSplitterFixed = true;
		this.splitContainer3.Location = new Point(0, 0);
		this.splitContainer3.Name = "splitContainer3";
		this.splitContainer3.Orientation = Orientation.Horizontal;
		this.splitContainer3.Panel1.Controls.Add(this.picPet);
		this.splitContainer3.Panel1.Controls.Add(this.pictureBox10);
		this.splitContainer3.Panel1MinSize = 2;
		this.splitContainer3.Panel2.Controls.Add(this.picExp);
		this.splitContainer3.Panel2.Controls.Add(this.pictureBox14);
		this.splitContainer3.Panel2MinSize = 2;
		this.splitContainer3.Size = new Size(241, 18);
		this.splitContainer3.SplitterDistance = 7;
		this.splitContainer3.SplitterWidth = 1;
		this.splitContainer3.TabIndex = 1;
		this.picPet.Dock = DockStyle.Left;
		this.picPet.Image = GClass130.Bitmap_2;
		this.picPet.Location = new Point(0, 0);
		this.picPet.Name = "picPet";
		this.picPet.Size = new Size(80, 7);
		this.picPet.SizeMode = PictureBoxSizeMode.StretchImage;
		this.picPet.TabIndex = 4;
		this.picPet.TabStop = false;
		this.pictureBox10.Dock = DockStyle.Fill;
		this.pictureBox10.Image = GClass130.Bitmap_5;
		this.pictureBox10.Location = new Point(0, 0);
		this.pictureBox10.Name = "pictureBox10";
		this.pictureBox10.Size = new Size(241, 7);
		this.pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
		this.pictureBox10.TabIndex = 2;
		this.pictureBox10.TabStop = false;
		this.picExp.Dock = DockStyle.Left;
		this.picExp.Image = GClass130.Bitmap_1;
		this.picExp.Location = new Point(0, 0);
		this.picExp.Name = "picExp";
		this.picExp.Size = new Size(80, 10);
		this.picExp.SizeMode = PictureBoxSizeMode.StretchImage;
		this.picExp.TabIndex = 4;
		this.picExp.TabStop = false;
		this.pictureBox14.Dock = DockStyle.Fill;
		this.pictureBox14.Image = GClass130.Bitmap_5;
		this.pictureBox14.Location = new Point(0, 0);
		this.pictureBox14.Name = "pictureBox14";
		this.pictureBox14.Size = new Size(241, 10);
		this.pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
		this.pictureBox14.TabIndex = 2;
		this.pictureBox14.TabStop = false;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.IsBalloon = true;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.panel2.Controls.Add(this.label1);
		this.panel2.Controls.Add(this.pictureBox1);
		this.panel2.Dock = DockStyle.Right;
		this.panel2.Location = new Point(462, 0);
		this.panel2.Name = "panel2";
		this.panel2.Size = new Size(210, 18);
		this.panel2.TabIndex = 2;
		this.label1.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
		this.label1.BackColor = Color.Transparent;
		this.label1.Font = new Font("Microsoft Sans Serif", 7.8f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.label1.ForeColor = Color.Yellow;
		this.label1.Location = new Point(3, 2);
		this.label1.Margin = new Padding(0);
		this.label1.Name = "label1";
		this.label1.Size = new Size(204, 14);
		this.label1.TabIndex = 1;
		this.label1.Text = "Phụng Hoàng Cổ Thành [96 69]";
		this.label1.TextAlign = ContentAlignment.TopCenter;
		this.pictureBox1.Dock = DockStyle.Fill;
		this.pictureBox1.Image = GClass130.Bitmap_4;
		this.pictureBox1.Location = new Point(0, 0);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new Size(210, 18);
		this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		this.label2.BackColor = Color.Peru;
		this.label2.Dock = DockStyle.Right;
		this.label2.Location = new Point(219, 0);
		this.label2.Name = "label2";
		this.label2.Size = new Size(1, 10);
		this.label2.TabIndex = 5;
		this.label3.BackColor = Color.Peru;
		this.label3.Dock = DockStyle.Right;
		this.label3.Location = new Point(219, 0);
		this.label3.Name = "label3";
		this.label3.Size = new Size(1, 7);
		this.label3.TabIndex = 6;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.Black;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.panel2);
		base.Name = "GameInfo";
		base.Size = new Size(672, 18);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		((ISupportInitialize)this.picHP).EndInit();
		((ISupportInitialize)this.pictureBox3).EndInit();
		((ISupportInitialize)this.picMP).EndInit();
		this.splitContainer3.Panel1.ResumeLayout(false);
		this.splitContainer3.Panel2.ResumeLayout(false);
		this.splitContainer3.ResumeLayout(false);
		((ISupportInitialize)this.picPet).EndInit();
		((ISupportInitialize)this.pictureBox10).EndInit();
		((ISupportInitialize)this.picExp).EndInit();
		((ISupportInitialize)this.pictureBox14).EndInit();
		this.panel2.ResumeLayout(false);
		((ISupportInitialize)this.pictureBox1).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040008D6 RID: 2262
	private IContainer icontainer_0;

	// Token: 0x040008D7 RID: 2263
	private SplitContainer splitContainer1;

	// Token: 0x040008D8 RID: 2264
	private SplitContainer splitContainer2;

	// Token: 0x040008D9 RID: 2265
	private SplitContainer splitContainer3;

	// Token: 0x040008DA RID: 2266
	private ToolTip toolTip_0;

	// Token: 0x040008DB RID: 2267
	private Panel panel1;

	// Token: 0x040008DC RID: 2268
	private PictureBox pictureBox3;

	// Token: 0x040008DD RID: 2269
	private PictureBox picHP;

	// Token: 0x040008DE RID: 2270
	private PictureBox picMP;

	// Token: 0x040008DF RID: 2271
	private PictureBox picPet;

	// Token: 0x040008E0 RID: 2272
	private PictureBox pictureBox10;

	// Token: 0x040008E1 RID: 2273
	private PictureBox picExp;

	// Token: 0x040008E2 RID: 2274
	private PictureBox pictureBox14;

	// Token: 0x040008E3 RID: 2275
	private Panel panel2;

	// Token: 0x040008E4 RID: 2276
	private PictureBox pictureBox1;

	// Token: 0x040008E5 RID: 2277
	private Label label1;

	// Token: 0x040008E6 RID: 2278
	private Label label3;

	// Token: 0x040008E7 RID: 2279
	private Label label2;
}
