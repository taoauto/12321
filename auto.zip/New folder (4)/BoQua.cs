﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x02000206 RID: 518
internal class BoQua : UserControl
{
	// Token: 0x06001AD8 RID: 6872 RVA: 0x0001374F File Offset: 0x0001194F
	public BoQua()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001AD9 RID: 6873 RVA: 0x00013768 File Offset: 0x00011968
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001ADA RID: 6874 RVA: 0x000CA4A8 File Offset: 0x000C86A8
	private void method_0()
	{
		foreach (object obj in this.listViewName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtBoQua.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtBoQua.Text = this.txtBoQua.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtBoQua.method_1();
	}

	// Token: 0x06001ADB RID: 6875 RVA: 0x00013768 File Offset: 0x00011968
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001ADC RID: 6876 RVA: 0x000CA5A8 File Offset: 0x000C87A8
	private void BoQua_Load(object sender, EventArgs e)
	{
		this.txtBoQua.Text = Class415.String_4;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
	}

	// Token: 0x06001ADD RID: 6877 RVA: 0x00013770 File Offset: 0x00011970
	private void txtBoQua_TextChanged(object sender, EventArgs e)
	{
		Class415.String_4 = this.txtBoQua.Text;
		Class415.smethod_0();
	}

	// Token: 0x06001ADE RID: 6878 RVA: 0x00002E18 File Offset: 0x00001018
	private void listViewName_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001ADF RID: 6879 RVA: 0x00013787 File Offset: 0x00011987
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.listViewName.Search(this.txtSearch.Text);
	}

	// Token: 0x06001AE0 RID: 6880 RVA: 0x00002E18 File Offset: 0x00001018
	private void listViewName_DockChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001AE1 RID: 6881 RVA: 0x000137A0 File Offset: 0x000119A0
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001AE2 RID: 6882 RVA: 0x000CA6A4 File Offset: 0x000C88A4
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BoQua));
		this.listViewName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtBoQua = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.txtSearch = new Class85();
		this.menuName.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.ContextMenuStrip = this.menuName;
		this.listViewName.Dock = DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = Color.Red;
		this.listViewName.Location = new Point(0, 20);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new Size(241, 335);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = View.Details;
		this.listViewName.SelectedIndexChanged += this.listViewName_SelectedIndexChanged;
		this.listViewName.DockChanged += this.listViewName_DockChanged;
		this.listViewName.DoubleClick += this.listViewName_DoubleClick;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 185;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtBoQua.Dock = DockStyle.Fill;
		this.txtBoQua.Location = new Point(0, 0);
		this.txtBoQua.Multiline = true;
		this.txtBoQua.Name = "txtBoQua";
		this.txtBoQua.ScrollBars = ScrollBars.Vertical;
		this.txtBoQua.Size = new Size(234, 355);
		this.txtBoQua.TabIndex = 6;
		this.txtBoQua.String_0 = "";
		this.txtBoQua.Color_0 = Color.Gray;
		this.txtBoQua.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtBoQua.Color_1 = Color.LightGray;
		this.txtBoQua.TextChanged += this.txtBoQua_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtBoQua);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(479, 355);
		this.splitContainer1.SplitterDistance = 234;
		this.splitContainer1.TabIndex = 8;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(241, 20);
		this.txtSearch.TabIndex = 8;
		this.txtSearch.String_0 = "Search.";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(479, 355);
		base.Controls.Add(this.splitContainer1);
		base.Name = "BoQua";
		base.Tag = "Bỏ Qua Quái - Skip Monter";
		this.Text = "Bỏ Qua Quái - Skip Monter";
		base.Load += this.BoQua_Load;
		this.menuName.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040010CF RID: 4303
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040010D0 RID: 4304
	private IContainer icontainer_0;

	// Token: 0x040010D1 RID: 4305
	private ListViewEx listViewName;

	// Token: 0x040010D2 RID: 4306
	private ColumnHeader columnHeader_0;

	// Token: 0x040010D3 RID: 4307
	private Class85 txtBoQua;

	// Token: 0x040010D4 RID: 4308
	private SplitContainer splitContainer1;

	// Token: 0x040010D5 RID: 4309
	private ContextMenuStrip menuName;

	// Token: 0x040010D6 RID: 4310
	private ToolStripMenuItem menuAddName;

	// Token: 0x040010D7 RID: 4311
	private Class85 txtSearch;
}
