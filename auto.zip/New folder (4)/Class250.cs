﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

// Token: 0x0200021E RID: 542
internal class Class250 : Label
{
	// Token: 0x06001D1F RID: 7455 RVA: 0x000D7154 File Offset: 0x000D5354
	public Class250()
	{
		this.float_0 = 1f;
		this.color_0 = Color.White;
		this.graphicsPath_0 = new GraphicsPath();
		this.pen_0 = new Pen(new SolidBrush(this.color_0), this.float_0);
		this.solidBrush_0 = new SolidBrush(this.ForeColor);
		base.Invalidate();
	}

	// Token: 0x170006AD RID: 1709
	// (get) Token: 0x06001D20 RID: 7456 RVA: 0x0001571E File Offset: 0x0001391E
	// (set) Token: 0x06001D21 RID: 7457 RVA: 0x000D71BC File Offset: 0x000D53BC
	[DefaultValue(1f)]
	[Description("The border's thickness")]
	[Category("Appearance")]
	[Browsable(true)]
	public float Single_0
	{
		get
		{
			return this.float_0;
		}
		set
		{
			this.float_0 = value;
			if (value == 0f)
			{
				this.pen_0.Color = Color.Transparent;
			}
			else
			{
				this.pen_0.Color = this.Color_0;
				this.pen_0.Width = value;
			}
			this.OnTextChanged(EventArgs.Empty);
		}
	}

	// Token: 0x170006AE RID: 1710
	// (get) Token: 0x06001D22 RID: 7458 RVA: 0x00015726 File Offset: 0x00013926
	// (set) Token: 0x06001D23 RID: 7459 RVA: 0x0001572E File Offset: 0x0001392E
	[Browsable(true)]
	[Category("Appearance")]
	[DefaultValue(typeof(Color), "White")]
	[Description("The border color of this component")]
	public Color Color_0
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			if (this.Single_0 != 0f)
			{
				this.pen_0.Color = value;
			}
			base.Invalidate();
		}
	}

	// Token: 0x06001D24 RID: 7460 RVA: 0x000D7214 File Offset: 0x000D5414
	protected virtual void Dispose(bool disposing)
	{
		if (disposing)
		{
			if (this.solidBrush_0 != null)
			{
				this.solidBrush_0.Dispose();
			}
			if (this.graphicsPath_0 != null)
			{
				this.graphicsPath_0.Dispose();
			}
			if (this.pen_0 != null)
			{
				this.pen_0.Dispose();
			}
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001D25 RID: 7461 RVA: 0x00015756 File Offset: 0x00013956
	protected virtual void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		base.Invalidate();
	}

	// Token: 0x06001D26 RID: 7462 RVA: 0x00015765 File Offset: 0x00013965
	protected virtual void OnTextAlignChanged(EventArgs e)
	{
		base.OnTextAlignChanged(e);
		base.Invalidate();
	}

	// Token: 0x06001D27 RID: 7463 RVA: 0x00015774 File Offset: 0x00013974
	protected virtual void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
	}

	// Token: 0x06001D28 RID: 7464 RVA: 0x0001577D File Offset: 0x0001397D
	protected virtual void OnForeColorChanged(EventArgs e)
	{
		this.solidBrush_0.Color = base.ForeColor;
		base.OnForeColorChanged(e);
		base.Invalidate();
	}

	// Token: 0x06001D29 RID: 7465 RVA: 0x000D7264 File Offset: 0x000D5464
	protected virtual void OnPaint(PaintEventArgs e)
	{
		if (this.Text.Length == 0)
		{
			return;
		}
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
		this.sizeF_0 = e.Graphics.MeasureString(this.Text, this.Font, default(PointF), StringFormat.GenericTypographic);
		if (this.AutoSize)
		{
			this.pointF_0.X = (float)base.Padding.Left;
			this.pointF_0.Y = (float)base.Padding.Top;
		}
		else
		{
			if (this.TextAlign != ContentAlignment.TopLeft && this.TextAlign != ContentAlignment.MiddleLeft)
			{
				if (this.TextAlign != ContentAlignment.BottomLeft)
				{
					if (this.TextAlign != ContentAlignment.TopCenter && this.TextAlign != ContentAlignment.MiddleCenter)
					{
						if (this.TextAlign != ContentAlignment.BottomCenter)
						{
							this.pointF_0.X = (float)base.Width - ((float)base.Padding.Right + this.sizeF_0.Width);
							goto IL_14C;
						}
					}
					this.pointF_0.X = ((float)base.Width - this.sizeF_0.Width) / 2f;
					goto IL_14C;
				}
			}
			this.pointF_0.X = (float)base.Padding.Left;
			IL_14C:
			if (this.TextAlign != ContentAlignment.TopLeft && this.TextAlign != ContentAlignment.TopCenter)
			{
				if (this.TextAlign != ContentAlignment.TopRight)
				{
					if (this.TextAlign != ContentAlignment.MiddleLeft && this.TextAlign != ContentAlignment.MiddleCenter)
					{
						if (this.TextAlign != ContentAlignment.MiddleRight)
						{
							this.pointF_0.Y = (float)base.Height - ((float)base.Padding.Bottom + this.sizeF_0.Height);
							goto IL_1FF;
						}
					}
					this.pointF_0.Y = ((float)base.Height - this.sizeF_0.Height) / 2f;
					goto IL_1FF;
				}
			}
			this.pointF_0.Y = (float)base.Padding.Top;
		}
		IL_1FF:
		float emSize = e.Graphics.DpiY * this.Font.SizeInPoints / 72f;
		this.graphicsPath_0.Reset();
		this.graphicsPath_0.AddString(this.Text, this.Font.FontFamily, (int)this.Font.Style, emSize, this.pointF_0, StringFormat.GenericTypographic);
		e.Graphics.FillPath(this.solidBrush_0, this.graphicsPath_0);
		e.Graphics.DrawPath(this.pen_0, this.graphicsPath_0);
	}

	// Token: 0x040011C6 RID: 4550
	private float float_0;

	// Token: 0x040011C7 RID: 4551
	private Color color_0;

	// Token: 0x040011C8 RID: 4552
	private PointF pointF_0;

	// Token: 0x040011C9 RID: 4553
	private SizeF sizeF_0;

	// Token: 0x040011CA RID: 4554
	private Pen pen_0;

	// Token: 0x040011CB RID: 4555
	private GraphicsPath graphicsPath_0;

	// Token: 0x040011CC RID: 4556
	private SolidBrush solidBrush_0;
}
