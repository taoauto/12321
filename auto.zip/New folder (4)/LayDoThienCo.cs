﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001EC RID: 492
public class LayDoThienCo : UserControl
{
	// Token: 0x060019E7 RID: 6631 RVA: 0x00012CBE File Offset: 0x00010EBE
	public LayDoThienCo()
	{
		this.InitializeComponent();
	}

	// Token: 0x060019E8 RID: 6632 RVA: 0x000BC03C File Offset: 0x000BA23C
	private void LayDoThienCo_Load(object sender, EventArgs e)
	{
		this.txtDropName.Text = Class415.String_18;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(LayDoThienCo.Class228.<>9.method_0)).ToArray<ListViewItem>());
	}

	// Token: 0x060019E9 RID: 6633 RVA: 0x00012CCC File Offset: 0x00010ECC
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060019EA RID: 6634 RVA: 0x000BC0A4 File Offset: 0x000BA2A4
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtDropName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtDropName.Text = this.txtDropName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtDropName.method_1();
	}

	// Token: 0x060019EB RID: 6635 RVA: 0x00012CD4 File Offset: 0x00010ED4
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x060019EC RID: 6636 RVA: 0x000BC1A4 File Offset: 0x000BA3A4
	private void txtDropName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_18 = this.txtDropName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x060019ED RID: 6637 RVA: 0x00012CED File Offset: 0x00010EED
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060019EE RID: 6638 RVA: 0x000BC20C File Offset: 0x000BA40C
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(LayDoThienCo));
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtDropName = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(234, 367);
		this.lvName.TabIndex = 20;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Tên Vật Phẩm";
		this.columnHeader_0.Width = 180;
		this.txtDropName.Dock = DockStyle.Fill;
		this.txtDropName.Location = new Point(0, 0);
		this.txtDropName.Multiline = true;
		this.txtDropName.Name = "txtDropName";
		this.txtDropName.ScrollBars = ScrollBars.Vertical;
		this.txtDropName.Size = new Size(222, 387);
		this.txtDropName.TabIndex = 18;
		this.txtDropName.String_0 = "";
		this.txtDropName.Color_0 = Color.Gray;
		this.txtDropName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtDropName.Color_1 = Color.LightGray;
		this.txtDropName.TextChanged += this.txtDropName_TextChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtDropName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(460, 387);
		this.splitContainer1.SplitterDistance = 222;
		this.splitContainer1.TabIndex = 0;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(234, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(460, 387);
		base.Controls.Add(this.splitContainer1);
		base.Name = "LayDoThienCo";
		this.Text = "Lấy Đồ Từ Túi Càn Khôn";
		base.Load += this.LayDoThienCo_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000F53 RID: 3923
	private IContainer icontainer_0;

	// Token: 0x04000F54 RID: 3924
	private ListViewEx lvName;

	// Token: 0x04000F55 RID: 3925
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F56 RID: 3926
	private Class85 txtDropName;

	// Token: 0x04000F57 RID: 3927
	private SplitContainer splitContainer1;

	// Token: 0x04000F58 RID: 3928
	private Class85 txtSearchName;

	// Token: 0x020001ED RID: 493
	[CompilerGenerated]
	[Serializable]
	private sealed class Class228
	{
		// Token: 0x060019F1 RID: 6641 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000F59 RID: 3929
		public static readonly LayDoThienCo.Class228 <>9 = new LayDoThienCo.Class228();

		// Token: 0x04000F5A RID: 3930
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
