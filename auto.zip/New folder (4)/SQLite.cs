﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x0200027E RID: 638
public partial class SQLite : Form
{
	// Token: 0x060023F2 RID: 9202 RVA: 0x0001B7EA File Offset: 0x000199EA
	public SQLite()
	{
		this.InitializeComponent();
	}

	// Token: 0x060023F3 RID: 9203 RVA: 0x00002E18 File Offset: 0x00001018
	public void method_0()
	{
	}

	// Token: 0x060023F4 RID: 9204 RVA: 0x00002E18 File Offset: 0x00001018
	public void method_1()
	{
	}

	// Token: 0x060023F5 RID: 9205 RVA: 0x00002E18 File Offset: 0x00001018
	private void button1_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060023F6 RID: 9206 RVA: 0x00002E18 File Offset: 0x00001018
	private void button2_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060023F7 RID: 9207 RVA: 0x00002E18 File Offset: 0x00001018
	private void SQLite_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x060023F8 RID: 9208 RVA: 0x00002E18 File Offset: 0x00001018
	private void button3_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x060023F9 RID: 9209 RVA: 0x0001B7F8 File Offset: 0x000199F8
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x040017AD RID: 6061
	private IContainer icontainer_0;

	// Token: 0x0200027F RID: 639
	public class GClass125
	{
		// Token: 0x1700076D RID: 1901
		// (get) Token: 0x060023FB RID: 9211 RVA: 0x0001B817 File Offset: 0x00019A17
		// (set) Token: 0x060023FC RID: 9212 RVA: 0x0001B81F File Offset: 0x00019A1F
		public int Int32_0 { get; set; }

		// Token: 0x1700076E RID: 1902
		// (get) Token: 0x060023FD RID: 9213 RVA: 0x0001B828 File Offset: 0x00019A28
		// (set) Token: 0x060023FE RID: 9214 RVA: 0x0001B830 File Offset: 0x00019A30
		public string String_0 { get; set; }

		// Token: 0x1700076F RID: 1903
		// (get) Token: 0x060023FF RID: 9215 RVA: 0x0001B839 File Offset: 0x00019A39
		// (set) Token: 0x06002400 RID: 9216 RVA: 0x0001B841 File Offset: 0x00019A41
		public int Int32_1 { get; set; }

		// Token: 0x17000770 RID: 1904
		// (get) Token: 0x06002401 RID: 9217 RVA: 0x0001B84A File Offset: 0x00019A4A
		// (set) Token: 0x06002402 RID: 9218 RVA: 0x0001B852 File Offset: 0x00019A52
		public string[] String_1 { get; set; }

		// Token: 0x17000771 RID: 1905
		// (get) Token: 0x06002403 RID: 9219 RVA: 0x0001B85B File Offset: 0x00019A5B
		// (set) Token: 0x06002404 RID: 9220 RVA: 0x0001B863 File Offset: 0x00019A63
		public bool Boolean_0 { get; set; }

		// Token: 0x040017B1 RID: 6065
		[CompilerGenerated]
		private int int_0;

		// Token: 0x040017B2 RID: 6066
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040017B3 RID: 6067
		[CompilerGenerated]
		private int int_1;

		// Token: 0x040017B4 RID: 6068
		[CompilerGenerated]
		private string[] string_1;

		// Token: 0x040017B5 RID: 6069
		[CompilerGenerated]
		private bool bool_0;
	}
}
