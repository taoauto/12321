﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x0200013A RID: 314
public class GEventArgs21 : MouseEventArgs
{
	// Token: 0x17000406 RID: 1030
	// (get) Token: 0x06000F9E RID: 3998 RVA: 0x0000CF11 File Offset: 0x0000B111
	// (set) Token: 0x06000F9F RID: 3999 RVA: 0x0000CF19 File Offset: 0x0000B119
	public GClass87 GClass87_0 { get; private set; }

	// Token: 0x17000407 RID: 1031
	// (get) Token: 0x06000FA0 RID: 4000 RVA: 0x0000CF22 File Offset: 0x0000B122
	// (set) Token: 0x06000FA1 RID: 4001 RVA: 0x0000CF2A File Offset: 0x0000B12A
	public GClass105 GClass105_0 { get; private set; }

	// Token: 0x06000FA2 RID: 4002 RVA: 0x0000CF33 File Offset: 0x0000B133
	public GEventArgs21(GClass87 gclass87_1, GClass105 gclass105_1, MouseEventArgs mouseEventArgs_0) : base(mouseEventArgs_0.Button, mouseEventArgs_0.Clicks, mouseEventArgs_0.X, mouseEventArgs_0.Y, mouseEventArgs_0.Delta)
	{
		this.GClass87_0 = gclass87_1;
		this.GClass105_0 = gclass105_1;
	}

	// Token: 0x04000809 RID: 2057
	[CompilerGenerated]
	private GClass87 gclass87_0;

	// Token: 0x0400080A RID: 2058
	[CompilerGenerated]
	private GClass105 gclass105_0;
}
