﻿using System;
using System.Threading;

// Token: 0x02000140 RID: 320
internal class Class125 : IDisposable
{
	// Token: 0x06000FAB RID: 4011 RVA: 0x0000CFA9 File Offset: 0x0000B1A9
	public Class125(object object_1)
	{
		this.object_0 = object_1;
		Monitor.Enter(this.object_0);
	}

	// Token: 0x06000FAC RID: 4012 RVA: 0x0000CFC3 File Offset: 0x0000B1C3
	public void Dispose()
	{
		Monitor.Exit(this.object_0);
	}

	// Token: 0x04000816 RID: 2070
	private object object_0;
}
