﻿using System;
using System.Drawing;

// Token: 0x020002F8 RID: 760
internal class Class418 : IDisposable
{
	// Token: 0x06002BC2 RID: 11202 RVA: 0x00126A3C File Offset: 0x00124C3C
	public Class418(Graphics graphics_1, int int_2, int int_3)
	{
		if (graphics_1 == null || int_2 <= 0 || int_3 <= 0)
		{
			throw new ArgumentException("Arguments are unacceptable");
		}
		IntPtr hdc = graphics_1.GetHdc();
		bool flag = true;
		if (!((this.intptr_0 = Class419.CreateCompatibleDC(hdc)) == IntPtr.Zero))
		{
			if ((this.intptr_1 = Class419.CreateCompatibleBitmap(hdc, int_2, int_3)) == IntPtr.Zero)
			{
				Class419.DeleteDC(this.intptr_0);
			}
			else
			{
				this.intptr_2 = Class419.SelectObject(this.intptr_0, this.intptr_1);
				if (this.intptr_2 == IntPtr.Zero)
				{
					Class419.DeleteObject(this.intptr_1);
					Class419.DeleteDC(this.intptr_0);
				}
				else
				{
					flag = false;
				}
			}
		}
		graphics_1.ReleaseHdc(hdc);
		if (flag)
		{
			throw new SystemException("GDI error occured while creating context");
		}
		this.graphics_0 = Graphics.FromHdc(this.intptr_0);
		this.int_0 = int_2;
		this.int_1 = int_3;
	}

	// Token: 0x06002BC3 RID: 11203 RVA: 0x00126B38 File Offset: 0x00124D38
	virtual ~Class418()
	{
		this.vmethod_0(false);
	}

	// Token: 0x06002BC4 RID: 11204 RVA: 0x00126B68 File Offset: 0x00124D68
	protected virtual void vmethod_0(bool bool_0)
	{
		if (bool_0 && this.graphics_0 != null)
		{
			this.graphics_0.Dispose();
		}
		Class419.SelectObject(this.intptr_0, this.intptr_2);
		Class419.DeleteDC(this.intptr_0);
		this.intptr_0 = (this.intptr_2 = IntPtr.Zero);
		Class419.DeleteObject(this.intptr_1);
		this.intptr_1 = IntPtr.Zero;
	}

	// Token: 0x06002BC5 RID: 11205 RVA: 0x00020036 File Offset: 0x0001E236
	public void Dispose()
	{
		this.vmethod_0(true);
		GC.SuppressFinalize(this);
	}

	// Token: 0x170009E7 RID: 2535
	// (get) Token: 0x06002BC6 RID: 11206 RVA: 0x00020045 File Offset: 0x0001E245
	public Graphics Graphics_0
	{
		get
		{
			return this.graphics_0;
		}
	}

	// Token: 0x06002BC7 RID: 11207 RVA: 0x00126BD4 File Offset: 0x00124DD4
	public void method_0()
	{
		if (this.intptr_0 != IntPtr.Zero)
		{
			Class419.StretchBlt(this.intptr_0, 0, this.int_1 - 1, this.int_0, -this.int_1, this.intptr_0, 0, 0, this.int_0, this.int_1, 13369376U);
		}
	}

	// Token: 0x170009E8 RID: 2536
	// (get) Token: 0x06002BC8 RID: 11208 RVA: 0x0002004D File Offset: 0x0001E24D
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x170009E9 RID: 2537
	// (get) Token: 0x06002BC9 RID: 11209 RVA: 0x00020055 File Offset: 0x0001E255
	public int Int32_1
	{
		get
		{
			return this.int_1;
		}
	}

	// Token: 0x06002BCA RID: 11210 RVA: 0x0002005D File Offset: 0x0001E25D
	public uint method_1(int int_2, int int_3)
	{
		if (!(this.intptr_0 != IntPtr.Zero))
		{
			throw new ObjectDisposedException(null, "GDI context seems to be disposed.");
		}
		return Class419.GetPixel(this.intptr_0, int_2, int_3);
	}

	// Token: 0x06002BCB RID: 11211 RVA: 0x0002008A File Offset: 0x0001E28A
	public void method_2(int int_2, int int_3, uint uint_0)
	{
		if (!(this.intptr_0 != IntPtr.Zero))
		{
			throw new ObjectDisposedException(null, "GDI context seems to be disposed.");
		}
		Class419.SetPixel(this.intptr_0, int_2, int_3, uint_0);
	}

	// Token: 0x06002BCC RID: 11212 RVA: 0x00126C30 File Offset: 0x00124E30
	public void method_3(Graphics graphics_1, Rectangle rectangle_0)
	{
		if (graphics_1 != null && !(this.intptr_0 == IntPtr.Zero))
		{
			IntPtr hdc = graphics_1.GetHdc();
			if (!(hdc == IntPtr.Zero))
			{
				Class419.BitBlt(hdc, rectangle_0.Left, rectangle_0.Top, rectangle_0.Width, rectangle_0.Height, this.intptr_0, 0, 0, 13369376U);
				graphics_1.ReleaseHdc(hdc);
			}
		}
	}

	// Token: 0x04001D17 RID: 7447
	private IntPtr intptr_0;

	// Token: 0x04001D18 RID: 7448
	private IntPtr intptr_1;

	// Token: 0x04001D19 RID: 7449
	private IntPtr intptr_2;

	// Token: 0x04001D1A RID: 7450
	private int int_0;

	// Token: 0x04001D1B RID: 7451
	private int int_1;

	// Token: 0x04001D1C RID: 7452
	private Graphics graphics_0;
}
