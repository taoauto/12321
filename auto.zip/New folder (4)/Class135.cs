﻿using System;
using System.IO;
using System.Net;

// Token: 0x02000155 RID: 341
internal class Class135 : Class134, Interface5
{
	// Token: 0x06001043 RID: 4163 RVA: 0x0005B0AC File Offset: 0x000592AC
	private void method_2(FtpWebRequest ftpWebRequest_0, Class141 class141_0)
	{
		if (class141_0.Boolean_0)
		{
			string text = class141_0.String_1;
			string domain = string.Empty;
			int num = text.IndexOf('\\');
			if (num >= 0)
			{
				domain = text.Substring(0, num);
				text = text.Substring(num + 1);
			}
			ftpWebRequest_0.Credentials = new NetworkCredential(text, class141_0.String_2)
			{
				Domain = domain
			};
		}
	}

	// Token: 0x06001044 RID: 4164 RVA: 0x00002E18 File Offset: 0x00001018
	public void imethod_0(Class130 class130_0)
	{
	}

	// Token: 0x06001045 RID: 4165 RVA: 0x0005B10C File Offset: 0x0005930C
	public Stream imethod_1(Class141 class141_0, long long_0, long long_1)
	{
		FtpWebRequest ftpWebRequest = (FtpWebRequest)base.method_0(class141_0);
		this.method_2(ftpWebRequest, class141_0);
		ftpWebRequest.Method = "RETR";
		ftpWebRequest.ContentOffset = long_0;
		return ftpWebRequest.GetResponse().GetResponseStream();
	}

	// Token: 0x06001046 RID: 4166 RVA: 0x0005B14C File Offset: 0x0005934C
	public Class140 imethod_2(Class141 class141_0, out Stream stream_0)
	{
		Class140 @class = new Class140();
		@class.Boolean_0 = true;
		stream_0 = null;
		FtpWebRequest ftpWebRequest = (FtpWebRequest)base.method_0(class141_0);
		ftpWebRequest.Method = "SIZE";
		this.method_2(ftpWebRequest, class141_0);
		using (FtpWebResponse ftpWebResponse = (FtpWebResponse)ftpWebRequest.GetResponse())
		{
			@class.Int64_0 = ftpWebResponse.ContentLength;
		}
		ftpWebRequest = (FtpWebRequest)base.method_0(class141_0);
		ftpWebRequest.Method = "MDTM";
		this.method_2(ftpWebRequest, class141_0);
		using (FtpWebResponse ftpWebResponse2 = (FtpWebResponse)ftpWebRequest.GetResponse())
		{
			@class.DateTime_0 = ftpWebResponse2.LastModified;
		}
		return @class;
	}
}
