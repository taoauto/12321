﻿// Token: 0x020002D2 RID: 722
internal partial class Loader : global::System.Windows.Forms.Form
{
	// Token: 0x060029A4 RID: 10660 RVA: 0x0011D29C File Offset: 0x0011B49C
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.lblMsg = new global::System.Windows.Forms.Label();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.lblClose = new global::System.Windows.Forms.Label();
		this.timer_1 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.lblMsg.BackColor = global::System.Drawing.Color.White;
		this.lblMsg.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.lblMsg.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.lblMsg.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.lblMsg.ForeColor = global::System.Drawing.Color.Green;
		this.lblMsg.Location = new global::System.Drawing.Point(0, 0);
		this.lblMsg.Name = "lblMsg";
		this.lblMsg.Size = new global::System.Drawing.Size(255, 45);
		this.lblMsg.TabIndex = 0;
		this.lblMsg.Text = "MicroAuto đang kết nối...";
		this.lblMsg.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.lblClose.AutoSize = true;
		this.lblClose.BackColor = global::System.Drawing.Color.Silver;
		this.lblClose.Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.lblClose.Location = new global::System.Drawing.Point(241, 1);
		this.lblClose.Name = "lblClose";
		this.lblClose.Size = new global::System.Drawing.Size(13, 13);
		this.lblClose.TabIndex = 1;
		this.lblClose.Text = "  ";
		this.lblClose.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.lblClose.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.lblClose_MouseClick);
		this.timer_1.Enabled = true;
		this.timer_1.Tick += new global::System.EventHandler(this.timer_1_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(255, 45);
		base.Controls.Add(this.lblClose);
		base.Controls.Add(this.lblMsg);
		base.Name = "Loader";
		base.Opacity = 0.9;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Loader";
		base.TopMost = true;
		base.Load += new global::System.EventHandler(this.Loader_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04001BDD RID: 7133
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04001BDE RID: 7134
	private global::System.Windows.Forms.Label lblMsg;

	// Token: 0x04001BDF RID: 7135
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04001BE0 RID: 7136
	private global::System.Windows.Forms.Label lblClose;

	// Token: 0x04001BE1 RID: 7137
	private global::System.Windows.Forms.Timer timer_1;
}
