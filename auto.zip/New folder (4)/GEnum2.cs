﻿using System;

// Token: 0x02000010 RID: 16
public enum GEnum2
{
	// Token: 0x04000045 RID: 69
	GET,
	// Token: 0x04000046 RID: 70
	HEAD,
	// Token: 0x04000047 RID: 71
	DELETE,
	// Token: 0x04000048 RID: 72
	POST,
	// Token: 0x04000049 RID: 73
	PUT
}
