﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

// Token: 0x02000035 RID: 53
public class GClass21 : GClass16
{
	// Token: 0x06000254 RID: 596 RVA: 0x00004900 File Offset: 0x00002B00
	public GClass21() : this(null)
	{
	}

	// Token: 0x06000255 RID: 597 RVA: 0x00004909 File Offset: 0x00002B09
	public GClass21(string string_3) : this(string_3, 1080)
	{
	}

	// Token: 0x06000256 RID: 598 RVA: 0x00004917 File Offset: 0x00002B17
	public GClass21(string string_3, int int_4) : this(string_3, int_4, string.Empty, string.Empty)
	{
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0000492B File Offset: 0x00002B2B
	public GClass21(string string_3, int int_4, string string_4, string string_5) : base(GEnum4.Socks5, string_3, int_4, string_4, string_5)
	{
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00004939 File Offset: 0x00002B39
	public static GClass21 smethod_2(string string_3)
	{
		return GClass16.smethod_0(GEnum4.Socks5, string_3) as GClass21;
	}

	// Token: 0x06000259 RID: 601 RVA: 0x000276B4 File Offset: 0x000258B4
	public static bool smethod_3(string string_3, out GClass21 gclass21_0)
	{
		GClass16 gclass;
		if (GClass16.smethod_1(GEnum4.Socks5, string_3, out gclass))
		{
			gclass21_0 = (gclass as GClass21);
			return true;
		}
		gclass21_0 = null;
		return false;
	}

	// Token: 0x0600025A RID: 602 RVA: 0x000276DC File Offset: 0x000258DC
	public override TcpClient \u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string string_3, int int_4, TcpClient tcpClient_0 = null)
	{
		base.method_1();
		if (string_3 == null)
		{
			throw new ArgumentNullException("destinationHost");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("destinationHost");
		}
		if (!Class13.smethod_5(int_4))
		{
			throw Class13.smethod_4("destinationPort");
		}
		TcpClient tcpClient = tcpClient_0;
		if (tcpClient == null)
		{
			tcpClient = base.method_0();
		}
		try
		{
			NetworkStream stream = tcpClient.GetStream();
			this.method_3(stream);
			this.method_5(stream, 1, string_3, int_4);
		}
		catch (Exception ex)
		{
			tcpClient.Close();
			if (!(ex is IOException) && !(ex is SocketException))
			{
				throw;
			}
			throw base.method_2(Class2.String_41, ex);
		}
		return tcpClient;
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00027784 File Offset: 0x00025984
	private void method_3(NetworkStream networkStream_0)
	{
		byte b;
		if (!string.IsNullOrEmpty(this.string_1) && !string.IsNullOrEmpty(this.string_2))
		{
			b = 2;
		}
		else
		{
			b = 0;
		}
		byte[] array = new byte[]
		{
			5,
			1,
			b
		};
		networkStream_0.Write(array, 0, array.Length);
		byte[] array2 = new byte[2];
		networkStream_0.Read(array2, 0, array2.Length);
		byte b2 = array2[1];
		if (b == 2 && b2 == 2)
		{
			this.method_4(networkStream_0);
			return;
		}
		if (b2 != 0)
		{
			this.method_9(b2);
		}
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00027800 File Offset: 0x00025A00
	private void method_4(NetworkStream networkStream_0)
	{
		byte[] array = string.IsNullOrEmpty(this.string_1) ? new byte[0] : Encoding.ASCII.GetBytes(this.string_1);
		byte[] array2 = string.IsNullOrEmpty(this.string_2) ? new byte[0] : Encoding.ASCII.GetBytes(this.string_2);
		byte[] array3 = new byte[array.Length + array2.Length + 3];
		array3[0] = 1;
		array3[1] = (byte)array.Length;
		array.CopyTo(array3, 2);
		array3[2 + array.Length] = (byte)array2.Length;
		array2.CopyTo(array3, 3 + array.Length);
		networkStream_0.Write(array3, 0, array3.Length);
		byte[] array4 = new byte[2];
		networkStream_0.Read(array4, 0, array4.Length);
		if (array4[1] != 0)
		{
			throw base.method_2(Class2.String_48, null);
		}
	}

	// Token: 0x0600025D RID: 605 RVA: 0x000278C4 File Offset: 0x00025AC4
	private void method_5(NetworkStream networkStream_0, byte byte_25, string string_3, int int_4)
	{
		byte b = this.method_6(string_3);
		byte[] array = this.method_7(b, string_3);
		Array array2 = this.method_8(int_4);
		byte[] array3 = new byte[4 + array.Length + 2];
		array3[0] = 5;
		array3[1] = byte_25;
		array3[2] = 0;
		array3[3] = b;
		array.CopyTo(array3, 4);
		array2.CopyTo(array3, 4 + array.Length);
		networkStream_0.Write(array3, 0, array3.Length);
		byte[] array4 = new byte[255];
		networkStream_0.Read(array4, 0, array4.Length);
		byte b2 = array4[1];
		if (b2 != 0)
		{
			this.method_9(b2);
		}
	}

	// Token: 0x0600025E RID: 606 RVA: 0x00027950 File Offset: 0x00025B50
	private byte method_6(string string_3)
	{
		IPAddress ipaddress = null;
		if (!IPAddress.TryParse(string_3, out ipaddress))
		{
			return 3;
		}
		AddressFamily addressFamily = ipaddress.AddressFamily;
		if (addressFamily == AddressFamily.InterNetwork)
		{
			return 1;
		}
		if (addressFamily != AddressFamily.InterNetworkV6)
		{
			throw new GException2(string.Format(Class2.String_44, string_3, Enum.GetName(typeof(AddressFamily), ipaddress.AddressFamily), this.ToString()), this, null);
		}
		return 4;
	}

	// Token: 0x0600025F RID: 607 RVA: 0x000279B4 File Offset: 0x00025BB4
	private byte[] method_7(byte byte_25, string string_3)
	{
		switch (byte_25)
		{
		case 1:
		case 4:
			return IPAddress.Parse(string_3).GetAddressBytes();
		default:
			return null;
		case 3:
		{
			byte[] array = new byte[string_3.Length + 1];
			array[0] = (byte)string_3.Length;
			Encoding.ASCII.GetBytes(string_3).CopyTo(array, 1);
			return array;
		}
		}
	}

	// Token: 0x06000260 RID: 608 RVA: 0x000048E2 File Offset: 0x00002AE2
	private byte[] method_8(int int_4)
	{
		return new byte[]
		{
			(byte)(int_4 / 256),
			(byte)(int_4 % 256)
		};
	}

	// Token: 0x06000261 RID: 609 RVA: 0x00027A14 File Offset: 0x00025C14
	private void method_9(byte byte_25)
	{
		string arg;
		switch (byte_25)
		{
		case 1:
			arg = Class2.String_59;
			break;
		case 2:
			arg = Class2.String_57;
			break;
		case 3:
			arg = Class2.String_61;
			break;
		case 4:
			arg = Class2.String_60;
			break;
		case 5:
			arg = Class2.String_58;
			break;
		case 6:
			arg = Class2.String_62;
			break;
		case 7:
			arg = Class2.String_56;
			break;
		case 8:
			arg = Class2.String_55;
			break;
		default:
			if (byte_25 == 255)
			{
				arg = Class2.String_54;
			}
			else
			{
				arg = Class2.String_50;
			}
			break;
		}
		throw new GException2(string.Format(Class2.String_38, arg, this.ToString()), this, null);
	}

	// Token: 0x0400014A RID: 330
	private const int int_3 = 1080;

	// Token: 0x0400014B RID: 331
	private const byte byte_0 = 5;

	// Token: 0x0400014C RID: 332
	private const byte byte_1 = 0;

	// Token: 0x0400014D RID: 333
	private const byte byte_2 = 0;

	// Token: 0x0400014E RID: 334
	private const byte byte_3 = 1;

	// Token: 0x0400014F RID: 335
	private const byte byte_4 = 2;

	// Token: 0x04000150 RID: 336
	private const byte byte_5 = 3;

	// Token: 0x04000151 RID: 337
	private const byte byte_6 = 127;

	// Token: 0x04000152 RID: 338
	private const byte byte_7 = 128;

	// Token: 0x04000153 RID: 339
	private const byte byte_8 = 254;

	// Token: 0x04000154 RID: 340
	private const byte byte_9 = 255;

	// Token: 0x04000155 RID: 341
	private const byte byte_10 = 1;

	// Token: 0x04000156 RID: 342
	private const byte byte_11 = 2;

	// Token: 0x04000157 RID: 343
	private const byte byte_12 = 3;

	// Token: 0x04000158 RID: 344
	private const byte byte_13 = 0;

	// Token: 0x04000159 RID: 345
	private const byte byte_14 = 1;

	// Token: 0x0400015A RID: 346
	private const byte byte_15 = 2;

	// Token: 0x0400015B RID: 347
	private const byte byte_16 = 3;

	// Token: 0x0400015C RID: 348
	private const byte byte_17 = 4;

	// Token: 0x0400015D RID: 349
	private const byte byte_18 = 5;

	// Token: 0x0400015E RID: 350
	private const byte byte_19 = 6;

	// Token: 0x0400015F RID: 351
	private const byte byte_20 = 7;

	// Token: 0x04000160 RID: 352
	private const byte byte_21 = 8;

	// Token: 0x04000161 RID: 353
	private const byte byte_22 = 1;

	// Token: 0x04000162 RID: 354
	private const byte byte_23 = 3;

	// Token: 0x04000163 RID: 355
	private const byte byte_24 = 4;
}
