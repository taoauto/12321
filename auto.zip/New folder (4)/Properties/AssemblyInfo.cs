﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: Guid("4b7338bf-1ba6-4d00-8bba-7f60a6f912b7")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: NeutralResourcesLanguage("en")]
[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: AssemblyTitle("iAuto")]
[assembly: AssemblyCompany("tieudattai")]
[assembly: AssemblyProduct("iAuto by tieudattai.org")]
[assembly: AssemblyDescription("iAuto by tieudattai.org")]
[assembly: AssemblyConfiguration("")]
