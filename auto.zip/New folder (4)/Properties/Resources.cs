﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace L.Properties
{
	// Token: 0x02000018 RID: 24
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000080 RID: 128 RVA: 0x00002264 File Offset: 0x00000464
		internal Resources()
		{
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000081 RID: 129 RVA: 0x000025FA File Offset: 0x000007FA
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("L.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000082 RID: 130 RVA: 0x00002626 File Offset: 0x00000826
		// (set) Token: 0x06000083 RID: 131 RVA: 0x0000262D File Offset: 0x0000082D
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000084 RID: 132 RVA: 0x00002635 File Offset: 0x00000835
		internal static Icon icon
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("icon", Resources.resourceCulture);
			}
		}

		// Token: 0x04000051 RID: 81
		private static ResourceManager resourceMan;

		// Token: 0x04000052 RID: 82
		private static CultureInfo resourceCulture;
	}
}
