﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020000B4 RID: 180
internal class Class85 : TextBox
{
	// Token: 0x060008A3 RID: 2211 RVA: 0x0000899B File Offset: 0x00006B9B
	public Class85()
	{
		this.method_2();
		base.KeyDown += this.Class85_KeyDown;
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x0003CB80 File Offset: 0x0003AD80
	public void method_0(string string_1)
	{
		string_1 = string_1.smethod_0();
		base.SelectionStart = 0;
		int num = 0;
		foreach (string text in base.Lines)
		{
			if (text.smethod_0().Contains(string_1))
			{
				base.SelectionStart = num;
				this.SelectionLength = text.Length;
				base.ScrollToCaret();
				return;
			}
			num += text.Length;
		}
		base.ScrollToCaret();
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x0003CBF0 File Offset: 0x0003ADF0
	private void Class85_KeyDown(object sender, KeyEventArgs e)
	{
		TextBox textBox = sender as TextBox;
		if (e.Control && e.KeyCode == Keys.A)
		{
			textBox.SelectAll();
		}
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x000089C6 File Offset: 0x00006BC6
	public void method_1()
	{
		base.SelectionStart = this.TextLength;
		base.ScrollToCaret();
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x0003CC1C File Offset: 0x0003AE1C
	private void method_2()
	{
		this.color_0 = Color.LightGray;
		this.color_1 = Color.Gray;
		this.font_0 = this.Font;
		this.solidBrush_0 = new SolidBrush(this.color_1);
		this.panel_0 = null;
		this.method_4();
		base.Enter += this.Class85_Enter;
		base.Leave += this.Class85_Leave;
		base.TextChanged += this.Class85_TextChanged;
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x000089DA File Offset: 0x00006BDA
	private void method_3()
	{
		if (this.panel_0 != null)
		{
			base.Controls.Remove(this.panel_0);
			this.panel_0 = null;
		}
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0003CCA0 File Offset: 0x0003AEA0
	private void method_4()
	{
		if (this.panel_0 == null && this.TextLength <= 0)
		{
			this.panel_0 = new Panel();
			this.panel_0.Paint += this.panel_0_Paint;
			this.panel_0.Invalidate();
			this.panel_0.Click += this.panel_0_Click;
			base.Controls.Add(this.panel_0);
		}
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x000089FC File Offset: 0x00006BFC
	private void panel_0_Click(object sender, EventArgs e)
	{
		base.Focus();
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x0003CD14 File Offset: 0x0003AF14
	private void panel_0_Paint(object sender, PaintEventArgs e)
	{
		this.panel_0.Location = new Point(2, 0);
		this.panel_0.Height = base.Height;
		this.panel_0.Width = base.Width;
		this.panel_0.Anchor = (AnchorStyles.Left | AnchorStyles.Right);
		if (base.ContainsFocus)
		{
			this.solidBrush_0 = new SolidBrush(this.color_1);
		}
		else
		{
			this.solidBrush_0 = new SolidBrush(this.color_0);
		}
		e.Graphics.DrawString(this.string_0, this.font_0, this.solidBrush_0, new PointF(-2f, 1f));
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x00008A05 File Offset: 0x00006C05
	private void Class85_Enter(object sender, EventArgs e)
	{
		this.solidBrush_0 = new SolidBrush(this.color_1);
		if (this.TextLength <= 0)
		{
			this.method_3();
			this.method_4();
		}
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x00008A2D File Offset: 0x00006C2D
	private void Class85_Leave(object sender, EventArgs e)
	{
		if (this.TextLength > 0)
		{
			this.method_3();
			return;
		}
		base.Invalidate();
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x00008A45 File Offset: 0x00006C45
	private void Class85_TextChanged(object sender, EventArgs e)
	{
		if (this.TextLength > 0)
		{
			this.method_3();
			return;
		}
		this.method_4();
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x00008A5D File Offset: 0x00006C5D
	protected virtual void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		this.method_4();
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x00008A6C File Offset: 0x00006C6C
	protected virtual void OnInvalidated(InvalidateEventArgs e)
	{
		base.OnInvalidated(e);
		if (this.panel_0 != null)
		{
			this.panel_0.Invalidate();
		}
	}

	// Token: 0x17000275 RID: 629
	// (get) Token: 0x060008B1 RID: 2225 RVA: 0x00008A88 File Offset: 0x00006C88
	// (set) Token: 0x060008B2 RID: 2226 RVA: 0x00008A90 File Offset: 0x00006C90
	[Category("Watermark attribtues")]
	[Description("Sets the text of the watermark")]
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000276 RID: 630
	// (get) Token: 0x060008B3 RID: 2227 RVA: 0x00008A9F File Offset: 0x00006C9F
	// (set) Token: 0x060008B4 RID: 2228 RVA: 0x00008AA7 File Offset: 0x00006CA7
	[Category("Watermark attribtues")]
	[Description("When the control gaines focus, this color will be used as the watermark's forecolor")]
	public Color Color_0
	{
		get
		{
			return this.color_1;
		}
		set
		{
			this.color_1 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000277 RID: 631
	// (get) Token: 0x060008B5 RID: 2229 RVA: 0x00008AB6 File Offset: 0x00006CB6
	// (set) Token: 0x060008B6 RID: 2230 RVA: 0x00008ABE File Offset: 0x00006CBE
	[Category("Watermark attribtues")]
	[Description("When the control looses focus, this color will be used as the watermark's forecolor")]
	public Color Color_1
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000278 RID: 632
	// (get) Token: 0x060008B7 RID: 2231 RVA: 0x00008ACD File Offset: 0x00006CCD
	// (set) Token: 0x060008B8 RID: 2232 RVA: 0x00008AD5 File Offset: 0x00006CD5
	[Category("Watermark attribtues")]
	[Description("The font used on the watermark. Default is the same as the control")]
	public Font Font_0
	{
		get
		{
			return this.font_0;
		}
		set
		{
			this.font_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x04000479 RID: 1145
	protected string string_0 = "Default Watermark...";

	// Token: 0x0400047A RID: 1146
	protected Color color_0;

	// Token: 0x0400047B RID: 1147
	protected Color color_1;

	// Token: 0x0400047C RID: 1148
	private Panel panel_0;

	// Token: 0x0400047D RID: 1149
	private Font font_0;

	// Token: 0x0400047E RID: 1150
	private SolidBrush solidBrush_0;
}
