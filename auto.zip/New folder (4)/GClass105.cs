﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;

// Token: 0x02000139 RID: 313
public class GClass105 : GClass101
{
	// Token: 0x17000405 RID: 1029
	// (get) Token: 0x06000F9B RID: 3995 RVA: 0x0000CEF0 File Offset: 0x0000B0F0
	// (set) Token: 0x06000F9C RID: 3996 RVA: 0x0000CEF8 File Offset: 0x0000B0F8
	public GClass87 GClass87_0 { get; private set; }

	// Token: 0x06000F9D RID: 3997 RVA: 0x0000CF01 File Offset: 0x0000B101
	public GClass105(Rectangle rectangle_1, GClass87 gclass87_1) : base(rectangle_1)
	{
		this.GClass87_0 = gclass87_1;
	}

	// Token: 0x04000808 RID: 2056
	[CompilerGenerated]
	private GClass87 gclass87_0;
}
