﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Windows.Forms;

// Token: 0x020002D2 RID: 722
internal partial class Loader : Form
{
	// Token: 0x06002999 RID: 10649 RVA: 0x0001E803 File Offset: 0x0001CA03
	public Loader(string string_1)
	{
		this.InitializeComponent();
		this.lblMsg.Text = string_1;
		base.FormBorderStyle = FormBorderStyle.None;
		this.timer_0.Start();
	}

	// Token: 0x0600299A RID: 10650 RVA: 0x0001E83A File Offset: 0x0001CA3A
	public void method_0()
	{
		base.Height = 25;
		this.lblClose.Visible = false;
		Class438.smethod_14(this, Class438.Enum22.BottomCenter);
	}

	// Token: 0x0600299B RID: 10651 RVA: 0x0001E857 File Offset: 0x0001CA57
	public void method_1()
	{
		Class438.smethod_15(this);
		this.method_0();
	}

	// Token: 0x0600299C RID: 10652 RVA: 0x0001E865 File Offset: 0x0001CA65
	public Loader(int int_0, string string_1)
	{
		this.InitializeComponent();
		this.lblMsg.Text = string_1;
		base.FormBorderStyle = FormBorderStyle.None;
		this.timer_1.Start();
	}

	// Token: 0x0600299D RID: 10653 RVA: 0x0011D230 File Offset: 0x0011B430
	public void method_2()
	{
		Class412 @class = new Class412();
		@class.control_0 = this;
		@class.string_1 = this.string_0;
		if (Class268.string_1 != "")
		{
			@class.String_0 = "cmd=logout&settings=Test&email=" + HttpUtility.UrlEncode(User.string_0);
		}
		@class.Event_0 += this.method_3;
		@class.method_0();
	}

	// Token: 0x0600299E RID: 10654 RVA: 0x0001E89C File Offset: 0x0001CA9C
	private void method_3(object sender, EventArgs e)
	{
		if (((Class412)sender).Boolean_2)
		{
			this.method_2();
			return;
		}
		base.Dispose();
	}

	// Token: 0x0600299F RID: 10655 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void timer_0_Tick(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x060029A0 RID: 10656 RVA: 0x00013421 File Offset: 0x00011621
	private void lblClose_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			base.Dispose();
		}
	}

	// Token: 0x060029A1 RID: 10657 RVA: 0x0001E83A File Offset: 0x0001CA3A
	private void Loader_Load(object sender, EventArgs e)
	{
		base.Height = 25;
		this.lblClose.Visible = false;
		Class438.smethod_14(this, Class438.Enum22.BottomCenter);
	}

	// Token: 0x060029A2 RID: 10658 RVA: 0x0001E8B8 File Offset: 0x0001CAB8
	private void timer_1_Tick(object sender, EventArgs e)
	{
		if (Main.bool_15)
		{
			base.Dispose();
		}
	}

	// Token: 0x060029A3 RID: 10659 RVA: 0x0001E8C7 File Offset: 0x0001CAC7
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04001BDC RID: 7132
	private string string_0 = "http://www.tieudattai.info/microauto/user.php";
}
