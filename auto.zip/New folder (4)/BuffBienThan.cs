﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001D6 RID: 470
internal class BuffBienThan : UserControl
{
	// Token: 0x06001949 RID: 6473 RVA: 0x00012634 File Offset: 0x00010834
	public BuffBienThan()
	{
		this.InitializeComponent();
	}

	// Token: 0x0600194A RID: 6474 RVA: 0x000B52F8 File Offset: 0x000B34F8
	private void BuffBienThan_Load(object sender, EventArgs e)
	{
		this.txtLst.Text = Class415.String_0;
		foreach (Class393 @class in Class159.List_3)
		{
			this.listViewName.Items.Add(@class.String_2);
		}
	}

	// Token: 0x0600194B RID: 6475 RVA: 0x0001264D File Offset: 0x0001084D
	private void txtLst_TextChanged(object sender, EventArgs e)
	{
		Class415.String_0 = this.txtLst.Text;
	}

	// Token: 0x0600194C RID: 6476 RVA: 0x0001265F File Offset: 0x0001085F
	private void txtLst_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.A)
		{
			this.txtLst.SelectAll();
		}
	}

	// Token: 0x0600194D RID: 6477 RVA: 0x0001267E File Offset: 0x0001087E
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.listViewName.Search(this.txtSearch.Text);
	}

	// Token: 0x0600194E RID: 6478 RVA: 0x000B536C File Offset: 0x000B356C
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		using (IEnumerator enumerator = this.listViewName.SelectedItems.GetEnumerator())
		{
			IL_B7:
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				ListViewItem listViewItem = (ListViewItem)obj;
				if (listViewItem.Text.Trim() != "")
				{
					bool flag = false;
					string[] array = this.txtLst.Text.Split(new char[]
					{
						'\n'
					});
					int i = 0;
					while (i < array.Length)
					{
						if (!(array[i].Trim() == listViewItem.Text.Trim()))
						{
							i++;
						}
						else
						{
							flag = true;
							IL_89:
							if (!flag)
							{
								this.txtLst.Text = this.txtLst.Text.Trim() + "\r\n" + listViewItem.Text;
								goto IL_B7;
							}
							goto IL_B7;
						}
					}
					goto IL_89;
				}
			}
		}
		this.txtLst.method_1();
	}

	// Token: 0x0600194F RID: 6479 RVA: 0x00012697 File Offset: 0x00010897
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001950 RID: 6480 RVA: 0x000B546C File Offset: 0x000B366C
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BuffBienThan));
		this.txtLst = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.listViewName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtSearch = new Class85();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.txtLst.Dock = DockStyle.Fill;
		this.txtLst.Location = new Point(0, 0);
		this.txtLst.Multiline = true;
		this.txtLst.Name = "txtLst";
		this.txtLst.ScrollBars = ScrollBars.Both;
		this.txtLst.Size = new Size(241, 341);
		this.txtLst.TabIndex = 6;
		this.txtLst.String_0 = "";
		this.txtLst.Color_0 = Color.Gray;
		this.txtLst.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtLst.Color_1 = Color.LightGray;
		this.txtLst.TextChanged += this.txtLst_TextChanged;
		this.txtLst.KeyDown += this.txtLst_KeyDown;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtLst);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(495, 341);
		this.splitContainer1.SplitterDistance = 241;
		this.splitContainer1.TabIndex = 240;
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.Dock = DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = Color.Red;
		this.listViewName.Location = new Point(0, 20);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new Size(250, 321);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = View.Details;
		this.listViewName.DoubleClick += this.listViewName_DoubleClick;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 185;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(250, 20);
		this.txtSearch.TabIndex = 8;
		this.txtSearch.String_0 = "Search.";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(495, 341);
		base.Controls.Add(this.splitContainer1);
		base.Name = "BuffBienThan";
		base.Tag = "Ném Biến Thân";
		this.Text = "Danh Sách Ném Biến Thân";
		base.Load += this.BuffBienThan_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000ECC RID: 3788
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x04000ECD RID: 3789
	private IContainer icontainer_0;

	// Token: 0x04000ECE RID: 3790
	private Class85 txtLst;

	// Token: 0x04000ECF RID: 3791
	private SplitContainer splitContainer1;

	// Token: 0x04000ED0 RID: 3792
	private ListViewEx listViewName;

	// Token: 0x04000ED1 RID: 3793
	private ColumnHeader columnHeader_0;

	// Token: 0x04000ED2 RID: 3794
	private Class85 txtSearch;

	// Token: 0x020001D7 RID: 471
	private class Class214
	{
		// Token: 0x1700063D RID: 1597
		// (get) Token: 0x06001951 RID: 6481 RVA: 0x000126B6 File Offset: 0x000108B6
		// (set) Token: 0x06001952 RID: 6482 RVA: 0x000126BE File Offset: 0x000108BE
		public string String_0 { get; private set; }

		// Token: 0x1700063E RID: 1598
		// (get) Token: 0x06001953 RID: 6483 RVA: 0x000126C7 File Offset: 0x000108C7
		// (set) Token: 0x06001954 RID: 6484 RVA: 0x000126CF File Offset: 0x000108CF
		public string String_1 { get; private set; }

		// Token: 0x06001955 RID: 6485 RVA: 0x000126D8 File Offset: 0x000108D8
		public Class214(string string_2, string string_3)
		{
			this.String_0 = string_2;
			this.String_1 = string_3;
		}

		// Token: 0x06001956 RID: 6486 RVA: 0x000126EE File Offset: 0x000108EE
		public virtual string ToString()
		{
			return this.String_1;
		}

		// Token: 0x04000ED3 RID: 3795
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000ED4 RID: 3796
		[CompilerGenerated]
		private string string_1;
	}
}
