﻿using System;

// Token: 0x020000A4 RID: 164
public class GClass43
{
	// Token: 0x060007A6 RID: 1958 RVA: 0x0000812B File Offset: 0x0000632B
	public GClass43(string string_5, string string_6) : this(string_5, string_6, null, null)
	{
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x0003AA18 File Offset: 0x00038C18
	public GClass43(string string_5, string string_6, string string_7, params string[] string_8)
	{
		if (string_5 == null)
		{
			throw new ArgumentNullException("username");
		}
		if (string_5.Length == 0)
		{
			throw new ArgumentException("An empty string.", "username");
		}
		this.string_4 = string_5;
		this.string_2 = string_6;
		this.string_0 = string_7;
		this.string_3 = string_8;
	}

	// Token: 0x17000216 RID: 534
	// (get) Token: 0x060007A8 RID: 1960 RVA: 0x00008137 File Offset: 0x00006337
	// (set) Token: 0x060007A9 RID: 1961 RVA: 0x00008148 File Offset: 0x00006348
	public string String_0
	{
		get
		{
			return this.string_0 ?? string.Empty;
		}
		internal set
		{
			this.string_0 = value;
		}
	}

	// Token: 0x17000217 RID: 535
	// (get) Token: 0x060007AA RID: 1962 RVA: 0x00008151 File Offset: 0x00006351
	// (set) Token: 0x060007AB RID: 1963 RVA: 0x00008162 File Offset: 0x00006362
	public string String_1
	{
		get
		{
			return this.string_2 ?? string.Empty;
		}
		internal set
		{
			this.string_2 = value;
		}
	}

	// Token: 0x17000218 RID: 536
	// (get) Token: 0x060007AC RID: 1964 RVA: 0x0000816B File Offset: 0x0000636B
	// (set) Token: 0x060007AD RID: 1965 RVA: 0x0000817C File Offset: 0x0000637C
	public string[] String_2
	{
		get
		{
			return this.string_3 ?? GClass43.string_1;
		}
		internal set
		{
			this.string_3 = value;
		}
	}

	// Token: 0x17000219 RID: 537
	// (get) Token: 0x060007AE RID: 1966 RVA: 0x00008185 File Offset: 0x00006385
	// (set) Token: 0x060007AF RID: 1967 RVA: 0x0000818D File Offset: 0x0000638D
	public string String_3
	{
		get
		{
			return this.string_4;
		}
		internal set
		{
			this.string_4 = value;
		}
	}

	// Token: 0x04000430 RID: 1072
	private string string_0;

	// Token: 0x04000431 RID: 1073
	private static readonly string[] string_1 = new string[0];

	// Token: 0x04000432 RID: 1074
	private string string_2;

	// Token: 0x04000433 RID: 1075
	private string[] string_3;

	// Token: 0x04000434 RID: 1076
	private string string_4;
}
