﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x0200027C RID: 636
internal class OnlyAttack : UserControl
{
	// Token: 0x060023E7 RID: 9191 RVA: 0x0001B749 File Offset: 0x00019949
	public OnlyAttack()
	{
		this.InitializeComponent();
	}

	// Token: 0x060023E8 RID: 9192 RVA: 0x00105AC0 File Offset: 0x00103CC0
	private void OnlyAttack_Load(object sender, EventArgs e)
	{
		this.txtBoQua.Text = Class415.String_7;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_6 && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
	}

	// Token: 0x060023E9 RID: 9193 RVA: 0x0001B762 File Offset: 0x00019962
	private void listViewName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060023EA RID: 9194 RVA: 0x00105BC4 File Offset: 0x00103DC4
	private void method_0()
	{
		foreach (object obj in this.listViewName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtBoQua.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtBoQua.Text = this.txtBoQua.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtBoQua.method_1();
	}

	// Token: 0x060023EB RID: 9195 RVA: 0x0001B76A File Offset: 0x0001996A
	private void txtBoQua_TextChanged(object sender, EventArgs e)
	{
		Class415.String_7 = this.txtBoQua.Text;
		Class415.smethod_0();
	}

	// Token: 0x060023EC RID: 9196 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_1(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x060023ED RID: 9197 RVA: 0x0001B781 File Offset: 0x00019981
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060023EE RID: 9198 RVA: 0x00105CC4 File Offset: 0x00103EC4
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(OnlyAttack));
		this.splitContainer1 = new SplitContainer();
		this.txtBoQua = new Class85();
		this.listViewName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.txtSearch = new Class85();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtBoQua);
		this.splitContainer1.Panel2.Controls.Add(this.listViewName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(482, 379);
		this.splitContainer1.SplitterDistance = 241;
		this.splitContainer1.TabIndex = 11;
		this.txtBoQua.Dock = DockStyle.Fill;
		this.txtBoQua.Location = new Point(0, 0);
		this.txtBoQua.Multiline = true;
		this.txtBoQua.Name = "txtBoQua";
		this.txtBoQua.ScrollBars = ScrollBars.Vertical;
		this.txtBoQua.Size = new Size(241, 379);
		this.txtBoQua.TabIndex = 6;
		this.txtBoQua.String_0 = "";
		this.txtBoQua.Color_0 = Color.Gray;
		this.txtBoQua.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtBoQua.Color_1 = Color.LightGray;
		this.txtBoQua.TextChanged += this.txtBoQua_TextChanged;
		this.listViewName.AllowColumnReorder = true;
		this.listViewName.AllowDrop = true;
		this.listViewName.AllowReorder = true;
		this.listViewName.AllowSort = true;
		this.listViewName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewName.Dock = DockStyle.Fill;
		this.listViewName.DoubleClickActivation = false;
		this.listViewName.FullRowSelect = true;
		this.listViewName.GridLines = true;
		this.listViewName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewName.hideItems");
		this.listViewName.HideSelection = false;
		this.listViewName.LineColor = Color.Red;
		this.listViewName.Location = new Point(0, 20);
		this.listViewName.Name = "listViewName";
		this.listViewName.Size = new Size(237, 359);
		this.listViewName.TabIndex = 7;
		this.listViewName.UseCompatibleStateImageBehavior = false;
		this.listViewName.View = View.Details;
		this.listViewName.DoubleClick += this.listViewName_DoubleClick;
		this.columnHeader_0.Text = "Tên người";
		this.columnHeader_0.Width = 190;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(237, 20);
		this.txtSearch.TabIndex = 8;
		this.txtSearch.String_0 = "Search...";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Name = "OnlyAttack";
		base.Size = new Size(482, 379);
		base.Tag = "Chỉ Đánh - Only Attack";
		base.Load += this.OnlyAttack_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040017A4 RID: 6052
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040017A5 RID: 6053
	private IContainer icontainer_0;

	// Token: 0x040017A6 RID: 6054
	private SplitContainer splitContainer1;

	// Token: 0x040017A7 RID: 6055
	private Class85 txtBoQua;

	// Token: 0x040017A8 RID: 6056
	private ListViewEx listViewName;

	// Token: 0x040017A9 RID: 6057
	private ColumnHeader columnHeader_0;

	// Token: 0x040017AA RID: 6058
	private Class85 txtSearch;
}
