﻿using System;
using System.Collections;
using System.Collections.Generic;

// Token: 0x02000096 RID: 150
public class GClass39 : IEnumerable<string>, ICollection<string>, IEnumerable
{
	// Token: 0x060006F9 RID: 1785 RVA: 0x000077FB File Offset: 0x000059FB
	internal GClass39(GClass37 gclass37_1)
	{
		this.gclass37_0 = gclass37_1;
		this.list_0 = new List<string>();
	}

	// Token: 0x170001DC RID: 476
	// (get) Token: 0x060006FA RID: 1786 RVA: 0x00007815 File Offset: 0x00005A15
	public int Count
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x170001DD RID: 477
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x00006FDC File Offset: 0x000051DC
	public bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	// Token: 0x170001DE RID: 478
	// (get) Token: 0x060006FC RID: 1788 RVA: 0x00006FDC File Offset: 0x000051DC
	public bool Boolean_0
	{
		get
		{
			return false;
		}
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x00037824 File Offset: 0x00035A24
	public void Add(string uriPrefix)
	{
		if (this.gclass37_0.Boolean_0)
		{
			throw new ObjectDisposedException(this.gclass37_0.GetType().ToString());
		}
		Class74.smethod_0(uriPrefix);
		if (this.list_0.Contains(uriPrefix))
		{
			return;
		}
		this.list_0.Add(uriPrefix);
		if (!this.gclass37_0.Boolean_3)
		{
			return;
		}
		Class69.smethod_5(uriPrefix, this.gclass37_0);
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x00037890 File Offset: 0x00035A90
	public void Clear()
	{
		if (this.gclass37_0.Boolean_0)
		{
			throw new ObjectDisposedException(this.gclass37_0.GetType().ToString());
		}
		this.list_0.Clear();
		if (!this.gclass37_0.Boolean_3)
		{
			return;
		}
		Class69.smethod_6(this.gclass37_0);
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x00007822 File Offset: 0x00005A22
	public bool Contains(string uriPrefix)
	{
		if (this.gclass37_0.Boolean_0)
		{
			throw new ObjectDisposedException(this.gclass37_0.GetType().ToString());
		}
		if (uriPrefix == null)
		{
			throw new ArgumentNullException("uriPrefix");
		}
		return this.list_0.Contains(uriPrefix);
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00007861 File Offset: 0x00005A61
	public void CopyTo(string[] array, int offset)
	{
		if (this.gclass37_0.Boolean_0)
		{
			throw new ObjectDisposedException(this.gclass37_0.GetType().ToString());
		}
		this.list_0.CopyTo(array, offset);
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x00007893 File Offset: 0x00005A93
	public IEnumerator<string> GetEnumerator()
	{
		return this.list_0.GetEnumerator();
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x000378E4 File Offset: 0x00035AE4
	public bool Remove(string uriPrefix)
	{
		if (this.gclass37_0.Boolean_0)
		{
			throw new ObjectDisposedException(this.gclass37_0.GetType().ToString());
		}
		if (uriPrefix == null)
		{
			throw new ArgumentNullException("uriPrefix");
		}
		bool result;
		if (!(result = this.list_0.Remove(uriPrefix)))
		{
			return result;
		}
		if (!this.gclass37_0.Boolean_3)
		{
			return result;
		}
		Class69.smethod_7(uriPrefix, this.gclass37_0);
		return result;
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x00007893 File Offset: 0x00005A93
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.list_0.GetEnumerator();
	}

	// Token: 0x04000365 RID: 869
	private GClass37 gclass37_0;

	// Token: 0x04000366 RID: 870
	private List<string> list_0;
}
