﻿using System;
using System.Collections.Generic;

// Token: 0x02000152 RID: 338
internal class Class132 : Interface6
{
	// Token: 0x06001033 RID: 4147 RVA: 0x0005AE18 File Offset: 0x00059018
	public GStruct4[] imethod_0(int int_0, Class140 class140_0)
	{
		long num = (long)Class144.int_0;
		long num2 = class140_0.Int64_0 / (long)int_0;
		while (int_0 > 1 && num2 < num)
		{
			int_0--;
			num2 = class140_0.Int64_0 / (long)int_0;
		}
		long num3 = 0L;
		List<GStruct4> list = new List<GStruct4>();
		for (int i = 0; i < int_0; i++)
		{
			if (int_0 - 1 == i)
			{
				list.Add(new GStruct4(num3, class140_0.Int64_0));
			}
			else
			{
				list.Add(new GStruct4(num3, num3 + (long)((int)num2)));
			}
			num3 = list[list.Count - 1].Int64_1;
		}
		return list.ToArray();
	}
}
