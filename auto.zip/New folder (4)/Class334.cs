﻿using System;

// Token: 0x02000283 RID: 643
internal class Class334
{
	// Token: 0x17000775 RID: 1909
	// (get) Token: 0x0600240F RID: 9231 RVA: 0x0001B881 File Offset: 0x00019A81
	public static string String_0
	{
		get
		{
			return "Lôi Đài Sinh Tử";
		}
	}

	// Token: 0x040017C7 RID: 6087
	public static int int_0 = 546;

	// Token: 0x040017C8 RID: 6088
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 12436U,
		Int32_0 = 12,
		Int32_1 = 34,
		Int32_2 = Class334.int_0,
		String_2 = "Khô Vinh Đại Sư"
	};
}
