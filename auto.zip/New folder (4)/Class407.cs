﻿using System;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x020002E4 RID: 740
internal class Class407
{
	// Token: 0x06002A80 RID: 10880 RVA: 0x0001EF52 File Offset: 0x0001D152
	public static void smethod_0()
	{
		if (Main.Boolean_16)
		{
			return;
		}
		new SoundPlayer
		{
			Stream = GClass130.UnmanagedMemoryStream_2
		}.Play();
	}

	// Token: 0x06002A81 RID: 10881 RVA: 0x0001EF71 File Offset: 0x0001D171
	public static void smethod_1()
	{
		new SoundPlayer
		{
			Stream = GClass130.UnmanagedMemoryStream_1
		}.Play();
	}

	// Token: 0x170009A2 RID: 2466
	// (get) Token: 0x06002A82 RID: 10882 RVA: 0x0001EF88 File Offset: 0x0001D188
	// (set) Token: 0x06002A83 RID: 10883 RVA: 0x0001EF8F File Offset: 0x0001D18F
	public static string String_0
	{
		get
		{
			return Class407.string_0;
		}
		set
		{
			Class407.string_0 = value;
		}
	}

	// Token: 0x06002A84 RID: 10884 RVA: 0x0001EF97 File Offset: 0x0001D197
	private static void smethod_2()
	{
		Class407.mciSendString("open \"" + Class407.String_0 + "\" type mpegvideo alias MediaFile", null, 0, IntPtr.Zero);
		Class407.bool_0 = true;
	}

	// Token: 0x06002A85 RID: 10885 RVA: 0x00120760 File Offset: 0x0011E960
	private static void smethod_3()
	{
		try
		{
			Class407.mciSendString("stop MediaFile", null, 0, IntPtr.Zero);
		}
		catch
		{
		}
	}

	// Token: 0x06002A86 RID: 10886 RVA: 0x0001EFC0 File Offset: 0x0001D1C0
	public static void smethod_4()
	{
		if (Class268.bool_79)
		{
			return;
		}
		if (Main.Boolean_16)
		{
			return;
		}
		if (!Class407.bool_0)
		{
			Class407.smethod_2();
			Class407.mciSendString("play MediaFile REPEAT", null, 0, IntPtr.Zero);
		}
	}

	// Token: 0x06002A87 RID: 10887 RVA: 0x0001EFF0 File Offset: 0x0001D1F0
	public static void smethod_5()
	{
		if (!Class407.bool_0)
		{
			Class407.smethod_2();
			Class407.mciSendString("play MediaFile REPEAT", null, 0, IntPtr.Zero);
		}
	}

	// Token: 0x06002A88 RID: 10888 RVA: 0x00120794 File Offset: 0x0011E994
	public static void smethod_6()
	{
		Class407.mciSendString("close MediaFile", null, 0, IntPtr.Zero);
		Class407.mciSendString("open \"" + Class407.string_1 + "\" type mpegvideo alias MediaFile", null, 0, IntPtr.Zero);
		Class407.mciSendString("play MediaFile", null, 0, IntPtr.Zero);
	}

	// Token: 0x06002A89 RID: 10889 RVA: 0x0001F010 File Offset: 0x0001D210
	public static void smethod_7()
	{
		Class407.mciSendString("close MediaFile", null, 0, IntPtr.Zero);
		Class407.bool_0 = false;
	}

	// Token: 0x06002A8A RID: 10890
	[DllImport("winmm.dll")]
	private static extern long mciSendString(string string_2, StringBuilder stringBuilder_0, int int_0, IntPtr intptr_0);

	// Token: 0x04001C56 RID: 7254
	private static bool bool_0 = false;

	// Token: 0x04001C57 RID: 7255
	public static string string_0 = Class268.String_4 + "\\alarm.mp3";

	// Token: 0x04001C58 RID: 7256
	public static string string_1 = Class268.String_4 + "\\temp.mp3";
}
