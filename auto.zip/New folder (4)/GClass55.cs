﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020000BD RID: 189
[Browsable(false)]
public class GClass55 : ToolStripDropDown, IDisposable
{
	// Token: 0x1700027F RID: 639
	// (get) Token: 0x060008E4 RID: 2276 RVA: 0x00008C9B File Offset: 0x00006E9B
	// (set) Token: 0x060008E5 RID: 2277 RVA: 0x00008CA3 File Offset: 0x00006EA3
	public GClass86 GClass86_0 { get; internal set; }

	// Token: 0x17000280 RID: 640
	// (get) Token: 0x060008E6 RID: 2278 RVA: 0x00008CAC File Offset: 0x00006EAC
	// (set) Token: 0x060008E7 RID: 2279 RVA: 0x00008CB4 File Offset: 0x00006EB4
	public string String_0 { get; set; }

	// Token: 0x17000281 RID: 641
	// (get) Token: 0x060008E8 RID: 2280 RVA: 0x00008CBD File Offset: 0x00006EBD
	// (set) Token: 0x060008E9 RID: 2281 RVA: 0x00008CC5 File Offset: 0x00006EC5
	public int Int32_0 { get; set; }

	// Token: 0x14000010 RID: 16
	// (add) Token: 0x060008EA RID: 2282 RVA: 0x0003D12C File Offset: 0x0003B32C
	// (remove) Token: 0x060008EB RID: 2283 RVA: 0x0003D164 File Offset: 0x0003B364
	public event EventHandler<GEventArgs6> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs6> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs6> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs6> value2 = (EventHandler<GEventArgs6>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs6>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs6> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs6> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs6> value2 = (EventHandler<GEventArgs6>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs6>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000011 RID: 17
	// (add) Token: 0x060008EC RID: 2284 RVA: 0x0003D19C File Offset: 0x0003B39C
	// (remove) Token: 0x060008ED RID: 2285 RVA: 0x0003D1D4 File Offset: 0x0003B3D4
	public event EventHandler<GEventArgs7> Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs7> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs7> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs7> value2 = (EventHandler<GEventArgs7>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs7>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs7> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs7> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs7> value2 = (EventHandler<GEventArgs7>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs7>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000012 RID: 18
	// (add) Token: 0x060008EE RID: 2286 RVA: 0x0003D20C File Offset: 0x0003B40C
	// (remove) Token: 0x060008EF RID: 2287 RVA: 0x0003D244 File Offset: 0x0003B444
	public event EventHandler<CancelEventArgs> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<CancelEventArgs> eventHandler = this.eventHandler_2;
			EventHandler<CancelEventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<CancelEventArgs> value2 = (EventHandler<CancelEventArgs>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<CancelEventArgs>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<CancelEventArgs> eventHandler = this.eventHandler_2;
			EventHandler<CancelEventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<CancelEventArgs> value2 = (EventHandler<CancelEventArgs>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<CancelEventArgs>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x17000282 RID: 642
	// (get) Token: 0x060008F0 RID: 2288 RVA: 0x00008CCE File Offset: 0x00006ECE
	// (set) Token: 0x060008F1 RID: 2289 RVA: 0x00008CDB File Offset: 0x00006EDB
	public bool Boolean_0
	{
		get
		{
			return this.gcontrol0_0.Boolean_0;
		}
		set
		{
			this.gcontrol0_0.Boolean_0 = value;
		}
	}

	// Token: 0x17000283 RID: 643
	// (get) Token: 0x060008F2 RID: 2290 RVA: 0x00008CE9 File Offset: 0x00006EE9
	// (set) Token: 0x060008F3 RID: 2291 RVA: 0x00008CF6 File Offset: 0x00006EF6
	public int Int32_1
	{
		get
		{
			return this.gcontrol0_0.Int32_1;
		}
		set
		{
			this.gcontrol0_0.Int32_1 = value;
		}
	}

	// Token: 0x17000284 RID: 644
	// (get) Token: 0x060008F4 RID: 2292 RVA: 0x00008D04 File Offset: 0x00006F04
	// (set) Token: 0x060008F5 RID: 2293 RVA: 0x00008D11 File Offset: 0x00006F11
	public Size Size_0
	{
		get
		{
			return this.gcontrol0_0.Size_0;
		}
		set
		{
			this.gcontrol0_0.Size_0 = value;
		}
	}

	// Token: 0x17000285 RID: 645
	// (get) Token: 0x060008F6 RID: 2294 RVA: 0x00008D1F File Offset: 0x00006F1F
	// (set) Token: 0x060008F7 RID: 2295 RVA: 0x00008D2C File Offset: 0x00006F2C
	public bool Boolean_1
	{
		get
		{
			return this.gcontrol0_0.Boolean_1;
		}
		set
		{
			this.gcontrol0_0.Boolean_1 = value;
		}
	}

	// Token: 0x17000286 RID: 646
	// (get) Token: 0x060008F8 RID: 2296 RVA: 0x00008D3A File Offset: 0x00006F3A
	// (set) Token: 0x060008F9 RID: 2297 RVA: 0x00008D47 File Offset: 0x00006F47
	[DefaultValue(typeof(Color), "Orange")]
	public Color Color_0
	{
		get
		{
			return this.gcontrol0_0.Color_0;
		}
		set
		{
			this.gcontrol0_0.Color_0 = value;
		}
	}

	// Token: 0x17000287 RID: 647
	// (get) Token: 0x060008FA RID: 2298 RVA: 0x00008D55 File Offset: 0x00006F55
	// (set) Token: 0x060008FB RID: 2299 RVA: 0x00008D62 File Offset: 0x00006F62
	[DefaultValue(typeof(Color), "Red")]
	public Color Color_1
	{
		get
		{
			return this.gcontrol0_0.Color_1;
		}
		set
		{
			this.gcontrol0_0.Color_1 = value;
		}
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x0003D27C File Offset: 0x0003B47C
	public GClass55(FastColoredTextBox fastColoredTextBox_0)
	{
		base.AutoClose = false;
		this.AutoSize = false;
		base.Margin = Padding.Empty;
		base.Padding = Padding.Empty;
		base.BackColor = Color.White;
		this.gcontrol0_0 = new GControl0(fastColoredTextBox_0);
		this.toolStripControlHost_0 = new ToolStripControlHost(this.gcontrol0_0);
		this.toolStripControlHost_0.Margin = new Padding(2, 2, 2, 2);
		this.toolStripControlHost_0.Padding = Padding.Empty;
		this.toolStripControlHost_0.AutoSize = false;
		this.toolStripControlHost_0.AutoToolTip = false;
		this.method_2();
		base.Items.Add(this.toolStripControlHost_0);
		this.gcontrol0_0.Parent = this;
		this.String_0 = "[\\w\\.]";
		this.Int32_0 = 2;
	}

	// Token: 0x17000288 RID: 648
	// (get) Token: 0x060008FD RID: 2301 RVA: 0x00008D70 File Offset: 0x00006F70
	// (set) Token: 0x060008FE RID: 2302 RVA: 0x00008D7D File Offset: 0x00006F7D
	public Font Font_0
	{
		get
		{
			return this.gcontrol0_0.Font;
		}
		set
		{
			this.gcontrol0_0.Font = value;
		}
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x00008D8B File Offset: 0x00006F8B
	internal void method_0(CancelEventArgs cancelEventArgs_0)
	{
		if (this.eventHandler_2 != null)
		{
			this.eventHandler_2(this, cancelEventArgs_0);
		}
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x00008DA2 File Offset: 0x00006FA2
	public void method_1()
	{
		this.gcontrol0_0.toolTip_0.Hide(this.gcontrol0_0);
		base.Close();
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x0003D350 File Offset: 0x0003B550
	internal void method_2()
	{
		this.toolStripControlHost_0.Size = this.gcontrol0_0.Size;
		base.Size = new Size(this.gcontrol0_0.Size.Width + 4, this.gcontrol0_0.Size.Height + 4);
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00008DC0 File Offset: 0x00006FC0
	public virtual void vmethod_0()
	{
		this.gcontrol0_0.vmethod_0();
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x00008DCD File Offset: 0x00006FCD
	public void method_3(int int_1)
	{
		this.gcontrol0_0.method_11(int_1);
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x00008DDB File Offset: 0x00006FDB
	internal void method_4(GEventArgs6 geventArgs6_0)
	{
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, geventArgs6_0);
		}
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x00008DF2 File Offset: 0x00006FF2
	public void method_5(GEventArgs7 geventArgs7_0)
	{
		if (this.eventHandler_1 != null)
		{
			this.eventHandler_1(this, geventArgs7_0);
		}
	}

	// Token: 0x17000289 RID: 649
	// (get) Token: 0x06000906 RID: 2310 RVA: 0x00008E09 File Offset: 0x00007009
	public GControl0 GControl0_0
	{
		get
		{
			return this.gcontrol0_0;
		}
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00008E11 File Offset: 0x00007011
	public void method_6(bool bool_0)
	{
		this.GControl0_0.method_4(bool_0);
	}

	// Token: 0x1700028A RID: 650
	// (get) Token: 0x06000908 RID: 2312 RVA: 0x00008E1F File Offset: 0x0000701F
	// (set) Token: 0x06000909 RID: 2313 RVA: 0x00008E2C File Offset: 0x0000702C
	public Size Size_1
	{
		get
		{
			return this.GControl0_0.MinimumSize;
		}
		set
		{
			this.GControl0_0.MinimumSize = value;
		}
	}

	// Token: 0x1700028B RID: 651
	// (get) Token: 0x0600090A RID: 2314 RVA: 0x00008E3A File Offset: 0x0000703A
	// (set) Token: 0x0600090B RID: 2315 RVA: 0x00008E47 File Offset: 0x00007047
	public ImageList ImageList_0
	{
		get
		{
			return this.GControl0_0.ImageList_0;
		}
		set
		{
			this.GControl0_0.ImageList_0 = value;
		}
	}

	// Token: 0x1700028C RID: 652
	// (get) Token: 0x0600090C RID: 2316 RVA: 0x00008E55 File Offset: 0x00007055
	// (set) Token: 0x0600090D RID: 2317 RVA: 0x00008E62 File Offset: 0x00007062
	public int Int32_2
	{
		get
		{
			return this.GControl0_0.Int32_2;
		}
		set
		{
			this.GControl0_0.Int32_2 = value;
		}
	}

	// Token: 0x1700028D RID: 653
	// (get) Token: 0x0600090E RID: 2318 RVA: 0x00008E70 File Offset: 0x00007070
	// (set) Token: 0x0600090F RID: 2319 RVA: 0x00008E7D File Offset: 0x0000707D
	public ToolTip ToolTip_0
	{
		get
		{
			return this.GControl0_0.toolTip_0;
		}
		set
		{
			this.GControl0_0.toolTip_0 = value;
		}
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x00008E8B File Offset: 0x0000708B
	protected virtual void Dispose(bool disposing)
	{
		base.Dispose(disposing);
		if (this.gcontrol0_0 != null && !this.gcontrol0_0.IsDisposed)
		{
			this.gcontrol0_0.Dispose();
		}
	}

	// Token: 0x0400048E RID: 1166
	private GControl0 gcontrol0_0;

	// Token: 0x0400048F RID: 1167
	public ToolStripControlHost toolStripControlHost_0;

	// Token: 0x04000490 RID: 1168
	[CompilerGenerated]
	private GClass86 gclass86_0;

	// Token: 0x04000491 RID: 1169
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000492 RID: 1170
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000493 RID: 1171
	[CompilerGenerated]
	private EventHandler<GEventArgs6> eventHandler_0;

	// Token: 0x04000494 RID: 1172
	[CompilerGenerated]
	private EventHandler<GEventArgs7> eventHandler_1;

	// Token: 0x04000495 RID: 1173
	[CompilerGenerated]
	private EventHandler<CancelEventArgs> eventHandler_2;
}
