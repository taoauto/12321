﻿// Token: 0x0200027E RID: 638
public partial class SQLite : global::System.Windows.Forms.Form
{
	// Token: 0x060023FA RID: 9210 RVA: 0x0010617C File Offset: 0x0010437C
	private void InitializeComponent()
	{
		this.button1 = new global::System.Windows.Forms.Button();
		this.button2 = new global::System.Windows.Forms.Button();
		this.button3 = new global::System.Windows.Forms.Button();
		base.SuspendLayout();
		this.button1.Location = new global::System.Drawing.Point(285, 125);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(141, 77);
		this.button1.TabIndex = 0;
		this.button1.Text = "button1";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.button2.Location = new global::System.Drawing.Point(308, 277);
		this.button2.Name = "button2";
		this.button2.Size = new global::System.Drawing.Size(141, 77);
		this.button2.TabIndex = 1;
		this.button2.Text = "button2";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += new global::System.EventHandler(this.button2_Click);
		this.button3.Location = new global::System.Drawing.Point(588, 208);
		this.button3.Name = "button3";
		this.button3.Size = new global::System.Drawing.Size(141, 77);
		this.button3.TabIndex = 2;
		this.button3.Text = "Save";
		this.button3.UseVisualStyleBackColor = true;
		this.button3.Click += new global::System.EventHandler(this.button3_Click);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(800, 450);
		base.Controls.Add(this.button3);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.button1);
		base.Name = "SQLite";
		this.Text = "SQLite";
		base.Load += new global::System.EventHandler(this.SQLite_Load);
		base.ResumeLayout(false);
	}

	// Token: 0x040017AE RID: 6062
	private global::System.Windows.Forms.Button button1;

	// Token: 0x040017AF RID: 6063
	private global::System.Windows.Forms.Button button2;

	// Token: 0x040017B0 RID: 6064
	private global::System.Windows.Forms.Button button3;
}
