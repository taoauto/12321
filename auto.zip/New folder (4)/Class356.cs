﻿using System;

// Token: 0x0200029C RID: 668
internal class Class356
{
	// Token: 0x17000792 RID: 1938
	// (get) Token: 0x060024A5 RID: 9381 RVA: 0x0001BCAD File Offset: 0x00019EAD
	public static string String_0
	{
		get
		{
			return "Quỷ Thị";
		}
	}

	// Token: 0x04001889 RID: 6281
	public static int int_0 = 738;

	// Token: 0x0400188A RID: 6282
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 248,
		Int32_1 = 154,
		Int32_2 = Class356.int_0,
		String_2 = "Thích Dẫn Giang"
	};
}
