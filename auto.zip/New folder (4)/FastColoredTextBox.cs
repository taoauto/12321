﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using Microsoft.Win32;

// Token: 0x020000DB RID: 219
public class FastColoredTextBox : UserControl, ISupportInitialize
{
	// Token: 0x06000A26 RID: 2598 RVA: 0x00041C6C File Offset: 0x0003FE6C
	public FastColoredTextBox()
	{
		TypeDescriptionProvider provider = TypeDescriptor.GetProvider(base.GetType());
		if (provider.GetType().GetField("Provider", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(provider).GetType() != typeof(Class118))
		{
			TypeDescriptor.AddProvider(new Class118(base.GetType()), base.GetType());
		}
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this.Font = new Font(FontFamily.GenericMonospace, 9.75f);
		this.vmethod_7(this.vmethod_6());
		if (this.gclass99_0.Count == 0)
		{
			this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.gclass99_0.vmethod_0());
		}
		this.gclass86_7 = new GClass86(this)
		{
			GStruct2_0 = new GStruct2(0, 0)
		};
		this.Cursor = Cursors.IBeam;
		this.BackColor = Color.White;
		this.Color_4 = Color.Teal;
		this.Color_5 = Color.WhiteSmoke;
		this.Color_9 = Color.Silver;
		this.Color_10 = Color.Green;
		this.Color_2 = Color.Transparent;
		this.Color_3 = Color.Transparent;
		this.Boolean_14 = true;
		this.Boolean_10 = true;
		this.Int32_5 = 4;
		this.GClass88_1 = new GClass89(Brushes.Gray, null, FontStyle.Regular);
		this.Color_11 = Color.Blue;
		this.GClass91_0 = new GClass91(new SolidBrush(Color.FromArgb(80, Color.Lime)));
		this.GClass91_1 = new GClass91(new SolidBrush(Color.FromArgb(60, Color.Red)));
		this.Int32_10 = 100;
		this.Int32_11 = 100;
		this.Boolean_16 = false;
		this.Char_1 = '\0';
		this.Char_2 = '\0';
		this.Char_3 = '\0';
		this.Char_4 = '\0';
		this.GClass98_0 = new GClass98(this);
		this.genum20_0 = GEnum20.Custom;
		this.Int32_9 = 0;
		this.bool_10 = true;
		this.dateTime_0 = DateTime.Now;
		this.Boolean_18 = true;
		this.Boolean_19 = true;
		this.String_1 = "//";
		this.uint_0 = 1U;
		this.bool_9 = true;
		this.bool_16 = true;
		this.Boolean_3 = true;
		this.Boolean_4 = true;
		this.bool_1 = true;
		this.Color_8 = Color.Black;
		this.Boolean_12 = false;
		this.Padding_0 = new Padding(0, 0, 0, 0);
		this.Color_6 = Color.Transparent;
		this.Color_7 = Color.FromArgb(100, 180, 180, 180);
		this.bool_12 = true;
		this.AllowDrop = true;
		this.GEnum13_0 = GEnum13.Strategy1;
		this.Boolean_2 = false;
		this.gclass56_0 = new GClass57(this);
		this.Color_0 = Color.PowderBlue;
		this.ToolTip_0 = new ToolTip();
		this.timer_2.Interval = 500;
		this.gclass77_0 = new GClass77(this);
		this.Boolean_24 = true;
		this.genum15_0 = GEnum15.None;
		this.color_9 = Color.Black;
		this.gclass84_0 = new GClass84(this);
		this.GClass79_0 = new GClass79();
		this.GClass79_0.vmethod_0();
		this.Boolean_1 = true;
		this.Dictionary_0 = new Dictionary<int, int>();
		this.Boolean_0 = false;
		this.String_6 = "^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\r\n^\\s*(case|default)\\s*[^:]*(?<range>:)\\s*(?<range>[^;]+);";
		this.Boolean_28 = true;
		this.Boolean_6 = true;
		this.GClass76_0 = new GClass76();
		base.AutoScroll = true;
		this.timer_0.Tick += this.timer_0_Tick;
		this.timer_1.Tick += this.timer_1_Tick;
		this.timer_2.Tick += this.timer_2_Tick;
		this.timer_3.Tick += this.timer_3_Tick;
	}

	// Token: 0x170002C2 RID: 706
	// (get) Token: 0x06000A27 RID: 2599 RVA: 0x00009A41 File Offset: 0x00007C41
	// (set) Token: 0x06000A28 RID: 2600 RVA: 0x00009A49 File Offset: 0x00007C49
	public char[] Char_0
	{
		get
		{
			return this.char_0;
		}
		set
		{
			this.char_0 = value;
		}
	}

	// Token: 0x170002C3 RID: 707
	// (get) Token: 0x06000A29 RID: 2601 RVA: 0x00009A52 File Offset: 0x00007C52
	// (set) Token: 0x06000A2A RID: 2602 RVA: 0x00009A5A File Offset: 0x00007C5A
	[DefaultValue(false)]
	[Description("AutoComplete brackets.")]
	public bool Boolean_0 { get; set; }

	// Token: 0x170002C4 RID: 708
	// (get) Token: 0x06000A2B RID: 2603 RVA: 0x00009A63 File Offset: 0x00007C63
	// (set) Token: 0x06000A2C RID: 2604 RVA: 0x00009A6B File Offset: 0x00007C6B
	[TypeConverter(typeof(ExpandableObjectConverter))]
	[Browsable(true)]
	[Description("Colors of some service visual markers.")]
	public GClass76 GClass76_0 { get; set; }

	// Token: 0x170002C5 RID: 709
	// (get) Token: 0x06000A2D RID: 2605 RVA: 0x00009A74 File Offset: 0x00007C74
	// (set) Token: 0x06000A2E RID: 2606 RVA: 0x00009A7C File Offset: 0x00007C7C
	[Browsable(false)]
	public Dictionary<int, int> Dictionary_0 { get; private set; }

	// Token: 0x170002C6 RID: 710
	// (get) Token: 0x06000A2F RID: 2607 RVA: 0x00009A85 File Offset: 0x00007C85
	// (set) Token: 0x06000A30 RID: 2608 RVA: 0x00009A8D File Offset: 0x00007C8D
	[DefaultValue(typeof(GEnum14), "Strategy1")]
	[Description("Strategy of search of brackets to highlighting.")]
	public GEnum14 GEnum14_0 { get; set; }

	// Token: 0x170002C7 RID: 711
	// (get) Token: 0x06000A31 RID: 2609 RVA: 0x00009A96 File Offset: 0x00007C96
	// (set) Token: 0x06000A32 RID: 2610 RVA: 0x00009A9E File Offset: 0x00007C9E
	[DefaultValue(true)]
	[Description("Automatically shifts secondary wordwrap lines on the shift amount of the first line.")]
	public bool Boolean_1 { get; set; }

	// Token: 0x170002C8 RID: 712
	// (get) Token: 0x06000A33 RID: 2611 RVA: 0x00009AA7 File Offset: 0x00007CA7
	// (set) Token: 0x06000A34 RID: 2612 RVA: 0x00009AAF File Offset: 0x00007CAF
	[DefaultValue(0)]
	[Description("Indent of secondary wordwrap lines (in chars).")]
	public int Int32_0 { get; set; }

	// Token: 0x170002C9 RID: 713
	// (get) Token: 0x06000A35 RID: 2613 RVA: 0x00009AB8 File Offset: 0x00007CB8
	[Browsable(false)]
	public GClass84 GClass84_0
	{
		get
		{
			return this.gclass84_0;
		}
	}

	// Token: 0x170002CA RID: 714
	// (get) Token: 0x06000A36 RID: 2614 RVA: 0x00009AC0 File Offset: 0x00007CC0
	// (set) Token: 0x06000A37 RID: 2615 RVA: 0x00009AC8 File Offset: 0x00007CC8
	[DefaultValue(true)]
	[Description("Allows drag and drop")]
	public virtual bool AllowDrop
	{
		get
		{
			return base.AllowDrop;
		}
		set
		{
			base.AllowDrop = value;
		}
	}

	// Token: 0x170002CB RID: 715
	// (get) Token: 0x06000A38 RID: 2616 RVA: 0x00009AD1 File Offset: 0x00007CD1
	// (set) Token: 0x06000A39 RID: 2617 RVA: 0x00009AD9 File Offset: 0x00007CD9
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	public GClass77 GClass77_0
	{
		get
		{
			return this.gclass77_0;
		}
		set
		{
			this.gclass77_0 = value;
		}
	}

	// Token: 0x170002CC RID: 716
	// (get) Token: 0x06000A3A RID: 2618 RVA: 0x00009AE2 File Offset: 0x00007CE2
	// (set) Token: 0x06000A3B RID: 2619 RVA: 0x00009AEF File Offset: 0x00007CEF
	[Browsable(true)]
	[DefaultValue(500)]
	[Description("Delay(ms) of ToolTip.")]
	public int Int32_1
	{
		get
		{
			return this.timer_2.Interval;
		}
		set
		{
			this.timer_2.Interval = value;
		}
	}

	// Token: 0x170002CD RID: 717
	// (get) Token: 0x06000A3C RID: 2620 RVA: 0x00009AFD File Offset: 0x00007CFD
	// (set) Token: 0x06000A3D RID: 2621 RVA: 0x00009B05 File Offset: 0x00007D05
	[Browsable(true)]
	[Description("ToolTip component.")]
	public ToolTip ToolTip_0 { get; set; }

	// Token: 0x170002CE RID: 718
	// (get) Token: 0x06000A3E RID: 2622 RVA: 0x00009B0E File Offset: 0x00007D0E
	// (set) Token: 0x06000A3F RID: 2623 RVA: 0x00009B16 File Offset: 0x00007D16
	[Browsable(true)]
	[DefaultValue(typeof(Color), "PowderBlue")]
	[Description("Color of bookmarks.")]
	public Color Color_0 { get; set; }

	// Token: 0x170002CF RID: 719
	// (get) Token: 0x06000A40 RID: 2624 RVA: 0x00009B1F File Offset: 0x00007D1F
	// (set) Token: 0x06000A41 RID: 2625 RVA: 0x00009B27 File Offset: 0x00007D27
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public GClass56 GClass56_0
	{
		get
		{
			return this.gclass56_0;
		}
		set
		{
			this.gclass56_0 = value;
		}
	}

	// Token: 0x170002D0 RID: 720
	// (get) Token: 0x06000A42 RID: 2626 RVA: 0x00009B30 File Offset: 0x00007D30
	// (set) Token: 0x06000A43 RID: 2627 RVA: 0x00009B38 File Offset: 0x00007D38
	[DefaultValue(false)]
	[Description("Enables virtual spaces.")]
	public bool Boolean_2 { get; set; }

	// Token: 0x170002D1 RID: 721
	// (get) Token: 0x06000A44 RID: 2628 RVA: 0x00009B41 File Offset: 0x00007D41
	// (set) Token: 0x06000A45 RID: 2629 RVA: 0x00009B49 File Offset: 0x00007D49
	[DefaultValue(GEnum13.Strategy1)]
	[Description("Strategy of search of end of folding block.")]
	public GEnum13 GEnum13_0 { get; set; }

	// Token: 0x170002D2 RID: 722
	// (get) Token: 0x06000A46 RID: 2630 RVA: 0x00009B52 File Offset: 0x00007D52
	// (set) Token: 0x06000A47 RID: 2631 RVA: 0x00009B5A File Offset: 0x00007D5A
	[DefaultValue(true)]
	[Description("Indicates if tab characters are accepted as input.")]
	public bool Boolean_3 { get; set; }

	// Token: 0x170002D3 RID: 723
	// (get) Token: 0x06000A48 RID: 2632 RVA: 0x00009B63 File Offset: 0x00007D63
	// (set) Token: 0x06000A49 RID: 2633 RVA: 0x00009B6B File Offset: 0x00007D6B
	[DefaultValue(true)]
	[Description("Indicates if return characters are accepted as input.")]
	public bool Boolean_4 { get; set; }

	// Token: 0x170002D4 RID: 724
	// (get) Token: 0x06000A4A RID: 2634 RVA: 0x00009B74 File Offset: 0x00007D74
	// (set) Token: 0x06000A4B RID: 2635 RVA: 0x00009B7C File Offset: 0x00007D7C
	[DefaultValue(true)]
	[Description("Shows or hides the caret")]
	public bool Boolean_5
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
			this.method_4();
		}
	}

	// Token: 0x170002D5 RID: 725
	// (get) Token: 0x06000A4C RID: 2636 RVA: 0x00009B8B File Offset: 0x00007D8B
	// (set) Token: 0x06000A4D RID: 2637 RVA: 0x00009B93 File Offset: 0x00007D93
	[DefaultValue(true)]
	[Description("Enables caret blinking")]
	public bool Boolean_6 { get; set; }

	// Token: 0x170002D6 RID: 726
	// (get) Token: 0x06000A4E RID: 2638 RVA: 0x00009B9C File Offset: 0x00007D9C
	// (set) Token: 0x06000A4F RID: 2639 RVA: 0x00009BA4 File Offset: 0x00007DA4
	[DefaultValue(false)]
	public bool Boolean_7 { get; set; }

	// Token: 0x170002D7 RID: 727
	// (get) Token: 0x06000A50 RID: 2640 RVA: 0x00009BAD File Offset: 0x00007DAD
	// (set) Token: 0x06000A51 RID: 2641 RVA: 0x00009BB5 File Offset: 0x00007DB5
	[DefaultValue(typeof(Color), "Black")]
	[Description("Color of border of text area")]
	public Color Color_1
	{
		get
		{
			return this.color_9;
		}
		set
		{
			this.color_9 = value;
			this.method_4();
		}
	}

	// Token: 0x170002D8 RID: 728
	// (get) Token: 0x06000A52 RID: 2642 RVA: 0x00009BC4 File Offset: 0x00007DC4
	// (set) Token: 0x06000A53 RID: 2643 RVA: 0x00009BCC File Offset: 0x00007DCC
	[DefaultValue(typeof(GEnum15), "None")]
	[Description("Type of border of text area")]
	public GEnum15 GEnum15_0
	{
		get
		{
			return this.genum15_0;
		}
		set
		{
			this.genum15_0 = value;
			this.method_4();
		}
	}

	// Token: 0x170002D9 RID: 729
	// (get) Token: 0x06000A54 RID: 2644 RVA: 0x00009BDB File Offset: 0x00007DDB
	// (set) Token: 0x06000A55 RID: 2645 RVA: 0x00009BE3 File Offset: 0x00007DE3
	[DefaultValue(typeof(Color), "Transparent")]
	[Description("Background color for current line. Set to Color.Transparent to hide current line highlighting")]
	public Color Color_2
	{
		get
		{
			return this.color_1;
		}
		set
		{
			this.color_1 = value;
			this.method_4();
		}
	}

	// Token: 0x170002DA RID: 730
	// (get) Token: 0x06000A56 RID: 2646 RVA: 0x00009BF2 File Offset: 0x00007DF2
	// (set) Token: 0x06000A57 RID: 2647 RVA: 0x00009BFA File Offset: 0x00007DFA
	[DefaultValue(typeof(Color), "Transparent")]
	[Description("Background color for highlighting of changed lines. Set to Color.Transparent to hide changed line highlighting")]
	public Color Color_3
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			this.method_4();
		}
	}

	// Token: 0x170002DB RID: 731
	// (get) Token: 0x06000A58 RID: 2648 RVA: 0x00009C09 File Offset: 0x00007E09
	// (set) Token: 0x06000A59 RID: 2649 RVA: 0x00009C11 File Offset: 0x00007E11
	public virtual Color ForeColor
	{
		get
		{
			return base.ForeColor;
		}
		set
		{
			base.ForeColor = value;
			this.gclass99_0.vmethod_1();
			this.method_4();
		}
	}

	// Token: 0x170002DC RID: 732
	// (get) Token: 0x06000A5A RID: 2650 RVA: 0x00009C2B File Offset: 0x00007E2B
	// (set) Token: 0x06000A5B RID: 2651 RVA: 0x00009C33 File Offset: 0x00007E33
	[Browsable(false)]
	public int Int32_2
	{
		get
		{
			return this.int_9;
		}
		set
		{
			this.int_9 = value;
			this.method_10();
			this.vmethod_5();
		}
	}

	// Token: 0x170002DD RID: 733
	// (get) Token: 0x06000A5C RID: 2652 RVA: 0x00009C48 File Offset: 0x00007E48
	// (set) Token: 0x06000A5D RID: 2653 RVA: 0x00009C50 File Offset: 0x00007E50
	[Description("Interval between lines in pixels")]
	[DefaultValue(0)]
	public int Int32_3
	{
		get
		{
			return this.int_12;
		}
		set
		{
			this.int_12 = value;
			this.method_0(this.Font);
			this.method_4();
		}
	}

	// Token: 0x170002DE RID: 734
	// (get) Token: 0x06000A5E RID: 2654 RVA: 0x00009C6B File Offset: 0x00007E6B
	// (set) Token: 0x06000A5F RID: 2655 RVA: 0x00009C73 File Offset: 0x00007E73
	[Browsable(false)]
	public int Int32_4 { get; set; }

	// Token: 0x170002DF RID: 735
	// (get) Token: 0x06000A60 RID: 2656 RVA: 0x00009C7C File Offset: 0x00007E7C
	// (set) Token: 0x06000A61 RID: 2657 RVA: 0x00009C84 File Offset: 0x00007E84
	[DefaultValue(4)]
	[Description("Spaces count for tab")]
	public int Int32_5 { get; set; }

	// Token: 0x170002E0 RID: 736
	// (get) Token: 0x06000A62 RID: 2658 RVA: 0x00009C8D File Offset: 0x00007E8D
	// (set) Token: 0x06000A63 RID: 2659 RVA: 0x00009C95 File Offset: 0x00007E95
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public bool Boolean_8
	{
		get
		{
			return this.bool_4;
		}
		set
		{
			if (!value)
			{
				this.gclass99_0.GClass99.\u202B\u206A\u206B\u200D\u200E\u200C\u200C\u206C\u200D\u206C\u206D\u202D\u206E\u206C\u200C\u206E\u206D\u200C\u202B\u200B\u200F\u206C\u200E\u206A\u202E\u200F\u206F\u200C\u206B\u206D\u202D\u200E\u206A\u206D\u206F\u206E\u202E\u202D\u206C\u200D\u202E();
			}
			this.bool_4 = value;
		}
	}

	// Token: 0x170002E1 RID: 737
	// (get) Token: 0x06000A64 RID: 2660 RVA: 0x00009CAC File Offset: 0x00007EAC
	// (set) Token: 0x06000A65 RID: 2661 RVA: 0x00009CB4 File Offset: 0x00007EB4
	[Browsable(false)]
	public int Int32_6 { get; private set; }

	// Token: 0x170002E2 RID: 738
	// (get) Token: 0x06000A66 RID: 2662 RVA: 0x00009CBD File Offset: 0x00007EBD
	// (set) Token: 0x06000A67 RID: 2663 RVA: 0x00009CC5 File Offset: 0x00007EC5
	[DefaultValue(false)]
	public bool Boolean_9 { get; set; }

	// Token: 0x170002E3 RID: 739
	// (get) Token: 0x06000A68 RID: 2664 RVA: 0x00009CCE File Offset: 0x00007ECE
	// (set) Token: 0x06000A69 RID: 2665 RVA: 0x00009CD6 File Offset: 0x00007ED6
	[DefaultValue(true)]
	[Description("Shows line numbers.")]
	public bool Boolean_10
	{
		get
		{
			return this.bool_18;
		}
		set
		{
			this.bool_18 = value;
			this.method_10();
			this.method_4();
		}
	}

	// Token: 0x170002E4 RID: 740
	// (get) Token: 0x06000A6A RID: 2666 RVA: 0x00009CEB File Offset: 0x00007EEB
	// (set) Token: 0x06000A6B RID: 2667 RVA: 0x00009CF3 File Offset: 0x00007EF3
	[DefaultValue(false)]
	[Description("Shows vertical lines between folding start line and folding end line.")]
	public bool Boolean_11
	{
		get
		{
			return this.bool_17;
		}
		set
		{
			this.bool_17 = value;
			this.method_4();
		}
	}

	// Token: 0x170002E5 RID: 741
	// (get) Token: 0x06000A6C RID: 2668 RVA: 0x000420C0 File Offset: 0x000402C0
	[Browsable(false)]
	public Rectangle Rectangle_0
	{
		get
		{
			int num = this.Int32_7 + this.int_14 * this.Int32_4 + this.Padding_0.Left + 1;
			num = Math.Max(base.ClientSize.Width - this.Padding_0.Right, num);
			int num2 = this.int_8 + this.Padding_0.Top;
			num2 = Math.Max(base.ClientSize.Height - this.Padding_0.Bottom, num2);
			int top = Math.Max(0, this.Padding_0.Top - 1) - base.VerticalScroll.Value;
			return Rectangle.FromLTRB(this.Int32_7 - base.HorizontalScroll.Value - 2 + Math.Max(0, this.Padding_0.Left - 1), top, num - base.HorizontalScroll.Value, num2 - base.VerticalScroll.Value);
		}
	}

	// Token: 0x170002E6 RID: 742
	// (get) Token: 0x06000A6D RID: 2669 RVA: 0x00009D02 File Offset: 0x00007F02
	// (set) Token: 0x06000A6E RID: 2670 RVA: 0x00009D0A File Offset: 0x00007F0A
	[DefaultValue(typeof(Color), "Teal")]
	[Description("Color of line numbers.")]
	public Color Color_4
	{
		get
		{
			return this.color_4;
		}
		set
		{
			this.color_4 = value;
			this.method_4();
		}
	}

	// Token: 0x170002E7 RID: 743
	// (get) Token: 0x06000A6F RID: 2671 RVA: 0x00009D19 File Offset: 0x00007F19
	// (set) Token: 0x06000A70 RID: 2672 RVA: 0x00009D21 File Offset: 0x00007F21
	[DefaultValue(typeof(uint), "1")]
	[Description("Start value of first line number.")]
	public uint UInt32_0
	{
		get
		{
			return this.uint_0;
		}
		set
		{
			this.uint_0 = value;
			this.bool_10 = true;
			this.method_4();
		}
	}

	// Token: 0x170002E8 RID: 744
	// (get) Token: 0x06000A71 RID: 2673 RVA: 0x00009D37 File Offset: 0x00007F37
	// (set) Token: 0x06000A72 RID: 2674 RVA: 0x00009D3F File Offset: 0x00007F3F
	[DefaultValue(typeof(GClass82), null)]
	[Description("Format of string displayed when ShowLineNumbers = true")]
	public GClass82 GClass82_0
	{
		get
		{
			return this.gclass82_0;
		}
		set
		{
			this.gclass82_0 = value;
			this.bool_10 = true;
			this.method_4();
		}
	}

	// Token: 0x170002E9 RID: 745
	// (get) Token: 0x06000A73 RID: 2675 RVA: 0x00009D55 File Offset: 0x00007F55
	// (set) Token: 0x06000A74 RID: 2676 RVA: 0x00009D5D File Offset: 0x00007F5D
	[DefaultValue(typeof(Color), "WhiteSmoke")]
	[Description("Background color of indent area")]
	public Color Color_5
	{
		get
		{
			return this.color_3;
		}
		set
		{
			this.color_3 = value;
			this.method_4();
		}
	}

	// Token: 0x170002EA RID: 746
	// (get) Token: 0x06000A75 RID: 2677 RVA: 0x00009D6C File Offset: 0x00007F6C
	// (set) Token: 0x06000A76 RID: 2678 RVA: 0x00009D74 File Offset: 0x00007F74
	[DefaultValue(typeof(Color), "Transparent")]
	[Description("Background color of padding area")]
	public Color Color_6
	{
		get
		{
			return this.color_5;
		}
		set
		{
			this.color_5 = value;
			this.method_4();
		}
	}

	// Token: 0x170002EB RID: 747
	// (get) Token: 0x06000A77 RID: 2679 RVA: 0x00009D83 File Offset: 0x00007F83
	// (set) Token: 0x06000A78 RID: 2680 RVA: 0x00009D8B File Offset: 0x00007F8B
	[DefaultValue(typeof(Color), "100;180;180;180")]
	[Description("Color of disabled component")]
	public Color Color_7 { get; set; }

	// Token: 0x170002EC RID: 748
	// (get) Token: 0x06000A79 RID: 2681 RVA: 0x00009D94 File Offset: 0x00007F94
	// (set) Token: 0x06000A7A RID: 2682 RVA: 0x00009D9C File Offset: 0x00007F9C
	[DefaultValue(typeof(Color), "Black")]
	[Description("Color of caret.")]
	public Color Color_8 { get; set; }

	// Token: 0x170002ED RID: 749
	// (get) Token: 0x06000A7B RID: 2683 RVA: 0x00009DA5 File Offset: 0x00007FA5
	// (set) Token: 0x06000A7C RID: 2684 RVA: 0x00009DAD File Offset: 0x00007FAD
	[DefaultValue(false)]
	[Description("Wide caret.")]
	public bool Boolean_12 { get; set; }

	// Token: 0x170002EE RID: 750
	// (get) Token: 0x06000A7D RID: 2685 RVA: 0x00009DB6 File Offset: 0x00007FB6
	// (set) Token: 0x06000A7E RID: 2686 RVA: 0x00009DBE File Offset: 0x00007FBE
	[DefaultValue(typeof(Color), "Silver")]
	[Description("Color of service lines (folding lines, borders of blocks etc.)")]
	public Color Color_9
	{
		get
		{
			return this.color_7;
		}
		set
		{
			this.color_7 = value;
			this.method_4();
		}
	}

	// Token: 0x170002EF RID: 751
	// (get) Token: 0x06000A7F RID: 2687 RVA: 0x00009DCD File Offset: 0x00007FCD
	// (set) Token: 0x06000A80 RID: 2688 RVA: 0x00009DD5 File Offset: 0x00007FD5
	[Browsable(true)]
	[Description("Paddings of text area.")]
	public Padding Padding_0 { get; set; }

	// Token: 0x170002F0 RID: 752
	// (get) Token: 0x06000A81 RID: 2689 RVA: 0x000096BD File Offset: 0x000078BD
	// (set) Token: 0x06000A82 RID: 2690 RVA: 0x000096BD File Offset: 0x000078BD
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public Padding Padding_1
	{
		get
		{
			throw new NotImplementedException();
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x170002F1 RID: 753
	// (get) Token: 0x06000A83 RID: 2691 RVA: 0x000096BD File Offset: 0x000078BD
	// (set) Token: 0x06000A84 RID: 2692 RVA: 0x000096BD File Offset: 0x000078BD
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public bool Boolean_13
	{
		get
		{
			throw new NotImplementedException();
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x170002F2 RID: 754
	// (get) Token: 0x06000A85 RID: 2693 RVA: 0x00009DDE File Offset: 0x00007FDE
	// (set) Token: 0x06000A86 RID: 2694 RVA: 0x00009DE6 File Offset: 0x00007FE6
	[DefaultValue(typeof(Color), "Green")]
	[Description("Color of folding area indicator.")]
	public Color Color_10
	{
		get
		{
			return this.color_2;
		}
		set
		{
			this.color_2 = value;
			this.method_4();
		}
	}

	// Token: 0x170002F3 RID: 755
	// (get) Token: 0x06000A87 RID: 2695 RVA: 0x00009DF5 File Offset: 0x00007FF5
	// (set) Token: 0x06000A88 RID: 2696 RVA: 0x00009DFD File Offset: 0x00007FFD
	[DefaultValue(true)]
	[Description("Enables folding indicator (left vertical line between folding bounds)")]
	public bool Boolean_14
	{
		get
		{
			return this.bool_3;
		}
		set
		{
			this.bool_3 = value;
			this.method_4();
		}
	}

	// Token: 0x170002F4 RID: 756
	// (get) Token: 0x06000A89 RID: 2697 RVA: 0x00009E0C File Offset: 0x0000800C
	// (set) Token: 0x06000A8A RID: 2698 RVA: 0x00009E14 File Offset: 0x00008014
	[Browsable(false)]
	[Description("Left distance to text beginning.")]
	public int Int32_7 { get; private set; }

	// Token: 0x170002F5 RID: 757
	// (get) Token: 0x06000A8B RID: 2699 RVA: 0x00009E1D File Offset: 0x0000801D
	// (set) Token: 0x06000A8C RID: 2700 RVA: 0x00009E25 File Offset: 0x00008025
	[DefaultValue(0)]
	[Description("Width of left service area (in pixels)")]
	public int Int32_8
	{
		get
		{
			return this.int_11;
		}
		set
		{
			this.int_11 = value;
			this.method_4();
		}
	}

	// Token: 0x170002F6 RID: 758
	// (get) Token: 0x06000A8D RID: 2701 RVA: 0x00009E34 File Offset: 0x00008034
	// (set) Token: 0x06000A8E RID: 2702 RVA: 0x00009E3C File Offset: 0x0000803C
	[DefaultValue(0)]
	[Description("This property draws vertical line after defined char position. Set to 0 for disable drawing of vertical line.")]
	public int Int32_9
	{
		get
		{
			return this.int_15;
		}
		set
		{
			this.int_15 = value;
			this.method_4();
		}
	}

	// Token: 0x170002F7 RID: 759
	// (get) Token: 0x06000A8F RID: 2703 RVA: 0x00009E4B File Offset: 0x0000804B
	[Browsable(false)]
	public GClass87[] GClass87_0
	{
		get
		{
			return this.gclass99_0.gclass87_0;
		}
	}

	// Token: 0x170002F8 RID: 760
	// (get) Token: 0x06000A90 RID: 2704 RVA: 0x00009E58 File Offset: 0x00008058
	// (set) Token: 0x06000A91 RID: 2705 RVA: 0x00009E65 File Offset: 0x00008065
	[Description("Here you can change hotkeys for FastColoredTextBox.")]
	[Editor(typeof(Class104), typeof(UITypeEditor))]
	[DefaultValue("Tab=IndentIncrease, Escape=ClearHints, PgUp=GoPageUp, PgDn=GoPageDown, End=GoEnd, Home=GoHome, Left=GoLeft, Up=GoUp, Right=GoRight, Down=GoDown, Ins=ReplaceMode, Del=DeleteCharRight, F3=FindNext, Shift+Tab=IndentDecrease, Shift+PgUp=GoPageUpWithSelection, Shift+PgDn=GoPageDownWithSelection, Shift+End=GoEndWithSelection, Shift+Home=GoHomeWithSelection, Shift+Left=GoLeftWithSelection, Shift+Up=GoUpWithSelection, Shift+Right=GoRightWithSelection, Shift+Down=GoDownWithSelection, Shift+Ins=Paste, Shift+Del=Cut, Ctrl+Back=ClearWordLeft, Ctrl+Space=AutocompleteMenu, Ctrl+End=GoLastLine, Ctrl+Home=GoFirstLine, Ctrl+Left=GoWordLeft, Ctrl+Up=ScrollUp, Ctrl+Right=GoWordRight, Ctrl+Down=ScrollDown, Ctrl+Ins=Copy, Ctrl+Del=ClearWordRight, Ctrl+0=ZoomNormal, Ctrl+A=SelectAll, Ctrl+B=BookmarkLine, Ctrl+C=Copy, Ctrl+E=MacroExecute, Ctrl+F=FindDialog, Ctrl+G=GoToDialog, Ctrl+H=ReplaceDialog, Ctrl+I=AutoIndentChars, Ctrl+M=MacroRecord, Ctrl+N=GoNextBookmark, Ctrl+R=Redo, Ctrl+U=UpperCase, Ctrl+V=Paste, Ctrl+X=Cut, Ctrl+Z=Undo, Ctrl+Add=ZoomIn, Ctrl+Subtract=ZoomOut, Ctrl+OemMinus=NavigateBackward, Ctrl+Shift+End=GoLastLineWithSelection, Ctrl+Shift+Home=GoFirstLineWithSelection, Ctrl+Shift+Left=GoWordLeftWithSelection, Ctrl+Shift+Right=GoWordRightWithSelection, Ctrl+Shift+B=UnbookmarkLine, Ctrl+Shift+C=CommentSelected, Ctrl+Shift+N=GoPrevBookmark, Ctrl+Shift+U=LowerCase, Ctrl+Shift+OemMinus=NavigateForward, Alt+Back=Undo, Alt+Up=MoveSelectedLinesUp, Alt+Down=MoveSelectedLinesDown, Alt+F=FindChar, Alt+Shift+Left=GoLeft_ColumnSelectionMode, Alt+Shift+Up=GoUp_ColumnSelectionMode, Alt+Shift+Right=GoRight_ColumnSelectionMode, Alt+Shift+Down=GoDown_ColumnSelectionMode")]
	public string String_0
	{
		get
		{
			return this.GClass79_0.ToString();
		}
		set
		{
			this.GClass79_0 = GClass79.smethod_0(value);
		}
	}

	// Token: 0x170002F9 RID: 761
	// (get) Token: 0x06000A92 RID: 2706 RVA: 0x00009E73 File Offset: 0x00008073
	// (set) Token: 0x06000A93 RID: 2707 RVA: 0x00009E7B File Offset: 0x0000807B
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass79 GClass79_0 { get; set; }

	// Token: 0x170002FA RID: 762
	// (get) Token: 0x06000A94 RID: 2708 RVA: 0x00009E84 File Offset: 0x00008084
	// (set) Token: 0x06000A95 RID: 2709 RVA: 0x00009E91 File Offset: 0x00008091
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass88 GClass88_0
	{
		get
		{
			return this.gclass99_0.GClass88_0;
		}
		set
		{
			this.gclass99_0.GClass88_0 = value;
		}
	}

	// Token: 0x170002FB RID: 763
	// (get) Token: 0x06000A96 RID: 2710 RVA: 0x00009E9F File Offset: 0x0000809F
	// (set) Token: 0x06000A97 RID: 2711 RVA: 0x00009EA7 File Offset: 0x000080A7
	[Browsable(false)]
	public GClass90 GClass90_0 { get; set; }

	// Token: 0x170002FC RID: 764
	// (get) Token: 0x06000A98 RID: 2712 RVA: 0x00009EB0 File Offset: 0x000080B0
	// (set) Token: 0x06000A99 RID: 2713 RVA: 0x00009EB8 File Offset: 0x000080B8
	[Browsable(false)]
	public GClass88 GClass88_1 { get; set; }

	// Token: 0x170002FD RID: 765
	// (get) Token: 0x06000A9A RID: 2714 RVA: 0x00009EC1 File Offset: 0x000080C1
	// (set) Token: 0x06000A9B RID: 2715 RVA: 0x00009EC9 File Offset: 0x000080C9
	[Browsable(false)]
	public GClass91 GClass91_0 { get; set; }

	// Token: 0x170002FE RID: 766
	// (get) Token: 0x06000A9C RID: 2716 RVA: 0x00009ED2 File Offset: 0x000080D2
	// (set) Token: 0x06000A9D RID: 2717 RVA: 0x00009EDA File Offset: 0x000080DA
	[Browsable(false)]
	public GClass91 GClass91_1 { get; set; }

	// Token: 0x170002FF RID: 767
	// (get) Token: 0x06000A9E RID: 2718 RVA: 0x00009EE3 File Offset: 0x000080E3
	// (set) Token: 0x06000A9F RID: 2719 RVA: 0x00009EEB File Offset: 0x000080EB
	[DefaultValue('\0')]
	[Description("Opening bracket for brackets highlighting. Set to '\\x0' for disable brackets highlighting.")]
	public char Char_1 { get; set; }

	// Token: 0x17000300 RID: 768
	// (get) Token: 0x06000AA0 RID: 2720 RVA: 0x00009EF4 File Offset: 0x000080F4
	// (set) Token: 0x06000AA1 RID: 2721 RVA: 0x00009EFC File Offset: 0x000080FC
	[DefaultValue('\0')]
	[Description("Closing bracket for brackets highlighting. Set to '\\x0' for disable brackets highlighting.")]
	public char Char_2 { get; set; }

	// Token: 0x17000301 RID: 769
	// (get) Token: 0x06000AA2 RID: 2722 RVA: 0x00009F05 File Offset: 0x00008105
	// (set) Token: 0x06000AA3 RID: 2723 RVA: 0x00009F0D File Offset: 0x0000810D
	[DefaultValue('\0')]
	[Description("Alternative opening bracket for brackets highlighting. Set to '\\x0' for disable brackets highlighting.")]
	public char Char_3 { get; set; }

	// Token: 0x17000302 RID: 770
	// (get) Token: 0x06000AA4 RID: 2724 RVA: 0x00009F16 File Offset: 0x00008116
	// (set) Token: 0x06000AA5 RID: 2725 RVA: 0x00009F1E File Offset: 0x0000811E
	[DefaultValue('\0')]
	[Description("Alternative closing bracket for brackets highlighting. Set to '\\x0' for disable brackets highlighting.")]
	public char Char_4 { get; set; }

	// Token: 0x17000303 RID: 771
	// (get) Token: 0x06000AA6 RID: 2726 RVA: 0x00009F27 File Offset: 0x00008127
	// (set) Token: 0x06000AA7 RID: 2727 RVA: 0x00009F2F File Offset: 0x0000812F
	[DefaultValue("//")]
	[Description("Comment line prefix.")]
	public string String_1 { get; set; }

	// Token: 0x17000304 RID: 772
	// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x00009F38 File Offset: 0x00008138
	// (set) Token: 0x06000AA9 RID: 2729 RVA: 0x00009F40 File Offset: 0x00008140
	[DefaultValue(typeof(GEnum12), "ChangedRange")]
	[Description("This property specifies which part of the text will be highlighted as you type.")]
	public GEnum12 GEnum12_0 { get; set; }

	// Token: 0x17000305 RID: 773
	// (get) Token: 0x06000AAA RID: 2730 RVA: 0x000421C4 File Offset: 0x000403C4
	// (set) Token: 0x06000AAB RID: 2731 RVA: 0x00009F49 File Offset: 0x00008149
	[Browsable(false)]
	public bool Boolean_15
	{
		get
		{
			return this.bool_6 && this.GClass86_5.Boolean_2 && !this.GClass86_5.Boolean_0 && this.GClass86_5.GStruct2_0.int_0 < this.gclass99_0[this.GClass86_5.GStruct2_0.int_1].Count;
		}
		set
		{
			this.bool_6 = value;
		}
	}

	// Token: 0x17000306 RID: 774
	// (get) Token: 0x06000AAC RID: 2732 RVA: 0x00009F52 File Offset: 0x00008152
	// (set) Token: 0x06000AAD RID: 2733 RVA: 0x00009F5A File Offset: 0x0000815A
	[Browsable(true)]
	[DefaultValue(false)]
	[Description("Allows text rendering several styles same time.")]
	public bool Boolean_16 { get; set; }

	// Token: 0x17000307 RID: 775
	// (get) Token: 0x06000AAE RID: 2734 RVA: 0x00009F63 File Offset: 0x00008163
	// (set) Token: 0x06000AAF RID: 2735 RVA: 0x00009F70 File Offset: 0x00008170
	[Browsable(true)]
	[DefaultValue(true)]
	[Description("Allows to record macros.")]
	public bool Boolean_17
	{
		get
		{
			return this.gclass84_0.Boolean_0;
		}
		set
		{
			this.gclass84_0.Boolean_0 = value;
		}
	}

	// Token: 0x17000308 RID: 776
	// (get) Token: 0x06000AB0 RID: 2736 RVA: 0x00009F7E File Offset: 0x0000817E
	// (set) Token: 0x06000AB1 RID: 2737 RVA: 0x00009F86 File Offset: 0x00008186
	[DefaultValue(true)]
	[Description("Allows auto indent. Inserts spaces before line chars.")]
	public bool Boolean_18 { get; set; }

	// Token: 0x17000309 RID: 777
	// (get) Token: 0x06000AB2 RID: 2738 RVA: 0x00009F8F File Offset: 0x0000818F
	// (set) Token: 0x06000AB3 RID: 2739 RVA: 0x00009F97 File Offset: 0x00008197
	[DefaultValue(true)]
	[Description("Does autoindenting in existing lines. It works only if AutoIndent is True.")]
	public bool Boolean_19 { get; set; }

	// Token: 0x1700030A RID: 778
	// (get) Token: 0x06000AB4 RID: 2740 RVA: 0x00009FA0 File Offset: 0x000081A0
	// (set) Token: 0x06000AB5 RID: 2741 RVA: 0x00009FAD File Offset: 0x000081AD
	[Browsable(true)]
	[DefaultValue(100)]
	[Description("Minimal delay(ms) for delayed events (except TextChangedDelayed).")]
	public int Int32_10
	{
		get
		{
			return this.timer_0.Interval;
		}
		set
		{
			this.timer_0.Interval = value;
		}
	}

	// Token: 0x1700030B RID: 779
	// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x00009FBB File Offset: 0x000081BB
	// (set) Token: 0x06000AB7 RID: 2743 RVA: 0x00009FC8 File Offset: 0x000081C8
	[DefaultValue(100)]
	[Description("Minimal delay(ms) for TextChangedDelayed event.")]
	[Browsable(true)]
	public int Int32_11
	{
		get
		{
			return this.timer_1.Interval;
		}
		set
		{
			this.timer_1.Interval = value;
		}
	}

	// Token: 0x1700030C RID: 780
	// (get) Token: 0x06000AB8 RID: 2744 RVA: 0x00009FD6 File Offset: 0x000081D6
	// (set) Token: 0x06000AB9 RID: 2745 RVA: 0x00009FDE File Offset: 0x000081DE
	[DefaultValue(typeof(GEnum20), "Custom")]
	[Description("Language for highlighting by built-in highlighter.")]
	[Browsable(true)]
	public GEnum20 GEnum20_0
	{
		get
		{
			return this.genum20_0;
		}
		set
		{
			this.genum20_0 = value;
			if (this.GClass98_0 != null)
			{
				this.GClass98_0.method_10(this.genum20_0);
			}
			this.method_4();
		}
	}

	// Token: 0x1700030D RID: 781
	// (get) Token: 0x06000ABA RID: 2746 RVA: 0x0000A006 File Offset: 0x00008206
	// (set) Token: 0x06000ABB RID: 2747 RVA: 0x0000A00E File Offset: 0x0000820E
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass98 GClass98_0 { get; set; }

	// Token: 0x1700030E RID: 782
	// (get) Token: 0x06000ABC RID: 2748 RVA: 0x0000A017 File Offset: 0x00008217
	// (set) Token: 0x06000ABD RID: 2749 RVA: 0x0000A01F File Offset: 0x0000821F
	[DefaultValue(null)]
	[Browsable(true)]
	[Description("XML file with description of syntax highlighting. This property works only with Language == Language.Custom.")]
	[Editor(typeof(FileNameEditor), typeof(UITypeEditor))]
	public string String_2
	{
		get
		{
			return this.string_0;
		}
		set
		{
			this.string_0 = value;
			this.method_4();
		}
	}

	// Token: 0x1700030F RID: 783
	// (get) Token: 0x06000ABE RID: 2750 RVA: 0x0000A02E File Offset: 0x0000822E
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass86 GClass86_0
	{
		get
		{
			return this.gclass86_1;
		}
	}

	// Token: 0x17000310 RID: 784
	// (get) Token: 0x06000ABF RID: 2751 RVA: 0x0000A036 File Offset: 0x00008236
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass86 GClass86_1
	{
		get
		{
			return this.gclass86_3;
		}
	}

	// Token: 0x17000311 RID: 785
	// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x0000A03E File Offset: 0x0000823E
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass86 GClass86_2
	{
		get
		{
			return this.gclass86_2;
		}
	}

	// Token: 0x17000312 RID: 786
	// (get) Token: 0x06000AC1 RID: 2753 RVA: 0x0000A046 File Offset: 0x00008246
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass86 GClass86_3
	{
		get
		{
			return this.gclass86_4;
		}
	}

	// Token: 0x17000313 RID: 787
	// (get) Token: 0x06000AC2 RID: 2754 RVA: 0x0000A04E File Offset: 0x0000824E
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public int Int32_12
	{
		get
		{
			return this.int_16;
		}
	}

	// Token: 0x17000314 RID: 788
	// (get) Token: 0x06000AC3 RID: 2755 RVA: 0x0000A056 File Offset: 0x00008256
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public int Int32_13
	{
		get
		{
			return this.int_10;
		}
	}

	// Token: 0x17000315 RID: 789
	// (get) Token: 0x06000AC4 RID: 2756 RVA: 0x0000A05E File Offset: 0x0000825E
	// (set) Token: 0x06000AC5 RID: 2757 RVA: 0x0000A066 File Offset: 0x00008266
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public GClass99 GClass99_0
	{
		get
		{
			return this.gclass99_0;
		}
		set
		{
			this.vmethod_7(value);
		}
	}

	// Token: 0x17000316 RID: 790
	// (get) Token: 0x06000AC6 RID: 2758 RVA: 0x0000A06F File Offset: 0x0000826F
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public bool Boolean_20
	{
		get
		{
			return this.FastColoredTextBox_0 != null;
		}
	}

	// Token: 0x17000317 RID: 791
	// (get) Token: 0x06000AC7 RID: 2759 RVA: 0x0000A07A File Offset: 0x0000827A
	// (set) Token: 0x06000AC8 RID: 2760 RVA: 0x00042228 File Offset: 0x00040428
	[Browsable(true)]
	[DefaultValue(null)]
	[Description("Allows to get text from other FastColoredTextBox.")]
	public FastColoredTextBox FastColoredTextBox_0
	{
		get
		{
			return this.fastColoredTextBox_0;
		}
		set
		{
			if (value == this.fastColoredTextBox_0)
			{
				return;
			}
			this.fastColoredTextBox_0 = value;
			if (this.fastColoredTextBox_0 == null)
			{
				this.vmethod_7(this.vmethod_6());
				this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.GClass99_0.vmethod_0());
				this.Boolean_8 = false;
			}
			else
			{
				this.vmethod_7(this.FastColoredTextBox_0.GClass99_0);
				this.bool_4 = false;
			}
			this.method_4();
		}
	}

	// Token: 0x17000318 RID: 792
	// (get) Token: 0x06000AC9 RID: 2761 RVA: 0x00042298 File Offset: 0x00040498
	[Browsable(false)]
	public GClass86 GClass86_4
	{
		get
		{
			if (this.gclass86_6 != null)
			{
				return this.gclass86_6;
			}
			return this.method_97(this.method_84(new Point(this.Int32_7, 0)), this.method_84(new Point(base.ClientSize.Width, base.ClientSize.Height)));
		}
	}

	// Token: 0x17000319 RID: 793
	// (get) Token: 0x06000ACA RID: 2762 RVA: 0x0000A082 File Offset: 0x00008282
	// (set) Token: 0x06000ACB RID: 2763 RVA: 0x000422F4 File Offset: 0x000404F4
	[Browsable(false)]
	public GClass86 GClass86_5
	{
		get
		{
			return this.gclass86_7;
		}
		set
		{
			if (value == this.gclass86_7)
			{
				return;
			}
			this.gclass86_7.method_38();
			this.gclass86_7.GStruct2_0 = value.GStruct2_0;
			this.gclass86_7.GStruct2_1 = value.GStruct2_1;
			this.gclass86_7.method_39();
			this.method_4();
		}
	}

	// Token: 0x1700031A RID: 794
	// (get) Token: 0x06000ACC RID: 2764 RVA: 0x0000A08A File Offset: 0x0000828A
	// (set) Token: 0x06000ACD RID: 2765 RVA: 0x0000A092 File Offset: 0x00008292
	[DefaultValue(typeof(Color), "White")]
	[Description("Background color.")]
	public virtual Color BackColor
	{
		get
		{
			return base.BackColor;
		}
		set
		{
			base.BackColor = value;
		}
	}

	// Token: 0x1700031B RID: 795
	// (get) Token: 0x06000ACE RID: 2766 RVA: 0x0000A09B File Offset: 0x0000829B
	// (set) Token: 0x06000ACF RID: 2767 RVA: 0x0000A0A3 File Offset: 0x000082A3
	[Browsable(false)]
	public Brush Brush_0
	{
		get
		{
			return this.brush_0;
		}
		set
		{
			this.brush_0 = value;
			this.method_4();
		}
	}

	// Token: 0x1700031C RID: 796
	// (get) Token: 0x06000AD0 RID: 2768 RVA: 0x0000A0B2 File Offset: 0x000082B2
	// (set) Token: 0x06000AD1 RID: 2769 RVA: 0x0000A0BA File Offset: 0x000082BA
	[Browsable(true)]
	[DefaultValue(true)]
	[Description("Scollbars visibility.")]
	public bool Boolean_21
	{
		get
		{
			return this.bool_16;
		}
		set
		{
			if (value == this.bool_16)
			{
				return;
			}
			this.bool_16 = value;
			this.bool_10 = true;
			this.method_4();
		}
	}

	// Token: 0x1700031D RID: 797
	// (get) Token: 0x06000AD2 RID: 2770 RVA: 0x0000A0DA File Offset: 0x000082DA
	// (set) Token: 0x06000AD3 RID: 2771 RVA: 0x0004234C File Offset: 0x0004054C
	[DefaultValue(true)]
	[Description("Multiline mode.")]
	[Browsable(true)]
	public bool Boolean_22
	{
		get
		{
			return this.bool_9;
		}
		set
		{
			if (this.bool_9 == value)
			{
				return;
			}
			this.bool_9 = value;
			this.bool_10 = true;
			if (this.bool_9)
			{
				base.AutoScroll = true;
				this.Boolean_21 = true;
			}
			else
			{
				base.AutoScroll = false;
				this.Boolean_21 = false;
				if (this.gclass99_0.Count > 1)
				{
					this.gclass99_0.GClass99.\u202B\u200F\u202D\u202B\u202A\u206E\u206A\u200C\u200E\u206D\u200C\u200B\u206C\u200B\u202A\u206A\u200F\u200C\u202D\u202A\u202E\u206A\u200F\u206F\u206A\u200E\u202A\u200D\u200E\u200B\u200B\u206E\u206C\u200C\u206C\u206A\u200C\u200B\u206C\u202E(1, this.gclass99_0.Count - 1);
				}
				this.gclass99_0.GClass59_0.method_5();
			}
			this.method_4();
		}
	}

	// Token: 0x1700031E RID: 798
	// (get) Token: 0x06000AD4 RID: 2772 RVA: 0x0000A0E2 File Offset: 0x000082E2
	// (set) Token: 0x06000AD5 RID: 2773 RVA: 0x0000A0EA File Offset: 0x000082EA
	[Browsable(true)]
	[DefaultValue(false)]
	[Description("WordWrap.")]
	public bool Boolean_23
	{
		get
		{
			return this.bool_19;
		}
		set
		{
			if (this.bool_19 == value)
			{
				return;
			}
			this.bool_19 = value;
			if (this.bool_19)
			{
				this.GClass86_5.Boolean_0 = false;
			}
			this.method_12(false, true);
			this.method_4();
		}
	}

	// Token: 0x1700031F RID: 799
	// (get) Token: 0x06000AD6 RID: 2774 RVA: 0x0000A11F File Offset: 0x0000831F
	// (set) Token: 0x06000AD7 RID: 2775 RVA: 0x0000A127 File Offset: 0x00008327
	[Browsable(true)]
	[DefaultValue(typeof(GEnum11), "WordWrapControlWidth")]
	[Description("WordWrap mode.")]
	public GEnum11 GEnum11_0
	{
		get
		{
			return this.genum11_0;
		}
		set
		{
			if (this.genum11_0 == value)
			{
				return;
			}
			this.genum11_0 = value;
			this.method_12(false, true);
			this.method_4();
		}
	}

	// Token: 0x17000320 RID: 800
	// (get) Token: 0x06000AD8 RID: 2776 RVA: 0x0000A148 File Offset: 0x00008348
	// (set) Token: 0x06000AD9 RID: 2777 RVA: 0x0000A150 File Offset: 0x00008350
	[DefaultValue(true)]
	[Description("If enabled then line ends included into the selection will be selected too. Then line ends will be shown as selected blank character.")]
	public bool Boolean_24
	{
		get
		{
			return this.bool_32;
		}
		set
		{
			this.bool_32 = value;
			this.method_4();
		}
	}

	// Token: 0x17000321 RID: 801
	// (get) Token: 0x06000ADA RID: 2778 RVA: 0x0000A15F File Offset: 0x0000835F
	// (set) Token: 0x06000ADB RID: 2779 RVA: 0x0000A167 File Offset: 0x00008367
	[Browsable(false)]
	public FindForm FindForm_0 { get; private set; }

	// Token: 0x17000322 RID: 802
	// (get) Token: 0x06000ADC RID: 2780 RVA: 0x0000A170 File Offset: 0x00008370
	// (set) Token: 0x06000ADD RID: 2781 RVA: 0x0000A178 File Offset: 0x00008378
	[Browsable(false)]
	public ReplaceForm ReplaceForm_0 { get; private set; }

	// Token: 0x17000323 RID: 803
	// (get) Token: 0x06000ADE RID: 2782 RVA: 0x0000A181 File Offset: 0x00008381
	// (set) Token: 0x06000ADF RID: 2783 RVA: 0x00002E18 File Offset: 0x00001018
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public virtual bool AutoScroll
	{
		get
		{
			return base.AutoScroll;
		}
		set
		{
		}
	}

	// Token: 0x17000324 RID: 804
	// (get) Token: 0x06000AE0 RID: 2784 RVA: 0x0000A189 File Offset: 0x00008389
	[Browsable(false)]
	public int Int32_14
	{
		get
		{
			return this.gclass99_0.Count;
		}
	}

	// Token: 0x17000325 RID: 805
	public GStruct0 this[GStruct2 gstruct2_0]
	{
		get
		{
			return this.gclass99_0[gstruct2_0.int_1][gstruct2_0.int_0];
		}
		set
		{
			this.gclass99_0[gstruct2_0.int_1][gstruct2_0.int_0] = value;
		}
	}

	// Token: 0x17000326 RID: 806
	public GClass81 this[int int_28]
	{
		get
		{
			return this.gclass99_0[int_28];
		}
	}

	// Token: 0x17000327 RID: 807
	// (get) Token: 0x06000AE4 RID: 2788 RVA: 0x0000A1E1 File Offset: 0x000083E1
	// (set) Token: 0x06000AE5 RID: 2789 RVA: 0x000423D4 File Offset: 0x000405D4
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
	[Localizable(true)]
	[Editor("System.ComponentModel.Design.MultilineStringEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
	[Bindable(true)]
	[SettingsBindable(true)]
	[Browsable(true)]
	[Description("Text of the control.")]
	public virtual string Text
	{
		get
		{
			if (this.Int32_14 == 0)
			{
				return "";
			}
			GClass86 gclass = new GClass86(this);
			gclass.method_2();
			return gclass.String_1;
		}
		set
		{
			if (value == this.Text && value != "")
			{
				return;
			}
			this.method_6();
			this.GClass86_5.Boolean_0 = false;
			this.GClass86_5.method_38();
			try
			{
				this.GClass86_5.method_2();
				this.vmethod_20(value);
				this.method_28();
			}
			finally
			{
				this.GClass86_5.method_39();
			}
		}
	}

	// Token: 0x17000328 RID: 808
	// (get) Token: 0x06000AE6 RID: 2790 RVA: 0x0000A202 File Offset: 0x00008402
	public int Int32_15
	{
		get
		{
			if (this.Int32_14 == 0)
			{
				return 0;
			}
			GClass86 gclass = new GClass86(this);
			gclass.method_2();
			return gclass.Int32_0;
		}
	}

	// Token: 0x17000329 RID: 809
	// (get) Token: 0x06000AE7 RID: 2791 RVA: 0x0000A21F File Offset: 0x0000841F
	[Browsable(false)]
	public IList<string> IList_0
	{
		get
		{
			return this.gclass99_0.vmethod_3();
		}
	}

	// Token: 0x1700032A RID: 810
	// (get) Token: 0x06000AE8 RID: 2792 RVA: 0x00042450 File Offset: 0x00040650
	[Browsable(false)]
	public string String_3
	{
		get
		{
			return "<pre>" + new GClass72
			{
				Boolean_0 = false,
				Boolean_3 = false,
				Boolean_4 = false
			}.method_0(this) + "</pre>";
		}
	}

	// Token: 0x1700032B RID: 811
	// (get) Token: 0x06000AE9 RID: 2793 RVA: 0x0000A22C File Offset: 0x0000842C
	[Browsable(false)]
	public string String_4
	{
		get
		{
			return new GClass73().method_0(this);
		}
	}

	// Token: 0x1700032C RID: 812
	// (get) Token: 0x06000AEA RID: 2794 RVA: 0x0000A239 File Offset: 0x00008439
	// (set) Token: 0x06000AEB RID: 2795 RVA: 0x0000A246 File Offset: 0x00008446
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public string String_5
	{
		get
		{
			return this.GClass86_5.String_1;
		}
		set
		{
			this.vmethod_20(value);
		}
	}

	// Token: 0x1700032D RID: 813
	// (get) Token: 0x06000AEC RID: 2796 RVA: 0x0000A24F File Offset: 0x0000844F
	// (set) Token: 0x06000AED RID: 2797 RVA: 0x0000A278 File Offset: 0x00008478
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public int Int32_16
	{
		get
		{
			return Math.Min(this.method_92(this.GClass86_5.GStruct2_0), this.method_92(this.GClass86_5.GStruct2_1));
		}
		set
		{
			this.GClass86_5.GStruct2_0 = this.method_93(value);
		}
	}

	// Token: 0x1700032E RID: 814
	// (get) Token: 0x06000AEE RID: 2798 RVA: 0x0000A28C File Offset: 0x0000848C
	// (set) Token: 0x06000AEF RID: 2799 RVA: 0x0000A299 File Offset: 0x00008499
	[Browsable(false)]
	[DefaultValue(0)]
	public int Int32_17
	{
		get
		{
			return this.GClass86_5.Int32_0;
		}
		set
		{
			if (value > 0)
			{
				this.GClass86_5.GStruct2_1 = this.method_93(this.Int32_16 + value);
			}
		}
	}

	// Token: 0x1700032F RID: 815
	// (get) Token: 0x06000AF0 RID: 2800 RVA: 0x0000A2B8 File Offset: 0x000084B8
	// (set) Token: 0x06000AF1 RID: 2801 RVA: 0x0000A2C0 File Offset: 0x000084C0
	[DefaultValue(typeof(Font), "Courier New, 9.75")]
	public virtual Font Font
	{
		get
		{
			return this.Font_0;
		}
		set
		{
			this.font_1 = (Font)value.Clone();
			this.method_0(value);
		}
	}

	// Token: 0x17000330 RID: 816
	// (get) Token: 0x06000AF2 RID: 2802 RVA: 0x0000A2DA File Offset: 0x000084DA
	// (set) Token: 0x06000AF3 RID: 2803 RVA: 0x0000A2E2 File Offset: 0x000084E2
	[DefaultValue(typeof(Font), "Courier New, 9.75")]
	private Font Font_0
	{
		get
		{
			return this.font_0;
		}
		set
		{
			this.font_0 = value;
		}
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x00042490 File Offset: 0x00040690
	private void method_0(Font font_2)
	{
		this.Font_0 = font_2;
		SizeF sz = FastColoredTextBox.smethod_1(this.Font_0, 'M');
		SizeF sz2 = FastColoredTextBox.smethod_1(this.Font_0, '.');
		if (sz != sz2)
		{
			this.Font_0 = new Font("Courier New", this.Font_0.SizeInPoints, FontStyle.Regular, GraphicsUnit.Point);
		}
		SizeF sizeF = FastColoredTextBox.smethod_1(this.Font_0, 'M');
		this.Int32_4 = (int)Math.Round((double)(sizeF.Width * 1f)) - 1;
		this.Int32_2 = this.int_12 + (int)Math.Round((double)(sizeF.Height * 1f)) - 1;
		this.method_12(false, this.bool_19);
		this.method_4();
	}

	// Token: 0x17000331 RID: 817
	// (get) Token: 0x06000AF6 RID: 2806 RVA: 0x0000A2EB File Offset: 0x000084EB
	// (set) Token: 0x06000AF5 RID: 2805 RVA: 0x00042544 File Offset: 0x00040744
	public Size Size_0
	{
		get
		{
			if (this.bool_16)
			{
				return base.AutoScrollMinSize;
			}
			return this.size_0;
		}
		set
		{
			if (this.bool_16)
			{
				if (!base.AutoScroll)
				{
					base.AutoScroll = true;
				}
				Size autoScrollMinSize = value;
				if (this.Boolean_23 && this.GEnum11_0 != GEnum11.Custom)
				{
					int val = this.method_44();
					autoScrollMinSize = new Size(Math.Min(autoScrollMinSize.Width, val), autoScrollMinSize.Height);
				}
				base.AutoScrollMinSize = autoScrollMinSize;
				return;
			}
			if (base.AutoScroll)
			{
				base.AutoScroll = false;
			}
			base.AutoScrollMinSize = new Size(0, 0);
			base.VerticalScroll.Visible = false;
			base.HorizontalScroll.Visible = false;
			base.VerticalScroll.Maximum = Math.Max(0, value.Height - base.ClientSize.Height);
			base.HorizontalScroll.Maximum = Math.Max(0, value.Width - base.ClientSize.Width);
			this.size_0 = value;
		}
	}

	// Token: 0x17000332 RID: 818
	// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x0000A302 File Offset: 0x00008502
	[Browsable(false)]
	public bool Boolean_25
	{
		get
		{
			return base.ImeMode != ImeMode.Disable && base.ImeMode != ImeMode.Off && base.ImeMode > ImeMode.NoControl;
		}
	}

	// Token: 0x17000333 RID: 819
	// (get) Token: 0x06000AF8 RID: 2808 RVA: 0x0000A321 File Offset: 0x00008521
	[Browsable(false)]
	public bool Boolean_26
	{
		get
		{
			return this.gclass99_0.GClass59_0.Boolean_1;
		}
	}

	// Token: 0x17000334 RID: 820
	// (get) Token: 0x06000AF9 RID: 2809 RVA: 0x0000A333 File Offset: 0x00008533
	[Browsable(false)]
	public bool Boolean_27
	{
		get
		{
			return this.gclass99_0.GClass59_0.Boolean_2;
		}
	}

	// Token: 0x17000335 RID: 821
	// (get) Token: 0x06000AFA RID: 2810 RVA: 0x0000A345 File Offset: 0x00008545
	private int Int32_18
	{
		get
		{
			return this.Int32_7 - 4 - 3;
		}
	}

	// Token: 0x17000336 RID: 822
	// (get) Token: 0x06000AFB RID: 2811 RVA: 0x0000A351 File Offset: 0x00008551
	[Browsable(false)]
	public GClass86 GClass86_6
	{
		get
		{
			return new GClass86(this, new GStruct2(0, 0), new GStruct2(this.gclass99_0[this.gclass99_0.Count - 1].Count, this.gclass99_0.Count - 1));
		}
	}

	// Token: 0x17000337 RID: 823
	// (get) Token: 0x06000AFC RID: 2812 RVA: 0x0000A38F File Offset: 0x0000858F
	// (set) Token: 0x06000AFD RID: 2813 RVA: 0x00042630 File Offset: 0x00040830
	[DefaultValue(typeof(Color), "Blue")]
	[Description("Color of selected area.")]
	public virtual Color Color_11
	{
		get
		{
			return this.color_6;
		}
		set
		{
			this.color_6 = value;
			if (this.color_6.A == 255)
			{
				this.color_6 = Color.FromArgb(60, this.color_6);
			}
			this.GClass90_0 = new GClass90(new SolidBrush(this.color_6), null);
			this.method_4();
		}
	}

	// Token: 0x17000338 RID: 824
	// (get) Token: 0x06000AFE RID: 2814 RVA: 0x0000A397 File Offset: 0x00008597
	// (set) Token: 0x06000AFF RID: 2815 RVA: 0x0000A39F File Offset: 0x0000859F
	public virtual Cursor Cursor
	{
		get
		{
			return base.Cursor;
		}
		set
		{
			this.cursor_0 = value;
			base.Cursor = value;
		}
	}

	// Token: 0x17000339 RID: 825
	// (get) Token: 0x06000B00 RID: 2816 RVA: 0x0000A3AF File Offset: 0x000085AF
	// (set) Token: 0x06000B01 RID: 2817 RVA: 0x0000A3B7 File Offset: 0x000085B7
	[DefaultValue(1)]
	[Description("Reserved space for line number characters. If smaller than needed (e. g. line count >= 10 and this value set to 1) this value will have no impact. If you want to reserve space, e. g. for line numbers >= 10 or >= 100, than you can set this value to 2 or 3 or higher.")]
	public int Int32_19
	{
		get
		{
			return this.int_18;
		}
		set
		{
			this.int_18 = value;
			this.method_10();
			this.method_4();
		}
	}

	// Token: 0x14000015 RID: 21
	// (add) Token: 0x06000B02 RID: 2818 RVA: 0x00042688 File Offset: 0x00040888
	// (remove) Token: 0x06000B03 RID: 2819 RVA: 0x000426C0 File Offset: 0x000408C0
	[Browsable(true)]
	[Description("Occurs when mouse is moving over text and tooltip is needed.")]
	public event EventHandler<GEventArgs15> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs15> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs15> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs15> value2 = (EventHandler<GEventArgs15>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs15>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs15> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs15> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs15> value2 = (EventHandler<GEventArgs15>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs15>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1700033A RID: 826
	// (get) Token: 0x06000B04 RID: 2820 RVA: 0x0000A3CC File Offset: 0x000085CC
	// (set) Token: 0x06000B05 RID: 2821 RVA: 0x0000A3D4 File Offset: 0x000085D4
	[Browsable(false)]
	[DefaultValue(0)]
	public int Int32_20
	{
		get
		{
			return this.int_25;
		}
		set
		{
			this.int_25 = value;
			this.method_4();
		}
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x0000A3E3 File Offset: 0x000085E3
	public void method_1()
	{
		if (this.GClass77_0 != null)
		{
			this.GClass77_0.Clear();
		}
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x000426F8 File Offset: 0x000408F8
	public virtual GClass78 vmethod_0(GClass86 gclass86_9, Control control_0, bool bool_37, bool bool_38, bool bool_39)
	{
		GClass78 gclass = new GClass78(gclass86_9, control_0, bool_38, bool_39);
		this.GClass77_0.Add(gclass);
		if (bool_37)
		{
			gclass.vmethod_0();
		}
		return gclass;
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x0000A3F8 File Offset: 0x000085F8
	public GClass78 method_2(GClass86 gclass86_9, Control control_0)
	{
		return this.vmethod_0(gclass86_9, control_0, true, true, true);
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x00042728 File Offset: 0x00040928
	public virtual GClass78 vmethod_1(GClass86 gclass86_9, string string_3, bool bool_37, bool bool_38, bool bool_39)
	{
		GClass78 gclass = new GClass78(gclass86_9, string_3, bool_38, bool_39);
		this.GClass77_0.Add(gclass);
		if (bool_37)
		{
			gclass.vmethod_0();
		}
		return gclass;
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x0000A405 File Offset: 0x00008605
	public GClass78 method_3(GClass86 gclass86_9, string string_3)
	{
		return this.vmethod_1(gclass86_9, string_3, true, true, true);
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x0000A412 File Offset: 0x00008612
	public virtual void vmethod_2(GClass78 gclass78_0)
	{
		if (this.eventHandler_1 != null)
		{
			this.eventHandler_1(this, new GEventArgs16(gclass78_0));
		}
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x0000A42E File Offset: 0x0000862E
	private void timer_2_Tick(object sender, EventArgs e)
	{
		this.timer_2.Stop();
		this.vmethod_3();
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x00042758 File Offset: 0x00040958
	protected virtual void vmethod_3()
	{
		if (this.ToolTip_0 == null)
		{
			return;
		}
		if (this.eventHandler_0 == null)
		{
			return;
		}
		GStruct2 gstruct = this.method_84(this.point_0);
		Point point = this.method_95(gstruct);
		if (Math.Abs(point.X - this.point_0.X) <= this.Int32_4 * 2 && Math.Abs(point.Y - this.point_0.Y) <= this.Int32_2 * 2)
		{
			string string_ = new GClass86(this, gstruct, gstruct).method_43("[a-zA-Z]").String_1;
			GEventArgs15 geventArgs = new GEventArgs15(gstruct, string_);
			this.eventHandler_0(this, geventArgs);
			if (geventArgs.String_2 != null)
			{
				this.ToolTip_0.ToolTipTitle = geventArgs.String_1;
				this.ToolTip_0.ToolTipIcon = geventArgs.ToolTipIcon_0;
				this.ToolTip_0.Show(geventArgs.String_2, this, new Point(this.point_0.X, this.point_0.Y + this.Int32_2));
			}
			return;
		}
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x0000A441 File Offset: 0x00008641
	public virtual void vmethod_4()
	{
		this.bool_12 = true;
		this.bool_15 = true;
		this.method_20(this.timer_0);
		if (this.eventHandler_7 != null)
		{
			this.eventHandler_7(this, new EventArgs());
		}
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x0000A476 File Offset: 0x00008676
	public void method_4()
	{
		if (base.InvokeRequired)
		{
			base.BeginInvoke(new MethodInvoker(this.method_4));
			return;
		}
		base.Invalidate();
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x0000A49A File Offset: 0x0000869A
	protected virtual void vmethod_5()
	{
		base.VerticalScroll.SmallChange = this.int_9;
		base.VerticalScroll.LargeChange = 10 * this.int_9;
		base.HorizontalScroll.SmallChange = this.Int32_4;
	}

	// Token: 0x14000016 RID: 22
	// (add) Token: 0x06000B11 RID: 2833 RVA: 0x00042864 File Offset: 0x00040A64
	// (remove) Token: 0x06000B12 RID: 2834 RVA: 0x0004289C File Offset: 0x00040A9C
	[Browsable(true)]
	[Description("It occurs if user click on the hint.")]
	public event EventHandler<GEventArgs16> Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs16> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs16> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs16> value2 = (EventHandler<GEventArgs16>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs16>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs16> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs16> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs16> value2 = (EventHandler<GEventArgs16>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs16>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000017 RID: 23
	// (add) Token: 0x06000B13 RID: 2835 RVA: 0x000428D4 File Offset: 0x00040AD4
	// (remove) Token: 0x06000B14 RID: 2836 RVA: 0x0004290C File Offset: 0x00040B0C
	[Browsable(true)]
	[Description("It occurs after insert, delete, clear, undo and redo operations.")]
	public event EventHandler<GEventArgs11> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs11> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs11> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs11> value2 = (EventHandler<GEventArgs11>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs11>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs11> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs11> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs11> value2 = (EventHandler<GEventArgs11>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs11>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000018 RID: 24
	// (add) Token: 0x06000B15 RID: 2837 RVA: 0x00042944 File Offset: 0x00040B44
	// (remove) Token: 0x06000B16 RID: 2838 RVA: 0x0004297C File Offset: 0x00040B7C
	[Browsable(false)]
	internal event EventHandler Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_3;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_3;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000019 RID: 25
	// (add) Token: 0x06000B17 RID: 2839 RVA: 0x000429B4 File Offset: 0x00040BB4
	// (remove) Token: 0x06000B18 RID: 2840 RVA: 0x000429EC File Offset: 0x00040BEC
	[Description("Occurs when user paste text from clipboard")]
	public event EventHandler<GEventArgs12> Event_4
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_4;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_4;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001A RID: 26
	// (add) Token: 0x06000B19 RID: 2841 RVA: 0x00042A24 File Offset: 0x00040C24
	// (remove) Token: 0x06000B1A RID: 2842 RVA: 0x00042A5C File Offset: 0x00040C5C
	[Browsable(true)]
	[Description("It occurs before insert, delete, clear, undo and redo operations.")]
	public event EventHandler<GEventArgs12> Event_5
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs12> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs12> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs12> value2 = (EventHandler<GEventArgs12>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs12>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001B RID: 27
	// (add) Token: 0x06000B1B RID: 2843 RVA: 0x00042A94 File Offset: 0x00040C94
	// (remove) Token: 0x06000B1C RID: 2844 RVA: 0x00042ACC File Offset: 0x00040CCC
	[Browsable(true)]
	[Description("It occurs after changing of selection.")]
	public event EventHandler Event_6
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_6;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_6;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001C RID: 28
	// (add) Token: 0x06000B1D RID: 2845 RVA: 0x00042B04 File Offset: 0x00040D04
	// (remove) Token: 0x06000B1E RID: 2846 RVA: 0x00042B3C File Offset: 0x00040D3C
	[Browsable(true)]
	[Description("It occurs after changing of visible range.")]
	public event EventHandler Event_7
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_7;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_7;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001D RID: 29
	// (add) Token: 0x06000B1F RID: 2847 RVA: 0x00042B74 File Offset: 0x00040D74
	// (remove) Token: 0x06000B20 RID: 2848 RVA: 0x00042BAC File Offset: 0x00040DAC
	[Browsable(true)]
	[Description("It occurs after insert, delete, clear, undo and redo operations. This event occurs with a delay relative to TextChanged, and fires only once.")]
	public event EventHandler<GEventArgs11> Event_8
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs11> eventHandler = this.eventHandler_8;
			EventHandler<GEventArgs11> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs11> value2 = (EventHandler<GEventArgs11>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs11>>(ref this.eventHandler_8, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs11> eventHandler = this.eventHandler_8;
			EventHandler<GEventArgs11> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs11> value2 = (EventHandler<GEventArgs11>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs11>>(ref this.eventHandler_8, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001E RID: 30
	// (add) Token: 0x06000B21 RID: 2849 RVA: 0x00042BE4 File Offset: 0x00040DE4
	// (remove) Token: 0x06000B22 RID: 2850 RVA: 0x00042C1C File Offset: 0x00040E1C
	[Browsable(true)]
	[Description("It occurs after changing of selection. This event occurs with a delay relative to SelectionChanged, and fires only once.")]
	public event EventHandler Event_9
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_9;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_9, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_9;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_9, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400001F RID: 31
	// (add) Token: 0x06000B23 RID: 2851 RVA: 0x00042C54 File Offset: 0x00040E54
	// (remove) Token: 0x06000B24 RID: 2852 RVA: 0x00042C8C File Offset: 0x00040E8C
	[Browsable(true)]
	[Description("It occurs after changing of visible range. This event occurs with a delay relative to VisibleRangeChanged, and fires only once.")]
	public event EventHandler Event_10
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_10;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_10, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_10;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_10, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000020 RID: 32
	// (add) Token: 0x06000B25 RID: 2853 RVA: 0x00042CC4 File Offset: 0x00040EC4
	// (remove) Token: 0x06000B26 RID: 2854 RVA: 0x00042CFC File Offset: 0x00040EFC
	[Browsable(true)]
	[Description("It occurs when user click on VisualMarker.")]
	public event EventHandler<GEventArgs21> Event_11
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs21> eventHandler = this.eventHandler_11;
			EventHandler<GEventArgs21> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs21> value2 = (EventHandler<GEventArgs21>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs21>>(ref this.eventHandler_11, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs21> eventHandler = this.eventHandler_11;
			EventHandler<GEventArgs21> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs21> value2 = (EventHandler<GEventArgs21>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs21>>(ref this.eventHandler_11, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000021 RID: 33
	// (add) Token: 0x06000B27 RID: 2855 RVA: 0x00042D34 File Offset: 0x00040F34
	// (remove) Token: 0x06000B28 RID: 2856 RVA: 0x00042D6C File Offset: 0x00040F6C
	[Browsable(true)]
	[Description("It occurs when visible char is enetering (alphabetic, digit, punctuation, DEL, BACKSPACE).")]
	public event KeyPressEventHandler Event_12
	{
		[CompilerGenerated]
		add
		{
			KeyPressEventHandler keyPressEventHandler = this.keyPressEventHandler_0;
			KeyPressEventHandler keyPressEventHandler2;
			do
			{
				keyPressEventHandler2 = keyPressEventHandler;
				KeyPressEventHandler value2 = (KeyPressEventHandler)Delegate.Combine(keyPressEventHandler2, value);
				keyPressEventHandler = Interlocked.CompareExchange<KeyPressEventHandler>(ref this.keyPressEventHandler_0, value2, keyPressEventHandler2);
			}
			while (keyPressEventHandler != keyPressEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			KeyPressEventHandler keyPressEventHandler = this.keyPressEventHandler_0;
			KeyPressEventHandler keyPressEventHandler2;
			do
			{
				keyPressEventHandler2 = keyPressEventHandler;
				KeyPressEventHandler value2 = (KeyPressEventHandler)Delegate.Remove(keyPressEventHandler2, value);
				keyPressEventHandler = Interlocked.CompareExchange<KeyPressEventHandler>(ref this.keyPressEventHandler_0, value2, keyPressEventHandler2);
			}
			while (keyPressEventHandler != keyPressEventHandler2);
		}
	}

	// Token: 0x14000022 RID: 34
	// (add) Token: 0x06000B29 RID: 2857 RVA: 0x00042DA4 File Offset: 0x00040FA4
	// (remove) Token: 0x06000B2A RID: 2858 RVA: 0x00042DDC File Offset: 0x00040FDC
	[Browsable(true)]
	[Description("It occurs when visible char is enetered (alphabetic, digit, punctuation, DEL, BACKSPACE).")]
	public event KeyPressEventHandler Event_13
	{
		[CompilerGenerated]
		add
		{
			KeyPressEventHandler keyPressEventHandler = this.keyPressEventHandler_1;
			KeyPressEventHandler keyPressEventHandler2;
			do
			{
				keyPressEventHandler2 = keyPressEventHandler;
				KeyPressEventHandler value2 = (KeyPressEventHandler)Delegate.Combine(keyPressEventHandler2, value);
				keyPressEventHandler = Interlocked.CompareExchange<KeyPressEventHandler>(ref this.keyPressEventHandler_1, value2, keyPressEventHandler2);
			}
			while (keyPressEventHandler != keyPressEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			KeyPressEventHandler keyPressEventHandler = this.keyPressEventHandler_1;
			KeyPressEventHandler keyPressEventHandler2;
			do
			{
				keyPressEventHandler2 = keyPressEventHandler;
				KeyPressEventHandler value2 = (KeyPressEventHandler)Delegate.Remove(keyPressEventHandler2, value);
				keyPressEventHandler = Interlocked.CompareExchange<KeyPressEventHandler>(ref this.keyPressEventHandler_1, value2, keyPressEventHandler2);
			}
			while (keyPressEventHandler != keyPressEventHandler2);
		}
	}

	// Token: 0x14000023 RID: 35
	// (add) Token: 0x06000B2B RID: 2859 RVA: 0x00042E14 File Offset: 0x00041014
	// (remove) Token: 0x06000B2C RID: 2860 RVA: 0x00042E4C File Offset: 0x0004104C
	[Browsable(true)]
	[Description("It occurs when calculates AutoIndent for new line.")]
	public event EventHandler<GEventArgs14> Event_14
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs14> eventHandler = this.eventHandler_12;
			EventHandler<GEventArgs14> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs14> value2 = (EventHandler<GEventArgs14>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs14>>(ref this.eventHandler_12, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs14> eventHandler = this.eventHandler_12;
			EventHandler<GEventArgs14> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs14> value2 = (EventHandler<GEventArgs14>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs14>>(ref this.eventHandler_12, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000024 RID: 36
	// (add) Token: 0x06000B2D RID: 2861 RVA: 0x00042E84 File Offset: 0x00041084
	// (remove) Token: 0x06000B2E RID: 2862 RVA: 0x00042EBC File Offset: 0x000410BC
	[Browsable(true)]
	[Description("It occurs when line background is painting.")]
	public event EventHandler<GEventArgs8> Event_15
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs8> eventHandler = this.eventHandler_13;
			EventHandler<GEventArgs8> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs8> value2 = (EventHandler<GEventArgs8>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs8>>(ref this.eventHandler_13, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs8> eventHandler = this.eventHandler_13;
			EventHandler<GEventArgs8> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs8> value2 = (EventHandler<GEventArgs8>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs8>>(ref this.eventHandler_13, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000025 RID: 37
	// (add) Token: 0x06000B2F RID: 2863 RVA: 0x00042EF4 File Offset: 0x000410F4
	// (remove) Token: 0x06000B30 RID: 2864 RVA: 0x00042F2C File Offset: 0x0004112C
	[Browsable(true)]
	[Description("Occurs when line was inserted/added.")]
	public event EventHandler<GEventArgs9> Event_16
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs9> eventHandler = this.eventHandler_14;
			EventHandler<GEventArgs9> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs9> value2 = (EventHandler<GEventArgs9>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs9>>(ref this.eventHandler_14, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs9> eventHandler = this.eventHandler_14;
			EventHandler<GEventArgs9> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs9> value2 = (EventHandler<GEventArgs9>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs9>>(ref this.eventHandler_14, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000026 RID: 38
	// (add) Token: 0x06000B31 RID: 2865 RVA: 0x00042F64 File Offset: 0x00041164
	// (remove) Token: 0x06000B32 RID: 2866 RVA: 0x00042F9C File Offset: 0x0004119C
	[Browsable(true)]
	[Description("Occurs when line was removed.")]
	public event EventHandler<GEventArgs10> Event_17
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs10> eventHandler = this.eventHandler_15;
			EventHandler<GEventArgs10> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs10> value2 = (EventHandler<GEventArgs10>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs10>>(ref this.eventHandler_15, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs10> eventHandler = this.eventHandler_15;
			EventHandler<GEventArgs10> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs10> value2 = (EventHandler<GEventArgs10>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs10>>(ref this.eventHandler_15, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000027 RID: 39
	// (add) Token: 0x06000B33 RID: 2867 RVA: 0x00042FD4 File Offset: 0x000411D4
	// (remove) Token: 0x06000B34 RID: 2868 RVA: 0x0004300C File Offset: 0x0004120C
	[Browsable(true)]
	[Description("Occurs when current highlighted folding area is changed.")]
	public event EventHandler<EventArgs> Event_18
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs> eventHandler = this.eventHandler_16;
			EventHandler<EventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs> value2 = (EventHandler<EventArgs>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs>>(ref this.eventHandler_16, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs> eventHandler = this.eventHandler_16;
			EventHandler<EventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs> value2 = (EventHandler<EventArgs>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs>>(ref this.eventHandler_16, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000028 RID: 40
	// (add) Token: 0x06000B35 RID: 2869 RVA: 0x00043044 File Offset: 0x00041244
	// (remove) Token: 0x06000B36 RID: 2870 RVA: 0x0004307C File Offset: 0x0004127C
	[Browsable(true)]
	[Description("Occurs when undo/redo stack is changed.")]
	public event EventHandler<EventArgs> Event_19
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs> eventHandler = this.eventHandler_17;
			EventHandler<EventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs> value2 = (EventHandler<EventArgs>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs>>(ref this.eventHandler_17, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs> eventHandler = this.eventHandler_17;
			EventHandler<EventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs> value2 = (EventHandler<EventArgs>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs>>(ref this.eventHandler_17, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000029 RID: 41
	// (add) Token: 0x06000B37 RID: 2871 RVA: 0x000430B4 File Offset: 0x000412B4
	// (remove) Token: 0x06000B38 RID: 2872 RVA: 0x000430EC File Offset: 0x000412EC
	[Browsable(true)]
	[Description("Occurs when component was zoomed.")]
	public event EventHandler Event_20
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_18;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_18, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_18;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_18, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400002A RID: 42
	// (add) Token: 0x06000B39 RID: 2873 RVA: 0x00043124 File Offset: 0x00041324
	// (remove) Token: 0x06000B3A RID: 2874 RVA: 0x0004315C File Offset: 0x0004135C
	[Browsable(true)]
	[Description("Occurs when user pressed key, that specified as CustomAction.")]
	public event EventHandler<GEventArgs17> Event_21
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs17> eventHandler = this.eventHandler_19;
			EventHandler<GEventArgs17> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs17> value2 = (EventHandler<GEventArgs17>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs17>>(ref this.eventHandler_19, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs17> eventHandler = this.eventHandler_19;
			EventHandler<GEventArgs17> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs17> value2 = (EventHandler<GEventArgs17>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs17>>(ref this.eventHandler_19, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400002B RID: 43
	// (add) Token: 0x06000B3B RID: 2875 RVA: 0x00043194 File Offset: 0x00041394
	// (remove) Token: 0x06000B3C RID: 2876 RVA: 0x000431CC File Offset: 0x000413CC
	[Browsable(true)]
	[Description("Occurs when scroolbars are updated.")]
	public event EventHandler Event_22
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_20;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_20, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_20;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_20, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400002C RID: 44
	// (add) Token: 0x06000B3D RID: 2877 RVA: 0x00043204 File Offset: 0x00041404
	// (remove) Token: 0x06000B3E RID: 2878 RVA: 0x0004323C File Offset: 0x0004143C
	[Browsable(true)]
	[Description("Occurs when custom wordwrap is needed.")]
	public event EventHandler<GEventArgs13> Event_23
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs13> eventHandler = this.eventHandler_21;
			EventHandler<GEventArgs13> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs13> value2 = (EventHandler<GEventArgs13>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs13>>(ref this.eventHandler_21, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs13> eventHandler = this.eventHandler_21;
			EventHandler<GEventArgs13> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs13> value2 = (EventHandler<GEventArgs13>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs13>>(ref this.eventHandler_21, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x00043274 File Offset: 0x00041474
	public List<GClass87> method_5(GStruct2 gstruct2_0)
	{
		List<GClass87> list = new List<GClass87>();
		if (gstruct2_0.int_1 < this.Int32_14 && gstruct2_0.int_0 < this[gstruct2_0.int_1].Count)
		{
			ushort styleIndex_ = (ushort)this[gstruct2_0].styleIndex_0;
			for (int i = 0; i < 16; i++)
			{
				if (((int)styleIndex_ & 1 << i) != 0)
				{
					list.Add(this.GClass87_0[i]);
				}
			}
		}
		return list;
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x0000A4D2 File Offset: 0x000086D2
	protected virtual GClass99 vmethod_6()
	{
		return new GClass99(this);
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x0000A4DA File Offset: 0x000086DA
	private void method_6()
	{
		this.GClass99_0.FastColoredTextBox_0 = this;
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x000432E4 File Offset: 0x000414E4
	protected virtual void vmethod_7(GClass99 gclass99_1)
	{
		if (this.gclass99_0 != null)
		{
			this.gclass99_0.Event_0 -= this.method_15;
			this.gclass99_0.Event_1 -= this.method_14;
			this.gclass99_0.Event_2 -= this.method_13;
			this.gclass99_0.Event_3 -= this.method_9;
			this.gclass99_0.Event_4 -= this.method_7;
			this.gclass99_0.Event_5 -= this.method_8;
			this.gclass99_0.Dispose();
		}
		this.list_0.Clear();
		this.method_1();
		if (this.GClass56_0 != null)
		{
			this.GClass56_0.Clear();
		}
		this.gclass99_0 = gclass99_1;
		if (gclass99_1 != null)
		{
			gclass99_1.Event_0 += this.method_15;
			gclass99_1.Event_1 += this.method_14;
			gclass99_1.Event_2 += this.method_13;
			gclass99_1.Event_3 += this.method_9;
			gclass99_1.Event_4 += this.method_7;
			gclass99_1.Event_5 += this.method_8;
			while (this.list_0.Count < gclass99_1.Count)
			{
				this.list_0.Add(new GStruct1(-1));
			}
		}
		this.bool_4 = false;
		this.bool_10 = true;
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x0000A4E8 File Offset: 0x000086E8
	private void method_7(object sender, GClass99.GEventArgs20 e)
	{
		this.method_45(e.int_0, e.int_1);
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x00043464 File Offset: 0x00041664
	private void method_8(object sender, GEventArgs12 e)
	{
		if (this.GClass99_0.FastColoredTextBox_0 == this)
		{
			string text = e.String_0;
			this.vmethod_52(ref text);
			e.String_0 = text;
		}
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x00043498 File Offset: 0x00041698
	private void method_9(object sender, GClass99.GEventArgs20 e)
	{
		if (e.int_0 == e.int_1 && !this.Boolean_23 && this.gclass99_0.Count > 100000)
		{
			this.method_42(e.int_0);
			return;
		}
		this.method_12(false, this.Boolean_23);
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x0000A4FC File Offset: 0x000086FC
	public void method_10()
	{
		this.method_11(false);
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x0000A505 File Offset: 0x00008705
	public void method_11(bool bool_37)
	{
		this.method_12(bool_37, false);
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x0000A50F File Offset: 0x0000870F
	public void method_12(bool bool_37, bool bool_38)
	{
		this.bool_10 = true;
		if (bool_38)
		{
			this.point_1 = new Point(0, this.Int32_14 - 1);
			this.bool_11 = true;
		}
		if (bool_37)
		{
			this.method_40();
		}
	}

	// Token: 0x06000B49 RID: 2889 RVA: 0x000434E8 File Offset: 0x000416E8
	private void method_13(object sender, GClass99.GEventArgs20 e)
	{
		if (e.int_0 == e.int_1 && !this.Boolean_23)
		{
			this.method_42(e.int_0);
		}
		else
		{
			this.bool_10 = true;
		}
		this.method_4();
		if (this.GClass99_0.FastColoredTextBox_0 == this)
		{
			this.vmethod_55(e.int_0, e.int_1);
		}
	}

	// Token: 0x06000B4A RID: 2890 RVA: 0x0000A53F File Offset: 0x0000873F
	private void method_14(object sender, GEventArgs10 e)
	{
		this.list_0.RemoveRange(e.Int32_0, e.Int32_1);
		this.method_123(e.Int32_0, e.Int32_1, e.List_0);
	}

	// Token: 0x06000B4B RID: 2891 RVA: 0x00043548 File Offset: 0x00041748
	private void method_15(object sender, GEventArgs9 e)
	{
		GEnum17 genum17_ = GEnum17.Visible;
		if (e.Int32_0 >= 0 && e.Int32_0 < this.list_0.Count && this.list_0[e.Int32_0].genum17_0 == GEnum17.Hidden)
		{
			genum17_ = GEnum17.Hidden;
		}
		if (e.Int32_1 > 100000)
		{
			this.list_0.Capacity = this.list_0.Count + e.Int32_1 + 1000;
		}
		GStruct1[] array = new GStruct1[e.Int32_1];
		for (int i = 0; i < e.Int32_1; i++)
		{
			array[i].int_0 = -1;
			array[i].genum17_0 = genum17_;
		}
		this.list_0.InsertRange(e.Int32_0, array);
		if (e.Int32_1 > 1000000)
		{
			GC.Collect();
		}
		this.method_122(e.Int32_0, e.Int32_1);
	}

	// Token: 0x06000B4C RID: 2892 RVA: 0x0004362C File Offset: 0x0004182C
	public bool method_16()
	{
		DateTime now = DateTime.Now;
		int num = -1;
		for (int i = 0; i < this.Int32_14; i++)
		{
			if (this.gclass99_0.vmethod_2(i) && this.gclass99_0[i].DateTime_0 > this.dateTime_0 && this.gclass99_0[i].DateTime_0 < now)
			{
				now = this.gclass99_0[i].DateTime_0;
				num = i;
			}
		}
		if (num >= 0)
		{
			this.method_18(num);
			return true;
		}
		return false;
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x000436BC File Offset: 0x000418BC
	public bool method_17()
	{
		DateTime t = default(DateTime);
		int num = -1;
		for (int i = 0; i < this.Int32_14; i++)
		{
			if (this.gclass99_0.vmethod_2(i) && this.gclass99_0[i].DateTime_0 < this.dateTime_0 && this.gclass99_0[i].DateTime_0 > t)
			{
				t = this.gclass99_0[i].DateTime_0;
				num = i;
			}
		}
		if (num >= 0)
		{
			this.method_18(num);
			return true;
		}
		return false;
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x0000A570 File Offset: 0x00008770
	public void method_18(int int_28)
	{
		if (int_28 >= this.Int32_14)
		{
			return;
		}
		this.dateTime_0 = this.gclass99_0[int_28].DateTime_0;
		this.GClass86_5.GStruct2_0 = new GStruct2(0, int_28);
		this.method_51();
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x0000A5AB File Offset: 0x000087AB
	protected virtual void OnLoad(EventArgs e)
	{
		base.OnLoad(e);
		this.intptr_0 = FastColoredTextBox.ImmGetContext(base.Handle);
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x0004374C File Offset: 0x0004194C
	private void timer_1_Tick(object sender, EventArgs e)
	{
		this.timer_1.Enabled = false;
		if (this.bool_14)
		{
			this.bool_14 = false;
			if (this.gclass86_0 == null)
			{
				return;
			}
			this.gclass86_0 = this.GClass86_6.vmethod_0(this.gclass86_0);
			this.gclass86_0.method_42();
			this.vmethod_8(this.gclass86_0);
			this.gclass86_0 = null;
		}
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x0000A5C5 File Offset: 0x000087C5
	public void method_19(GClass101 gclass101_0)
	{
		this.list_1.Add(gclass101_0);
	}

	// Token: 0x06000B52 RID: 2898 RVA: 0x0000A5D3 File Offset: 0x000087D3
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.timer_0.Enabled = false;
		if (this.bool_13)
		{
			this.bool_13 = false;
			this.vmethod_9();
		}
		if (this.bool_15)
		{
			this.bool_15 = false;
			this.vmethod_10();
		}
	}

	// Token: 0x06000B53 RID: 2899 RVA: 0x0000A60B File Offset: 0x0000880B
	public virtual void vmethod_8(GClass86 gclass86_9)
	{
		if (this.eventHandler_8 != null)
		{
			this.eventHandler_8(this, new GEventArgs11(gclass86_9));
		}
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x000437B4 File Offset: 0x000419B4
	public virtual void vmethod_9()
	{
		this.method_42(this.GClass86_5.GStruct2_0.int_1);
		this.method_110();
		if (this.Char_1 != '\0' && this.Char_2 != '\0')
		{
			this.method_111(this.Char_1, this.Char_2, ref this.gclass86_1, ref this.gclass86_3);
		}
		if (this.Char_3 != '\0' && this.Char_4 != '\0')
		{
			this.method_111(this.Char_3, this.Char_4, ref this.gclass86_2, ref this.gclass86_4);
		}
		if (this.GClass86_5.Boolean_2 && this.GClass86_5.GStruct2_0.int_1 < this.Int32_14 && this.dateTime_0 != this.gclass99_0[this.GClass86_5.GStruct2_0.int_1].DateTime_0)
		{
			this.gclass99_0[this.GClass86_5.GStruct2_0.int_1].DateTime_0 = DateTime.Now;
			this.dateTime_0 = this.gclass99_0[this.GClass86_5.GStruct2_0.int_1].DateTime_0;
		}
		if (this.eventHandler_9 != null)
		{
			this.eventHandler_9(this, new EventArgs());
		}
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x0000A627 File Offset: 0x00008827
	public virtual void vmethod_10()
	{
		if (this.eventHandler_10 != null)
		{
			this.eventHandler_10(this, new EventArgs());
		}
	}

	// Token: 0x06000B56 RID: 2902 RVA: 0x000438F4 File Offset: 0x00041AF4
	private void method_20(System.Windows.Forms.Timer timer_4)
	{
		FastColoredTextBox.Class94 @class = new FastColoredTextBox.Class94();
		@class.fastColoredTextBox_0 = this;
		@class.timer_0 = timer_4;
		if (base.InvokeRequired)
		{
			base.BeginInvoke(new MethodInvoker(@class.method_0));
			return;
		}
		@class.timer_0.Stop();
		if (base.IsHandleCreated)
		{
			@class.timer_0.Start();
			return;
		}
		this.dictionary_2[@class.timer_0] = @class.timer_0;
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x00043968 File Offset: 0x00041B68
	protected virtual void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		foreach (System.Windows.Forms.Timer timer_ in new List<System.Windows.Forms.Timer>(this.dictionary_2.Keys))
		{
			this.method_20(timer_);
		}
		this.dictionary_2.Clear();
		this.vmethod_29();
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x000439E0 File Offset: 0x00041BE0
	public int method_21(GClass87 gclass87_0)
	{
		if (gclass87_0 == null)
		{
			return -1;
		}
		int num = this.method_32(gclass87_0);
		if (num >= 0)
		{
			return num;
		}
		num = this.method_22();
		this.GClass87_0[num] = gclass87_0;
		return num;
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x00043A14 File Offset: 0x00041C14
	public int method_22()
	{
		int num = this.GClass87_0.Length - 1;
		while (num >= 0 && this.GClass87_0[num] == null)
		{
			num--;
		}
		num++;
		if (num >= this.GClass87_0.Length)
		{
			throw new Exception("Maximum count of Styles is exceeded.");
		}
		return num;
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x0000A642 File Offset: 0x00008842
	public virtual void vmethod_11()
	{
		this.vmethod_12(null);
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x00043A5C File Offset: 0x00041C5C
	public virtual void vmethod_12(string string_3)
	{
		if (this.FindForm_0 == null)
		{
			this.FindForm_0 = new FindForm(this);
		}
		if (string_3 != null)
		{
			this.FindForm_0.tbFind.Text = string_3;
		}
		else if (!this.GClass86_5.Boolean_2 && this.GClass86_5.GStruct2_0.int_1 == this.GClass86_5.GStruct2_1.int_1)
		{
			this.FindForm_0.tbFind.Text = this.GClass86_5.String_1;
		}
		this.FindForm_0.tbFind.SelectAll();
		this.FindForm_0.Show();
		this.FindForm_0.Focus();
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x0000A64B File Offset: 0x0000884B
	public virtual void vmethod_13()
	{
		this.vmethod_14(null);
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x00043B04 File Offset: 0x00041D04
	public virtual void vmethod_14(string string_3)
	{
		if (this.Boolean_9)
		{
			return;
		}
		if (this.ReplaceForm_0 == null)
		{
			this.ReplaceForm_0 = new ReplaceForm(this);
		}
		if (string_3 != null)
		{
			this.ReplaceForm_0.tbFind.Text = string_3;
		}
		else if (!this.GClass86_5.Boolean_2 && this.GClass86_5.GStruct2_0.int_1 == this.GClass86_5.GStruct2_1.int_1)
		{
			this.ReplaceForm_0.tbFind.Text = this.GClass86_5.String_1;
		}
		this.ReplaceForm_0.tbFind.SelectAll();
		this.ReplaceForm_0.Show();
		this.ReplaceForm_0.Focus();
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x0000A654 File Offset: 0x00008854
	public int method_23(int int_28)
	{
		if (int_28 < 0 || int_28 >= this.gclass99_0.Count)
		{
			throw new ArgumentOutOfRangeException("Line index out of range");
		}
		return this.gclass99_0[int_28].Count;
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x00043BB8 File Offset: 0x00041DB8
	public GClass86 method_24(int int_28)
	{
		if (int_28 < 0 || int_28 >= this.gclass99_0.Count)
		{
			throw new ArgumentOutOfRangeException("Line index out of range");
		}
		return new GClass86(this)
		{
			GStruct2_0 = new GStruct2(0, int_28),
			GStruct2_1 = new GStruct2(this.gclass99_0[int_28].Count, int_28)
		};
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x00043C14 File Offset: 0x00041E14
	public virtual void vmethod_15()
	{
		FastColoredTextBox.Class95 @class = new FastColoredTextBox.Class95();
		@class.fastColoredTextBox_0 = this;
		if (this.GClass86_5.Boolean_2)
		{
			this.GClass86_5.method_42();
		}
		if (!this.GClass86_5.Boolean_2)
		{
			@class.dataObject_0 = new DataObject();
			this.vmethod_16(@class.dataObject_0);
			Thread thread = new Thread(new ThreadStart(@class.method_0));
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
			thread.Join();
		}
	}

	// Token: 0x06000B61 RID: 2913 RVA: 0x00043C90 File Offset: 0x00041E90
	protected virtual void vmethod_16(DataObject dataObject_0)
	{
		string string_ = "<pre>" + new GClass72
		{
			Boolean_4 = false,
			Boolean_0 = false,
			Boolean_3 = true
		}.method_1(this.GClass86_5.method_6()) + "</pre>";
		dataObject_0.SetData(DataFormats.UnicodeText, true, this.GClass86_5.String_1);
		dataObject_0.SetData(DataFormats.Html, FastColoredTextBox.smethod_0(string_));
		dataObject_0.SetData(DataFormats.Rtf, new GClass73().method_1(this.GClass86_5.method_6()));
	}

	// Token: 0x06000B62 RID: 2914
	[DllImport("user32.dll")]
	private static extern IntPtr GetOpenClipboardWindow();

	// Token: 0x06000B63 RID: 2915
	[DllImport("user32.dll")]
	private static extern IntPtr CloseClipboard();

	// Token: 0x06000B64 RID: 2916 RVA: 0x00043D24 File Offset: 0x00041F24
	protected void method_25(DataObject dataObject_0)
	{
		try
		{
			FastColoredTextBox.CloseClipboard();
			Clipboard.SetDataObject(dataObject_0, true, 5, 100);
		}
		catch (ExternalException)
		{
		}
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x00043D58 File Offset: 0x00041F58
	public static MemoryStream smethod_0(string string_3)
	{
		Encoding utf = Encoding.UTF8;
		string format = "Version:0.9\r\nStartHTML:{0:000000}\r\nEndHTML:{1:000000}\r\nStartFragment:{2:000000}\r\nEndFragment:{3:000000}\r\n";
		string text = "<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=" + utf.WebName + "\">\r\n<title>HTML clipboard</title>\r\n</head>\r\n<body>\r\n<!--StartFragment-->";
		string text2 = "<!--EndFragment-->\r\n</body>\r\n</html>\r\n";
		string s = string.Format(format, new object[]
		{
			0,
			0,
			0,
			0
		});
		int byteCount = utf.GetByteCount(s);
		int byteCount2 = utf.GetByteCount(text);
		int byteCount3 = utf.GetByteCount(string_3);
		int byteCount4 = utf.GetByteCount(text2);
		string s2 = string.Format(format, new object[]
		{
			byteCount,
			byteCount + byteCount2 + byteCount3 + byteCount4,
			byteCount + byteCount2,
			byteCount + byteCount2 + byteCount3
		}) + text + string_3 + text2;
		return new MemoryStream(utf.GetBytes(s2));
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x00043E44 File Offset: 0x00042044
	public virtual void vmethod_17()
	{
		FastColoredTextBox.Class96 @class = new FastColoredTextBox.Class96();
		@class.fastColoredTextBox_0 = this;
		if (!this.GClass86_5.Boolean_2)
		{
			this.vmethod_15();
			this.vmethod_28();
			return;
		}
		if (this.Int32_14 == 1)
		{
			this.GClass86_5.method_2();
			this.vmethod_15();
			this.vmethod_28();
			return;
		}
		@class.dataObject_0 = new DataObject();
		this.vmethod_16(@class.dataObject_0);
		Thread thread = new Thread(new ThreadStart(@class.method_0));
		thread.SetApartmentState(ApartmentState.STA);
		thread.Start();
		thread.Join();
		if (this.GClass86_5.GStruct2_0.int_1 >= 0 && this.GClass86_5.GStruct2_0.int_1 < this.Int32_14)
		{
			int num = this.GClass86_5.GStruct2_0.int_1;
			this.method_135(new List<int>
			{
				num
			});
			this.GClass86_5.GStruct2_0 = new GStruct2(0, Math.Max(0, Math.Min(num, this.Int32_14 - 1)));
		}
	}

	// Token: 0x06000B67 RID: 2919 RVA: 0x00043F48 File Offset: 0x00042148
	public virtual void vmethod_18()
	{
		FastColoredTextBox.Class97 @class = new FastColoredTextBox.Class97();
		@class.string_0 = null;
		Thread thread = new Thread(new ThreadStart(@class.method_0));
		thread.SetApartmentState(ApartmentState.STA);
		thread.Start();
		thread.Join();
		if (this.eventHandler_4 != null)
		{
			GEventArgs12 geventArgs = new GEventArgs12
			{
				Boolean_0 = false,
				String_0 = @class.string_0
			};
			this.eventHandler_4(this, geventArgs);
			if (geventArgs.Boolean_0)
			{
				@class.string_0 = string.Empty;
			}
			else
			{
				@class.string_0 = geventArgs.String_0;
			}
		}
		if (!string.IsNullOrEmpty(@class.string_0))
		{
			this.vmethod_20(@class.string_0);
		}
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x0000A684 File Offset: 0x00008884
	public void method_26()
	{
		this.GClass86_5.method_2();
	}

	// Token: 0x06000B69 RID: 2921 RVA: 0x00043FF0 File Offset: 0x000421F0
	public void method_27()
	{
		if (this.gclass99_0.Count > 0)
		{
			this.GClass86_5.GStruct2_0 = new GStruct2(this.gclass99_0[this.gclass99_0.Count - 1].Count, this.gclass99_0.Count - 1);
		}
		else
		{
			this.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
		}
		this.method_49();
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x0000A691 File Offset: 0x00008891
	public void method_28()
	{
		this.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
		this.method_49();
	}

	// Token: 0x06000B6B RID: 2923 RVA: 0x00044060 File Offset: 0x00042260
	public virtual void vmethod_19()
	{
		this.GClass86_5.method_38();
		try
		{
			this.GClass86_5.method_2();
			this.vmethod_28();
			this.gclass99_0.GClass59_0.method_5();
			this.method_4();
		}
		finally
		{
			this.GClass86_5.method_39();
		}
	}

	// Token: 0x06000B6C RID: 2924 RVA: 0x000440C0 File Offset: 0x000422C0
	public void method_29()
	{
		for (int i = 0; i < this.GClass87_0.Length; i++)
		{
			this.GClass87_0[i] = null;
		}
	}

	// Token: 0x06000B6D RID: 2925 RVA: 0x000440EC File Offset: 0x000422EC
	public void method_30(StyleIndex styleIndex_0)
	{
		foreach (GClass81 gclass in this.gclass99_0)
		{
			gclass.method_0(styleIndex_0);
		}
		for (int i = 0; i < this.list_0.Count; i++)
		{
			this.method_129(i, GEnum17.Visible);
		}
		this.method_4();
	}

	// Token: 0x06000B6E RID: 2926 RVA: 0x0000A6AB File Offset: 0x000088AB
	public void method_31()
	{
		this.gclass99_0.GClass59_0.method_5();
	}

	// Token: 0x06000B6F RID: 2927 RVA: 0x0000A6BD File Offset: 0x000088BD
	public virtual void vmethod_20(string string_3)
	{
		this.vmethod_21(string_3, true);
	}

	// Token: 0x06000B70 RID: 2928 RVA: 0x0004415C File Offset: 0x0004235C
	public virtual void vmethod_21(string string_3, bool bool_37)
	{
		if (string_3 == null)
		{
			return;
		}
		if (string_3 == "\r")
		{
			string_3 = "\n";
		}
		this.gclass99_0.GClass59_0.method_4();
		try
		{
			if (!this.GClass86_5.Boolean_2)
			{
				this.gclass99_0.GClass59_0.vmethod_0(new GClass65(this.GClass99_0));
			}
			if (this.GClass99_0.Count > 0 && this.GClass86_5.Boolean_2 && this.GClass86_5.GStruct2_0.int_0 > this.method_23(this.GClass86_5.GStruct2_0.int_1) && this.Boolean_2)
			{
				this.method_38();
			}
			this.gclass99_0.GClass59_0.vmethod_0(new GClass63(this.GClass99_0, string_3));
			if (this.int_17 <= 0 && bool_37)
			{
				this.method_49();
			}
		}
		finally
		{
			this.gclass99_0.GClass59_0.method_3();
		}
		this.method_4();
	}

	// Token: 0x06000B71 RID: 2929 RVA: 0x0000A6C7 File Offset: 0x000088C7
	public virtual GClass86 vmethod_22(string string_3, GClass87 gclass87_0)
	{
		return this.vmethod_23(string_3, gclass87_0, true);
	}

	// Token: 0x06000B72 RID: 2930 RVA: 0x00044268 File Offset: 0x00042468
	public virtual GClass86 vmethod_23(string string_3, GClass87 gclass87_0, bool bool_37)
	{
		if (string_3 == null)
		{
			return null;
		}
		GStruct2 gstruct2_ = GStruct2.smethod_4(this.GClass86_5.GStruct2_0, this.GClass86_5.GStruct2_1) ? this.GClass86_5.GStruct2_1 : this.GClass86_5.GStruct2_0;
		this.vmethod_21(string_3, bool_37);
		GClass86 gclass = new GClass86(this, gstruct2_, this.GClass86_5.GStruct2_0)
		{
			Boolean_0 = this.GClass86_5.Boolean_0
		}.vmethod_0(this.GClass86_6);
		gclass.method_18(gclass87_0);
		return gclass;
	}

	// Token: 0x06000B73 RID: 2931 RVA: 0x000442F0 File Offset: 0x000424F0
	public virtual GClass86 vmethod_24(GClass86 gclass86_9, string string_3, GClass87 gclass87_0)
	{
		if (string_3 == null)
		{
			return null;
		}
		int num = this.method_92(this.GClass86_5.GStruct2_0);
		int num2 = this.method_92(this.GClass86_5.GStruct2_1);
		int num3 = gclass86_9.String_1.Length;
		int num4 = this.method_92(gclass86_9.GStruct2_0);
		this.GClass86_5.method_38();
		this.GClass86_5 = gclass86_9;
		GClass86 gclass = this.vmethod_22(string_3, gclass87_0);
		num3 = gclass.String_1.Length - num3;
		this.GClass86_5.GStruct2_0 = this.method_93(num + ((num >= num4) ? num3 : 0));
		this.GClass86_5.GStruct2_1 = this.method_93(num2 + ((num2 >= num4) ? num3 : 0));
		this.GClass86_5.method_39();
		return gclass;
	}

	// Token: 0x06000B74 RID: 2932 RVA: 0x0000A6D2 File Offset: 0x000088D2
	public virtual void vmethod_25(string string_3)
	{
		this.vmethod_26(string_3, null);
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x000443A8 File Offset: 0x000425A8
	public virtual void vmethod_26(string string_3, GClass87 gclass87_0)
	{
		if (string_3 == null)
		{
			return;
		}
		this.GClass86_5.Boolean_0 = false;
		GStruct2 gstruct2_ = this.GClass86_5.GStruct2_0;
		GStruct2 gstruct2_2 = this.GClass86_5.GStruct2_1;
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		try
		{
			if (this.gclass99_0.Count > 0)
			{
				this.GClass86_5.GStruct2_0 = new GStruct2(this.gclass99_0[this.gclass99_0.Count - 1].Count, this.gclass99_0.Count - 1);
			}
			else
			{
				this.GClass86_5.GStruct2_0 = new GStruct2(0, 0);
			}
			GStruct2 gstruct2_3 = this.GClass86_5.GStruct2_0;
			this.gclass99_0.GClass59_0.vmethod_0(new GClass63(this.GClass99_0, string_3));
			if (gclass87_0 != null)
			{
				new GClass86(this, gstruct2_3, this.GClass86_5.GStruct2_0).method_18(gclass87_0);
			}
		}
		finally
		{
			this.gclass99_0.GClass59_0.method_3();
			this.GClass86_5.GStruct2_0 = gstruct2_;
			this.GClass86_5.GStruct2_1 = gstruct2_2;
			this.GClass86_5.method_39();
		}
		this.method_4();
	}

	// Token: 0x06000B76 RID: 2934 RVA: 0x0000A6DC File Offset: 0x000088DC
	public int method_32(GClass87 gclass87_0)
	{
		return Array.IndexOf<GClass87>(this.GClass87_0, gclass87_0);
	}

	// Token: 0x06000B77 RID: 2935 RVA: 0x000444E4 File Offset: 0x000426E4
	public StyleIndex method_33(GClass87[] gclass87_0)
	{
		StyleIndex styleIndex = StyleIndex.None;
		foreach (GClass87 gclass87_ in gclass87_0)
		{
			int num = this.method_32(gclass87_);
			if (num >= 0)
			{
				styleIndex |= GClass86.smethod_0(num);
			}
		}
		return styleIndex;
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x00044520 File Offset: 0x00042720
	internal int method_34(GClass87 gclass87_0)
	{
		int num = this.method_32(gclass87_0);
		if (num < 0)
		{
			num = this.method_21(gclass87_0);
		}
		return num;
	}

	// Token: 0x06000B79 RID: 2937 RVA: 0x00044544 File Offset: 0x00042744
	public static SizeF smethod_1(Font font_2, char char_5)
	{
		Size size = TextRenderer.MeasureText("<" + char_5.ToString() + ">", font_2);
		Size size2 = TextRenderer.MeasureText("<>", font_2);
		return new SizeF((float)(size.Width - size2.Width + 1), (float)font_2.Height);
	}

	// Token: 0x06000B7A RID: 2938
	[DllImport("Imm32.dll")]
	public static extern IntPtr ImmGetContext(IntPtr intptr_1);

	// Token: 0x06000B7B RID: 2939
	[DllImport("Imm32.dll")]
	public static extern IntPtr ImmAssociateContext(IntPtr intptr_1, IntPtr intptr_2);

	// Token: 0x06000B7C RID: 2940 RVA: 0x00044598 File Offset: 0x00042798
	protected virtual void WndProc(ref Message m)
	{
		if ((m.Msg == 276 || m.Msg == 277) && m.WParam.ToInt32() != 8)
		{
			this.method_4();
		}
		base.WndProc(ref m);
		if (this.Boolean_25 && m.Msg == 641 && m.WParam.ToInt32() == 1)
		{
			FastColoredTextBox.ImmAssociateContext(base.Handle, this.intptr_0);
		}
	}

	// Token: 0x06000B7D RID: 2941 RVA: 0x00044618 File Offset: 0x00042818
	private void method_35()
	{
		if (!this.Boolean_21 && this.GClass77_0.Count > 0)
		{
			base.SuspendLayout();
			foreach (object obj in base.Controls)
			{
				Control item = (Control)obj;
				this.list_2.Add(item);
			}
			base.Controls.Clear();
		}
	}

	// Token: 0x06000B7E RID: 2942 RVA: 0x000446A0 File Offset: 0x000428A0
	private void method_36()
	{
		if (!this.Boolean_21 && this.GClass77_0.Count > 0)
		{
			foreach (Control value in this.list_2)
			{
				base.Controls.Add(value);
			}
			this.list_2.Clear();
			base.ResumeLayout(false);
			if (!this.Focused)
			{
				base.Focus();
			}
		}
	}

	// Token: 0x06000B7F RID: 2943 RVA: 0x00044730 File Offset: 0x00042930
	public void method_37(ScrollEventArgs scrollEventArgs_0, bool bool_37)
	{
		this.method_35();
		if (scrollEventArgs_0.ScrollOrientation == ScrollOrientation.VerticalScroll)
		{
			int num = scrollEventArgs_0.NewValue;
			if (bool_37)
			{
				num = (int)(Math.Ceiling(1.0 * (double)num / (double)this.Int32_2) * (double)this.Int32_2);
			}
			base.VerticalScroll.Value = Math.Max(base.VerticalScroll.Minimum, Math.Min(base.VerticalScroll.Maximum, num));
		}
		if (scrollEventArgs_0.ScrollOrientation == ScrollOrientation.HorizontalScroll)
		{
			base.HorizontalScroll.Value = Math.Max(base.HorizontalScroll.Minimum, Math.Min(base.HorizontalScroll.Maximum, scrollEventArgs_0.NewValue));
		}
		this.method_47();
		this.method_36();
		this.method_4();
		base.OnScroll(scrollEventArgs_0);
		this.vmethod_4();
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x0000A6EA File Offset: 0x000088EA
	protected virtual void OnScroll(ScrollEventArgs se)
	{
		this.method_37(se, true);
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x00044800 File Offset: 0x00042A00
	protected virtual void vmethod_27(char char_5)
	{
		this.gclass99_0.GClass59_0.method_4();
		try
		{
			if (!this.GClass86_5.Boolean_2)
			{
				this.gclass99_0.GClass59_0.vmethod_0(new GClass65(this.GClass99_0));
			}
			if (this.GClass86_5.Boolean_2 && this.GClass86_5.GStruct2_0.int_0 > this.method_23(this.GClass86_5.GStruct2_0.int_1) && this.Boolean_2)
			{
				this.method_38();
			}
			this.gclass99_0.GClass59_0.vmethod_0(new GClass62(this.GClass99_0, char_5));
		}
		finally
		{
			this.gclass99_0.GClass59_0.method_3();
		}
		this.method_4();
	}

	// Token: 0x06000B82 RID: 2946 RVA: 0x000448D0 File Offset: 0x00042AD0
	private void method_38()
	{
		int num = this.method_23(this.GClass86_5.GStruct2_0.int_1);
		int count = this.GClass86_5.GStruct2_0.int_0 - num;
		this.GClass86_5.method_38();
		try
		{
			this.GClass86_5.GStruct2_0 = new GStruct2(num, this.GClass86_5.GStruct2_0.int_1);
			this.gclass99_0.GClass59_0.vmethod_0(new GClass63(this.GClass99_0, new string(' ', count)));
		}
		finally
		{
			this.GClass86_5.method_39();
		}
	}

	// Token: 0x06000B83 RID: 2947 RVA: 0x0000A6F4 File Offset: 0x000088F4
	public virtual void vmethod_28()
	{
		if (!this.GClass86_5.Boolean_2)
		{
			this.gclass99_0.GClass59_0.vmethod_0(new GClass65(this.GClass99_0));
			this.method_4();
		}
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x00044974 File Offset: 0x00042B74
	public void method_39()
	{
		this.GClass86_5.method_42();
		this.gclass99_0.GClass59_0.vmethod_0(new GClass65(this.GClass99_0));
		if (this.GClass86_5.GStruct2_0.int_1 == 0 && !this.GClass86_5.vmethod_1())
		{
			return;
		}
		if (this.GClass86_5.GStruct2_0.int_1 > 0)
		{
			this.gclass99_0.GClass59_0.vmethod_0(new GClass62(this.GClass99_0, '\b'));
		}
		this.method_4();
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x000449FC File Offset: 0x00042BFC
	private void method_40()
	{
		if (!this.bool_10)
		{
			return;
		}
		this.bool_10 = false;
		this.Int32_7 = this.Int32_8;
		long num = (long)this.Int32_14 + (long)((ulong)this.uint_0) - 1L;
		int num2 = 2 + ((num > 0L) ? ((int)Math.Log10((double)num)) : 0);
		if (this.Int32_19 + 1 > num2)
		{
			num2 = this.Int32_19 + 1;
		}
		if (base.Created)
		{
			if (this.Boolean_10)
			{
				this.Int32_7 += num2 * this.Int32_4 + 8 + 1;
			}
			if (this.bool_11)
			{
				this.method_45(this.point_1.X, this.point_1.Y);
				this.bool_11 = false;
			}
		}
		else
		{
			this.bool_10 = true;
		}
		this.int_8 = 0;
		this.int_14 = this.method_43();
		int width;
		this.method_41(out width, ref this.int_14);
		this.Size_0 = new Size(width, this.int_8 + this.Padding_0.Top + this.Padding_0.Bottom);
		this.method_47();
	}

	// Token: 0x06000B86 RID: 2950 RVA: 0x00044B14 File Offset: 0x00042D14
	private void method_41(out int int_28, ref int int_29)
	{
		int_28 = this.Int32_7 + int_29 * this.Int32_4 + 2 + this.Padding_0.Left + this.Padding_0.Right;
		if (this.bool_19)
		{
			switch (this.GEnum11_0)
			{
			case GEnum11.WordWrapControlWidth:
			case GEnum11.CharWrapControlWidth:
				int_29 = Math.Min(int_29, (base.ClientSize.Width - this.Int32_7 - this.Padding_0.Left - this.Padding_0.Right) / this.Int32_4);
				int_28 = 0;
				return;
			case GEnum11.WordWrapPreferredWidth:
			case GEnum11.CharWrapPreferredWidth:
				int_29 = Math.Min(int_29, this.Int32_9);
				int_28 = this.Int32_7 + this.Int32_9 * this.Int32_4 + 2 + this.Padding_0.Left + this.Padding_0.Right;
				break;
			default:
				return;
			}
		}
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x00044C08 File Offset: 0x00042E08
	private void method_42(int int_28)
	{
		if (int_28 >= this.gclass99_0.Count)
		{
			return;
		}
		int count = this.gclass99_0[int_28].Count;
		if (this.int_14 < count && !this.Boolean_23)
		{
			this.int_14 = count;
		}
		int num;
		this.method_41(out num, ref count);
		if (this.Size_0.Width < num)
		{
			this.Size_0 = new Size(num, this.Size_0.Height);
		}
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x00044C84 File Offset: 0x00042E84
	private int method_43()
	{
		int num = 0;
		GClass99 gclass = this.gclass99_0;
		int count = gclass.Count;
		int int32_ = this.Int32_2;
		int top = this.Padding_0.Top;
		this.int_8 = top;
		for (int i = 0; i < count; i++)
		{
			int num2 = gclass.GClass99.\u200B\u206A\u206E\u200C\u202B\u202C\u206B\u202C\u202E\u202A\u200E\u200D\u202D\u206F\u206C\u206D\u200C\u206B\u200D\u202C\u202A\u200F\u202B\u206B\u200E\u206E\u200F\u202D\u200F\u200E\u200C\u206A\u206C\u200D\u202E\u206F\u206B\u202D\u206B\u206F\u202E(i);
			GStruct1 gstruct = this.list_0[i];
			if (num2 > num && gstruct.genum17_0 == GEnum17.Visible)
			{
				num = num2;
			}
			gstruct.int_0 = this.int_8;
			this.int_8 += gstruct.Int32_0 * int32_ + gstruct.int_1;
			this.list_0[i] = gstruct;
		}
		this.int_8 -= top;
		return num;
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x00044D48 File Offset: 0x00042F48
	private int method_44()
	{
		if (this.bool_19)
		{
			switch (this.genum11_0)
			{
			case GEnum11.WordWrapControlWidth:
			case GEnum11.CharWrapControlWidth:
				return base.ClientSize.Width;
			case GEnum11.WordWrapPreferredWidth:
			case GEnum11.CharWrapPreferredWidth:
				return this.Int32_7 + this.Int32_9 * this.Int32_4 + 2 + this.Padding_0.Left + this.Padding_0.Right;
			}
		}
		return int.MaxValue;
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x00044DC8 File Offset: 0x00042FC8
	private void method_45(int int_28, int int_29)
	{
		int num = 0;
		bool bool_ = false;
		int_29 = Math.Min(this.Int32_14 - 1, int_29);
		switch (this.GEnum11_0)
		{
		case GEnum11.WordWrapControlWidth:
			num = (base.ClientSize.Width - this.Int32_7 - this.Padding_0.Left - this.Padding_0.Right) / this.Int32_4;
			break;
		case GEnum11.WordWrapPreferredWidth:
			num = this.Int32_9;
			break;
		case GEnum11.CharWrapControlWidth:
			num = (base.ClientSize.Width - this.Int32_7 - this.Padding_0.Left - this.Padding_0.Right) / this.Int32_4;
			bool_ = true;
			break;
		case GEnum11.CharWrapPreferredWidth:
			num = this.Int32_9;
			bool_ = true;
			break;
		}
		for (int i = int_28; i <= int_29; i++)
		{
			if (this.gclass99_0.vmethod_2(i))
			{
				if (!this.bool_19)
				{
					this.list_0[i].List_0.Clear();
				}
				else
				{
					GStruct1 gstruct = this.list_0[i];
					gstruct.int_2 = (this.Boolean_1 ? (this.gclass99_0[i].Int32_2 + this.Int32_0) : this.Int32_0);
					if (this.GEnum11_0 == GEnum11.Custom)
					{
						if (this.eventHandler_21 != null)
						{
							this.eventHandler_21(this, new GEventArgs13(gstruct.List_0, this.Boolean_25, this.gclass99_0[i]));
						}
					}
					else
					{
						FastColoredTextBox.smethod_2(gstruct.List_0, num, num - gstruct.int_2, this.Boolean_25, bool_, this.gclass99_0[i]);
					}
					this.list_0[i] = gstruct;
				}
			}
		}
		this.bool_10 = true;
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x00044FAC File Offset: 0x000431AC
	public static void smethod_2(List<int> list_3, int int_28, int int_29, bool bool_37, bool bool_38, GClass81 gclass81_0)
	{
		if (int_29 < 1)
		{
			int_29 = 1;
		}
		if (int_28 < 1)
		{
			int_28 = 1;
		}
		int num = 0;
		int num2 = 0;
		list_3.Clear();
		for (int i = 0; i < gclass81_0.Count - 1; i++)
		{
			char c = gclass81_0[i].char_0;
			if (bool_38)
			{
				num2 = i + 1;
			}
			else if (bool_37 && FastColoredTextBox.smethod_3(c))
			{
				num2 = i;
			}
			else if (!char.IsLetterOrDigit(c) && c != '_' && c != '\'' && c != '\u00a0' && ((c != '.' && c != ',') || !char.IsDigit(gclass81_0[i + 1].char_0)))
			{
				num2 = Math.Min(i + 1, gclass81_0.Count - 1);
			}
			num++;
			if (num == int_28)
			{
				if (num2 == 0 || (list_3.Count > 0 && num2 == list_3[list_3.Count - 1]))
				{
					num2 = i + 1;
				}
				list_3.Add(num2);
				num = 1 + i - num2;
				int_28 = int_29;
			}
		}
	}

	// Token: 0x06000B8C RID: 2956 RVA: 0x00045098 File Offset: 0x00043298
	public static bool smethod_3(char char_5)
	{
		int num = Convert.ToInt32(char_5);
		return (num >= 13056 && num <= 13311) || (num >= 65072 && num <= 65103) || (num >= 63744 && num <= 64255) || (num >= 11904 && num <= 12031) || (num >= 12736 && num <= 12783) || (num >= 19968 && num <= 40959) || (num >= 13312 && num <= 19903) || (num >= 12800 && num <= 13055) || (num >= 9312 && num <= 9471) || (num >= 12352 && num <= 12447) || (num >= 12032 && num <= 12255) || (num >= 12704 && num <= 12735) || (num >= 19904 && num <= 19967) || (num >= 12544 && num <= 12591) || (num >= 12448 && num <= 12543) || (num >= 12784 && num <= 12799) || (num >= 12272 && num <= 12287) || (num >= 4352 && num <= 4607) || (num >= 43360 && num <= 43391) || (num >= 55216 && num <= 55295) || (num >= 12592 && num <= 12687) || (num >= 44032 && num <= 55215);
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x0000A724 File Offset: 0x00008924
	protected virtual void OnClientSizeChanged(EventArgs e)
	{
		base.OnClientSizeChanged(e);
		if (this.Boolean_23)
		{
			this.method_12(false, true);
			this.method_4();
		}
		this.vmethod_4();
		this.method_47();
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x0004523C File Offset: 0x0004343C
	internal void method_46(Rectangle rectangle_1)
	{
		this.method_35();
		int value = base.VerticalScroll.Value;
		int num = base.VerticalScroll.Value;
		int num2 = base.HorizontalScroll.Value;
		if (rectangle_1.Bottom > base.ClientRectangle.Height)
		{
			num += rectangle_1.Bottom - base.ClientRectangle.Height;
		}
		else if (rectangle_1.Top < 0)
		{
			num += rectangle_1.Top;
		}
		if (rectangle_1.Right > base.ClientRectangle.Width)
		{
			num2 += rectangle_1.Right - base.ClientRectangle.Width;
		}
		else if (rectangle_1.Left < this.Int32_7)
		{
			num2 += rectangle_1.Left - this.Int32_7;
		}
		if (!this.Boolean_22)
		{
			num = 0;
		}
		num = Math.Max(base.VerticalScroll.Minimum, num);
		num2 = Math.Max(base.HorizontalScroll.Minimum, num2);
		try
		{
			if (base.VerticalScroll.Visible || !this.Boolean_21)
			{
				base.VerticalScroll.Value = Math.Min(num, base.VerticalScroll.Maximum);
			}
			if (base.HorizontalScroll.Visible || !this.Boolean_21)
			{
				base.HorizontalScroll.Value = Math.Min(num2, base.HorizontalScroll.Maximum);
			}
		}
		catch (ArgumentOutOfRangeException)
		{
		}
		this.method_47();
		this.method_36();
		if (value != base.VerticalScroll.Value)
		{
			this.vmethod_4();
		}
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x0000A74F File Offset: 0x0000894F
	public void method_47()
	{
		if (this.Boolean_21)
		{
			this.method_48();
		}
		else
		{
			base.PerformLayout();
		}
		if (base.IsHandleCreated)
		{
			base.BeginInvoke(new MethodInvoker(this.vmethod_29));
		}
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x000453D0 File Offset: 0x000435D0
	private void method_48()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new MethodInvoker(this.method_48));
			return;
		}
		base.AutoScrollMinSize -= new Size(1, 0);
		base.AutoScrollMinSize += new Size(1, 0);
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x0000A783 File Offset: 0x00008983
	protected virtual void vmethod_29()
	{
		if (this.eventHandler_20 != null)
		{
			this.eventHandler_20(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x0004542C File Offset: 0x0004362C
	public void method_49()
	{
		this.method_4();
		this.method_40();
		Point location = this.method_95(this.GClass86_5.GStruct2_0);
		location.Offset(-this.Int32_4, 0);
		this.method_46(new Rectangle(location, new Size(2 * this.Int32_4, 2 * this.Int32_2)));
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x00045488 File Offset: 0x00043688
	public void method_50()
	{
		this.method_4();
		base.HorizontalScroll.Value = 0;
		this.Size_0 -= new Size(1, 0);
		this.Size_0 += new Size(1, 0);
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x000454D8 File Offset: 0x000436D8
	public void method_51()
	{
		if (this.list_0[this.GClass86_5.GStruct2_1.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_101(this.GClass86_5.GStruct2_1.int_1);
		}
		if (this.list_0[this.GClass86_5.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_101(this.GClass86_5.GStruct2_0.int_1);
		}
		this.method_40();
		this.method_46(new Rectangle(this.method_95(new GStruct2(0, this.GClass86_5.GStruct2_1.int_1)), new Size(2 * this.Int32_4, 2 * this.Int32_2)));
		Point location = this.method_95(this.GClass86_5.GStruct2_0);
		Point point = this.method_95(this.GClass86_5.GStruct2_1);
		location.Offset(-this.Int32_4, -base.ClientSize.Height / 2);
		this.method_46(new Rectangle(location, new Size(Math.Abs(point.X - location.X), base.ClientSize.Height)));
		this.method_4();
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x0000A79E File Offset: 0x0000899E
	public void method_52(GClass86 gclass86_9)
	{
		this.method_53(gclass86_9, false);
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x00045614 File Offset: 0x00043814
	public void method_53(GClass86 gclass86_9, bool bool_37)
	{
		gclass86_9 = gclass86_9.method_6();
		gclass86_9.method_40();
		gclass86_9.GStruct2_1 = new GStruct2(gclass86_9.GStruct2_1.int_0, Math.Min(gclass86_9.GStruct2_1.int_1, gclass86_9.GStruct2_0.int_1 + base.ClientSize.Height / this.Int32_2));
		if (this.list_0[gclass86_9.GStruct2_1.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_101(gclass86_9.GStruct2_1.int_1);
		}
		if (this.list_0[gclass86_9.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_101(gclass86_9.GStruct2_0.int_1);
		}
		this.method_40();
		int height = (1 + gclass86_9.GStruct2_1.int_1 - gclass86_9.GStruct2_0.int_1) * this.Int32_2;
		Point location = this.method_95(new GStruct2(0, gclass86_9.GStruct2_0.int_1));
		if (bool_37)
		{
			location.Offset(0, -base.ClientSize.Height / 2);
			height = base.ClientSize.Height;
		}
		this.method_46(new Rectangle(location, new Size(2 * this.Int32_4, height)));
		this.method_4();
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x0004575C File Offset: 0x0004395C
	protected virtual void OnKeyUp(KeyEventArgs e)
	{
		base.OnKeyUp(e);
		if (e.KeyCode == Keys.ShiftKey)
		{
			this.keys_0 &= ~Keys.Shift;
		}
		if (e.KeyCode == Keys.Alt)
		{
			this.keys_0 &= ~Keys.Alt;
		}
		if (e.KeyCode == Keys.ControlKey)
		{
			this.keys_0 &= ~Keys.Control;
		}
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x000457C8 File Offset: 0x000439C8
	protected virtual void OnKeyDown(KeyEventArgs e)
	{
		if (this.bool_36)
		{
			return;
		}
		base.OnKeyDown(e);
		if (this.Focused)
		{
			this.keys_0 = e.Modifiers;
		}
		this.bool_2 = false;
		if (e.Handled)
		{
			this.bool_2 = true;
			return;
		}
		if (this.vmethod_30(e.KeyData))
		{
			return;
		}
		e.Handled = true;
		this.method_49();
		this.method_4();
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x0000A7A8 File Offset: 0x000089A8
	protected virtual bool ProcessDialogKey(Keys keyData)
	{
		if ((keyData & Keys.Alt) > Keys.None && this.GClass79_0.ContainsKey(keyData))
		{
			this.vmethod_30(keyData);
			return true;
		}
		return base.ProcessDialogKey(keyData);
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x00045834 File Offset: 0x00043A34
	public virtual bool vmethod_30(Keys keys_1)
	{
		KeyEventArgs keyEventArgs = new KeyEventArgs(keys_1);
		if (keyEventArgs.KeyCode == Keys.Tab && !this.Boolean_3)
		{
			return false;
		}
		if (this.gclass84_0 != null && (!this.GClass79_0.ContainsKey(keys_1) || (this.GClass79_0[keys_1] != FCTBAction.MacroExecute && this.GClass79_0[keys_1] != FCTBAction.MacroRecord)))
		{
			this.gclass84_0.method_4(keys_1);
		}
		if (this.GClass79_0.ContainsKey(keys_1))
		{
			FCTBAction fctbaction = this.GClass79_0[keys_1];
			this.method_54(fctbaction);
			if (FastColoredTextBox.dictionary_3.ContainsKey(fctbaction))
			{
				return true;
			}
			if (keys_1 == Keys.Tab || keys_1 == (Keys.LButton | Keys.Back | Keys.Shift))
			{
				this.bool_2 = true;
				return true;
			}
		}
		else
		{
			if (keyEventArgs.KeyCode == Keys.Alt)
			{
				return true;
			}
			if ((keyEventArgs.Modifiers & Keys.Control) != Keys.None)
			{
				return true;
			}
			if ((keyEventArgs.Modifiers & Keys.Alt) != Keys.None)
			{
				if ((Control.MouseButtons & MouseButtons.Left) != MouseButtons.None)
				{
					this.vmethod_50();
				}
				return true;
			}
			if (keyEventArgs.KeyCode == Keys.ShiftKey)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x00045934 File Offset: 0x00043B34
	private void method_54(FCTBAction fctbaction_0)
	{
		switch (fctbaction_0)
		{
		case FCTBAction.AutoIndentChars:
			if (!this.GClass86_5.Boolean_1)
			{
				this.method_63(this.GClass86_5.GStruct2_0.int_1);
				return;
			}
			break;
		case FCTBAction.BookmarkLine:
			this.vmethod_32(this.GClass86_5.GStruct2_0.int_1);
			return;
		case FCTBAction.ClearHints:
			this.method_1();
			if (this.GClass84_0 != null)
			{
				this.GClass84_0.Boolean_1 = false;
				return;
			}
			break;
		case FCTBAction.ClearWordLeft:
			if (!this.method_61('\b'))
			{
				if (!this.GClass86_5.Boolean_1)
				{
					if (!this.GClass86_5.Boolean_2)
					{
						this.vmethod_28();
					}
					this.GClass86_5.method_48(true);
					if (!this.GClass86_5.Boolean_1)
					{
						this.vmethod_28();
					}
				}
				this.method_62('\b');
				return;
			}
			break;
		case FCTBAction.ClearWordRight:
			if (!this.method_61('ÿ'))
			{
				if (!this.GClass86_5.Boolean_1)
				{
					if (!this.GClass86_5.Boolean_2)
					{
						this.vmethod_28();
					}
					this.GClass86_5.method_49(true, false);
					if (!this.GClass86_5.Boolean_1)
					{
						this.vmethod_28();
					}
				}
				this.method_62('ÿ');
				return;
			}
			break;
		case FCTBAction.CommentSelected:
			this.method_59();
			return;
		case FCTBAction.Copy:
			this.vmethod_15();
			return;
		case FCTBAction.Cut:
			if (!this.GClass86_5.Boolean_1)
			{
				this.vmethod_17();
				return;
			}
			break;
		case FCTBAction.DeleteCharRight:
			if (!this.GClass86_5.Boolean_1 && !this.method_61('ÿ'))
			{
				if (!this.GClass86_5.Boolean_2)
				{
					this.vmethod_28();
				}
				else
				{
					if (this[this.GClass86_5.GStruct2_0.int_1].Int32_2 == this[this.GClass86_5.GStruct2_0.int_1].Count)
					{
						this.method_67();
					}
					if (!this.GClass86_5.method_54() && this.GClass86_5.vmethod_1())
					{
						int num = this.GClass86_5.GStruct2_0.int_1;
						this.vmethod_27('\b');
						if (num != this.GClass86_5.GStruct2_0.int_1 && this.Boolean_18 && this.GClass86_5.GStruct2_0.int_0 > 0)
						{
							this.method_67();
						}
					}
				}
				if (this.Boolean_28)
				{
					this.method_63(this.GClass86_5.GStruct2_0.int_1);
				}
				this.method_62('ÿ');
				return;
			}
			break;
		case FCTBAction.FindChar:
			this.bool_33 = true;
			return;
		case FCTBAction.FindDialog:
			this.vmethod_11();
			return;
		case FCTBAction.FindNext:
			if (this.FindForm_0 != null && !(this.FindForm_0.tbFind.Text == ""))
			{
				this.FindForm_0.vmethod_0(this.FindForm_0.tbFind.Text);
				return;
			}
			this.vmethod_11();
			return;
		case FCTBAction.GoDown:
			this.GClass86_5.method_14(false);
			this.method_50();
			return;
		case FCTBAction.GoDownWithSelection:
			this.GClass86_5.method_14(true);
			this.method_50();
			return;
		case FCTBAction.GoDown_ColumnSelectionMode:
			this.vmethod_50();
			if (this.GClass86_5.Boolean_0)
			{
				this.GClass86_5.method_60();
			}
			this.method_4();
			return;
		case FCTBAction.GoEnd:
			this.GClass86_5.method_17(false);
			return;
		case FCTBAction.GoEndWithSelection:
			this.GClass86_5.method_17(true);
			return;
		case FCTBAction.GoFirstLine:
			this.GClass86_5.method_50(false);
			return;
		case FCTBAction.GoFirstLineWithSelection:
			this.GClass86_5.method_50(true);
			return;
		case FCTBAction.GoHome:
			this.method_58(false);
			this.method_50();
			return;
		case FCTBAction.GoHomeWithSelection:
			this.method_58(true);
			this.method_50();
			return;
		case FCTBAction.GoLastLine:
			this.GClass86_5.method_51(false);
			return;
		case FCTBAction.GoLastLineWithSelection:
			this.GClass86_5.method_51(true);
			return;
		case FCTBAction.GoLeft:
			this.GClass86_5.method_10(false);
			return;
		case FCTBAction.GoLeftWithSelection:
			this.GClass86_5.method_10(true);
			return;
		case FCTBAction.GoLeft_ColumnSelectionMode:
			this.vmethod_50();
			if (this.GClass86_5.Boolean_0)
			{
				this.GClass86_5.method_63();
			}
			this.method_4();
			return;
		case FCTBAction.GoPageDown:
			this.GClass86_5.method_15(false);
			this.method_50();
			return;
		case FCTBAction.GoPageDownWithSelection:
			this.GClass86_5.method_15(true);
			this.method_50();
			return;
		case FCTBAction.GoPageUp:
			this.GClass86_5.method_13(false);
			this.method_50();
			return;
		case FCTBAction.GoPageUpWithSelection:
			this.GClass86_5.method_13(true);
			this.method_50();
			return;
		case FCTBAction.GoRight:
			this.GClass86_5.method_11(false);
			return;
		case FCTBAction.GoRightWithSelection:
			this.GClass86_5.method_11(true);
			return;
		case FCTBAction.GoRight_ColumnSelectionMode:
			this.vmethod_50();
			if (this.GClass86_5.Boolean_0)
			{
				this.GClass86_5.method_62();
			}
			this.method_4();
			return;
		case FCTBAction.GoToDialog:
			this.method_131();
			return;
		case FCTBAction.GoNextBookmark:
			this.method_56(this.GClass86_5.GStruct2_0.int_1);
			return;
		case FCTBAction.GoPrevBookmark:
			this.method_57(this.GClass86_5.GStruct2_0.int_1);
			return;
		case FCTBAction.GoUp:
			this.GClass86_5.method_12(false);
			this.method_50();
			return;
		case FCTBAction.GoUpWithSelection:
			this.GClass86_5.method_12(true);
			this.method_50();
			return;
		case FCTBAction.GoUp_ColumnSelectionMode:
			this.vmethod_50();
			if (this.GClass86_5.Boolean_0)
			{
				this.GClass86_5.method_61();
			}
			this.method_4();
			return;
		case FCTBAction.GoWordLeft:
			this.GClass86_5.method_48(false);
			return;
		case FCTBAction.GoWordLeftWithSelection:
			this.GClass86_5.method_48(true);
			return;
		case FCTBAction.GoWordRight:
			this.GClass86_5.method_49(false, true);
			return;
		case FCTBAction.GoWordRightWithSelection:
			this.GClass86_5.method_49(true, true);
			return;
		case FCTBAction.IndentIncrease:
			if (!this.GClass86_5.Boolean_1)
			{
				GClass86 gclass = this.GClass86_5.method_6();
				bool flag = GStruct2.smethod_4(gclass.GStruct2_0, gclass.GStruct2_1);
				gclass.method_40();
				int int32_ = this[gclass.GStruct2_0.int_1].Int32_2;
				if (gclass.GStruct2_0.int_1 == gclass.GStruct2_1.int_1 && (gclass.GStruct2_0.int_0 > int32_ || gclass.GStruct2_1.int_0 != this[gclass.GStruct2_0.int_1].Count) && gclass.GStruct2_1.int_0 > int32_)
				{
					this.vmethod_41('\t', Keys.None);
					return;
				}
				this.vmethod_69();
				if (gclass.GStruct2_0.int_1 == gclass.GStruct2_1.int_1 && !gclass.Boolean_2)
				{
					this.GClass86_5 = new GClass86(this, this[gclass.GStruct2_0.int_1].Int32_2, gclass.GStruct2_1.int_1, this[gclass.GStruct2_0.int_1].Count, gclass.GStruct2_1.int_1);
					if (flag)
					{
						this.GClass86_5.method_41();
						return;
					}
				}
			}
			break;
		case FCTBAction.IndentDecrease:
			if (!this.GClass86_5.Boolean_1)
			{
				GClass86 gclass2 = this.GClass86_5.method_6();
				if (gclass2.GStruct2_0.int_1 == gclass2.GStruct2_1.int_1)
				{
					GClass81 gclass3 = this[gclass2.GStruct2_0.int_1];
					if (gclass2.GStruct2_0.int_0 == 0 && gclass2.GStruct2_1.int_0 == gclass3.Count)
					{
						this.GClass86_5 = new GClass86(this, gclass3.Int32_2, gclass2.GStruct2_0.int_1, gclass3.Count, gclass2.GStruct2_0.int_1);
					}
					else if (gclass2.GStruct2_0.int_0 == gclass3.Count && gclass2.GStruct2_1.int_0 == 0)
					{
						this.GClass86_5 = new GClass86(this, gclass3.Count, gclass2.GStruct2_0.int_1, gclass3.Int32_2, gclass2.GStruct2_0.int_1);
					}
				}
				this.vmethod_70();
				return;
			}
			break;
		case FCTBAction.LowerCase:
			if (!this.GClass86_5.Boolean_1)
			{
				this.vmethod_37();
				return;
			}
			break;
		case FCTBAction.MacroExecute:
			if (this.GClass84_0 != null)
			{
				this.GClass84_0.Boolean_1 = false;
				this.GClass84_0.method_0();
				return;
			}
			break;
		case FCTBAction.MacroRecord:
			if (this.GClass84_0 != null)
			{
				if (this.GClass84_0.Boolean_0)
				{
					this.GClass84_0.Boolean_1 = !this.GClass84_0.Boolean_1;
				}
				if (this.GClass84_0.Boolean_1)
				{
					this.GClass84_0.method_3();
					return;
				}
			}
			break;
		case FCTBAction.MoveSelectedLinesDown:
			if (!this.GClass86_5.Boolean_0)
			{
				this.vmethod_34();
				return;
			}
			break;
		case FCTBAction.MoveSelectedLinesUp:
			if (!this.GClass86_5.Boolean_0)
			{
				this.vmethod_35();
				return;
			}
			break;
		case FCTBAction.NavigateBackward:
			this.method_17();
			return;
		case FCTBAction.NavigateForward:
			this.method_16();
			return;
		case FCTBAction.Paste:
			if (!this.GClass86_5.Boolean_1)
			{
				this.vmethod_18();
				return;
			}
			break;
		case FCTBAction.Redo:
			if (!this.Boolean_9)
			{
				this.vmethod_48();
				return;
			}
			break;
		case FCTBAction.ReplaceDialog:
			this.vmethod_13();
			return;
		case FCTBAction.ReplaceMode:
			if (!this.Boolean_9)
			{
				this.bool_6 = !this.bool_6;
				return;
			}
			break;
		case FCTBAction.ScrollDown:
			this.method_78(1, -1);
			return;
		case FCTBAction.ScrollUp:
			this.method_78(1, 1);
			return;
		case FCTBAction.SelectAll:
			this.GClass86_5.method_2();
			return;
		case FCTBAction.UnbookmarkLine:
			this.vmethod_33(this.GClass86_5.GStruct2_0.int_1);
			return;
		case FCTBAction.Undo:
			if (!this.Boolean_9)
			{
				this.vmethod_47();
				return;
			}
			break;
		case FCTBAction.UpperCase:
			if (!this.GClass86_5.Boolean_1)
			{
				this.vmethod_36();
				return;
			}
			break;
		case FCTBAction.ZoomIn:
			this.method_79(2);
			return;
		case FCTBAction.ZoomNormal:
			this.method_55();
			return;
		case FCTBAction.ZoomOut:
			this.method_79(-2);
			return;
		case FCTBAction.CustomAction1:
		case FCTBAction.CustomAction2:
		case FCTBAction.CustomAction3:
		case FCTBAction.CustomAction4:
		case FCTBAction.CustomAction5:
		case FCTBAction.CustomAction6:
		case FCTBAction.CustomAction7:
		case FCTBAction.CustomAction8:
		case FCTBAction.CustomAction9:
		case FCTBAction.CustomAction10:
		case FCTBAction.CustomAction11:
		case FCTBAction.CustomAction12:
		case FCTBAction.CustomAction13:
		case FCTBAction.CustomAction14:
		case FCTBAction.CustomAction15:
		case FCTBAction.CustomAction16:
		case FCTBAction.CustomAction17:
		case FCTBAction.CustomAction18:
		case FCTBAction.CustomAction19:
		case FCTBAction.CustomAction20:
			this.vmethod_31(new GEventArgs17(fctbaction_0));
			break;
		default:
			return;
		}
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0000A7D3 File Offset: 0x000089D3
	protected virtual void vmethod_31(GEventArgs17 geventArgs17_0)
	{
		if (this.eventHandler_19 != null)
		{
			this.eventHandler_19(this, geventArgs17_0);
		}
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x0000A7EA File Offset: 0x000089EA
	private void method_55()
	{
		this.Int32_21 = 100;
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x00046318 File Offset: 0x00044518
	public bool method_56(int int_28)
	{
		GClass58 gclass = null;
		int num = int.MaxValue;
		GClass58 gclass2 = null;
		int num2 = int.MaxValue;
		foreach (GClass58 gclass3 in this.gclass56_0)
		{
			if (gclass3.Int32_0 < num2)
			{
				num2 = gclass3.Int32_0;
				gclass2 = gclass3;
			}
			if (gclass3.Int32_0 > int_28 && gclass3.Int32_0 < num)
			{
				num = gclass3.Int32_0;
				gclass = gclass3;
			}
		}
		if (gclass != null)
		{
			gclass.vmethod_0();
			return true;
		}
		if (gclass2 != null)
		{
			gclass2.vmethod_0();
			return true;
		}
		return false;
	}

	// Token: 0x06000B9F RID: 2975 RVA: 0x000463C0 File Offset: 0x000445C0
	public bool method_57(int int_28)
	{
		GClass58 gclass = null;
		int num = -1;
		GClass58 gclass2 = null;
		int num2 = -1;
		foreach (GClass58 gclass3 in this.gclass56_0)
		{
			if (gclass3.Int32_0 > num2)
			{
				num2 = gclass3.Int32_0;
				gclass2 = gclass3;
			}
			if (gclass3.Int32_0 < int_28 && gclass3.Int32_0 > num)
			{
				num = gclass3.Int32_0;
				gclass = gclass3;
			}
		}
		if (gclass != null)
		{
			gclass.vmethod_0();
			return true;
		}
		if (gclass2 != null)
		{
			gclass2.vmethod_0();
			return true;
		}
		return false;
	}

	// Token: 0x06000BA0 RID: 2976 RVA: 0x0000A7F4 File Offset: 0x000089F4
	public virtual void vmethod_32(int int_28)
	{
		if (!this.gclass56_0.GClass56.\u206B\u206C\u200F\u206F\u200F\u202D\u202C\u200F\u200C\u206B\u202C\u200C\u200C\u200B\u206D\u206F\u206A\u206C\u200C\u200E\u200E\u206C\u200E\u206D\u206F\u202D\u202A\u200C\u200B\u202E\u206E\u206D\u202A\u200E\u202A\u202A\u200C\u206B\u206C\u202E\u202E(int_28))
		{
			this.gclass56_0.GClass56.\u202B\u206E\u202B\u202C\u200F\u200D\u206D\u206D\u202E\u202E\u202C\u202B\u200C\u202B\u206A\u206A\u202E\u202E\u202D\u200E\u206A\u202E\u200C\u206A\u206B\u202B\u202B\u202A\u206E\u200F\u202C\u202B\u202A\u200C\u206D\u206D\u206A\u202D\u206E\u206C\u202E(int_28);
		}
	}

	// Token: 0x06000BA1 RID: 2977 RVA: 0x0000A810 File Offset: 0x00008A10
	public virtual void vmethod_33(int int_28)
	{
		this.gclass56_0.GClass56.\u202E\u200F\u206E\u200D\u202D\u202A\u200B\u202A\u200E\u202B\u202C\u206B\u206D\u200C\u200D\u202E\u206B\u206C\u206C\u200D\u206C\u206E\u202A\u206E\u200F\u202E\u206B\u206F\u206B\u206A\u200E\u202C\u200E\u202D\u200C\u202A\u200C\u200B\u206E\u200F\u202E(int_28);
	}

	// Token: 0x06000BA2 RID: 2978 RVA: 0x00046460 File Offset: 0x00044660
	public virtual void vmethod_34()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		this.GClass86_5.method_42();
		if (this.GClass86_5.Boolean_1)
		{
			this.GClass86_5 = gclass;
			return;
		}
		int int_ = this.GClass86_5.GStruct2_0.int_1;
		if (this.GClass86_5.GStruct2_1.int_1 >= this.Int32_14 - 1)
		{
			this.GClass86_5 = gclass;
			return;
		}
		string string_ = this.String_5;
		List<int> list = new List<int>();
		for (int i = this.GClass86_5.GStruct2_0.int_1; i <= this.GClass86_5.GStruct2_1.int_1; i++)
		{
			list.Add(i);
		}
		this.method_135(list);
		this.GClass86_5.GStruct2_0 = new GStruct2(this.method_23(int_), int_);
		this.String_5 = "\n" + string_;
		this.GClass86_5.GStruct2_0 = new GStruct2(gclass.GStruct2_0.int_0, gclass.GStruct2_0.int_1 + 1);
		this.GClass86_5.GStruct2_1 = new GStruct2(gclass.GStruct2_1.int_0, gclass.GStruct2_1.int_1 + 1);
	}

	// Token: 0x06000BA3 RID: 2979 RVA: 0x00046594 File Offset: 0x00044794
	public virtual void vmethod_35()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		this.GClass86_5.method_42();
		if (this.GClass86_5.Boolean_1)
		{
			this.GClass86_5 = gclass;
			return;
		}
		int num = this.GClass86_5.GStruct2_0.int_1;
		if (num == 0)
		{
			this.GClass86_5 = gclass;
			return;
		}
		string string_ = this.String_5;
		List<int> list = new List<int>();
		for (int i = this.GClass86_5.GStruct2_0.int_1; i <= this.GClass86_5.GStruct2_1.int_1; i++)
		{
			list.Add(i);
		}
		this.method_135(list);
		this.GClass86_5.GStruct2_0 = new GStruct2(0, num - 1);
		this.String_5 = string_ + "\n";
		this.GClass86_5.GStruct2_0 = new GStruct2(gclass.GStruct2_0.int_0, gclass.GStruct2_0.int_1 - 1);
		this.GClass86_5.GStruct2_1 = new GStruct2(gclass.GStruct2_1.int_0, gclass.GStruct2_1.int_1 - 1);
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x000466AC File Offset: 0x000448AC
	private void method_58(bool bool_37)
	{
		this.GClass86_5.method_38();
		try
		{
			int int_ = this.GClass86_5.GStruct2_0.int_1;
			int int32_ = this[int_].Int32_2;
			if (this.GClass86_5.GStruct2_0.int_0 <= int32_)
			{
				this.GClass86_5.method_16(bool_37);
			}
			else
			{
				this.GClass86_5.method_16(bool_37);
				for (int i = 0; i < int32_; i++)
				{
					this.GClass86_5.method_11(bool_37);
				}
			}
		}
		finally
		{
			this.GClass86_5.method_39();
		}
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x00046748 File Offset: 0x00044948
	public virtual void vmethod_36()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		this.String_5 = this.String_5.ToUpper();
		this.GClass86_5.GStruct2_0 = gclass.GStruct2_0;
		this.GClass86_5.GStruct2_1 = gclass.GStruct2_1;
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x00046794 File Offset: 0x00044994
	public virtual void vmethod_37()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		this.String_5 = this.String_5.ToLower();
		this.GClass86_5.GStruct2_0 = gclass.GStruct2_0;
		this.GClass86_5.GStruct2_1 = gclass.GStruct2_1;
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x000467E0 File Offset: 0x000449E0
	public virtual void vmethod_38()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		this.String_5 = Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.String_5.ToLower());
		this.GClass86_5.GStruct2_0 = gclass.GStruct2_0;
		this.GClass86_5.GStruct2_1 = gclass.GStruct2_1;
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x00046840 File Offset: 0x00044A40
	public virtual void vmethod_39()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		string input = this.String_5.ToLower();
		Regex regex = new Regex("(^\\S)|[\\.\\?!:]\\s+(\\S)", RegexOptions.ExplicitCapture);
		this.String_5 = regex.Replace(input, new MatchEvaluator(FastColoredTextBox.Class98.<>9.method_0));
		this.GClass86_5.GStruct2_0 = gclass.GStruct2_0;
		this.GClass86_5.GStruct2_1 = gclass.GStruct2_1;
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x0000A81F File Offset: 0x00008A1F
	public void method_59()
	{
		this.vmethod_40(this.String_1);
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x000468C0 File Offset: 0x00044AC0
	public virtual void vmethod_40(string string_3)
	{
		if (string.IsNullOrEmpty(string_3))
		{
			return;
		}
		this.GClass86_5.method_40();
		if (this.gclass99_0[this.GClass86_5.GStruct2_0.int_1].String_2.TrimStart(new char[0]).StartsWith(string_3))
		{
			this.vmethod_74(string_3);
			return;
		}
		this.vmethod_73(string_3);
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0000A82D File Offset: 0x00008A2D
	public void method_60(KeyPressEventArgs keyPressEventArgs_0)
	{
		if (this.keyPressEventHandler_0 != null)
		{
			this.keyPressEventHandler_0(this, keyPressEventArgs_0);
		}
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x00046924 File Offset: 0x00044B24
	private bool method_61(char char_5)
	{
		if (this.bool_33)
		{
			this.bool_33 = false;
			this.vmethod_42(char_5);
			return true;
		}
		KeyPressEventArgs keyPressEventArgs = new KeyPressEventArgs(char_5);
		this.method_60(keyPressEventArgs);
		return keyPressEventArgs.Handled;
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x00046960 File Offset: 0x00044B60
	public void method_62(char char_5)
	{
		KeyPressEventArgs e = new KeyPressEventArgs(char_5);
		if (this.keyPressEventHandler_1 != null)
		{
			this.keyPressEventHandler_1(this, e);
		}
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x0000A844 File Offset: 0x00008A44
	protected virtual bool ProcessMnemonic(char charCode)
	{
		return !this.bool_36 && this.Focused && (this.vmethod_41(charCode, this.keys_0) || base.ProcessMnemonic(charCode));
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x0004698C File Offset: 0x00044B8C
	protected virtual bool ProcessKeyMessage(ref Message m)
	{
		if (m.Msg == 258)
		{
			this.ProcessMnemonic(Convert.ToChar(m.WParam.ToInt32()));
		}
		return base.ProcessKeyMessage(ref m);
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x000469C8 File Offset: 0x00044BC8
	public virtual bool vmethod_41(char char_5, Keys keys_1)
	{
		if (this.bool_2)
		{
			return true;
		}
		if (this.gclass84_0 != null)
		{
			this.gclass84_0.method_5(char_5, keys_1);
		}
		if (char_5 == '\b' && (keys_1 == Keys.None || keys_1 == Keys.Shift || (keys_1 & Keys.Alt) != Keys.None))
		{
			if (this.Boolean_9 || !base.Enabled)
			{
				return false;
			}
			if (this.method_61(char_5))
			{
				return true;
			}
			if (this.GClass86_5.Boolean_1)
			{
				return false;
			}
			if (!this.GClass86_5.Boolean_2)
			{
				this.vmethod_28();
			}
			else if (!this.GClass86_5.method_53())
			{
				this.vmethod_27('\b');
			}
			if (this.Boolean_28)
			{
				this.method_63(this.GClass86_5.GStruct2_0.int_1);
			}
			this.method_62('\b');
			return true;
		}
		else
		{
			if (char.IsControl(char_5) && char_5 != '\r' && char_5 != '\t')
			{
				return false;
			}
			if (this.Boolean_9 || !base.Enabled)
			{
				return false;
			}
			if (keys_1 != Keys.None && keys_1 != Keys.Shift && keys_1 != (Keys.Control | Keys.Alt) && keys_1 != (Keys.Shift | Keys.Control | Keys.Alt) && (keys_1 != Keys.Alt || char.IsLetterOrDigit(char_5)))
			{
				return false;
			}
			char char_6 = char_5;
			if (this.method_61(char_6))
			{
				return true;
			}
			if (this.GClass86_5.Boolean_1)
			{
				return false;
			}
			if (char_5 == '\r' && !this.Boolean_4)
			{
				return false;
			}
			if (char_5 == '\r')
			{
				char_5 = '\n';
			}
			if (this.Boolean_15)
			{
				this.GClass86_5.method_11(true);
				this.GClass86_5.method_41();
			}
			if (!this.GClass86_5.Boolean_1 && !this.method_65(char_5))
			{
				this.vmethod_27(char_5);
			}
			if (char_5 == '\n' || this.Boolean_19)
			{
				this.vmethod_43();
			}
			if (this.Boolean_28)
			{
				this.method_63(this.GClass86_5.GStruct2_0.int_1);
			}
			this.method_49();
			this.method_4();
			this.method_62(char_6);
			return true;
		}
	}

	// Token: 0x1700033B RID: 827
	// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x0000A872 File Offset: 0x00008A72
	// (set) Token: 0x06000BB2 RID: 2994 RVA: 0x0000A87A File Offset: 0x00008A7A
	[Description("Enables AutoIndentChars mode")]
	[DefaultValue(true)]
	public bool Boolean_28 { get; set; }

	// Token: 0x1700033C RID: 828
	// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x0000A883 File Offset: 0x00008A83
	// (set) Token: 0x06000BB4 RID: 2996 RVA: 0x0000A88B File Offset: 0x00008A8B
	[Description("Regex patterns for AutoIndentChars (one regex per line)")]
	[Editor("System.ComponentModel.Design.MultilineStringEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
	[DefaultValue("^\\s*[\\w\\.]+\\s*(?<range>=)\\s*(?<range>[^;]+);")]
	public string String_6 { get; set; }

	// Token: 0x06000BB5 RID: 2997 RVA: 0x00046B9C File Offset: 0x00044D9C
	public void method_63(int int_28)
	{
		foreach (string pattern in this.String_6.Split(new char[]
		{
			'\r',
			'\n'
		}, StringSplitOptions.RemoveEmptyEntries))
		{
			if (Regex.Match(this[int_28].String_2, pattern).Success)
			{
				this.method_64(int_28, new Regex(pattern));
				return;
			}
		}
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x00046C00 File Offset: 0x00044E00
	protected void method_64(int int_28, Regex regex_0)
	{
		GClass86 gclass = this.GClass86_5.method_6();
		SortedDictionary<int, CaptureCollection> sortedDictionary = new SortedDictionary<int, CaptureCollection>();
		SortedDictionary<int, string> sortedDictionary2 = new SortedDictionary<int, string>();
		int num = 0;
		int int32_ = this[int_28].Int32_2;
		int num2 = int_28;
		while (num2 >= 0 && int32_ == this[num2].Int32_2)
		{
			string text = this[num2].String_2;
			Match match = regex_0.Match(text);
			if (!match.Success)
			{
				break;
			}
			sortedDictionary[num2] = match.Groups["range"].Captures;
			sortedDictionary2[num2] = text;
			if (sortedDictionary[num2].Count > num)
			{
				num = sortedDictionary[num2].Count;
			}
			num2--;
		}
		int num3 = int_28 + 1;
		while (num3 < this.Int32_14 && int32_ == this[num3].Int32_2)
		{
			string text2 = this[num3].String_2;
			Match match2 = regex_0.Match(text2);
			if (!match2.Success)
			{
				break;
			}
			sortedDictionary[num3] = match2.Groups["range"].Captures;
			sortedDictionary2[num3] = text2;
			if (sortedDictionary[num3].Count > num)
			{
				num = sortedDictionary[num3].Count;
			}
			num3++;
		}
		Dictionary<int, bool> dictionary = new Dictionary<int, bool>();
		bool flag = false;
		for (int i = num - 1; i >= 0; i--)
		{
			int num4 = 0;
			foreach (int key in sortedDictionary.Keys)
			{
				CaptureCollection captureCollection = sortedDictionary[key];
				if (captureCollection.Count > i)
				{
					int j = captureCollection[i].Index;
					string text3 = sortedDictionary2[key];
					while (j > 0)
					{
						if (text3[j - 1] != ' ')
						{
							break;
						}
						j--;
					}
					int num5;
					if (i == 0)
					{
						num5 = j;
					}
					else
					{
						num5 = j - captureCollection[i - 1].Index - 1;
					}
					if (num5 > num4)
					{
						num4 = num5;
					}
				}
			}
			foreach (int num6 in new List<int>(sortedDictionary2.Keys))
			{
				if (sortedDictionary[num6].Count > i)
				{
					Capture capture = sortedDictionary[num6][i];
					int num7;
					if (i == 0)
					{
						num7 = capture.Index;
					}
					else
					{
						num7 = capture.Index - sortedDictionary[num6][i - 1].Index - 1;
					}
					int num8 = num4 - num7 + 1;
					if (num8 != 0)
					{
						if (gclass.GStruct2_0.int_1 == num6 && gclass.GStruct2_0.int_0 > capture.Index)
						{
							gclass.GStruct2_0 = new GStruct2(gclass.GStruct2_0.int_0 + num8, num6);
						}
						if (num8 > 0)
						{
							sortedDictionary2[num6] = sortedDictionary2[num6].Insert(capture.Index, new string(' ', num8));
						}
						else
						{
							sortedDictionary2[num6] = sortedDictionary2[num6].Remove(capture.Index + num8, -num8);
						}
						dictionary[num6] = true;
						flag = true;
					}
				}
			}
		}
		if (flag)
		{
			this.GClass86_5.method_38();
			this.method_108();
			this.method_87();
			this.GClass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
			foreach (int num9 in sortedDictionary2.Keys)
			{
				if (dictionary.ContainsKey(num9))
				{
					this.GClass86_5 = new GClass86(this, 0, num9, this[num9].Count, num9);
					if (!this.GClass86_5.Boolean_1)
					{
						this.vmethod_20(sortedDictionary2[num9]);
					}
				}
			}
			this.GClass86_5 = gclass;
			this.method_88();
			this.method_109();
			this.GClass86_5.method_39();
		}
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x00047084 File Offset: 0x00045284
	private bool method_65(char char_5)
	{
		if (this.Boolean_0)
		{
			if (!this.GClass86_5.Boolean_0)
			{
				for (int i = 1; i < this.char_0.Length; i += 2)
				{
					if (char_5 == this.char_0[i] && char_5 == this.GClass86_5.Char_0)
					{
						this.GClass86_5.method_7();
						return true;
					}
				}
			}
			for (int j = 0; j < this.char_0.Length; j += 2)
			{
				if (char_5 == this.char_0[j])
				{
					this.method_66(this.char_0[j], this.char_0[j + 1]);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x00047128 File Offset: 0x00045328
	private bool method_66(char char_5, char char_6)
	{
		if (this.GClass86_5.Boolean_0)
		{
			GClass86 gclass = this.GClass86_5.method_6();
			gclass.method_40();
			this.GClass86_5.method_38();
			this.method_108();
			this.GClass86_5 = new GClass86(this, gclass.GStruct2_0.int_0, gclass.GStruct2_0.int_1, gclass.GStruct2_0.int_0, gclass.GStruct2_1.int_1)
			{
				Boolean_0 = true
			};
			this.vmethod_27(char_5);
			this.GClass86_5 = new GClass86(this, gclass.GStruct2_1.int_0 + 1, gclass.GStruct2_0.int_1, gclass.GStruct2_1.int_0 + 1, gclass.GStruct2_1.int_1)
			{
				Boolean_0 = true
			};
			this.vmethod_27(char_6);
			if (gclass.Boolean_2)
			{
				this.GClass86_5 = new GClass86(this, gclass.GStruct2_1.int_0 + 1, gclass.GStruct2_0.int_1, gclass.GStruct2_1.int_0 + 1, gclass.GStruct2_1.int_1)
				{
					Boolean_0 = true
				};
			}
			this.method_109();
			this.GClass86_5.method_39();
		}
		else if (this.GClass86_5.Boolean_2)
		{
			this.vmethod_20(char_5.ToString() + char_6.ToString());
			this.GClass86_5.method_8();
		}
		else
		{
			this.vmethod_20(char_5.ToString() + this.String_5 + char_6.ToString());
		}
		return true;
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x000472AC File Offset: 0x000454AC
	protected virtual void vmethod_42(char char_5)
	{
		if (char_5 == '\r')
		{
			char_5 = '\n';
		}
		GClass86 gclass = this.GClass86_5.method_6();
		while (gclass.method_7())
		{
			if (gclass.Char_1 == char_5)
			{
				this.GClass86_5 = gclass;
				this.method_49();
				return;
			}
		}
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x000472F4 File Offset: 0x000454F4
	public virtual void vmethod_43()
	{
		if (this.GClass86_5.Boolean_0)
		{
			return;
		}
		if (this.Boolean_18)
		{
			this.method_49();
			int num = this.vmethod_45(this.GClass86_5.GStruct2_0.int_1);
			if (this[this.GClass86_5.GStruct2_0.int_1].Int32_1 != num)
			{
				this.vmethod_44(this.GClass86_5.GStruct2_0.int_1);
				this[this.GClass86_5.GStruct2_0.int_1].Int32_1 = num;
			}
		}
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x0000A894 File Offset: 0x00008A94
	private void method_67()
	{
		if (!this.GClass86_5.Boolean_2)
		{
			return;
		}
		GStruct2 gstruct2_ = this.GClass86_5.GStruct2_0;
		while (this.GClass86_5.Char_0 == ' ')
		{
			this.GClass86_5.method_11(true);
		}
		this.vmethod_28();
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x00047384 File Offset: 0x00045584
	public virtual void vmethod_44(int int_28)
	{
		if (this.GClass86_5.Boolean_0)
		{
			return;
		}
		GStruct2 gstruct2_ = this.GClass86_5.GStruct2_0;
		int num = this.vmethod_45(int_28);
		int int32_ = this.gclass99_0[int_28].Int32_2;
		int num2 = num - int32_;
		if (num2 < 0)
		{
			num2 = -Math.Min(-num2, int32_);
		}
		if (num2 == 0)
		{
			return;
		}
		this.GClass86_5.GStruct2_0 = new GStruct2(0, int_28);
		if (num2 > 0)
		{
			this.vmethod_20(new string(' ', num2));
		}
		else
		{
			this.GClass86_5.GStruct2_0 = new GStruct2(0, int_28);
			this.GClass86_5.GStruct2_1 = new GStruct2(-num2, int_28);
			this.vmethod_28();
		}
		this.GClass86_5.GStruct2_0 = new GStruct2(Math.Min(this.gclass99_0[int_28].Count, Math.Max(0, gstruct2_.int_0 + num2)), int_28);
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x00047460 File Offset: 0x00045660
	public virtual int vmethod_45(int int_28)
	{
		if (int_28 >= 0 && int_28 < this.Int32_14)
		{
			EventHandler<GEventArgs14> eventHandler = this.eventHandler_12;
			if (eventHandler == null)
			{
				if (this.GEnum20_0 != GEnum20.Custom && this.GClass98_0 != null)
				{
					eventHandler = new EventHandler<GEventArgs14>(this.GClass98_0.vmethod_2);
				}
				else
				{
					eventHandler = new EventHandler<GEventArgs14>(this.vmethod_46);
				}
			}
			Stack<GEventArgs14> stack = new Stack<GEventArgs14>();
			int i;
			for (i = int_28 - 1; i >= 0; i--)
			{
				GEventArgs14 geventArgs = new GEventArgs14(i, this.gclass99_0[i].String_2, (i > 0) ? this.gclass99_0[i - 1].String_2 : "", this.Int32_5, 0);
				eventHandler(this, geventArgs);
				stack.Push(geventArgs);
				if (geventArgs.Int32_2 == 0 && geventArgs.Int32_4 == 0 && geventArgs.String_0.Trim() != "")
				{
					break;
				}
			}
			int num = this.gclass99_0[(i >= 0) ? i : 0].Int32_2;
			while (stack.Count != 0)
			{
				GEventArgs14 geventArgs2 = stack.Pop();
				if (geventArgs2.Int32_4 != 0)
				{
					num = geventArgs2.Int32_4 + geventArgs2.Int32_3;
				}
				else
				{
					num += geventArgs2.Int32_3;
				}
			}
			GEventArgs14 geventArgs3 = new GEventArgs14(int_28, this.gclass99_0[int_28].String_2, (int_28 > 0) ? this.gclass99_0[int_28 - 1].String_2 : "", this.Int32_5, num);
			eventHandler(this, geventArgs3);
			return geventArgs3.Int32_4 + geventArgs3.Int32_2;
		}
		return 0;
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x000475F8 File Offset: 0x000457F8
	internal virtual void vmethod_46(object sender, GEventArgs14 e)
	{
		if (string.IsNullOrEmpty(this.gclass99_0[e.Int32_0].String_1) && !string.IsNullOrEmpty(this.gclass99_0[e.Int32_0].String_0))
		{
			e.Int32_3 = this.Int32_5;
			return;
		}
		if (!string.IsNullOrEmpty(this.gclass99_0[e.Int32_0].String_1) && string.IsNullOrEmpty(this.gclass99_0[e.Int32_0].String_0))
		{
			e.Int32_2 = -this.Int32_5;
			e.Int32_3 = -this.Int32_5;
			return;
		}
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x000476A4 File Offset: 0x000458A4
	protected int method_68(int int_28, int int_29)
	{
		if (int_28 > int_29)
		{
			return 0;
		}
		int num = int.MaxValue;
		for (int i = int_28; i <= int_29; i++)
		{
			int int32_ = this.gclass99_0[i].Int32_2;
			if (int32_ < num)
			{
				num = int32_;
			}
		}
		return num;
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x000476E4 File Offset: 0x000458E4
	protected int method_69(int int_28, int int_29)
	{
		if (int_28 > int_29)
		{
			return 0;
		}
		int num = 0;
		for (int i = int_28; i <= int_29; i++)
		{
			int int32_ = this.gclass99_0[i].Int32_2;
			if (int32_ > num)
			{
				num = int32_;
			}
		}
		return num;
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x0000A8D3 File Offset: 0x00008AD3
	public virtual void vmethod_47()
	{
		this.gclass99_0.GClass59_0.method_0();
		this.method_49();
		this.method_4();
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x0000A8F1 File Offset: 0x00008AF1
	public virtual void vmethod_48()
	{
		this.gclass99_0.GClass59_0.method_6();
		this.method_49();
		this.method_4();
	}

	// Token: 0x06000BC3 RID: 3011 RVA: 0x00047720 File Offset: 0x00045920
	protected virtual bool IsInputKey(Keys keyData)
	{
		if ((keyData == Keys.Tab || keyData == (Keys.LButton | Keys.Back | Keys.Shift)) && !this.Boolean_3)
		{
			return false;
		}
		if (keyData == Keys.Return && !this.Boolean_4)
		{
			return false;
		}
		if ((keyData & Keys.Alt) == Keys.None && (keyData & Keys.KeyCode) == Keys.Return)
		{
			return true;
		}
		if ((keyData & Keys.Alt) != Keys.Alt)
		{
			Keys keys = keyData & Keys.KeyCode;
			if (keys == Keys.Tab)
			{
				return (keyData & Keys.Control) == Keys.None;
			}
			if (keys == Keys.Escape)
			{
				return false;
			}
			if (keys - Keys.Prior <= 7)
			{
				return true;
			}
		}
		return base.IsInputKey(keyData);
	}

	// Token: 0x06000BC4 RID: 3012
	[DllImport("User32.dll")]
	private static extern bool CreateCaret(IntPtr intptr_1, int int_28, int int_29, int int_30);

	// Token: 0x06000BC5 RID: 3013
	[DllImport("User32.dll")]
	private static extern bool SetCaretPos(int int_28, int int_29);

	// Token: 0x06000BC6 RID: 3014
	[DllImport("User32.dll")]
	private static extern bool DestroyCaret();

	// Token: 0x06000BC7 RID: 3015
	[DllImport("User32.dll")]
	private static extern bool ShowCaret(IntPtr intptr_1);

	// Token: 0x06000BC8 RID: 3016
	[DllImport("User32.dll")]
	private static extern bool HideCaret(IntPtr intptr_1);

	// Token: 0x06000BC9 RID: 3017 RVA: 0x0000A90F File Offset: 0x00008B0F
	protected virtual void OnPaintBackground(PaintEventArgs e)
	{
		if (this.Brush_0 == null)
		{
			base.OnPaintBackground(e);
			return;
		}
		e.Graphics.FillRectangle(this.Brush_0, base.ClientRectangle);
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x000477A8 File Offset: 0x000459A8
	public void method_70(Graphics graphics_0, GStruct2 gstruct2_0, Size size_1)
	{
		if (this.bool_10)
		{
			this.method_40();
		}
		if (this.bool_12)
		{
			this.vmethod_67();
		}
		Point point = this.method_95(gstruct2_0);
		int num = point.Y + base.VerticalScroll.Value;
		int num2 = point.X + base.HorizontalScroll.Value - this.Int32_7 - this.Padding_0.Left;
		int int_ = gstruct2_0.int_0;
		int int_2 = (num2 + size_1.Width) / this.Int32_4;
		for (int i = gstruct2_0.int_1; i < this.gclass99_0.Count; i++)
		{
			GClass81 gclass = this.gclass99_0[i];
			GStruct1 gstruct = this.list_0[i];
			if (gstruct.int_0 > num + size_1.Height)
			{
				break;
			}
			if (gstruct.int_0 + gstruct.Int32_0 * this.Int32_2 >= num && gstruct.genum17_0 != GEnum17.Hidden)
			{
				int num3 = gstruct.int_0 - num;
				graphics_0.SmoothingMode = SmoothingMode.None;
				if (gstruct.genum17_0 == GEnum17.Visible && gclass.Brush_0 != null)
				{
					graphics_0.FillRectangle(gclass.Brush_0, new Rectangle(0, num3, size_1.Width, this.Int32_2 * gstruct.Int32_0));
				}
				graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
				for (int j = 0; j < gstruct.Int32_0; j++)
				{
					num3 = gstruct.int_0 + j * this.Int32_2 - num;
					int num4 = (j == 0) ? 0 : (gstruct.int_2 * this.Int32_4);
					this.method_75(graphics_0, int_, int_2, i, j, -num2 + num4, num3);
				}
			}
		}
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x00047960 File Offset: 0x00045B60
	protected virtual void OnPaint(PaintEventArgs e)
	{
		if (this.bool_10)
		{
			this.method_40();
		}
		if (this.bool_12)
		{
			this.vmethod_67();
		}
		this.list_1.Clear();
		e.Graphics.SmoothingMode = SmoothingMode.None;
		Pen pen = new Pen(this.Color_9);
		Brush brush = new SolidBrush(this.Color_3);
		Brush brush2 = new SolidBrush(this.Color_5);
		Brush brush3 = new SolidBrush(this.Color_6);
		Brush brush4 = new SolidBrush(Color.FromArgb((int)((this.Color_2.A == byte.MaxValue) ? 50 : this.Color_2.A), this.Color_2));
		Rectangle rectangle = this.Rectangle_0;
		e.Graphics.FillRectangle(brush3, 0, -base.VerticalScroll.Value, base.ClientSize.Width, Math.Max(0, this.Padding_0.Top - 1));
		e.Graphics.FillRectangle(brush3, 0, rectangle.Bottom, base.ClientSize.Width, base.ClientSize.Height);
		e.Graphics.FillRectangle(brush3, rectangle.Right, 0, base.ClientSize.Width, base.ClientSize.Height);
		e.Graphics.FillRectangle(brush3, this.Int32_18, 0, this.Int32_7 - this.Int32_18 - 1, base.ClientSize.Height);
		if (base.HorizontalScroll.Value <= this.Padding_0.Left)
		{
			e.Graphics.FillRectangle(brush3, this.Int32_7 - base.HorizontalScroll.Value - 2, 0, Math.Max(0, this.Padding_0.Left - 1), base.ClientSize.Height);
		}
		Math.Max(this.Int32_7, this.Int32_7 + this.Padding_0.Left - base.HorizontalScroll.Value);
		int width = rectangle.Width;
		e.Graphics.FillRectangle(brush2, 0, 0, this.Int32_18, base.ClientSize.Height);
		if (this.Int32_7 > 8)
		{
			e.Graphics.DrawLine(pen, this.Int32_18, 0, this.Int32_18, base.ClientSize.Height);
		}
		if (this.Int32_9 > 0)
		{
			e.Graphics.DrawLine(pen, new Point(this.Int32_7 + this.Padding_0.Left + this.Int32_9 * this.Int32_4 - base.HorizontalScroll.Value + 1, rectangle.Top + 1), new Point(this.Int32_7 + this.Padding_0.Left + this.Int32_9 * this.Int32_4 - base.HorizontalScroll.Value + 1, rectangle.Bottom - 1));
		}
		this.method_73(e.Graphics);
		int num = Math.Max(0, base.HorizontalScroll.Value - this.Padding_0.Left) / this.Int32_4;
		int int_ = (base.HorizontalScroll.Value + base.ClientSize.Width) / this.Int32_4;
		int num2 = this.Int32_7 + this.Padding_0.Left - base.HorizontalScroll.Value;
		if (num2 < this.Int32_7)
		{
			num++;
		}
		Dictionary<int, GClass58> dictionary = new Dictionary<int, GClass58>();
		foreach (GClass58 gclass in this.gclass56_0)
		{
			dictionary[gclass.Int32_0] = gclass;
		}
		int num3 = this.method_83(base.VerticalScroll.Value);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		int i;
		for (i = num3; i < this.gclass99_0.Count; i++)
		{
			GClass81 gclass2 = this.gclass99_0[i];
			GStruct1 gstruct = this.list_0[i];
			if (gstruct.int_0 > base.VerticalScroll.Value + base.ClientSize.Height)
			{
				break;
			}
			if (gstruct.int_0 + gstruct.Int32_0 * this.Int32_2 >= base.VerticalScroll.Value && gstruct.genum17_0 != GEnum17.Hidden)
			{
				int num4 = gstruct.int_0 - base.VerticalScroll.Value;
				e.Graphics.SmoothingMode = SmoothingMode.None;
				if (gstruct.genum17_0 == GEnum17.Visible && gclass2.Brush_0 != null)
				{
					e.Graphics.FillRectangle(gclass2.Brush_0, new Rectangle(rectangle.Left, num4, rectangle.Width, this.Int32_2 * gstruct.Int32_0));
				}
				if (this.Color_2 != Color.Transparent && i == this.GClass86_5.GStruct2_0.int_1 && this.GClass86_5.Boolean_2)
				{
					e.Graphics.FillRectangle(brush4, new Rectangle(rectangle.Left, num4, rectangle.Width, this.Int32_2));
				}
				if (this.Color_3 != Color.Transparent && gclass2.Boolean_0)
				{
					e.Graphics.FillRectangle(brush, new RectangleF(-10f, (float)num4, (float)(this.Int32_7 - 8 - 2 + 10), (float)(this.Int32_2 + 1)));
				}
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				if (dictionary.ContainsKey(i))
				{
					dictionary[i].vmethod_1(e.Graphics, new Rectangle(this.Int32_7, num4, base.Width, this.Int32_2 * gstruct.Int32_0));
				}
				if (gstruct.genum17_0 == GEnum17.Visible)
				{
					this.vmethod_81(new GEventArgs8(i, new Rectangle(this.Int32_7, num4, base.Width, this.Int32_2 * gstruct.Int32_0), e.Graphics, e.ClipRectangle));
				}
				if (this.Boolean_10)
				{
					int num5 = i + (int)this.uint_0;
					GClass82 gclass3 = this.GClass82_0;
					if (gclass3 == null)
					{
						goto IL_63E;
					}
					string text;
					if ((text = gclass3.vmethod_0(num5)) == null)
					{
						goto IL_63E;
					}
					IL_650:
					string s = text;
					using (SolidBrush solidBrush = new SolidBrush(this.Color_4))
					{
						e.Graphics.DrawString(s, this.Font, solidBrush, new RectangleF(-10f, (float)num4, (float)(this.Int32_7 - 8 - 2 + 10), (float)(this.Int32_2 + (int)((float)this.int_12 * 0.5f))), new StringFormat(StringFormatFlags.DirectionRightToLeft)
						{
							LineAlignment = StringAlignment.Center
						});
					}
					goto IL_6C0;
					IL_63E:
					text = string.Format("{0}", num5);
					goto IL_650;
				}
				IL_6C0:
				int num6 = (int)((float)(this.int_25 * this.int_19) / 100f);
				int num7 = num6 / 2;
				if (gstruct.genum17_0 == GEnum17.StartOfHiddenBlock)
				{
					this.list_1.Add(new GClass103(i, new Rectangle(this.Int32_18 - num7, num4 + this.Int32_2 / 2 - num7 + 1, num6, num6)));
				}
				if (!string.IsNullOrEmpty(gclass2.String_0) && gstruct.genum17_0 == GEnum17.Visible && string.IsNullOrEmpty(gclass2.String_1))
				{
					this.list_1.Add(new GClass102(i, new Rectangle(this.Int32_18 - num7, num4 + this.Int32_2 / 2 - num7 + 1, num6, num6)));
				}
				if (gstruct.genum17_0 == GEnum17.Visible && !string.IsNullOrEmpty(gclass2.String_1) && string.IsNullOrEmpty(gclass2.String_0))
				{
					e.Graphics.DrawLine(pen, this.Int32_18, num4 + this.Int32_2 * gstruct.Int32_0 - 1, this.Int32_18 + 4, num4 + this.Int32_2 * gstruct.Int32_0 - 1);
				}
				for (int j = 0; j < gstruct.Int32_0; j++)
				{
					num4 = gstruct.int_0 + j * this.Int32_2 - base.VerticalScroll.Value;
					if (num4 > base.VerticalScroll.Value + base.ClientSize.Height)
					{
						break;
					}
					if (gstruct.int_0 + j * this.Int32_2 >= base.VerticalScroll.Value)
					{
						int num8 = (j == 0) ? 0 : (gstruct.int_2 * this.Int32_4);
						this.method_75(e.Graphics, num, int_, i, j, num2 + num8, num4);
					}
				}
			}
		}
		int int_2 = i - 1;
		if (this.Boolean_11)
		{
			this.vmethod_49(e, num3, int_2);
		}
		if (this.GClass86_5.Boolean_0 && this.GClass90_0.Brush_0 is SolidBrush)
		{
			Color color = ((SolidBrush)this.GClass90_0.Brush_0).Color;
			Point point = this.method_95(this.GClass86_5.GStruct2_0);
			Point point2 = this.method_95(this.GClass86_5.GStruct2_1);
			using (Pen pen2 = new Pen(color))
			{
				e.Graphics.DrawRectangle(pen2, Rectangle.FromLTRB(Math.Min(point.X, point2.X) - 1, Math.Min(point.Y, point2.Y), Math.Max(point.X, point2.X), Math.Max(point.Y, point2.Y) + this.Int32_2));
			}
		}
		if (this.GClass91_0 != null && this.gclass86_1 != null && this.gclass86_3 != null)
		{
			this.GClass91_0.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(e.Graphics, this.method_95(this.gclass86_1.GStruct2_0), this.gclass86_1);
			this.GClass91_0.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(e.Graphics, this.method_95(this.gclass86_3.GStruct2_0), this.gclass86_3);
		}
		if (this.GClass91_1 != null && this.gclass86_2 != null && this.gclass86_4 != null)
		{
			this.GClass91_1.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(e.Graphics, this.method_95(this.gclass86_2.GStruct2_0), this.gclass86_2);
			this.GClass91_1.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(e.Graphics, this.method_95(this.gclass86_4.GStruct2_0), this.gclass86_4);
		}
		e.Graphics.SmoothingMode = SmoothingMode.None;
		if ((this.int_16 >= 0 || this.int_10 >= 0) && GStruct2.smethod_1(this.GClass86_5.GStruct2_0, this.GClass86_5.GStruct2_1) && this.int_10 < this.list_0.Count)
		{
			int y = ((this.int_16 >= 0) ? this.list_0[this.int_16].int_0 : 0) - base.VerticalScroll.Value + this.Int32_2 / 2;
			int y2 = ((this.int_10 >= 0) ? (this.list_0[this.int_10].int_0 + (this.list_0[this.int_10].Int32_0 - 1) * this.Int32_2) : (this.int_8 + this.Int32_2)) - base.VerticalScroll.Value + this.Int32_2;
			using (Pen pen3 = new Pen(Color.FromArgb(100, this.Color_10), 4f))
			{
				e.Graphics.DrawLine(pen3, this.Int32_7 - 5, y, this.Int32_7 - 5, y2);
			}
		}
		this.method_74(e.Graphics);
		this.method_71(e, pen);
		Point point3 = this.method_95(this.GClass86_5.GStruct2_0);
		int num9 = this.Int32_2 - this.int_12;
		point3.Offset(0, this.int_12 / 2);
		if ((this.Focused || this.Boolean_29 || this.Boolean_7) && point3.X >= this.Int32_7 && this.Boolean_5)
		{
			int num10 = (this.Boolean_15 || this.Boolean_12) ? this.Int32_4 : 1;
			if (this.Boolean_12)
			{
				using (SolidBrush solidBrush2 = new SolidBrush(this.Color_8))
				{
					e.Graphics.FillRectangle(solidBrush2, point3.X, point3.Y, num10, num9 + 1);
					goto IL_CC3;
				}
			}
			using (Pen pen4 = new Pen(this.Color_8))
			{
				e.Graphics.DrawLine(pen4, point3.X, point3.Y, point3.X, point3.Y + num9);
			}
			IL_CC3:
			Rectangle right = new Rectangle(base.HorizontalScroll.Value + point3.X, base.VerticalScroll.Value + point3.Y, num10, num9 + 1);
			if (this.Boolean_6 && (this.rectangle_0 != right || !this.Boolean_21))
			{
				FastColoredTextBox.CreateCaret(base.Handle, 0, num10, num9 + 1);
				FastColoredTextBox.SetCaretPos(point3.X, point3.Y);
				FastColoredTextBox.ShowCaret(base.Handle);
			}
			this.rectangle_0 = right;
		}
		else
		{
			FastColoredTextBox.HideCaret(base.Handle);
			this.rectangle_0 = Rectangle.Empty;
		}
		if (!base.Enabled)
		{
			using (SolidBrush solidBrush3 = new SolidBrush(this.Color_7))
			{
				e.Graphics.FillRectangle(solidBrush3, base.ClientRectangle);
			}
		}
		if (this.GClass84_0.Boolean_1)
		{
			this.method_72(e.Graphics);
		}
		if (this.bool_36)
		{
			this.method_140(e.Graphics);
		}
		pen.Dispose();
		brush.Dispose();
		brush2.Dispose();
		brush4.Dispose();
		brush3.Dispose();
		base.OnPaint(e);
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x000487B8 File Offset: 0x000469B8
	private void method_71(PaintEventArgs paintEventArgs_0, Pen pen_0)
	{
		foreach (GClass101 gclass in this.list_1)
		{
			if (gclass is GClass102)
			{
				using (SolidBrush solidBrush = new SolidBrush(this.GClass76_0.Color_1))
				{
					using (Pen pen = new Pen(this.GClass76_0.Color_0))
					{
						using (Pen pen2 = new Pen(this.GClass76_0.Color_2))
						{
							(gclass as GClass102).method_0(paintEventArgs_0.Graphics, pen2, solidBrush, pen);
							continue;
						}
					}
				}
			}
			if (gclass is GClass103)
			{
				using (SolidBrush solidBrush2 = new SolidBrush(this.GClass76_0.Color_4))
				{
					using (Pen pen3 = new Pen(this.GClass76_0.Color_3))
					{
						using (Pen pen4 = new Pen(this.GClass76_0.Color_5))
						{
							(gclass as GClass103).method_0(paintEventArgs_0.Graphics, pen4, solidBrush2, pen3);
							continue;
						}
					}
				}
			}
			gclass.GClass101.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(paintEventArgs_0.Graphics, pen_0);
		}
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x000489A8 File Offset: 0x00046BA8
	private void method_72(Graphics graphics_0)
	{
		FastColoredTextBox.Class99 @class = new FastColoredTextBox.Class99();
		@class.fastColoredTextBox_0 = this;
		@class.rectangle_0 = new Rectangle(base.ClientRectangle.Right - 75, base.ClientRectangle.Bottom - 13, 75, 13);
		Rectangle rect = new Rectangle(-3, -3, 6, 6);
		GraphicsState gstate = graphics_0.Save();
		graphics_0.SmoothingMode = SmoothingMode.HighQuality;
		graphics_0.TranslateTransform((float)(@class.rectangle_0.Left + 6), (float)(@class.rectangle_0.Top + 6));
		new TimeSpan(DateTime.Now.Ticks);
		graphics_0.RotateTransform(180f * ((float)DateTime.Now.Millisecond / 1000f));
		using (Pen pen = new Pen(Color.Red, 2f))
		{
			graphics_0.DrawArc(pen, rect, 0f, 90f);
			graphics_0.DrawArc(pen, rect, 180f, 90f);
		}
		graphics_0.DrawEllipse(Pens.Red, rect);
		graphics_0.Restore(gstate);
		using (Font font = new Font(FontFamily.GenericSansSerif, 8f))
		{
			graphics_0.DrawString("Recording...", font, Brushes.Red, new PointF((float)(@class.rectangle_0.Left + 13), (float)@class.rectangle_0.Top));
		}
		@class.timer_0 = null;
		@class.timer_0 = new System.Threading.Timer(new TimerCallback(@class.method_0), null, 200, -1);
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x00048B50 File Offset: 0x00046D50
	private void method_73(Graphics graphics_0)
	{
		if (this.GEnum15_0 == GEnum15.None)
		{
			return;
		}
		Rectangle rect = this.Rectangle_0;
		if (this.GEnum15_0 == GEnum15.Shadow)
		{
			Rectangle rect2 = new Rectangle(rect.Left + 4, rect.Bottom, rect.Width - 4, 4);
			Rectangle rect3 = new Rectangle(rect.Right, rect.Bottom, 4, 4);
			Rectangle rect4 = new Rectangle(rect.Right, rect.Top + 4, 4, rect.Height - 4);
			using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(80, this.Color_1)))
			{
				graphics_0.FillRectangle(solidBrush, rect2);
				graphics_0.FillRectangle(solidBrush, rect4);
				graphics_0.FillRectangle(solidBrush, rect3);
			}
		}
		using (Pen pen = new Pen(this.Color_1))
		{
			graphics_0.DrawRectangle(pen, rect);
		}
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x00048C50 File Offset: 0x00046E50
	private void method_74(Graphics graphics_0)
	{
		foreach (GClass78 gclass in this.gclass77_0)
		{
			GClass86 gclass2 = gclass.GClass86_0.method_6();
			gclass2.method_40();
			Point point = this.method_95(gclass2.GStruct2_0);
			Point point2 = this.method_95(gclass2.GStruct2_1);
			if (this.method_130(gclass2.GStruct2_0.int_1) == GEnum17.Visible && this.method_130(gclass2.GStruct2_1.int_1) == GEnum17.Visible)
			{
				using (Pen pen = new Pen(gclass.Color_2))
				{
					pen.DashStyle = DashStyle.Dash;
					if (gclass2.Boolean_2)
					{
						point.Offset(1, -1);
						graphics_0.DrawLines(pen, new Point[]
						{
							point,
							new Point(point.X, point.Y + this.int_9 + 2)
						});
					}
					else
					{
						point.Offset(-1, -1);
						point2.Offset(1, -1);
						graphics_0.DrawLines(pen, new Point[]
						{
							new Point(point.X + this.Int32_4 / 2, point.Y),
							point,
							new Point(point.X, point.Y + this.int_9 + 2),
							new Point(point.X + this.Int32_4 / 2, point.Y + this.int_9 + 2)
						});
						graphics_0.DrawLines(pen, new Point[]
						{
							new Point(point2.X - this.Int32_4 / 2, point2.Y),
							point2,
							new Point(point2.X, point2.Y + this.int_9 + 2),
							new Point(point2.X - this.Int32_4 / 2, point2.Y + this.int_9 + 2)
						});
					}
				}
			}
		}
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x00048EB0 File Offset: 0x000470B0
	protected virtual void vmethod_49(PaintEventArgs paintEventArgs_0, int int_28, int int_29)
	{
		paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.None;
		using (Pen pen = new Pen(Color.FromArgb(200, this.Color_9))
		{
			DashStyle = DashStyle.Dot
		})
		{
			foreach (KeyValuePair<int, int> keyValuePair in this.dictionary_0)
			{
				if (keyValuePair.Key < int_29 && keyValuePair.Value > int_28)
				{
					GClass81 gclass = this.gclass99_0[keyValuePair.Key];
					int num = this.list_0[keyValuePair.Key].int_0 - base.VerticalScroll.Value + this.Int32_2;
					num += num % 2;
					int num2;
					if (keyValuePair.Value >= this.Int32_14)
					{
						num2 = this.list_0[this.Int32_14 - 1].int_0 + this.Int32_2 - base.VerticalScroll.Value;
					}
					else
					{
						if (this.list_0[keyValuePair.Value].genum17_0 != GEnum17.Visible)
						{
							continue;
						}
						int num3 = 0;
						int int32_ = gclass.Int32_2;
						if (this.gclass99_0[keyValuePair.Value].Count <= int32_ || this.gclass99_0[keyValuePair.Value][int32_].char_0 == ' ')
						{
							num3 = this.Int32_2;
						}
						num2 = this.list_0[keyValuePair.Value].int_0 - base.VerticalScroll.Value + num3;
					}
					int num4 = this.Int32_7 + this.Padding_0.Left + gclass.Int32_2 * this.Int32_4 - base.HorizontalScroll.Value;
					if (num4 >= this.Int32_7 + this.Padding_0.Left)
					{
						paintEventArgs_0.Graphics.DrawLine(pen, num4, (num >= 0) ? num : 0, num4, (num2 < base.ClientSize.Height) ? num2 : base.ClientSize.Height);
					}
				}
			}
		}
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x00049120 File Offset: 0x00047320
	private void method_75(Graphics graphics_0, int int_28, int int_29, int int_30, int int_31, int int_32, int int_33)
	{
		GClass81 gclass = this.gclass99_0[int_30];
		GStruct1 gstruct = this.list_0[int_30];
		int num = gstruct.method_0(int_31);
		int_29 = Math.Min(gstruct.method_1(int_31, gclass) - num, int_29);
		graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
		if (gstruct.genum17_0 == GEnum17.StartOfHiddenBlock)
		{
			this.GClass88_1.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, new Point(int_32 + int_28 * this.Int32_4, int_33), new GClass86(this, num + int_28, int_30, num + int_29 + 1, int_30));
		}
		else
		{
			StyleIndex styleIndex = StyleIndex.None;
			int num2 = int_28 - 1;
			for (int i = int_28; i <= int_29; i++)
			{
				StyleIndex styleIndex_ = gclass[num + i].styleIndex_0;
				if (styleIndex != styleIndex_)
				{
					this.method_76(graphics_0, styleIndex, new Point(int_32 + (num2 + 1) * this.Int32_4, int_33), new GClass86(this, num + num2 + 1, int_30, num + i, int_30));
					num2 = i - 1;
					styleIndex = styleIndex_;
				}
			}
			this.method_76(graphics_0, styleIndex, new Point(int_32 + (num2 + 1) * this.Int32_4, int_33), new GClass86(this, num + num2 + 1, int_30, num + int_29 + 1, int_30));
		}
		if (this.Boolean_24 && int_31 == gstruct.Int32_0 - 1)
		{
			int_29++;
		}
		if (!this.GClass86_5.Boolean_2 && int_29 >= int_28)
		{
			graphics_0.SmoothingMode = SmoothingMode.None;
			GClass86 gclass2 = new GClass86(this, num + int_28, int_30, num + int_29 + 1, int_30);
			gclass2 = this.GClass86_5.vmethod_0(gclass2);
			if (gclass2 != null && this.GClass90_0 != null)
			{
				this.GClass90_0.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, new Point(int_32 + (gclass2.GStruct2_0.int_0 - num) * this.Int32_4, 1 + int_33), gclass2);
			}
		}
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x000492D8 File Offset: 0x000474D8
	private void method_76(Graphics graphics_0, StyleIndex styleIndex_0, Point point_4, GClass86 gclass86_9)
	{
		if (GStruct2.smethod_4(gclass86_9.GStruct2_1, gclass86_9.GStruct2_0))
		{
			int num = 1;
			bool flag = false;
			for (int i = 0; i < this.GClass87_0.Length; i++)
			{
				if (this.GClass87_0[i] != null && ((int)styleIndex_0 & num) != 0)
				{
					GClass87 gclass = this.GClass87_0[i];
					bool flag2 = gclass is GClass88;
					if (!flag || !flag2 || this.Boolean_16)
					{
						gclass.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, point_4, gclass86_9);
					}
					flag = (flag || flag2);
				}
				num <<= 1;
			}
			if (!flag)
			{
				this.GClass88_0.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, point_4, gclass86_9);
			}
		}
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x0000A938 File Offset: 0x00008B38
	protected virtual void OnEnter(EventArgs e)
	{
		base.OnEnter(e);
		this.bool_7 = false;
		this.bool_8 = false;
		this.gclass86_8 = null;
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x0000A956 File Offset: 0x00008B56
	protected virtual void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		this.bool_5 = false;
		if (e.Button == MouseButtons.Left && this.bool_8)
		{
			this.method_77(e);
		}
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x00049368 File Offset: 0x00047568
	protected virtual void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		if (this.bool_36)
		{
			this.method_138();
			this.bool_7 = false;
			if (e.Button == MouseButtons.Middle)
			{
				this.method_139();
			}
			return;
		}
		this.GClass84_0.Boolean_1 = false;
		base.Select();
		base.ActiveControl = null;
		if (e.Button != MouseButtons.Left)
		{
			if (e.Button == MouseButtons.Middle)
			{
				this.method_137(e);
			}
			return;
		}
		GClass101 gclass = this.method_107(e.Location);
		if (gclass != null)
		{
			this.bool_7 = false;
			this.bool_8 = false;
			this.gclass86_8 = null;
			this.vmethod_76(e, gclass);
			return;
		}
		this.bool_7 = true;
		this.bool_8 = false;
		this.gclass86_8 = null;
		this.bool_5 = (e.Location.X < this.Int32_18);
		if (this.bool_5)
		{
			this.vmethod_50();
			this.GClass86_5.method_38();
			int int_ = this.method_85(e.Location).int_1;
			this.int_13 = int_;
			this.GClass86_5.GStruct2_0 = new GStruct2(0, int_);
			this.GClass86_5.GStruct2_1 = new GStruct2(this.method_23(int_), int_);
			this.GClass86_5.method_39();
			this.method_4();
			return;
		}
		GStruct2 gstruct = this.method_84(e.Location);
		if (e.Clicks == 2)
		{
			this.bool_7 = false;
			this.bool_8 = false;
			this.gclass86_8 = null;
			this.method_82(gstruct);
			return;
		}
		if (!this.GClass86_5.Boolean_2 && this.GClass86_5.method_0(gstruct) && this[gstruct.int_1].Count > gstruct.int_0 && !this.Boolean_9)
		{
			this.bool_8 = true;
			this.bool_7 = false;
			return;
		}
		this.method_77(e);
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x00049538 File Offset: 0x00047738
	private void method_77(MouseEventArgs mouseEventArgs_0)
	{
		GStruct2 gstruct2_ = this.GClass86_5.GStruct2_1;
		this.GClass86_5.method_38();
		if (this.GClass86_5.Boolean_0)
		{
			this.GClass86_5.GStruct2_0 = this.method_85(mouseEventArgs_0.Location);
			this.GClass86_5.Boolean_0 = true;
		}
		else if (this.Boolean_2)
		{
			this.GClass86_5.GStruct2_0 = this.method_85(mouseEventArgs_0.Location);
		}
		else
		{
			this.GClass86_5.GStruct2_0 = this.method_84(mouseEventArgs_0.Location);
		}
		if ((this.keys_0 & Keys.Shift) != Keys.None)
		{
			this.GClass86_5.GStruct2_1 = gstruct2_;
		}
		this.vmethod_50();
		this.GClass86_5.method_39();
		this.method_4();
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x0000A982 File Offset: 0x00008B82
	protected virtual void vmethod_50()
	{
		if ((Control.ModifierKeys & Keys.Alt) != Keys.None && !this.Boolean_23)
		{
			this.GClass86_5.Boolean_0 = true;
			return;
		}
		this.GClass86_5.Boolean_0 = false;
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x000495F8 File Offset: 0x000477F8
	protected virtual void OnMouseWheel(MouseEventArgs e)
	{
		this.method_4();
		if (this.keys_0 == Keys.Control)
		{
			this.method_79(2 * Math.Sign(e.Delta));
			((HandledMouseEventArgs)e).Handled = true;
		}
		else if (base.VerticalScroll.Visible || !this.Boolean_21)
		{
			int int_ = FastColoredTextBox.smethod_4();
			this.method_78(int_, e.Delta);
			((HandledMouseEventArgs)e).Handled = true;
		}
		this.method_138();
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x00049674 File Offset: 0x00047874
	private void method_78(int int_28, int int_29)
	{
		if (base.VerticalScroll.Visible || !this.Boolean_21)
		{
			int num = base.ClientSize.Height / this.Int32_2;
			int num2;
			if (int_28 != -1 && int_28 <= num)
			{
				num2 = this.Int32_2 * int_28;
			}
			else
			{
				num2 = this.Int32_2 * num;
			}
			int newValue = base.VerticalScroll.Value - Math.Sign(int_29) * num2;
			ScrollEventArgs se = new ScrollEventArgs((int_29 > 0) ? ScrollEventType.SmallDecrement : ScrollEventType.SmallIncrement, base.VerticalScroll.Value, newValue, ScrollOrientation.VerticalScroll);
			this.OnScroll(se);
		}
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x00049700 File Offset: 0x00047900
	private static int smethod_4()
	{
		int result;
		try
		{
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", false))
			{
				result = Convert.ToInt32(registryKey.GetValue("WheelScrollLines"));
			}
		}
		catch
		{
			result = 1;
		}
		return result;
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x00049760 File Offset: 0x00047960
	public void method_79(int int_28)
	{
		float sizeInPoints = this.Font.SizeInPoints;
		using (Graphics graphics = Graphics.FromHwnd(base.Handle))
		{
			float dpiY = graphics.DpiY;
			float num = sizeInPoints + (float)int_28 * 72f / dpiY;
			if (num >= 1f)
			{
				float num2 = num / this.font_1.SizeInPoints;
				this.Int32_21 = (int)Math.Round((double)(100f * num2));
			}
		}
	}

	// Token: 0x1700033D RID: 829
	// (get) Token: 0x06000BDC RID: 3036 RVA: 0x0000A9B2 File Offset: 0x00008BB2
	// (set) Token: 0x06000BDD RID: 3037 RVA: 0x0000A9BA File Offset: 0x00008BBA
	[Browsable(false)]
	public int Int32_21
	{
		get
		{
			return this.int_19;
		}
		set
		{
			this.int_19 = value;
			this.method_80((float)this.int_19 / 100f);
			this.vmethod_51();
		}
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x0000A9DC File Offset: 0x00008BDC
	protected virtual void vmethod_51()
	{
		if (this.eventHandler_18 != null)
		{
			this.eventHandler_18(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x000497E4 File Offset: 0x000479E4
	private void method_80(float float_0)
	{
		int num = this.method_83(base.VerticalScroll.Value);
		float num2 = this.font_1.SizeInPoints;
		num2 *= float_0;
		if (num2 >= 1f && num2 <= 300f)
		{
			Font font = this.Font;
			this.method_0(new Font(this.Font.FontFamily, num2, this.Font.Style, GraphicsUnit.Point));
			font.Dispose();
			this.method_11(true);
			if (num < this.Int32_14)
			{
				base.VerticalScroll.Value = Math.Min(base.VerticalScroll.Maximum, this.list_0[num].int_0 - this.Padding_0.Top);
			}
			this.method_47();
			this.method_4();
			this.vmethod_4();
			return;
		}
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x0000A9F7 File Offset: 0x00008BF7
	protected virtual void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		this.method_81();
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x000498B8 File Offset: 0x00047AB8
	protected virtual void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if (this.bool_36)
		{
			return;
		}
		if (this.point_0 != e.Location)
		{
			this.method_81();
			this.timer_2.Start();
		}
		this.point_0 = e.Location;
		if (e.Button == MouseButtons.Left && this.bool_8)
		{
			this.gclass86_8 = this.GClass86_5.method_6();
			base.DoDragDrop(this.String_5, DragDropEffects.Copy);
			this.gclass86_8 = null;
			return;
		}
		if (e.Button == MouseButtons.Left && this.bool_7)
		{
			GStruct2 gstruct;
			if (!this.GClass86_5.Boolean_0 && !this.Boolean_2)
			{
				gstruct = this.method_84(e.Location);
			}
			else
			{
				gstruct = this.method_85(e.Location);
			}
			if (this.bool_5)
			{
				this.GClass86_5.method_38();
				int num = gstruct.int_1;
				if (num < this.int_13)
				{
					this.GClass86_5.GStruct2_0 = new GStruct2(0, num);
					this.GClass86_5.GStruct2_1 = new GStruct2(this.method_23(this.int_13), this.int_13);
				}
				else
				{
					this.GClass86_5.GStruct2_0 = new GStruct2(this.method_23(num), num);
					this.GClass86_5.GStruct2_1 = new GStruct2(0, this.int_13);
				}
				this.GClass86_5.method_39();
				this.method_49();
				base.HorizontalScroll.Value = 0;
				this.method_47();
				this.method_4();
			}
			else if (GStruct2.smethod_0(gstruct, this.GClass86_5.GStruct2_0))
			{
				GStruct2 gstruct2_ = this.GClass86_5.GStruct2_1;
				this.GClass86_5.method_38();
				if (this.GClass86_5.Boolean_0)
				{
					this.GClass86_5.GStruct2_0 = gstruct;
					this.GClass86_5.Boolean_0 = true;
				}
				else
				{
					this.GClass86_5.GStruct2_0 = gstruct;
				}
				this.GClass86_5.GStruct2_1 = gstruct2_;
				this.GClass86_5.method_39();
				this.method_49();
				this.method_4();
				return;
			}
		}
		GClass101 gclass = this.method_107(e.Location);
		if (gclass != null)
		{
			base.Cursor = gclass.Cursor_0;
			return;
		}
		if (e.Location.X >= this.Int32_18 && !this.bool_5)
		{
			base.Cursor = this.cursor_0;
			return;
		}
		base.Cursor = Cursors.Arrow;
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x00049B1C File Offset: 0x00047D1C
	private void method_81()
	{
		this.timer_2.Stop();
		if (this.ToolTip_0 != null && !string.IsNullOrEmpty(this.ToolTip_0.GetToolTip(this)))
		{
			this.ToolTip_0.Hide(this);
			this.ToolTip_0.SetToolTip(this, null);
		}
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x00049B68 File Offset: 0x00047D68
	protected virtual void OnMouseDoubleClick(MouseEventArgs e)
	{
		base.OnMouseDoubleClick(e);
		GClass101 gclass = this.method_107(e.Location);
		if (gclass != null)
		{
			this.vmethod_77(gclass);
		}
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x00049B94 File Offset: 0x00047D94
	private void method_82(GStruct2 gstruct2_0)
	{
		int num = gstruct2_0.int_0;
		int num2 = gstruct2_0.int_0;
		for (int i = gstruct2_0.int_0; i < this.gclass99_0[gstruct2_0.int_1].Count; i++)
		{
			char c = this.gclass99_0[gstruct2_0.int_1][i].char_0;
			if (!char.IsLetterOrDigit(c) && c != '_')
			{
				break;
			}
			num2 = i + 1;
		}
		for (int j = gstruct2_0.int_0 - 1; j >= 0; j--)
		{
			char c2 = this.gclass99_0[gstruct2_0.int_1][j].char_0;
			if (!char.IsLetterOrDigit(c2) && c2 != '_')
			{
				break;
			}
			num = j;
		}
		this.GClass86_5 = new GClass86(this, num2, gstruct2_0.int_1, num, gstruct2_0.int_1);
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x00049C68 File Offset: 0x00047E68
	public int method_83(int int_28)
	{
		int num = this.list_0.BinarySearch(new GStruct1(-10), new FastColoredTextBox.Class93(int_28));
		num = ((num < 0) ? (-num - 2) : num);
		if (num < 0)
		{
			return 0;
		}
		if (num > this.gclass99_0.Count - 1)
		{
			return this.gclass99_0.Count - 1;
		}
		return num;
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x00049CC0 File Offset: 0x00047EC0
	public GStruct2 method_84(Point point_4)
	{
		point_4.Offset(base.HorizontalScroll.Value, base.VerticalScroll.Value);
		point_4.Offset(-this.Int32_7 - this.Padding_0.Left, 0);
		int i = this.method_83(point_4.Y);
		if (i < 0)
		{
			return GStruct2.GStruct2_0;
		}
		int num = 0;
		while (i < this.gclass99_0.Count)
		{
			num = this.list_0[i].int_0 + this.list_0[i].Int32_0 * this.Int32_2;
			if (num > point_4.Y && this.list_0[i].genum17_0 == GEnum17.Visible)
			{
				break;
			}
			i++;
		}
		if (i >= this.gclass99_0.Count)
		{
			i = this.gclass99_0.Count - 1;
		}
		if (this.list_0[i].genum17_0 != GEnum17.Visible)
		{
			i = this.method_106(i);
		}
		int num2 = this.list_0[i].Int32_0;
		if (num > point_4.Y)
		{
			int num3 = (num - point_4.Y - this.Int32_2) / this.Int32_2;
			num -= num3 * this.Int32_2;
			num2 -= num3;
		}
		do
		{
			num2--;
			num -= this.Int32_2;
		}
		while (num > point_4.Y);
		if (num2 < 0)
		{
			num2 = 0;
		}
		int num4 = this.list_0[i].method_0(num2);
		int num5 = this.list_0[i].method_1(num2, this.gclass99_0[i]);
		int num6 = (int)Math.Round((double)((float)point_4.X / (float)this.Int32_4));
		if (num2 > 0)
		{
			num6 -= this.list_0[i].int_2;
		}
		num6 = ((num6 < 0) ? num4 : (num4 + num6));
		if (num6 > num5)
		{
			num6 = num5 + 1;
		}
		if (num6 > this.gclass99_0[i].Count)
		{
			num6 = this.gclass99_0[i].Count;
		}
		return new GStruct2(num6, i);
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x00049EDC File Offset: 0x000480DC
	private GStruct2 method_85(Point point_4)
	{
		point_4.Offset(base.HorizontalScroll.Value, base.VerticalScroll.Value);
		point_4.Offset(-this.Int32_7 - this.Padding_0.Left, 0);
		int num = this.method_83(point_4.Y);
		int num2 = (int)Math.Round((double)((float)point_4.X / (float)this.Int32_4));
		if (num2 < 0)
		{
			num2 = 0;
		}
		return new GStruct2(num2, num);
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x0000AA06 File Offset: 0x00008C06
	public int method_86(Point point_4)
	{
		return this.method_92(this.method_84(point_4));
	}

	// Token: 0x06000BE9 RID: 3049 RVA: 0x00049F58 File Offset: 0x00048158
	public virtual void vmethod_52(ref string string_3)
	{
		this.method_110();
		if (this.eventHandler_5 != null)
		{
			GEventArgs12 geventArgs = new GEventArgs12
			{
				String_0 = string_3
			};
			this.eventHandler_5(this, geventArgs);
			string_3 = geventArgs.String_0;
			if (geventArgs.Boolean_0)
			{
				string_3 = string.Empty;
			}
		}
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x00049FA8 File Offset: 0x000481A8
	public virtual void vmethod_53()
	{
		string text = null;
		this.vmethod_52(ref text);
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x00049FC0 File Offset: 0x000481C0
	public virtual void vmethod_54()
	{
		GClass86 gclass = new GClass86(this);
		gclass.method_2();
		this.vmethod_57(new GEventArgs11(gclass));
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x00049FE8 File Offset: 0x000481E8
	public virtual void vmethod_55(int int_28, int int_29)
	{
		this.vmethod_57(new GEventArgs11(new GClass86(this)
		{
			GStruct2_0 = new GStruct2(0, Math.Min(int_28, int_29)),
			GStruct2_1 = new GStruct2(this.gclass99_0[Math.Max(int_28, int_29)].Count, Math.Max(int_28, int_29))
		}));
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x0000AA15 File Offset: 0x00008C15
	public virtual void vmethod_56(GClass86 gclass86_9)
	{
		this.vmethod_57(new GEventArgs11(gclass86_9));
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x0000AA23 File Offset: 0x00008C23
	public void method_87()
	{
		if (this.int_17 == 0)
		{
			this.gclass86_5 = null;
		}
		this.int_17++;
	}

	// Token: 0x06000BEF RID: 3055 RVA: 0x0000AA42 File Offset: 0x00008C42
	public void method_88()
	{
		this.int_17--;
		if (this.int_17 == 0 && this.gclass86_5 != null)
		{
			this.gclass86_5.method_42();
			this.vmethod_56(this.gclass86_5);
		}
	}

	// Token: 0x06000BF0 RID: 3056 RVA: 0x0004A044 File Offset: 0x00048244
	protected virtual void vmethod_57(GEventArgs11 geventArgs11_0)
	{
		geventArgs11_0.GClass86_0.method_40();
		if (this.int_17 <= 0)
		{
			this.method_81();
			this.method_1();
			this.Boolean_8 = true;
			int int32_ = this.Int32_6;
			this.Int32_6 = int32_ + 1;
			this.method_90(geventArgs11_0.GClass86_0);
			this.method_89(geventArgs11_0.GClass86_0);
			if (this.bool_19)
			{
				this.method_45(geventArgs11_0.GClass86_0.GStruct2_0.int_1, geventArgs11_0.GClass86_0.GStruct2_1.int_1);
			}
			base.OnTextChanged(geventArgs11_0);
			if (this.gclass86_0 == null)
			{
				this.gclass86_0 = geventArgs11_0.GClass86_0.method_6();
			}
			else
			{
				this.gclass86_0 = this.gclass86_0.method_1(geventArgs11_0.GClass86_0);
			}
			this.bool_14 = true;
			this.method_20(this.timer_1);
			this.vmethod_78(geventArgs11_0);
			if (this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs11_0);
			}
			if (this.eventHandler_3 != null)
			{
				this.eventHandler_3(this, EventArgs.Empty);
			}
			base.OnTextChanged(EventArgs.Empty);
			this.vmethod_4();
			return;
		}
		if (this.gclass86_5 == null)
		{
			this.gclass86_5 = geventArgs11_0.GClass86_0.method_6();
			return;
		}
		if (this.gclass86_5.GStruct2_0.int_1 > geventArgs11_0.GClass86_0.GStruct2_0.int_1)
		{
			this.gclass86_5.GStruct2_0 = new GStruct2(0, geventArgs11_0.GClass86_0.GStruct2_0.int_1);
		}
		if (this.gclass86_5.GStruct2_1.int_1 < geventArgs11_0.GClass86_0.GStruct2_1.int_1)
		{
			this.gclass86_5.GStruct2_1 = new GStruct2(this.gclass99_0[geventArgs11_0.GClass86_0.GStruct2_1.int_1].Count, geventArgs11_0.GClass86_0.GStruct2_1.int_1);
		}
		this.gclass86_5 = this.gclass86_5.vmethod_0(this.GClass86_6);
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x0004A23C File Offset: 0x0004843C
	private void method_89(GClass86 gclass86_9)
	{
		for (int i = gclass86_9.GStruct2_0.int_1; i <= gclass86_9.GStruct2_1.int_1; i++)
		{
			if (i >= 0 && i < this.gclass99_0.Count)
			{
				this.Dictionary_0.Remove(this[i].Int32_0);
			}
		}
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x0004A294 File Offset: 0x00048494
	private void method_90(GClass86 gclass86_9)
	{
		for (int i = gclass86_9.GStruct2_0.int_1; i <= gclass86_9.GStruct2_1.int_1; i++)
		{
			if (i >= 0 && i < this.gclass99_0.Count)
			{
				this.gclass99_0[i].Boolean_0 = true;
			}
		}
	}

	// Token: 0x06000BF3 RID: 3059 RVA: 0x0000AA79 File Offset: 0x00008C79
	public virtual void vmethod_58()
	{
		if (this.Boolean_14)
		{
			this.method_91();
		}
		this.bool_13 = true;
		this.method_20(this.timer_0);
		if (this.eventHandler_6 != null)
		{
			this.eventHandler_6(this, new EventArgs());
		}
	}

	// Token: 0x06000BF4 RID: 3060 RVA: 0x0004A2E8 File Offset: 0x000484E8
	private void method_91()
	{
		if (this.Int32_14 == 0)
		{
			return;
		}
		int num = this.int_16;
		int num2 = this.int_10;
		this.int_16 = -1;
		this.int_10 = -1;
		int num3 = 0;
		for (int i = this.GClass86_5.GStruct2_0.int_1; i >= Math.Max(this.GClass86_5.GStruct2_0.int_1 - 3000, 0); i--)
		{
			bool flag = this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(i);
			bool flag2;
			if (!(flag2 = this.gclass99_0.GClass99.\u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(i)) || !flag)
			{
				if (flag)
				{
					num3--;
					if (num3 == -1)
					{
						this.int_16 = i;
						IL_B1:
						if (this.int_16 >= 0)
						{
							this.int_10 = this.vmethod_66(this.int_16, 3000);
							if (this.int_10 == this.int_16)
							{
								this.int_10 = -1;
							}
						}
						if (this.int_16 != num || this.int_10 != num2)
						{
							this.vmethod_59();
						}
						return;
					}
				}
				if (flag2 && i != this.GClass86_5.GStruct2_0.int_1)
				{
					num3++;
				}
			}
		}
		goto IL_B1;
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x0000AAB5 File Offset: 0x00008CB5
	protected virtual void vmethod_59()
	{
		if (this.eventHandler_16 != null)
		{
			this.eventHandler_16(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x0000AAD0 File Offset: 0x00008CD0
	protected virtual void OnGotFocus(EventArgs e)
	{
		this.method_6();
		base.OnGotFocus(e);
		this.method_4();
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x0000AAE5 File Offset: 0x00008CE5
	protected virtual void OnLostFocus(EventArgs e)
	{
		this.keys_0 = Keys.None;
		this.method_138();
		base.OnLostFocus(e);
		this.method_4();
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x0004A3F4 File Offset: 0x000485F4
	public int method_92(GStruct2 gstruct2_0)
	{
		if (gstruct2_0.int_1 >= 0 && gstruct2_0.int_1 < this.gclass99_0.Count && gstruct2_0.int_0 < this.gclass99_0[gstruct2_0.int_1].Count + Environment.NewLine.Length)
		{
			int num = 0;
			for (int i = 0; i < gstruct2_0.int_1; i++)
			{
				num += this.gclass99_0[i].Count + Environment.NewLine.Length;
			}
			return num + gstruct2_0.int_0;
		}
		return -1;
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x0004A484 File Offset: 0x00048684
	public GStruct2 method_93(int int_28)
	{
		if (int_28 < 0)
		{
			return new GStruct2(0, 0);
		}
		for (int i = 0; i < this.gclass99_0.Count; i++)
		{
			int num = this.gclass99_0[i].Count + Environment.NewLine.Length;
			if (int_28 < this.gclass99_0[i].Count)
			{
				return new GStruct2(int_28, i);
			}
			if (int_28 < num)
			{
				return new GStruct2(this.gclass99_0[i].Count, i);
			}
			int_28 -= num;
		}
		if (this.gclass99_0.Count > 0)
		{
			return new GStruct2(this.gclass99_0[this.gclass99_0.Count - 1].Count, this.gclass99_0.Count - 1);
		}
		return new GStruct2(0, 0);
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x0000AB01 File Offset: 0x00008D01
	public Point method_94(int int_28)
	{
		return this.method_95(this.method_93(int_28));
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x0004A554 File Offset: 0x00048754
	public Point method_95(GStruct2 gstruct2_0)
	{
		if (gstruct2_0.int_1 >= this.list_0.Count)
		{
			return default(Point);
		}
		int num = this.list_0[gstruct2_0.int_1].int_0;
		int num2 = this.list_0[gstruct2_0.int_1].method_2(gstruct2_0.int_0);
		num += num2 * this.Int32_2;
		int num3 = (gstruct2_0.int_0 - this.list_0[gstruct2_0.int_1].method_0(num2)) * this.Int32_4;
		if (num2 > 0)
		{
			num3 += this.list_0[gstruct2_0.int_1].int_2 * this.Int32_4;
		}
		num -= base.VerticalScroll.Value;
		num3 = this.Int32_7 + this.Padding_0.Left + num3 - base.HorizontalScroll.Value;
		return new Point(num3, num);
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x0000AB10 File Offset: 0x00008D10
	public GClass86 method_96(int int_28, int int_29)
	{
		return new GClass86(this)
		{
			GStruct2_0 = this.method_93(int_28),
			GStruct2_1 = this.method_93(int_29)
		};
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0000AB32 File Offset: 0x00008D32
	public GClass86 method_97(GStruct2 gstruct2_0, GStruct2 gstruct2_1)
	{
		return new GClass86(this, gstruct2_0, gstruct2_1);
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x0000AB3C File Offset: 0x00008D3C
	public IEnumerable<GClass86> method_98(string string_3)
	{
		FastColoredTextBox.Class100 @class = new FastColoredTextBox.Class100(-2);
		@class.fastColoredTextBox_0 = this;
		@class.string_1 = string_3;
		return @class;
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x0000AB53 File Offset: 0x00008D53
	public IEnumerable<GClass86> method_99(string string_3, RegexOptions regexOptions_0)
	{
		FastColoredTextBox.Class101 @class = new FastColoredTextBox.Class101(-2);
		@class.fastColoredTextBox_0 = this;
		@class.string_1 = string_3;
		@class.regexOptions_1 = regexOptions_0;
		return @class;
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x0004A64C File Offset: 0x0004884C
	public string method_100(int int_28)
	{
		if (int_28 >= 0 && int_28 < this.gclass99_0.Count)
		{
			StringBuilder stringBuilder = new StringBuilder(this.gclass99_0[int_28].Count);
			using (IEnumerator<GStruct0> enumerator = this.gclass99_0[int_28].GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					GStruct0 gstruct = enumerator.Current;
					stringBuilder.Append(gstruct.char_0);
				}
				goto IL_71;
			}
			goto IL_66;
			IL_71:
			return stringBuilder.ToString();
		}
		IL_66:
		throw new ArgumentOutOfRangeException("Line index out of range");
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x0004A6E0 File Offset: 0x000488E0
	public virtual void vmethod_60(int int_28)
	{
		if (int_28 >= 0 && int_28 < this.gclass99_0.Count)
		{
			for (int i = int_28; i < this.Int32_14 - 1; i++)
			{
				if (this.list_0[i + 1].genum17_0 != GEnum17.Hidden)
				{
					IL_48:
					this.vmethod_62(int_28, i);
					this.Dictionary_0.Remove(this[int_28].Int32_0);
					this.vmethod_61();
					return;
				}
			}
			goto IL_48;
		}
		throw new ArgumentOutOfRangeException("Line index out of range");
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x0004A75C File Offset: 0x0004895C
	public virtual void vmethod_61()
	{
		for (int i = 0; i < this.Int32_14; i++)
		{
			if (this.list_0[i].genum17_0 == GEnum17.Visible && this.Dictionary_0.ContainsKey(this[i].Int32_0))
			{
				this.vmethod_65(i);
			}
		}
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x0004A7B0 File Offset: 0x000489B0
	public virtual void vmethod_62(int int_28, int int_29)
	{
		int num = Math.Min(int_28, int_29);
		int num2 = Math.Max(int_28, int_29);
		for (int i = num; i <= num2; i++)
		{
			this.method_129(i, GEnum17.Visible);
		}
		this.bool_10 = true;
		this.method_4();
		this.vmethod_4();
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x0004A7F4 File Offset: 0x000489F4
	public void method_101(int int_28)
	{
		if (this.list_0[int_28].genum17_0 == GEnum17.Visible)
		{
			return;
		}
		int num = int_28;
		while (num < this.Int32_14 && this.list_0[num].genum17_0 != GEnum17.Visible)
		{
			this.method_129(num, GEnum17.Visible);
			this.bool_10 = true;
			num++;
		}
		int num2 = int_28 - 1;
		while (num2 >= 0 && this.list_0[num2].genum17_0 != GEnum17.Visible)
		{
			this.method_129(num2, GEnum17.Visible);
			this.bool_10 = true;
			num2--;
		}
		this.method_4();
		this.vmethod_4();
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x0004A884 File Offset: 0x00048A84
	public virtual void vmethod_63()
	{
		for (int i = 0; i < this.Int32_14; i++)
		{
			if (this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(i))
			{
				int num = this.method_102(i);
				if (num >= 0)
				{
					this.vmethod_68(i, num);
					i = num;
				}
			}
		}
		this.vmethod_4();
		this.method_47();
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x0004A8D4 File Offset: 0x00048AD4
	public virtual void vmethod_64()
	{
		for (int i = 0; i < this.Int32_14; i++)
		{
			this.method_129(i, GEnum17.Visible);
		}
		this.Dictionary_0.Clear();
		this.vmethod_4();
		this.method_4();
		this.method_47();
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x0004A918 File Offset: 0x00048B18
	public virtual void vmethod_65(int int_28)
	{
		if (int_28 < 0 || int_28 >= this.gclass99_0.Count)
		{
			throw new ArgumentOutOfRangeException("Line index out of range");
		}
		if (string.IsNullOrEmpty(this.gclass99_0[int_28].String_0))
		{
			throw new ArgumentOutOfRangeException("This line is not folding start line");
		}
		int num = this.method_102(int_28);
		if (num >= 0)
		{
			this.vmethod_68(int_28, num);
			int int32_ = this[int_28].Int32_0;
			this.Dictionary_0[int32_] = int32_;
		}
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x0000AB71 File Offset: 0x00008D71
	private int method_102(int int_28)
	{
		return this.vmethod_66(int_28, int.MaxValue);
	}

	// Token: 0x06000C09 RID: 3081 RVA: 0x0004A998 File Offset: 0x00048B98
	protected virtual int vmethod_66(int int_28, int int_29)
	{
		string text = this.gclass99_0[int_28].String_0;
		Stack<string> stack = new Stack<string>();
		GEnum13 genum = this.GEnum13_0;
		if (genum != GEnum13.Strategy1)
		{
			if (genum == GEnum13.Strategy2)
			{
				for (int i = int_28; i < this.Int32_14; i++)
				{
					if (this.gclass99_0.GClass99.\u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(i))
					{
						string b = this.gclass99_0[i].String_1;
						while (stack.Count > 0 && stack.Pop() != b)
						{
						}
						if (stack.Count == 0)
						{
							return i;
						}
					}
					if (this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(i))
					{
						stack.Push(this.gclass99_0[i].String_0);
					}
					int_29--;
					if (int_29 < 0)
					{
						return i;
					}
				}
			}
		}
		else
		{
			for (int i = int_28; i < this.Int32_14; i++)
			{
				if (this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(i))
				{
					stack.Push(this.gclass99_0[i].String_0);
				}
				if (this.gclass99_0.GClass99.\u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(i))
				{
					string b2 = this.gclass99_0[i].String_1;
					while (stack.Count > 0 && stack.Pop() != b2)
					{
					}
					if (stack.Count == 0)
					{
						return i;
					}
				}
				int_29--;
				if (int_29 < 0)
				{
					return i;
				}
			}
		}
		return this.Int32_14 - 1;
	}

	// Token: 0x06000C0A RID: 3082 RVA: 0x0000AB7F File Offset: 0x00008D7F
	public string method_103(int int_28)
	{
		if (this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(int_28))
		{
			return this.gclass99_0[int_28].String_0;
		}
		return null;
	}

	// Token: 0x06000C0B RID: 3083 RVA: 0x0000ABA2 File Offset: 0x00008DA2
	public string method_104(int int_28)
	{
		if (this.gclass99_0.GClass99.\u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(int_28))
		{
			return this.gclass99_0[int_28].String_1;
		}
		return null;
	}

	// Token: 0x06000C0C RID: 3084 RVA: 0x0004AAEC File Offset: 0x00048CEC
	protected virtual void vmethod_67()
	{
		if (!this.bool_12)
		{
			return;
		}
		this.bool_12 = false;
		if (!this.Boolean_11)
		{
			return;
		}
		this.dictionary_0.Clear();
		GClass86 gclass = this.GClass86_4;
		int num = Math.Max(gclass.GStruct2_0.int_1 - 3000, 0);
		int num2 = Math.Min(gclass.GStruct2_1.int_1 + 3000, Math.Max(gclass.GStruct2_1.int_1, this.Int32_14 - 1));
		Stack<int> stack = new Stack<int>();
		for (int i = num; i <= num2; i++)
		{
			bool flag = this.gclass99_0.GClass99.\u200C\u206F\u200C\u202C\u206B\u202C\u202D\u206D\u206B\u206E\u202E\u206F\u206B\u206C\u200F\u206D\u200C\u206A\u200C\u202D\u206A\u202C\u200E\u206C\u202E\u200C\u202C\u206F\u202A\u200F\u200C\u206B\u206F\u200F\u200B\u202D\u200F\u200C\u206E\u206F\u202E(i);
			bool flag2;
			if (!(flag2 = this.gclass99_0.GClass99.\u202D\u202D\u200D\u202B\u206D\u206E\u200E\u206B\u202D\u202D\u200F\u200F\u200D\u200C\u206C\u202E\u206E\u202A\u200C\u206E\u202C\u202A\u200E\u206F\u206E\u202C\u206C\u202E\u206E\u200E\u202E\u202A\u200F\u202B\u206D\u202A\u206F\u206E\u200B\u202D\u202E(i)) || !flag)
			{
				if (flag)
				{
					stack.Push(i);
				}
				if (flag2)
				{
					string a = this.gclass99_0[i].String_1;
					while (stack.Count > 0)
					{
						int num3 = stack.Pop();
						this.dictionary_0[num3] = i;
						if (a == this.gclass99_0[num3].String_0)
						{
							break;
						}
					}
				}
			}
		}
		while (stack.Count > 0)
		{
			this.dictionary_0[stack.Pop()] = num2 + 1;
		}
	}

	// Token: 0x06000C0D RID: 3085 RVA: 0x0004AC20 File Offset: 0x00048E20
	public virtual void vmethod_68(int int_28, int int_29)
	{
		int num = Math.Min(int_28, int_29);
		int num2 = Math.Max(int_28, int_29);
		if (num == num2)
		{
			return;
		}
		for (int i = num + 1; i <= num2; i++)
		{
			this.method_129(i, GEnum17.Hidden);
		}
		this.method_129(num, GEnum17.StartOfHiddenBlock);
		this.method_4();
		num = Math.Min(int_28, int_29);
		num2 = Math.Max(int_28, int_29);
		int num3 = this.method_105(num2);
		if (num3 == num2)
		{
			num3 = this.method_106(num);
		}
		this.GClass86_5.GStruct2_0 = new GStruct2(0, num3);
		this.bool_10 = true;
		this.method_4();
		this.vmethod_4();
	}

	// Token: 0x06000C0E RID: 3086 RVA: 0x0004ACB0 File Offset: 0x00048EB0
	internal int method_105(int int_28)
	{
		if (int_28 >= this.gclass99_0.Count - 1)
		{
			return int_28;
		}
		int result = int_28;
		do
		{
			int_28++;
		}
		while (int_28 < this.gclass99_0.Count - 1 && this.list_0[int_28].genum17_0 != GEnum17.Visible);
		if (this.list_0[int_28].genum17_0 != GEnum17.Visible)
		{
			return result;
		}
		return int_28;
	}

	// Token: 0x06000C0F RID: 3087 RVA: 0x0004AD14 File Offset: 0x00048F14
	internal int method_106(int int_28)
	{
		if (int_28 <= 0)
		{
			return int_28;
		}
		int result = int_28;
		do
		{
			int_28--;
		}
		while (int_28 > 0 && this.list_0[int_28].genum17_0 != GEnum17.Visible);
		if (this.list_0[int_28].genum17_0 != GEnum17.Visible)
		{
			return result;
		}
		return int_28;
	}

	// Token: 0x06000C10 RID: 3088 RVA: 0x0004AD60 File Offset: 0x00048F60
	private GClass101 method_107(Point point_4)
	{
		foreach (GClass101 gclass in this.list_1)
		{
			if (gclass.rectangle_0.Contains(point_4))
			{
				return gclass;
			}
		}
		return null;
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x0004ADC8 File Offset: 0x00048FC8
	public virtual void vmethod_69()
	{
		if (GStruct2.smethod_1(this.GClass86_5.GStruct2_0, this.GClass86_5.GStruct2_1))
		{
			if (!this.GClass86_5.Boolean_1)
			{
				this.GClass86_5.GStruct2_0 = new GStruct2(this[this.GClass86_5.GStruct2_0.int_1].Int32_2, this.GClass86_5.GStruct2_0.int_1);
				int num = this.Int32_5 - this.GClass86_5.GStruct2_0.int_0 % this.Int32_5;
				if (this.Boolean_15)
				{
					for (int i = 0; i < num; i++)
					{
						this.GClass86_5.method_11(true);
					}
					this.GClass86_5.method_41();
				}
				this.vmethod_20(new string(' ', num));
			}
			return;
		}
		bool flag = GStruct2.smethod_4(this.GClass86_5.GStruct2_0, this.GClass86_5.GStruct2_1) && !this.GClass86_5.Boolean_0;
		int num2 = 0;
		if (this.GClass86_5.Boolean_0)
		{
			num2 = Math.Min(this.GClass86_5.GStruct2_1.int_0, this.GClass86_5.GStruct2_0.int_0);
		}
		this.method_87();
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		GClass86 gclass = this.GClass86_5.method_6();
		this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
		this.GClass86_5.method_40();
		GClass86 gclass2 = this.GClass86_5.method_6();
		int num3 = this.GClass86_5.GStruct2_0.int_1;
		int num4 = this.GClass86_5.GStruct2_1.int_1;
		if (!this.GClass86_5.Boolean_0 && this.GClass86_5.GStruct2_1.int_0 == 0)
		{
			num4--;
		}
		for (int j = num3; j <= num4; j++)
		{
			if (this.gclass99_0[j].Count != 0)
			{
				this.GClass86_5.GStruct2_0 = new GStruct2(num2, j);
				this.gclass99_0.GClass59_0.vmethod_0(new GClass63(this.GClass99_0, new string(' ', this.Int32_5)));
			}
		}
		if (!this.GClass86_5.Boolean_0)
		{
			int num5 = gclass2.GStruct2_0.int_0 + this.Int32_5;
			int num6 = gclass2.GStruct2_1.int_0 + ((gclass2.GStruct2_1.int_1 == num4) ? this.Int32_5 : 0);
			this.GClass86_5.GStruct2_0 = new GStruct2(num5, gclass2.GStruct2_0.int_1);
			this.GClass86_5.GStruct2_1 = new GStruct2(num6, gclass2.GStruct2_1.int_1);
		}
		else
		{
			this.GClass86_5 = gclass;
		}
		this.gclass99_0.GClass59_0.method_3();
		if (flag)
		{
			this.GClass86_5.method_41();
		}
		this.bool_10 = true;
		this.GClass86_5.method_39();
		this.method_88();
		this.method_4();
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x0004B0D0 File Offset: 0x000492D0
	public virtual void vmethod_70()
	{
		if (this.GClass86_5.GStruct2_0.int_1 == this.GClass86_5.GStruct2_1.int_1)
		{
			this.vmethod_71();
			return;
		}
		int num = 0;
		if (this.GClass86_5.Boolean_0)
		{
			num = Math.Min(this.GClass86_5.GStruct2_1.int_0, this.GClass86_5.GStruct2_0.int_0);
		}
		this.method_87();
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		GClass86 gclass = this.GClass86_5.method_6();
		this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
		GClass86 gclass2 = this.GClass86_5.method_6();
		this.GClass86_5.method_40();
		int num2 = this.GClass86_5.GStruct2_0.int_1;
		int num3 = this.GClass86_5.GStruct2_1.int_1;
		if (!this.GClass86_5.Boolean_0 && this.GClass86_5.GStruct2_1.int_0 == 0)
		{
			num3--;
		}
		int num4 = 0;
		int num5 = 0;
		for (int i = num2; i <= num3; i++)
		{
			if (num <= this.gclass99_0[i].Count)
			{
				int num6 = Math.Min(this.gclass99_0[i].Count, num + this.Int32_5);
				string text = this.gclass99_0[i].String_2.Substring(num, num6 - num);
				num6 = Math.Min(num6, num + text.Length - text.TrimStart(new char[0]).Length);
				this.GClass86_5 = new GClass86(this, new GStruct2(num, i), new GStruct2(num6, i));
				int num7 = num6 - num;
				if (i == gclass2.GStruct2_0.int_1)
				{
					num4 = num7;
				}
				if (i == gclass2.GStruct2_1.int_1)
				{
					num5 = num7;
				}
				if (!this.GClass86_5.Boolean_2)
				{
					this.vmethod_28();
				}
			}
		}
		if (!this.GClass86_5.Boolean_0)
		{
			int num8 = Math.Max(0, gclass2.GStruct2_0.int_0 - num4);
			int num9 = Math.Max(0, gclass2.GStruct2_1.int_0 - num5);
			this.GClass86_5.GStruct2_0 = new GStruct2(num8, gclass2.GStruct2_0.int_1);
			this.GClass86_5.GStruct2_1 = new GStruct2(num9, gclass2.GStruct2_1.int_1);
		}
		else
		{
			this.GClass86_5 = gclass;
		}
		this.gclass99_0.GClass59_0.method_3();
		this.bool_10 = true;
		this.GClass86_5.method_39();
		this.method_88();
		this.method_4();
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x0004B37C File Offset: 0x0004957C
	protected virtual void vmethod_71()
	{
		if (this.GClass86_5.GStruct2_0.int_1 != this.GClass86_5.GStruct2_1.int_1)
		{
			return;
		}
		GClass86 gclass = this.GClass86_5.method_6();
		int i = this.GClass86_5.GStruct2_0.int_1;
		int num = Math.Min(this.GClass86_5.GStruct2_0.int_0, this.GClass86_5.GStruct2_1.int_0);
		string input = this.gclass99_0[i].String_2;
		Match match = new Regex("\\s*", RegexOptions.RightToLeft).Match(input, num);
		int index = match.Index;
		int length = match.Length;
		int num2 = 0;
		if (length > 0)
		{
			int num3 = (this.Int32_5 > 0) ? (num % this.Int32_5) : 0;
			num2 = ((num3 != 0) ? Math.Min(num3, length) : Math.Min(this.Int32_5, length));
		}
		if (num2 > 0)
		{
			this.method_87();
			this.GClass86_5.method_38();
			this.gclass99_0.GClass59_0.method_4();
			this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
			this.GClass86_5.GStruct2_0 = new GStruct2(index, i);
			this.GClass86_5.GStruct2_1 = new GStruct2(index + num2, i);
			this.vmethod_28();
			int num4 = gclass.GStruct2_0.int_0 - num2;
			int num5 = gclass.GStruct2_1.int_0 - num2;
			this.GClass86_5.GStruct2_0 = new GStruct2(num4, i);
			this.GClass86_5.GStruct2_1 = new GStruct2(num5, i);
			this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
			this.gclass99_0.GClass59_0.method_3();
			this.GClass86_5.method_39();
			this.method_88();
		}
		this.method_4();
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x0004B55C File Offset: 0x0004975C
	public virtual void vmethod_72()
	{
		if (this.GClass86_5.Boolean_0)
		{
			return;
		}
		GClass86 gclass = this.GClass86_5.method_6();
		gclass.method_40();
		this.method_87();
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		for (int i = gclass.GStruct2_0.int_1; i <= gclass.GStruct2_1.int_1; i++)
		{
			this.vmethod_44(i);
		}
		this.gclass99_0.GClass59_0.method_3();
		this.GClass86_5.GStruct2_0 = gclass.GStruct2_0;
		this.GClass86_5.GStruct2_1 = gclass.GStruct2_1;
		this.GClass86_5.method_42();
		this.GClass86_5.method_39();
		this.method_88();
	}

	// Token: 0x06000C15 RID: 3093 RVA: 0x0004B620 File Offset: 0x00049820
	public virtual void vmethod_73(string string_3)
	{
		this.GClass86_5.method_6();
		int num = Math.Min(this.GClass86_5.GStruct2_0.int_1, this.GClass86_5.GStruct2_1.int_1);
		int num2 = Math.Max(this.GClass86_5.GStruct2_0.int_1, this.GClass86_5.GStruct2_1.int_1);
		this.method_87();
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
		int num3 = this.method_68(num, num2);
		for (int i = num; i <= num2; i++)
		{
			this.GClass86_5.GStruct2_0 = new GStruct2(num3, i);
			this.gclass99_0.GClass59_0.vmethod_0(new GClass63(this.GClass99_0, string_3));
		}
		this.GClass86_5.GStruct2_0 = new GStruct2(0, num);
		this.GClass86_5.GStruct2_1 = new GStruct2(this.gclass99_0[num2].Count, num2);
		this.bool_10 = true;
		this.gclass99_0.GClass59_0.method_3();
		this.GClass86_5.method_39();
		this.method_88();
		this.method_4();
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x0004B768 File Offset: 0x00049968
	public virtual void vmethod_74(string string_3)
	{
		this.GClass86_5.method_6();
		int num = Math.Min(this.GClass86_5.GStruct2_0.int_1, this.GClass86_5.GStruct2_1.int_1);
		int num2 = Math.Max(this.GClass86_5.GStruct2_0.int_1, this.GClass86_5.GStruct2_1.int_1);
		this.method_87();
		this.GClass86_5.method_38();
		this.gclass99_0.GClass59_0.method_4();
		this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.GClass99_0));
		for (int i = num; i <= num2; i++)
		{
			string text = this.gclass99_0[i].String_2;
			string text2 = text.TrimStart(new char[0]);
			if (text2.StartsWith(string_3))
			{
				int num3 = text.Length - text2.Length;
				this.GClass86_5.GStruct2_0 = new GStruct2(num3, i);
				this.GClass86_5.GStruct2_1 = new GStruct2(num3 + string_3.Length, i);
				this.vmethod_28();
			}
		}
		this.GClass86_5.GStruct2_0 = new GStruct2(0, num);
		this.GClass86_5.GStruct2_1 = new GStruct2(this.gclass99_0[num2].Count, num2);
		this.bool_10 = true;
		this.gclass99_0.GClass59_0.method_3();
		this.GClass86_5.method_39();
		this.method_88();
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x0000ABC5 File Offset: 0x00008DC5
	public void method_108()
	{
		this.gclass99_0.GClass59_0.method_4();
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x0000ABD7 File Offset: 0x00008DD7
	public void method_109()
	{
		this.gclass99_0.GClass59_0.method_3();
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x0000ABE9 File Offset: 0x00008DE9
	public virtual void vmethod_75(MouseEventArgs mouseEventArgs_0, GClass105 gclass105_0)
	{
		if (this.eventHandler_11 != null)
		{
			this.eventHandler_11(this, new GEventArgs21(gclass105_0.GClass87_0, gclass105_0, mouseEventArgs_0));
		}
		gclass105_0.GClass87_0.vmethod_0(this, new GEventArgs21(gclass105_0.GClass87_0, gclass105_0, mouseEventArgs_0));
	}

	// Token: 0x06000C1A RID: 3098 RVA: 0x0004B8E0 File Offset: 0x00049AE0
	protected virtual void vmethod_76(MouseEventArgs mouseEventArgs_0, GClass101 gclass101_0)
	{
		if (gclass101_0 is GClass105)
		{
			this.vmethod_75(mouseEventArgs_0, gclass101_0 as GClass105);
			return;
		}
		if (gclass101_0 is GClass102)
		{
			this.vmethod_65((gclass101_0 as GClass102).int_0);
			return;
		}
		if (gclass101_0 is GClass103)
		{
			this.vmethod_60((gclass101_0 as GClass103).int_0);
			return;
		}
		if (!(gclass101_0 is GClass104))
		{
			return;
		}
		int int_ = (gclass101_0 as GClass104).int_0;
		int num = this.method_102(int_);
		if (num < 0)
		{
			return;
		}
		this.GClass86_5.method_38();
		this.GClass86_5.GStruct2_0 = new GStruct2(0, int_);
		this.GClass86_5.GStruct2_1 = new GStruct2(this.gclass99_0[num].Count, num);
		this.GClass86_5.method_39();
		this.method_4();
	}

	// Token: 0x06000C1B RID: 3099 RVA: 0x0000AC25 File Offset: 0x00008E25
	protected virtual void vmethod_77(GClass101 gclass101_0)
	{
		if (gclass101_0 is GClass104)
		{
			this.vmethod_60((gclass101_0 as GClass104).int_0);
			this.method_4();
			return;
		}
	}

	// Token: 0x06000C1C RID: 3100 RVA: 0x0000AC47 File Offset: 0x00008E47
	private void method_110()
	{
		this.gclass86_1 = null;
		this.gclass86_3 = null;
		this.gclass86_2 = null;
		this.gclass86_4 = null;
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x0004B9AC File Offset: 0x00049BAC
	private void method_111(char char_5, char char_6, ref GClass86 gclass86_9, ref GClass86 gclass86_10)
	{
		GEnum14 genum = this.GEnum14_0;
		if (genum == GEnum14.Strategy1)
		{
			this.method_112(char_5, char_6, ref gclass86_9, ref gclass86_10);
			return;
		}
		if (genum != GEnum14.Strategy2)
		{
			return;
		}
		this.method_114(char_5, char_6, ref gclass86_9, ref gclass86_10);
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x0004B9E0 File Offset: 0x00049BE0
	private void method_112(char char_5, char char_6, ref GClass86 gclass86_9, ref GClass86 gclass86_10)
	{
		if (!this.GClass86_5.Boolean_2)
		{
			return;
		}
		if (this.Int32_14 == 0)
		{
			return;
		}
		GClass86 gclass = gclass86_9;
		GClass86 gclass2 = gclass86_10;
		GClass86 gclass3 = this.method_113(this.GClass86_5.GStruct2_0, char_5, char_6, true);
		if (gclass3 != null)
		{
			gclass86_9 = new GClass86(this, gclass3.GStruct2_0, new GStruct2(gclass3.GStruct2_0.int_0 + 1, gclass3.GStruct2_0.int_1));
			gclass86_10 = new GClass86(this, new GStruct2(gclass3.GStruct2_1.int_0 - 1, gclass3.GStruct2_1.int_1), gclass3.GStruct2_1);
		}
		if (gclass != gclass86_9 || gclass2 != gclass86_10)
		{
			this.method_4();
		}
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x0004BA8C File Offset: 0x00049C8C
	public GClass86 method_113(GStruct2 gstruct2_0, char char_5, char char_6, bool bool_37)
	{
		GClass86 gclass = new GClass86(this, gstruct2_0, gstruct2_0);
		GClass86 gclass2 = gclass.method_6();
		GClass86 gclass3 = null;
		GClass86 gclass4 = null;
		int num = 0;
		int num2 = 1000;
		while (gclass2.method_9())
		{
			if (gclass2.Char_0 == char_5)
			{
				num++;
			}
			if (gclass2.Char_0 == char_6)
			{
				num--;
			}
			if (num == 1)
			{
				gclass2.GStruct2_0 = new GStruct2(gclass2.GStruct2_0.int_0 + ((!bool_37) ? 1 : 0), gclass2.GStruct2_0.int_1);
				gclass3 = gclass2;
			}
			else
			{
				num2--;
				if (num2 > 0)
				{
					continue;
				}
			}
			IL_86:
			gclass2 = gclass.method_6();
			num = 0;
			num2 = 1000;
			for (;;)
			{
				if (gclass2.Char_0 == char_5)
				{
					num++;
				}
				if (gclass2.Char_0 == char_6)
				{
					num--;
				}
				if (num == -1)
				{
					break;
				}
				num2--;
				if (num2 <= 0)
				{
					goto IL_103;
				}
				if (!gclass2.vmethod_1())
				{
					goto Block_9;
				}
			}
			gclass2.GStruct2_1 = new GStruct2(gclass2.GStruct2_0.int_0 + (bool_37 ? 1 : 0), gclass2.GStruct2_0.int_1);
			gclass4 = gclass2;
			Block_9:
			IL_103:
			if (gclass3 != null && gclass4 != null)
			{
				return new GClass86(this, gclass3.GStruct2_0, gclass4.GStruct2_1);
			}
			return null;
		}
		goto IL_86;
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x0004BBB8 File Offset: 0x00049DB8
	private void method_114(char char_5, char char_6, ref GClass86 gclass86_9, ref GClass86 gclass86_10)
	{
		if (!this.GClass86_5.Boolean_2)
		{
			return;
		}
		if (this.Int32_14 == 0)
		{
			return;
		}
		GClass86 gclass = gclass86_9;
		GClass86 gclass2 = gclass86_10;
		GClass86 gclass3 = this.GClass86_5.method_6();
		bool flag = false;
		int num = 0;
		int num2 = 1000;
		if (gclass3.Char_1 == char_6)
		{
			gclass86_10 = new GClass86(this, gclass3.GStruct2_0.int_0 - 1, gclass3.GStruct2_0.int_1, gclass3.GStruct2_0.int_0, gclass3.GStruct2_0.int_1);
			while (gclass3.method_9())
			{
				if (gclass3.Char_0 == char_5)
				{
					num++;
				}
				if (gclass3.Char_0 == char_6)
				{
					num--;
				}
				if (num == 0)
				{
					gclass3.GStruct2_1 = new GStruct2(gclass3.GStruct2_0.int_0 + 1, gclass3.GStruct2_0.int_1);
					gclass86_9 = gclass3;
					flag = true;
					break;
				}
				num2--;
				if (num2 <= 0)
				{
					break;
				}
			}
		}
		gclass3 = this.GClass86_5.method_6();
		num = 0;
		num2 = 1000;
		if (!flag && gclass3.Char_0 == char_5)
		{
			gclass86_9 = new GClass86(this, gclass3.GStruct2_0.int_0, gclass3.GStruct2_0.int_1, gclass3.GStruct2_0.int_0 + 1, gclass3.GStruct2_0.int_1);
			do
			{
				if (gclass3.Char_0 == char_5)
				{
					num++;
				}
				if (gclass3.Char_0 == char_6)
				{
					num--;
				}
				if (num == 0)
				{
					goto IL_175;
				}
				num2--;
				if (num2 <= 0)
				{
					break;
				}
			}
			while (gclass3.vmethod_1());
			goto IL_19E;
			IL_175:
			gclass3.GStruct2_1 = new GStruct2(gclass3.GStruct2_0.int_0 + 1, gclass3.GStruct2_0.int_1);
			gclass86_10 = gclass3;
		}
		IL_19E:
		if (gclass != gclass86_9 || gclass2 != gclass86_10)
		{
			this.method_4();
		}
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x0004BD74 File Offset: 0x00049F74
	public bool method_115(string string_3, bool bool_37 = false, RegexOptions regexOptions_0 = RegexOptions.None)
	{
		GClass86 gclass = this.GClass86_5.method_6();
		gclass.method_40();
		GClass86 gclass2 = bool_37 ? new GClass86(this, this.GClass86_6.GStruct2_0, gclass.GStruct2_0) : new GClass86(this, gclass.GStruct2_1, this.GClass86_6.GStruct2_1);
		GClass86 gclass3 = null;
		using (IEnumerator<GClass86> enumerator = gclass2.method_29(string_3, regexOptions_0).GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				gclass3 = enumerator.Current;
				if (!bool_37)
				{
					break;
				}
			}
		}
		if (gclass3 == null)
		{
			return false;
		}
		this.GClass86_5 = gclass3;
		this.method_4();
		return true;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x0004BE1C File Offset: 0x0004A01C
	public virtual void vmethod_78(GEventArgs11 geventArgs11_0)
	{
		GEnum12 genum = this.GEnum12_0;
		GClass86 gclass;
		if (genum != GEnum12.VisibleRange)
		{
			if (genum != GEnum12.AllTextRange)
			{
				gclass = geventArgs11_0.GClass86_0;
			}
			else
			{
				gclass = this.GClass86_6;
			}
		}
		else
		{
			gclass = this.GClass86_4.method_1(geventArgs11_0.GClass86_0);
		}
		if (this.GClass98_0 != null)
		{
			if (this.GEnum20_0 == GEnum20.Custom && !string.IsNullOrEmpty(this.String_2))
			{
				this.GClass98_0.vmethod_1(this.String_2, gclass);
				return;
			}
			this.GClass98_0.vmethod_0(this.GEnum20_0, gclass);
		}
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x0000AC65 File Offset: 0x00008E65
	private void method_116()
	{
		base.SuspendLayout();
		base.Name = "FastColoredTextBox";
		base.ResumeLayout(false);
	}

	// Token: 0x06000C24 RID: 3108 RVA: 0x0004BEA0 File Offset: 0x0004A0A0
	public virtual void vmethod_79(GClass86 gclass86_9, GClass75 gclass75_0)
	{
		GClass72 gclass = new GClass72();
		gclass.Boolean_4 = true;
		gclass.Boolean_1 = true;
		gclass.Boolean_0 = true;
		gclass.Boolean_3 = false;
		gclass.Boolean_5 = gclass75_0.Boolean_3;
		if (gclass86_9 == null)
		{
			gclass86_9 = this.GClass86_6;
		}
		if (gclass86_9.String_1 == string.Empty)
		{
			return;
		}
		this.gclass86_6 = gclass86_9;
		try
		{
			if (this.eventHandler_7 != null)
			{
				this.eventHandler_7(this, new EventArgs());
			}
			if (this.eventHandler_10 != null)
			{
				this.eventHandler_10(this, new EventArgs());
			}
		}
		finally
		{
			this.gclass86_6 = null;
		}
		string text = gclass.method_1(gclass86_9);
		text = string.Concat(new string[]
		{
			"<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\"><head><title>",
			this.vmethod_80(gclass75_0.String_0),
			"</title></head>",
			text,
			"<br>",
			this.method_120()
		});
		string text2 = Path.GetTempPath() + "fctb.html";
		File.WriteAllText(text2, text);
		FastColoredTextBox.smethod_5(gclass75_0);
		WebBrowser webBrowser = new WebBrowser();
		webBrowser.Tag = gclass75_0;
		webBrowser.Visible = false;
		webBrowser.Location = new Point(-1000, -1000);
		webBrowser.Parent = this;
		webBrowser.StatusTextChanged += this.method_117;
		webBrowser.Navigate(text2);
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x0000AC7F File Offset: 0x00008E7F
	protected virtual string vmethod_80(string string_3)
	{
		return string_3.Replace("<", "&lt;").Replace(">", "&gt;").Replace("&", "&amp;");
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x0004BFF8 File Offset: 0x0004A1F8
	private void method_117(object sender, EventArgs e)
	{
		WebBrowser webBrowser = sender as WebBrowser;
		if (webBrowser.StatusText.Contains("#print"))
		{
			GClass75 gclass = webBrowser.Tag as GClass75;
			try
			{
				if (gclass.Boolean_2)
				{
					webBrowser.ShowPrintPreviewDialog();
				}
				else
				{
					if (gclass.Boolean_0)
					{
						webBrowser.ShowPageSetupDialog();
					}
					if (gclass.Boolean_1)
					{
						webBrowser.ShowPrintDialog();
					}
					else
					{
						webBrowser.Print();
					}
				}
			}
			finally
			{
				webBrowser.Parent = null;
				webBrowser.Dispose();
			}
		}
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x0000ACAF File Offset: 0x00008EAF
	public void method_118(GClass75 gclass75_0)
	{
		this.vmethod_79(this.GClass86_6, gclass75_0);
	}

	// Token: 0x06000C28 RID: 3112 RVA: 0x0000ACBE File Offset: 0x00008EBE
	public void method_119()
	{
		this.vmethod_79(this.GClass86_6, new GClass75
		{
			Boolean_0 = false,
			Boolean_1 = false,
			Boolean_2 = false
		});
	}

	// Token: 0x06000C29 RID: 3113 RVA: 0x0004C080 File Offset: 0x0004A280
	private string method_120()
	{
		GClass86 gclass = this.GClass86_5.method_6();
		gclass.method_40();
		int num = this.method_92(gclass.GStruct2_0) - gclass.GStruct2_0.int_1;
		int num2 = gclass.String_1.Length - (gclass.GStruct2_1.int_1 - gclass.GStruct2_0.int_1);
		return string.Format("<script type=\"text/javascript\">\r\ntry{{\r\n    var sel = document.selection;\r\n    var rng = sel.createRange();\r\n    rng.moveStart(\"character\", {0});\r\n    rng.moveEnd(\"character\", {1});\r\n    rng.select();\r\n}}catch(ex){{}}\r\nwindow.status = \"#print\";\r\n</script>", num, num2);
	}

	// Token: 0x06000C2A RID: 3114 RVA: 0x0004C0F4 File Offset: 0x0004A2F4
	private static void smethod_5(GClass75 gclass75_0)
	{
		RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Internet Explorer\\PageSetup", true);
		if (registryKey != null)
		{
			registryKey.SetValue("footer", gclass75_0.String_1);
			registryKey.SetValue("header", gclass75_0.String_2);
		}
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x0004C138 File Offset: 0x0004A338
	protected virtual void Dispose(bool disposing)
	{
		base.Dispose(disposing);
		if (disposing)
		{
			if (this.GClass98_0 != null)
			{
				this.GClass98_0.Dispose();
			}
			this.timer_0.Dispose();
			this.timer_1.Dispose();
			this.timer_3.Dispose();
			if (this.FindForm_0 != null)
			{
				this.FindForm_0.Dispose();
			}
			if (this.ReplaceForm_0 != null)
			{
				this.ReplaceForm_0.Dispose();
			}
			if (this.GClass99_0 != null)
			{
				this.GClass99_0.Dispose();
			}
			if (this.ToolTip_0 != null)
			{
				this.ToolTip_0.Dispose();
			}
		}
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x0000ACE6 File Offset: 0x00008EE6
	protected virtual void vmethod_81(GEventArgs8 geventArgs8_0)
	{
		if (this.eventHandler_13 != null)
		{
			this.eventHandler_13(this, geventArgs8_0);
		}
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x0000ACFD File Offset: 0x00008EFD
	internal void method_121(int int_28)
	{
		this.method_122(int_28, 1);
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x0000AD07 File Offset: 0x00008F07
	internal void method_122(int int_28, int int_29)
	{
		if (this.eventHandler_14 != null)
		{
			this.eventHandler_14(this, new GEventArgs9(int_28, int_29));
		}
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x0000AD24 File Offset: 0x00008F24
	internal void method_123(int int_28, int int_29, List<int> list_3)
	{
		if (int_29 > 0 && this.eventHandler_15 != null)
		{
			this.eventHandler_15(this, new GEventArgs10(int_28, int_29, list_3));
		}
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x0004C1D4 File Offset: 0x0004A3D4
	public void method_124(string string_3, Encoding encoding_0)
	{
		GClass99 gclass99_ = this.vmethod_6();
		try
		{
			this.vmethod_7(gclass99_);
			this.Text = File.ReadAllText(string_3, encoding_0);
			this.method_31();
			this.Boolean_8 = false;
			this.vmethod_4();
		}
		catch
		{
			this.vmethod_7(this.vmethod_6());
			this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.GClass99_0.vmethod_0());
			this.Boolean_8 = false;
			throw;
		}
		this.GClass86_5.GStruct2_0 = GStruct2.GStruct2_0;
		this.method_51();
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x0004C264 File Offset: 0x0004A464
	public void method_125(string string_3)
	{
		try
		{
			Encoding encoding = GClass71.smethod_0(string_3);
			if (encoding != null)
			{
				this.method_124(string_3, encoding);
			}
			else
			{
				this.method_124(string_3, Encoding.Default);
			}
		}
		catch
		{
			this.vmethod_7(this.vmethod_6());
			this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.GClass99_0.vmethod_0());
			this.Boolean_8 = false;
			throw;
		}
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x0004C2D0 File Offset: 0x0004A4D0
	public void method_126(string string_3, Encoding encoding_0)
	{
		GClass100 gclass = new GClass100(this);
		try
		{
			this.vmethod_7(gclass);
			gclass.method_2(string_3, encoding_0);
			this.Boolean_8 = false;
			this.vmethod_4();
		}
		catch
		{
			gclass.method_4();
			this.vmethod_7(this.vmethod_6());
			this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.GClass99_0.vmethod_0());
			this.Boolean_8 = false;
			throw;
		}
		this.method_4();
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x0004C34C File Offset: 0x0004A54C
	public void method_127()
	{
		if (this.gclass99_0 is GClass100)
		{
			(this.gclass99_0 as GClass100).method_4();
			this.vmethod_7(this.vmethod_6());
			this.gclass99_0.GClass99.\u206F\u206C\u206B\u200F\u206E\u202D\u200D\u206F\u206B\u206C\u202D\u200E\u202B\u202B\u202C\u202D\u202A\u202A\u200F\u202C\u206C\u200E\u202C\u200D\u200E\u200E\u200B\u202C\u202C\u200D\u202A\u202E\u200C\u206A\u206A\u206E\u206F\u200C\u200E\u202E\u202E(0, this.GClass99_0.vmethod_0());
			this.Boolean_8 = false;
			this.method_4();
		}
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x0000AD46 File Offset: 0x00008F46
	public void method_128(string string_3, Encoding encoding_0)
	{
		this.gclass99_0.GClass99.\u202E\u206E\u202C\u200B\u206C\u200B\u200E\u202B\u206F\u200D\u206D\u206A\u202C\u206F\u206D\u206C\u202C\u200E\u200F\u202E\u202B\u206F\u202D\u202E\u202B\u200F\u206C\u200D\u206E\u202A\u202B\u206E\u200E\u206E\u200C\u206D\u206A\u202B\u206E\u206F\u202E(string_3, encoding_0);
		this.Boolean_8 = false;
		this.vmethod_4();
		this.method_47();
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x0004C3A8 File Offset: 0x0004A5A8
	public void method_129(int int_28, GEnum17 genum17_0)
	{
		GStruct1 value = this.list_0[int_28];
		value.genum17_0 = genum17_0;
		this.list_0[int_28] = value;
		this.bool_10 = true;
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x0000AD68 File Offset: 0x00008F68
	public GEnum17 method_130(int int_28)
	{
		return this.list_0[int_28].genum17_0;
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x0004C3E0 File Offset: 0x0004A5E0
	public void method_131()
	{
		GoToForm goToForm = new GoToForm();
		goToForm.Int32_1 = this.Int32_14;
		goToForm.Int32_0 = this.GClass86_5.GStruct2_0.int_1 + 1;
		if (goToForm.ShowDialog() == DialogResult.OK)
		{
			this.method_132(goToForm.Int32_0);
		}
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x0004C42C File Offset: 0x0004A62C
	public void method_132(int int_28)
	{
		int num = Math.Min(this.Int32_14 - 1, Math.Max(0, int_28 - 1));
		this.GClass86_5 = new GClass86(this, 0, num, 0, num);
		this.method_51();
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x0000AD7B File Offset: 0x00008F7B
	public void method_133()
	{
		if (this.eventHandler_17 != null)
		{
			this.eventHandler_17(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x0004C468 File Offset: 0x0004A668
	public List<int> method_134(string string_3, RegexOptions regexOptions_0)
	{
		List<int> list = new List<int>();
		foreach (GClass86 gclass in this.GClass86_6.method_30(string_3, regexOptions_0))
		{
			list.Add(gclass.GStruct2_0.int_1);
		}
		return list;
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x0004C4D0 File Offset: 0x0004A6D0
	public void method_135(List<int> list_3)
	{
		this.GClass99_0.GClass59_0.vmethod_0(new GClass67(this.GClass99_0, list_3));
		if (list_3.Count > 0)
		{
			this.Boolean_8 = true;
		}
		if (this.Int32_14 == 0)
		{
			this.Text = "";
		}
		this.method_10();
		this.method_4();
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x00002E18 File Offset: 0x00001018
	void ISupportInitialize.BeginInit()
	{
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x0000AD96 File Offset: 0x00008F96
	void ISupportInitialize.EndInit()
	{
		this.vmethod_54();
		this.GClass86_5.GStruct2_0 = GStruct2.GStruct2_0;
		this.method_49();
		this.Boolean_8 = false;
		this.method_31();
	}

	// Token: 0x1700033E RID: 830
	// (get) Token: 0x06000C3E RID: 3134 RVA: 0x0000ADC1 File Offset: 0x00008FC1
	// (set) Token: 0x06000C3F RID: 3135 RVA: 0x0000ADC9 File Offset: 0x00008FC9
	private bool Boolean_29 { get; set; }

	// Token: 0x06000C40 RID: 3136 RVA: 0x0000ADD2 File Offset: 0x00008FD2
	protected virtual void OnDragEnter(DragEventArgs drgevent)
	{
		if (drgevent.Data.GetDataPresent(DataFormats.Text) && this.AllowDrop)
		{
			drgevent.Effect = DragDropEffects.Copy;
			this.Boolean_29 = true;
		}
		base.OnDragEnter(drgevent);
	}

	// Token: 0x06000C41 RID: 3137 RVA: 0x0004C528 File Offset: 0x0004A728
	protected virtual void OnDragDrop(DragEventArgs drgevent)
	{
		if (!this.Boolean_9 && this.AllowDrop)
		{
			if (drgevent.Data.GetDataPresent(DataFormats.Text))
			{
				if (base.ParentForm != null)
				{
					base.ParentForm.Activate();
				}
				base.Focus();
				Point point_ = base.PointToClient(new Point(drgevent.X, drgevent.Y));
				string string_ = drgevent.Data.GetData(DataFormats.Text).ToString();
				GStruct2 gstruct2_ = this.method_84(point_);
				this.vmethod_82(gstruct2_, string_);
				this.Boolean_29 = false;
			}
			base.OnDragDrop(drgevent);
			return;
		}
		this.Boolean_29 = false;
	}

	// Token: 0x06000C42 RID: 3138 RVA: 0x0004C5C8 File Offset: 0x0004A7C8
	private void method_136(GStruct2 gstruct2_0, string string_3)
	{
		GClass86 gclass = new GClass86(this, gstruct2_0, gstruct2_0);
		if (gclass.Boolean_1)
		{
			return;
		}
		if (this.gclass86_8 != null && this.gclass86_8.method_0(gstruct2_0))
		{
			return;
		}
		bool flag = this.gclass86_8 == null || this.gclass86_8.Boolean_1 || (Control.ModifierKeys & Keys.Control) > Keys.None;
		if (this.gclass86_8 == null)
		{
			this.GClass86_5.method_38();
			this.GClass86_5.GStruct2_0 = gstruct2_0;
			this.vmethod_20(string_3);
			this.GClass86_5 = new GClass86(this, gstruct2_0, this.GClass86_5.GStruct2_0);
			this.GClass86_5.method_39();
			return;
		}
		this.method_108();
		this.GClass86_5.method_38();
		this.GClass86_5 = this.gclass86_8;
		this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.gclass99_0));
		if (this.gclass86_8.Boolean_0)
		{
			this.gclass86_8.method_40();
			gclass = new GClass86(this, gstruct2_0, new GStruct2(gstruct2_0.int_0, gstruct2_0.int_1 + this.gclass86_8.GStruct2_1.int_1 - this.gclass86_8.GStruct2_0.int_1))
			{
				Boolean_0 = true
			};
			for (int i = this.Int32_14; i <= gclass.GStruct2_1.int_1; i++)
			{
				this.GClass86_5.method_51(false);
				this.vmethod_27('\n');
			}
		}
		if (!gclass.Boolean_1)
		{
			GStruct2 gstruct2_;
			if (GStruct2.smethod_2(gstruct2_0, this.gclass86_8.GStruct2_0))
			{
				if (!flag)
				{
					this.GClass86_5 = this.gclass86_8;
					this.vmethod_28();
				}
				this.GClass86_5 = gclass;
				this.GClass86_5.Boolean_0 = gclass.Boolean_0;
				this.vmethod_20(string_3);
				gstruct2_ = this.GClass86_5.GStruct2_0;
			}
			else
			{
				this.GClass86_5 = gclass;
				this.GClass86_5.Boolean_0 = gclass.Boolean_0;
				this.vmethod_20(string_3);
				gstruct2_ = this.GClass86_5.GStruct2_0;
				int count = this[gstruct2_.int_1].Count;
				if (!flag)
				{
					this.GClass86_5 = this.gclass86_8;
					this.vmethod_28();
				}
				int num = count - this[gstruct2_.int_1].Count;
				gstruct2_.int_0 -= num;
				gstruct2_0.int_0 -= num;
			}
			if (!this.gclass86_8.Boolean_0)
			{
				this.GClass86_5 = new GClass86(this, gstruct2_0, gstruct2_);
			}
			else
			{
				this.gclass86_8.method_40();
				this.GClass86_5 = new GClass86(this, gstruct2_0, new GStruct2(gstruct2_0.int_0 + this.gclass86_8.GStruct2_1.int_0 - this.gclass86_8.GStruct2_0.int_0, gstruct2_0.int_1 + this.gclass86_8.GStruct2_1.int_1 - this.gclass86_8.GStruct2_0.int_1))
				{
					Boolean_0 = true
				};
			}
		}
		this.GClass86_5.method_39();
		this.method_109();
		this.gclass86_8 = null;
	}

	// Token: 0x06000C43 RID: 3139 RVA: 0x0004C8C4 File Offset: 0x0004AAC4
	protected virtual void vmethod_82(GStruct2 gstruct2_0, string string_3)
	{
		GClass86 gclass = new GClass86(this, gstruct2_0, gstruct2_0);
		if (gclass.Boolean_1)
		{
			return;
		}
		if (this.gclass86_8 != null && this.gclass86_8.method_0(gstruct2_0))
		{
			return;
		}
		bool flag = this.gclass86_8 == null || this.gclass86_8.Boolean_1 || (Control.ModifierKeys & Keys.Control) > Keys.None;
		if (this.gclass86_8 == null)
		{
			this.GClass86_5.method_38();
			this.GClass86_5.GStruct2_0 = gstruct2_0;
			this.vmethod_20(string_3);
			this.GClass86_5 = new GClass86(this, gstruct2_0, this.GClass86_5.GStruct2_0);
			this.GClass86_5.method_39();
		}
		else
		{
			if (!this.gclass86_8.method_0(gstruct2_0))
			{
				this.method_108();
				this.GClass86_5 = this.gclass86_8;
				this.gclass99_0.GClass59_0.vmethod_0(new GClass69(this.gclass99_0));
				if (this.gclass86_8.Boolean_0)
				{
					this.gclass86_8.method_40();
					gclass = new GClass86(this, gstruct2_0, new GStruct2(gstruct2_0.int_0, gstruct2_0.int_1 + this.gclass86_8.GStruct2_1.int_1 - this.gclass86_8.GStruct2_0.int_1))
					{
						Boolean_0 = true
					};
					for (int i = this.Int32_14; i <= gclass.GStruct2_1.int_1; i++)
					{
						this.GClass86_5.method_51(false);
						this.vmethod_27('\n');
					}
				}
				if (!gclass.Boolean_1)
				{
					if (GStruct2.smethod_2(gstruct2_0, this.gclass86_8.GStruct2_0))
					{
						if (!flag)
						{
							this.GClass86_5 = this.gclass86_8;
							this.vmethod_28();
						}
						this.GClass86_5 = gclass;
						this.GClass86_5.Boolean_0 = gclass.Boolean_0;
						this.vmethod_20(string_3);
					}
					else
					{
						this.GClass86_5 = gclass;
						this.GClass86_5.Boolean_0 = gclass.Boolean_0;
						this.vmethod_20(string_3);
						if (!flag)
						{
							this.GClass86_5 = this.gclass86_8;
							this.vmethod_28();
						}
					}
				}
				GStruct2 gstruct2_ = gstruct2_0;
				GStruct2 gstruct2_2 = this.GClass86_5.GStruct2_0;
				GClass86 gclass2 = GStruct2.smethod_4(this.gclass86_8.GStruct2_1, this.gclass86_8.GStruct2_0) ? this.method_97(this.gclass86_8.GStruct2_0, this.gclass86_8.GStruct2_1) : this.method_97(this.gclass86_8.GStruct2_1, this.gclass86_8.GStruct2_0);
				if (GStruct2.smethod_4(gstruct2_0, this.gclass86_8.GStruct2_0) && !flag && !this.gclass86_8.Boolean_0)
				{
					int num;
					int num2;
					if (gclass2.GStruct2_0.int_1 != gclass2.GStruct2_1.int_1)
					{
						num = ((gclass2.GStruct2_1.int_1 != gstruct2_0.int_1) ? gstruct2_0.int_0 : (gclass2.GStruct2_0.int_0 + (gstruct2_0.int_0 - gclass2.GStruct2_1.int_0)));
						num2 = gclass2.GStruct2_1.int_0;
					}
					else if (gclass2.GStruct2_1.int_1 == gstruct2_0.int_1)
					{
						num = gstruct2_0.int_0 - gclass2.String_1.Length;
						num2 = gstruct2_0.int_0;
					}
					else
					{
						num = gstruct2_0.int_0;
						num2 = gstruct2_0.int_0 + gclass2.String_1.Length;
					}
					int num3;
					int num4;
					if (gclass2.GStruct2_1.int_1 != gstruct2_0.int_1)
					{
						num3 = gstruct2_0.int_1 - (gclass2.GStruct2_1.int_1 - gclass2.GStruct2_0.int_1);
						num4 = gstruct2_0.int_1;
					}
					else
					{
						num3 = gclass2.GStruct2_0.int_1;
						num4 = gclass2.GStruct2_1.int_1;
					}
					gstruct2_ = new GStruct2(num, num3);
					gstruct2_2 = new GStruct2(num2, num4);
				}
				if (!this.gclass86_8.Boolean_0)
				{
					this.GClass86_5 = new GClass86(this, gstruct2_, gstruct2_2);
				}
				else
				{
					int num;
					int num2;
					if (!flag && gstruct2_0.int_1 >= gclass2.GStruct2_0.int_1 && gstruct2_0.int_1 <= gclass2.GStruct2_1.int_1 && gstruct2_0.int_0 >= gclass2.GStruct2_1.int_0)
					{
						num = gstruct2_0.int_0 - (gclass2.GStruct2_1.int_0 - gclass2.GStruct2_0.int_0);
						num2 = gstruct2_0.int_0;
					}
					else
					{
						num = gstruct2_0.int_0;
						num2 = gstruct2_0.int_0 + (gclass2.GStruct2_1.int_0 - gclass2.GStruct2_0.int_0);
					}
					int num3 = gstruct2_0.int_1;
					int num4 = gstruct2_0.int_1 + (gclass2.GStruct2_1.int_1 - gclass2.GStruct2_0.int_1);
					gstruct2_ = new GStruct2(num, num3);
					gstruct2_2 = new GStruct2(num2, num4);
					this.GClass86_5 = new GClass86(this, gstruct2_, gstruct2_2)
					{
						Boolean_0 = true
					};
				}
				this.method_109();
			}
			this.gclass86_7.method_41();
			this.vmethod_58();
		}
		this.gclass86_8 = null;
	}

	// Token: 0x06000C44 RID: 3140 RVA: 0x0004CDBC File Offset: 0x0004AFBC
	protected virtual void OnDragOver(DragEventArgs drgevent)
	{
		if (drgevent.Data.GetDataPresent(DataFormats.Text))
		{
			Point point_ = base.PointToClient(new Point(drgevent.X, drgevent.Y));
			this.GClass86_5.GStruct2_0 = this.method_84(point_);
			if (point_.Y < 6 && base.VerticalScroll.Visible && base.VerticalScroll.Value > 0)
			{
				base.VerticalScroll.Value = Math.Max(0, base.VerticalScroll.Value - this.int_9);
			}
			this.method_49();
			this.method_4();
		}
		base.OnDragOver(drgevent);
	}

	// Token: 0x06000C45 RID: 3141 RVA: 0x0000AE03 File Offset: 0x00009003
	protected virtual void OnDragLeave(EventArgs e)
	{
		this.Boolean_29 = false;
		base.OnDragLeave(e);
	}

	// Token: 0x06000C46 RID: 3142 RVA: 0x0004CE60 File Offset: 0x0004B060
	private void method_137(MouseEventArgs mouseEventArgs_0)
	{
		if (!this.bool_36)
		{
			if (!base.HorizontalScroll.Visible && !base.VerticalScroll.Visible && this.Boolean_21)
			{
				return;
			}
			this.bool_36 = true;
			this.point_2 = mouseEventArgs_0.Location;
			this.point_3 = new Point(base.HorizontalScroll.Value, base.VerticalScroll.Value);
			this.timer_3.Interval = 50;
			this.timer_3.Enabled = true;
			base.Capture = true;
			this.Refresh();
			FastColoredTextBox.SendMessage(base.Handle, 11, 0, 0);
		}
	}

	// Token: 0x06000C47 RID: 3143 RVA: 0x0004CF08 File Offset: 0x0004B108
	private void method_138()
	{
		if (this.bool_36)
		{
			this.bool_36 = false;
			this.timer_3.Enabled = false;
			base.Capture = false;
			base.Cursor = this.cursor_0;
			FastColoredTextBox.SendMessage(base.Handle, 11, 1, 0);
			this.method_4();
		}
	}

	// Token: 0x06000C48 RID: 3144 RVA: 0x0004CF5C File Offset: 0x0004B15C
	private void method_139()
	{
		ScrollEventArgs se = new ScrollEventArgs(ScrollEventType.ThumbPosition, base.HorizontalScroll.Value, this.point_3.X, ScrollOrientation.HorizontalScroll);
		this.OnScroll(se);
		ScrollEventArgs se2 = new ScrollEventArgs(ScrollEventType.ThumbPosition, base.VerticalScroll.Value, this.point_3.Y, ScrollOrientation.VerticalScroll);
		this.OnScroll(se2);
	}

	// Token: 0x06000C49 RID: 3145
	[DllImport("user32.dll")]
	private static extern int SendMessage(IntPtr intptr_1, int int_28, int int_29, int int_30);

	// Token: 0x06000C4A RID: 3146 RVA: 0x0004CFB4 File Offset: 0x0004B1B4
	private void timer_3_Tick(object sender, EventArgs e)
	{
		if (base.IsDisposed)
		{
			return;
		}
		if (!this.bool_36)
		{
			return;
		}
		Point point = base.PointToClient(Cursor.Position);
		base.Capture = true;
		int num = this.point_2.X - point.X;
		int num2 = this.point_2.Y - point.Y;
		if (!base.VerticalScroll.Visible && this.Boolean_21)
		{
			num2 = 0;
		}
		if (!base.HorizontalScroll.Visible && this.Boolean_21)
		{
			num = 0;
		}
		double num3 = 180.0 - Math.Atan2((double)num2, (double)num) * 180.0 / 3.141592653589793;
		if (Math.Sqrt(Math.Pow((double)num, 2.0) + Math.Pow((double)num2, 2.0)) > 10.0)
		{
			if (num3 < 325.0 && num3 > 35.0)
			{
				if (num3 <= 55.0)
				{
					this.genum16_0 = (GEnum16.Right | GEnum16.Up);
				}
				else if (num3 <= 125.0)
				{
					this.genum16_0 = GEnum16.Up;
				}
				else if (num3 <= 145.0)
				{
					this.genum16_0 = (GEnum16.Left | GEnum16.Up);
				}
				else if (num3 <= 215.0)
				{
					this.genum16_0 = GEnum16.Left;
				}
				else if (num3 <= 235.0)
				{
					this.genum16_0 = (GEnum16.Left | GEnum16.Down);
				}
				else if (num3 <= 305.0)
				{
					this.genum16_0 = GEnum16.Down;
				}
				else
				{
					this.genum16_0 = (GEnum16.Right | GEnum16.Down);
				}
			}
			else
			{
				this.genum16_0 = GEnum16.Right;
			}
		}
		else
		{
			this.genum16_0 = GEnum16.None;
		}
		switch (this.genum16_0)
		{
		case GEnum16.Left:
			base.Cursor = Cursors.PanWest;
			goto IL_23F;
		case GEnum16.Right:
			base.Cursor = Cursors.PanEast;
			goto IL_23F;
		case GEnum16.Up:
			base.Cursor = Cursors.PanNorth;
			goto IL_23F;
		case GEnum16.Left | GEnum16.Up:
			base.Cursor = Cursors.PanNW;
			goto IL_23F;
		case GEnum16.Right | GEnum16.Up:
			base.Cursor = Cursors.PanNE;
			goto IL_23F;
		case GEnum16.Down:
			base.Cursor = Cursors.PanSouth;
			goto IL_23F;
		case GEnum16.Left | GEnum16.Down:
			base.Cursor = Cursors.PanSW;
			goto IL_23F;
		case GEnum16.Right | GEnum16.Down:
			base.Cursor = Cursors.PanSE;
			goto IL_23F;
		}
		base.Cursor = this.cursor_0;
		return;
		IL_23F:
		int num4 = (int)((double)(-(double)num) / 5.0);
		int num5 = (int)((double)(-(double)num2) / 5.0);
		ScrollEventArgs se = new ScrollEventArgs((num4 < 0) ? ScrollEventType.SmallIncrement : ScrollEventType.SmallDecrement, base.HorizontalScroll.Value, base.HorizontalScroll.Value + num4, ScrollOrientation.HorizontalScroll);
		ScrollEventArgs scrollEventArgs_ = new ScrollEventArgs((num5 < 0) ? ScrollEventType.SmallDecrement : ScrollEventType.SmallIncrement, base.VerticalScroll.Value, base.VerticalScroll.Value + num5, ScrollOrientation.VerticalScroll);
		if ((this.genum16_0 & (GEnum16.Up | GEnum16.Down)) > GEnum16.None)
		{
			this.method_37(scrollEventArgs_, false);
		}
		if ((this.genum16_0 & (GEnum16.Left | GEnum16.Right)) > GEnum16.None)
		{
			this.OnScroll(se);
		}
		FastColoredTextBox.SendMessage(base.Handle, 11, 1, 0);
		this.Refresh();
		FastColoredTextBox.SendMessage(base.Handle, 11, 0, 0);
	}

	// Token: 0x06000C4B RID: 3147 RVA: 0x0004D2C4 File Offset: 0x0004B4C4
	private void method_140(Graphics graphics_0)
	{
		bool flag = base.VerticalScroll.Visible || !this.Boolean_21;
		bool flag2 = base.HorizontalScroll.Visible || !this.Boolean_21;
		using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(100, (int)(~this.BackColor.R), (int)(~this.BackColor.G), (int)(~this.BackColor.B))))
		{
			Point point = this.point_2;
			GraphicsState gstate = graphics_0.Save();
			graphics_0.SmoothingMode = SmoothingMode.HighQuality;
			graphics_0.TranslateTransform((float)point.X, (float)point.Y);
			graphics_0.FillEllipse(solidBrush, -2, -2, 4, 4);
			if (flag)
			{
				this.method_141(graphics_0, solidBrush);
			}
			graphics_0.RotateTransform(90f);
			if (flag2)
			{
				this.method_141(graphics_0, solidBrush);
			}
			graphics_0.RotateTransform(90f);
			if (flag)
			{
				this.method_141(graphics_0, solidBrush);
			}
			graphics_0.RotateTransform(90f);
			if (flag2)
			{
				this.method_141(graphics_0, solidBrush);
			}
			graphics_0.Restore(gstate);
		}
	}

	// Token: 0x06000C4C RID: 3148 RVA: 0x0004D3F0 File Offset: 0x0004B5F0
	private void method_141(Graphics graphics_0, Brush brush_1)
	{
		Point[] points = new Point[]
		{
			new Point(5, 10),
			new Point(0, 15),
			new Point(-5, 10)
		};
		graphics_0.FillPolygon(brush_1, points);
	}

	// Token: 0x040004F2 RID: 1266
	internal const int int_0 = 8;

	// Token: 0x040004F3 RID: 1267
	private const int int_1 = 1000;

	// Token: 0x040004F4 RID: 1268
	private const int int_2 = 3000;

	// Token: 0x040004F5 RID: 1269
	private const int int_3 = 100000;

	// Token: 0x040004F6 RID: 1270
	private const int int_4 = 641;

	// Token: 0x040004F7 RID: 1271
	private const int int_5 = 276;

	// Token: 0x040004F8 RID: 1272
	private const int int_6 = 277;

	// Token: 0x040004F9 RID: 1273
	private const int int_7 = 8;

	// Token: 0x040004FA RID: 1274
	public readonly List<GStruct1> list_0 = new List<GStruct1>();

	// Token: 0x040004FB RID: 1275
	private readonly System.Windows.Forms.Timer timer_0 = new System.Windows.Forms.Timer();

	// Token: 0x040004FC RID: 1276
	private readonly System.Windows.Forms.Timer timer_1 = new System.Windows.Forms.Timer();

	// Token: 0x040004FD RID: 1277
	private readonly System.Windows.Forms.Timer timer_2 = new System.Windows.Forms.Timer();

	// Token: 0x040004FE RID: 1278
	private readonly List<GClass101> list_1 = new List<GClass101>();

	// Token: 0x040004FF RID: 1279
	public int int_8;

	// Token: 0x04000500 RID: 1280
	public bool bool_0 = true;

	// Token: 0x04000501 RID: 1281
	private Brush brush_0;

	// Token: 0x04000502 RID: 1282
	private GClass56 gclass56_0;

	// Token: 0x04000503 RID: 1283
	private bool bool_1;

	// Token: 0x04000504 RID: 1284
	private Color color_0;

	// Token: 0x04000505 RID: 1285
	private int int_9;

	// Token: 0x04000506 RID: 1286
	private Color color_1;

	// Token: 0x04000507 RID: 1287
	private Cursor cursor_0;

	// Token: 0x04000508 RID: 1288
	private GClass86 gclass86_0;

	// Token: 0x04000509 RID: 1289
	private string string_0;

	// Token: 0x0400050A RID: 1290
	private int int_10 = -1;

	// Token: 0x0400050B RID: 1291
	private Color color_2;

	// Token: 0x0400050C RID: 1292
	protected Dictionary<int, int> dictionary_0 = new Dictionary<int, int>();

	// Token: 0x0400050D RID: 1293
	private bool bool_2;

	// Token: 0x0400050E RID: 1294
	private bool bool_3;

	// Token: 0x0400050F RID: 1295
	private GClass77 gclass77_0;

	// Token: 0x04000510 RID: 1296
	private Color color_3;

	// Token: 0x04000511 RID: 1297
	private bool bool_4;

	// Token: 0x04000512 RID: 1298
	private bool bool_5;

	// Token: 0x04000513 RID: 1299
	private bool bool_6;

	// Token: 0x04000514 RID: 1300
	private GEnum20 genum20_0;

	// Token: 0x04000515 RID: 1301
	private Keys keys_0;

	// Token: 0x04000516 RID: 1302
	private Point point_0;

	// Token: 0x04000517 RID: 1303
	private DateTime dateTime_0;

	// Token: 0x04000518 RID: 1304
	private GClass86 gclass86_1;

	// Token: 0x04000519 RID: 1305
	private GClass86 gclass86_2;

	// Token: 0x0400051A RID: 1306
	private int int_11;

	// Token: 0x0400051B RID: 1307
	private int int_12;

	// Token: 0x0400051C RID: 1308
	private Color color_4;

	// Token: 0x0400051D RID: 1309
	private uint uint_0;

	// Token: 0x0400051E RID: 1310
	private GClass82 gclass82_0;

	// Token: 0x0400051F RID: 1311
	private int int_13;

	// Token: 0x04000520 RID: 1312
	private GClass99 gclass99_0;

	// Token: 0x04000521 RID: 1313
	private IntPtr intptr_0;

	// Token: 0x04000522 RID: 1314
	private int int_14;

	// Token: 0x04000523 RID: 1315
	private bool bool_7;

	// Token: 0x04000524 RID: 1316
	private bool bool_8;

	// Token: 0x04000525 RID: 1317
	private bool bool_9;

	// Token: 0x04000526 RID: 1318
	protected bool bool_10;

	// Token: 0x04000527 RID: 1319
	protected bool bool_11;

	// Token: 0x04000528 RID: 1320
	private Point point_1;

	// Token: 0x04000529 RID: 1321
	private bool bool_12;

	// Token: 0x0400052A RID: 1322
	private bool bool_13;

	// Token: 0x0400052B RID: 1323
	private bool bool_14;

	// Token: 0x0400052C RID: 1324
	private bool bool_15;

	// Token: 0x0400052D RID: 1325
	private Color color_5;

	// Token: 0x0400052E RID: 1326
	private int int_15;

	// Token: 0x0400052F RID: 1327
	private GClass86 gclass86_3;

	// Token: 0x04000530 RID: 1328
	private GClass86 gclass86_4;

	// Token: 0x04000531 RID: 1329
	private bool bool_16;

	// Token: 0x04000532 RID: 1330
	private Color color_6;

	// Token: 0x04000533 RID: 1331
	private Color color_7;

	// Token: 0x04000534 RID: 1332
	private bool bool_17;

	// Token: 0x04000535 RID: 1333
	private bool bool_18;

	// Token: 0x04000536 RID: 1334
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x04000537 RID: 1335
	private int int_16 = -1;

	// Token: 0x04000538 RID: 1336
	private int int_17;

	// Token: 0x04000539 RID: 1337
	private GClass86 gclass86_5;

	// Token: 0x0400053A RID: 1338
	private GClass86 gclass86_6;

	// Token: 0x0400053B RID: 1339
	private bool bool_19;

	// Token: 0x0400053C RID: 1340
	private GEnum11 genum11_0;

	// Token: 0x0400053D RID: 1341
	private int int_18 = 1;

	// Token: 0x0400053E RID: 1342
	private int int_19 = 100;

	// Token: 0x0400053F RID: 1343
	private Size size_0;

	// Token: 0x04000540 RID: 1344
	private char[] char_0 = new char[]
	{
		'(',
		')',
		'{',
		'}',
		'[',
		']',
		'"',
		'"',
		'\'',
		'\''
	};

	// Token: 0x04000541 RID: 1345
	[CompilerGenerated]
	private bool bool_20;

	// Token: 0x04000542 RID: 1346
	[CompilerGenerated]
	private GClass76 gclass76_0;

	// Token: 0x04000543 RID: 1347
	[CompilerGenerated]
	private Dictionary<int, int> dictionary_1;

	// Token: 0x04000544 RID: 1348
	[CompilerGenerated]
	private GEnum14 genum14_0;

	// Token: 0x04000545 RID: 1349
	[CompilerGenerated]
	private bool bool_21;

	// Token: 0x04000546 RID: 1350
	[CompilerGenerated]
	private int int_20;

	// Token: 0x04000547 RID: 1351
	private GClass84 gclass84_0;

	// Token: 0x04000548 RID: 1352
	[CompilerGenerated]
	private ToolTip toolTip_0;

	// Token: 0x04000549 RID: 1353
	[CompilerGenerated]
	private Color color_8;

	// Token: 0x0400054A RID: 1354
	[CompilerGenerated]
	private bool bool_22;

	// Token: 0x0400054B RID: 1355
	[CompilerGenerated]
	private GEnum13 genum13_0;

	// Token: 0x0400054C RID: 1356
	[CompilerGenerated]
	private bool bool_23;

	// Token: 0x0400054D RID: 1357
	[CompilerGenerated]
	private bool bool_24;

	// Token: 0x0400054E RID: 1358
	[CompilerGenerated]
	private bool bool_25;

	// Token: 0x0400054F RID: 1359
	[CompilerGenerated]
	private bool bool_26;

	// Token: 0x04000550 RID: 1360
	private Color color_9;

	// Token: 0x04000551 RID: 1361
	private GEnum15 genum15_0;

	// Token: 0x04000552 RID: 1362
	[CompilerGenerated]
	private int int_21;

	// Token: 0x04000553 RID: 1363
	[CompilerGenerated]
	private int int_22;

	// Token: 0x04000554 RID: 1364
	[CompilerGenerated]
	private int int_23;

	// Token: 0x04000555 RID: 1365
	[CompilerGenerated]
	private bool bool_27;

	// Token: 0x04000556 RID: 1366
	[CompilerGenerated]
	private Color color_10;

	// Token: 0x04000557 RID: 1367
	[CompilerGenerated]
	private Color color_11;

	// Token: 0x04000558 RID: 1368
	[CompilerGenerated]
	private bool bool_28;

	// Token: 0x04000559 RID: 1369
	[CompilerGenerated]
	private Padding padding_0;

	// Token: 0x0400055A RID: 1370
	[CompilerGenerated]
	private int int_24;

	// Token: 0x0400055B RID: 1371
	[CompilerGenerated]
	private GClass79 gclass79_0;

	// Token: 0x0400055C RID: 1372
	[CompilerGenerated]
	private GClass90 gclass90_0;

	// Token: 0x0400055D RID: 1373
	[CompilerGenerated]
	private GClass88 gclass88_0;

	// Token: 0x0400055E RID: 1374
	[CompilerGenerated]
	private GClass91 gclass91_0;

	// Token: 0x0400055F RID: 1375
	[CompilerGenerated]
	private GClass91 gclass91_1;

	// Token: 0x04000560 RID: 1376
	[CompilerGenerated]
	private char char_1;

	// Token: 0x04000561 RID: 1377
	[CompilerGenerated]
	private char char_2;

	// Token: 0x04000562 RID: 1378
	[CompilerGenerated]
	private char char_3;

	// Token: 0x04000563 RID: 1379
	[CompilerGenerated]
	private char char_4;

	// Token: 0x04000564 RID: 1380
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04000565 RID: 1381
	[CompilerGenerated]
	private GEnum12 genum12_0;

	// Token: 0x04000566 RID: 1382
	[CompilerGenerated]
	private bool bool_29;

	// Token: 0x04000567 RID: 1383
	[CompilerGenerated]
	private bool bool_30;

	// Token: 0x04000568 RID: 1384
	[CompilerGenerated]
	private bool bool_31;

	// Token: 0x04000569 RID: 1385
	[CompilerGenerated]
	private GClass98 gclass98_0;

	// Token: 0x0400056A RID: 1386
	private readonly GClass86 gclass86_7;

	// Token: 0x0400056B RID: 1387
	private bool bool_32;

	// Token: 0x0400056C RID: 1388
	[CompilerGenerated]
	private FindForm findForm_0;

	// Token: 0x0400056D RID: 1389
	[CompilerGenerated]
	private ReplaceForm replaceForm_0;

	// Token: 0x0400056E RID: 1390
	private Font font_0;

	// Token: 0x0400056F RID: 1391
	[CompilerGenerated]
	private EventHandler<GEventArgs15> eventHandler_0;

	// Token: 0x04000570 RID: 1392
	private int int_25 = 8;

	// Token: 0x04000571 RID: 1393
	[CompilerGenerated]
	private EventHandler<GEventArgs16> eventHandler_1;

	// Token: 0x04000572 RID: 1394
	[CompilerGenerated]
	private EventHandler<GEventArgs11> eventHandler_2;

	// Token: 0x04000573 RID: 1395
	[CompilerGenerated]
	private EventHandler eventHandler_3;

	// Token: 0x04000574 RID: 1396
	[CompilerGenerated]
	private EventHandler<GEventArgs12> eventHandler_4;

	// Token: 0x04000575 RID: 1397
	[CompilerGenerated]
	private EventHandler<GEventArgs12> eventHandler_5;

	// Token: 0x04000576 RID: 1398
	[CompilerGenerated]
	private EventHandler eventHandler_6;

	// Token: 0x04000577 RID: 1399
	[CompilerGenerated]
	private EventHandler eventHandler_7;

	// Token: 0x04000578 RID: 1400
	[CompilerGenerated]
	private EventHandler<GEventArgs11> eventHandler_8;

	// Token: 0x04000579 RID: 1401
	[CompilerGenerated]
	private EventHandler eventHandler_9;

	// Token: 0x0400057A RID: 1402
	[CompilerGenerated]
	private EventHandler eventHandler_10;

	// Token: 0x0400057B RID: 1403
	[CompilerGenerated]
	private EventHandler<GEventArgs21> eventHandler_11;

	// Token: 0x0400057C RID: 1404
	[CompilerGenerated]
	private KeyPressEventHandler keyPressEventHandler_0;

	// Token: 0x0400057D RID: 1405
	[CompilerGenerated]
	private KeyPressEventHandler keyPressEventHandler_1;

	// Token: 0x0400057E RID: 1406
	[CompilerGenerated]
	private EventHandler<GEventArgs14> eventHandler_12;

	// Token: 0x0400057F RID: 1407
	[CompilerGenerated]
	private EventHandler<GEventArgs8> eventHandler_13;

	// Token: 0x04000580 RID: 1408
	[CompilerGenerated]
	private EventHandler<GEventArgs9> eventHandler_14;

	// Token: 0x04000581 RID: 1409
	[CompilerGenerated]
	private EventHandler<GEventArgs10> eventHandler_15;

	// Token: 0x04000582 RID: 1410
	[CompilerGenerated]
	private EventHandler<EventArgs> eventHandler_16;

	// Token: 0x04000583 RID: 1411
	[CompilerGenerated]
	private EventHandler<EventArgs> eventHandler_17;

	// Token: 0x04000584 RID: 1412
	[CompilerGenerated]
	private EventHandler eventHandler_18;

	// Token: 0x04000585 RID: 1413
	[CompilerGenerated]
	private EventHandler<GEventArgs17> eventHandler_19;

	// Token: 0x04000586 RID: 1414
	[CompilerGenerated]
	private EventHandler eventHandler_20;

	// Token: 0x04000587 RID: 1415
	[CompilerGenerated]
	private EventHandler<GEventArgs13> eventHandler_21;

	// Token: 0x04000588 RID: 1416
	private Dictionary<System.Windows.Forms.Timer, System.Windows.Forms.Timer> dictionary_2 = new Dictionary<System.Windows.Forms.Timer, System.Windows.Forms.Timer>();

	// Token: 0x04000589 RID: 1417
	private List<Control> list_2 = new List<Control>();

	// Token: 0x0400058A RID: 1418
	private bool bool_33;

	// Token: 0x0400058B RID: 1419
	private static Dictionary<FCTBAction, bool> dictionary_3 = new Dictionary<FCTBAction, bool>
	{
		{
			FCTBAction.ScrollDown,
			true
		},
		{
			FCTBAction.ScrollUp,
			true
		},
		{
			FCTBAction.ZoomOut,
			true
		},
		{
			FCTBAction.ZoomIn,
			true
		},
		{
			FCTBAction.ZoomNormal,
			true
		}
	};

	// Token: 0x0400058C RID: 1420
	private Font font_1;

	// Token: 0x0400058D RID: 1421
	private const int int_26 = 258;

	// Token: 0x0400058E RID: 1422
	[CompilerGenerated]
	private bool bool_34;

	// Token: 0x0400058F RID: 1423
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04000590 RID: 1424
	private Rectangle rectangle_0;

	// Token: 0x04000591 RID: 1425
	protected GClass86 gclass86_8;

	// Token: 0x04000592 RID: 1426
	[CompilerGenerated]
	private bool bool_35;

	// Token: 0x04000593 RID: 1427
	private bool bool_36;

	// Token: 0x04000594 RID: 1428
	private Point point_2;

	// Token: 0x04000595 RID: 1429
	private Point point_3;

	// Token: 0x04000596 RID: 1430
	private readonly System.Windows.Forms.Timer timer_3 = new System.Windows.Forms.Timer();

	// Token: 0x04000597 RID: 1431
	private GEnum16 genum16_0;

	// Token: 0x04000598 RID: 1432
	private const int int_27 = 11;

	// Token: 0x020000DC RID: 220
	private class Class93 : IComparer<GStruct1>
	{
		// Token: 0x06000C4E RID: 3150 RVA: 0x0000AE4C File Offset: 0x0000904C
		public Class93(int int_1)
		{
			this.int_0 = int_1;
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x0000AE5B File Offset: 0x0000905B
		public int Compare(GStruct1 x, GStruct1 y)
		{
			if (x.int_0 == -10)
			{
				return -y.int_0.CompareTo(this.int_0);
			}
			return x.int_0.CompareTo(this.int_0);
		}

		// Token: 0x04000599 RID: 1433
		private readonly int int_0;
	}

	// Token: 0x020000DD RID: 221
	[CompilerGenerated]
	private sealed class Class94
	{
		// Token: 0x06000C51 RID: 3153 RVA: 0x0000AE8D File Offset: 0x0000908D
		internal void method_0()
		{
			this.fastColoredTextBox_0.method_20(this.timer_0);
		}

		// Token: 0x0400059A RID: 1434
		public FastColoredTextBox fastColoredTextBox_0;

		// Token: 0x0400059B RID: 1435
		public System.Windows.Forms.Timer timer_0;
	}

	// Token: 0x020000DE RID: 222
	[CompilerGenerated]
	private sealed class Class95
	{
		// Token: 0x06000C53 RID: 3155 RVA: 0x0000AEA0 File Offset: 0x000090A0
		internal void method_0()
		{
			this.fastColoredTextBox_0.method_25(this.dataObject_0);
		}

		// Token: 0x0400059C RID: 1436
		public FastColoredTextBox fastColoredTextBox_0;

		// Token: 0x0400059D RID: 1437
		public DataObject dataObject_0;
	}

	// Token: 0x020000DF RID: 223
	[CompilerGenerated]
	private sealed class Class96
	{
		// Token: 0x06000C55 RID: 3157 RVA: 0x0000AEB3 File Offset: 0x000090B3
		internal void method_0()
		{
			this.fastColoredTextBox_0.method_25(this.dataObject_0);
		}

		// Token: 0x0400059E RID: 1438
		public FastColoredTextBox fastColoredTextBox_0;

		// Token: 0x0400059F RID: 1439
		public DataObject dataObject_0;
	}

	// Token: 0x020000E0 RID: 224
	[CompilerGenerated]
	private sealed class Class97
	{
		// Token: 0x06000C57 RID: 3159 RVA: 0x0000AEC6 File Offset: 0x000090C6
		internal void method_0()
		{
			if (Clipboard.ContainsText())
			{
				this.string_0 = Clipboard.GetText();
			}
		}

		// Token: 0x040005A0 RID: 1440
		public string string_0;
	}

	// Token: 0x020000E1 RID: 225
	[CompilerGenerated]
	[Serializable]
	private sealed class Class98
	{
		// Token: 0x06000C5A RID: 3162 RVA: 0x0000AEE6 File Offset: 0x000090E6
		internal string method_0(Match match_0)
		{
			return match_0.Value.ToUpper();
		}

		// Token: 0x040005A1 RID: 1441
		public static readonly FastColoredTextBox.Class98 <>9 = new FastColoredTextBox.Class98();

		// Token: 0x040005A2 RID: 1442
		public static MatchEvaluator <>9__662_0;
	}

	// Token: 0x020000E2 RID: 226
	[CompilerGenerated]
	private sealed class Class99
	{
		// Token: 0x06000C5C RID: 3164 RVA: 0x0000AEF3 File Offset: 0x000090F3
		internal void method_0(object object_0)
		{
			this.fastColoredTextBox_0.Invalidate(this.rectangle_0);
			this.timer_0.Dispose();
		}

		// Token: 0x040005A3 RID: 1443
		public FastColoredTextBox fastColoredTextBox_0;

		// Token: 0x040005A4 RID: 1444
		public Rectangle rectangle_0;

		// Token: 0x040005A5 RID: 1445
		public System.Threading.Timer timer_0;
	}
}
