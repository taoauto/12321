﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Token: 0x0200002E RID: 46
public class GClass18 : GClass16
{
	// Token: 0x06000214 RID: 532 RVA: 0x000045CB File Offset: 0x000027CB
	public GClass18() : this(null)
	{
	}

	// Token: 0x06000215 RID: 533 RVA: 0x000045D4 File Offset: 0x000027D4
	public GClass18(string string_3) : this(string_3, 8080)
	{
	}

	// Token: 0x06000216 RID: 534 RVA: 0x000045E2 File Offset: 0x000027E2
	public GClass18(string string_3, int int_5) : this(string_3, int_5, string.Empty, string.Empty)
	{
	}

	// Token: 0x06000217 RID: 535 RVA: 0x000045F6 File Offset: 0x000027F6
	public GClass18(string string_3, int int_5, string string_4, string string_5) : base(GEnum4.Http, string_3, int_5, string_4, string_5)
	{
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00004604 File Offset: 0x00002804
	public static GClass18 smethod_2(string string_3)
	{
		return GClass16.smethod_0(GEnum4.Http, string_3) as GClass18;
	}

	// Token: 0x06000219 RID: 537 RVA: 0x00026C4C File Offset: 0x00024E4C
	public static bool smethod_3(string string_3, out GClass18 gclass18_0)
	{
		GClass16 gclass;
		if (GClass16.smethod_1(GEnum4.Http, string_3, out gclass))
		{
			gclass18_0 = (gclass as GClass18);
			return true;
		}
		gclass18_0 = null;
		return false;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00026C74 File Offset: 0x00024E74
	public override TcpClient \u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string string_3, int int_5, TcpClient tcpClient_0 = null)
	{
		base.method_1();
		if (string_3 == null)
		{
			throw new ArgumentNullException("destinationHost");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("destinationHost");
		}
		if (!Class13.smethod_5(int_5))
		{
			throw Class13.smethod_4("destinationPort");
		}
		TcpClient tcpClient = tcpClient_0;
		if (tcpClient == null)
		{
			tcpClient = base.method_0();
		}
		if (int_5 != 80)
		{
			GEnum3 genum = GEnum3.OK;
			try
			{
				NetworkStream stream = tcpClient.GetStream();
				this.method_4(stream, string_3, int_5);
				genum = this.method_5(stream);
			}
			catch (Exception ex)
			{
				tcpClient.Close();
				if (!(ex is IOException) && !(ex is SocketException))
				{
					throw;
				}
				throw base.method_2(Class2.String_41, ex);
			}
			if (genum != GEnum3.OK)
			{
				tcpClient.Close();
				throw new GException2(string.Format(Class2.String_47, genum, this.ToString()), this, null);
			}
		}
		return tcpClient;
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00026D50 File Offset: 0x00024F50
	private string method_3()
	{
		if (string.IsNullOrEmpty(this.string_1) && string.IsNullOrEmpty(this.string_2))
		{
			return string.Empty;
		}
		string arg = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", this.string_1, this.string_2)));
		return string.Format("Proxy-Authorization: Basic {0}\r\n", arg);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00026DB0 File Offset: 0x00024FB0
	private void method_4(NetworkStream networkStream_0, string string_3, int int_5)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendFormat("CONNECT {0}:{1} HTTP/1.1\r\n", string_3, int_5);
		stringBuilder.AppendFormat(this.method_3(), new object[0]);
		stringBuilder.AppendLine();
		byte[] bytes = Encoding.ASCII.GetBytes(stringBuilder.ToString());
		networkStream_0.Write(bytes, 0, bytes.Length);
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00026E0C File Offset: 0x0002500C
	private GEnum3 method_5(NetworkStream networkStream_0)
	{
		byte[] array = new byte[50];
		StringBuilder stringBuilder = new StringBuilder();
		this.method_6(networkStream_0);
		do
		{
			int count = networkStream_0.Read(array, 0, 50);
			stringBuilder.Append(Encoding.ASCII.GetString(array, 0, count));
		}
		while (networkStream_0.DataAvailable);
		string text = stringBuilder.ToString();
		if (text.Length == 0)
		{
			throw base.method_2(Class2.String_45, null);
		}
		string text2 = text.smethod_5(" ", "\r\n", StringComparison.Ordinal);
		int num = text2.IndexOf(' ');
		if (num == -1)
		{
			throw base.method_2(Class2.String_46, null);
		}
		string text3 = text2.Substring(0, num);
		if (text3.Length == 0)
		{
			throw base.method_2(Class2.String_46, null);
		}
		return (GEnum3)Enum.Parse(typeof(GEnum3), text3);
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00026ED0 File Offset: 0x000250D0
	private void method_6(NetworkStream networkStream_0)
	{
		int num = 0;
		int num2 = (networkStream_0.ReadTimeout < 10) ? 10 : networkStream_0.ReadTimeout;
		while (!networkStream_0.DataAvailable)
		{
			if (num >= num2)
			{
				throw base.method_2(Class2.String_49, null);
			}
			num += 10;
			Thread.Sleep(10);
		}
	}

	// Token: 0x0400012F RID: 303
	private const int int_3 = 50;

	// Token: 0x04000130 RID: 304
	private const int int_4 = 8080;
}
