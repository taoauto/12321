﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;

// Token: 0x02000084 RID: 132
internal class Class67
{
	// Token: 0x060005D0 RID: 1488 RVA: 0x00006B78 File Offset: 0x00004D78
	public Class67(GClass45 gclass45_1)
	{
		this.gclass45_0 = gclass45_1;
		this.int_1 = -1;
		this.list_0 = new List<Class66>();
		this.stringBuilder_0 = new StringBuilder();
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00006BA4 File Offset: 0x00004DA4
	public Class67(byte[] byte_0, int int_3, int int_4, GClass45 gclass45_1) : this(gclass45_1)
	{
		this.method_9(byte_0, int_3, int_4);
	}

	// Token: 0x1700017B RID: 379
	// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00006BB7 File Offset: 0x00004DB7
	internal GClass45 GClass45_0
	{
		get
		{
			return this.gclass45_0;
		}
	}

	// Token: 0x1700017C RID: 380
	// (get) Token: 0x060005D3 RID: 1491 RVA: 0x00006BBF File Offset: 0x00004DBF
	public int Int32_0
	{
		get
		{
			return this.int_1 - this.int_0;
		}
	}

	// Token: 0x1700017D RID: 381
	// (get) Token: 0x060005D4 RID: 1492 RVA: 0x00006BCE File Offset: 0x00004DCE
	public bool Boolean_0
	{
		get
		{
			return this.enum7_0 != Enum7.End;
		}
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x00033E50 File Offset: 0x00032050
	private int method_0(byte[] byte_0, int int_3, int int_4)
	{
		int num = 0;
		int count = this.list_0.Count;
		for (int i = 0; i < count; i++)
		{
			Class66 @class = this.list_0[i];
			if (@class != null)
			{
				if (@class.Int32_0 == 0)
				{
					this.list_0[i] = null;
				}
				else
				{
					num += @class.method_0(byte_0, int_3 + num, int_4 - num);
					if (num == int_4)
					{
						break;
					}
				}
			}
		}
		return num;
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00033EB4 File Offset: 0x000320B4
	private static string smethod_0(string string_0)
	{
		int num = string_0.IndexOf(';');
		if (num <= -1)
		{
			return string_0;
		}
		return string_0.Substring(0, num);
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x00033ED8 File Offset: 0x000320D8
	private Enum7 method_1(byte[] byte_0, ref int int_3, int int_4)
	{
		int num;
		if (!this.bool_1)
		{
			num = int_3;
			int_3 = num + 1;
			if (byte_0[num] != 13)
			{
				Class67.smethod_1("CR is expected.");
			}
			this.bool_1 = true;
			if (int_3 == int_4)
			{
				return Enum7.DataEnded;
			}
		}
		num = int_3;
		int_3 = num + 1;
		if (byte_0[num] != 10)
		{
			Class67.smethod_1("LF is expected.");
		}
		return Enum7.None;
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00033F30 File Offset: 0x00032130
	private Enum7 method_2(byte[] byte_0, ref int int_3, int int_4)
	{
		byte b = 0;
		while (int_3 < int_4)
		{
			int num = int_3;
			int_3 = num + 1;
			b = byte_0[num];
			if (this.bool_1)
			{
				if (b != 10)
				{
					Class67.smethod_1("LF is expected.");
				}
				IL_85:
				if (this.bool_1)
				{
					if (b == 10)
					{
						this.int_0 = 0;
						try
						{
							this.int_1 = int.Parse(Class67.smethod_0(this.stringBuilder_0.ToString()), NumberStyles.HexNumber);
						}
						catch
						{
							Class67.smethod_1("The chunk size cannot be parsed.");
						}
						if (this.int_1 == 0)
						{
							this.int_2 = 2;
							return Enum7.Trailer;
						}
						return Enum7.Data;
					}
				}
				return Enum7.None;
			}
			if (b == 13)
			{
				this.bool_1 = true;
			}
			else
			{
				if (b == 10)
				{
					Class67.smethod_1("LF is unexpected.");
				}
				if (b == 32)
				{
					this.bool_0 = true;
				}
				if (!this.bool_0)
				{
					this.stringBuilder_0.Append((char)b);
				}
				if (this.stringBuilder_0.Length > 20)
				{
					Class67.smethod_1("The chunk size is too long.");
				}
			}
		}
		goto IL_85;
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x0003402C File Offset: 0x0003222C
	private Enum7 method_3(byte[] byte_0, ref int int_3, int int_4)
	{
		if (this.int_2 == 2 && byte_0[int_3] == 13 && this.stringBuilder_0.Length == 0)
		{
			int_3++;
			if (int_3 < int_4 && byte_0[int_3] == 10)
			{
				int_3++;
				return Enum7.End;
			}
			int_3--;
		}
		while (int_3 < int_4 && this.int_2 < 4)
		{
			int num = int_3;
			int_3 = num + 1;
			byte b = byte_0[num];
			this.stringBuilder_0.Append((char)b);
			if (this.stringBuilder_0.Length > 4196)
			{
				Class67.smethod_1("The trailer is too long.");
			}
			if (this.int_2 != 1)
			{
				if (this.int_2 != 3)
				{
					if (b == 13)
					{
						this.int_2++;
						continue;
					}
					if (b == 10)
					{
						Class67.smethod_1("LF is unexpected.");
					}
					this.int_2 = 0;
					continue;
				}
			}
			if (b != 10)
			{
				Class67.smethod_1("LF is expected.");
			}
			this.int_2++;
		}
		if (this.int_2 < 4)
		{
			return Enum7.Trailer;
		}
		this.stringBuilder_0.Length -= 2;
		StringReader stringReader = new StringReader(this.stringBuilder_0.ToString());
		string text;
		while ((text = stringReader.ReadLine()) != null && text.Length > 0)
		{
			this.gclass45_0.method_9(text);
		}
		return Enum7.End;
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x00006BDC File Offset: 0x00004DDC
	private static void smethod_1(string string_0)
	{
		throw new WebException(string_0, null, WebExceptionStatus.ServerProtocolViolation, null);
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x00034180 File Offset: 0x00032380
	private void method_4(byte[] byte_0, ref int int_3, int int_4)
	{
		if (this.enum7_0 == Enum7.End)
		{
			Class67.smethod_1("The chunks were ended.");
		}
		if (this.enum7_0 == Enum7.None)
		{
			this.enum7_0 = this.method_2(byte_0, ref int_3, int_4);
			if (this.enum7_0 == Enum7.None)
			{
				return;
			}
			this.stringBuilder_0.Length = 0;
			this.bool_1 = false;
			this.bool_0 = false;
		}
		if (this.enum7_0 == Enum7.Data && int_3 < int_4)
		{
			this.enum7_0 = this.method_5(byte_0, ref int_3, int_4);
			if (this.enum7_0 == Enum7.Data)
			{
				return;
			}
		}
		if (this.enum7_0 == Enum7.DataEnded && int_3 < int_4)
		{
			this.enum7_0 = this.method_1(byte_0, ref int_3, int_4);
			if (this.enum7_0 == Enum7.DataEnded)
			{
				return;
			}
			this.bool_1 = false;
		}
		if (this.enum7_0 == Enum7.Trailer && int_3 < int_4)
		{
			this.enum7_0 = this.method_3(byte_0, ref int_3, int_4);
			if (this.enum7_0 == Enum7.Trailer)
			{
				return;
			}
			this.stringBuilder_0.Length = 0;
		}
		if (int_3 < int_4)
		{
			this.method_4(byte_0, ref int_3, int_4);
		}
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x00034270 File Offset: 0x00032470
	private Enum7 method_5(byte[] byte_0, ref int int_3, int int_4)
	{
		int num = int_4 - int_3;
		int num2 = this.int_1 - this.int_0;
		if (num > num2)
		{
			num = num2;
		}
		byte[] array = new byte[num];
		Buffer.BlockCopy(byte_0, int_3, array, 0, num);
		this.list_0.Add(new Class66(array));
		int_3 += num;
		this.int_0 += num;
		if (this.int_0 != this.int_1)
		{
			return Enum7.Data;
		}
		return Enum7.DataEnded;
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00006BE8 File Offset: 0x00004DE8
	internal void method_6()
	{
		this.int_0 = 0;
		this.int_1 = -1;
		this.list_0.Clear();
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00006C03 File Offset: 0x00004E03
	internal int method_7(byte[] byte_0, int int_3, int int_4, int int_5)
	{
		this.method_9(byte_0, int_3, int_4);
		return this.method_8(byte_0, int_3, int_5);
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x00006C18 File Offset: 0x00004E18
	public int method_8(byte[] byte_0, int int_3, int int_4)
	{
		if (int_4 <= 0)
		{
			return 0;
		}
		return this.method_0(byte_0, int_3, int_4);
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x00006C29 File Offset: 0x00004E29
	public void method_9(byte[] byte_0, int int_3, int int_4)
	{
		if (int_4 <= 0)
		{
			return;
		}
		this.method_4(byte_0, ref int_3, int_3 + int_4);
	}

	// Token: 0x040002E4 RID: 740
	private int int_0;

	// Token: 0x040002E5 RID: 741
	private int int_1;

	// Token: 0x040002E6 RID: 742
	private List<Class66> list_0;

	// Token: 0x040002E7 RID: 743
	private bool bool_0;

	// Token: 0x040002E8 RID: 744
	private GClass45 gclass45_0;

	// Token: 0x040002E9 RID: 745
	private StringBuilder stringBuilder_0;

	// Token: 0x040002EA RID: 746
	private bool bool_1;

	// Token: 0x040002EB RID: 747
	private Enum7 enum7_0;

	// Token: 0x040002EC RID: 748
	private int int_2;
}
