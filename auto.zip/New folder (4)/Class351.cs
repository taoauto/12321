﻿using System;

// Token: 0x02000297 RID: 663
internal class Class351
{
	// Token: 0x1700078D RID: 1933
	// (get) Token: 0x06002496 RID: 9366 RVA: 0x0001BC8A File Offset: 0x00019E8A
	public static string String_0
	{
		get
		{
			return "Giám ngục";
		}
	}

	// Token: 0x04001860 RID: 6240
	public static int int_0 = 194;

	// Token: 0x04001861 RID: 6241
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 45,
		Int32_1 = 31,
		Int32_2 = Class351.int_0,
		String_2 = "Trương Chính Quý"
	};
}
