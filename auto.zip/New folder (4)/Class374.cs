﻿using System;

// Token: 0x020002B0 RID: 688
internal class Class374
{
	// Token: 0x17000848 RID: 2120
	// (get) Token: 0x06002671 RID: 9841 RVA: 0x0001CB51 File Offset: 0x0001AD51
	public static string String_0
	{
		get
		{
			return "Thiếu Lâm Tự";
		}
	}

	// Token: 0x040019D3 RID: 6611
	public static int int_0 = 9;

	// Token: 0x040019D4 RID: 6612
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 6U,
		Int32_0 = 61,
		Int32_1 = 82,
		Int32_2 = Class374.int_0,
		String_2 = "Huyền Sinh"
	};

	// Token: 0x040019D5 RID: 6613
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 90,
		Int32_1 = 72,
		Int32_2 = Class374.int_0,
		String_2 = "Huyền Tịch"
	};

	// Token: 0x040019D6 RID: 6614
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 96,
		Int32_1 = 82,
		Int32_2 = Class374.int_0,
		String_2 = "Tuệ Phương"
	};

	// Token: 0x040019D7 RID: 6615
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 5U,
		Int32_0 = 92,
		Int32_1 = 71,
		Int32_2 = Class374.int_0,
		String_2 = "Huyền Nạn"
	};
}
