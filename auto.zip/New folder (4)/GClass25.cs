﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using WebSocketSharp;
using WebSocketSharp.Net;

// Token: 0x02000053 RID: 83
public class GClass25 : IDisposable
{
	// Token: 0x0600035A RID: 858 RVA: 0x0002A850 File Offset: 0x00028A50
	internal GClass25(GClass47 gclass47_0, string string_7)
	{
		this.gclass46_0 = gclass47_0;
		this.string_4 = string_7;
		this.action_0 = new Action(gclass47_0.method_0);
		this.gclass24_0 = gclass47_0.GClass24_0;
		this.action_1 = new Action<GEventArgs4>(this.method_29);
		this.bool_10 = gclass47_0.GClass46.\u202A\u206B\u206D\u206A\u200C\u206D\u200E\u206F\u200E\u200E\u200B\u200D\u206D\u200E\u206E\u200D\u202C\u200B\u202D\u202C\u202A\u206F\u200B\u200C\u202A\u206E\u206D\u206E\u202C\u202D\u200B\u206E\u202B\u202D\u202E\u200C\u206D\u202B\u202A\u200E\u202E;
		this.stream_0 = gclass47_0.Stream_0;
		this.timeSpan_0 = TimeSpan.FromSeconds(1.0);
		this.method_26();
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0002A8D8 File Offset: 0x00028AD8
	internal GClass25(Class84 class84_0, string string_7)
	{
		this.gclass46_0 = class84_0;
		this.string_4 = string_7;
		this.action_0 = new Action(class84_0.method_2);
		this.gclass24_0 = class84_0.GClass24_0;
		this.action_1 = new Action<GEventArgs4>(this.method_29);
		this.bool_10 = class84_0.GClass46.\u202A\u206B\u206D\u206A\u200C\u206D\u200E\u206F\u200E\u200E\u200B\u200D\u206D\u200E\u206E\u200D\u202C\u200B\u202D\u202C\u202A\u206F\u200B\u200C\u202A\u206E\u206D\u206E\u202C\u202D\u200B\u206E\u202B\u202D\u202E\u200C\u206D\u202B\u202A\u200E\u202E;
		this.stream_0 = class84_0.Stream_0;
		this.timeSpan_0 = TimeSpan.FromSeconds(1.0);
		this.method_26();
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0002A960 File Offset: 0x00028B60
	public GClass25(string string_7, params string[] string_8)
	{
		if (string_7 == null)
		{
			throw new ArgumentNullException("url");
		}
		if (string_7.Length == 0)
		{
			throw new ArgumentException("An empty string.", "url");
		}
		string message;
		if (!string_7.smethod_72(out this.uri_1, out message))
		{
			throw new ArgumentException(message, "url");
		}
		if (string_8 != null && string_8.Length != 0)
		{
			if (!GClass25.smethod_0(string_8, out message))
			{
				throw new ArgumentException(message, "protocols");
			}
			this.string_5 = string_8;
		}
		this.string_0 = GClass25.smethod_1();
		this.bool_0 = true;
		this.gclass24_0 = new GClass24();
		this.action_1 = new Action<GEventArgs4>(this.method_28);
		this.bool_10 = (this.uri_1.Scheme == "wss");
		this.timeSpan_0 = TimeSpan.FromSeconds(5.0);
		this.method_26();
	}

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x0600035D RID: 861 RVA: 0x0000531F File Offset: 0x0000351F
	internal GClass34 GClass34_0
	{
		get
		{
			return this.gclass34_0;
		}
	}

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x0600035E RID: 862 RVA: 0x00005327 File Offset: 0x00003527
	// (set) Token: 0x0600035F RID: 863 RVA: 0x0000532F File Offset: 0x0000352F
	internal Func<GClass46, string> Func_0
	{
		get
		{
			return this.func_0;
		}
		set
		{
			this.func_0 = value;
		}
	}

	// Token: 0x170000ED RID: 237
	// (get) Token: 0x06000360 RID: 864 RVA: 0x0002AA40 File Offset: 0x00028C40
	internal bool Boolean_0
	{
		get
		{
			object obj = this.object_0;
			bool result;
			lock (obj)
			{
				result = (this.queue_0.Count > 0);
			}
			return result;
		}
	}

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x06000361 RID: 865 RVA: 0x00005338 File Offset: 0x00003538
	// (set) Token: 0x06000362 RID: 866 RVA: 0x00005340 File Offset: 0x00003540
	internal bool Boolean_1
	{
		get
		{
			return this.bool_5;
		}
		set
		{
			this.bool_5 = value;
		}
	}

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x06000363 RID: 867 RVA: 0x00005349 File Offset: 0x00003549
	internal bool Boolean_2
	{
		get
		{
			return this.genum8_0 == GEnum8.Open || this.genum8_0 == GEnum8.Closing;
		}
	}

	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x06000364 RID: 868 RVA: 0x00005363 File Offset: 0x00003563
	// (set) Token: 0x06000365 RID: 869 RVA: 0x0002AA8C File Offset: 0x00028C8C
	public CompressionMethod CompressionMethod_0
	{
		get
		{
			return this.compressionMethod_0;
		}
		set
		{
			string message = null;
			if (!this.bool_0)
			{
				message = "This instance is not a client.";
				throw new InvalidOperationException(message);
			}
			if (!this.method_2(out message))
			{
				this.gclass24_0.method_6(message);
				return;
			}
			object obj = this.object_3;
			lock (obj)
			{
				if (!this.method_2(out message))
				{
					this.gclass24_0.method_6(message);
				}
				else
				{
					this.compressionMethod_0 = value;
				}
			}
		}
	}

	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x06000366 RID: 870 RVA: 0x0000536B File Offset: 0x0000356B
	public IEnumerable<GClass33> IEnumerable_0
	{
		get
		{
			GClass25.Class32 @class = new GClass25.Class32(-2);
			@class.gclass25_0 = this;
			return @class;
		}
	}

	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x06000367 RID: 871 RVA: 0x0000537B File Offset: 0x0000357B
	public GClass43 GClass43_0
	{
		get
		{
			return this.gclass43_0;
		}
	}

	// Token: 0x170000F3 RID: 243
	// (get) Token: 0x06000368 RID: 872 RVA: 0x00005383 File Offset: 0x00003583
	// (set) Token: 0x06000369 RID: 873 RVA: 0x0000538B File Offset: 0x0000358B
	public bool Boolean_3
	{
		get
		{
			return this.bool_1;
		}
		set
		{
			this.bool_1 = value;
		}
	}

	// Token: 0x170000F4 RID: 244
	// (get) Token: 0x0600036A RID: 874 RVA: 0x00005394 File Offset: 0x00003594
	// (set) Token: 0x0600036B RID: 875 RVA: 0x0002AB18 File Offset: 0x00028D18
	public bool Boolean_4
	{
		get
		{
			return this.bool_2;
		}
		set
		{
			string message = null;
			if (!this.bool_0)
			{
				message = "This instance is not a client.";
				throw new InvalidOperationException(message);
			}
			if (!this.method_2(out message))
			{
				this.gclass24_0.method_6(message);
				return;
			}
			object obj = this.object_3;
			lock (obj)
			{
				if (!this.method_2(out message))
				{
					this.gclass24_0.method_6(message);
				}
				else
				{
					this.bool_2 = value;
				}
			}
		}
	}

	// Token: 0x170000F5 RID: 245
	// (get) Token: 0x0600036C RID: 876 RVA: 0x0000539C File Offset: 0x0000359C
	public string String_0
	{
		get
		{
			return this.string_1 ?? string.Empty;
		}
	}

	// Token: 0x170000F6 RID: 246
	// (get) Token: 0x0600036D RID: 877 RVA: 0x000053AD File Offset: 0x000035AD
	public bool Boolean_5
	{
		get
		{
			return this.method_31(GClass25.byte_0);
		}
	}

	// Token: 0x170000F7 RID: 247
	// (get) Token: 0x0600036E RID: 878 RVA: 0x000053BA File Offset: 0x000035BA
	public bool Boolean_6
	{
		get
		{
			return this.bool_10;
		}
	}

	// Token: 0x170000F8 RID: 248
	// (get) Token: 0x0600036F RID: 879 RVA: 0x000053C2 File Offset: 0x000035C2
	// (set) Token: 0x06000370 RID: 880 RVA: 0x000053CC File Offset: 0x000035CC
	public GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
		internal set
		{
			this.gclass24_0 = value;
		}
	}

	// Token: 0x170000F9 RID: 249
	// (get) Token: 0x06000371 RID: 881 RVA: 0x000053D7 File Offset: 0x000035D7
	// (set) Token: 0x06000372 RID: 882 RVA: 0x0002ABA4 File Offset: 0x00028DA4
	public string String_1
	{
		get
		{
			return this.string_3;
		}
		set
		{
			string message = null;
			if (!this.bool_0)
			{
				message = "This instance is not a client.";
				throw new InvalidOperationException(message);
			}
			if (!value.smethod_88())
			{
				Uri uri;
				if (!Uri.TryCreate(value, UriKind.Absolute, out uri))
				{
					message = "Not an absolute URI string.";
					throw new ArgumentException(message, "value");
				}
				if (uri.Segments.Length > 1)
				{
					message = "It includes the path segments.";
					throw new ArgumentException(message, "value");
				}
			}
			if (!this.method_2(out message))
			{
				this.gclass24_0.method_6(message);
				return;
			}
			object obj = this.object_3;
			lock (obj)
			{
				if (!this.method_2(out message))
				{
					this.gclass24_0.method_6(message);
				}
				else
				{
					this.string_3 = ((!value.smethod_88()) ? value.TrimEnd(new char[]
					{
						'/'
					}) : value);
				}
			}
		}
	}

	// Token: 0x170000FA RID: 250
	// (get) Token: 0x06000373 RID: 883 RVA: 0x000053DF File Offset: 0x000035DF
	// (set) Token: 0x06000374 RID: 884 RVA: 0x000053F0 File Offset: 0x000035F0
	public string String_2
	{
		get
		{
			return this.string_4 ?? string.Empty;
		}
		internal set
		{
			this.string_4 = value;
		}
	}

	// Token: 0x170000FB RID: 251
	// (get) Token: 0x06000375 RID: 885 RVA: 0x000053F9 File Offset: 0x000035F9
	public GEnum8 GEnum8_0
	{
		get
		{
			return this.genum8_0;
		}
	}

	// Token: 0x170000FC RID: 252
	// (get) Token: 0x06000376 RID: 886 RVA: 0x00005403 File Offset: 0x00003603
	public GClass32 GClass32_0
	{
		get
		{
			if (!this.bool_0)
			{
				throw new InvalidOperationException("This instance is not a client.");
			}
			if (!this.bool_10)
			{
				throw new InvalidOperationException("This instance does not use a secure connection.");
			}
			return this.method_25();
		}
	}

	// Token: 0x170000FD RID: 253
	// (get) Token: 0x06000377 RID: 887 RVA: 0x00005431 File Offset: 0x00003631
	public Uri Uri_0
	{
		get
		{
			if (!this.bool_0)
			{
				return this.gclass46_0.GClass46.\u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E;
			}
			return this.uri_1;
		}
	}

	// Token: 0x170000FE RID: 254
	// (get) Token: 0x06000378 RID: 888 RVA: 0x0000544D File Offset: 0x0000364D
	// (set) Token: 0x06000379 RID: 889 RVA: 0x0002AC8C File Offset: 0x00028E8C
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.timeSpan_0;
		}
		set
		{
			if (value <= TimeSpan.Zero)
			{
				throw new ArgumentOutOfRangeException("value", "Zero or less.");
			}
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_3;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.timeSpan_0 = value;
				}
			}
		}
	}

	// Token: 0x14000003 RID: 3
	// (add) Token: 0x0600037A RID: 890 RVA: 0x0002AD20 File Offset: 0x00028F20
	// (remove) Token: 0x0600037B RID: 891 RVA: 0x0002AD58 File Offset: 0x00028F58
	public event EventHandler<GEventArgs2> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs2> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs2> value2 = (EventHandler<GEventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs2>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs2> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs2> value2 = (EventHandler<GEventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs2>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000004 RID: 4
	// (add) Token: 0x0600037C RID: 892 RVA: 0x0002AD90 File Offset: 0x00028F90
	// (remove) Token: 0x0600037D RID: 893 RVA: 0x0002ADC8 File Offset: 0x00028FC8
	public event EventHandler<GEventArgs3> Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs3> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs3> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000005 RID: 5
	// (add) Token: 0x0600037E RID: 894 RVA: 0x0002AE00 File Offset: 0x00029000
	// (remove) Token: 0x0600037F RID: 895 RVA: 0x0002AE38 File Offset: 0x00029038
	public event EventHandler<GEventArgs4> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs4> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs4> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs4> value2 = (EventHandler<GEventArgs4>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs4>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs4> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs4> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs4> value2 = (EventHandler<GEventArgs4>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs4>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000006 RID: 6
	// (add) Token: 0x06000380 RID: 896 RVA: 0x0002AE70 File Offset: 0x00029070
	// (remove) Token: 0x06000381 RID: 897 RVA: 0x0002AEA8 File Offset: 0x000290A8
	public event EventHandler Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_3;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_3;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000382 RID: 898 RVA: 0x0002AEE0 File Offset: 0x000290E0
	private bool method_0()
	{
		if (this.genum8_0 == GEnum8.Open)
		{
			string text = "The handshake request has already been accepted.";
			this.gclass24_0.method_6(text);
			return false;
		}
		object obj = this.object_3;
		bool result;
		lock (obj)
		{
			if (this.genum8_0 == GEnum8.Open)
			{
				string text2 = "The handshake request has already been accepted.";
				this.gclass24_0.method_6(text2);
				result = false;
			}
			else if (this.genum8_0 == GEnum8.Closing)
			{
				string string_ = "The close process has set in.";
				this.gclass24_0.method_2(string_);
				string_ = "An interruption has occurred while attempting to accept.";
				this.method_21(string_, null);
				result = false;
			}
			else if (this.genum8_0 == GEnum8.Closed)
			{
				string string_2 = "The connection has been closed.";
				this.gclass24_0.method_2(string_2);
				string_2 = "An interruption has occurred while attempting to accept.";
				this.method_21(string_2, null);
				result = false;
			}
			else
			{
				try
				{
					if (!this.method_1())
					{
						return false;
					}
				}
				catch (Exception ex)
				{
					this.gclass24_0.method_3(ex.Message);
					this.gclass24_0.method_1(ex.ToString());
					string string_3 = "An exception has occurred while attempting to accept.";
					this.method_22(string_3, ex);
					return false;
				}
				this.genum8_0 = GEnum8.Open;
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0002B03C File Offset: 0x0002923C
	private bool method_1()
	{
		this.gclass24_0.method_1(string.Format("A handshake request from {0}:\n{1}", this.gclass46_0.GClass46.\u202D\u200D\u202A\u200B\u206B\u202E\u206F\u202A\u206C\u206F\u200B\u206C\u202C\u200B\u206A\u206C\u200D\u200D\u202D\u206A\u206B\u206D\u206D\u206C\u206E\u206F\u200C\u206F\u206A\u206E\u206D\u202B\u206B\u206F\u206B\u202C\u206B\u206F\u202A\u206F\u202E, this.gclass46_0));
		string text;
		if (!this.method_3(this.gclass46_0, out text))
		{
			this.gclass24_0.method_2(text);
			this.method_43(GEnum6.ProtocolError, "A handshake error has occurred while attempting to accept.");
			return false;
		}
		if (!this.method_17(this.gclass46_0, out text))
		{
			this.gclass24_0.method_2(text);
			this.method_43(GEnum6.PolicyViolation, "A handshake error has occurred while attempting to accept.");
			return false;
		}
		this.string_0 = this.gclass46_0.GClass46.\u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E["Sec-WebSocket-Key"];
		if (this.string_4 != null)
		{
			IEnumerable<string> ienumerable_ = this.gclass46_0.GClass46.\u202C\u206C\u200B\u200F\u202B\u200C\u202E\u200D\u200E\u206C\u206E\u206E\u202B\u200B\u202D\u202B\u206F\u206B\u206A\u202E\u202C\u206E\u206C\u202E\u206C\u206A\u206E\u200F\u200E\u202A\u202A\u200E\u202A\u202B\u206D\u200D\u206E\u200C\u206C\u202C\u202E;
			this.method_41(ienumerable_);
		}
		if (!this.bool_5)
		{
			string string_ = this.gclass46_0.GClass46.\u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E["Sec-WebSocket-Extensions"];
			this.method_39(string_);
		}
		return this.method_55(this.method_16());
	}

	// Token: 0x06000384 RID: 900 RVA: 0x00005455 File Offset: 0x00003655
	private bool method_2(out string string_7)
	{
		string_7 = null;
		if (this.genum8_0 == GEnum8.Open)
		{
			string_7 = "The connection has already been established.";
			return false;
		}
		if (this.genum8_0 == GEnum8.Closing)
		{
			string_7 = "The connection is closing.";
			return false;
		}
		return true;
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0002B138 File Offset: 0x00029338
	private bool method_3(GClass46 gclass46_1, out string string_7)
	{
		string_7 = null;
		if (!gclass46_1.GClass46.\u206B\u206B\u206C\u206F\u202D\u202C\u202A\u206E\u202C\u200F\u206E\u202C\u202A\u206B\u200C\u206F\u200C\u202A\u206C\u206B\u202A\u206C\u206F\u200C\u206B\u200C\u200F\u206F\u200B\u206B\u200D\u206B\u206B\u200F\u202E\u206F\u200C\u200B\u200F\u200E\u202E)
		{
			string_7 = "Not a handshake request.";
			return false;
		}
		if (gclass46_1.GClass46.\u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E == null)
		{
			string_7 = "It specifies an invalid Request-URI.";
			return false;
		}
		NameValueCollection nameValueCollection = gclass46_1.GClass46.\u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E;
		string text = nameValueCollection["Sec-WebSocket-Key"];
		if (text == null)
		{
			string_7 = "It includes no Sec-WebSocket-Key header.";
			return false;
		}
		if (text.Length == 0)
		{
			string_7 = "It includes an invalid Sec-WebSocket-Key header.";
			return false;
		}
		string text2 = nameValueCollection["Sec-WebSocket-Version"];
		if (text2 == null)
		{
			string_7 = "It includes no Sec-WebSocket-Version header.";
			return false;
		}
		if (text2 != "13")
		{
			string_7 = "It includes an invalid Sec-WebSocket-Version header.";
			return false;
		}
		string text3 = nameValueCollection["Sec-WebSocket-Protocol"];
		if (text3 != null && text3.Length == 0)
		{
			string_7 = "It includes an invalid Sec-WebSocket-Protocol header.";
			return false;
		}
		if (!this.bool_5)
		{
			string text4 = nameValueCollection["Sec-WebSocket-Extensions"];
			if (text4 != null && text4.Length == 0)
			{
				string_7 = "It includes an invalid Sec-WebSocket-Extensions header.";
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0002B21C File Offset: 0x0002941C
	private bool method_4(Class27 class27_0, out string string_7)
	{
		string_7 = null;
		if (class27_0.Boolean_2)
		{
			string_7 = "Indicates the redirection.";
			return false;
		}
		if (class27_0.Boolean_3)
		{
			string_7 = "Requires the authentication.";
			return false;
		}
		if (!class27_0.Boolean_4)
		{
			string_7 = "Not a WebSocket handshake response.";
			return false;
		}
		NameValueCollection nameValueCollection_ = class27_0.NameValueCollection_0;
		if (!this.method_59(nameValueCollection_["Sec-WebSocket-Accept"]))
		{
			string_7 = "Includes no Sec-WebSocket-Accept header, or it has an invalid value.";
			return false;
		}
		if (!this.method_61(nameValueCollection_["Sec-WebSocket-Protocol"]))
		{
			string_7 = "Includes no Sec-WebSocket-Protocol header, or it has an invalid value.";
			return false;
		}
		if (!this.method_60(nameValueCollection_["Sec-WebSocket-Extensions"]))
		{
			string_7 = "Includes an invalid Sec-WebSocket-Extensions header.";
			return false;
		}
		if (!this.method_62(nameValueCollection_["Sec-WebSocket-Version"]))
		{
			string_7 = "Includes an invalid Sec-WebSocket-Version header.";
			return false;
		}
		return true;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x0002B2D8 File Offset: 0x000294D8
	private static bool smethod_0(string[] string_7, out string string_8)
	{
		string_8 = null;
		Func<string, bool> func = new Func<string, bool>(GClass25.Class33.<>9.method_0);
		if (string_7.smethod_17(func))
		{
			string_8 = "It contains a value that is not a token.";
			return false;
		}
		if (string_7.smethod_18())
		{
			string_8 = "It contains a value twice.";
			return false;
		}
		return true;
	}

	// Token: 0x06000388 RID: 904 RVA: 0x0002B32C File Offset: 0x0002952C
	private bool method_5(Class42 class42_0, out string string_7)
	{
		string_7 = null;
		bool boolean_ = class42_0.Boolean_8;
		if (this.bool_0 && boolean_)
		{
			string_7 = "A frame from the server is masked.";
			return false;
		}
		if (!this.bool_0 && !boolean_)
		{
			string_7 = "A frame from a client is not masked.";
			return false;
		}
		if (this.bool_6 && class42_0.Boolean_5)
		{
			string_7 = "A data frame has been received while receiving continuation frames.";
			return false;
		}
		if (class42_0.Boolean_2 && this.compressionMethod_0 == CompressionMethod.None)
		{
			string_7 = "A compressed frame has been received without any agreement for it.";
			return false;
		}
		if (class42_0.Enum4_1 == Enum4.On)
		{
			string_7 = "The RSV2 of a frame is non-zero without any negotiation for it.";
			return false;
		}
		if (class42_0.Enum4_2 == Enum4.On)
		{
			string_7 = "The RSV3 of a frame is non-zero without any negotiation for it.";
			return false;
		}
		return true;
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0002B3C4 File Offset: 0x000295C4
	private void method_6(ushort ushort_0, string string_7)
	{
		if (this.genum8_0 == GEnum8.Closing)
		{
			this.gclass24_0.method_4("The closing is already in progress.");
			return;
		}
		if (this.genum8_0 == GEnum8.Closed)
		{
			this.gclass24_0.method_4("The connection has already been closed.");
			return;
		}
		if (ushort_0 == 1005)
		{
			this.method_7(Class30.class30_0, true, true, false);
			return;
		}
		bool flag = !ushort_0.smethod_47();
		this.method_7(new Class30(ushort_0, string_7), flag, flag, false);
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0002B440 File Offset: 0x00029640
	private void method_7(Class30 class30_0, bool bool_11, bool bool_12, bool bool_13)
	{
		object obj = this.object_3;
		lock (obj)
		{
			if (this.genum8_0 == GEnum8.Closing)
			{
				this.gclass24_0.method_4("The closing is already in progress.");
				return;
			}
			if (this.genum8_0 == GEnum8.Closed)
			{
				this.gclass24_0.method_4("The connection has already been closed.");
				return;
			}
			bool_11 = (bool_11 && this.genum8_0 == GEnum8.Open);
			bool_12 = (bool_11 && bool_12);
			this.genum8_0 = GEnum8.Closing;
		}
		this.gclass24_0.method_5("Begin closing the connection.");
		bool flag2 = this.method_11(class30_0, bool_11, bool_12, bool_13);
		this.method_46();
		this.gclass24_0.method_5("End closing the connection.");
		this.genum8_0 = GEnum8.Closed;
		GEventArgs2 gparam_ = new GEventArgs2(class30_0, flag2);
		try
		{
			this.eventHandler_0.smethod_27(this, gparam_);
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
	}

	// Token: 0x0600038B RID: 907 RVA: 0x0002B570 File Offset: 0x00029770
	private void method_8(ushort ushort_0, string string_7)
	{
		if (this.genum8_0 == GEnum8.Closing)
		{
			this.gclass24_0.method_4("The closing is already in progress.");
			return;
		}
		if (this.genum8_0 == GEnum8.Closed)
		{
			this.gclass24_0.method_4("The connection has already been closed.");
			return;
		}
		if (ushort_0 == 1005)
		{
			this.method_9(Class30.class30_0, true, true, false);
			return;
		}
		bool flag = !ushort_0.smethod_47();
		this.method_9(new Class30(ushort_0, string_7), flag, flag, false);
	}

	// Token: 0x0600038C RID: 908 RVA: 0x0002B5EC File Offset: 0x000297EC
	private void method_9(Class30 class30_0, bool bool_11, bool bool_12, bool bool_13)
	{
		GClass25.Class34 @class = new GClass25.Class34();
		@class.action_0 = new Action<Class30, bool, bool, bool>(this.method_7);
		@class.action_0.BeginInvoke(class30_0, bool_11, bool_12, bool_13, new AsyncCallback(@class.method_0), null);
	}

	// Token: 0x0600038D RID: 909 RVA: 0x0002B630 File Offset: 0x00029830
	private bool method_10(byte[] byte_1, bool bool_11, bool bool_12)
	{
		bool flag = byte_1 != null && this.method_52(byte_1);
		if (!bool_12 && flag && bool_11 && this.manualResetEvent_1 != null)
		{
			bool_12 = this.manualResetEvent_1.WaitOne(this.timeSpan_0);
		}
		bool flag2 = flag && bool_12;
		this.gclass24_0.method_1(string.Format("Was clean?: {0}\n  sent: {1}\n  received: {2}", flag2, flag, bool_12));
		return flag2;
	}

	// Token: 0x0600038E RID: 910 RVA: 0x0002B6A4 File Offset: 0x000298A4
	private bool method_11(Class30 class30_0, bool bool_11, bool bool_12, bool bool_13)
	{
		bool flag = false;
		if (bool_11)
		{
			Class42 @class = Class42.smethod_13(class30_0, this.bool_0);
			flag = this.method_52(@class.method_3());
			if (this.bool_0)
			{
				@class.method_0();
			}
		}
		if (!bool_13 && flag && bool_12 && this.manualResetEvent_1 != null)
		{
			bool_13 = this.manualResetEvent_1.WaitOne(this.timeSpan_0);
		}
		bool flag2 = flag && bool_13;
		this.gclass24_0.method_1(string.Format("Was clean?: {0}\n  sent: {1}\n  received: {2}", flag2, flag, bool_13));
		return flag2;
	}

	// Token: 0x0600038F RID: 911 RVA: 0x0002B73C File Offset: 0x0002993C
	private bool method_12()
	{
		if (this.genum8_0 == GEnum8.Open)
		{
			string text = "The connection has already been established.";
			this.gclass24_0.method_6(text);
			return false;
		}
		object obj = this.object_3;
		bool result;
		lock (obj)
		{
			if (this.genum8_0 == GEnum8.Open)
			{
				string text2 = "The connection has already been established.";
				this.gclass24_0.method_6(text2);
				result = false;
			}
			else if (this.genum8_0 == GEnum8.Closing)
			{
				string string_ = "The close process has set in.";
				this.gclass24_0.method_2(string_);
				string_ = "An interruption has occurred while attempting to connect.";
				this.method_21(string_, null);
				result = false;
			}
			else if (this.int_1 > GClass25.int_0)
			{
				string string_2 = "An opportunity for reconnecting has been lost.";
				this.gclass24_0.method_2(string_2);
				string_2 = "An interruption has occurred while attempting to connect.";
				this.method_21(string_2, null);
				result = false;
			}
			else
			{
				this.genum8_0 = GEnum8.Connecting;
				try
				{
					this.method_19();
				}
				catch (Exception ex)
				{
					this.int_1++;
					this.gclass24_0.method_3(ex.Message);
					this.gclass24_0.method_1(ex.ToString());
					string string_3 = "An exception has occurred while attempting to connect.";
					this.method_22(string_3, ex);
					return false;
				}
				this.int_1 = 1;
				this.genum8_0 = GEnum8.Open;
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06000390 RID: 912 RVA: 0x0002B8C8 File Offset: 0x00029AC8
	private string method_13()
	{
		StringBuilder stringBuilder = new StringBuilder(80);
		if (this.compressionMethod_0 != CompressionMethod.None)
		{
			string arg = this.compressionMethod_0.smethod_62(new string[]
			{
				"server_no_context_takeover",
				"client_no_context_takeover"
			});
			stringBuilder.AppendFormat("{0}, ", arg);
		}
		int length = stringBuilder.Length;
		if (length > 2)
		{
			stringBuilder.Length = length - 2;
			return stringBuilder.ToString();
		}
		return null;
	}

	// Token: 0x06000391 RID: 913 RVA: 0x00005483 File Offset: 0x00003683
	private Class27 method_14(GEnum9 genum9_0)
	{
		Class27 @class = Class27.smethod_3(genum9_0);
		@class.NameValueCollection_0["Sec-WebSocket-Version"] = "13";
		return @class;
	}

	// Token: 0x06000392 RID: 914 RVA: 0x0002B930 File Offset: 0x00029B30
	private Class26 method_15()
	{
		Class26 @class = Class26.smethod_4(this.uri_1);
		NameValueCollection nameValueCollection_ = @class.NameValueCollection_0;
		if (!this.string_3.smethod_88())
		{
			nameValueCollection_["Origin"] = this.string_3;
		}
		nameValueCollection_["Sec-WebSocket-Key"] = this.string_0;
		this.bool_9 = (this.string_5 != null);
		if (this.bool_9)
		{
			nameValueCollection_["Sec-WebSocket-Protocol"] = this.string_5.smethod_104(", ");
		}
		this.bool_3 = (this.compressionMethod_0 > CompressionMethod.None);
		if (this.bool_3)
		{
			nameValueCollection_["Sec-WebSocket-Extensions"] = this.method_13();
		}
		nameValueCollection_["Sec-WebSocket-Version"] = "13";
		Class64 class2 = null;
		if (this.class63_0 != null && this.gclass43_0 != null)
		{
			class2 = new Class64(this.class63_0, this.gclass43_0, this.uint_0);
			this.uint_0 = class2.UInt32_0;
		}
		else if (this.bool_8)
		{
			class2 = new Class64(this.gclass43_0);
		}
		if (class2 != null)
		{
			nameValueCollection_["Authorization"] = class2.ToString();
		}
		if (this.gclass34_0.Count > 0)
		{
			@class.method_2(this.gclass34_0);
		}
		return @class;
	}

	// Token: 0x06000393 RID: 915 RVA: 0x0002BA64 File Offset: 0x00029C64
	private Class27 method_16()
	{
		Class27 @class = Class27.smethod_5();
		NameValueCollection nameValueCollection_ = @class.NameValueCollection_0;
		nameValueCollection_["Sec-WebSocket-Accept"] = GClass25.smethod_2(this.string_0);
		if (this.string_4 != null)
		{
			nameValueCollection_["Sec-WebSocket-Protocol"] = this.string_4;
		}
		if (this.string_1 != null)
		{
			nameValueCollection_["Sec-WebSocket-Extensions"] = this.string_1;
		}
		if (this.gclass34_0.Count > 0)
		{
			@class.method_1(this.gclass34_0);
		}
		return @class;
	}

	// Token: 0x06000394 RID: 916 RVA: 0x000054A0 File Offset: 0x000036A0
	private bool method_17(GClass46 gclass46_1, out string string_7)
	{
		string_7 = null;
		if (this.func_0 == null)
		{
			return true;
		}
		string_7 = this.func_0(gclass46_1);
		return string_7 == null;
	}

	// Token: 0x06000395 RID: 917 RVA: 0x0002BAE4 File Offset: 0x00029CE4
	private GEventArgs4 method_18()
	{
		object obj = this.object_0;
		GEventArgs4 result;
		lock (obj)
		{
			result = ((this.queue_0.Count > 0) ? this.queue_0.Dequeue() : null);
		}
		return result;
	}

	// Token: 0x06000396 RID: 918 RVA: 0x0002BB3C File Offset: 0x00029D3C
	private void method_19()
	{
		this.method_57();
		Class27 @class = this.method_53();
		string text;
		if (!this.method_4(@class, out text))
		{
			throw new GException3(GEnum6.ProtocolError, text);
		}
		if (this.bool_9)
		{
			this.string_4 = @class.NameValueCollection_0["Sec-WebSocket-Protocol"];
		}
		if (this.bool_3)
		{
			this.method_40(@class.NameValueCollection_0["Sec-WebSocket-Extensions"]);
		}
		this.method_33(@class.GClass34_0);
	}

	// Token: 0x06000397 RID: 919 RVA: 0x0002BBB8 File Offset: 0x00029DB8
	private void method_20(GEventArgs4 geventArgs4_0)
	{
		object obj = this.object_0;
		lock (obj)
		{
			this.queue_0.Enqueue(geventArgs4_0);
		}
	}

	// Token: 0x06000398 RID: 920 RVA: 0x0002BC00 File Offset: 0x00029E00
	private void method_21(string string_7, Exception exception_0)
	{
		try
		{
			this.eventHandler_1.smethod_27(this, new GEventArgs3(string_7, exception_0));
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
	}

	// Token: 0x06000399 RID: 921 RVA: 0x0002BC5C File Offset: 0x00029E5C
	private void method_22(string string_7, Exception exception_0)
	{
		GEnum6 ushort_ = (exception_0 is GException3) ? ((GException3)exception_0).GEnum6_0 : GEnum6.Abnormal;
		this.method_23(string_7, (ushort)ushort_);
	}

	// Token: 0x0600039A RID: 922 RVA: 0x0002BC8C File Offset: 0x00029E8C
	private void method_23(string string_7, ushort ushort_0)
	{
		Class30 class30_ = new Class30(ushort_0, string_7);
		this.method_7(class30_, !ushort_0.smethod_47(), false, false);
	}

	// Token: 0x0600039B RID: 923 RVA: 0x000054C2 File Offset: 0x000036C2
	private void method_24(string string_7, GEnum6 genum6_0)
	{
		this.method_23(string_7, (ushort)genum6_0);
	}

	// Token: 0x0600039C RID: 924 RVA: 0x000054CC File Offset: 0x000036CC
	private GClass32 method_25()
	{
		if (this.gclass32_0 == null)
		{
			this.gclass32_0 = new GClass32(this.uri_1.DnsSafeHost);
		}
		return this.gclass32_0;
	}

	// Token: 0x0600039D RID: 925 RVA: 0x0002BCB4 File Offset: 0x00029EB4
	private void method_26()
	{
		this.compressionMethod_0 = CompressionMethod.None;
		this.gclass34_0 = new GClass34();
		this.object_1 = new object();
		this.object_2 = new object();
		this.object_3 = new object();
		this.queue_0 = new Queue<GEventArgs4>();
		this.object_0 = ((ICollection)this.queue_0).SyncRoot;
		this.genum8_0 = GEnum8.Connecting;
	}

	// Token: 0x0600039E RID: 926 RVA: 0x0002BD1C File Offset: 0x00029F1C
	private void method_27()
	{
		GEventArgs4 obj = null;
		object obj2 = this.object_0;
		lock (obj2)
		{
			if (!this.bool_7 && this.queue_0.Count != 0)
			{
				if (this.genum8_0 == GEnum8.Open)
				{
					this.bool_7 = true;
					obj = this.queue_0.Dequeue();
					goto IL_5A;
				}
			}
			return;
		}
		IL_5A:
		this.action_1(obj);
	}

	// Token: 0x0600039F RID: 927 RVA: 0x0002BDA0 File Offset: 0x00029FA0
	private void method_28(GEventArgs4 geventArgs4_0)
	{
		for (;;)
		{
			try
			{
				this.eventHandler_2.smethod_27(this, geventArgs4_0);
				goto IL_78;
			}
			catch (Exception ex)
			{
				this.gclass24_0.method_2(ex.ToString());
				this.method_21("An error has occurred during an OnMessage event.", ex);
				goto IL_78;
			}
			object obj;
			bool flag;
			try
			{
				IL_32:
				Monitor.Enter(obj, ref flag);
				if (this.queue_0.Count != 0)
				{
					if (this.genum8_0 == GEnum8.Open)
					{
						geventArgs4_0 = this.queue_0.Dequeue();
						continue;
					}
				}
				this.bool_7 = false;
				break;
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(obj);
				}
			}
			IL_78:
			obj = this.object_0;
			flag = false;
			goto IL_32;
		}
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x0002BE4C File Offset: 0x0002A04C
	private void method_29(GEventArgs4 geventArgs4_0)
	{
		GClass25.Class35 @class = new GClass25.Class35();
		@class.gclass25_0 = this;
		@class.geventArgs4_0 = geventArgs4_0;
		try
		{
			this.eventHandler_2.smethod_27(this, @class.geventArgs4_0);
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.ToString());
			this.method_21("An error has occurred during an OnMessage event.", ex);
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.queue_0.Count != 0)
			{
				if (this.genum8_0 == GEnum8.Open)
				{
					@class.geventArgs4_0 = this.queue_0.Dequeue();
					goto IL_9D;
				}
			}
			this.bool_7 = false;
			return;
		}
		IL_9D:
		ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x0002BF24 File Offset: 0x0002A124
	private void method_30()
	{
		this.bool_7 = true;
		this.method_58();
		try
		{
			this.eventHandler_3.smethod_26(this, EventArgs.Empty);
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.ToString());
			this.method_21("An error has occurred during the OnOpen event.", ex);
		}
		GEventArgs4 obj = null;
		object obj2 = this.object_0;
		lock (obj2)
		{
			if (this.queue_0.Count != 0)
			{
				if (this.genum8_0 == GEnum8.Open)
				{
					obj = this.queue_0.Dequeue();
					goto IL_94;
				}
			}
			this.bool_7 = false;
			return;
		}
		IL_94:
		this.action_1.BeginInvoke(obj, new AsyncCallback(this.method_97), null);
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x0002BFFC File Offset: 0x0002A1FC
	private bool method_31(byte[] byte_1)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			return false;
		}
		ManualResetEvent manualResetEvent = this.manualResetEvent_0;
		if (manualResetEvent == null)
		{
			return false;
		}
		object obj = this.object_1;
		bool result;
		lock (obj)
		{
			try
			{
				manualResetEvent.Reset();
				if (!this.method_50(Enum1.Final, Enum3.Ping, byte_1, false))
				{
					result = false;
				}
				else
				{
					result = manualResetEvent.WaitOne(this.timeSpan_0);
				}
			}
			catch (ObjectDisposedException)
			{
				result = false;
			}
		}
		return result;
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x0002C088 File Offset: 0x0002A288
	private bool method_32(Class42 class42_0)
	{
		Class30 class30_ = class42_0.Class30_0;
		this.method_7(class30_, !class30_.Boolean_0, false, true);
		return false;
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x000054F2 File Offset: 0x000036F2
	private void method_33(GClass34 gclass34_1)
	{
		if (gclass34_1.Count == 0)
		{
			return;
		}
		this.gclass34_0.method_4(gclass34_1);
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x00005509 File Offset: 0x00003709
	private bool method_34(Class42 class42_0)
	{
		this.method_20(class42_0.Boolean_2 ? new GEventArgs4(class42_0.Enum3_0, class42_0.Class30_0.Byte_0.smethod_23(this.compressionMethod_0)) : new GEventArgs4(class42_0));
		return true;
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x0002C0B0 File Offset: 0x0002A2B0
	private bool method_35(Class42 class42_0)
	{
		if (!this.bool_6)
		{
			if (class42_0.Boolean_3)
			{
				return true;
			}
			this.enum3_0 = class42_0.Enum3_0;
			this.bool_4 = class42_0.Boolean_2;
			this.memoryStream_0 = new MemoryStream();
			this.bool_6 = true;
		}
		this.memoryStream_0.smethod_80(class42_0.Class30_0.Byte_0, 1024);
		if (class42_0.Boolean_6)
		{
			using (this.memoryStream_0)
			{
				byte[] byte_ = this.bool_4 ? this.memoryStream_0.smethod_25(this.compressionMethod_0) : this.memoryStream_0.ToArray();
				this.method_20(new GEventArgs4(this.enum3_0, byte_));
			}
			this.memoryStream_0 = null;
			this.bool_6 = false;
		}
		return true;
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x0002C188 File Offset: 0x0002A388
	private bool method_36(Class42 class42_0)
	{
		this.gclass24_0.method_5("A ping was received.");
		Class42 @class = Class42.smethod_16(class42_0.Class30_0, this.bool_0);
		object obj = this.object_3;
		lock (obj)
		{
			if (this.genum8_0 != GEnum8.Open)
			{
				this.gclass24_0.method_2("The connection is closing.");
				return true;
			}
			if (!this.method_52(@class.method_3()))
			{
				return false;
			}
		}
		this.gclass24_0.method_5("A pong to this ping has been sent.");
		if (this.bool_1)
		{
			if (this.bool_0)
			{
				@class.method_0();
			}
			this.method_20(new GEventArgs4(class42_0));
		}
		return true;
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x0002C250 File Offset: 0x0002A450
	private bool method_37(Class42 class42_0)
	{
		this.gclass24_0.method_5("A pong was received.");
		bool result;
		try
		{
			this.manualResetEvent_0.Set();
			goto IL_78;
		}
		catch (NullReferenceException ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
			result = false;
		}
		catch (ObjectDisposedException ex2)
		{
			this.gclass24_0.method_2(ex2.Message);
			this.gclass24_0.method_1(ex2.ToString());
			result = false;
		}
		return result;
		IL_78:
		this.gclass24_0.method_5("It has been signaled.");
		return true;
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x0002C304 File Offset: 0x0002A504
	private bool method_38(Class42 class42_0)
	{
		string text;
		if (!this.method_5(class42_0, out text))
		{
			throw new GException3(GEnum6.ProtocolError, text);
		}
		class42_0.method_0();
		if (class42_0.Boolean_7)
		{
			return this.method_35(class42_0);
		}
		if (class42_0.Boolean_5)
		{
			return this.method_34(class42_0);
		}
		if (class42_0.Boolean_9)
		{
			return this.method_36(class42_0);
		}
		if (class42_0.Boolean_10)
		{
			return this.method_37(class42_0);
		}
		if (!class42_0.Boolean_1)
		{
			return this.method_42(class42_0);
		}
		return this.method_32(class42_0);
	}

	// Token: 0x060003AA RID: 938 RVA: 0x0002C388 File Offset: 0x0002A588
	private void method_39(string string_7)
	{
		if (string_7 == null)
		{
			return;
		}
		StringBuilder stringBuilder = new StringBuilder(80);
		bool flag = false;
		foreach (string text in string_7.smethod_59(new char[]
		{
			','
		}))
		{
			string text2 = text.Trim();
			if (text2.Length != 0 && !flag && text2.smethod_40(CompressionMethod.Deflate))
			{
				this.compressionMethod_0 = CompressionMethod.Deflate;
				stringBuilder.AppendFormat("{0}, ", this.compressionMethod_0.smethod_62(new string[]
				{
					"client_no_context_takeover",
					"server_no_context_takeover"
				}));
				flag = true;
			}
		}
		int length = stringBuilder.Length;
		if (length <= 2)
		{
			return;
		}
		stringBuilder.Length = length - 2;
		this.string_1 = stringBuilder.ToString();
	}

	// Token: 0x060003AB RID: 939 RVA: 0x00005543 File Offset: 0x00003743
	private void method_40(string string_7)
	{
		if (string_7 == null)
		{
			this.compressionMethod_0 = CompressionMethod.None;
			return;
		}
		this.string_1 = string_7;
	}

	// Token: 0x060003AC RID: 940 RVA: 0x00005557 File Offset: 0x00003757
	private void method_41(IEnumerable<string> ienumerable_0)
	{
		if (ienumerable_0.smethod_17(new Func<string, bool>(this.method_98)))
		{
			return;
		}
		this.string_4 = null;
	}

	// Token: 0x060003AD RID: 941 RVA: 0x00005575 File Offset: 0x00003775
	private bool method_42(Class42 class42_0)
	{
		this.gclass24_0.method_3("An unsupported frame:" + class42_0.method_2(false));
		this.method_24("There is no way to handle it.", GEnum6.PolicyViolation);
		return false;
	}

	// Token: 0x060003AE RID: 942 RVA: 0x0002C45C File Offset: 0x0002A65C
	private void method_43(GEnum6 genum6_0, string string_7)
	{
		this.genum8_0 = GEnum8.Closing;
		Class27 class27_ = this.method_14(GEnum9.BadRequest);
		this.method_55(class27_);
		this.method_47();
		this.genum8_0 = GEnum8.Closed;
		GEventArgs2 gparam_ = new GEventArgs2((ushort)genum6_0, string_7, false);
		try
		{
			this.eventHandler_0.smethod_27(this, gparam_);
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
	}

	// Token: 0x060003AF RID: 943 RVA: 0x000055A6 File Offset: 0x000037A6
	private void method_44()
	{
		if (this.stream_0 != null)
		{
			this.stream_0.Dispose();
			this.stream_0 = null;
		}
		if (this.tcpClient_0 != null)
		{
			this.tcpClient_0.Close();
			this.tcpClient_0 = null;
		}
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x0002C4E8 File Offset: 0x0002A6E8
	private void method_45()
	{
		if (this.memoryStream_0 != null)
		{
			this.memoryStream_0.Dispose();
			this.memoryStream_0 = null;
			this.bool_6 = false;
		}
		if (this.manualResetEvent_0 != null)
		{
			this.manualResetEvent_0.Close();
			this.manualResetEvent_0 = null;
		}
		if (this.manualResetEvent_1 != null)
		{
			this.manualResetEvent_1.Close();
			this.manualResetEvent_1 = null;
		}
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x000055DC File Offset: 0x000037DC
	private void method_46()
	{
		if (this.bool_0)
		{
			this.method_44();
		}
		else
		{
			this.method_47();
		}
		this.method_45();
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x000055FA File Offset: 0x000037FA
	private void method_47()
	{
		if (this.action_0 == null)
		{
			return;
		}
		this.action_0();
		this.action_0 = null;
		this.stream_0 = null;
		this.gclass46_0 = null;
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x0002C54C File Offset: 0x0002A74C
	private bool method_48(Enum3 enum3_1, Stream stream_1)
	{
		object obj = this.object_2;
		bool result;
		lock (obj)
		{
			Stream stream = stream_1;
			bool flag2 = false;
			bool flag3 = false;
			try
			{
				if (this.compressionMethod_0 != CompressionMethod.None)
				{
					stream_1 = stream_1.smethod_12(this.compressionMethod_0);
					flag2 = true;
				}
				if (!(flag3 = this.method_49(enum3_1, stream_1, flag2)))
				{
					this.method_21("A send has been interrupted.", null);
				}
			}
			catch (Exception ex)
			{
				this.gclass24_0.method_2(ex.ToString());
				this.method_21("An error has occurred during a send.", ex);
			}
			finally
			{
				if (flag2)
				{
					stream_1.Dispose();
				}
				stream.Dispose();
			}
			result = flag3;
		}
		return result;
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x0002C614 File Offset: 0x0002A814
	private bool method_49(Enum3 enum3_1, Stream stream_1, bool bool_11)
	{
		long length = stream_1.Length;
		if (length == 0L)
		{
			return this.method_50(Enum1.Final, enum3_1, GClass25.byte_0, false);
		}
		long num = length / (long)GClass25.int_2;
		int num2 = (int)(length % (long)GClass25.int_2);
		byte[] array;
		if (num == 0L)
		{
			array = new byte[num2];
			return stream_1.Read(array, 0, num2) == num2 && this.method_50(Enum1.Final, enum3_1, array, bool_11);
		}
		if (num == 1L && num2 == 0)
		{
			array = new byte[GClass25.int_2];
			return stream_1.Read(array, 0, GClass25.int_2) == GClass25.int_2 && this.method_50(Enum1.Final, enum3_1, array, bool_11);
		}
		array = new byte[GClass25.int_2];
		if (stream_1.Read(array, 0, GClass25.int_2) != GClass25.int_2 || !this.method_50(Enum1.More, enum3_1, array, bool_11))
		{
			return false;
		}
		long num3 = (num2 == 0) ? (num - 2L) : (num - 1L);
		for (long num4 = 0L; num4 < num3; num4 += 1L)
		{
			if (stream_1.Read(array, 0, GClass25.int_2) != GClass25.int_2 || !this.method_50(Enum1.More, Enum3.Cont, array, false))
			{
				return false;
			}
		}
		if (num2 == 0)
		{
			num2 = GClass25.int_2;
		}
		else
		{
			array = new byte[num2];
		}
		return stream_1.Read(array, 0, num2) == num2 && this.method_50(Enum1.Final, Enum3.Cont, array, false);
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x0002C748 File Offset: 0x0002A948
	private bool method_50(Enum1 enum1_0, Enum3 enum3_1, byte[] byte_1, bool bool_11)
	{
		object obj = this.object_3;
		bool result;
		lock (obj)
		{
			if (this.genum8_0 != GEnum8.Open)
			{
				this.gclass24_0.method_2("The connection is closing.");
				result = false;
			}
			else
			{
				Class42 @class = new Class42(enum1_0, enum3_1, byte_1, bool_11, this.bool_0);
				result = this.method_52(@class.method_3());
			}
		}
		return result;
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x0002C7C4 File Offset: 0x0002A9C4
	private void method_51(Enum3 enum3_1, Stream stream_1, Action<bool> action_2)
	{
		GClass25.Class36 @class = new GClass25.Class36();
		@class.action_0 = action_2;
		@class.gclass25_0 = this;
		@class.func_0 = new Func<Enum3, Stream, bool>(this.method_48);
		@class.func_0.BeginInvoke(enum3_1, stream_1, new AsyncCallback(@class.method_0), null);
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x0002C814 File Offset: 0x0002AA14
	private bool method_52(byte[] byte_1)
	{
		bool result;
		try
		{
			this.stream_0.Write(byte_1, 0, byte_1.Length);
			return true;
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
			result = false;
		}
		return result;
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x0002C874 File Offset: 0x0002AA74
	private Class27 method_53()
	{
		Class26 @class = this.method_15();
		Class27 class2 = this.method_54(@class, 90000);
		if (class2.Boolean_3)
		{
			string arg = class2.NameValueCollection_0["WWW-Authenticate"];
			this.gclass24_0.method_6(string.Format("Received an authentication requirement for '{0}'.", arg));
			if (arg.smethod_88())
			{
				this.gclass24_0.method_2("No authentication challenge is specified.");
				return class2;
			}
			this.class63_0 = Class63.smethod_4(arg);
			if (this.class63_0 == null)
			{
				this.gclass24_0.method_2("An invalid authentication challenge is specified.");
				return class2;
			}
			if (this.gclass43_0 != null && (!this.bool_8 || this.class63_0.AuthenticationSchemes_0 == AuthenticationSchemes.Digest))
			{
				if (class2.Boolean_0)
				{
					this.method_44();
					this.method_57();
				}
				Class64 class3 = new Class64(this.class63_0, this.gclass43_0, this.uint_0);
				this.uint_0 = class3.UInt32_0;
				@class.NameValueCollection_0["Authorization"] = class3.ToString();
				class2 = this.method_54(@class, 15000);
			}
		}
		if (class2.Boolean_2)
		{
			string arg2 = class2.NameValueCollection_0["Location"];
			this.gclass24_0.method_6(string.Format("Received a redirection to '{0}'.", arg2));
			if (this.bool_2)
			{
				if (arg2.smethod_88())
				{
					this.gclass24_0.method_2("No url to redirect is located.");
					return class2;
				}
				Uri uri;
				string str;
				if (!arg2.smethod_72(out uri, out str))
				{
					this.gclass24_0.method_2("An invalid url to redirect is located: " + str);
					return class2;
				}
				this.method_44();
				this.uri_1 = uri;
				this.bool_10 = (uri.Scheme == "wss");
				this.method_57();
				return this.method_53();
			}
		}
		return class2;
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x0002CA3C File Offset: 0x0002AC3C
	private Class27 method_54(Class26 class26_0, int int_3)
	{
		this.gclass24_0.method_1("A request to the server:\n" + class26_0.ToString());
		Class27 @class = class26_0.method_1(this.stream_0, int_3);
		this.gclass24_0.method_1("A response to this request:\n" + @class.ToString());
		return @class;
	}

	// Token: 0x060003BA RID: 954 RVA: 0x00005625 File Offset: 0x00003825
	private bool method_55(Class27 class27_0)
	{
		this.gclass24_0.method_1(string.Format("A response to {0}:\n{1}", this.gclass46_0.GClass46.\u202D\u200D\u202A\u200B\u206B\u202E\u206F\u202A\u206C\u206F\u200B\u206C\u202C\u200B\u206A\u206C\u200D\u200D\u202D\u206A\u206B\u206D\u206D\u206C\u206E\u206F\u200C\u206F\u206A\u206E\u206D\u202B\u206B\u206F\u206B\u202C\u206B\u206F\u202A\u206F\u202E, class27_0));
		return this.method_52(class27_0.method_0());
	}

	// Token: 0x060003BB RID: 955 RVA: 0x0002CA94 File Offset: 0x0002AC94
	private void method_56()
	{
		Class26 @class = Class26.smethod_3(this.uri_1);
		Class27 class2 = this.method_54(@class, 90000);
		if (class2.Boolean_1)
		{
			string arg = class2.NameValueCollection_0["Proxy-Authenticate"];
			this.gclass24_0.method_6(string.Format("Received a proxy authentication requirement for '{0}'.", arg));
			if (arg.smethod_88())
			{
				throw new GException3("No proxy authentication challenge is specified.");
			}
			Class63 class3 = Class63.smethod_4(arg);
			if (class3 == null)
			{
				throw new GException3("An invalid proxy authentication challenge is specified.");
			}
			if (this.gclass43_1 != null)
			{
				if (class2.Boolean_0)
				{
					this.method_44();
					this.tcpClient_0 = new TcpClient(this.uri_0.DnsSafeHost, this.uri_0.Port);
					this.stream_0 = this.tcpClient_0.GetStream();
				}
				Class64 class4 = new Class64(class3, this.gclass43_1, 0U);
				@class.NameValueCollection_0["Proxy-Authorization"] = class4.ToString();
				class2 = this.method_54(@class, 15000);
			}
			if (class2.Boolean_1)
			{
				throw new GException3("A proxy authentication is required.");
			}
		}
		if (class2.String_2[0] != '2')
		{
			throw new GException3("The proxy has failed a connection to the requested host and port.");
		}
	}

	// Token: 0x060003BC RID: 956 RVA: 0x0002CBC0 File Offset: 0x0002ADC0
	private void method_57()
	{
		if (this.uri_0 != null)
		{
			this.tcpClient_0 = new TcpClient(this.uri_0.DnsSafeHost, this.uri_0.Port);
			this.stream_0 = this.tcpClient_0.GetStream();
			this.method_56();
		}
		else
		{
			this.tcpClient_0 = new TcpClient(this.uri_1.DnsSafeHost, this.uri_1.Port);
			this.stream_0 = this.tcpClient_0.GetStream();
		}
		if (this.bool_10)
		{
			GClass32 gclass = this.method_25();
			string text = gclass.String_0;
			if (text != this.uri_1.DnsSafeHost)
			{
				throw new GException3(GEnum6.TlsHandshakeFailure, "An invalid host name is specified.");
			}
			try
			{
				SslStream sslStream = new SslStream(this.stream_0, false, gclass.RemoteCertificateValidationCallback_0, gclass.LocalCertificateSelectionCallback_0);
				sslStream.AuthenticateAsClient(text, gclass.X509CertificateCollection_0, gclass.SslProtocols_0, gclass.Boolean_0);
				this.stream_0 = sslStream;
			}
			catch (Exception exception_)
			{
				throw new GException3(GEnum6.TlsHandshakeFailure, exception_);
			}
		}
	}

	// Token: 0x060003BD RID: 957 RVA: 0x0002CCDC File Offset: 0x0002AEDC
	private void method_58()
	{
		GClass25.Class37 @class = new GClass25.Class37();
		@class.gclass25_0 = this;
		if (this.queue_0.Count > 0)
		{
			this.queue_0.Clear();
		}
		this.manualResetEvent_0 = new ManualResetEvent(false);
		this.manualResetEvent_1 = new ManualResetEvent(false);
		@class.action_0 = null;
		@class.action_0 = new Action(@class.method_0);
		@class.action_0();
	}

	// Token: 0x060003BE RID: 958 RVA: 0x00005656 File Offset: 0x00003856
	private bool method_59(string string_7)
	{
		return string_7 != null && string_7 == GClass25.smethod_2(this.string_0);
	}

	// Token: 0x060003BF RID: 959 RVA: 0x0002CD4C File Offset: 0x0002AF4C
	private bool method_60(string string_7)
	{
		if (string_7 == null)
		{
			return true;
		}
		if (string_7.Length == 0)
		{
			return false;
		}
		if (!this.bool_3)
		{
			return false;
		}
		bool flag = this.compressionMethod_0 > CompressionMethod.None;
		foreach (string text in string_7.smethod_59(new char[]
		{
			','
		}))
		{
			string text2 = text.Trim();
			if (!flag || !text2.smethod_40(this.compressionMethod_0))
			{
				return false;
			}
			GClass25.Class38 @class = new GClass25.Class38();
			if (!text2.Contains("server_no_context_takeover"))
			{
				this.gclass24_0.method_2("The server hasn't sent back 'server_no_context_takeover'.");
				return false;
			}
			if (!text2.Contains("client_no_context_takeover"))
			{
				this.gclass24_0.method_6("The server hasn't sent back 'client_no_context_takeover'.");
			}
			@class.string_0 = this.compressionMethod_0.smethod_62(new string[0]);
			if (text2.smethod_59(new char[]
			{
				';'
			}).smethod_17(new Func<string, bool>(@class.method_0)))
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x0002CE78 File Offset: 0x0002B078
	private bool method_61(string string_7)
	{
		GClass25.Class39 @class = new GClass25.Class39();
		@class.string_0 = string_7;
		if (@class.string_0 == null)
		{
			return !this.bool_9;
		}
		return @class.string_0.Length != 0 && this.bool_9 && this.string_5.smethod_17(new Func<string, bool>(@class.method_0));
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x0000566E File Offset: 0x0000386E
	private bool method_62(string string_7)
	{
		return string_7 == null || string_7 == "13";
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x00005680 File Offset: 0x00003880
	internal void method_63(Class27 class27_0)
	{
		this.genum8_0 = GEnum8.Closing;
		this.method_55(class27_0);
		this.method_47();
		this.genum8_0 = GEnum8.Closed;
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x000056A2 File Offset: 0x000038A2
	internal void method_64(GEnum9 genum9_0)
	{
		this.method_63(this.method_14(genum9_0));
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x0002CED4 File Offset: 0x0002B0D4
	internal void method_65(Class30 class30_0, byte[] byte_1)
	{
		object obj = this.object_3;
		lock (obj)
		{
			if (this.genum8_0 == GEnum8.Closing)
			{
				this.gclass24_0.method_4("The closing is already in progress.");
				return;
			}
			if (this.genum8_0 == GEnum8.Closed)
			{
				this.gclass24_0.method_4("The connection has already been closed.");
				return;
			}
			this.genum8_0 = GEnum8.Closing;
		}
		this.gclass24_0.method_5("Begin closing the connection.");
		bool flag3;
		bool flag2 = (flag3 = (byte_1 != null && this.method_52(byte_1))) && this.manualResetEvent_1 != null && this.manualResetEvent_1.WaitOne(this.timeSpan_0);
		bool flag4 = flag3 && flag2;
		this.gclass24_0.method_1(string.Format("Was clean?: {0}\n  sent: {1}\n  received: {2}", flag4, flag3, flag2));
		this.method_47();
		this.method_45();
		this.gclass24_0.method_5("End closing the connection.");
		this.genum8_0 = GEnum8.Closed;
		GEventArgs2 gparam_ = new GEventArgs2(class30_0, flag4);
		try
		{
			this.eventHandler_0.smethod_27(this, gparam_);
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_2(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
		}
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x0002D044 File Offset: 0x0002B244
	internal static string smethod_1()
	{
		byte[] array = new byte[16];
		GClass25.randomNumberGenerator_0.GetBytes(array);
		return Convert.ToBase64String(array);
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x0002D06C File Offset: 0x0002B26C
	internal static string smethod_2(string string_7)
	{
		StringBuilder stringBuilder = new StringBuilder(string_7, 64);
		stringBuilder.Append("258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
		return Convert.ToBase64String(new SHA1CryptoServiceProvider().ComputeHash(stringBuilder.ToString().smethod_35()));
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x0002D0A8 File Offset: 0x0002B2A8
	internal void method_66()
	{
		try
		{
			if (!this.method_1())
			{
				return;
			}
		}
		catch (Exception ex)
		{
			this.gclass24_0.method_3(ex.Message);
			this.gclass24_0.method_1(ex.ToString());
			string string_ = "An exception has occurred while attempting to accept.";
			this.method_22(string_, ex);
			return;
		}
		this.genum8_0 = GEnum8.Open;
		this.method_30();
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x0002D118 File Offset: 0x0002B318
	internal bool method_67(byte[] byte_1, TimeSpan timeSpan_1)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			return false;
		}
		ManualResetEvent manualResetEvent = this.manualResetEvent_0;
		if (manualResetEvent == null)
		{
			return false;
		}
		object obj = this.object_1;
		bool result;
		lock (obj)
		{
			try
			{
				manualResetEvent.Reset();
				object obj2 = this.object_3;
				lock (obj2)
				{
					if (this.genum8_0 != GEnum8.Open)
					{
						return false;
					}
					if (!this.method_52(byte_1))
					{
						return false;
					}
				}
				result = manualResetEvent.WaitOne(timeSpan_1);
			}
			catch (ObjectDisposedException)
			{
				result = false;
			}
		}
		return result;
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x0002D1D8 File Offset: 0x0002B3D8
	internal void method_68(Enum3 enum3_1, byte[] byte_1, Dictionary<CompressionMethod, byte[]> dictionary_0)
	{
		object obj = this.object_2;
		lock (obj)
		{
			object obj2 = this.object_3;
			lock (obj2)
			{
				if (this.genum8_0 != GEnum8.Open)
				{
					this.gclass24_0.method_2("The connection is closing.");
				}
				else
				{
					byte[] array;
					if (!dictionary_0.TryGetValue(this.compressionMethod_0, out array))
					{
						array = new Class42(Enum1.Final, enum3_1, byte_1.smethod_11(this.compressionMethod_0), this.compressionMethod_0 > CompressionMethod.None, false).method_3();
						dictionary_0.Add(this.compressionMethod_0, array);
					}
					this.method_52(array);
				}
			}
		}
	}

	// Token: 0x060003CA RID: 970 RVA: 0x0002D2A4 File Offset: 0x0002B4A4
	internal void method_69(Enum3 enum3_1, Stream stream_1, Dictionary<CompressionMethod, Stream> dictionary_0)
	{
		object obj = this.object_2;
		lock (obj)
		{
			Stream stream;
			if (!dictionary_0.TryGetValue(this.compressionMethod_0, out stream))
			{
				stream = stream_1.smethod_12(this.compressionMethod_0);
				dictionary_0.Add(this.compressionMethod_0, stream);
			}
			else
			{
				stream.Position = 0L;
			}
			this.method_49(enum3_1, stream, this.compressionMethod_0 > CompressionMethod.None);
		}
	}

	// Token: 0x060003CB RID: 971 RVA: 0x0002D324 File Offset: 0x0002B524
	public void method_70()
	{
		if (this.bool_0)
		{
			throw new InvalidOperationException("This instance is a client.");
		}
		if (this.genum8_0 == GEnum8.Closing)
		{
			throw new InvalidOperationException("The close process is in progress.");
		}
		if (this.genum8_0 == GEnum8.Closed)
		{
			throw new InvalidOperationException("The connection has already been closed.");
		}
		if (this.method_0())
		{
			this.method_30();
		}
	}

	// Token: 0x060003CC RID: 972 RVA: 0x0002D380 File Offset: 0x0002B580
	public void method_71()
	{
		GClass25.Class40 @class = new GClass25.Class40();
		@class.gclass25_0 = this;
		if (this.bool_0)
		{
			throw new InvalidOperationException("This instance is a client.");
		}
		if (this.genum8_0 == GEnum8.Closing)
		{
			throw new InvalidOperationException("The close process is in progress.");
		}
		if (this.genum8_0 == GEnum8.Closed)
		{
			throw new InvalidOperationException("The connection has already been closed.");
		}
		@class.func_0 = new Func<bool>(this.method_0);
		@class.func_0.BeginInvoke(new AsyncCallback(@class.method_0), null);
	}

	// Token: 0x060003CD RID: 973 RVA: 0x000056B1 File Offset: 0x000038B1
	public void method_72()
	{
		this.method_6(1005, string.Empty);
	}

	// Token: 0x060003CE RID: 974 RVA: 0x0002D404 File Offset: 0x0002B604
	public void method_73(ushort ushort_0)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (this.bool_0 && ushort_0 == 1011)
		{
			throw new ArgumentException("1011 cannot be used.", "code");
		}
		if (!this.bool_0 && ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		this.method_6(ushort_0, string.Empty);
	}

	// Token: 0x060003CF RID: 975 RVA: 0x0002D478 File Offset: 0x0002B678
	public void method_74(GEnum6 genum6_0)
	{
		if (this.bool_0 && genum6_0 == GEnum6.ServerError)
		{
			throw new ArgumentException("ServerError cannot be used.", "code");
		}
		if (!this.bool_0 && genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		this.method_6((ushort)genum6_0, string.Empty);
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x0002D4D4 File Offset: 0x0002B6D4
	public void method_75(ushort ushort_0, string string_7)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (this.bool_0 && ushort_0 == 1011)
		{
			throw new ArgumentException("1011 cannot be used.", "code");
		}
		if (!this.bool_0 && ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		if (string_7.smethod_88())
		{
			this.method_6(ushort_0, string.Empty);
			return;
		}
		if (ushort_0 == 1005)
		{
			throw new ArgumentException("1005 cannot be used.", "code");
		}
		byte[] array;
		if (!string_7.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
		}
		if (array.Length > 123)
		{
			string message2 = "Its size is greater than 123 bytes.";
			throw new ArgumentOutOfRangeException("reason", message2);
		}
		this.method_6(ushort_0, string_7);
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x0002D5A4 File Offset: 0x0002B7A4
	public void method_76(GEnum6 genum6_0, string string_7)
	{
		if (this.bool_0 && genum6_0 == GEnum6.ServerError)
		{
			throw new ArgumentException("ServerError cannot be used.", "code");
		}
		if (!this.bool_0 && genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		if (string_7.smethod_88())
		{
			this.method_6((ushort)genum6_0, string.Empty);
			return;
		}
		if (genum6_0 == GEnum6.NoStatus)
		{
			throw new ArgumentException("NoStatus cannot be used.", "code");
		}
		byte[] array;
		if (!string_7.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
		}
		if (array.Length > 123)
		{
			string message = "Its size is greater than 123 bytes.";
			throw new ArgumentOutOfRangeException("reason", message);
		}
		this.method_6((ushort)genum6_0, string_7);
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x000056C3 File Offset: 0x000038C3
	public void method_77()
	{
		this.method_8(1005, string.Empty);
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x0002D65C File Offset: 0x0002B85C
	public void method_78(ushort ushort_0)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (this.bool_0 && ushort_0 == 1011)
		{
			throw new ArgumentException("1011 cannot be used.", "code");
		}
		if (!this.bool_0 && ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		this.method_8(ushort_0, string.Empty);
	}

	// Token: 0x060003D4 RID: 980 RVA: 0x0002D6D0 File Offset: 0x0002B8D0
	public void method_79(GEnum6 genum6_0)
	{
		if (this.bool_0 && genum6_0 == GEnum6.ServerError)
		{
			throw new ArgumentException("ServerError cannot be used.", "code");
		}
		if (!this.bool_0 && genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		this.method_8((ushort)genum6_0, string.Empty);
	}

	// Token: 0x060003D5 RID: 981 RVA: 0x0002D72C File Offset: 0x0002B92C
	public void method_80(ushort ushort_0, string string_7)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (this.bool_0 && ushort_0 == 1011)
		{
			throw new ArgumentException("1011 cannot be used.", "code");
		}
		if (!this.bool_0 && ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		if (string_7.smethod_88())
		{
			this.method_8(ushort_0, string.Empty);
			return;
		}
		if (ushort_0 == 1005)
		{
			throw new ArgumentException("1005 cannot be used.", "code");
		}
		byte[] array;
		if (!string_7.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
		}
		if (array.Length > 123)
		{
			string message2 = "Its size is greater than 123 bytes.";
			throw new ArgumentOutOfRangeException("reason", message2);
		}
		this.method_8(ushort_0, string_7);
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x0002D7FC File Offset: 0x0002B9FC
	public void method_81(GEnum6 genum6_0, string string_7)
	{
		if (this.bool_0 && genum6_0 == GEnum6.ServerError)
		{
			throw new ArgumentException("ServerError cannot be used.", "code");
		}
		if (!this.bool_0 && genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		if (string_7.smethod_88())
		{
			this.method_8((ushort)genum6_0, string.Empty);
			return;
		}
		if (genum6_0 == GEnum6.NoStatus)
		{
			throw new ArgumentException("NoStatus cannot be used.", "code");
		}
		byte[] array;
		if (!string_7.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
		}
		if (array.Length > 123)
		{
			string message = "Its size is greater than 123 bytes.";
			throw new ArgumentOutOfRangeException("reason", message);
		}
		this.method_8((ushort)genum6_0, string_7);
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x0002D8B4 File Offset: 0x0002BAB4
	public void method_82()
	{
		if (!this.bool_0)
		{
			throw new InvalidOperationException("This instance is not a client.");
		}
		if (this.genum8_0 == GEnum8.Closing)
		{
			throw new InvalidOperationException("The close process is in progress.");
		}
		if (this.int_1 > GClass25.int_0)
		{
			throw new InvalidOperationException("A series of reconnecting has failed.");
		}
		if (this.method_12())
		{
			this.method_30();
		}
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x0002D910 File Offset: 0x0002BB10
	public void method_83()
	{
		GClass25.Class41 @class = new GClass25.Class41();
		@class.gclass25_0 = this;
		if (!this.bool_0)
		{
			throw new InvalidOperationException("This instance is not a client.");
		}
		if (this.genum8_0 == GEnum8.Closing)
		{
			throw new InvalidOperationException("The close process is in progress.");
		}
		if (this.int_1 > GClass25.int_0)
		{
			throw new InvalidOperationException("A series of reconnecting has failed.");
		}
		@class.func_0 = new Func<bool>(this.method_12);
		@class.func_0.BeginInvoke(new AsyncCallback(@class.method_0), null);
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x000053AD File Offset: 0x000035AD
	public bool method_84()
	{
		return this.method_31(GClass25.byte_0);
	}

	// Token: 0x060003DA RID: 986 RVA: 0x0002D998 File Offset: 0x0002BB98
	public bool method_85(string string_7)
	{
		if (string_7.smethod_88())
		{
			return this.method_31(GClass25.byte_0);
		}
		byte[] array;
		if (!string_7.smethod_74(out array))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "message");
		}
		if (array.Length > 125)
		{
			string message = "Its size is greater than 125 bytes.";
			throw new ArgumentOutOfRangeException("message", message);
		}
		return this.method_31(array);
	}

	// Token: 0x060003DB RID: 987 RVA: 0x000056D5 File Offset: 0x000038D5
	public void method_86(byte[] byte_1)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException("data");
		}
		this.method_48(Enum3.Binary, new MemoryStream(byte_1));
	}

	// Token: 0x060003DC RID: 988 RVA: 0x0002D9F4 File Offset: 0x0002BBF4
	public void method_87(FileInfo fileInfo_0)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (fileInfo_0 == null)
		{
			throw new ArgumentNullException("fileInfo");
		}
		if (!fileInfo_0.Exists)
		{
			throw new ArgumentException("The file does not exist.", "fileInfo");
		}
		FileStream stream_;
		if (!fileInfo_0.smethod_75(out stream_))
		{
			throw new ArgumentException("The file could not be opened.", "fileInfo");
		}
		this.method_48(Enum3.Binary, stream_);
	}

	// Token: 0x060003DD RID: 989 RVA: 0x0002DA60 File Offset: 0x0002BC60
	public void method_88(string string_7)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (string_7 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] buffer;
		if (!string_7.smethod_74(out buffer))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		this.method_48(Enum3.Text, new MemoryStream(buffer));
	}

	// Token: 0x060003DE RID: 990 RVA: 0x0002DABC File Offset: 0x0002BCBC
	public void method_89(Stream stream_1, int int_3)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream_1.CanRead)
		{
			throw new ArgumentException("It cannot be read.", "stream");
		}
		if (int_3 < 1)
		{
			throw new ArgumentException("Less than 1.", "length");
		}
		byte[] array = stream_1.smethod_54(int_3);
		int num = array.Length;
		if (num == 0)
		{
			throw new ArgumentException("No data could be read from it.", "stream");
		}
		if (num < int_3)
		{
			this.gclass24_0.method_6(string.Format("Only {0} byte(s) of data could be read from the stream.", num));
		}
		this.method_48(Enum3.Binary, new MemoryStream(array));
	}

	// Token: 0x060003DF RID: 991 RVA: 0x00005709 File Offset: 0x00003909
	public void method_90(byte[] byte_1, Action<bool> action_2)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException("data");
		}
		this.method_51(Enum3.Binary, new MemoryStream(byte_1), action_2);
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x0002DB68 File Offset: 0x0002BD68
	public void method_91(FileInfo fileInfo_0, Action<bool> action_2)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (fileInfo_0 == null)
		{
			throw new ArgumentNullException("fileInfo");
		}
		if (!fileInfo_0.Exists)
		{
			throw new ArgumentException("The file does not exist.", "fileInfo");
		}
		FileStream stream_;
		if (!fileInfo_0.smethod_75(out stream_))
		{
			throw new ArgumentException("The file could not be opened.", "fileInfo");
		}
		this.method_51(Enum3.Binary, stream_, action_2);
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x0002DBD4 File Offset: 0x0002BDD4
	public void method_92(string string_7, Action<bool> action_2)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (string_7 == null)
		{
			throw new ArgumentNullException("data");
		}
		byte[] buffer;
		if (!string_7.smethod_74(out buffer))
		{
			throw new ArgumentException("It could not be UTF-8-encoded.", "data");
		}
		this.method_51(Enum3.Text, new MemoryStream(buffer), action_2);
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x0002DC30 File Offset: 0x0002BE30
	public void method_93(Stream stream_1, int int_3, Action<bool> action_2)
	{
		if (this.genum8_0 != GEnum8.Open)
		{
			throw new InvalidOperationException("The current state of the connection is not Open.");
		}
		if (stream_1 == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (!stream_1.CanRead)
		{
			throw new ArgumentException("It cannot be read.", "stream");
		}
		if (int_3 < 1)
		{
			throw new ArgumentException("Less than 1.", "length");
		}
		byte[] array = stream_1.smethod_54(int_3);
		int num = array.Length;
		if (num == 0)
		{
			throw new ArgumentException("No data could be read from it.", "stream");
		}
		if (num < int_3)
		{
			this.gclass24_0.method_6(string.Format("Only {0} byte(s) of data could be read from the stream.", num));
		}
		this.method_51(Enum3.Binary, new MemoryStream(array), action_2);
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x0002DCDC File Offset: 0x0002BEDC
	public void method_94(GClass33 gclass33_0)
	{
		string message = null;
		if (!this.bool_0)
		{
			message = "This instance is not a client.";
			throw new InvalidOperationException(message);
		}
		if (gclass33_0 == null)
		{
			throw new ArgumentNullException("cookie");
		}
		if (!this.method_2(out message))
		{
			this.gclass24_0.method_6(message);
			return;
		}
		object obj = this.object_3;
		lock (obj)
		{
			if (this.method_2(out message))
			{
				object obj2 = this.gclass34_0.Object_0;
				lock (obj2)
				{
					this.gclass34_0.method_3(gclass33_0);
					return;
				}
			}
			this.gclass24_0.method_6(message);
		}
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x0002DDA8 File Offset: 0x0002BFA8
	public void method_95(string string_7, string string_8, bool bool_11)
	{
		string message = null;
		if (!this.bool_0)
		{
			message = "This instance is not a client.";
			throw new InvalidOperationException(message);
		}
		if (!string_7.smethod_88() && (string_7.smethod_14(new char[]
		{
			':'
		}) || !string_7.smethod_50()))
		{
			message = "It contains an invalid character.";
			throw new ArgumentException(message, "username");
		}
		if (!string_8.smethod_88() && !string_8.smethod_50())
		{
			message = "It contains an invalid character.";
			throw new ArgumentException(message, "password");
		}
		if (!this.method_2(out message))
		{
			this.gclass24_0.method_6(message);
			return;
		}
		object obj = this.object_3;
		lock (obj)
		{
			if (!this.method_2(out message))
			{
				this.gclass24_0.method_6(message);
			}
			else if (string_7.smethod_88())
			{
				this.gclass43_0 = null;
				this.bool_8 = false;
			}
			else
			{
				this.gclass43_0 = new GClass43(string_7, string_8, this.uri_1.PathAndQuery, new string[0]);
				this.bool_8 = bool_11;
			}
		}
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x0002DEC0 File Offset: 0x0002C0C0
	public void method_96(string string_7, string string_8, string string_9)
	{
		string message = null;
		if (!this.bool_0)
		{
			message = "This instance is not a client.";
			throw new InvalidOperationException(message);
		}
		Uri uri = null;
		if (!string_7.smethod_88())
		{
			if (!Uri.TryCreate(string_7, UriKind.Absolute, out uri))
			{
				message = "Not an absolute URI string.";
				throw new ArgumentException(message, "url");
			}
			if (uri.Scheme != "http")
			{
				message = "The scheme part is not http.";
				throw new ArgumentException(message, "url");
			}
			if (uri.Segments.Length > 1)
			{
				message = "It includes the path segments.";
				throw new ArgumentException(message, "url");
			}
		}
		if (!string_8.smethod_88() && (string_8.smethod_14(new char[]
		{
			':'
		}) || !string_8.smethod_50()))
		{
			message = "It contains an invalid character.";
			throw new ArgumentException(message, "username");
		}
		if (!string_9.smethod_88() && !string_9.smethod_50())
		{
			message = "It contains an invalid character.";
			throw new ArgumentException(message, "password");
		}
		if (!this.method_2(out message))
		{
			this.gclass24_0.method_6(message);
			return;
		}
		object obj = this.object_3;
		lock (obj)
		{
			if (!this.method_2(out message))
			{
				this.gclass24_0.method_6(message);
			}
			else if (string_7.smethod_88())
			{
				this.uri_0 = null;
				this.gclass43_1 = null;
			}
			else
			{
				this.uri_0 = uri;
				this.gclass43_1 = ((!string_8.smethod_88()) ? new GClass43(string_8, string_9, string.Format("{0}:{1}", this.uri_1.DnsSafeHost, this.uri_1.Port), new string[0]) : null);
			}
		}
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x0000573D File Offset: 0x0000393D
	void IDisposable.Dispose()
	{
		this.method_6(1001, string.Empty);
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x0000574F File Offset: 0x0000394F
	[CompilerGenerated]
	private void method_97(IAsyncResult iasyncResult_0)
	{
		this.action_1.EndInvoke(iasyncResult_0);
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x0000575D File Offset: 0x0000395D
	[CompilerGenerated]
	private bool method_98(string string_7)
	{
		return string_7 == this.string_4;
	}

	// Token: 0x040001EC RID: 492
	private Class63 class63_0;

	// Token: 0x040001ED RID: 493
	private string string_0;

	// Token: 0x040001EE RID: 494
	private bool bool_0;

	// Token: 0x040001EF RID: 495
	private Action action_0;

	// Token: 0x040001F0 RID: 496
	private CompressionMethod compressionMethod_0;

	// Token: 0x040001F1 RID: 497
	private GClass46 gclass46_0;

	// Token: 0x040001F2 RID: 498
	private GClass34 gclass34_0;

	// Token: 0x040001F3 RID: 499
	private GClass43 gclass43_0;

	// Token: 0x040001F4 RID: 500
	private bool bool_1;

	// Token: 0x040001F5 RID: 501
	private bool bool_2;

	// Token: 0x040001F6 RID: 502
	private string string_1;

	// Token: 0x040001F7 RID: 503
	private bool bool_3;

	// Token: 0x040001F8 RID: 504
	private object object_0;

	// Token: 0x040001F9 RID: 505
	private object object_1;

	// Token: 0x040001FA RID: 506
	private object object_2;

	// Token: 0x040001FB RID: 507
	private object object_3;

	// Token: 0x040001FC RID: 508
	private MemoryStream memoryStream_0;

	// Token: 0x040001FD RID: 509
	private bool bool_4;

	// Token: 0x040001FE RID: 510
	private Enum3 enum3_0;

	// Token: 0x040001FF RID: 511
	private const string string_2 = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

	// Token: 0x04000200 RID: 512
	private Func<GClass46, string> func_0;

	// Token: 0x04000201 RID: 513
	private bool bool_5;

	// Token: 0x04000202 RID: 514
	private bool bool_6;

	// Token: 0x04000203 RID: 515
	private volatile bool bool_7;

	// Token: 0x04000204 RID: 516
	private volatile GClass24 gclass24_0;

	// Token: 0x04000205 RID: 517
	private static readonly int int_0 = 10;

	// Token: 0x04000206 RID: 518
	private Action<GEventArgs4> action_1;

	// Token: 0x04000207 RID: 519
	private Queue<GEventArgs4> queue_0;

	// Token: 0x04000208 RID: 520
	private uint uint_0;

	// Token: 0x04000209 RID: 521
	private string string_3;

	// Token: 0x0400020A RID: 522
	private ManualResetEvent manualResetEvent_0;

	// Token: 0x0400020B RID: 523
	private bool bool_8;

	// Token: 0x0400020C RID: 524
	private string string_4;

	// Token: 0x0400020D RID: 525
	private string[] string_5;

	// Token: 0x0400020E RID: 526
	private bool bool_9;

	// Token: 0x0400020F RID: 527
	private GClass43 gclass43_1;

	// Token: 0x04000210 RID: 528
	private Uri uri_0;

	// Token: 0x04000211 RID: 529
	private volatile GEnum8 genum8_0;

	// Token: 0x04000212 RID: 530
	private ManualResetEvent manualResetEvent_1;

	// Token: 0x04000213 RID: 531
	private int int_1;

	// Token: 0x04000214 RID: 532
	private bool bool_10;

	// Token: 0x04000215 RID: 533
	private GClass32 gclass32_0;

	// Token: 0x04000216 RID: 534
	private Stream stream_0;

	// Token: 0x04000217 RID: 535
	private TcpClient tcpClient_0;

	// Token: 0x04000218 RID: 536
	private Uri uri_1;

	// Token: 0x04000219 RID: 537
	private const string string_6 = "13";

	// Token: 0x0400021A RID: 538
	private TimeSpan timeSpan_0;

	// Token: 0x0400021B RID: 539
	internal static readonly byte[] byte_0 = new byte[0];

	// Token: 0x0400021C RID: 540
	internal static readonly int int_2 = 1016;

	// Token: 0x0400021D RID: 541
	internal static readonly RandomNumberGenerator randomNumberGenerator_0 = new RNGCryptoServiceProvider();

	// Token: 0x0400021E RID: 542
	[CompilerGenerated]
	private EventHandler<GEventArgs2> eventHandler_0;

	// Token: 0x0400021F RID: 543
	[CompilerGenerated]
	private EventHandler<GEventArgs3> eventHandler_1;

	// Token: 0x04000220 RID: 544
	[CompilerGenerated]
	private EventHandler<GEventArgs4> eventHandler_2;

	// Token: 0x04000221 RID: 545
	[CompilerGenerated]
	private EventHandler eventHandler_3;

	// Token: 0x02000055 RID: 85
	[CompilerGenerated]
	[Serializable]
	private sealed class Class33
	{
		// Token: 0x060003F5 RID: 1013 RVA: 0x000057DA File Offset: 0x000039DA
		internal bool method_0(string string_0)
		{
			return string_0.smethod_88() || !string_0.smethod_51();
		}

		// Token: 0x04000229 RID: 553
		public static readonly GClass25.Class33 <>9 = new GClass25.Class33();

		// Token: 0x0400022A RID: 554
		public static Func<string, bool> <>9__120_0;
	}

	// Token: 0x02000056 RID: 86
	[CompilerGenerated]
	private sealed class Class34
	{
		// Token: 0x060003F7 RID: 1015 RVA: 0x000057EF File Offset: 0x000039EF
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			this.action_0.EndInvoke(iasyncResult_0);
		}

		// Token: 0x0400022B RID: 555
		public Action<Class30, bool, bool, bool> action_0;
	}

	// Token: 0x02000057 RID: 87
	[CompilerGenerated]
	private sealed class Class35
	{
		// Token: 0x060003F9 RID: 1017 RVA: 0x000057FD File Offset: 0x000039FD
		internal void method_0(object object_0)
		{
			this.gclass25_0.method_29(this.geventArgs4_0);
		}

		// Token: 0x0400022C RID: 556
		public GClass25 gclass25_0;

		// Token: 0x0400022D RID: 557
		public GEventArgs4 geventArgs4_0;
	}

	// Token: 0x02000058 RID: 88
	[CompilerGenerated]
	private sealed class Class36
	{
		// Token: 0x060003FB RID: 1019 RVA: 0x0002E1F0 File Offset: 0x0002C3F0
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				bool obj = this.func_0.EndInvoke(iasyncResult_0);
				if (this.action_0 != null)
				{
					this.action_0(obj);
				}
			}
			catch (Exception ex)
			{
				this.gclass25_0.gclass24_0.method_2(ex.ToString());
				this.gclass25_0.method_21("An error has occurred during the callback for an async send.", ex);
			}
		}

		// Token: 0x0400022E RID: 558
		public Func<Enum3, Stream, bool> func_0;

		// Token: 0x0400022F RID: 559
		public Action<bool> action_0;

		// Token: 0x04000230 RID: 560
		public GClass25 gclass25_0;
	}

	// Token: 0x02000059 RID: 89
	[CompilerGenerated]
	private sealed class Class37
	{
		// Token: 0x060003FD RID: 1021 RVA: 0x0002E25C File Offset: 0x0002C45C
		internal void method_0()
		{
			Stream stream_ = this.gclass25_0.stream_0;
			bool bool_ = false;
			Action<Class42> action;
			if ((action = this.action_1) == null)
			{
				action = (this.action_1 = new Action<Class42>(this.method_1));
			}
			Action<Exception> action2;
			if ((action2 = this.action_2) == null)
			{
				action2 = (this.action_2 = new Action<Exception>(this.method_2));
			}
			Class42.smethod_18(stream_, bool_, action, action2);
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0002E2B8 File Offset: 0x0002C4B8
		internal void method_1(Class42 class42_0)
		{
			if (this.gclass25_0.method_38(class42_0))
			{
				if (this.gclass25_0.genum8_0 != GEnum8.Closed)
				{
					this.action_0();
					if (!this.gclass25_0.bool_7 && this.gclass25_0.Boolean_0)
					{
						if (this.gclass25_0.genum8_0 == GEnum8.Open)
						{
							this.gclass25_0.method_27();
							return;
						}
					}
					return;
				}
			}
			ManualResetEvent manualResetEvent_ = this.gclass25_0.manualResetEvent_1;
			if (manualResetEvent_ != null)
			{
				manualResetEvent_.Set();
			}
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00005810 File Offset: 0x00003A10
		internal void method_2(Exception exception_0)
		{
			this.gclass25_0.gclass24_0.method_3(exception_0.ToString());
			this.gclass25_0.method_22("An exception has occurred while receiving.", exception_0);
		}

		// Token: 0x04000231 RID: 561
		public GClass25 gclass25_0;

		// Token: 0x04000232 RID: 562
		public Action action_0;

		// Token: 0x04000233 RID: 563
		public Action<Class42> action_1;

		// Token: 0x04000234 RID: 564
		public Action<Exception> action_2;
	}

	// Token: 0x0200005A RID: 90
	[CompilerGenerated]
	private sealed class Class38
	{
		// Token: 0x06000401 RID: 1025 RVA: 0x0000583B File Offset: 0x00003A3B
		internal bool method_0(string string_1)
		{
			string_1 = string_1.Trim();
			return string_1 != this.string_0 && string_1 != "server_no_context_takeover" && string_1 != "client_no_context_takeover";
		}

		// Token: 0x04000235 RID: 565
		public string string_0;
	}

	// Token: 0x0200005B RID: 91
	[CompilerGenerated]
	private sealed class Class39
	{
		// Token: 0x06000403 RID: 1027 RVA: 0x0000586D File Offset: 0x00003A6D
		internal bool method_0(string string_1)
		{
			return string_1 == this.string_0;
		}

		// Token: 0x04000236 RID: 566
		public string string_0;
	}

	// Token: 0x0200005C RID: 92
	[CompilerGenerated]
	private sealed class Class40
	{
		// Token: 0x06000405 RID: 1029 RVA: 0x0000587B File Offset: 0x00003A7B
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			if (this.func_0.EndInvoke(iasyncResult_0))
			{
				this.gclass25_0.method_30();
			}
		}

		// Token: 0x04000237 RID: 567
		public Func<bool> func_0;

		// Token: 0x04000238 RID: 568
		public GClass25 gclass25_0;
	}

	// Token: 0x0200005D RID: 93
	[CompilerGenerated]
	private sealed class Class41
	{
		// Token: 0x06000407 RID: 1031 RVA: 0x00005896 File Offset: 0x00003A96
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			if (this.func_0.EndInvoke(iasyncResult_0))
			{
				this.gclass25_0.method_30();
			}
		}

		// Token: 0x04000239 RID: 569
		public Func<bool> func_0;

		// Token: 0x0400023A RID: 570
		public GClass25 gclass25_0;
	}
}
