﻿using System;

// Token: 0x020000B5 RID: 181
// (Invoke) Token: 0x060008BA RID: 2234
public delegate void GDelegate0(string Reply);
