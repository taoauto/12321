﻿using System;

// Token: 0x0200010B RID: 267
public abstract class GClass82
{
	// Token: 0x06000D9F RID: 3487
	public abstract string vmethod_0(int int_0);

	// Token: 0x06000DA0 RID: 3488
	public abstract bool vmethod_1(string string_0, out int int_0);
}
