﻿using System;
using System.Windows.Forms;

// Token: 0x02000161 RID: 353
internal class Class144
{
	// Token: 0x04000880 RID: 2176
	public static int int_0 = 204800;

	// Token: 0x04000881 RID: 2177
	public static int int_1 = 30;

	// Token: 0x04000882 RID: 2178
	public static int int_2 = 5;

	// Token: 0x04000883 RID: 2179
	public static int int_3 = 10;

	// Token: 0x04000884 RID: 2180
	public static int int_4 = 64;

	// Token: 0x04000885 RID: 2181
	public static string string_0 = Application.StartupPath + "\\Downloads";

	// Token: 0x04000886 RID: 2182
	public static string string_1 = string.Empty;

	// Token: 0x04000887 RID: 2183
	public static string string_2 = string.Empty;

	// Token: 0x04000888 RID: 2184
	public static string string_3 = string.Empty;

	// Token: 0x04000889 RID: 2185
	public static string string_4 = string.Empty;

	// Token: 0x0400088A RID: 2186
	public static bool bool_0 = false;

	// Token: 0x0400088B RID: 2187
	public static bool bool_1 = false;

	// Token: 0x0400088C RID: 2188
	public static int int_5 = 80;
}
