﻿using System;

// Token: 0x02000038 RID: 56
public enum GEnum6 : ushort
{
	// Token: 0x0400016A RID: 362
	Normal = 1000,
	// Token: 0x0400016B RID: 363
	Away,
	// Token: 0x0400016C RID: 364
	ProtocolError,
	// Token: 0x0400016D RID: 365
	UnsupportedData,
	// Token: 0x0400016E RID: 366
	Undefined,
	// Token: 0x0400016F RID: 367
	NoStatus,
	// Token: 0x04000170 RID: 368
	Abnormal,
	// Token: 0x04000171 RID: 369
	InvalidData,
	// Token: 0x04000172 RID: 370
	PolicyViolation,
	// Token: 0x04000173 RID: 371
	TooBig,
	// Token: 0x04000174 RID: 372
	MandatoryExtension,
	// Token: 0x04000175 RID: 373
	ServerError,
	// Token: 0x04000176 RID: 374
	TlsHandshakeFailure = 1015
}
