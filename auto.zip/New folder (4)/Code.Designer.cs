﻿// Token: 0x020001DC RID: 476
public partial class Code : global::System.Windows.Forms.Form
{
	// Token: 0x0600197A RID: 6522 RVA: 0x000B6D58 File Offset: 0x000B4F58
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Code));
		this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
		this.txtCode = new global::Class85();
		this.btnCode = new global::System.Windows.Forms.Button();
		this.listViewCode = new global::_i.ListViewEx();
		this.columnHeader_0 = new global::System.Windows.Forms.ColumnHeader();
		this.columnHeader_1 = new global::System.Windows.Forms.ColumnHeader();
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		this.panel2 = new global::System.Windows.Forms.Panel();
		this.label3 = new global::System.Windows.Forms.Label();
		this.numericUpDown2 = new global::System.Windows.Forms.NumericUpDown();
		this.label4 = new global::System.Windows.Forms.Label();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.panel2.SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).BeginInit();
		base.SuspendLayout();
		this.splitContainer1.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.splitContainer1.Location = new global::System.Drawing.Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtCode);
		this.splitContainer1.Panel1.Controls.Add(this.btnCode);
		this.splitContainer1.Panel1.Controls.Add(this.panel2);
		this.splitContainer1.Panel2.Controls.Add(this.listViewCode);
		this.splitContainer1.Size = new global::System.Drawing.Size(607, 417);
		this.splitContainer1.SplitterDistance = 297;
		this.splitContainer1.TabIndex = 1;
		this.txtCode.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.txtCode.Location = new global::System.Drawing.Point(0, 0);
		this.txtCode.Multiline = true;
		this.txtCode.Name = "txtCode";
		this.txtCode.Size = new global::System.Drawing.Size(297, 361);
		this.txtCode.TabIndex = 0;
		this.txtCode.String_0 = "Default Watermark...";
		this.txtCode.Color_0 = global::System.Drawing.Color.Gray;
		this.txtCode.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtCode.Color_1 = global::System.Drawing.Color.LightGray;
		this.btnCode.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.btnCode.Location = new global::System.Drawing.Point(0, 361);
		this.btnCode.Name = "btnCode";
		this.btnCode.Size = new global::System.Drawing.Size(297, 23);
		this.btnCode.TabIndex = 1;
		this.btnCode.Text = ">>";
		this.btnCode.UseVisualStyleBackColor = true;
		this.btnCode.Click += new global::System.EventHandler(this.btnCode_Click);
		this.listViewCode.AllowColumnReorder = true;
		this.listViewCode.AllowDrop = true;
		this.listViewCode.AllowReorder = true;
		this.listViewCode.AllowSort = false;
		this.listViewCode.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.listViewCode.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.listViewCode.DoubleClickActivation = false;
		this.listViewCode.FullRowSelect = true;
		this.listViewCode.GridLines = true;
		this.listViewCode.hideItems = (global::System.Collections.Generic.List<global::System.Windows.Forms.ListViewItem>)componentResourceManager.GetObject("listViewCode.hideItems");
		this.listViewCode.HideSelection = false;
		this.listViewCode.LineColor = global::System.Drawing.Color.Red;
		this.listViewCode.Location = new global::System.Drawing.Point(0, 0);
		this.listViewCode.Name = "listViewCode";
		this.listViewCode.Size = new global::System.Drawing.Size(306, 417);
		this.listViewCode.TabIndex = 0;
		this.listViewCode.UseCompatibleStateImageBehavior = false;
		this.listViewCode.View = global::System.Windows.Forms.View.Details;
		this.columnHeader_0.Text = "Code";
		this.columnHeader_0.Width = 170;
		this.columnHeader_1.Text = "Status";
		this.columnHeader_1.Width = 97;
		this.timer_0.Enabled = true;
		this.timer_0.Interval = 5000;
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		this.panel2.Controls.Add(this.label3);
		this.panel2.Controls.Add(this.numericUpDown2);
		this.panel2.Controls.Add(this.label4);
		this.panel2.Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.panel2.Location = new global::System.Drawing.Point(0, 384);
		this.panel2.Name = "panel2";
		this.panel2.Size = new global::System.Drawing.Size(297, 33);
		this.panel2.TabIndex = 2;
		this.label3.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.label3.AutoSize = true;
		this.label3.Location = new global::System.Drawing.Point(106, 8);
		this.label3.Name = "label3";
		this.label3.Size = new global::System.Drawing.Size(12, 13);
		this.label3.TabIndex = 3;
		this.label3.Text = "s";
		this.numericUpDown2.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.numericUpDown2.Location = new global::System.Drawing.Point(49, 6);
		global::System.Windows.Forms.NumericUpDown numericUpDown = this.numericUpDown2;
		int[] array = new int[4];
		array[0] = 1;
		numericUpDown.Minimum = new decimal(array);
		this.numericUpDown2.Name = "numericUpDown2";
		this.numericUpDown2.Size = new global::System.Drawing.Size(51, 20);
		this.numericUpDown2.TabIndex = 2;
		global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.numericUpDown2;
		int[] array2 = new int[4];
		array2[0] = 5;
		numericUpDown2.Value = new decimal(array2);
		this.numericUpDown2.ValueChanged += new global::System.EventHandler(this.numericUpDown2_ValueChanged);
		this.label4.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.label4.AutoSize = true;
		this.label4.Location = new global::System.Drawing.Point(9, 9);
		this.label4.Name = "label4";
		this.label4.Size = new global::System.Drawing.Size(34, 13);
		this.label4.TabIndex = 1;
		this.label4.Text = "Delay";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(607, 417);
		base.Controls.Add(this.splitContainer1);
		base.Name = "Code";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Code";
		base.Load += new global::System.EventHandler(this.Code_Load);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel2.PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x04000EF1 RID: 3825
	private global::System.ComponentModel.IContainer icontainer_0;

	// Token: 0x04000EF2 RID: 3826
	private global::System.Windows.Forms.SplitContainer splitContainer1;

	// Token: 0x04000EF3 RID: 3827
	private global::Class85 txtCode;

	// Token: 0x04000EF4 RID: 3828
	private global::System.Windows.Forms.Button btnCode;

	// Token: 0x04000EF5 RID: 3829
	private global::_i.ListViewEx listViewCode;

	// Token: 0x04000EF6 RID: 3830
	private global::System.Windows.Forms.ColumnHeader columnHeader_0;

	// Token: 0x04000EF7 RID: 3831
	private global::System.Windows.Forms.ColumnHeader columnHeader_1;

	// Token: 0x04000EF8 RID: 3832
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04000EF9 RID: 3833
	private global::System.Windows.Forms.Panel panel2;

	// Token: 0x04000EFA RID: 3834
	private global::System.Windows.Forms.Label label3;

	// Token: 0x04000EFB RID: 3835
	private global::System.Windows.Forms.NumericUpDown numericUpDown2;

	// Token: 0x04000EFC RID: 3836
	private global::System.Windows.Forms.Label label4;
}
