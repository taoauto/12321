﻿using System;
using System.Runtime.Serialization;
using System.Security.Permissions;

// Token: 0x02000088 RID: 136
[Serializable]
public class GException4 : FormatException, ISerializable
{
	// Token: 0x06000642 RID: 1602 RVA: 0x000070E0 File Offset: 0x000052E0
	internal GException4(string string_0) : base(string_0)
	{
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x000070E9 File Offset: 0x000052E9
	internal GException4(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x000070F3 File Offset: 0x000052F3
	protected GException4(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0) : base(serializationInfo_0, streamingContext_0)
	{
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x000070FD File Offset: 0x000052FD
	public GException4()
	{
	}

	// Token: 0x06000646 RID: 1606 RVA: 0x00007105 File Offset: 0x00005305
	[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		base.GetObjectData(info, context);
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x00007105 File Offset: 0x00005305
	[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter, SerializationFormatter = true)]
	void ISerializable.GetObjectData(SerializationInfo serializationInfo, StreamingContext streamingContext)
	{
		base.GetObjectData(serializationInfo, streamingContext);
	}
}
