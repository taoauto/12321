﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001D8 RID: 472
public class CatDoThienCo : UserControl
{
	// Token: 0x06001957 RID: 6487 RVA: 0x000126F6 File Offset: 0x000108F6
	public CatDoThienCo()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001958 RID: 6488 RVA: 0x000B5960 File Offset: 0x000B3B60
	private void CatDoThienCo_Load(object sender, EventArgs e)
	{
		this.txtDropName.Text = Class415.String_10;
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Concat(Class209.IEnumerable_1).Concat(Class209.IEnumerable_1).Select(new Func<string, ListViewItem>(CatDoThienCo.Class215.<>9.method_0)).ToArray<ListViewItem>());
	}

	// Token: 0x06001959 RID: 6489 RVA: 0x000B59D0 File Offset: 0x000B3BD0
	private void method_0()
	{
		foreach (object obj in this.lvName.SelectedItems)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text.Trim() != "")
			{
				bool flag = false;
				string[] array = this.txtDropName.Text.Split(new char[]
				{
					'\n'
				});
				for (int i = 0; i < array.Length; i++)
				{
					if (Class426.smethod_57(array[i]) == Class426.smethod_57(listViewItem.Text))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					this.txtDropName.Text = this.txtDropName.Text.Trim() + "\r\n" + listViewItem.Text;
				}
			}
		}
		this.txtDropName.method_1();
	}

	// Token: 0x0600195A RID: 6490 RVA: 0x00012704 File Offset: 0x00010904
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x0600195B RID: 6491 RVA: 0x00012704 File Offset: 0x00010904
	private void menuAddName_Click(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x0600195C RID: 6492 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x0600195D RID: 6493 RVA: 0x0001270C File Offset: 0x0001090C
	private void txtSearchName_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearchName.Text);
	}

	// Token: 0x0600195E RID: 6494 RVA: 0x000B5AD0 File Offset: 0x000B3CD0
	private void txtDropName_TextChanged(object sender, EventArgs e)
	{
		Class415.String_10 = this.txtDropName.Text;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			keyValuePair.Value.method_365();
		}
	}

	// Token: 0x0600195F RID: 6495 RVA: 0x00012725 File Offset: 0x00010925
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001960 RID: 6496 RVA: 0x000B5B38 File Offset: 0x000B3D38
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(CatDoThienCo));
		this.columnHeader_0 = new ColumnHeader();
		this.lvName = new ListViewEx();
		this.menuName = new ContextMenuStrip(this.icontainer_0);
		this.menuAddName = new ToolStripMenuItem();
		this.txtDropName = new Class85();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.splitContainer1 = new SplitContainer();
		this.txtSearchName = new Class85();
		this.menuName.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		base.SuspendLayout();
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 200;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.ContextMenuStrip = this.menuName;
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(245, 352);
		this.lvName.TabIndex = 15;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.menuName.Items.AddRange(new ToolStripItem[]
		{
			this.menuAddName
		});
		this.menuName.Name = "menuName";
		this.menuName.Size = new Size(105, 26);
		this.menuAddName.Name = "menuAddName";
		this.menuAddName.Size = new Size(104, 22);
		this.menuAddName.Text = "Thêm";
		this.menuAddName.Click += this.menuAddName_Click;
		this.txtDropName.Dock = DockStyle.Fill;
		this.txtDropName.Location = new Point(0, 0);
		this.txtDropName.Multiline = true;
		this.txtDropName.Name = "txtDropName";
		this.txtDropName.ScrollBars = ScrollBars.Vertical;
		this.txtDropName.Size = new Size(232, 372);
		this.txtDropName.TabIndex = 13;
		this.txtDropName.String_0 = "";
		this.txtDropName.Color_0 = Color.Gray;
		this.txtDropName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtDropName.Color_1 = Color.LightGray;
		this.txtDropName.TextChanged += this.txtDropName_TextChanged;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.txtDropName);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearchName);
		this.splitContainer1.Size = new Size(481, 372);
		this.splitContainer1.SplitterDistance = 232;
		this.splitContainer1.TabIndex = 0;
		this.txtSearchName.Dock = DockStyle.Top;
		this.txtSearchName.Location = new Point(0, 0);
		this.txtSearchName.Name = "txtSearchName";
		this.txtSearchName.Size = new Size(245, 20);
		this.txtSearchName.TabIndex = 8;
		this.txtSearchName.String_0 = "Search...";
		this.txtSearchName.Color_0 = Color.Gray;
		this.txtSearchName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearchName.Color_1 = Color.LightGray;
		this.txtSearchName.TextChanged += this.txtSearchName_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Name = "CatDoThienCo";
		base.Size = new Size(481, 372);
		base.Tag = "Cất Đồ Thiên Cơ";
		base.Load += this.CatDoThienCo_Load;
		this.menuName.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.PerformLayout();
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000ED5 RID: 3797
	private IContainer icontainer_0;

	// Token: 0x04000ED6 RID: 3798
	private ToolTip toolTip_0;

	// Token: 0x04000ED7 RID: 3799
	private ColumnHeader columnHeader_0;

	// Token: 0x04000ED8 RID: 3800
	private ListViewEx lvName;

	// Token: 0x04000ED9 RID: 3801
	private ContextMenuStrip menuName;

	// Token: 0x04000EDA RID: 3802
	private ToolStripMenuItem menuAddName;

	// Token: 0x04000EDB RID: 3803
	private Class85 txtDropName;

	// Token: 0x04000EDC RID: 3804
	private SplitContainer splitContainer1;

	// Token: 0x04000EDD RID: 3805
	private Class85 txtSearchName;

	// Token: 0x020001D9 RID: 473
	[CompilerGenerated]
	[Serializable]
	private sealed class Class215
	{
		// Token: 0x06001963 RID: 6499 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x04000EDE RID: 3806
		public static readonly CatDoThienCo.Class215 <>9 = new CatDoThienCo.Class215();

		// Token: 0x04000EDF RID: 3807
		public static Func<string, ListViewItem> <>9__1_0;
	}
}
