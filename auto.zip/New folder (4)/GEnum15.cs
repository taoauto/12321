﻿using System;

// Token: 0x020000F4 RID: 244
public enum GEnum15
{
	// Token: 0x040005E9 RID: 1513
	None,
	// Token: 0x040005EA RID: 1514
	Single,
	// Token: 0x040005EB RID: 1515
	Shadow
}
