﻿using System;

// Token: 0x02000321 RID: 801
internal class Class444
{
	// Token: 0x17000AA7 RID: 2727
	// (get) Token: 0x06002E02 RID: 11778 RVA: 0x000216EF File Offset: 0x0001F8EF
	public static string String_0
	{
		get
		{
			return "Vân Phù";
		}
	}

	// Token: 0x04001F7F RID: 8063
	private static int int_0 = Class365.Int32_130;

	// Token: 0x04001F80 RID: 8064
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 135U,
		Int32_0 = 228,
		Int32_1 = 63,
		Int32_2 = Class444.int_0,
		String_2 = "Lương Thiên Hòa"
	};
}
