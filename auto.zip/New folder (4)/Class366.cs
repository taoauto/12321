﻿using System;

// Token: 0x020002A8 RID: 680
internal class Class366
{
	// Token: 0x1700083F RID: 2111
	// (get) Token: 0x0600262B RID: 9771 RVA: 0x00018904 File Offset: 0x00016B04
	public static int Int32_0
	{
		get
		{
			return 10;
		}
	}

	// Token: 0x17000840 RID: 2112
	// (get) Token: 0x0600262C RID: 9772 RVA: 0x0001C747 File Offset: 0x0001A947
	public static string String_0
	{
		get
		{
			return "Cái Bang Tổng Đà";
		}
	}

	// Token: 0x040019AF RID: 6575
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 54,
		Int32_1 = 86,
		Int32_2 = Class366.Int32_0,
		String_2 = "Lý Nhật Việt"
	};

	// Token: 0x040019B0 RID: 6576
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 23U,
		Int32_0 = 92,
		Int32_1 = 99,
		Int32_2 = Class366.Int32_0,
		String_2 = "Trần Cô Nhạn"
	};

	// Token: 0x040019B1 RID: 6577
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 16U,
		Int32_0 = 92,
		Int32_1 = 77,
		Int32_2 = Class366.Int32_0,
		String_2 = "Hồng Thông"
	};

	// Token: 0x040019B2 RID: 6578
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 94,
		Int32_1 = 99,
		Int32_2 = Class366.Int32_0,
		String_2 = "Hề Tam Kì"
	};
}
