﻿using System;

// Token: 0x0200014A RID: 330
internal class EventArgs2 : EventArgs1
{
	// Token: 0x06001023 RID: 4131 RVA: 0x0000D44E File Offset: 0x0000B64E
	public EventArgs2(Class130 class130_1, Class142 class142_1) : base(class130_1)
	{
		this.class142_0 = class142_1;
	}

	// Token: 0x17000425 RID: 1061
	// (get) Token: 0x06001024 RID: 4132 RVA: 0x0000D45E File Offset: 0x0000B65E
	// (set) Token: 0x06001025 RID: 4133 RVA: 0x0000D466 File Offset: 0x0000B666
	public Class142 Class142_0
	{
		get
		{
			return this.class142_0;
		}
		set
		{
			this.class142_0 = value;
		}
	}

	// Token: 0x0400084C RID: 2124
	private Class142 class142_0;
}
