﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020000F1 RID: 241
public class GEventArgs15 : EventArgs
{
	// Token: 0x06000CAD RID: 3245 RVA: 0x0000B23D File Offset: 0x0000943D
	public GEventArgs15(GStruct2 gstruct2_1, string string_3)
	{
		this.String_0 = string_3;
		this.GStruct2_0 = gstruct2_1;
	}

	// Token: 0x1700035E RID: 862
	// (get) Token: 0x06000CAE RID: 3246 RVA: 0x0000B253 File Offset: 0x00009453
	// (set) Token: 0x06000CAF RID: 3247 RVA: 0x0000B25B File Offset: 0x0000945B
	public GStruct2 GStruct2_0 { get; private set; }

	// Token: 0x1700035F RID: 863
	// (get) Token: 0x06000CB0 RID: 3248 RVA: 0x0000B264 File Offset: 0x00009464
	// (set) Token: 0x06000CB1 RID: 3249 RVA: 0x0000B26C File Offset: 0x0000946C
	public string String_0 { get; private set; }

	// Token: 0x17000360 RID: 864
	// (get) Token: 0x06000CB2 RID: 3250 RVA: 0x0000B275 File Offset: 0x00009475
	// (set) Token: 0x06000CB3 RID: 3251 RVA: 0x0000B27D File Offset: 0x0000947D
	public string String_1 { get; set; }

	// Token: 0x17000361 RID: 865
	// (get) Token: 0x06000CB4 RID: 3252 RVA: 0x0000B286 File Offset: 0x00009486
	// (set) Token: 0x06000CB5 RID: 3253 RVA: 0x0000B28E File Offset: 0x0000948E
	public string String_2 { get; set; }

	// Token: 0x17000362 RID: 866
	// (get) Token: 0x06000CB6 RID: 3254 RVA: 0x0000B297 File Offset: 0x00009497
	// (set) Token: 0x06000CB7 RID: 3255 RVA: 0x0000B29F File Offset: 0x0000949F
	public ToolTipIcon ToolTipIcon_0 { get; set; }

	// Token: 0x040005E1 RID: 1505
	[CompilerGenerated]
	private GStruct2 gstruct2_0;

	// Token: 0x040005E2 RID: 1506
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040005E3 RID: 1507
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040005E4 RID: 1508
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040005E5 RID: 1509
	[CompilerGenerated]
	private ToolTipIcon toolTipIcon_0;
}
