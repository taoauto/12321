﻿using System;

// Token: 0x02000037 RID: 55
public class GEventArgs2 : EventArgs
{
	// Token: 0x06000262 RID: 610 RVA: 0x00004947 File Offset: 0x00002B47
	internal GEventArgs2(Class30 class30_1, bool bool_1)
	{
		this.class30_0 = class30_1;
		this.bool_0 = bool_1;
	}

	// Token: 0x06000263 RID: 611 RVA: 0x0000495D File Offset: 0x00002B5D
	internal GEventArgs2(ushort ushort_0, string string_0, bool bool_1)
	{
		this.class30_0 = new Class30(ushort_0, string_0);
		this.bool_0 = bool_1;
	}

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x06000264 RID: 612 RVA: 0x00004979 File Offset: 0x00002B79
	public ushort UInt16_0
	{
		get
		{
			return this.class30_0.UInt16_0;
		}
	}

	// Token: 0x170000BD RID: 189
	// (get) Token: 0x06000265 RID: 613 RVA: 0x00004986 File Offset: 0x00002B86
	public string String_0
	{
		get
		{
			return this.class30_0.String_0;
		}
	}

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x06000266 RID: 614 RVA: 0x00004993 File Offset: 0x00002B93
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x04000167 RID: 359
	private bool bool_0;

	// Token: 0x04000168 RID: 360
	private Class30 class30_0;
}
