﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

// Token: 0x020001CF RID: 463
internal class Class209
{
	// Token: 0x060018F2 RID: 6386 RVA: 0x000B2FF8 File Offset: 0x000B11F8
	public Class209(Class159 class159_1, uint uint_14)
	{
		this.class159_0 = class159_1;
		this.UInt32_0 = class159_1.Class405_0.method_11(uint_14);
		this.UInt32_1 = class159_1.Class405_0.method_11(this.UInt32_0);
		this.UInt32_3 = class159_1.Class405_0.method_11(this.UInt32_0 + 4U);
		this.UInt32_5 = 1U;
		if (this.UInt32_1 == class159_1.UInt32_3 + 7450148U)
		{
			this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 32U));
			this.String_1 = "Chân Nguyên";
			this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 92U));
		}
		else
		{
			if (this.UInt32_1 != class159_1.Class392_0.UInt32_113)
			{
				if (this.UInt32_1 != class159_1.Class392_0.UInt32_117)
				{
					if (this.UInt32_1 == class159_1.Class392_0.UInt32_114)
					{
						this.UInt32_2 = 2U;
						this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 24U));
						if (class159_1.Class392_0.UInt32_106 == 2U)
						{
							this.UInt32_5 = class159_1.Class405_0.method_13(this.UInt32_0 + 20U, 88U);
						}
						else
						{
							this.UInt32_5 = class159_1.Class405_0.method_13(this.UInt32_0 + 20U, 64U);
						}
						this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 76U));
						this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 20U));
						goto IL_465;
					}
					if (this.UInt32_1 == class159_1.Class392_0.UInt32_115)
					{
						this.UInt32_2 = 3U;
						this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 28U));
						this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 304U));
						this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 20U));
						goto IL_465;
					}
					if (this.UInt32_1 == class159_1.Class392_0.UInt32_116)
					{
						this.UInt32_2 = 4U;
						this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 40U));
						this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 76U));
						this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 72U));
						goto IL_465;
					}
					this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 88U));
					this.UInt32_5 = 1U;
					this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 80U));
					this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 20U));
					goto IL_465;
				}
			}
			this.UInt32_2 = 1U;
			this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 40U));
			this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 88U));
			this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 84U));
			if (string.IsNullOrEmpty(this.String_2))
			{
				this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 64U));
				this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 60U));
			}
		}
		IL_465:
		if (this.UInt32_1 == class159_1.Class392_0.UInt32_118 || string.IsNullOrEmpty(this.String_0))
		{
			this.UInt32_2 = 6U;
			this.String_0 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 44U));
			this.String_1 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 104U));
			this.String_2 = class159_1.Class405_0.method_26(class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 40U));
		}
		this.String_0 = this.String_0.Trim();
		this.String_1 = this.String_1.Trim();
		this.String_2 = this.String_2.Trim();
		if (this.String_2.Contains("Card_Icon"))
		{
			this.String_1 = "Điển Tịch";
		}
		this.UInt32_6 = class159_1.Class405_0.method_11(this.UInt32_0 + 16U);
		if (class159_1.Class392_0.UInt32_106 == 1U)
		{
			this.UInt32_12 = 70U;
		}
		else
		{
			this.UInt32_12 = 94U;
		}
		uint num = class159_1.Class405_0.method_11(this.UInt32_0 + 20U);
		this.UInt32_8 = class159_1.Class405_0.method_12(num + this.UInt32_12);
		this.UInt32_7 = class159_1.Class405_0.method_12(num + this.UInt32_12 + 12U);
		if (this.String_2 == "Cloth2_9" || this.String_2.Contains("Charm") || this.String_2.Contains("CircularTaskTool64_5"))
		{
			if (class159_1.Class392_0.UInt32_106 == 1U)
			{
				this.UInt32_9 = class159_1.Class405_0.method_14(class159_1.Class405_0.method_44(new uint[]
				{
					this.UInt32_0 + 20U,
					56U
				}));
				this.UInt32_10 = class159_1.Class405_0.method_14(num + 58U);
				this.UInt32_11 = class159_1.Class405_0.method_14(num + 60U);
			}
			else
			{
				this.UInt32_9 = class159_1.Class405_0.method_14(class159_1.Class405_0.method_44(new uint[]
				{
					this.UInt32_0 + 20U,
					80U
				}));
				this.UInt32_10 = class159_1.Class405_0.method_14(num + 82U);
				this.UInt32_11 = class159_1.Class405_0.method_14(num + 84U);
			}
		}
		this.UInt32_13 = class159_1.Class405_0.method_17(this.UInt32_0 + 40U, 44U);
		this.Boolean_0 = (class159_1.Class405_0.method_12(num + 13U) == 1U);
		if (this.String_2 == "CircularTaskTool33_6")
		{
			this.Int32_0 = (int)class159_1.Class405_0.method_12(num + 19U);
		}
		if (this.String_1 == "Võ Hồn")
		{
			this.Int32_1 = (int)class159_1.Class405_0.method_12(num + 40U);
		}
	}

	// Token: 0x1700061E RID: 1566
	// (get) Token: 0x060018F3 RID: 6387 RVA: 0x00012253 File Offset: 0x00010453
	public static IEnumerable<string> IEnumerable_0
	{
		get
		{
			return Main.Main_0.IEnumerable_5.SelectMany(new Func<Class159, IEnumerable<string>>(Class209.Class210.<>9.method_0)).Distinct<string>();
		}
	}

	// Token: 0x1700061F RID: 1567
	// (get) Token: 0x060018F4 RID: 6388 RVA: 0x00012288 File Offset: 0x00010488
	public static IEnumerable<string> IEnumerable_1
	{
		get
		{
			return Main.Main_0.IEnumerable_5.SelectMany(new Func<Class159, IEnumerable<string>>(Class209.Class210.<>9.method_2)).Distinct<string>();
		}
	}

	// Token: 0x060018F5 RID: 6389 RVA: 0x000122BD File Offset: 0x000104BD
	public void method_0()
	{
		this.class159_0.method_313(this.String_2, this.UInt32_3);
	}

	// Token: 0x060018F6 RID: 6390 RVA: 0x000122D7 File Offset: 0x000104D7
	public void method_1()
	{
		this.class159_0.method_312(this.String_2, this.UInt32_3);
	}

	// Token: 0x060018F7 RID: 6391 RVA: 0x000B3760 File Offset: 0x000B1960
	public void method_2()
	{
		this.class159_0.method_282("PlayerPackage:UseItem(" + this.UInt32_6.ToString() + ");", false);
	}

	// Token: 0x060018F8 RID: 6392 RVA: 0x000122F1 File Offset: 0x000104F1
	public void method_3()
	{
		this.class159_0.method_58(this.UInt32_0, 117);
	}

	// Token: 0x17000620 RID: 1568
	// (get) Token: 0x060018F9 RID: 6393 RVA: 0x00012306 File Offset: 0x00010506
	// (set) Token: 0x060018FA RID: 6394 RVA: 0x0001230E File Offset: 0x0001050E
	public uint UInt32_0 { get; set; }

	// Token: 0x17000621 RID: 1569
	// (get) Token: 0x060018FB RID: 6395 RVA: 0x00012317 File Offset: 0x00010517
	// (set) Token: 0x060018FC RID: 6396 RVA: 0x0001231F File Offset: 0x0001051F
	public uint UInt32_1 { get; set; }

	// Token: 0x17000622 RID: 1570
	// (get) Token: 0x060018FD RID: 6397 RVA: 0x00012328 File Offset: 0x00010528
	// (set) Token: 0x060018FE RID: 6398 RVA: 0x00012330 File Offset: 0x00010530
	public uint UInt32_2 { get; set; }

	// Token: 0x17000623 RID: 1571
	// (get) Token: 0x060018FF RID: 6399 RVA: 0x00012339 File Offset: 0x00010539
	// (set) Token: 0x06001900 RID: 6400 RVA: 0x00012341 File Offset: 0x00010541
	public uint UInt32_3 { get; set; }

	// Token: 0x17000624 RID: 1572
	// (get) Token: 0x06001901 RID: 6401 RVA: 0x0001234A File Offset: 0x0001054A
	// (set) Token: 0x06001902 RID: 6402 RVA: 0x00012352 File Offset: 0x00010552
	public uint UInt32_4 { get; set; }

	// Token: 0x17000625 RID: 1573
	// (get) Token: 0x06001903 RID: 6403 RVA: 0x0001235B File Offset: 0x0001055B
	// (set) Token: 0x06001904 RID: 6404 RVA: 0x00012363 File Offset: 0x00010563
	public string String_0 { get; set; }

	// Token: 0x17000626 RID: 1574
	// (get) Token: 0x06001905 RID: 6405 RVA: 0x0001236C File Offset: 0x0001056C
	// (set) Token: 0x06001906 RID: 6406 RVA: 0x00012374 File Offset: 0x00010574
	public uint UInt32_5 { get; set; }

	// Token: 0x17000627 RID: 1575
	// (get) Token: 0x06001907 RID: 6407 RVA: 0x0001237D File Offset: 0x0001057D
	// (set) Token: 0x06001908 RID: 6408 RVA: 0x00012385 File Offset: 0x00010585
	public uint UInt32_6 { get; set; }

	// Token: 0x17000628 RID: 1576
	// (get) Token: 0x06001909 RID: 6409 RVA: 0x0001238E File Offset: 0x0001058E
	// (set) Token: 0x0600190A RID: 6410 RVA: 0x00012396 File Offset: 0x00010596
	public string String_1 { get; set; }

	// Token: 0x17000629 RID: 1577
	// (get) Token: 0x0600190B RID: 6411 RVA: 0x0001239F File Offset: 0x0001059F
	// (set) Token: 0x0600190C RID: 6412 RVA: 0x000123A7 File Offset: 0x000105A7
	public uint UInt32_7 { get; set; }

	// Token: 0x1700062A RID: 1578
	// (get) Token: 0x0600190D RID: 6413 RVA: 0x000123B0 File Offset: 0x000105B0
	// (set) Token: 0x0600190E RID: 6414 RVA: 0x000123B8 File Offset: 0x000105B8
	public uint UInt32_8 { get; set; }

	// Token: 0x1700062B RID: 1579
	// (get) Token: 0x0600190F RID: 6415 RVA: 0x000123C1 File Offset: 0x000105C1
	// (set) Token: 0x06001910 RID: 6416 RVA: 0x000123C9 File Offset: 0x000105C9
	public string String_2 { get; set; }

	// Token: 0x1700062C RID: 1580
	// (get) Token: 0x06001911 RID: 6417 RVA: 0x000123D2 File Offset: 0x000105D2
	// (set) Token: 0x06001912 RID: 6418 RVA: 0x000123DA File Offset: 0x000105DA
	public uint UInt32_9 { get; set; } = uint.MaxValue;

	// Token: 0x1700062D RID: 1581
	// (get) Token: 0x06001913 RID: 6419 RVA: 0x000123E3 File Offset: 0x000105E3
	// (set) Token: 0x06001914 RID: 6420 RVA: 0x000123EB File Offset: 0x000105EB
	public uint UInt32_10 { get; set; }

	// Token: 0x1700062E RID: 1582
	// (get) Token: 0x06001915 RID: 6421 RVA: 0x000123F4 File Offset: 0x000105F4
	// (set) Token: 0x06001916 RID: 6422 RVA: 0x000123FC File Offset: 0x000105FC
	public uint UInt32_11 { get; set; }

	// Token: 0x1700062F RID: 1583
	// (get) Token: 0x06001917 RID: 6423 RVA: 0x00012405 File Offset: 0x00010605
	// (set) Token: 0x06001918 RID: 6424 RVA: 0x0001240D File Offset: 0x0001060D
	public uint UInt32_12 { get; set; }

	// Token: 0x17000630 RID: 1584
	// (get) Token: 0x06001919 RID: 6425 RVA: 0x00012416 File Offset: 0x00010616
	public string String_3
	{
		get
		{
			if (this.string_3 == null)
			{
				this.string_3 = this.String_0.smethod_0();
			}
			return this.string_3;
		}
	}

	// Token: 0x17000631 RID: 1585
	// (get) Token: 0x0600191A RID: 6426 RVA: 0x00012437 File Offset: 0x00010637
	// (set) Token: 0x0600191B RID: 6427 RVA: 0x0001243F File Offset: 0x0001063F
	public uint UInt32_13 { get; set; }

	// Token: 0x17000632 RID: 1586
	// (get) Token: 0x0600191C RID: 6428 RVA: 0x00012448 File Offset: 0x00010648
	// (set) Token: 0x0600191D RID: 6429 RVA: 0x00012450 File Offset: 0x00010650
	public int Int32_0 { get; set; }

	// Token: 0x17000633 RID: 1587
	// (get) Token: 0x0600191E RID: 6430 RVA: 0x00012459 File Offset: 0x00010659
	// (set) Token: 0x0600191F RID: 6431 RVA: 0x00012461 File Offset: 0x00010661
	public int Int32_1 { get; set; }

	// Token: 0x17000634 RID: 1588
	// (get) Token: 0x06001920 RID: 6432 RVA: 0x0001246A File Offset: 0x0001066A
	// (set) Token: 0x06001921 RID: 6433 RVA: 0x00012472 File Offset: 0x00010672
	public bool Boolean_0 { get; set; }

	// Token: 0x17000635 RID: 1589
	// (get) Token: 0x06001922 RID: 6434 RVA: 0x0001247B File Offset: 0x0001067B
	public int Int32_2
	{
		get
		{
			return (int)Math.Floor(this.UInt32_6 / 5m) + 1;
		}
	}

	// Token: 0x17000636 RID: 1590
	// (get) Token: 0x06001923 RID: 6435 RVA: 0x0001249F File Offset: 0x0001069F
	public uint UInt32_14
	{
		get
		{
			return this.UInt32_6 % 5U + 1U;
		}
	}

	// Token: 0x17000637 RID: 1591
	// (get) Token: 0x06001924 RID: 6436 RVA: 0x000124AB File Offset: 0x000106AB
	public int Int32_3
	{
		get
		{
			if (this.UInt32_7 != 0U && this.UInt32_8 != 0U)
			{
				return (int)(this.UInt32_13 + (this.UInt32_7 + this.UInt32_8) * 10U);
			}
			return 0;
		}
	}

	// Token: 0x17000638 RID: 1592
	// (get) Token: 0x06001925 RID: 6437 RVA: 0x000B3798 File Offset: 0x000B1998
	public int Int32_4
	{
		get
		{
			if (this.String_2.Contains("Card_Icon_Jinzhuang1"))
			{
				if (this.String_2.EndsWith("_4") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_7") || this.String_2.EndsWith("_9"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_2") || this.String_2.EndsWith("_3") || this.String_2.EndsWith("_8") || this.String_2.EndsWith("_13"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_14") || this.String_2.EndsWith("_15") || this.String_2.EndsWith("_16"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_5") || this.String_2.EndsWith("_10") || this.String_2.EndsWith("_11") || this.String_2.EndsWith("_12"))
				{
					return 4;
				}
			}
			if (this.String_2.Contains("Card_Icon_Mingju1"))
			{
				if (this.String_2.EndsWith("_8") || this.String_2.EndsWith("_9") || this.String_2.EndsWith("_11") || this.String_2.EndsWith("_16"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_3") || this.String_2.EndsWith("_4") || this.String_2.EndsWith("_10") || this.String_2.EndsWith("_13"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_2") || this.String_2.EndsWith("_5") || this.String_2.EndsWith("_7") || this.String_2.EndsWith("_14"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_12") || this.String_2.EndsWith("_15"))
				{
					return 4;
				}
			}
			if (this.String_2.Contains("Card_Icon_Mingshi1"))
			{
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_2") || this.String_2.EndsWith("_4") || this.String_2.EndsWith("_9"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_5") || this.String_2.EndsWith("_7") || this.String_2.EndsWith("_8") || this.String_2.EndsWith("_13"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_10") || this.String_2.EndsWith("_14") || this.String_2.EndsWith("_15") || this.String_2.EndsWith("_16"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_3") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_11") || this.String_2.EndsWith("_12"))
				{
					return 4;
				}
			}
			if (this.String_2.Contains("Card_Icon_Qinggong1"))
			{
				if (this.String_2.EndsWith("_3") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_10") || this.String_2.EndsWith("_16"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_5") || this.String_2.EndsWith("_12") || this.String_2.EndsWith("_15"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_2") || this.String_2.EndsWith("_4") || this.String_2.EndsWith("_8") || this.String_2.EndsWith("_11"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_7") || this.String_2.EndsWith("_9") || this.String_2.EndsWith("_13") || this.String_2.EndsWith("_14"))
				{
					return 4;
				}
			}
			if (this.String_2.Contains("Card_Icon_Shenbing1"))
			{
				if (this.String_2.EndsWith("_2") || this.String_2.EndsWith("_4") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_11"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_3") || this.String_2.EndsWith("_5") || this.String_2.EndsWith("_10") || this.String_2.EndsWith("_16"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_8") || this.String_2.EndsWith("_9") || this.String_2.EndsWith("_13") || this.String_2.EndsWith("_14"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_7") || this.String_2.EndsWith("_12") || this.String_2.EndsWith("_15"))
				{
					return 4;
				}
			}
			if (this.String_2.Contains("Card_Icon_Wujue1"))
			{
				if (this.String_2.EndsWith("_3") || this.String_2.EndsWith("_10") || this.String_2.EndsWith("_12") || this.String_2.EndsWith("_14"))
				{
					return 1;
				}
				if (this.String_2.EndsWith("_4") || this.String_2.EndsWith("_8") || this.String_2.EndsWith("_9") || this.String_2.EndsWith("_13"))
				{
					return 2;
				}
				if (this.String_2.EndsWith("_2") || this.String_2.EndsWith("_11") || this.String_2.EndsWith("_15") || this.String_2.EndsWith("_16"))
				{
					return 3;
				}
				if (this.String_2.EndsWith("_1") || this.String_2.EndsWith("_5") || this.String_2.EndsWith("_6") || this.String_2.EndsWith("_7"))
				{
					return 4;
				}
			}
			return -1;
		}
	}

	// Token: 0x17000639 RID: 1593
	// (get) Token: 0x06001926 RID: 6438 RVA: 0x000124D6 File Offset: 0x000106D6
	public bool Boolean_1
	{
		get
		{
			if (this.class159_0.Class392_0.UInt32_106 == 1U)
			{
				return this.String_4[50] == '1';
			}
			return this.String_4[51] == '1';
		}
	}

	// Token: 0x1700063A RID: 1594
	// (get) Token: 0x06001927 RID: 6439 RVA: 0x000B3FB8 File Offset: 0x000B21B8
	public string String_4
	{
		get
		{
			string text = "";
			for (uint num = 0U; num < 2U; num += 1U)
			{
				uint num2;
				if (this.class159_0.Class392_0.UInt32_106 == 1U)
				{
					num2 = this.class159_0.Class405_0.method_11(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + 84U + num * 4U);
				}
				else
				{
					num2 = this.class159_0.Class405_0.method_11(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + 112U + num * 4U);
				}
				string text2 = Convert.ToString((long)((ulong)num2), 2);
				while (text2.Length < 32)
				{
					text2 = "0" + text2;
				}
				text += text2;
			}
			return text;
		}
	}

	// Token: 0x1700063B RID: 1595
	// (get) Token: 0x06001928 RID: 6440 RVA: 0x000B4080 File Offset: 0x000B2280
	public uint UInt32_15
	{
		get
		{
			if (!this.Boolean_1)
			{
				return 0U;
			}
			uint num = 0U;
			for (int i = 0; i < 32; i++)
			{
				if (this.String_4[i] == '1')
				{
					num += 1U;
				}
			}
			for (int j = 52; j < 64; j++)
			{
				if (this.String_4[j] == '1')
				{
					num += 1U;
				}
			}
			if (this.class159_0.Class392_0.UInt32_106 == 1U)
			{
				return this.class159_0.Class405_0.method_14(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + (110U + num * 2U));
			}
			return this.class159_0.Class405_0.method_14(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + (138U + num * 2U));
		}
	}

	// Token: 0x06001929 RID: 6441 RVA: 0x000B4154 File Offset: 0x000B2354
	public void method_4()
	{
		if (this.class159_0.Class405_0.method_11(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + 13U).ToString("X8").EndsWith("000010") || this.class159_0.Class405_0.method_11(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + 13U).ToString("X8").EndsWith("000011"))
		{
			this.class159_0.Class405_0.method_37(this.class159_0.Class405_0.method_11(this.UInt32_0 + 20U) + 13U, 50);
		}
	}

	// Token: 0x04000EA5 RID: 3749
	private Class159 class159_0;

	// Token: 0x04000EA6 RID: 3750
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04000EA7 RID: 3751
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04000EA8 RID: 3752
	[CompilerGenerated]
	private uint uint_2;

	// Token: 0x04000EA9 RID: 3753
	[CompilerGenerated]
	private uint uint_3;

	// Token: 0x04000EAA RID: 3754
	[CompilerGenerated]
	private uint uint_4;

	// Token: 0x04000EAB RID: 3755
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000EAC RID: 3756
	[CompilerGenerated]
	private uint uint_5;

	// Token: 0x04000EAD RID: 3757
	[CompilerGenerated]
	private uint uint_6;

	// Token: 0x04000EAE RID: 3758
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04000EAF RID: 3759
	[CompilerGenerated]
	private uint uint_7;

	// Token: 0x04000EB0 RID: 3760
	[CompilerGenerated]
	private uint uint_8;

	// Token: 0x04000EB1 RID: 3761
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04000EB2 RID: 3762
	[CompilerGenerated]
	private uint uint_9;

	// Token: 0x04000EB3 RID: 3763
	[CompilerGenerated]
	private uint uint_10;

	// Token: 0x04000EB4 RID: 3764
	[CompilerGenerated]
	private uint uint_11;

	// Token: 0x04000EB5 RID: 3765
	[CompilerGenerated]
	private uint uint_12;

	// Token: 0x04000EB6 RID: 3766
	private string string_3;

	// Token: 0x04000EB7 RID: 3767
	[CompilerGenerated]
	private uint uint_13;

	// Token: 0x04000EB8 RID: 3768
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000EB9 RID: 3769
	[CompilerGenerated]
	private int int_1;

	// Token: 0x04000EBA RID: 3770
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x020001D0 RID: 464
	[CompilerGenerated]
	[Serializable]
	private sealed class Class210
	{
		// Token: 0x0600192C RID: 6444 RVA: 0x000B421C File Offset: 0x000B241C
		internal IEnumerable<string> method_0(Class159 class159_0)
		{
			return class159_0.Class196_0.IEnumerable_0.Concat(class159_0.Class196_0.IEnumerable_4).Select(new Func<Class209, string>(Class209.Class210.<>9.method_1));
		}

		// Token: 0x0600192D RID: 6445 RVA: 0x0001251A File Offset: 0x0001071A
		internal string method_1(Class209 class209_0)
		{
			return class209_0.String_0;
		}

		// Token: 0x0600192E RID: 6446 RVA: 0x000B4268 File Offset: 0x000B2468
		internal IEnumerable<string> method_2(Class159 class159_0)
		{
			return class159_0.Class196_0.IEnumerable_0.Concat(class159_0.Class196_0.IEnumerable_4).Select(new Func<Class209, string>(Class209.Class210.<>9.method_3));
		}

		// Token: 0x0600192F RID: 6447 RVA: 0x00012522 File Offset: 0x00010722
		internal string method_3(Class209 class209_0)
		{
			return class209_0.String_1;
		}

		// Token: 0x04000EBB RID: 3771
		public static readonly Class209.Class210 <>9 = new Class209.Class210();

		// Token: 0x04000EBC RID: 3772
		public static Func<Class209, string> <>9__3_1;

		// Token: 0x04000EBD RID: 3773
		public static Func<Class159, IEnumerable<string>> <>9__3_0;

		// Token: 0x04000EBE RID: 3774
		public static Func<Class209, string> <>9__5_1;

		// Token: 0x04000EBF RID: 3775
		public static Func<Class159, IEnumerable<string>> <>9__5_0;
	}
}
