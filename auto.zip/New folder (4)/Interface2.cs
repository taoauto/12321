﻿using System;

// Token: 0x0200014D RID: 333
internal interface Interface2
{
	// Token: 0x0600102A RID: 4138
	void imethod_0();
}
