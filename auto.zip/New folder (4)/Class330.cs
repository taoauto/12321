﻿using System;
using System.Diagnostics;

// Token: 0x0200027D RID: 637
internal class Class330
{
	// Token: 0x1700076C RID: 1900
	// (get) Token: 0x060023EF RID: 9199 RVA: 0x0001B7A0 File Offset: 0x000199A0
	// (set) Token: 0x060023F0 RID: 9200 RVA: 0x0001B7B8 File Offset: 0x000199B8
	public DateTime DateTime_0
	{
		get
		{
			return this.dateTime_0.Add(this.stopwatch_0.Elapsed);
		}
		set
		{
			this.dateTime_0 = value;
			this.stopwatch_0.Reset();
			this.stopwatch_0.Start();
		}
	}

	// Token: 0x040017AB RID: 6059
	public DateTime dateTime_0;

	// Token: 0x040017AC RID: 6060
	public Stopwatch stopwatch_0 = Stopwatch.StartNew();
}
