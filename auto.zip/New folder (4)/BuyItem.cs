﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000207 RID: 519
internal class BuyItem : UserControl
{
	// Token: 0x06001AE3 RID: 6883 RVA: 0x000137BF File Offset: 0x000119BF
	public BuyItem()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001AE4 RID: 6884 RVA: 0x000CAC88 File Offset: 0x000C8E88
	private void button1_Click(object sender, EventArgs e)
	{
		if (Class426.smethod_43(this.txtNum.Text) <= 0)
		{
			MessageBox.Show(this, "Vui lòng điền số lượng cần mua", "MicroAuto");
			return;
		}
		if (this.txtName.Text.Trim().Length == 0)
		{
			MessageBox.Show(this, "Vui lòng điền tên vật phẩm cần mua", "MicroAuto");
			return;
		}
		bool flag = false;
		foreach (object obj in this.lvBuyName.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text == this.txtName.Text)
			{
				listViewItem.SubItems[1].Text = Class426.smethod_43(this.txtNum.Text).ToString();
				flag = true;
			}
		}
		if (!flag)
		{
			ListViewItem listViewItem2 = new ListViewItem(this.txtName.Text);
			listViewItem2.SubItems.Add(this.txtNum.Text);
			this.lvBuyName.Items.Add(listViewItem2);
		}
		this.method_1();
	}

	// Token: 0x06001AE5 RID: 6885 RVA: 0x000CADBC File Offset: 0x000C8FBC
	private void BuyItem_Load(object sender, EventArgs e)
	{
		this.lvName.Items.AddRange(Class209.IEnumerable_0.Select(new Func<string, ListViewItem>(BuyItem.Class240.<>9.method_0)).ToArray<ListViewItem>());
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Class339("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(this.method_2));
		this.cboPlayer.SelectedIndex = 0;
		this.tabPage2.Controls.Add(new BachBaoCac
		{
			Dock = DockStyle.Fill
		});
	}

	// Token: 0x06001AE6 RID: 6886 RVA: 0x000137CD File Offset: 0x000119CD
	private void lvName_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (this.lvName.SelectedItems.Count > 0)
		{
			this.txtName.Text = this.lvName.SelectedItems[0].Text;
		}
	}

	// Token: 0x06001AE7 RID: 6887 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0(object sender, FormClosingEventArgs e)
	{
	}

	// Token: 0x06001AE8 RID: 6888 RVA: 0x00013803 File Offset: 0x00011A03
	private void lvBuyName_DoubleClick(object sender, EventArgs e)
	{
		while (this.lvBuyName.SelectedItems.Count > 0)
		{
			this.lvBuyName.SelectedItems[0].Remove();
		}
		this.method_1();
	}

	// Token: 0x06001AE9 RID: 6889 RVA: 0x00013837 File Offset: 0x00011A37
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.lvName.Search(this.txtSearch.Text);
	}

	// Token: 0x06001AEA RID: 6890 RVA: 0x000CAE80 File Offset: 0x000C9080
	private void cboPlayer_DropDown(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Class339("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(this.method_3));
	}

	// Token: 0x06001AEB RID: 6891 RVA: 0x000CAEE0 File Offset: 0x000C90E0
	private void method_1()
	{
		string text = "";
		foreach (object obj in this.lvBuyName.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = string.Concat(new string[]
			{
				text,
				listViewItem.Text,
				"|",
				listViewItem.SubItems[1].Text,
				";"
			});
		}
		text = text.Trim(new char[]
		{
			';'
		});
		string string_ = (this.cboPlayer.SelectedItem as Class339).String_0;
		if (string_ == "0000FFFF")
		{
			this.Text = "Mua Đồ - BuyItem - All";
			Class415.String_3 = text;
			return;
		}
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			if (keyValuePair.Value.Class432_0.String_1 == string_)
			{
				Class159 value = keyValuePair.Value;
				this.Text = "Mua Đồ - BuyItem - " + value.Class432_0.String_2;
				value.String_23 = text;
				break;
			}
		}
	}

	// Token: 0x06001AEC RID: 6892 RVA: 0x000CB04C File Offset: 0x000C924C
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.lvBuyName.Items.Clear();
		string string_ = (this.cboPlayer.SelectedItem as Class339).String_0;
		string text = "";
		if (string_ == "0000FFFF")
		{
			this.Text = "Mua Đồ - BuyItem - All";
			text = Class415.String_3;
		}
		else
		{
			foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
			{
				if (keyValuePair.Value.Class432_0.String_1 == string_)
				{
					Class159 value = keyValuePair.Value;
					this.Text = "Mua Đồ - BuyItem - " + value.Class432_0.String_2;
					text = value.String_23;
					break;
				}
			}
		}
		foreach (string text2 in text.Split(new char[]
		{
			';'
		}))
		{
			if (text2.Split(new char[]
			{
				'|'
			}).Length >= 2)
			{
				this.lvBuyName.Items.Add(new ListViewItem(new string[]
				{
					text2.Split(new char[]
					{
						'|'
					})[0],
					text2.Split(new char[]
					{
						'|'
					})[1]
				}));
			}
		}
	}

	// Token: 0x06001AED RID: 6893 RVA: 0x00013850 File Offset: 0x00011A50
	private void lvBuyName_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (this.lvBuyName.SelectedItems.Count > 0)
		{
			this.txtName.Text = this.lvBuyName.SelectedItems[0].Text;
		}
	}

	// Token: 0x06001AEE RID: 6894 RVA: 0x000CB1BC File Offset: 0x000C93BC
	private void lvName_DoubleClick(object sender, EventArgs e)
	{
		if (this.lvName.SelectedItems.Count == 0)
		{
			return;
		}
		this.txtName.Text = this.lvName.SelectedItems[0].Text;
		if (Class426.smethod_43(this.txtNum.Text) <= 0)
		{
			return;
		}
		if (this.txtName.Text.Trim().Length == 0)
		{
			return;
		}
		bool flag = false;
		foreach (object obj in this.lvBuyName.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Text == this.txtName.Text)
			{
				listViewItem.SubItems[1].Text = Class426.smethod_43(this.txtNum.Text).ToString();
				flag = true;
			}
		}
		if (!flag)
		{
			ListViewItem listViewItem2 = new ListViewItem(this.txtName.Text);
			listViewItem2.SubItems.Add(this.txtNum.Text);
			this.lvBuyName.Items.Add(listViewItem2);
		}
		this.method_1();
	}

	// Token: 0x06001AEF RID: 6895 RVA: 0x00013886 File Offset: 0x00011A86
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001AF0 RID: 6896 RVA: 0x000CB304 File Offset: 0x000C9504
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BuyItem));
		this.button1 = new Button();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.txtNum = new Class85();
		this.txtName = new Class85();
		this.lvName = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.lvBuyName = new ListViewEx();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.txtSearch = new Class85();
		this.cboPlayer = new ComboBox();
		this.splitContainer1 = new SplitContainer();
		this.panel1 = new Panel();
		this.tabControlEx1 = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.panel1.SuspendLayout();
		this.tabControlEx1.SuspendLayout();
		this.tabPage1.SuspendLayout();
		base.SuspendLayout();
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 328);
		this.button1.Name = "button1";
		this.button1.Size = new Size(224, 20);
		this.button1.TabIndex = 11;
		this.button1.Text = "Thêm";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.txtNum.Dock = DockStyle.Right;
		this.txtNum.Location = new Point(179, 0);
		this.txtNum.Name = "txtNum";
		this.txtNum.Size = new Size(45, 20);
		this.txtNum.TabIndex = 10;
		this.txtNum.Text = "20";
		this.txtNum.String_0 = "SL";
		this.txtNum.Color_0 = Color.Gray;
		this.txtNum.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtNum.Color_1 = Color.LightGray;
		this.txtName.Dock = DockStyle.Fill;
		this.txtName.Location = new Point(0, 0);
		this.txtName.Name = "txtName";
		this.txtName.Size = new Size(179, 20);
		this.txtName.TabIndex = 9;
		this.txtName.String_0 = "Tên Vật Phẩm Cần Mua";
		this.txtName.Color_0 = Color.Gray;
		this.txtName.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtName.Color_1 = Color.LightGray;
		this.lvName.AllowColumnReorder = true;
		this.lvName.AllowDrop = true;
		this.lvName.AllowReorder = true;
		this.lvName.AllowSort = true;
		this.lvName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvName.Dock = DockStyle.Fill;
		this.lvName.DoubleClickActivation = false;
		this.lvName.FullRowSelect = true;
		this.lvName.GridLines = true;
		this.lvName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvName.hideItems");
		this.lvName.HideSelection = false;
		this.lvName.LineColor = Color.Red;
		this.lvName.Location = new Point(0, 20);
		this.lvName.Name = "lvName";
		this.lvName.Size = new Size(224, 288);
		this.lvName.TabIndex = 8;
		this.lvName.UseCompatibleStateImageBehavior = false;
		this.lvName.View = View.Details;
		this.lvName.SelectedIndexChanged += this.lvName_SelectedIndexChanged;
		this.lvName.DoubleClick += this.lvName_DoubleClick;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 197;
		this.lvBuyName.AllowColumnReorder = true;
		this.lvBuyName.AllowDrop = true;
		this.lvBuyName.AllowReorder = true;
		this.lvBuyName.AllowSort = true;
		this.lvBuyName.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_1,
			this.columnHeader_2
		});
		this.lvBuyName.Dock = DockStyle.Fill;
		this.lvBuyName.DoubleClickActivation = false;
		this.lvBuyName.FullRowSelect = true;
		this.lvBuyName.GridLines = true;
		this.lvBuyName.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvBuyName.hideItems");
		this.lvBuyName.HideSelection = false;
		this.lvBuyName.LineColor = Color.Red;
		this.lvBuyName.Location = new Point(0, 0);
		this.lvBuyName.Name = "lvBuyName";
		this.lvBuyName.Size = new Size(224, 327);
		this.lvBuyName.TabIndex = 7;
		this.lvBuyName.UseCompatibleStateImageBehavior = false;
		this.lvBuyName.View = View.Details;
		this.lvBuyName.SelectedIndexChanged += this.lvBuyName_SelectedIndexChanged;
		this.lvBuyName.DoubleClick += this.lvBuyName_DoubleClick;
		this.columnHeader_1.Text = "Name";
		this.columnHeader_1.Width = 147;
		this.columnHeader_2.Text = "SL";
		this.columnHeader_2.Width = 38;
		this.txtSearch.Dock = DockStyle.Top;
		this.txtSearch.Location = new Point(0, 0);
		this.txtSearch.Name = "txtSearch";
		this.txtSearch.Size = new Size(224, 20);
		this.txtSearch.TabIndex = 15;
		this.txtSearch.String_0 = "Search";
		this.txtSearch.Color_0 = Color.Gray;
		this.txtSearch.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtSearch.Color_1 = Color.LightGray;
		this.txtSearch.TextChanged += this.txtSearch_TextChanged;
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Location = new Point(0, 327);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(224, 21);
		this.cboPlayer.TabIndex = 16;
		this.cboPlayer.DropDown += this.cboPlayer_DropDown;
		this.cboPlayer.SelectedIndexChanged += this.cboPlayer_SelectedIndexChanged;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.Location = new Point(3, 3);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.lvBuyName);
		this.splitContainer1.Panel1.Controls.Add(this.cboPlayer);
		this.splitContainer1.Panel2.Controls.Add(this.lvName);
		this.splitContainer1.Panel2.Controls.Add(this.panel1);
		this.splitContainer1.Panel2.Controls.Add(this.button1);
		this.splitContainer1.Panel2.Controls.Add(this.txtSearch);
		this.splitContainer1.Size = new Size(452, 348);
		this.splitContainer1.SplitterDistance = 224;
		this.splitContainer1.TabIndex = 17;
		this.panel1.Controls.Add(this.txtName);
		this.panel1.Controls.Add(this.txtNum);
		this.panel1.Dock = DockStyle.Bottom;
		this.panel1.Location = new Point(0, 308);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(224, 20);
		this.panel1.TabIndex = 10;
		this.tabControlEx1.TabAlignment_0 = TabAlignment.Top;
		this.tabControlEx1.Controls.Add(this.tabPage1);
		this.tabControlEx1.Controls.Add(this.tabPage2);
		this.tabControlEx1.Dock = DockStyle.Fill;
		this.tabControlEx1.Location = new Point(0, 0);
		this.tabControlEx1.Name = "tabControlEx1";
		this.tabControlEx1.SelectedIndex = 0;
		this.tabControlEx1.Size = new Size(466, 380);
		this.tabControlEx1.TabIndex = 18;
		this.tabPage1.Controls.Add(this.splitContainer1);
		this.tabPage1.Location = new Point(4, 22);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(458, 354);
		this.tabPage1.TabIndex = 0;
		this.tabPage1.Text = "Shop Thường";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Location = new Point(4, 22);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(458, 354);
		this.tabPage2.TabIndex = 1;
		this.tabPage2.Text = "Shop Đặc Biệt";
		this.tabPage2.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.tabControlEx1);
		base.Name = "BuyItem";
		base.Size = new Size(466, 380);
		base.Tag = "Mua Vật Phẩm - Buy Item";
		base.Load += this.BuyItem_Load;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		this.splitContainer1.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		this.tabControlEx1.ResumeLayout(false);
		this.tabPage1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x06001AF1 RID: 6897 RVA: 0x000138A5 File Offset: 0x00011AA5
	[CompilerGenerated]
	private void method_2(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Class339(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x06001AF2 RID: 6898 RVA: 0x000138A5 File Offset: 0x00011AA5
	[CompilerGenerated]
	private void method_3(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Class339(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x040010D8 RID: 4312
	private IContainer icontainer_0;

	// Token: 0x040010D9 RID: 4313
	private ListViewEx lvName;

	// Token: 0x040010DA RID: 4314
	private ColumnHeader columnHeader_0;

	// Token: 0x040010DB RID: 4315
	private ListViewEx lvBuyName;

	// Token: 0x040010DC RID: 4316
	private ColumnHeader columnHeader_1;

	// Token: 0x040010DD RID: 4317
	private ColumnHeader columnHeader_2;

	// Token: 0x040010DE RID: 4318
	private Class85 txtName;

	// Token: 0x040010DF RID: 4319
	private Class85 txtNum;

	// Token: 0x040010E0 RID: 4320
	private Button button1;

	// Token: 0x040010E1 RID: 4321
	private ToolTip toolTip_0;

	// Token: 0x040010E2 RID: 4322
	private Class85 txtSearch;

	// Token: 0x040010E3 RID: 4323
	private ComboBox cboPlayer;

	// Token: 0x040010E4 RID: 4324
	private SplitContainer splitContainer1;

	// Token: 0x040010E5 RID: 4325
	private Panel panel1;

	// Token: 0x040010E6 RID: 4326
	private Control1 tabControlEx1;

	// Token: 0x040010E7 RID: 4327
	private TabPage tabPage1;

	// Token: 0x040010E8 RID: 4328
	private TabPage tabPage2;

	// Token: 0x02000208 RID: 520
	[CompilerGenerated]
	[Serializable]
	private sealed class Class240
	{
		// Token: 0x06001AF5 RID: 6901 RVA: 0x00012750 File Offset: 0x00010950
		internal ListViewItem method_0(string string_0)
		{
			return new ListViewItem(string_0);
		}

		// Token: 0x040010E9 RID: 4329
		public static readonly BuyItem.Class240 <>9 = new BuyItem.Class240();

		// Token: 0x040010EA RID: 4330
		public static Func<string, ListViewItem> <>9__2_0;
	}
}
