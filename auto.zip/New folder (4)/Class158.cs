﻿using System;
using System.Diagnostics;
using System.Threading;

// Token: 0x02000179 RID: 377
internal class Class158 : Class156
{
	// Token: 0x06001217 RID: 4631 RVA: 0x00068778 File Offset: 0x00066978
	public override IntPtr \u206B\u202C\u202C\u206E\u202A\u200F\u206D\u200D\u200B\u206D\u206E\u202D\u202A\u206A\u202B\u202A\u200F\u200E\u200D\u200D\u202E\u206E\u206A\u202D\u206E\u200D\u206A\u200F\u206B\u206B\u202A\u202B\u202E\u206C\u206B\u206C\u206D\u200B\u200B\u202A\u202E(string string_0, IntPtr intptr_0)
	{
		this.vmethod_0();
		IntPtr[] array = this.GClass114.\u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(new string[]
		{
			string_0
		}, intptr_0);
		if (array != null && array[0].smethod_4() && this.vmethod_1() == null)
		{
			this.vmethod_2(new Exception("Module's entry point function reported a failure"));
		}
		if (array != null && array.Length != 0)
		{
			return array[0];
		}
		return IntPtr.Zero;
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x000687D4 File Offset: 0x000669D4
	public override IntPtr[] \u200B\u200F\u206B\u206C\u206E\u200D\u202A\u200E\u202C\u206D\u202A\u200B\u200C\u206E\u202A\u206B\u200E\u206B\u200F\u206C\u200D\u206E\u202C\u200C\u202D\u202A\u206D\u200B\u206C\u200E\u206E\u200D\u206F\u202E\u206C\u200C\u200B\u200E\u206F\u206F\u202E(string[] string_0, IntPtr intptr_0)
	{
		this.vmethod_0();
		IntPtr[] result;
		try
		{
			if (intptr_0.smethod_4() || intptr_0.smethod_2(-1L))
			{
				throw new ArgumentException("Invalid process handle.", "hProcess");
			}
			int processId = GClass120.GetProcessId(intptr_0);
			if (processId == 0)
			{
				throw new ArgumentException("Provided handle doesn't have sufficient permissions to inject", "hProcess");
			}
			Process processById = Process.GetProcessById(processId);
			if (processById.Threads.Count == 0)
			{
				throw new Exception("Target process has no targetable threads to hijack.");
			}
			ProcessThread processThread = Class158.smethod_1(processById);
			IntPtr intptr_ = GClass120.OpenThread(26U, false, processThread.Id);
			if (intptr_.smethod_4() || intptr_.smethod_2(-1L))
			{
				throw new Exception("Unable to obtain a handle for the remote thread.");
			}
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			IntPtr intPtr = this.vmethod_10(string_0, intptr_0, out zero, 1U);
			IntPtr[] array = null;
			if (!intPtr.smethod_4())
			{
				if (GClass120.SuspendThread(intptr_) == 4294967295U)
				{
					throw new Exception("Unable to suspend the remote thread");
				}
				try
				{
					uint num = 0U;
					GClass120.GStruct18 gstruct = new GClass120.GStruct18
					{
						uint_0 = 65537U
					};
					if (!GClass120.GetThreadContext(intptr_, ref gstruct))
					{
						throw new InvalidOperationException("Cannot get the remote thread's context");
					}
					byte[] array2 = Class158.byte_2;
					IntPtr intPtr2 = GClass120.VirtualAllocEx(intptr_0, IntPtr.Zero, (uint)array2.Length, 12288, 64);
					if (intPtr2.smethod_4())
					{
						throw new InvalidOperationException("Unable to allocate memory in the remote process.");
					}
					BitConverter.GetBytes(intPtr.smethod_7(intPtr2.smethod_0(7L)).ToInt32()).CopyTo(array2, 3);
					BitConverter.GetBytes(gstruct.uint_18 - (uint)intPtr2.smethod_0((long)array2.Length).ToInt32()).CopyTo(array2, array2.Length - 4);
					if (!GClass120.WriteProcessMemory(intptr_0, intPtr2, array2, array2.Length, out num) || (ulong)num != (ulong)((long)array2.Length))
					{
						throw new InvalidOperationException("Unable to write stub to the remote process.");
					}
					gstruct.uint_18 = (uint)intPtr2.ToInt32();
					GClass120.SetThreadContext(intptr_, ref gstruct);
				}
				catch (Exception exception_)
				{
					this.vmethod_2(exception_);
					array = null;
					GClass120.VirtualFreeEx(intptr_0, zero, 0, 32768);
					GClass120.VirtualFreeEx(intptr_0, intPtr, 0, 32768);
					GClass120.VirtualFreeEx(intptr_0, zero2, 0, 32768);
				}
				GClass120.ResumeThread(intptr_);
				if (this.vmethod_1() == null)
				{
					Thread.Sleep(100);
					array = new IntPtr[string_0.Length];
					byte[] array3 = GClass120.smethod_4(intptr_0, zero, (uint)((uint)string_0.Length << 2));
					if (array3 != null)
					{
						for (int i = 0; i < array.Length; i++)
						{
							array[i] = GClass119.smethod_3((long)BitConverter.ToInt32(array3, i << 2));
						}
					}
				}
				GClass120.CloseHandle(intptr_);
			}
			result = array;
		}
		catch (Exception exception_)
		{
			this.vmethod_2(exception_);
			result = null;
		}
		return result;
	}

	// Token: 0x06001219 RID: 4633 RVA: 0x0000E510 File Offset: 0x0000C710
	private static ProcessThread smethod_1(Process process_0)
	{
		return process_0.Threads[0];
	}

	// Token: 0x04000986 RID: 2438
	private static readonly byte[] byte_2 = new byte[]
	{
		156,
		96,
		232,
		0,
		0,
		0,
		0,
		97,
		157,
		233,
		0,
		0,
		0,
		0
	};
}
