﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

// Token: 0x02000162 RID: 354
[ToolboxBitmap(typeof(GClass106), "CheckGroupBox.bmp")]
public class GClass106 : GroupBox
{
	// Token: 0x060010C6 RID: 4294 RVA: 0x0005BDC4 File Offset: 0x00059FC4
	public GClass106()
	{
		this.method_0();
		this.bool_0 = true;
		this.m_checkBox.Parent = this;
		this.m_checkBox.Location = new Point(10, 0);
		this.Boolean_0 = true;
		Color color = new VisualStyleRenderer(VisualStyleElement.Button.GroupBox.Normal).GetColor(ColorProperty.TextColor);
		this.m_checkBox.ForeColor = color;
	}

	// Token: 0x17000459 RID: 1113
	// (get) Token: 0x060010C7 RID: 4295 RVA: 0x0000D9A8 File Offset: 0x0000BBA8
	// (set) Token: 0x060010C8 RID: 4296 RVA: 0x0000D9D0 File Offset: 0x0000BBD0
	public virtual string Text
	{
		get
		{
			if (this.Site != null && this.Site.DesignMode)
			{
				return this.m_checkBox.Text;
			}
			return " ";
		}
		set
		{
			base.Text = " ";
			this.m_checkBox.Text = value;
		}
	}

	// Token: 0x1700045A RID: 1114
	// (get) Token: 0x060010C9 RID: 4297 RVA: 0x0000D9E9 File Offset: 0x0000BBE9
	// (set) Token: 0x060010CA RID: 4298 RVA: 0x0000D9F6 File Offset: 0x0000BBF6
	[DefaultValue(true)]
	[Description("Indicates whether the component is checked or not.")]
	[Category("Appearance")]
	public bool Boolean_0
	{
		get
		{
			return this.m_checkBox.Checked;
		}
		set
		{
			if (this.m_checkBox.Checked != value)
			{
				this.m_checkBox.Checked = value;
			}
		}
	}

	// Token: 0x1700045B RID: 1115
	// (get) Token: 0x060010CB RID: 4299 RVA: 0x0000DA12 File Offset: 0x0000BC12
	// (set) Token: 0x060010CC RID: 4300 RVA: 0x0000DA1F File Offset: 0x0000BC1F
	[DefaultValue(CheckState.Checked)]
	[Description("Indicates the state of the component.")]
	[Category("Appearance")]
	public CheckState CheckState_0
	{
		get
		{
			return this.m_checkBox.CheckState;
		}
		set
		{
			if (this.m_checkBox.CheckState != value)
			{
				this.m_checkBox.CheckState = value;
			}
		}
	}

	// Token: 0x1700045C RID: 1116
	// (get) Token: 0x060010CD RID: 4301 RVA: 0x0000DA3B File Offset: 0x0000BC3B
	// (set) Token: 0x060010CE RID: 4302 RVA: 0x0000DA43 File Offset: 0x0000BC43
	[Description("Determines if child controls of the GroupBox are disabled when the CheckBox is unchecked.")]
	[Category("Appearance")]
	[DefaultValue(true)]
	public bool Boolean_1
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			if (this.bool_0 != value)
			{
				this.bool_0 = value;
			}
		}
	}

	// Token: 0x14000047 RID: 71
	// (add) Token: 0x060010CF RID: 4303 RVA: 0x0005BE2C File Offset: 0x0005A02C
	// (remove) Token: 0x060010D0 RID: 4304 RVA: 0x0005BE64 File Offset: 0x0005A064
	[Description("Occurs whenever the Checked property of the CheckBox is changed.")]
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000048 RID: 72
	// (add) Token: 0x060010D1 RID: 4305 RVA: 0x0005BE9C File Offset: 0x0005A09C
	// (remove) Token: 0x060010D2 RID: 4306 RVA: 0x0005BED4 File Offset: 0x0005A0D4
	[Description("Occurs whenever the CheckState property of the CheckBox is changed.")]
	public event EventHandler Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x060010D3 RID: 4307 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_0(EventArgs eventArgs_0)
	{
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x00002E18 File Offset: 0x00001018
	protected virtual void vmethod_1(EventArgs eventArgs_0)
	{
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x0005BF0C File Offset: 0x0005A10C
	private void m_checkBox_CheckedChanged(object sender, EventArgs e)
	{
		if (this.bool_0)
		{
			bool @checked = this.m_checkBox.Checked;
			foreach (object obj in base.Controls)
			{
				Control control = (Control)obj;
				if (control != this.m_checkBox)
				{
					control.Enabled = @checked;
				}
			}
		}
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(sender, e);
		}
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x0000DA55 File Offset: 0x0000BC55
	private void m_checkBox_CheckStateChanged(object sender, EventArgs e)
	{
		if (this.eventHandler_1 != null)
		{
			this.eventHandler_1(sender, e);
		}
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x0000DA6C File Offset: 0x0000BC6C
	private void GClass106_ControlAdded(object sender, ControlEventArgs e)
	{
		if (this.bool_0)
		{
			e.Control.Enabled = this.Boolean_0;
		}
	}

	// Token: 0x060010D8 RID: 4312 RVA: 0x0000DA87 File Offset: 0x0000BC87
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x060010D9 RID: 4313 RVA: 0x0005BF98 File Offset: 0x0005A198
	private void method_0()
	{
		this.m_checkBox = new CheckBox();
		base.SuspendLayout();
		this.m_checkBox.AutoSize = true;
		this.m_checkBox.Checked = true;
		this.m_checkBox.CheckState = CheckState.Checked;
		this.m_checkBox.Location = new Point(0, 0);
		this.m_checkBox.Name = "m_checkBox";
		this.m_checkBox.Size = new Size(104, 24);
		this.m_checkBox.TabIndex = 0;
		this.m_checkBox.Text = "checkBox";
		this.m_checkBox.UseVisualStyleBackColor = true;
		this.m_checkBox.CheckStateChanged += this.m_checkBox_CheckStateChanged;
		this.m_checkBox.CheckedChanged += this.m_checkBox_CheckedChanged;
		base.ControlAdded += this.GClass106_ControlAdded;
		base.ResumeLayout(false);
	}

	// Token: 0x0400088D RID: 2189
	private const int int_0 = 10;

	// Token: 0x0400088E RID: 2190
	private const int int_1 = 0;

	// Token: 0x0400088F RID: 2191
	private bool bool_0;

	// Token: 0x04000890 RID: 2192
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04000891 RID: 2193
	[CompilerGenerated]
	private EventHandler eventHandler_1;

	// Token: 0x04000892 RID: 2194
	private IContainer icontainer_0;

	// Token: 0x04000893 RID: 2195
	private CheckBox m_checkBox;
}
