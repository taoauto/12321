﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000E9 RID: 233
public class GEventArgs12 : EventArgs
{
	// Token: 0x1700034B RID: 843
	// (get) Token: 0x06000C83 RID: 3203 RVA: 0x0000B080 File Offset: 0x00009280
	// (set) Token: 0x06000C84 RID: 3204 RVA: 0x0000B088 File Offset: 0x00009288
	public string String_0 { get; set; }

	// Token: 0x1700034C RID: 844
	// (get) Token: 0x06000C85 RID: 3205 RVA: 0x0000B091 File Offset: 0x00009291
	// (set) Token: 0x06000C86 RID: 3206 RVA: 0x0000B099 File Offset: 0x00009299
	public bool Boolean_0 { get; set; }

	// Token: 0x040005BE RID: 1470
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040005BF RID: 1471
	[CompilerGenerated]
	private bool bool_0;
}
