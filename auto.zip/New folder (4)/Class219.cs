﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020001E0 RID: 480
internal class Class219
{
	// Token: 0x17000642 RID: 1602
	// (get) Token: 0x060019A5 RID: 6565 RVA: 0x00012A14 File Offset: 0x00010C14
	// (set) Token: 0x060019A6 RID: 6566 RVA: 0x00012A1C File Offset: 0x00010C1C
	public string String_0 { get; set; } = string.Empty;

	// Token: 0x17000643 RID: 1603
	// (get) Token: 0x060019A7 RID: 6567 RVA: 0x00012A25 File Offset: 0x00010C25
	// (set) Token: 0x060019A8 RID: 6568 RVA: 0x00012A2D File Offset: 0x00010C2D
	public string String_1 { get; set; } = string.Empty;

	// Token: 0x060019A9 RID: 6569 RVA: 0x00012A36 File Offset: 0x00010C36
	public virtual int GetHashCode()
	{
		return ("[" + this.String_0 + "]" + this.String_1).GetHashCode();
	}

	// Token: 0x060019AA RID: 6570 RVA: 0x00012A58 File Offset: 0x00010C58
	public virtual bool Equals(object obj)
	{
		return obj != null && (obj as Class219).String_0 == this.String_0 && (obj as Class219).String_1 == this.String_1;
	}

	// Token: 0x04000F24 RID: 3876
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000F25 RID: 3877
	[CompilerGenerated]
	private string string_1;
}
