﻿// Token: 0x020001D4 RID: 468
internal partial class BoQuaEx : global::System.Windows.Forms.Form
{
	// Token: 0x06001945 RID: 6469 RVA: 0x000B50D8 File Offset: 0x000B32D8
	private void InitializeComponent()
	{
		this.txtBoQua = new global::Class85();
		base.SuspendLayout();
		this.txtBoQua.Dock = global::System.Windows.Forms.DockStyle.Fill;
		this.txtBoQua.Location = new global::System.Drawing.Point(0, 0);
		this.txtBoQua.Multiline = true;
		this.txtBoQua.Name = "txtBoQua";
		this.txtBoQua.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
		this.txtBoQua.Size = new global::System.Drawing.Size(381, 421);
		this.txtBoQua.TabIndex = 6;
		this.txtBoQua.String_0 = "";
		this.txtBoQua.Color_0 = global::System.Drawing.Color.Gray;
		this.txtBoQua.Font_0 = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.txtBoQua.Color_1 = global::System.Drawing.Color.LightGray;
		this.txtBoQua.TextChanged += new global::System.EventHandler(this.txtBoQua_TextChanged);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(381, 421);
		base.Controls.Add(this.txtBoQua);
		base.Name = "BoQuaEx";
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Tự Động Chặn Khi Có Nội Dung";
		base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.BoQuaEx_FormClosing);
		base.Load += new global::System.EventHandler(this.BoQuaEx_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000ECA RID: 3786
	private global::Class85 txtBoQua;
}
