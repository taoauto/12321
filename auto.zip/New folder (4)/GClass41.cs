﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000098 RID: 152
public sealed class GClass41 : IDisposable
{
	// Token: 0x0600072D RID: 1837 RVA: 0x00007AE8 File Offset: 0x00005CE8
	internal GClass41(GClass38 gclass38_1)
	{
		this.gclass38_0 = gclass38_1;
		this.bool_3 = true;
		this.int_0 = 200;
		this.string_1 = "OK";
		this.version_0 = GClass42.version_1;
	}

	// Token: 0x170001FA RID: 506
	// (get) Token: 0x0600072E RID: 1838 RVA: 0x00007B1F File Offset: 0x00005D1F
	// (set) Token: 0x0600072F RID: 1839 RVA: 0x00007B27 File Offset: 0x00005D27
	internal bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x170001FB RID: 507
	// (get) Token: 0x06000730 RID: 1840 RVA: 0x00037FE0 File Offset: 0x000361E0
	internal GClass45 GClass45_0
	{
		get
		{
			GClass45 gclass = new GClass45(Enum6.Response, true);
			if (this.gclass45_0 != null)
			{
				gclass.Add(this.gclass45_0);
			}
			if (this.string_0 != null)
			{
				gclass.method_6("Content-Type", GClass41.smethod_0(this.string_0, this.encoding_0), true);
			}
			if (gclass["Server"] == null)
			{
				gclass.method_6("Server", "websocket-sharp/1.0", true);
			}
			if (gclass["Date"] == null)
			{
				gclass.method_6("Date", DateTime.UtcNow.ToString("r", CultureInfo.InvariantCulture), true);
			}
			if (this.bool_4)
			{
				gclass.method_6("Transfer-Encoding", "chunked", true);
			}
			else
			{
				gclass.method_6("Content-Length", this.long_0.ToString(CultureInfo.InvariantCulture), true);
			}
			bool flag = !this.gclass38_0.GClass40_0.Boolean_5 || !this.bool_3 || this.int_0 == 400 || this.int_0 == 408 || this.int_0 == 411 || this.int_0 == 413 || this.int_0 == 414 || this.int_0 == 500 || this.int_0 == 503;
			int int32_ = this.gclass38_0.Class70_0.Int32_0;
			if (!flag && int32_ < 100)
			{
				gclass.method_6("Keep-Alive", string.Format("timeout=15,max={0}", 100 - int32_), true);
				if (this.gclass38_0.GClass40_0.Version_0 < GClass42.version_1)
				{
					gclass.method_6("Connection", "keep-alive", true);
				}
			}
			else
			{
				gclass.method_6("Connection", "close", true);
			}
			if (this.uri_0 != null)
			{
				gclass.method_6("Location", this.uri_0.AbsoluteUri, true);
			}
			if (this.gclass34_0 != null)
			{
				foreach (GClass33 gclass2 in this.gclass34_0)
				{
					gclass.method_6("Set-Cookie", gclass2.method_6(), true);
				}
			}
			return gclass;
		}
	}

	// Token: 0x170001FC RID: 508
	// (get) Token: 0x06000731 RID: 1841 RVA: 0x00007B30 File Offset: 0x00005D30
	// (set) Token: 0x06000732 RID: 1842 RVA: 0x00007B38 File Offset: 0x00005D38
	internal bool Boolean_1
	{
		get
		{
			return this.bool_2;
		}
		set
		{
			this.bool_2 = value;
		}
	}

	// Token: 0x170001FD RID: 509
	// (get) Token: 0x06000733 RID: 1843 RVA: 0x00007B41 File Offset: 0x00005D41
	internal string String_0
	{
		get
		{
			return string.Format("HTTP/{0} {1} {2}\r\n", this.version_0, this.int_0, this.string_1);
		}
	}

	// Token: 0x170001FE RID: 510
	// (get) Token: 0x06000734 RID: 1844 RVA: 0x00007B64 File Offset: 0x00005D64
	// (set) Token: 0x06000735 RID: 1845 RVA: 0x00007B6C File Offset: 0x00005D6C
	public Encoding Encoding_0
	{
		get
		{
			return this.encoding_0;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			this.encoding_0 = value;
		}
	}

	// Token: 0x170001FF RID: 511
	// (get) Token: 0x06000736 RID: 1846 RVA: 0x00007BA1 File Offset: 0x00005DA1
	// (set) Token: 0x06000737 RID: 1847 RVA: 0x00038220 File Offset: 0x00036420
	public long Int64_0
	{
		get
		{
			return this.long_0;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value < 0L)
			{
				throw new ArgumentOutOfRangeException("Less than zero.", "value");
			}
			this.long_0 = value;
		}
	}

	// Token: 0x17000200 RID: 512
	// (get) Token: 0x06000738 RID: 1848 RVA: 0x00007BA9 File Offset: 0x00005DA9
	// (set) Token: 0x06000739 RID: 1849 RVA: 0x00038278 File Offset: 0x00036478
	public string String_1
	{
		get
		{
			return this.string_0;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value == null)
			{
				this.string_0 = null;
				return;
			}
			if (value.Length == 0)
			{
				throw new ArgumentException("An empty string.", "value");
			}
			if (!GClass41.smethod_1(value))
			{
				throw new ArgumentException("It contains an invalid character.", "value");
			}
			this.string_0 = value;
		}
	}

	// Token: 0x17000201 RID: 513
	// (get) Token: 0x0600073A RID: 1850 RVA: 0x00007BB1 File Offset: 0x00005DB1
	// (set) Token: 0x0600073B RID: 1851 RVA: 0x00007BCC File Offset: 0x00005DCC
	public GClass34 GClass34_0
	{
		get
		{
			if (this.gclass34_0 == null)
			{
				this.gclass34_0 = new GClass34();
			}
			return this.gclass34_0;
		}
		set
		{
			this.gclass34_0 = value;
		}
	}

	// Token: 0x17000202 RID: 514
	// (get) Token: 0x0600073C RID: 1852 RVA: 0x00007BD5 File Offset: 0x00005DD5
	// (set) Token: 0x0600073D RID: 1853 RVA: 0x00007BF2 File Offset: 0x00005DF2
	public GClass45 GClass45_1
	{
		get
		{
			if (this.gclass45_0 == null)
			{
				this.gclass45_0 = new GClass45(Enum6.Response, false);
			}
			return this.gclass45_0;
		}
		set
		{
			if (value == null)
			{
				this.gclass45_0 = null;
				return;
			}
			if (value.Enum6_0 != Enum6.Response)
			{
				throw new InvalidOperationException("The value is not valid for a response.");
			}
			this.gclass45_0 = value;
		}
	}

	// Token: 0x17000203 RID: 515
	// (get) Token: 0x0600073E RID: 1854 RVA: 0x00007C1A File Offset: 0x00005E1A
	// (set) Token: 0x0600073F RID: 1855 RVA: 0x00007C22 File Offset: 0x00005E22
	public bool Boolean_2
	{
		get
		{
			return this.bool_3;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			this.bool_3 = value;
		}
	}

	// Token: 0x17000204 RID: 516
	// (get) Token: 0x06000740 RID: 1856 RVA: 0x00007C57 File Offset: 0x00005E57
	public Stream Stream_0
	{
		get
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.stream4_0 == null)
			{
				this.stream4_0 = this.gclass38_0.Class70_0.method_14();
			}
			return this.stream4_0;
		}
	}

	// Token: 0x17000205 RID: 517
	// (get) Token: 0x06000741 RID: 1857 RVA: 0x00007C96 File Offset: 0x00005E96
	// (set) Token: 0x06000742 RID: 1858 RVA: 0x000382F4 File Offset: 0x000364F4
	public Version Version_0
	{
		get
		{
			return this.version_0;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (value.Major != 1)
			{
				throw new ArgumentException("Its Major property is not 1.", "value");
			}
			if (value.Minor < 0 || value.Minor > 1)
			{
				throw new ArgumentException("Its Minor property is not 0 or 1.", "value");
			}
			this.version_0 = value;
		}
	}

	// Token: 0x17000206 RID: 518
	// (get) Token: 0x06000743 RID: 1859 RVA: 0x00007C9E File Offset: 0x00005E9E
	// (set) Token: 0x06000744 RID: 1860 RVA: 0x00038384 File Offset: 0x00036584
	public string String_2
	{
		get
		{
			if (!(this.uri_0 != null))
			{
				return null;
			}
			return this.uri_0.OriginalString;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value == null)
			{
				this.uri_0 = null;
				return;
			}
			if (value.Length == 0)
			{
				throw new ArgumentException("An empty string.", "value");
			}
			Uri uri;
			if (!Uri.TryCreate(value, UriKind.Absolute, out uri))
			{
				throw new ArgumentException("Not an absolute URL.", "value");
			}
			this.uri_0 = uri;
		}
	}

	// Token: 0x17000207 RID: 519
	// (get) Token: 0x06000745 RID: 1861 RVA: 0x00007CBB File Offset: 0x00005EBB
	// (set) Token: 0x06000746 RID: 1862 RVA: 0x00007CC3 File Offset: 0x00005EC3
	public bool Boolean_3
	{
		get
		{
			return this.bool_4;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			this.bool_4 = value;
		}
	}

	// Token: 0x17000208 RID: 520
	// (get) Token: 0x06000747 RID: 1863 RVA: 0x00007CF8 File Offset: 0x00005EF8
	// (set) Token: 0x06000748 RID: 1864 RVA: 0x00038404 File Offset: 0x00036604
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value < 100 || value > 999)
			{
				throw new ProtocolViolationException("A value is not between 100 and 999 inclusive.");
			}
			this.int_0 = value;
			this.string_1 = value.smethod_83();
		}
	}

	// Token: 0x17000209 RID: 521
	// (get) Token: 0x06000749 RID: 1865 RVA: 0x00007D00 File Offset: 0x00005F00
	// (set) Token: 0x0600074A RID: 1866 RVA: 0x00038468 File Offset: 0x00036668
	public string String_3
	{
		get
		{
			return this.string_1;
		}
		set
		{
			if (this.bool_1)
			{
				throw new ObjectDisposedException(base.GetType().ToString());
			}
			if (this.bool_2)
			{
				throw new InvalidOperationException("The response is already being sent.");
			}
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (value.Length == 0)
			{
				this.string_1 = this.int_0.smethod_83();
				return;
			}
			if (!GClass41.smethod_2(value))
			{
				throw new ArgumentException("It contains an invalid character.", "value");
			}
			this.string_1 = value;
		}
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x000384E8 File Offset: 0x000366E8
	private bool method_0(GClass33 gclass33_0)
	{
		List<GClass33> list = this.method_3(gclass33_0).smethod_64<GClass33>();
		if (list.Count == 0)
		{
			return true;
		}
		int int32_ = gclass33_0.Int32_2;
		using (List<GClass33>.Enumerator enumerator = list.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.Int32_2 == int32_)
				{
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x00007D08 File Offset: 0x00005F08
	private void method_1(bool bool_5)
	{
		this.bool_1 = true;
		this.gclass38_0.Class70_0.method_10(bool_5);
	}

	// Token: 0x0600074D RID: 1869 RVA: 0x00038560 File Offset: 0x00036760
	private void method_2(byte[] byte_0, int int_1, bool bool_5)
	{
		Stream stream_ = this.Stream_0;
		if (bool_5)
		{
			stream_.smethod_80(byte_0, int_1);
			this.method_1(false);
			return;
		}
		stream_.smethod_81(byte_0, int_1, new Action(this.method_13), null);
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x00007D22 File Offset: 0x00005F22
	private static string smethod_0(string string_2, Encoding encoding_1)
	{
		if (string_2.IndexOf("charset=", StringComparison.Ordinal) > -1)
		{
			return string_2;
		}
		if (encoding_1 == null)
		{
			return string_2;
		}
		return string.Format("{0}; charset={1}", string_2, encoding_1.WebName);
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x00007D4B File Offset: 0x00005F4B
	private IEnumerable<GClass33> method_3(GClass33 gclass33_0)
	{
		goto IL_26;
		IEnumerator<GClass33> enumerator;
		for (;;)
		{
			GClass33 gclass;
			try
			{
				IL_77:
				while (enumerator.MoveNext())
				{
					gclass = enumerator.Current;
					if (gclass.method_4(gclass33_0))
					{
						goto IL_95;
					}
				}
				break;
				IL_26:
				if (this.gclass34_0 == null || this.gclass34_0.Count == 0)
				{
					goto IL_A7;
				}
				enumerator = this.gclass34_0.GetEnumerator();
				goto IL_77;
			}
			finally
			{
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			break;
			IL_95:
			yield return gclass;
		}
		enumerator = null;
		yield break;
		IL_A7:
		yield break;
		yield break;
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x0003859C File Offset: 0x0003679C
	private static bool smethod_1(string string_2)
	{
		foreach (char c in string_2)
		{
			if (c < ' ')
			{
				return false;
			}
			if (c > '~')
			{
				return false;
			}
			if ("()<>@:\\[]?{}".IndexOf(c) > -1)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x000385E4 File Offset: 0x000367E4
	private static bool smethod_2(string string_2)
	{
		foreach (char c in string_2)
		{
			if (c < ' ')
			{
				return false;
			}
			if (c > '~')
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x00007D62 File Offset: 0x00005F62
	public void method_4()
	{
		if (this.bool_1)
		{
			return;
		}
		this.method_1(true);
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x00007D74 File Offset: 0x00005F74
	public void method_5(GClass33 gclass33_0)
	{
		this.GClass34_0.Add(gclass33_0);
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x00007D82 File Offset: 0x00005F82
	public void method_6(string string_2, string string_3)
	{
		this.GClass45_1.Add(string_2, string_3);
	}

	// Token: 0x06000755 RID: 1877 RVA: 0x00007D91 File Offset: 0x00005F91
	public void method_7()
	{
		if (this.bool_1)
		{
			return;
		}
		this.method_1(false);
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x0003861C File Offset: 0x0003681C
	public void method_8(byte[] byte_0, bool bool_5)
	{
		GClass41.Class76 @class = new GClass41.Class76();
		@class.gclass41_0 = this;
		if (this.bool_1)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		if (byte_0 == null)
		{
			throw new ArgumentNullException("responseEntity");
		}
		long num = (long)byte_0.Length;
		if (num > 2147483647L)
		{
			this.method_2(byte_0, 1024, bool_5);
			return;
		}
		@class.stream_0 = this.Stream_0;
		if (bool_5)
		{
			@class.stream_0.Write(byte_0, 0, (int)num);
			this.method_1(false);
			return;
		}
		@class.stream_0.BeginWrite(byte_0, 0, (int)num, new AsyncCallback(@class.method_0), null);
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x000386BC File Offset: 0x000368BC
	public void method_9(GClass41 gclass41_0)
	{
		if (gclass41_0 == null)
		{
			throw new ArgumentNullException("templateResponse");
		}
		GClass45 gclass = gclass41_0.gclass45_0;
		if (gclass != null)
		{
			if (this.gclass45_0 != null)
			{
				this.gclass45_0.Clear();
			}
			this.GClass45_1.Add(gclass);
		}
		else
		{
			this.gclass45_0 = null;
		}
		this.long_0 = gclass41_0.long_0;
		this.int_0 = gclass41_0.int_0;
		this.string_1 = gclass41_0.string_1;
		this.bool_3 = gclass41_0.bool_3;
		this.version_0 = gclass41_0.version_0;
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x00038748 File Offset: 0x00036948
	public void method_10(string string_2)
	{
		if (this.bool_1)
		{
			throw new ObjectDisposedException(base.GetType().ToString());
		}
		if (this.bool_2)
		{
			throw new InvalidOperationException("The response is already being sent.");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("url");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentException("An empty string.", "url");
		}
		Uri uri;
		if (!Uri.TryCreate(string_2, UriKind.Absolute, out uri))
		{
			throw new ArgumentException("Not an absolute URL.", "url");
		}
		this.uri_0 = uri;
		this.int_0 = 302;
		this.string_1 = "Found";
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00007DA3 File Offset: 0x00005FA3
	public void method_11(GClass33 gclass33_0)
	{
		if (gclass33_0 == null)
		{
			throw new ArgumentNullException("cookie");
		}
		if (!this.method_0(gclass33_0))
		{
			throw new ArgumentException("It cannot be updated.", "cookie");
		}
		this.GClass34_0.Add(gclass33_0);
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x00007DD8 File Offset: 0x00005FD8
	public void method_12(string string_2, string string_3)
	{
		this.GClass45_1.Set(string_2, string_3);
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x00007D62 File Offset: 0x00005F62
	void IDisposable.Dispose()
	{
		if (this.bool_1)
		{
			return;
		}
		this.method_1(true);
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x00007DE7 File Offset: 0x00005FE7
	[CompilerGenerated]
	private void method_13()
	{
		this.method_1(false);
	}

	// Token: 0x0400037B RID: 891
	private bool bool_0;

	// Token: 0x0400037C RID: 892
	private Encoding encoding_0;

	// Token: 0x0400037D RID: 893
	private long long_0;

	// Token: 0x0400037E RID: 894
	private string string_0;

	// Token: 0x0400037F RID: 895
	private GClass38 gclass38_0;

	// Token: 0x04000380 RID: 896
	private GClass34 gclass34_0;

	// Token: 0x04000381 RID: 897
	private bool bool_1;

	// Token: 0x04000382 RID: 898
	private GClass45 gclass45_0;

	// Token: 0x04000383 RID: 899
	private bool bool_2;

	// Token: 0x04000384 RID: 900
	private bool bool_3;

	// Token: 0x04000385 RID: 901
	private Stream4 stream4_0;

	// Token: 0x04000386 RID: 902
	private Uri uri_0;

	// Token: 0x04000387 RID: 903
	private bool bool_4;

	// Token: 0x04000388 RID: 904
	private int int_0;

	// Token: 0x04000389 RID: 905
	private string string_1;

	// Token: 0x0400038A RID: 906
	private Version version_0;

	// Token: 0x0200009A RID: 154
	[CompilerGenerated]
	private sealed class Class76
	{
		// Token: 0x06000767 RID: 1895 RVA: 0x00007E36 File Offset: 0x00006036
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			this.stream_0.EndWrite(iasyncResult_0);
			this.gclass41_0.method_1(false);
		}

		// Token: 0x04000392 RID: 914
		public Stream stream_0;

		// Token: 0x04000393 RID: 915
		public GClass41 gclass41_0;
	}
}
