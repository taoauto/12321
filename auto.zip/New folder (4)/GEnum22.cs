﻿using System;

// Token: 0x02000173 RID: 371
public enum GEnum22
{
	// Token: 0x04000972 RID: 2418
	Standard,
	// Token: 0x04000973 RID: 2419
	ThreadHijack,
	// Token: 0x04000974 RID: 2420
	ManualMap
}
