﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

// Token: 0x02000213 RID: 531
internal class MicroLogin : UserControl
{
	// Token: 0x06001B8D RID: 7053 RVA: 0x00014077 File Offset: 0x00012277
	public MicroLogin()
	{
		this.InitializeComponent();
		MicroLogin.MicroLogin_0 = this;
	}

	// Token: 0x17000690 RID: 1680
	// (get) Token: 0x06001B8E RID: 7054 RVA: 0x0001408B File Offset: 0x0001228B
	// (set) Token: 0x06001B8F RID: 7055 RVA: 0x00014092 File Offset: 0x00012292
	public static int Int32_0 { get; set; }

	// Token: 0x06001B90 RID: 7056 RVA: 0x000D1A88 File Offset: 0x000CFC88
	private void method_0(object sender, FormClosingEventArgs e)
	{
		try
		{
			if (Main.Boolean_8)
			{
				base.Dispose();
			}
			else if (e.CloseReason != CloseReason.WindowsShutDown && e.CloseReason != CloseReason.ApplicationExitCall)
			{
				base.Hide();
				e.Cancel = true;
			}
			else if (e.CloseReason == CloseReason.WindowsShutDown)
			{
				base.Dispose();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001B91 RID: 7057 RVA: 0x000D1AEC File Offset: 0x000CFCEC
	private void btnPublisher_Click(object sender, EventArgs e)
	{
		Publisher publisher = new Publisher
		{
			Dock = DockStyle.Fill
		};
		base.Controls.Add(publisher);
		publisher.BringToFront();
		this.splitContainer1.Visible = false;
		publisher.Disposed += this.method_5;
	}

	// Token: 0x06001B92 RID: 7058 RVA: 0x000D1B38 File Offset: 0x000CFD38
	private void btnAddAcc_Click(object sender, EventArgs e)
	{
		try
		{
			if (this.tab.SelectedTab.Tag != null && this.tab.SelectedTab.Tag.ToString() == "loged")
			{
				(this.tab.SelectedTab.Controls[0] as TabLogin).method_8();
			}
		}
		catch
		{
		}
	}

	// Token: 0x06001B93 RID: 7059 RVA: 0x0001409A File Offset: 0x0001229A
	public void method_1()
	{
		EventHandler eventHandler = this.eventHandler_0;
		if (eventHandler == null)
		{
			return;
		}
		eventHandler(MicroLogin.MicroLogin_0, null);
	}

	// Token: 0x17000691 RID: 1681
	// (get) Token: 0x06001B94 RID: 7060 RVA: 0x000140B2 File Offset: 0x000122B2
	// (set) Token: 0x06001B95 RID: 7061 RVA: 0x000140B9 File Offset: 0x000122B9
	public static List<Class145> List_0 { get; set; }

	// Token: 0x1400004B RID: 75
	// (add) Token: 0x06001B96 RID: 7062 RVA: 0x000D1BB0 File Offset: 0x000CFDB0
	// (remove) Token: 0x06001B97 RID: 7063 RVA: 0x000D1BE8 File Offset: 0x000CFDE8
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06001B98 RID: 7064 RVA: 0x000D1C20 File Offset: 0x000CFE20
	private void MicroLogin_Load(object sender, EventArgs e)
	{
		this.tab.TabPages[0].Controls.Add(new TabLogin
		{
			Dock = DockStyle.Fill
		});
		MicroLogin.MicroLogin_0 = this;
		this.CboNPH.Items.Clear();
		foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("Publishers").SelectNodes("Publisher"))
		{
			XmlNode xmlNode = (XmlNode)obj;
			this.CboNPH.Items.Add(xmlNode.Attributes["Name"].Value);
		}
	}

	// Token: 0x06001B99 RID: 7065 RVA: 0x000D1CEC File Offset: 0x000CFEEC
	private void method_2()
	{
		this.CboNPH.Items.Clear();
		foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("Publishers").SelectNodes("Publisher"))
		{
			XmlNode xmlNode = (XmlNode)obj;
			this.CboNPH.Items.Add(xmlNode.Attributes["Name"].Value);
		}
	}

	// Token: 0x06001B9A RID: 7066 RVA: 0x000D1D88 File Offset: 0x000CFF88
	private void CboNPH_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.CboServer.Items.Clear();
		try
		{
			foreach (object obj in Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.CboNPH.Text + "\"]/Servers").SelectNodes("Server"))
			{
				XmlNode xmlNode = (XmlNode)obj;
				this.CboServer.Items.Add(xmlNode.InnerText);
			}
		}
		catch
		{
		}
		if (this.CboTail.Items.Count > 0)
		{
			this.CboTail.Items.Clear();
		}
		try
		{
			foreach (object obj2 in Publisher.xmlDocument_0.SelectSingleNode("//Publishers/Publisher[@Name=\"" + this.CboNPH.Text + "\"]/Tails").SelectNodes("Tail"))
			{
				XmlNode xmlNode2 = (XmlNode)obj2;
				this.CboTail.Items.Add(xmlNode2.InnerText);
			}
		}
		catch
		{
		}
	}

	// Token: 0x17000692 RID: 1682
	// (get) Token: 0x06001B9B RID: 7067 RVA: 0x000140C1 File Offset: 0x000122C1
	// (set) Token: 0x06001B9C RID: 7068 RVA: 0x000140C8 File Offset: 0x000122C8
	public static int Int32_1 { get; set; } = 6;

	// Token: 0x17000693 RID: 1683
	// (get) Token: 0x06001B9D RID: 7069 RVA: 0x000140D0 File Offset: 0x000122D0
	// (set) Token: 0x06001B9E RID: 7070 RVA: 0x000140D7 File Offset: 0x000122D7
	public static int Int32_2 { get; set; } = 5;

	// Token: 0x06001B9F RID: 7071 RVA: 0x000140DF File Offset: 0x000122DF
	private void chkShowPass_CheckedChanged(object sender, EventArgs e)
	{
		if (this.chkShowPass.Checked)
		{
			this.TxtPass.PasswordChar = '\0';
			return;
		}
		this.TxtPass.PasswordChar = '*';
	}

	// Token: 0x06001BA0 RID: 7072 RVA: 0x00014108 File Offset: 0x00012308
	private void TxtUser_TextChanged(object sender, EventArgs e)
	{
		this.TxtUser.Text = this.TxtUser.Text.Trim();
	}

	// Token: 0x06001BA1 RID: 7073 RVA: 0x00002E18 File Offset: 0x00001018
	private void CboServer_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001BA2 RID: 7074 RVA: 0x00002E18 File Offset: 0x00001018
	private void MicroLogin_Resize(object sender, EventArgs e)
	{
	}

	// Token: 0x06001BA3 RID: 7075 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_3(object sender, EventArgs e)
	{
	}

	// Token: 0x17000694 RID: 1684
	// (get) Token: 0x06001BA4 RID: 7076 RVA: 0x00014125 File Offset: 0x00012325
	// (set) Token: 0x06001BA5 RID: 7077 RVA: 0x0001412C File Offset: 0x0001232C
	public static bool Boolean_0 { get; set; }

	// Token: 0x17000695 RID: 1685
	// (get) Token: 0x06001BA6 RID: 7078 RVA: 0x00014134 File Offset: 0x00012334
	// (set) Token: 0x06001BA7 RID: 7079 RVA: 0x0001413B File Offset: 0x0001233B
	public static MicroLogin MicroLogin_0 { get; set; }

	// Token: 0x17000696 RID: 1686
	// (get) Token: 0x06001BA8 RID: 7080 RVA: 0x00014143 File Offset: 0x00012343
	// (set) Token: 0x06001BA9 RID: 7081 RVA: 0x0001414A File Offset: 0x0001234A
	public static bool Boolean_1 { get; set; }

	// Token: 0x17000697 RID: 1687
	// (get) Token: 0x06001BAA RID: 7082 RVA: 0x00014152 File Offset: 0x00012352
	// (set) Token: 0x06001BAB RID: 7083 RVA: 0x00014159 File Offset: 0x00012359
	public static bool Boolean_2 { get; set; }

	// Token: 0x17000698 RID: 1688
	// (get) Token: 0x06001BAC RID: 7084 RVA: 0x00014161 File Offset: 0x00012361
	// (set) Token: 0x06001BAD RID: 7085 RVA: 0x00014168 File Offset: 0x00012368
	public static bool Boolean_3 { get; set; }

	// Token: 0x17000699 RID: 1689
	// (get) Token: 0x06001BAE RID: 7086 RVA: 0x00014170 File Offset: 0x00012370
	// (set) Token: 0x06001BAF RID: 7087 RVA: 0x00014177 File Offset: 0x00012377
	public static bool Boolean_4 { get; set; }

	// Token: 0x1700069A RID: 1690
	// (get) Token: 0x06001BB0 RID: 7088 RVA: 0x0001417F File Offset: 0x0001237F
	// (set) Token: 0x06001BB1 RID: 7089 RVA: 0x00014186 File Offset: 0x00012386
	public static int Int32_3 { get; set; } = 30;

	// Token: 0x06001BB2 RID: 7090 RVA: 0x00002E18 File Offset: 0x00001018
	private void TxtUser_KeyPress(object sender, KeyPressEventArgs e)
	{
	}

	// Token: 0x06001BB3 RID: 7091 RVA: 0x0001418E File Offset: 0x0001238E
	private void TxtUser_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			this.btnAddAcc_Click(null, null);
		}
	}

	// Token: 0x06001BB4 RID: 7092 RVA: 0x0001418E File Offset: 0x0001238E
	private void TxtPass_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			this.btnAddAcc_Click(null, null);
		}
	}

	// Token: 0x06001BB5 RID: 7093 RVA: 0x000D1EF4 File Offset: 0x000D00F4
	private void btnEdit_Click(object sender, EventArgs e)
	{
		try
		{
			if (this.tab.SelectedTab.Tag != null && this.tab.SelectedTab.Tag.ToString() == "loged")
			{
				TabLogin tabLogin = this.tab.SelectedTab.Controls[0] as TabLogin;
				if (tabLogin.ListViewItem_0 != null)
				{
					Class145 @class = tabLogin.ListViewItem_0.Tag as Class145;
					@class.String_2 = this.TxtUser.Text;
					@class.String_4 = this.TxtPass.Text;
					@class.String_5 = this.CboNPH.Text;
					@class.String_6 = this.CboServer.Text;
					@class.String_7 = this.CboTail.Text;
					EventHandler eventHandler = this.eventHandler_0;
					if (eventHandler != null)
					{
						eventHandler(this, null);
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x1700069B RID: 1691
	// (get) Token: 0x06001BB6 RID: 7094 RVA: 0x000141A2 File Offset: 0x000123A2
	// (set) Token: 0x06001BB7 RID: 7095 RVA: 0x000141A9 File Offset: 0x000123A9
	public static bool Boolean_5 { get; set; }

	// Token: 0x1700069C RID: 1692
	// (get) Token: 0x06001BB8 RID: 7096 RVA: 0x000141B1 File Offset: 0x000123B1
	// (set) Token: 0x06001BB9 RID: 7097 RVA: 0x000141B8 File Offset: 0x000123B8
	public static string String_0 { get; set; } = string.Empty;

	// Token: 0x1700069D RID: 1693
	// (get) Token: 0x06001BBA RID: 7098 RVA: 0x000141C0 File Offset: 0x000123C0
	public static bool Boolean_6
	{
		get
		{
			return CalendarEx.bool_0;
		}
	}

	// Token: 0x1700069E RID: 1694
	// (get) Token: 0x06001BBB RID: 7099 RVA: 0x000141C7 File Offset: 0x000123C7
	// (set) Token: 0x06001BBC RID: 7100 RVA: 0x000141CE File Offset: 0x000123CE
	public static bool Boolean_7 { get; set; }

	// Token: 0x1700069F RID: 1695
	// (get) Token: 0x06001BBD RID: 7101 RVA: 0x000141D6 File Offset: 0x000123D6
	// (set) Token: 0x06001BBE RID: 7102 RVA: 0x000141DD File Offset: 0x000123DD
	public static int Int32_4 { get; set; } = 6;

	// Token: 0x170006A0 RID: 1696
	// (get) Token: 0x06001BBF RID: 7103 RVA: 0x000141E5 File Offset: 0x000123E5
	// (set) Token: 0x06001BC0 RID: 7104 RVA: 0x000141EC File Offset: 0x000123EC
	public static bool Boolean_8 { get; set; }

	// Token: 0x170006A1 RID: 1697
	// (get) Token: 0x06001BC1 RID: 7105 RVA: 0x000141F4 File Offset: 0x000123F4
	// (set) Token: 0x06001BC2 RID: 7106 RVA: 0x000141FB File Offset: 0x000123FB
	public static int Int32_5 { get; set; } = 6;

	// Token: 0x170006A2 RID: 1698
	// (get) Token: 0x06001BC3 RID: 7107 RVA: 0x00014203 File Offset: 0x00012403
	// (set) Token: 0x06001BC4 RID: 7108 RVA: 0x0001420A File Offset: 0x0001240A
	public static bool Boolean_9 { get; set; }

	// Token: 0x170006A3 RID: 1699
	// (get) Token: 0x06001BC5 RID: 7109 RVA: 0x00014212 File Offset: 0x00012412
	// (set) Token: 0x06001BC6 RID: 7110 RVA: 0x00014219 File Offset: 0x00012419
	public static int Int32_6 { get; set; } = 6;

	// Token: 0x170006A4 RID: 1700
	// (get) Token: 0x06001BC7 RID: 7111 RVA: 0x0000354C File Offset: 0x0000174C
	public static bool Boolean_10
	{
		get
		{
			return true;
		}
	}

	// Token: 0x170006A5 RID: 1701
	// (get) Token: 0x06001BC8 RID: 7112 RVA: 0x00014221 File Offset: 0x00012421
	// (set) Token: 0x06001BC9 RID: 7113 RVA: 0x00014228 File Offset: 0x00012428
	public static bool Boolean_11 { get; set; }

	// Token: 0x06001BCA RID: 7114 RVA: 0x000D1FEC File Offset: 0x000D01EC
	private void tab_Selecting(object sender, TabControlCancelEventArgs e)
	{
		Control1 control = sender as Control1;
		if (e.TabPageIndex == control.TabCount - 1)
		{
			e.Cancel = true;
		}
	}

	// Token: 0x06001BCB RID: 7115 RVA: 0x00002E18 File Offset: 0x00001018
	private void tab_MouseDown(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001BCC RID: 7116 RVA: 0x000D2018 File Offset: 0x000D0218
	private void tab_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			Control1 control = sender as Control1;
			int num = control.TabCount - 1;
			if (control.GetTabRect(num).Contains(e.Location))
			{
				TabPage tabPage = new TabPage("Online");
				control.TabPages.Insert(num, tabPage);
				control.SelectedIndex = num;
				tabPage.Controls.Add(new TabLogin
				{
					Dock = DockStyle.Fill
				});
			}
		}
	}

	// Token: 0x06001BCD RID: 7117 RVA: 0x000D2090 File Offset: 0x000D0290
	public static void smethod_0()
	{
		try
		{
			string text = "nier.xml";
			if (File.Exists(text))
			{
				MicroLogin.xmlDocument_0.Load(text);
			}
			else if (File.Exists(text + ".old"))
			{
				MicroLogin.xmlDocument_0.Load(text + ".old");
			}
			else
			{
				MicroLogin.xmlDocument_0 = new XmlDocument();
				MicroLogin.xmlDocument_0.InsertBefore(MicroLogin.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), MicroLogin.xmlDocument_0.DocumentElement);
				MicroLogin.xmlDocument_0.AppendChild(MicroLogin.xmlDocument_0.CreateNode(XmlNodeType.Element, "Accounts", ""));
			}
		}
		catch
		{
			try
			{
				MicroLogin.xmlDocument_0 = new XmlDocument();
				if (MicroLogin.xmlDocument_0.SelectSingleNode("/*") == null)
				{
					MicroLogin.xmlDocument_0.InsertBefore(MicroLogin.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), MicroLogin.xmlDocument_0.DocumentElement);
					MicroLogin.xmlDocument_0.AppendChild(MicroLogin.xmlDocument_0.CreateNode(XmlNodeType.Element, "Accounts", ""));
				}
			}
			catch
			{
			}
		}
	}

	// Token: 0x06001BCE RID: 7118 RVA: 0x000D21C0 File Offset: 0x000D03C0
	public static void smethod_1()
	{
		try
		{
			MicroLogin.Class245 @class = new MicroLogin.Class245();
			@class.xmlNode_0 = MicroLogin.xmlDocument_0.SelectSingleNode("/*");
			List<XmlNode> list = new List<XmlNode>();
			foreach (object obj in MicroLogin.xmlDocument_0.SelectSingleNode("Accounts").SelectNodes("*"))
			{
				XmlElement xmlElement = (XmlElement)obj;
				if (!(xmlElement.Name == "Account" + Main.String_3.Replace("#", "")))
				{
					list.Add(xmlElement);
				}
			}
			@class.xmlNode_0.RemoveAll();
			foreach (Class145 class2 in MicroLogin.List_0)
			{
				@class.xmlNode_0.AppendChild(class2.xmlNode_0);
			}
			list.ForEach(new Action<XmlNode>(@class.method_0));
			string text = "nier.xml";
			MicroLogin.xmlDocument_0.Save(text + ".new");
			try
			{
				File.Delete(text + ".old");
				File.Move(text, text + ".old");
			}
			catch
			{
			}
			try
			{
				File.Delete(text);
				File.Move(text + ".new", text);
			}
			catch
			{
			}
			try
			{
				File.Delete(text + ".old");
			}
			catch
			{
			}
		}
		catch
		{
		}
	}

	// Token: 0x170006A6 RID: 1702
	// (get) Token: 0x06001BCF RID: 7119 RVA: 0x00014230 File Offset: 0x00012430
	// (set) Token: 0x06001BD0 RID: 7120 RVA: 0x00014237 File Offset: 0x00012437
	public static bool Boolean_12 { get; set; }

	// Token: 0x170006A7 RID: 1703
	// (get) Token: 0x06001BD1 RID: 7121 RVA: 0x0001423F File Offset: 0x0001243F
	// (set) Token: 0x06001BD2 RID: 7122 RVA: 0x00014246 File Offset: 0x00012446
	public static bool Boolean_13 { get; set; } = true;

	// Token: 0x06001BD3 RID: 7123 RVA: 0x000D23E0 File Offset: 0x000D05E0
	private void method_4(object sender, EventArgs e)
	{
		SleepTime sleepTime = new SleepTime
		{
			Dock = DockStyle.Fill
		};
		base.Controls.Add(sleepTime);
		sleepTime.BringToFront();
	}

	// Token: 0x170006A8 RID: 1704
	// (get) Token: 0x06001BD4 RID: 7124 RVA: 0x0001424E File Offset: 0x0001244E
	// (set) Token: 0x06001BD5 RID: 7125 RVA: 0x00014255 File Offset: 0x00012455
	public static bool Boolean_14 { get; set; }

	// Token: 0x06001BD6 RID: 7126 RVA: 0x00002E18 File Offset: 0x00001018
	private void tab_TabIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06001BD7 RID: 7127 RVA: 0x0001425D File Offset: 0x0001245D
	private void tab_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (this.tab.TabPages[this.tab.SelectedIndex].Tag == null)
		{
			this.splitContainer1.Visible = false;
			return;
		}
		this.splitContainer1.Visible = true;
	}

	// Token: 0x06001BD8 RID: 7128 RVA: 0x0001429A File Offset: 0x0001249A
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001BD9 RID: 7129 RVA: 0x000D240C File Offset: 0x000D060C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		this.chkShowPass = new CheckBox();
		this.CboTail = new ComboBox();
		this.btnPublisher = new Button();
		this.CboServer = new ComboBox();
		this.btnAddAcc = new Button();
		this.CboNPH = new ComboBox();
		this.tabPage3 = new TabPage();
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.btnEdit = new Button();
		this.TxtUser = new Class85();
		this.TxtPass = new Class85();
		this.splitContainer1 = new SplitContainer();
		this.splitContainer3 = new SplitContainer();
		this.panel3 = new Panel();
		this.panel4 = new Panel();
		this.panel1 = new Panel();
		this.tab = new Control1();
		this.tabPage1 = new TabPage();
		this.tabPage2 = new TabPage();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.splitContainer3.Panel1.SuspendLayout();
		this.splitContainer3.Panel2.SuspendLayout();
		this.splitContainer3.SuspendLayout();
		this.panel3.SuspendLayout();
		this.panel4.SuspendLayout();
		this.panel1.SuspendLayout();
		this.tab.SuspendLayout();
		base.SuspendLayout();
		this.chkShowPass.AutoSize = true;
		this.chkShowPass.Dock = DockStyle.Right;
		this.chkShowPass.Location = new Point(141, 0);
		this.chkShowPass.Name = "chkShowPass";
		this.chkShowPass.Size = new Size(15, 22);
		this.chkShowPass.TabIndex = 43;
		this.chkShowPass.UseVisualStyleBackColor = true;
		this.chkShowPass.CheckedChanged += this.chkShowPass_CheckedChanged;
		this.CboTail.Dock = DockStyle.Right;
		this.CboTail.DropDownStyle = ComboBoxStyle.DropDownList;
		this.CboTail.FormattingEnabled = true;
		this.CboTail.Location = new Point(123, 0);
		this.CboTail.Name = "CboTail";
		this.CboTail.Size = new Size(77, 21);
		this.CboTail.TabIndex = 40;
		this.btnPublisher.Dock = DockStyle.Right;
		this.btnPublisher.Location = new Point(177, 0);
		this.btnPublisher.Name = "btnPublisher";
		this.btnPublisher.Size = new Size(23, 22);
		this.btnPublisher.TabIndex = 42;
		this.btnPublisher.Text = "+";
		this.btnPublisher.UseVisualStyleBackColor = true;
		this.btnPublisher.Click += this.btnPublisher_Click;
		this.CboServer.Dock = DockStyle.Fill;
		this.CboServer.DropDownStyle = ComboBoxStyle.DropDownList;
		this.CboServer.FormattingEnabled = true;
		this.CboServer.Location = new Point(0, 0);
		this.CboServer.Name = "CboServer";
		this.CboServer.Size = new Size(123, 21);
		this.CboServer.TabIndex = 32;
		this.CboServer.SelectedIndexChanged += this.CboServer_SelectedIndexChanged;
		this.btnAddAcc.Dock = DockStyle.Fill;
		this.btnAddAcc.Location = new Point(0, 22);
		this.btnAddAcc.Name = "btnAddAcc";
		this.btnAddAcc.Size = new Size(60, 22);
		this.btnAddAcc.TabIndex = 38;
		this.btnAddAcc.Text = "Add";
		this.btnAddAcc.UseVisualStyleBackColor = true;
		this.btnAddAcc.Click += this.btnAddAcc_Click;
		this.CboNPH.Dock = DockStyle.Fill;
		this.CboNPH.DropDownStyle = ComboBoxStyle.DropDownList;
		this.CboNPH.FormattingEnabled = true;
		this.CboNPH.Location = new Point(0, 0);
		this.CboNPH.Name = "CboNPH";
		this.CboNPH.Size = new Size(177, 21);
		this.CboNPH.TabIndex = 30;
		this.CboNPH.SelectedIndexChanged += this.CboNPH_SelectedIndexChanged;
		this.tabPage3.Location = new Point(0, 0);
		this.tabPage3.Name = "tabPage3";
		this.tabPage3.Size = new Size(200, 100);
		this.tabPage3.TabIndex = 0;
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.btnEdit.Dock = DockStyle.Top;
		this.btnEdit.Location = new Point(0, 0);
		this.btnEdit.Name = "btnEdit";
		this.btnEdit.Size = new Size(60, 22);
		this.btnEdit.TabIndex = 72;
		this.btnEdit.Text = "Edit";
		this.btnEdit.UseVisualStyleBackColor = true;
		this.btnEdit.Click += this.btnEdit_Click;
		this.TxtUser.Dock = DockStyle.Top;
		this.TxtUser.Location = new Point(0, 0);
		this.TxtUser.Name = "TxtUser";
		this.TxtUser.Size = new Size(156, 20);
		this.TxtUser.TabIndex = 24;
		this.TxtUser.String_0 = "User...";
		this.TxtUser.Color_0 = Color.Gray;
		this.TxtUser.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.TxtUser.Color_1 = Color.LightGray;
		this.TxtUser.TextChanged += this.TxtUser_TextChanged;
		this.TxtUser.KeyDown += this.TxtUser_KeyDown;
		this.TxtUser.KeyPress += this.TxtUser_KeyPress;
		this.TxtPass.Dock = DockStyle.Fill;
		this.TxtPass.Location = new Point(0, 0);
		this.TxtPass.Name = "TxtPass";
		this.TxtPass.PasswordChar = '*';
		this.TxtPass.Size = new Size(156, 20);
		this.TxtPass.TabIndex = 25;
		this.TxtPass.String_0 = "Pass...";
		this.TxtPass.Color_0 = Color.Gray;
		this.TxtPass.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.TxtPass.Color_1 = Color.LightGray;
		this.TxtPass.KeyDown += this.TxtPass_KeyDown;
		this.splitContainer1.Dock = DockStyle.Top;
		this.splitContainer1.Location = new Point(0, 0);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
		this.splitContainer1.Panel2.Controls.Add(this.btnAddAcc);
		this.splitContainer1.Panel2.Controls.Add(this.btnEdit);
		this.splitContainer1.Size = new Size(424, 44);
		this.splitContainer1.SplitterDistance = 360;
		this.splitContainer1.TabIndex = 75;
		this.splitContainer3.Dock = DockStyle.Fill;
		this.splitContainer3.Location = new Point(0, 0);
		this.splitContainer3.Name = "splitContainer3";
		this.splitContainer3.Panel1.Controls.Add(this.panel3);
		this.splitContainer3.Panel1.Controls.Add(this.TxtUser);
		this.splitContainer3.Panel2.Controls.Add(this.panel4);
		this.splitContainer3.Panel2.Controls.Add(this.panel1);
		this.splitContainer3.Size = new Size(360, 44);
		this.splitContainer3.SplitterDistance = 156;
		this.splitContainer3.TabIndex = 75;
		this.panel3.Controls.Add(this.chkShowPass);
		this.panel3.Controls.Add(this.TxtPass);
		this.panel3.Dock = DockStyle.Bottom;
		this.panel3.Location = new Point(0, 22);
		this.panel3.Name = "panel3";
		this.panel3.Size = new Size(156, 22);
		this.panel3.TabIndex = 26;
		this.panel4.Controls.Add(this.CboServer);
		this.panel4.Controls.Add(this.CboTail);
		this.panel4.Dock = DockStyle.Fill;
		this.panel4.Location = new Point(0, 22);
		this.panel4.Name = "panel4";
		this.panel4.Size = new Size(200, 22);
		this.panel4.TabIndex = 31;
		this.panel1.Controls.Add(this.CboNPH);
		this.panel1.Controls.Add(this.btnPublisher);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(0, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(200, 22);
		this.panel1.TabIndex = 32;
		this.tab.Controls.Add(this.tabPage1);
		this.tab.Controls.Add(this.tabPage2);
		this.tab.Dock = DockStyle.Fill;
		this.tab.Location = new Point(0, 44);
		this.tab.Name = "tab";
		this.tab.SelectedIndex = 0;
		this.tab.Size = new Size(424, 469);
		this.tab.TabIndex = 45;
		this.tab.SelectedIndexChanged += this.tab_SelectedIndexChanged;
		this.tab.Selecting += this.tab_Selecting;
		this.tab.TabIndexChanged += this.tab_TabIndexChanged;
		this.tab.MouseClick += this.tab_MouseClick;
		this.tab.MouseDown += this.tab_MouseDown;
		this.tabPage1.Location = new Point(4, 4);
		this.tabPage1.Name = "tabPage1";
		this.tabPage1.Padding = new Padding(3);
		this.tabPage1.Size = new Size(416, 443);
		this.tabPage1.TabIndex = 5;
		this.tabPage1.Tag = "loged";
		this.tabPage1.Text = "Offline";
		this.tabPage1.UseVisualStyleBackColor = true;
		this.tabPage2.Location = new Point(4, 4);
		this.tabPage2.Name = "tabPage2";
		this.tabPage2.Padding = new Padding(3);
		this.tabPage2.Size = new Size(416, 443);
		this.tabPage2.TabIndex = 4;
		this.tabPage2.Text = "+";
		this.tabPage2.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		this.BackColor = Color.White;
		base.Controls.Add(this.tab);
		base.Controls.Add(this.splitContainer1);
		base.Name = "MicroLogin";
		base.Size = new Size(424, 513);
		base.Load += this.MicroLogin_Load;
		base.Resize += this.MicroLogin_Resize;
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.splitContainer3.Panel1.ResumeLayout(false);
		this.splitContainer3.Panel1.PerformLayout();
		this.splitContainer3.Panel2.ResumeLayout(false);
		this.splitContainer3.ResumeLayout(false);
		this.panel3.ResumeLayout(false);
		this.panel3.PerformLayout();
		this.panel4.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.tab.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x06001BDB RID: 7131 RVA: 0x000142B9 File Offset: 0x000124B9
	[CompilerGenerated]
	private void method_5(object sender, EventArgs e)
	{
		this.splitContainer1.Visible = true;
	}

	// Token: 0x0400115C RID: 4444
	[CompilerGenerated]
	private static int int_0;

	// Token: 0x0400115D RID: 4445
	[CompilerGenerated]
	private static List<Class145> list_0;

	// Token: 0x0400115E RID: 4446
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x0400115F RID: 4447
	public static bool bool_0 = false;

	// Token: 0x04001160 RID: 4448
	[CompilerGenerated]
	private static int int_1;

	// Token: 0x04001161 RID: 4449
	[CompilerGenerated]
	private static int int_2;

	// Token: 0x04001162 RID: 4450
	public static Stopwatch stopwatch_0;

	// Token: 0x04001163 RID: 4451
	public static Dictionary<string, string> dictionary_0 = new Dictionary<string, string>();

	// Token: 0x04001164 RID: 4452
	public static Class145 class145_0 = null;

	// Token: 0x04001165 RID: 4453
	public static bool bool_1 = false;

	// Token: 0x04001166 RID: 4454
	[CompilerGenerated]
	private static bool bool_2;

	// Token: 0x04001167 RID: 4455
	[CompilerGenerated]
	private static MicroLogin microLogin_0;

	// Token: 0x04001168 RID: 4456
	public static List<Class145> list_1 = new List<Class145>();

	// Token: 0x04001169 RID: 4457
	public static int int_3 = 30;

	// Token: 0x0400116A RID: 4458
	public static Stopwatch stopwatch_1 = Stopwatch.StartNew();

	// Token: 0x0400116B RID: 4459
	public static Stopwatch stopwatch_2 = Stopwatch.StartNew();

	// Token: 0x0400116C RID: 4460
	[CompilerGenerated]
	private static bool bool_3;

	// Token: 0x0400116D RID: 4461
	[CompilerGenerated]
	private static bool bool_4;

	// Token: 0x0400116E RID: 4462
	[CompilerGenerated]
	private static bool bool_5;

	// Token: 0x0400116F RID: 4463
	[CompilerGenerated]
	private static bool bool_6;

	// Token: 0x04001170 RID: 4464
	[CompilerGenerated]
	private static int int_4;

	// Token: 0x04001171 RID: 4465
	[CompilerGenerated]
	private static bool bool_7;

	// Token: 0x04001172 RID: 4466
	public static Stopwatch stopwatch_3;

	// Token: 0x04001173 RID: 4467
	public static int int_5;

	// Token: 0x04001174 RID: 4468
	[CompilerGenerated]
	private static string string_0;

	// Token: 0x04001175 RID: 4469
	[CompilerGenerated]
	private static bool bool_8;

	// Token: 0x04001176 RID: 4470
	[CompilerGenerated]
	private static int int_6;

	// Token: 0x04001177 RID: 4471
	[CompilerGenerated]
	private static bool bool_9;

	// Token: 0x04001178 RID: 4472
	[CompilerGenerated]
	private static int int_7;

	// Token: 0x04001179 RID: 4473
	[CompilerGenerated]
	private static bool bool_10;

	// Token: 0x0400117A RID: 4474
	[CompilerGenerated]
	private static int int_8;

	// Token: 0x0400117B RID: 4475
	[CompilerGenerated]
	private static bool bool_11;

	// Token: 0x0400117C RID: 4476
	public static XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x0400117D RID: 4477
	public static int int_9 = 60;

	// Token: 0x0400117E RID: 4478
	[CompilerGenerated]
	private static bool bool_12;

	// Token: 0x0400117F RID: 4479
	[CompilerGenerated]
	private static bool bool_13;

	// Token: 0x04001180 RID: 4480
	[CompilerGenerated]
	private static bool bool_14;

	// Token: 0x04001181 RID: 4481
	private IContainer icontainer_0;

	// Token: 0x04001182 RID: 4482
	private Button btnAddAcc;

	// Token: 0x04001183 RID: 4483
	private ToolTip toolTip_0;

	// Token: 0x04001184 RID: 4484
	private TabPage tabPage3;

	// Token: 0x04001185 RID: 4485
	private Button btnEdit;

	// Token: 0x04001186 RID: 4486
	public ComboBox CboTail;

	// Token: 0x04001187 RID: 4487
	public ComboBox CboServer;

	// Token: 0x04001188 RID: 4488
	public ComboBox CboNPH;

	// Token: 0x04001189 RID: 4489
	private TabPage tabPage2;

	// Token: 0x0400118A RID: 4490
	private TabPage tabPage1;

	// Token: 0x0400118B RID: 4491
	public CheckBox chkShowPass;

	// Token: 0x0400118C RID: 4492
	public Button btnPublisher;

	// Token: 0x0400118D RID: 4493
	public Class85 TxtUser;

	// Token: 0x0400118E RID: 4494
	public Class85 TxtPass;

	// Token: 0x0400118F RID: 4495
	public Control1 tab;

	// Token: 0x04001190 RID: 4496
	private SplitContainer splitContainer3;

	// Token: 0x04001191 RID: 4497
	private Panel panel3;

	// Token: 0x04001192 RID: 4498
	private Panel panel4;

	// Token: 0x04001193 RID: 4499
	private Panel panel1;

	// Token: 0x04001194 RID: 4500
	public SplitContainer splitContainer1;

	// Token: 0x02000214 RID: 532
	[CompilerGenerated]
	private sealed class Class245
	{
		// Token: 0x06001BDD RID: 7133 RVA: 0x000142C7 File Offset: 0x000124C7
		internal void method_0(XmlNode xmlNode_1)
		{
			this.xmlNode_0.AppendChild(xmlNode_1);
		}

		// Token: 0x04001195 RID: 4501
		public XmlNode xmlNode_0;
	}
}
