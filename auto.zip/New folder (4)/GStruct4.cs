﻿using System;

// Token: 0x0200013B RID: 315
[Serializable]
public struct GStruct4
{
	// Token: 0x17000408 RID: 1032
	// (get) Token: 0x06000FA3 RID: 4003 RVA: 0x0000CF67 File Offset: 0x0000B167
	public long Int64_0
	{
		get
		{
			return this.startPosition;
		}
	}

	// Token: 0x17000409 RID: 1033
	// (get) Token: 0x06000FA4 RID: 4004 RVA: 0x0000CF6F File Offset: 0x0000B16F
	public long Int64_1
	{
		get
		{
			return this.endPosition;
		}
	}

	// Token: 0x06000FA5 RID: 4005 RVA: 0x0000CF77 File Offset: 0x0000B177
	public GStruct4(long long_0, long long_1)
	{
		this.endPosition = long_1;
		this.startPosition = long_0;
	}

	// Token: 0x0400080B RID: 2059
	private long startPosition;

	// Token: 0x0400080C RID: 2060
	private long endPosition;
}
