﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000181 RID: 385
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct10
{
	// Token: 0x040009CF RID: 2511
	public int Signature;

	// Token: 0x040009D0 RID: 2512
	public GStruct8 FileHeader;

	// Token: 0x040009D1 RID: 2513
	public GStruct11 OptionalHeader;
}
