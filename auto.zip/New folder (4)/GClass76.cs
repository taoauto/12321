﻿using System;
using System.Drawing;

// Token: 0x020000F6 RID: 246
[Serializable]
public class GClass76
{
	// Token: 0x17000365 RID: 869
	// (get) Token: 0x06000CBE RID: 3262 RVA: 0x0000B2E8 File Offset: 0x000094E8
	// (set) Token: 0x06000CBF RID: 3263 RVA: 0x0000B2F0 File Offset: 0x000094F0
	public Color Color_0 { get; set; }

	// Token: 0x17000366 RID: 870
	// (get) Token: 0x06000CC0 RID: 3264 RVA: 0x0000B2F9 File Offset: 0x000094F9
	// (set) Token: 0x06000CC1 RID: 3265 RVA: 0x0000B301 File Offset: 0x00009501
	public Color Color_1 { get; set; }

	// Token: 0x17000367 RID: 871
	// (get) Token: 0x06000CC2 RID: 3266 RVA: 0x0000B30A File Offset: 0x0000950A
	// (set) Token: 0x06000CC3 RID: 3267 RVA: 0x0000B312 File Offset: 0x00009512
	public Color Color_2 { get; set; }

	// Token: 0x17000368 RID: 872
	// (get) Token: 0x06000CC4 RID: 3268 RVA: 0x0000B31B File Offset: 0x0000951B
	// (set) Token: 0x06000CC5 RID: 3269 RVA: 0x0000B323 File Offset: 0x00009523
	public Color Color_3 { get; set; }

	// Token: 0x17000369 RID: 873
	// (get) Token: 0x06000CC6 RID: 3270 RVA: 0x0000B32C File Offset: 0x0000952C
	// (set) Token: 0x06000CC7 RID: 3271 RVA: 0x0000B334 File Offset: 0x00009534
	public Color Color_4 { get; set; }

	// Token: 0x1700036A RID: 874
	// (get) Token: 0x06000CC8 RID: 3272 RVA: 0x0000B33D File Offset: 0x0000953D
	// (set) Token: 0x06000CC9 RID: 3273 RVA: 0x0000B345 File Offset: 0x00009545
	public Color Color_5 { get; set; }

	// Token: 0x06000CCA RID: 3274 RVA: 0x0004D6DC File Offset: 0x0004B8DC
	public GClass76()
	{
		this.Color_0 = Color.Silver;
		this.Color_1 = Color.White;
		this.Color_2 = Color.Silver;
		this.Color_3 = Color.Red;
		this.Color_4 = Color.White;
		this.Color_5 = Color.Silver;
	}
}
