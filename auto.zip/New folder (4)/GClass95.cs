﻿using System;
using System.Collections.Generic;

// Token: 0x02000129 RID: 297
public class GClass95 : IDisposable
{
	// Token: 0x06000EDE RID: 3806 RVA: 0x00056484 File Offset: 0x00054684
	public void Dispose()
	{
		foreach (GClass87 gclass in this.list_0)
		{
			gclass.Dispose();
		}
	}

	// Token: 0x04000767 RID: 1895
	public char char_0 = '(';

	// Token: 0x04000768 RID: 1896
	public char char_1 = ')';

	// Token: 0x04000769 RID: 1897
	public char char_2 = '{';

	// Token: 0x0400076A RID: 1898
	public char char_3 = '}';

	// Token: 0x0400076B RID: 1899
	public GEnum14 genum14_0 = GEnum14.Strategy2;

	// Token: 0x0400076C RID: 1900
	public readonly List<GClass87> list_0 = new List<GClass87>();

	// Token: 0x0400076D RID: 1901
	public readonly List<GClass96> list_1 = new List<GClass96>();

	// Token: 0x0400076E RID: 1902
	public readonly List<GClass97> list_2 = new List<GClass97>();
}
