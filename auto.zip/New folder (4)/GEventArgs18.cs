﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000F9 RID: 249
public class GEventArgs18 : EventArgs
{
	// Token: 0x1700036D RID: 877
	// (get) Token: 0x06000CE6 RID: 3302 RVA: 0x0000B48E File Offset: 0x0000968E
	// (set) Token: 0x06000CE7 RID: 3303 RVA: 0x0000B496 File Offset: 0x00009696
	public string String_0 { get; private set; }

	// Token: 0x1700036E RID: 878
	// (get) Token: 0x06000CE8 RID: 3304 RVA: 0x0000B49F File Offset: 0x0000969F
	// (set) Token: 0x06000CE9 RID: 3305 RVA: 0x0000B4A7 File Offset: 0x000096A7
	public int Int32_0 { get; private set; }

	// Token: 0x1700036F RID: 879
	// (get) Token: 0x06000CEA RID: 3306 RVA: 0x0000B4B0 File Offset: 0x000096B0
	// (set) Token: 0x06000CEB RID: 3307 RVA: 0x0000B4B8 File Offset: 0x000096B8
	public string String_1 { get; set; }

	// Token: 0x06000CEC RID: 3308 RVA: 0x0000B4C1 File Offset: 0x000096C1
	public GEventArgs18(string string_2, int int_1)
	{
		this.String_0 = string_2;
		this.Int32_0 = int_1;
		this.String_1 = string_2;
	}

	// Token: 0x04000612 RID: 1554
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04000613 RID: 1555
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000614 RID: 1556
	[CompilerGenerated]
	private string string_1;
}
