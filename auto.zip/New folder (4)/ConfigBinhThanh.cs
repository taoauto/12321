﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x02000328 RID: 808
public class ConfigBinhThanh : UserControl
{
	// Token: 0x06002E4B RID: 11851 RVA: 0x00021A81 File Offset: 0x0001FC81
	public ConfigBinhThanh()
	{
		this.InitializeComponent();
		base.Tag = "Cài Đặt Đánh Cọc Binh Thánh";
	}

	// Token: 0x06002E4C RID: 11852 RVA: 0x00135D64 File Offset: 0x00133F64
	private void ConfigBinhThanh_Load(object sender, EventArgs e)
	{
		if (Class159.Class220_0.method_0("Config", "BinhThanh").Trim() == string.Empty || !Class159.Class220_0.method_0("Config", "BinhThanh").Contains("["))
		{
			Class159.Class220_0.method_1("Config", "BinhThanh", "[Băng][Hỏa][Nội]");
		}
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (Class159.Class220_0.method_0("Config", "BinhThanh").Trim().Contains("[" + listViewItem.Text + "]"))
			{
				listViewItem.Checked = true;
			}
		}
	}

	// Token: 0x06002E4D RID: 11853 RVA: 0x00135E58 File Offset: 0x00134058
	private void method_0(object sender, FormClosingEventArgs e)
	{
		string text = "";
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Checked)
			{
				text = text + "[" + listViewItem.Text + "]";
			}
		}
		Class159.Class220_0.method_1("Config", "BinhThanh", text);
	}

	// Token: 0x06002E4E RID: 11854 RVA: 0x00135EEC File Offset: 0x001340EC
	private void method_1(object sender, EventArgs e)
	{
		string text = "";
		foreach (object obj in this.listViewEx1.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			if (listViewItem.Checked)
			{
				text = text + "[" + listViewItem.Text + "]";
			}
		}
		Class159.Class220_0.method_1("Config", "BinhThanh", text);
		base.Dispose();
	}

	// Token: 0x06002E4F RID: 11855 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button1_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06002E50 RID: 11856 RVA: 0x00021A9A File Offset: 0x0001FC9A
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06002E51 RID: 11857 RVA: 0x00135F84 File Offset: 0x00134184
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ConfigBinhThanh));
		ListViewItem listViewItem = new ListViewItem("Băng");
		ListViewItem listViewItem2 = new ListViewItem("Huyền");
		ListViewItem listViewItem3 = new ListViewItem("Hỏa");
		ListViewItem listViewItem4 = new ListViewItem("Độc");
		ListViewItem listViewItem5 = new ListViewItem("Nội");
		ListViewItem listViewItem6 = new ListViewItem("Ngoại");
		this.listViewEx1 = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.button1 = new Button();
		base.SuspendLayout();
		this.listViewEx1.AllowColumnReorder = true;
		this.listViewEx1.AllowDrop = true;
		this.listViewEx1.AllowReorder = true;
		this.listViewEx1.AllowSort = false;
		this.listViewEx1.CheckBoxes = true;
		this.listViewEx1.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.listViewEx1.Dock = DockStyle.Fill;
		this.listViewEx1.DoubleClickActivation = false;
		this.listViewEx1.FullRowSelect = true;
		this.listViewEx1.GridLines = true;
		this.listViewEx1.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewEx1.hideItems");
		this.listViewEx1.HideSelection = false;
		listViewItem.StateImageIndex = 0;
		listViewItem2.StateImageIndex = 0;
		listViewItem3.StateImageIndex = 0;
		listViewItem4.StateImageIndex = 0;
		listViewItem5.StateImageIndex = 0;
		listViewItem6.StateImageIndex = 0;
		this.listViewEx1.Items.AddRange(new ListViewItem[]
		{
			listViewItem,
			listViewItem2,
			listViewItem3,
			listViewItem4,
			listViewItem5,
			listViewItem6
		});
		this.listViewEx1.LineColor = Color.Red;
		this.listViewEx1.Location = new Point(0, 0);
		this.listViewEx1.Name = "listViewEx1";
		this.listViewEx1.Size = new Size(263, 240);
		this.listViewEx1.TabIndex = 1;
		this.listViewEx1.Tag = "Đánh Cọc Binh Thánh";
		this.listViewEx1.UseCompatibleStateImageBehavior = false;
		this.listViewEx1.View = View.Details;
		this.columnHeader_0.Text = "Đội Trên (Đội 2) => Sẽ Đánh Cọc";
		this.columnHeader_0.Width = 214;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 240);
		this.button1.Name = "button1";
		this.button1.Size = new Size(263, 23);
		this.button1.TabIndex = 2;
		this.button1.Text = "Ok";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.listViewEx1);
		base.Controls.Add(this.button1);
		base.Name = "ConfigBinhThanh";
		base.Size = new Size(263, 263);
		base.Load += this.ConfigBinhThanh_Load;
		base.ResumeLayout(false);
	}

	// Token: 0x04001F9D RID: 8093
	private IContainer icontainer_0;

	// Token: 0x04001F9E RID: 8094
	private ListViewEx listViewEx1;

	// Token: 0x04001F9F RID: 8095
	private ColumnHeader columnHeader_0;

	// Token: 0x04001FA0 RID: 8096
	private Button button1;
}
