﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x0200020C RID: 524
internal class ChatLogs : UserControl
{
	// Token: 0x06001B25 RID: 6949 RVA: 0x00013A11 File Offset: 0x00011C11
	public ChatLogs()
	{
		this.InitializeComponent();
		ChatLogs.chatLogs_0 = this;
	}

	// Token: 0x17000678 RID: 1656
	// (get) Token: 0x06001B26 RID: 6950 RVA: 0x00013A32 File Offset: 0x00011C32
	public static ChatLogs ChatLogs_0
	{
		get
		{
			if (ChatLogs.chatLogs_0 == null || ChatLogs.chatLogs_0.IsDisposed)
			{
				ChatLogs.chatLogs_0 = new ChatLogs();
				ChatLogs.listViewEx_0 = ChatLogs.chatLogs_0.listViewChat;
			}
			return ChatLogs.chatLogs_0;
		}
	}

	// Token: 0x06001B27 RID: 6951 RVA: 0x00013A65 File Offset: 0x00011C65
	private void ChatLogs_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001B28 RID: 6952 RVA: 0x000D01A0 File Offset: 0x000CE3A0
	public void method_0()
	{
		this.listViewChat.dicHides.Clear();
		this.listViewChat.hideItems.Clear();
		this.listViewChat.Items.Clear();
		try
		{
			List<ListViewItem> list = new List<ListViewItem>();
			foreach (string text in Class159.Class220_0.method_0("Item", "Chat").Split(new char[]
			{
				'\n'
			}))
			{
				try
				{
					ListViewItem listViewItem = new ListViewItem(text.Split(new char[]
					{
						'#'
					}, 2)[0]);
					try
					{
						listViewItem.SubItems.Add(text.Split(new char[]
						{
							'#'
						}, 2)[1].Split(new char[]
						{
							':'
						}, 2)[0].Split(new string[]
						{
							"->"
						}, StringSplitOptions.None)[0].Replace("[", "").Replace("]", ""));
						listViewItem.SubItems.Add(text.Split(new char[]
						{
							'#'
						}, 2)[1].Split(new char[]
						{
							':'
						}, 2)[0].Split(new string[]
						{
							"->"
						}, StringSplitOptions.None)[1].Replace("[", "").Replace("]", ""));
						listViewItem.Tag = text;
					}
					catch
					{
					}
					listViewItem.SubItems.Add(text.Split(new char[]
					{
						'#'
					}, 2)[1].Split(new char[]
					{
						':'
					}, 2)[1]);
					list.Add(listViewItem);
				}
				catch
				{
				}
			}
			list.Reverse();
			this.listViewChat.Items.AddRange(list.ToArray());
			this.listViewChat.ScrollToEnd();
		}
		catch
		{
		}
	}

	// Token: 0x06001B29 RID: 6953 RVA: 0x000D03D4 File Offset: 0x000CE5D4
	private void listViewChat_DoubleClick(object sender, EventArgs e)
	{
		if (this.listViewChat.SelectedItems.Count == 0)
		{
			return;
		}
		ListViewItem listViewItem = this.listViewChat.SelectedItems[0];
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			if (listViewItem.SubItems[1].Text.Contains(keyValuePair.Value.Class432_0.String_2))
			{
				keyValuePair.Value.method_223();
			}
		}
	}

	// Token: 0x17000679 RID: 1657
	// (get) Token: 0x06001B2A RID: 6954 RVA: 0x00013A6D File Offset: 0x00011C6D
	// (set) Token: 0x06001B2B RID: 6955 RVA: 0x00013A74 File Offset: 0x00011C74
	public static bool Boolean_0 { get; set; }

	// Token: 0x06001B2C RID: 6956 RVA: 0x00002E18 File Offset: 0x00001018
	private void listViewChat_MouseMove(object sender, MouseEventArgs e)
	{
	}

	// Token: 0x06001B2D RID: 6957 RVA: 0x000D047C File Offset: 0x000CE67C
	private void listViewChat_MouseClick(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right && ChatLogs.listViewEx_0.SelectedItems.Count > 0)
		{
			ChatLogs.Class242 @class = new ChatLogs.Class242();
			@class.string_0 = ChatLogs.listViewEx_0.SelectedItems[0].SubItems[1].Text;
			@class.string_0 = Class426.smethod_13(@class.string_0, "[", "]");
			Main.dictionary_3.ToList<KeyValuePair<int, Class159>>().ForEach(new Action<KeyValuePair<int, Class159>>(@class.method_0));
		}
	}

	// Token: 0x06001B2E RID: 6958 RVA: 0x00013A7C File Offset: 0x00011C7C
	private void textBoxEx1_TextChanged(object sender, EventArgs e)
	{
		ChatLogs.listViewEx_0.Search(this.textBoxEx1.Text);
	}

	// Token: 0x06001B2F RID: 6959 RVA: 0x000D050C File Offset: 0x000CE70C
	private void listViewChat_SelectedIndexChanged(object sender, EventArgs e)
	{
		ListView listView = sender as ListView;
		if (listView.SelectedItems.Count > 0)
		{
			this.txtContent.Text = string.Concat(new string[]
			{
				listView.SelectedItems[0].SubItems[0].Text,
				"\t",
				listView.SelectedItems[0].SubItems[1].Text,
				"\t",
				listView.SelectedItems[0].SubItems[2].Text,
				"\r\n\r\n",
				listView.SelectedItems[0].SubItems[3].Text
			});
		}
	}

	// Token: 0x1700067A RID: 1658
	// (get) Token: 0x06001B30 RID: 6960 RVA: 0x00013A94 File Offset: 0x00011C94
	// (set) Token: 0x06001B31 RID: 6961 RVA: 0x00013A9B File Offset: 0x00011C9B
	public static bool Boolean_1 { get; set; } = true;

	// Token: 0x06001B32 RID: 6962 RVA: 0x000D05DC File Offset: 0x000CE7DC
	private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
	{
		while (this.listViewChat.SelectedItems.Count > 0)
		{
			this.listViewChat.SelectedItems[0].Remove();
		}
		Class159.Class220_0.method_1("Item", "Chat", string.Join("\n", this.listViewChat.Items.Cast<ListViewItem>().Select(new Func<ListViewItem, string>(ChatLogs.Class243.<>9.method_0)).ToArray<string>()));
	}

	// Token: 0x06001B33 RID: 6963 RVA: 0x00013AA3 File Offset: 0x00011CA3
	private void listViewChat_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.A && e.Control)
		{
			this.listViewChat.smethod_12();
		}
	}

	// Token: 0x06001B34 RID: 6964 RVA: 0x00013AC2 File Offset: 0x00011CC2
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001B35 RID: 6965 RVA: 0x000D066C File Offset: 0x000CE86C
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ChatLogs));
		this.toolTip_0 = new ToolTip(this.icontainer_0);
		this.listViewChat = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_2 = new ColumnHeader();
		this.columnHeader_3 = new ColumnHeader();
		this.contextMenuStrip1 = new ContextMenuStrip(this.icontainer_0);
		this.deleteToolStripMenuItem = new ToolStripMenuItem();
		this.txtContent = new Class85();
		this.textBoxEx1 = new Class85();
		this.contextMenuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.toolTip_0.AutoPopDelay = 5000;
		this.toolTip_0.BackColor = Color.FromArgb(64, 64, 64);
		this.toolTip_0.ForeColor = Color.FromArgb(0, 192, 0);
		this.toolTip_0.InitialDelay = 100;
		this.toolTip_0.ReshowDelay = 100;
		this.toolTip_0.ShowAlways = true;
		this.listViewChat.AllowColumnReorder = true;
		this.listViewChat.AllowDrop = true;
		this.listViewChat.AllowReorder = true;
		this.listViewChat.AllowSort = false;
		this.listViewChat.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1,
			this.columnHeader_2,
			this.columnHeader_3
		});
		this.listViewChat.ContextMenuStrip = this.contextMenuStrip1;
		this.listViewChat.Dock = DockStyle.Fill;
		this.listViewChat.DoubleClickActivation = false;
		this.listViewChat.FullRowSelect = true;
		this.listViewChat.GridLines = true;
		this.listViewChat.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("listViewChat.hideItems");
		this.listViewChat.HideSelection = false;
		this.listViewChat.LineColor = Color.Red;
		this.listViewChat.Location = new Point(0, 20);
		this.listViewChat.Name = "listViewChat";
		this.listViewChat.ShowItemToolTips = true;
		this.listViewChat.Size = new Size(677, 394);
		this.listViewChat.TabIndex = 0;
		this.listViewChat.UseCompatibleStateImageBehavior = false;
		this.listViewChat.View = View.Details;
		this.listViewChat.SelectedIndexChanged += this.listViewChat_SelectedIndexChanged;
		this.listViewChat.DoubleClick += this.listViewChat_DoubleClick;
		this.listViewChat.KeyDown += this.listViewChat_KeyDown;
		this.listViewChat.MouseClick += this.listViewChat_MouseClick;
		this.listViewChat.MouseMove += this.listViewChat_MouseMove;
		this.columnHeader_0.Text = "Time";
		this.columnHeader_0.Width = 74;
		this.columnHeader_1.Text = "From";
		this.columnHeader_1.Width = 70;
		this.columnHeader_2.Text = "To";
		this.columnHeader_2.Width = 70;
		this.columnHeader_3.Text = "Message";
		this.columnHeader_3.Width = 247;
		this.contextMenuStrip1.Items.AddRange(new ToolStripItem[]
		{
			this.deleteToolStripMenuItem
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new Size(108, 26);
		this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
		this.deleteToolStripMenuItem.Size = new Size(107, 22);
		this.deleteToolStripMenuItem.Text = "Delete";
		this.deleteToolStripMenuItem.Click += this.deleteToolStripMenuItem_Click;
		this.txtContent.Dock = DockStyle.Bottom;
		this.txtContent.Location = new Point(0, 414);
		this.txtContent.Multiline = true;
		this.txtContent.Name = "txtContent";
		this.txtContent.Size = new Size(677, 63);
		this.txtContent.TabIndex = 4;
		this.txtContent.String_0 = "Content...";
		this.txtContent.Color_0 = Color.Gray;
		this.txtContent.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.txtContent.Color_1 = Color.LightGray;
		this.textBoxEx1.Dock = DockStyle.Top;
		this.textBoxEx1.Location = new Point(0, 0);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new Size(677, 20);
		this.textBoxEx1.TabIndex = 3;
		this.textBoxEx1.String_0 = "Search...";
		this.textBoxEx1.Color_0 = Color.Gray;
		this.textBoxEx1.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = Color.LightGray;
		this.textBoxEx1.TextChanged += this.textBoxEx1_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.listViewChat);
		base.Controls.Add(this.txtContent);
		base.Controls.Add(this.textBoxEx1);
		base.Name = "ChatLogs";
		base.Size = new Size(677, 477);
		base.Load += this.ChatLogs_Load;
		this.contextMenuStrip1.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400113C RID: 4412
	private static ChatLogs chatLogs_0;

	// Token: 0x0400113D RID: 4413
	public static ListViewEx listViewEx_0;

	// Token: 0x0400113E RID: 4414
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x0400113F RID: 4415
	private Point point_0 = new Point(-1, -1);

	// Token: 0x04001140 RID: 4416
	[CompilerGenerated]
	private static bool bool_1;

	// Token: 0x04001141 RID: 4417
	private IContainer icontainer_0;

	// Token: 0x04001142 RID: 4418
	private ListViewEx listViewChat;

	// Token: 0x04001143 RID: 4419
	private ColumnHeader columnHeader_0;

	// Token: 0x04001144 RID: 4420
	private ColumnHeader columnHeader_1;

	// Token: 0x04001145 RID: 4421
	private ColumnHeader columnHeader_2;

	// Token: 0x04001146 RID: 4422
	private ToolTip toolTip_0;

	// Token: 0x04001147 RID: 4423
	private Class85 textBoxEx1;

	// Token: 0x04001148 RID: 4424
	private Class85 txtContent;

	// Token: 0x04001149 RID: 4425
	private ColumnHeader columnHeader_3;

	// Token: 0x0400114A RID: 4426
	private ContextMenuStrip contextMenuStrip1;

	// Token: 0x0400114B RID: 4427
	private ToolStripMenuItem deleteToolStripMenuItem;

	// Token: 0x0200020D RID: 525
	[CompilerGenerated]
	private sealed class Class242
	{
		// Token: 0x06001B38 RID: 6968 RVA: 0x00013AE9 File Offset: 0x00011CE9
		internal void method_0(KeyValuePair<int, Class159> keyValuePair_0)
		{
			keyValuePair_0.Value.method_282("setmetatable(_G, {__index = ChatFrame_Env}); ChatFrame_SetEditBoxTxt('/" + this.string_0 + " ');", false);
		}

		// Token: 0x0400114C RID: 4428
		public string string_0;
	}

	// Token: 0x0200020E RID: 526
	[CompilerGenerated]
	[Serializable]
	private sealed class Class243
	{
		// Token: 0x06001B3B RID: 6971 RVA: 0x00013B19 File Offset: 0x00011D19
		internal string method_0(ListViewItem listViewItem_0)
		{
			return listViewItem_0.Tag.ToString();
		}

		// Token: 0x0400114D RID: 4429
		public static readonly ChatLogs.Class243 <>9 = new ChatLogs.Class243();

		// Token: 0x0400114E RID: 4430
		public static Func<ListViewItem, string> <>9__21_0;
	}
}
