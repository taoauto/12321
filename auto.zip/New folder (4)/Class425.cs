﻿using System;

// Token: 0x02000304 RID: 772
internal class Class425
{
	// Token: 0x06002C25 RID: 11301 RVA: 0x00020481 File Offset: 0x0001E681
	public static int[,] smethod_0(int int_2)
	{
		return new int[0, 0];
	}

	// Token: 0x04001DB7 RID: 7607
	public static int[,] int_0 = new int[,]
	{
		{
			13,
			29
		},
		{
			32,
			34
		},
		{
			48,
			34
		},
		{
			32,
			20
		},
		{
			40,
			18
		}
	};

	// Token: 0x04001DB8 RID: 7608
	public static int[,] int_1 = new int[,]
	{
		{
			45,
			82
		},
		{
			45,
			75
		},
		{
			49,
			68
		},
		{
			39,
			66
		},
		{
			51,
			64
		},
		{
			46,
			61
		}
	};
}
