﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000231 RID: 561
internal class Class266 : Panel
{
	// Token: 0x06001E7B RID: 7803 RVA: 0x000E2E18 File Offset: 0x000E1018
	public Class266()
	{
		this.DoubleBuffered = true;
		base.Padding = new Padding(2);
		this.textBox_0 = new TextBox();
		this.textBox_0.AutoSize = false;
		this.textBox_0.BorderStyle = BorderStyle.None;
		this.textBox_0.Dock = DockStyle.Fill;
		this.textBox_0.MaxLength = 4;
		this.textBox_0.KeyPress += this.textBox_0_KeyPress;
		this.textBox_0.Enter += this.textBox_0_Resize;
		this.textBox_0.Leave += this.textBox_0_Resize;
		this.textBox_0.Resize += this.textBox_0_Resize;
		base.Controls.Add(this.textBox_0);
	}

	// Token: 0x06001E7C RID: 7804 RVA: 0x00016998 File Offset: 0x00014B98
	private void textBox_0_KeyPress(object sender, KeyPressEventArgs e)
	{
		if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
		{
			e.Handled = true;
		}
	}

	// Token: 0x06001E7D RID: 7805 RVA: 0x0000C6E7 File Offset: 0x0000A8E7
	private void textBox_0_Resize(object sender, EventArgs e)
	{
		base.Invalidate();
	}

	// Token: 0x06001E7E RID: 7806 RVA: 0x000E2EFC File Offset: 0x000E10FC
	protected virtual void OnPaint(PaintEventArgs e)
	{
		e.Graphics.Clear(SystemColors.Window);
		using (Pen pen = new Pen((this.TextBox_0.Focused || this.Boolean_0) ? this.color_1 : this.color_0))
		{
			e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.ClientSize.Width - 1, base.ClientSize.Height - 1));
		}
		base.OnPaint(e);
	}

	// Token: 0x170006C3 RID: 1731
	// (get) Token: 0x06001E7F RID: 7807 RVA: 0x000169C5 File Offset: 0x00014BC5
	// (set) Token: 0x06001E80 RID: 7808 RVA: 0x000169CD File Offset: 0x00014BCD
	public TextBox TextBox_0
	{
		get
		{
			return this.textBox_0;
		}
		set
		{
			this.textBox_0 = value;
		}
	}

	// Token: 0x170006C4 RID: 1732
	// (get) Token: 0x06001E81 RID: 7809 RVA: 0x000169D6 File Offset: 0x00014BD6
	// (set) Token: 0x06001E82 RID: 7810 RVA: 0x000169DE File Offset: 0x00014BDE
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x040012E9 RID: 4841
	private TextBox textBox_0;

	// Token: 0x040012EA RID: 4842
	private bool bool_0;

	// Token: 0x040012EB RID: 4843
	private Color color_0 = Color.Gray;

	// Token: 0x040012EC RID: 4844
	private Color color_1 = Color.Red;
}
