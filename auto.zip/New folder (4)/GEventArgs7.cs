﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000C0 RID: 192
public class GEventArgs7 : EventArgs
{
	// Token: 0x1700029F RID: 671
	// (get) Token: 0x06000954 RID: 2388 RVA: 0x000091A2 File Offset: 0x000073A2
	// (set) Token: 0x06000955 RID: 2389 RVA: 0x000091AA File Offset: 0x000073AA
	public GClass51 GClass51_0 { get; internal set; }

	// Token: 0x170002A0 RID: 672
	// (get) Token: 0x06000956 RID: 2390 RVA: 0x000091B3 File Offset: 0x000073B3
	// (set) Token: 0x06000957 RID: 2391 RVA: 0x000091BB File Offset: 0x000073BB
	public FastColoredTextBox FastColoredTextBox_0 { get; set; }

	// Token: 0x040004A9 RID: 1193
	[CompilerGenerated]
	private GClass51 gclass51_0;

	// Token: 0x040004AA RID: 1194
	[CompilerGenerated]
	private FastColoredTextBox fastColoredTextBox_0;
}
