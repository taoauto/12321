﻿using System;

// Token: 0x02000302 RID: 770
internal enum Enum19
{
	// Token: 0x04001D4B RID: 7499
	None
}
