﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000182 RID: 386
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct11
{
	// Token: 0x040009D2 RID: 2514
	public ushort Magic;

	// Token: 0x040009D3 RID: 2515
	public byte MajorLinkerVersion;

	// Token: 0x040009D4 RID: 2516
	public byte MinorLinkerVersion;

	// Token: 0x040009D5 RID: 2517
	public uint SizeOfCode;

	// Token: 0x040009D6 RID: 2518
	public uint SizeOfInitializedData;

	// Token: 0x040009D7 RID: 2519
	public uint SizeOfUninitializedData;

	// Token: 0x040009D8 RID: 2520
	public uint AddressOfEntryPoint;

	// Token: 0x040009D9 RID: 2521
	public uint BaseOfCode;

	// Token: 0x040009DA RID: 2522
	public uint BaseOfData;

	// Token: 0x040009DB RID: 2523
	public uint ImageBase;

	// Token: 0x040009DC RID: 2524
	public uint SectionAlignment;

	// Token: 0x040009DD RID: 2525
	public uint FileAlignment;

	// Token: 0x040009DE RID: 2526
	public ushort MajorOperatingSystemVersion;

	// Token: 0x040009DF RID: 2527
	public ushort MinorOperatingSystemVersion;

	// Token: 0x040009E0 RID: 2528
	public ushort MajorImageVersion;

	// Token: 0x040009E1 RID: 2529
	public ushort MinorImageVersion;

	// Token: 0x040009E2 RID: 2530
	public ushort MajorSubsystemVersion;

	// Token: 0x040009E3 RID: 2531
	public ushort MinorSubsystemVersion;

	// Token: 0x040009E4 RID: 2532
	public uint Win32VersionValue;

	// Token: 0x040009E5 RID: 2533
	public uint SizeOfImage;

	// Token: 0x040009E6 RID: 2534
	public uint SizeOfHeaders;

	// Token: 0x040009E7 RID: 2535
	public uint CheckSum;

	// Token: 0x040009E8 RID: 2536
	public ushort Subsystem;

	// Token: 0x040009E9 RID: 2537
	public ushort DllCharacteristics;

	// Token: 0x040009EA RID: 2538
	public uint SizeOfStackReserve;

	// Token: 0x040009EB RID: 2539
	public uint SizeOfStackCommit;

	// Token: 0x040009EC RID: 2540
	public uint SizeOfHeapReserve;

	// Token: 0x040009ED RID: 2541
	public uint SizeOfHeapCommit;

	// Token: 0x040009EE RID: 2542
	public uint LoaderFlags;

	// Token: 0x040009EF RID: 2543
	public uint NumberOfRvaAndSizes;

	// Token: 0x040009F0 RID: 2544
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
	public GStruct6[] DataDirectory;
}
