﻿using System;
using System.Security.Principal;

// Token: 0x0200008B RID: 139
public class GClass35 : GenericIdentity
{
	// Token: 0x06000666 RID: 1638 RVA: 0x00007181 File Offset: 0x00005381
	internal GClass35(string string_1, string string_2) : base(string_1, "Basic")
	{
		this.string_0 = string_2;
	}

	// Token: 0x170001A2 RID: 418
	// (get) Token: 0x06000667 RID: 1639 RVA: 0x00007196 File Offset: 0x00005396
	public virtual string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x04000312 RID: 786
	private string string_0;
}
