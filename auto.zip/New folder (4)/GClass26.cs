﻿using System;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using WebSocketSharp.Net;

// Token: 0x0200006A RID: 106
public class GClass26
{
	// Token: 0x06000468 RID: 1128 RVA: 0x00005D29 File Offset: 0x00003F29
	public GClass26()
	{
		this.method_4("*", IPAddress.Any, 80, false);
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x00005D44 File Offset: 0x00003F44
	public GClass26(int int_1) : this(int_1, int_1 == 443)
	{
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x0002EFC0 File Offset: 0x0002D1C0
	public GClass26(string string_2)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("url");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentException("An empty string.", "url");
		}
		Uri uri;
		string message;
		if (!GClass26.smethod_1(string_2, out uri, out message))
		{
			throw new ArgumentException(message, "url");
		}
		string string_3 = uri.smethod_31(true);
		IPAddress ipaddress = string_3.smethod_63();
		if (ipaddress == null)
		{
			message = "The host part could not be converted to an IP address.";
			throw new ArgumentException(message, "url");
		}
		if (!ipaddress.smethod_87())
		{
			message = "The IP address of the host is not a local IP address.";
			throw new ArgumentException(message, "url");
		}
		this.method_4(string_3, ipaddress, uri.Port, uri.Scheme == "https");
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x0002F070 File Offset: 0x0002D270
	public GClass26(int int_1, bool bool_1)
	{
		if (!int_1.smethod_46())
		{
			string message = "Less than 1 or greater than 65535.";
			throw new ArgumentOutOfRangeException("port", message);
		}
		this.method_4("*", IPAddress.Any, int_1, bool_1);
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x00005D55 File Offset: 0x00003F55
	public GClass26(IPAddress ipaddress_1, int int_1) : this(ipaddress_1, int_1, int_1 == 443)
	{
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x0002F0B0 File Offset: 0x0002D2B0
	public GClass26(IPAddress ipaddress_1, int int_1, bool bool_1)
	{
		if (ipaddress_1 == null)
		{
			throw new ArgumentNullException("address");
		}
		if (!ipaddress_1.smethod_87())
		{
			throw new ArgumentException("Not a local IP address.", "address");
		}
		if (!int_1.smethod_46())
		{
			string message = "Less than 1 or greater than 65535.";
			throw new ArgumentOutOfRangeException("port", message);
		}
		this.method_4(ipaddress_1.smethod_65(true), ipaddress_1, int_1, bool_1);
	}

	// Token: 0x17000120 RID: 288
	// (get) Token: 0x0600046E RID: 1134 RVA: 0x00005D67 File Offset: 0x00003F67
	public IPAddress IPAddress_0
	{
		get
		{
			return this.ipaddress_0;
		}
	}

	// Token: 0x17000121 RID: 289
	// (get) Token: 0x0600046F RID: 1135 RVA: 0x00005D6F File Offset: 0x00003F6F
	// (set) Token: 0x06000470 RID: 1136 RVA: 0x0002F114 File Offset: 0x0002D314
	public WebSocketSharp.Net.AuthenticationSchemes AuthenticationSchemes_0
	{
		get
		{
			return this.gclass37_0.AuthenticationSchemes_0;
		}
		set
		{
			string text;
			if (!this.method_1(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_1(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.gclass37_0.AuthenticationSchemes_0 = value;
				}
			}
		}
	}

	// Token: 0x17000122 RID: 290
	// (get) Token: 0x06000471 RID: 1137 RVA: 0x00005D7C File Offset: 0x00003F7C
	// (set) Token: 0x06000472 RID: 1138 RVA: 0x0002F18C File Offset: 0x0002D38C
	public string String_0
	{
		get
		{
			return this.string_0;
		}
		set
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (value.Length == 0)
			{
				throw new ArgumentException("An empty string.", "value");
			}
			value = value.smethod_70();
			string text = null;
			try
			{
				text = Path.GetFullPath(value);
			}
			catch (Exception innerException)
			{
				throw new ArgumentException("An invalid path string.", "value", innerException);
			}
			if (value == "/")
			{
				throw new ArgumentException("An absolute root.", "value");
			}
			if (value == "\\")
			{
				throw new ArgumentException("An absolute root.", "value");
			}
			if (value.Length == 2 && value[1] == ':')
			{
				throw new ArgumentException("An absolute root.", "value");
			}
			if (text == "/")
			{
				throw new ArgumentException("An absolute root.", "value");
			}
			text = text.smethod_70();
			if (text.Length == 2 && text[1] == ':')
			{
				throw new ArgumentException("An absolute root.", "value");
			}
			string text2;
			if (!this.method_1(out text2))
			{
				this.gclass24_0.method_6(text2);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_1(out text2))
				{
					this.gclass24_0.method_6(text2);
				}
				else
				{
					this.string_0 = value;
				}
			}
		}
	}

	// Token: 0x17000123 RID: 291
	// (get) Token: 0x06000473 RID: 1139 RVA: 0x00005D84 File Offset: 0x00003F84
	public bool Boolean_0
	{
		get
		{
			return this.enum5_0 == Enum5.Start;
		}
	}

	// Token: 0x17000124 RID: 292
	// (get) Token: 0x06000474 RID: 1140 RVA: 0x00005D91 File Offset: 0x00003F91
	public bool Boolean_1
	{
		get
		{
			return this.bool_0;
		}
	}

	// Token: 0x17000125 RID: 293
	// (get) Token: 0x06000475 RID: 1141 RVA: 0x00005D99 File Offset: 0x00003F99
	// (set) Token: 0x06000476 RID: 1142 RVA: 0x00005DA6 File Offset: 0x00003FA6
	public bool Boolean_2
	{
		get
		{
			return this.gclass30_0.Boolean_0;
		}
		set
		{
			this.gclass30_0.Boolean_0 = value;
		}
	}

	// Token: 0x17000126 RID: 294
	// (get) Token: 0x06000477 RID: 1143 RVA: 0x00005DB4 File Offset: 0x00003FB4
	public GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
	}

	// Token: 0x17000127 RID: 295
	// (get) Token: 0x06000478 RID: 1144 RVA: 0x00005DBC File Offset: 0x00003FBC
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x17000128 RID: 296
	// (get) Token: 0x06000479 RID: 1145 RVA: 0x00005DC4 File Offset: 0x00003FC4
	// (set) Token: 0x0600047A RID: 1146 RVA: 0x0002F2FC File Offset: 0x0002D4FC
	public string String_1
	{
		get
		{
			return this.gclass37_0.String_1;
		}
		set
		{
			string text;
			if (!this.method_1(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_1(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.gclass37_0.String_1 = value;
				}
			}
		}
	}

	// Token: 0x17000129 RID: 297
	// (get) Token: 0x0600047B RID: 1147 RVA: 0x00005DD1 File Offset: 0x00003FD1
	// (set) Token: 0x0600047C RID: 1148 RVA: 0x0002F374 File Offset: 0x0002D574
	public bool Boolean_3
	{
		get
		{
			return this.gclass37_0.Boolean_1;
		}
		set
		{
			string text;
			if (!this.method_1(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_1(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.gclass37_0.Boolean_1 = value;
				}
			}
		}
	}

	// Token: 0x1700012A RID: 298
	// (get) Token: 0x0600047D RID: 1149 RVA: 0x00005DDE File Offset: 0x00003FDE
	public GClass44 GClass44_0
	{
		get
		{
			if (!this.bool_0)
			{
				throw new InvalidOperationException("This instance does not provide secure connections.");
			}
			return this.gclass37_0.GClass44_0;
		}
	}

	// Token: 0x1700012B RID: 299
	// (get) Token: 0x0600047E RID: 1150 RVA: 0x00005DFE File Offset: 0x00003FFE
	// (set) Token: 0x0600047F RID: 1151 RVA: 0x0002F3EC File Offset: 0x0002D5EC
	public Func<IIdentity, GClass43> Func_0
	{
		get
		{
			return this.gclass37_0.Func_1;
		}
		set
		{
			string text;
			if (!this.method_1(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_1(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.gclass37_0.Func_1 = value;
				}
			}
		}
	}

	// Token: 0x1700012C RID: 300
	// (get) Token: 0x06000480 RID: 1152 RVA: 0x00005E0B File Offset: 0x0000400B
	// (set) Token: 0x06000481 RID: 1153 RVA: 0x00005E18 File Offset: 0x00004018
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.gclass30_0.TimeSpan_0;
		}
		set
		{
			this.gclass30_0.TimeSpan_0 = value;
		}
	}

	// Token: 0x1700012D RID: 301
	// (get) Token: 0x06000482 RID: 1154 RVA: 0x00005E26 File Offset: 0x00004026
	public GClass30 GClass30_0
	{
		get
		{
			return this.gclass30_0;
		}
	}

	// Token: 0x14000007 RID: 7
	// (add) Token: 0x06000483 RID: 1155 RVA: 0x0002F464 File Offset: 0x0002D664
	// (remove) Token: 0x06000484 RID: 1156 RVA: 0x0002F49C File Offset: 0x0002D69C
	public event EventHandler<GEventArgs5> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000008 RID: 8
	// (add) Token: 0x06000485 RID: 1157 RVA: 0x0002F4D4 File Offset: 0x0002D6D4
	// (remove) Token: 0x06000486 RID: 1158 RVA: 0x0002F50C File Offset: 0x0002D70C
	public event EventHandler<GEventArgs5> Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_1;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000009 RID: 9
	// (add) Token: 0x06000487 RID: 1159 RVA: 0x0002F544 File Offset: 0x0002D744
	// (remove) Token: 0x06000488 RID: 1160 RVA: 0x0002F57C File Offset: 0x0002D77C
	public event EventHandler<GEventArgs5> Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_2;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400000A RID: 10
	// (add) Token: 0x06000489 RID: 1161 RVA: 0x0002F5B4 File Offset: 0x0002D7B4
	// (remove) Token: 0x0600048A RID: 1162 RVA: 0x0002F5EC File Offset: 0x0002D7EC
	public event EventHandler<GEventArgs5> Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_3;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_3;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400000B RID: 11
	// (add) Token: 0x0600048B RID: 1163 RVA: 0x0002F624 File Offset: 0x0002D824
	// (remove) Token: 0x0600048C RID: 1164 RVA: 0x0002F65C File Offset: 0x0002D85C
	public event EventHandler<GEventArgs5> Event_4
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_4;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_4;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400000C RID: 12
	// (add) Token: 0x0600048D RID: 1165 RVA: 0x0002F694 File Offset: 0x0002D894
	// (remove) Token: 0x0600048E RID: 1166 RVA: 0x0002F6CC File Offset: 0x0002D8CC
	public event EventHandler<GEventArgs5> Event_5
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_5;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400000D RID: 13
	// (add) Token: 0x0600048F RID: 1167 RVA: 0x0002F704 File Offset: 0x0002D904
	// (remove) Token: 0x06000490 RID: 1168 RVA: 0x0002F73C File Offset: 0x0002D93C
	public event EventHandler<GEventArgs5> Event_6
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_6;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_6;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400000E RID: 14
	// (add) Token: 0x06000491 RID: 1169 RVA: 0x0002F774 File Offset: 0x0002D974
	// (remove) Token: 0x06000492 RID: 1170 RVA: 0x0002F7AC File Offset: 0x0002D9AC
	public event EventHandler<GEventArgs5> Event_7
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_7;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs5> eventHandler = this.eventHandler_7;
			EventHandler<GEventArgs5> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs5> value2 = (EventHandler<GEventArgs5>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs5>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x0002F7E4 File Offset: 0x0002D9E4
	private void method_0()
	{
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				return;
			}
			this.enum5_0 = Enum5.ShuttingDown;
		}
		try
		{
			try
			{
				this.gclass30_0.method_9(1006, string.Empty);
			}
			finally
			{
				this.gclass37_0.method_16();
			}
		}
		catch
		{
		}
		this.enum5_0 = Enum5.Stop;
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x00005E2E File Offset: 0x0000402E
	private bool method_1(out string string_2)
	{
		string_2 = null;
		if (this.enum5_0 == Enum5.Start)
		{
			string_2 = "The server has already started.";
			return false;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			string_2 = "The server is shutting down.";
			return false;
		}
		return true;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x0002F880 File Offset: 0x0002DA80
	private bool method_2(out string string_2)
	{
		string_2 = null;
		bool flag = this.gclass37_0.GClass44_0.X509Certificate2_0 != null;
		string text = this.gclass37_0.String_0;
		bool flag2 = Class68.smethod_7(this.int_0, text);
		if (!flag && !flag2)
		{
			string_2 = "There is no server certificate for secure connection.";
			return false;
		}
		if (flag && flag2)
		{
			this.gclass24_0.method_6("The server certificate associated with the port is used.");
		}
		return true;
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x00005E5C File Offset: 0x0000405C
	private string method_3(string string_2)
	{
		string_2 = string_2.TrimStart(new char[]
		{
			'/',
			'\\'
		});
		return new StringBuilder(this.string_0, 32).AppendFormat("/{0}", string_2).ToString().Replace('\\', '/');
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x0002F8E4 File Offset: 0x0002DAE4
	private static GClass37 smethod_0(string string_2, int int_1, bool bool_1)
	{
		GClass37 gclass = new GClass37();
		string arg = bool_1 ? "https" : "http";
		string uriPrefix = string.Format("{0}://{1}:{2}/", arg, string_2, int_1);
		gclass.GClass39_0.Add(uriPrefix);
		return gclass;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x0002F928 File Offset: 0x0002DB28
	private void method_4(string string_2, IPAddress ipaddress_1, int int_1, bool bool_1)
	{
		this.string_1 = string_2;
		this.ipaddress_0 = ipaddress_1;
		this.int_0 = int_1;
		this.bool_0 = bool_1;
		this.string_0 = "./Public";
		this.gclass37_0 = GClass26.smethod_0(this.string_1, this.int_0, this.bool_0);
		this.gclass24_0 = this.gclass37_0.GClass24_0;
		this.gclass30_0 = new GClass30(this.gclass24_0);
		this.object_0 = new object();
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x0002F9A8 File Offset: 0x0002DBA8
	private void method_5(GClass38 gclass38_0)
	{
		string string_ = gclass38_0.GClass40_0.String_2;
		EventHandler<GEventArgs5> eventHandler = (string_ == "GET") ? this.eventHandler_2 : ((string_ == "HEAD") ? this.eventHandler_3 : ((string_ == "POST") ? this.eventHandler_5 : ((string_ == "PUT") ? this.eventHandler_6 : ((string_ == "DELETE") ? this.eventHandler_1 : ((string_ == "CONNECT") ? this.eventHandler_0 : ((string_ == "OPTIONS") ? this.eventHandler_4 : ((string_ == "TRACE") ? this.eventHandler_7 : null)))))));
		if (eventHandler != null)
		{
			eventHandler(this, new GEventArgs5(gclass38_0, this.string_0));
		}
		else
		{
			gclass38_0.GClass41_0.Int32_0 = 501;
		}
		gclass38_0.GClass41_0.method_7();
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x0002FAA4 File Offset: 0x0002DCA4
	private void method_6(GClass47 gclass47_0)
	{
		Uri uri = gclass47_0.GClass46.\u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E;
		if (uri == null)
		{
			gclass47_0.method_1(GEnum9.BadRequest);
			return;
		}
		string text = uri.AbsolutePath;
		if (text.IndexOfAny(new char[]
		{
			'%',
			'+'
		}) > -1)
		{
			text = Class78.smethod_27(text, Encoding.UTF8);
		}
		GClass29 gclass;
		if (!this.gclass30_0.method_7(text, out gclass))
		{
			gclass47_0.method_1(GEnum9.NotImplemented);
			return;
		}
		gclass.method_1(gclass47_0);
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x0002FB1C File Offset: 0x0002DD1C
	private void method_7()
	{
		for (;;)
		{
			GClass26.Class51 @class = new GClass26.Class51();
			@class.gclass26_0 = this;
			@class.gclass38_0 = null;
			try
			{
				@class.gclass38_0 = this.gclass37_0.method_20();
				ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
				continue;
			}
			catch (GException5)
			{
				this.gclass24_0.method_4("The underlying listener is stopped.");
			}
			catch (InvalidOperationException)
			{
				this.gclass24_0.method_4("The underlying listener is stopped.");
			}
			catch (Exception ex)
			{
				this.gclass24_0.method_3(ex.Message);
				this.gclass24_0.method_1(ex.ToString());
				if (@class.gclass38_0 != null)
				{
					@class.gclass38_0.Class70_0.method_10(true);
				}
			}
			break;
		}
		if (this.enum5_0 != Enum5.ShuttingDown)
		{
			this.method_0();
		}
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x0002FC00 File Offset: 0x0002DE00
	private void method_8()
	{
		if (this.enum5_0 == Enum5.Start)
		{
			this.gclass24_0.method_4("The server has already started.");
			return;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			this.gclass24_0.method_6("The server is shutting down.");
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 == Enum5.Start)
			{
				this.gclass24_0.method_4("The server has already started.");
			}
			else if (this.enum5_0 == Enum5.ShuttingDown)
			{
				this.gclass24_0.method_6("The server is shutting down.");
			}
			else
			{
				this.gclass30_0.method_8();
				try
				{
					this.method_9();
				}
				catch
				{
					this.gclass30_0.method_9(1011, string.Empty);
					throw;
				}
				this.enum5_0 = Enum5.Start;
			}
		}
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x0002FCEC File Offset: 0x0002DEEC
	private void method_9()
	{
		try
		{
			this.gclass37_0.method_21();
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException("The underlying listener has failed to start.", innerException);
		}
		this.thread_0 = new Thread(new ThreadStart(this.method_7));
		this.thread_0.IsBackground = true;
		this.thread_0.Start();
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x0002FD54 File Offset: 0x0002DF54
	private void method_10(ushort ushort_0, string string_2)
	{
		if (this.enum5_0 == Enum5.Ready)
		{
			this.gclass24_0.method_4("The server is not started.");
			return;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			this.gclass24_0.method_4("The server is shutting down.");
			return;
		}
		if (this.enum5_0 == Enum5.Stop)
		{
			this.gclass24_0.method_4("The server has already stopped.");
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 == Enum5.ShuttingDown)
			{
				this.gclass24_0.method_4("The server is shutting down.");
				return;
			}
			if (this.enum5_0 == Enum5.Stop)
			{
				this.gclass24_0.method_4("The server has already stopped.");
				return;
			}
			this.enum5_0 = Enum5.ShuttingDown;
		}
		try
		{
			bool flag2 = false;
			try
			{
				this.gclass30_0.method_9(ushort_0, string_2);
			}
			catch
			{
				flag2 = true;
				throw;
			}
			finally
			{
				try
				{
					this.method_11(5000);
				}
				catch
				{
					if (!flag2)
					{
						throw;
					}
				}
			}
		}
		finally
		{
			this.enum5_0 = Enum5.Stop;
		}
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x00005E9C File Offset: 0x0000409C
	private void method_11(int int_1)
	{
		this.gclass37_0.method_22();
		this.thread_0.Join(int_1);
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x0002FE8C File Offset: 0x0002E08C
	private static bool smethod_1(string string_2, out Uri uri_0, out string string_3)
	{
		uri_0 = null;
		string_3 = null;
		Uri uri = string_2.smethod_105();
		if (uri == null)
		{
			string_3 = "An invalid URI string.";
			return false;
		}
		if (!uri.IsAbsoluteUri)
		{
			string_3 = "A relative URI.";
			return false;
		}
		string scheme = uri.Scheme;
		if (!(scheme == "http") && !(scheme == "https"))
		{
			string_3 = "The scheme part is not 'http' or 'https'.";
			return false;
		}
		if (uri.PathAndQuery != "/")
		{
			string_3 = "It includes either or both path and query components.";
			return false;
		}
		if (uri.Fragment.Length > 0)
		{
			string_3 = "It includes the fragment component.";
			return false;
		}
		if (uri.Port == 0)
		{
			string_3 = "The port part is zero.";
			return false;
		}
		uri_0 = uri;
		return true;
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x0002FF3C File Offset: 0x0002E13C
	[Obsolete("This method will be removed. Use added one instead.")]
	public void method_12<T>(string string_2, Func<T> func_0) where T : GClass27
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (func_0 == null)
		{
			throw new ArgumentNullException("creator");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_2[0] != '/')
		{
			throw new ArgumentException("Not an absolute path.", "path");
		}
		if (string_2.IndexOfAny(new char[]
		{
			'?',
			'#'
		}) > -1)
		{
			throw new ArgumentException("It includes either or both query and fragment components.", "path");
		}
		this.gclass30_0.method_6<T>(string_2, func_0);
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x00005EB6 File Offset: 0x000040B6
	public void method_13<T>(string string_2) where T : GClass27, new()
	{
		this.gclass30_0.method_10<T>(string_2, null);
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x00005EC5 File Offset: 0x000040C5
	public void method_14<T>(string string_2, Action<T> action_0) where T : GClass27, new()
	{
		this.gclass30_0.method_10<T>(string_2, action_0);
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x0002FFD0 File Offset: 0x0002E1D0
	[Obsolete("This method will be removed.")]
	public byte[] method_15(string string_2)
	{
		if (string_2 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (string_2.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_2.IndexOf("..") > -1)
		{
			throw new ArgumentException("It contains '..'.", "path");
		}
		string_2 = this.method_3(string_2);
		if (!File.Exists(string_2))
		{
			return null;
		}
		return File.ReadAllBytes(string_2);
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x00005ED4 File Offset: 0x000040D4
	public bool method_16(string string_2)
	{
		return this.gclass30_0.method_19(string_2);
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x0003003C File Offset: 0x0002E23C
	public void method_17()
	{
		string message;
		if (this.bool_0 && !this.method_2(out message))
		{
			throw new InvalidOperationException(message);
		}
		this.method_8();
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x00005EE2 File Offset: 0x000040E2
	public void method_18()
	{
		this.method_10(1001, string.Empty);
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x00030068 File Offset: 0x0002E268
	[Obsolete("This method will be removed.")]
	public void method_19(ushort ushort_0, string string_2)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		if (!string_2.smethod_88())
		{
			if (ushort_0 == 1005)
			{
				throw new ArgumentException("1005 cannot be used.", "code");
			}
			byte[] array;
			if (!string_2.smethod_74(out array))
			{
				throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
			}
			if (array.Length > 123)
			{
				string message2 = "Its size is greater than 123 bytes.";
				throw new ArgumentOutOfRangeException("reason", message2);
			}
		}
		this.method_10(ushort_0, string_2);
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x00030104 File Offset: 0x0002E304
	[Obsolete("This method will be removed.")]
	public void method_20(GEnum6 genum6_0, string string_2)
	{
		if (genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		if (!string_2.smethod_88())
		{
			if (genum6_0 == GEnum6.NoStatus)
			{
				throw new ArgumentException("NoStatus cannot be used.", "code");
			}
			byte[] array;
			if (!string_2.smethod_74(out array))
			{
				throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
			}
			if (array.Length > 123)
			{
				string message = "Its size is greater than 123 bytes.";
				throw new ArgumentOutOfRangeException("reason", message);
			}
		}
		this.method_10((ushort)genum6_0, string_2);
	}

	// Token: 0x04000268 RID: 616
	private IPAddress ipaddress_0;

	// Token: 0x04000269 RID: 617
	private string string_0;

	// Token: 0x0400026A RID: 618
	private string string_1;

	// Token: 0x0400026B RID: 619
	private GClass37 gclass37_0;

	// Token: 0x0400026C RID: 620
	private GClass24 gclass24_0;

	// Token: 0x0400026D RID: 621
	private int int_0;

	// Token: 0x0400026E RID: 622
	private Thread thread_0;

	// Token: 0x0400026F RID: 623
	private bool bool_0;

	// Token: 0x04000270 RID: 624
	private GClass30 gclass30_0;

	// Token: 0x04000271 RID: 625
	private volatile Enum5 enum5_0;

	// Token: 0x04000272 RID: 626
	private object object_0;

	// Token: 0x04000273 RID: 627
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_0;

	// Token: 0x04000274 RID: 628
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_1;

	// Token: 0x04000275 RID: 629
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_2;

	// Token: 0x04000276 RID: 630
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_3;

	// Token: 0x04000277 RID: 631
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_4;

	// Token: 0x04000278 RID: 632
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_5;

	// Token: 0x04000279 RID: 633
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_6;

	// Token: 0x0400027A RID: 634
	[CompilerGenerated]
	private EventHandler<GEventArgs5> eventHandler_7;

	// Token: 0x0200006B RID: 107
	[CompilerGenerated]
	private sealed class Class51
	{
		// Token: 0x060004AB RID: 1195 RVA: 0x00030184 File Offset: 0x0002E384
		internal void method_0(object object_0)
		{
			try
			{
				if (this.gclass38_0.GClass40_0.method_6("websocket"))
				{
					this.gclass26_0.method_6(this.gclass38_0.method_3(null));
				}
				else
				{
					this.gclass26_0.method_5(this.gclass38_0);
				}
			}
			catch (Exception ex)
			{
				this.gclass26_0.gclass24_0.method_3(ex.Message);
				this.gclass26_0.gclass24_0.method_1(ex.ToString());
				this.gclass38_0.Class70_0.method_10(true);
			}
		}

		// Token: 0x0400027B RID: 635
		public GClass38 gclass38_0;

		// Token: 0x0400027C RID: 636
		public GClass26 gclass26_0;
	}
}
