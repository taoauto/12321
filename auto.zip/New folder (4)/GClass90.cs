﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;

// Token: 0x02000124 RID: 292
public class GClass90 : GClass87
{
	// Token: 0x170003D7 RID: 983
	// (get) Token: 0x06000EC7 RID: 3783 RVA: 0x0000C81F File Offset: 0x0000AA1F
	// (set) Token: 0x06000EC8 RID: 3784 RVA: 0x0000C827 File Offset: 0x0000AA27
	public Brush Brush_0 { get; set; }

	// Token: 0x170003D8 RID: 984
	// (get) Token: 0x06000EC9 RID: 3785 RVA: 0x0000C830 File Offset: 0x0000AA30
	// (set) Token: 0x06000ECA RID: 3786 RVA: 0x0000C838 File Offset: 0x0000AA38
	public Brush Brush_1 { get; private set; }

	// Token: 0x170003D9 RID: 985
	// (get) Token: 0x06000ECB RID: 3787 RVA: 0x00006FDC File Offset: 0x000051DC
	// (set) Token: 0x06000ECC RID: 3788 RVA: 0x00002E18 File Offset: 0x00001018
	public override bool \u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	// Token: 0x06000ECD RID: 3789 RVA: 0x0000C841 File Offset: 0x0000AA41
	public GClass90(Brush brush_2, Brush brush_3 = null)
	{
		this.Brush_0 = brush_2;
		this.Brush_1 = brush_3;
	}

	// Token: 0x06000ECE RID: 3790 RVA: 0x00056100 File Offset: 0x00054300
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		if (this.Brush_0 != null)
		{
			graphics_0.SmoothingMode = SmoothingMode.None;
			Rectangle rect = new Rectangle(point_0.X, point_0.Y, (gclass86_0.GStruct2_1.int_0 - gclass86_0.GStruct2_0.int_0) * gclass86_0.fastColoredTextBox_0.Int32_4, gclass86_0.fastColoredTextBox_0.Int32_2);
			if (rect.Width == 0)
			{
				return;
			}
			graphics_0.FillRectangle(this.Brush_0, rect);
			if (this.Brush_1 != null)
			{
				graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
				GClass86 gclass86_ = new GClass86(gclass86_0.fastColoredTextBox_0, gclass86_0.GStruct2_0.int_0, gclass86_0.GStruct2_0.int_1, Math.Min(gclass86_0.fastColoredTextBox_0[gclass86_0.GStruct2_1.int_1].Count, gclass86_0.GStruct2_1.int_0), gclass86_0.GStruct2_1.int_1);
				using (GClass88 gclass = new GClass88(this.Brush_1, null, FontStyle.Regular))
				{
					gclass.GClass87.\u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(graphics_0, new Point(point_0.X, point_0.Y - 1), gclass86_);
				}
			}
		}
	}

	// Token: 0x04000762 RID: 1890
	[CompilerGenerated]
	private Brush brush_0;

	// Token: 0x04000763 RID: 1891
	[CompilerGenerated]
	private Brush brush_1;
}
