﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200022F RID: 559
internal class Class264 : ToolTip
{
	// Token: 0x06001E5B RID: 7771 RVA: 0x000168D0 File Offset: 0x00014AD0
	public Class264()
	{
		base.BackColor = Color.Black;
		base.ForeColor = Color.LimeGreen;
		base.OwnerDraw = true;
		base.Draw += this.Class264_Draw;
	}

	// Token: 0x06001E5C RID: 7772 RVA: 0x00016907 File Offset: 0x00014B07
	private void Class264_Draw(object sender, DrawToolTipEventArgs e)
	{
		e.DrawBackground();
		e.DrawBorder();
		e.DrawText();
	}
}
