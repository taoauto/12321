﻿using System;

// Token: 0x020000A6 RID: 166
internal class Class80
{
	// Token: 0x060007B6 RID: 1974 RVA: 0x000081D8 File Offset: 0x000063D8
	public Class80(byte[] byte_1, int int_3, int int_4, Class77 class77_1)
	{
		this.byte_0 = byte_1;
		this.int_2 = int_3;
		this.int_0 = int_4;
		this.int_1 = int_4;
		this.class77_0 = class77_1;
	}

	// Token: 0x1700021A RID: 538
	// (get) Token: 0x060007B7 RID: 1975 RVA: 0x00008204 File Offset: 0x00006404
	// (set) Token: 0x060007B8 RID: 1976 RVA: 0x0000820C File Offset: 0x0000640C
	public Class77 Class77_0
	{
		get
		{
			return this.class77_0;
		}
		set
		{
			this.class77_0 = value;
		}
	}

	// Token: 0x1700021B RID: 539
	// (get) Token: 0x060007B9 RID: 1977 RVA: 0x00008215 File Offset: 0x00006415
	// (set) Token: 0x060007BA RID: 1978 RVA: 0x0000821D File Offset: 0x0000641D
	public byte[] Byte_0
	{
		get
		{
			return this.byte_0;
		}
		set
		{
			this.byte_0 = value;
		}
	}

	// Token: 0x1700021C RID: 540
	// (get) Token: 0x060007BB RID: 1979 RVA: 0x00008226 File Offset: 0x00006426
	// (set) Token: 0x060007BC RID: 1980 RVA: 0x0000822E File Offset: 0x0000642E
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
		set
		{
			this.int_0 = value;
		}
	}

	// Token: 0x1700021D RID: 541
	// (get) Token: 0x060007BD RID: 1981 RVA: 0x00008237 File Offset: 0x00006437
	// (set) Token: 0x060007BE RID: 1982 RVA: 0x0000823F File Offset: 0x0000643F
	public int Int32_1
	{
		get
		{
			return this.int_1;
		}
		set
		{
			this.int_1 = value;
		}
	}

	// Token: 0x1700021E RID: 542
	// (get) Token: 0x060007BF RID: 1983 RVA: 0x00008248 File Offset: 0x00006448
	// (set) Token: 0x060007C0 RID: 1984 RVA: 0x00008250 File Offset: 0x00006450
	public int Int32_2
	{
		get
		{
			return this.int_2;
		}
		set
		{
			this.int_2 = value;
		}
	}

	// Token: 0x04000435 RID: 1077
	private Class77 class77_0;

	// Token: 0x04000436 RID: 1078
	private byte[] byte_0;

	// Token: 0x04000437 RID: 1079
	private int int_0;

	// Token: 0x04000438 RID: 1080
	private int int_1;

	// Token: 0x04000439 RID: 1081
	private int int_2;
}
