﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Token: 0x0200008C RID: 140
internal sealed class Class70
{
	// Token: 0x06000668 RID: 1640 RVA: 0x00036174 File Offset: 0x00034374
	internal Class70(Socket socket_1, Class68 class68_1)
	{
		this.socket_0 = socket_1;
		this.class68_0 = class68_1;
		NetworkStream innerStream = new NetworkStream(socket_1, false);
		if (class68_1.Boolean_0)
		{
			GClass44 gclass44_ = class68_1.GClass44_0;
			SslStream sslStream = new SslStream(innerStream, false, gclass44_.RemoteCertificateValidationCallback_0);
			sslStream.AuthenticateAsServer(gclass44_.X509Certificate2_0, gclass44_.Boolean_1, gclass44_.SslProtocols_0, gclass44_.Boolean_0);
			this.bool_1 = true;
			this.stream_0 = sslStream;
		}
		else
		{
			this.stream_0 = innerStream;
		}
		this.endPoint_0 = socket_1.LocalEndPoint;
		this.endPoint_1 = socket_1.RemoteEndPoint;
		this.object_0 = new object();
		this.int_3 = 90000;
		this.dictionary_0 = new Dictionary<int, bool>();
		this.timer_0 = new Timer(new TimerCallback(Class70.smethod_1), this, -1, -1);
		this.method_5();
	}

	// Token: 0x170001A3 RID: 419
	// (get) Token: 0x06000669 RID: 1641 RVA: 0x0000719E File Offset: 0x0000539E
	public bool Boolean_0
	{
		get
		{
			return this.socket_0 == null;
		}
	}

	// Token: 0x170001A4 RID: 420
	// (get) Token: 0x0600066A RID: 1642 RVA: 0x000071A9 File Offset: 0x000053A9
	public bool Boolean_1
	{
		get
		{
			return ((IPEndPoint)this.endPoint_1).Address.smethod_87();
		}
	}

	// Token: 0x170001A5 RID: 421
	// (get) Token: 0x0600066B RID: 1643 RVA: 0x000071C0 File Offset: 0x000053C0
	public bool Boolean_2
	{
		get
		{
			return this.bool_1;
		}
	}

	// Token: 0x170001A6 RID: 422
	// (get) Token: 0x0600066C RID: 1644 RVA: 0x000071C8 File Offset: 0x000053C8
	public IPEndPoint IPEndPoint_0
	{
		get
		{
			return (IPEndPoint)this.endPoint_0;
		}
	}

	// Token: 0x170001A7 RID: 423
	// (get) Token: 0x0600066D RID: 1645 RVA: 0x000071D5 File Offset: 0x000053D5
	public IPEndPoint IPEndPoint_1
	{
		get
		{
			return (IPEndPoint)this.endPoint_1;
		}
	}

	// Token: 0x170001A8 RID: 424
	// (get) Token: 0x0600066E RID: 1646 RVA: 0x000071E2 File Offset: 0x000053E2
	public int Int32_0
	{
		get
		{
			return this.int_2;
		}
	}

	// Token: 0x170001A9 RID: 425
	// (get) Token: 0x0600066F RID: 1647 RVA: 0x000071EA File Offset: 0x000053EA
	public Stream Stream_0
	{
		get
		{
			return this.stream_0;
		}
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00036248 File Offset: 0x00034448
	private void method_0()
	{
		object obj = this.object_0;
		lock (obj)
		{
			if (this.socket_0 == null)
			{
				return;
			}
			this.method_4();
			this.method_2();
			this.method_3();
			this.method_1();
		}
		this.method_9();
		this.method_8();
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x000362B0 File Offset: 0x000344B0
	private void method_1()
	{
		try
		{
			this.socket_0.Shutdown(SocketShutdown.Both);
		}
		catch
		{
		}
		this.socket_0.Close();
		this.socket_0 = null;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x000071F2 File Offset: 0x000053F2
	private void method_2()
	{
		if (this.memoryStream_0 == null)
		{
			return;
		}
		this.memoryStream_0.Dispose();
		this.memoryStream_0 = null;
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x0000720F File Offset: 0x0000540F
	private void method_3()
	{
		if (this.stream_0 == null)
		{
			return;
		}
		this.stream2_0 = null;
		this.stream4_0 = null;
		this.stream_0.Dispose();
		this.stream_0 = null;
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x000362F0 File Offset: 0x000344F0
	private void method_4()
	{
		if (this.timer_0 == null)
		{
			return;
		}
		try
		{
			this.timer_0.Change(-1, -1);
		}
		catch
		{
		}
		this.timer_0.Dispose();
		this.timer_0 = null;
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x0000723A File Offset: 0x0000543A
	private void method_5()
	{
		this.gclass38_0 = new GClass38(this);
		this.enum8_0 = Enum8.RequestLine;
		this.stream2_0 = null;
		this.enum9_0 = Enum9.None;
		this.stream4_0 = null;
		this.int_1 = 0;
		this.memoryStream_0 = new MemoryStream();
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x0003633C File Offset: 0x0003453C
	private static void smethod_0(IAsyncResult iasyncResult_0)
	{
		Class70 @class = (Class70)iasyncResult_0.AsyncState;
		if (@class.socket_0 == null)
		{
			return;
		}
		object obj = @class.object_0;
		lock (obj)
		{
			if (@class.socket_0 != null)
			{
				int num = -1;
				int int_ = 0;
				try
				{
					int key = @class.int_2;
					if (!@class.dictionary_0[key])
					{
						@class.timer_0.Change(-1, -1);
						@class.dictionary_0[key] = true;
					}
					num = @class.stream_0.EndRead(iasyncResult_0);
					@class.memoryStream_0.Write(@class.byte_0, 0, num);
					int_ = (int)@class.memoryStream_0.Length;
				}
				catch (Exception ex)
				{
					if (@class.memoryStream_0 != null && @class.memoryStream_0.Length > 0L)
					{
						@class.method_16(ex.Message, 400);
						return;
					}
					@class.method_0();
					return;
				}
				if (num <= 0)
				{
					@class.method_0();
				}
				else if (@class.method_6(@class.memoryStream_0.GetBuffer(), int_))
				{
					if (!@class.gclass38_0.Boolean_0)
					{
						@class.gclass38_0.GClass40_0.method_4();
					}
					GClass37 gclass;
					if (@class.gclass38_0.Boolean_0)
					{
						@class.method_15();
					}
					else if (!@class.class68_0.method_2(@class.gclass38_0.GClass40_0.Uri_0, out gclass))
					{
						@class.method_16(null, 404);
					}
					else
					{
						if (@class.gclass37_0 != gclass)
						{
							@class.method_8();
							if (!gclass.method_7(@class))
							{
								@class.method_0();
								return;
							}
							@class.gclass37_0 = gclass;
						}
						@class.gclass38_0.GClass37_0 = gclass;
						if (@class.gclass38_0.method_0())
						{
							if (@class.gclass38_0.method_1())
							{
								@class.bool_0 = true;
							}
						}
					}
				}
				else
				{
					@class.stream_0.BeginRead(@class.byte_0, 0, 8192, new AsyncCallback(Class70.smethod_0), @class);
				}
			}
		}
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x0003656C File Offset: 0x0003476C
	private static void smethod_1(object object_1)
	{
		Class70 @class = (Class70)object_1;
		int key = @class.int_2;
		if (@class.socket_0 == null)
		{
			return;
		}
		object obj = @class.object_0;
		lock (obj)
		{
			if (@class.socket_0 != null)
			{
				if (!@class.dictionary_0[key])
				{
					@class.method_16(null, 408);
				}
			}
		}
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x000365E4 File Offset: 0x000347E4
	private bool method_6(byte[] byte_1, int int_4)
	{
		if (this.stringBuilder_0 == null)
		{
			this.stringBuilder_0 = new StringBuilder(64);
		}
		int num = 0;
		try
		{
			string text;
			while ((text = this.method_7(byte_1, this.int_1, int_4, out num)) != null)
			{
				this.int_1 += num;
				if (text.Length == 0)
				{
					if (this.enum8_0 != Enum8.RequestLine)
					{
						if (this.int_1 > 32768)
						{
							this.gclass38_0.String_0 = "Headers too long";
						}
						this.stringBuilder_0 = null;
						return true;
					}
				}
				else
				{
					if (this.enum8_0 == Enum8.RequestLine)
					{
						this.gclass38_0.GClass40_0.method_7(text);
						this.enum8_0 = Enum8.Headers;
					}
					else
					{
						this.gclass38_0.GClass40_0.method_3(text);
					}
					if (this.gclass38_0.Boolean_0)
					{
						return true;
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.gclass38_0.String_0 = ex.Message;
			return true;
		}
		this.int_1 += num;
		if (this.int_1 >= 32768)
		{
			this.gclass38_0.String_0 = "Headers too long";
			return true;
		}
		return false;
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x00036704 File Offset: 0x00034904
	private string method_7(byte[] byte_1, int int_4, int int_5, out int int_6)
	{
		int_6 = 0;
		for (int i = int_4; i < int_5; i++)
		{
			if (this.enum9_0 == Enum9.Lf)
			{
				break;
			}
			int_6++;
			byte b = byte_1[i];
			if (b == 13)
			{
				this.enum9_0 = Enum9.Cr;
			}
			else if (b == 10)
			{
				this.enum9_0 = Enum9.Lf;
			}
			else
			{
				this.stringBuilder_0.Append((char)b);
			}
		}
		if (this.enum9_0 != Enum9.Lf)
		{
			return null;
		}
		string result = this.stringBuilder_0.ToString();
		this.stringBuilder_0.Length = 0;
		this.enum9_0 = Enum9.None;
		return result;
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00007276 File Offset: 0x00005476
	private void method_8()
	{
		if (this.gclass37_0 != null)
		{
			this.gclass37_0.method_13(this);
			return;
		}
		this.class68_0.method_1(this);
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x00007299 File Offset: 0x00005499
	private void method_9()
	{
		if (!this.bool_0)
		{
			return;
		}
		this.gclass38_0.method_2();
		this.bool_0 = false;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x0003678C File Offset: 0x0003498C
	internal void method_10(bool bool_2)
	{
		if (this.socket_0 == null)
		{
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.socket_0 != null)
			{
				if (bool_2)
				{
					if (this.stream4_0 != null)
					{
						this.stream4_0.method_6(true);
					}
					this.method_0();
				}
				else
				{
					this.method_14().method_6(false);
					if (this.gclass38_0.GClass41_0.Boolean_0)
					{
						this.method_0();
					}
					else if (!this.gclass38_0.GClass40_0.method_5())
					{
						this.method_0();
					}
					else
					{
						this.method_2();
						this.method_9();
						this.method_5();
						this.int_2++;
						this.method_11();
					}
				}
			}
		}
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x00036864 File Offset: 0x00034A64
	public void method_11()
	{
		if (this.byte_0 == null)
		{
			this.byte_0 = new byte[8192];
		}
		if (this.int_2 == 1)
		{
			this.int_3 = 15000;
		}
		try
		{
			this.dictionary_0.Add(this.int_2, false);
			this.timer_0.Change(this.int_3, -1);
			this.stream_0.BeginRead(this.byte_0, 0, 8192, new AsyncCallback(Class70.smethod_0), this);
		}
		catch
		{
			this.method_0();
		}
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x000072B6 File Offset: 0x000054B6
	public void method_12()
	{
		this.method_10(false);
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x00036904 File Offset: 0x00034B04
	public Stream2 method_13(long long_0, bool bool_2)
	{
		object obj = this.object_0;
		Stream2 result;
		lock (obj)
		{
			if (this.socket_0 == null)
			{
				result = null;
			}
			else if (this.stream2_0 != null)
			{
				result = this.stream2_0;
			}
			else
			{
				byte[] buffer = this.memoryStream_0.GetBuffer();
				int int_ = (int)this.memoryStream_0.Length - this.int_1;
				this.method_2();
				this.stream2_0 = (bool_2 ? new Stream3(this.stream_0, buffer, this.int_1, int_, this.gclass38_0) : new Stream2(this.stream_0, buffer, this.int_1, int_, long_0));
				result = this.stream2_0;
			}
		}
		return result;
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x000369C8 File Offset: 0x00034BC8
	public Stream4 method_14()
	{
		object obj = this.object_0;
		Stream4 result;
		lock (obj)
		{
			if (this.socket_0 == null)
			{
				result = null;
			}
			else if (this.stream4_0 != null)
			{
				result = this.stream4_0;
			}
			else
			{
				GClass37 gclass = this.gclass38_0.GClass37_0;
				bool bool_ = gclass == null || gclass.Boolean_2;
				this.stream4_0 = new Stream4(this.stream_0, this.gclass38_0.GClass41_0, bool_);
				result = this.stream4_0;
			}
		}
		return result;
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x000072BF File Offset: 0x000054BF
	public void method_15()
	{
		this.method_16(this.gclass38_0.String_0, this.gclass38_0.Int32_0);
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x00036A64 File Offset: 0x00034C64
	public void method_16(string string_0, int int_4)
	{
		if (this.socket_0 == null)
		{
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.socket_0 != null)
			{
				try
				{
					GClass41 gclass41_ = this.gclass38_0.GClass41_0;
					gclass41_.Int32_0 = int_4;
					gclass41_.String_1 = "text/html";
					StringBuilder stringBuilder = new StringBuilder(64);
					stringBuilder.AppendFormat("<html><body><h1>{0} {1}", int_4, gclass41_.String_3);
					if (string_0 != null && string_0.Length > 0)
					{
						stringBuilder.AppendFormat(" ({0})</h1></body></html>", string_0);
					}
					else
					{
						stringBuilder.Append("</h1></body></html>");
					}
					Encoding utf = Encoding.UTF8;
					byte[] bytes = utf.GetBytes(stringBuilder.ToString());
					gclass41_.Encoding_0 = utf;
					gclass41_.Int64_0 = (long)bytes.Length;
					gclass41_.method_8(bytes, true);
				}
				catch
				{
					this.method_10(true);
				}
			}
		}
	}

	// Token: 0x04000313 RID: 787
	private byte[] byte_0;

	// Token: 0x04000314 RID: 788
	private const int int_0 = 8192;

	// Token: 0x04000315 RID: 789
	private GClass38 gclass38_0;

	// Token: 0x04000316 RID: 790
	private bool bool_0;

	// Token: 0x04000317 RID: 791
	private StringBuilder stringBuilder_0;

	// Token: 0x04000318 RID: 792
	private Enum8 enum8_0;

	// Token: 0x04000319 RID: 793
	private Stream2 stream2_0;

	// Token: 0x0400031A RID: 794
	private GClass37 gclass37_0;

	// Token: 0x0400031B RID: 795
	private Enum9 enum9_0;

	// Token: 0x0400031C RID: 796
	private Class68 class68_0;

	// Token: 0x0400031D RID: 797
	private EndPoint endPoint_0;

	// Token: 0x0400031E RID: 798
	private Stream4 stream4_0;

	// Token: 0x0400031F RID: 799
	private int int_1;

	// Token: 0x04000320 RID: 800
	private EndPoint endPoint_1;

	// Token: 0x04000321 RID: 801
	private MemoryStream memoryStream_0;

	// Token: 0x04000322 RID: 802
	private int int_2;

	// Token: 0x04000323 RID: 803
	private bool bool_1;

	// Token: 0x04000324 RID: 804
	private Socket socket_0;

	// Token: 0x04000325 RID: 805
	private Stream stream_0;

	// Token: 0x04000326 RID: 806
	private object object_0;

	// Token: 0x04000327 RID: 807
	private int int_3;

	// Token: 0x04000328 RID: 808
	private Dictionary<int, bool> dictionary_0;

	// Token: 0x04000329 RID: 809
	private Timer timer_0;
}
