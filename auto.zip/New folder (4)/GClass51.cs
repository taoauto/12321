﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;

// Token: 0x020000B8 RID: 184
public class GClass51
{
	// Token: 0x17000279 RID: 633
	// (get) Token: 0x060008C5 RID: 2245 RVA: 0x00008AE4 File Offset: 0x00006CE4
	// (set) Token: 0x060008C6 RID: 2246 RVA: 0x00008AEC File Offset: 0x00006CEC
	public GClass55 GClass55_0 { get; internal set; }

	// Token: 0x060008C7 RID: 2247 RVA: 0x00008AF5 File Offset: 0x00006CF5
	public GClass51()
	{
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00008B04 File Offset: 0x00006D04
	public GClass51(string string_4)
	{
		this.string_0 = string_4;
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00008B1A File Offset: 0x00006D1A
	public GClass51(string string_4, int int_1) : this(string_4)
	{
		this.int_0 = int_1;
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00008B2A File Offset: 0x00006D2A
	public GClass51(string string_4, int int_1, string string_5) : this(string_4, int_1)
	{
		this.string_3 = string_5;
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00008B3B File Offset: 0x00006D3B
	public GClass51(string string_4, int int_1, string string_5, string string_6, string string_7) : this(string_4, int_1, string_5)
	{
		this.string_1 = string_6;
		this.string_2 = string_7;
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x00008B56 File Offset: 0x00006D56
	public virtual string \u200F\u206C\u202D\u206E\u206B\u200F\u202C\u202E\u200C\u206A\u200E\u206F\u200F\u206A\u200D\u202A\u202B\u206C\u202C\u206D\u202C\u200D\u206E\u206B\u202D\u202A\u206A\u206E\u206C\u206B\u206C\u202A\u200C\u200D\u200F\u206A\u206A\u206F\u206A\u206F\u202E()
	{
		return this.string_0;
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x00008B5E File Offset: 0x00006D5E
	public virtual GEnum10 \u206A\u200E\u206A\u206E\u200F\u206C\u202D\u200F\u206D\u200E\u200C\u202D\u200D\u202E\u206C\u200B\u200E\u206F\u200D\u202D\u202E\u206A\u206D\u202A\u206E\u202B\u206F\u202D\u200B\u200B\u206D\u206D\u206D\u202D\u202A\u200F\u200C\u202A\u206F\u200D\u202E(string string_4)
	{
		if (this.string_0.StartsWith(string_4, StringComparison.InvariantCultureIgnoreCase) && this.string_0 != string_4)
		{
			return GEnum10.VisibleAndSelected;
		}
		return GEnum10.Hidden;
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x00008B80 File Offset: 0x00006D80
	public virtual string \u202B\u202E\u206A\u200C\u202B\u206D\u206F\u200E\u200D\u200C\u206F\u200E\u206F\u200F\u200F\u202B\u206E\u200C\u206B\u206E\u202C\u200B\u206F\u206E\u206C\u200D\u202C\u206C\u200B\u200F\u206D\u206C\u206C\u202A\u202B\u202A\u206E\u206E\u200D\u206B\u202E()
	{
		return this.string_3 ?? this.string_0;
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void \u202E\u200D\u206F\u200D\u202B\u202A\u202B\u200B\u206B\u202B\u206A\u202A\u206E\u200B\u206D\u206A\u200F\u202C\u200B\u206F\u200B\u206F\u202B\u202B\u206F\u202D\u206D\u206B\u202C\u200D\u202B\u202D\u202C\u200D\u206A\u206F\u206B\u202D\u200C\u202E(GClass55 gclass55_1, GEventArgs7 geventArgs7_0)
	{
	}

	// Token: 0x1700027A RID: 634
	// (get) Token: 0x060008D0 RID: 2256 RVA: 0x00008B92 File Offset: 0x00006D92
	// (set) Token: 0x060008D1 RID: 2257 RVA: 0x00008B9A File Offset: 0x00006D9A
	public virtual string String_0
	{
		get
		{
			return this.string_1;
		}
		set
		{
			this.string_1 = value;
		}
	}

	// Token: 0x1700027B RID: 635
	// (get) Token: 0x060008D2 RID: 2258 RVA: 0x00008BA3 File Offset: 0x00006DA3
	// (set) Token: 0x060008D3 RID: 2259 RVA: 0x00008BAB File Offset: 0x00006DAB
	public virtual string String_1
	{
		get
		{
			return this.string_2;
		}
		set
		{
			this.string_2 = value;
		}
	}

	// Token: 0x1700027C RID: 636
	// (get) Token: 0x060008D4 RID: 2260 RVA: 0x00008BB4 File Offset: 0x00006DB4
	// (set) Token: 0x060008D5 RID: 2261 RVA: 0x00008BBC File Offset: 0x00006DBC
	public virtual string String_2
	{
		get
		{
			return this.string_3;
		}
		set
		{
			this.string_3 = value;
		}
	}

	// Token: 0x1700027D RID: 637
	// (get) Token: 0x060008D6 RID: 2262 RVA: 0x00008BC5 File Offset: 0x00006DC5
	// (set) Token: 0x060008D7 RID: 2263 RVA: 0x00008BCC File Offset: 0x00006DCC
	public virtual Color Color_0
	{
		get
		{
			return Color.Transparent;
		}
		set
		{
			throw new NotImplementedException("Override this property to change color");
		}
	}

	// Token: 0x1700027E RID: 638
	// (get) Token: 0x060008D8 RID: 2264 RVA: 0x00008BC5 File Offset: 0x00006DC5
	// (set) Token: 0x060008D9 RID: 2265 RVA: 0x00008BCC File Offset: 0x00006DCC
	public virtual Color Color_1
	{
		get
		{
			return Color.Transparent;
		}
		set
		{
			throw new NotImplementedException("Override this property to change color");
		}
	}

	// Token: 0x04000481 RID: 1153
	public string string_0;

	// Token: 0x04000482 RID: 1154
	public int int_0 = -1;

	// Token: 0x04000483 RID: 1155
	public object object_0;

	// Token: 0x04000484 RID: 1156
	private string string_1;

	// Token: 0x04000485 RID: 1157
	private string string_2;

	// Token: 0x04000486 RID: 1158
	private string string_3;

	// Token: 0x04000487 RID: 1159
	[CompilerGenerated]
	private GClass55 gclass55_0;
}
