﻿using System;
using System.Collections;
using System.Collections.Generic;

// Token: 0x02000050 RID: 80
internal class Class30 : IEnumerable<byte>, IEnumerable
{
	// Token: 0x06000343 RID: 835 RVA: 0x000051B5 File Offset: 0x000033B5
	internal Class30(byte[] byte_1) : this(byte_1, (long)byte_1.Length)
	{
	}

	// Token: 0x06000344 RID: 836 RVA: 0x000051C1 File Offset: 0x000033C1
	internal Class30(byte[] byte_1, long long_2)
	{
		this.byte_0 = byte_1;
		this.long_1 = long_2;
	}

	// Token: 0x06000345 RID: 837 RVA: 0x000051D7 File Offset: 0x000033D7
	internal Class30(ushort ushort_0, string string_0)
	{
		this.byte_0 = ushort_0.smethod_8(string_0);
		this.long_1 = (long)this.byte_0.Length;
	}

	// Token: 0x170000E2 RID: 226
	// (get) Token: 0x06000346 RID: 838 RVA: 0x000051FA File Offset: 0x000033FA
	internal ushort UInt16_0
	{
		get
		{
			if (this.long_1 < 2L)
			{
				return 1005;
			}
			return this.byte_0.smethod_91(0, 2).smethod_66(GEnum5.Big);
		}
	}

	// Token: 0x170000E3 RID: 227
	// (get) Token: 0x06000347 RID: 839 RVA: 0x0000521F File Offset: 0x0000341F
	// (set) Token: 0x06000348 RID: 840 RVA: 0x00005227 File Offset: 0x00003427
	internal long Int64_0
	{
		get
		{
			return this.long_0;
		}
		set
		{
			this.long_0 = value;
		}
	}

	// Token: 0x170000E4 RID: 228
	// (get) Token: 0x06000349 RID: 841 RVA: 0x00005230 File Offset: 0x00003430
	internal bool Boolean_0
	{
		get
		{
			return this.long_1 >= 2L && this.UInt16_0.smethod_47();
		}
	}

	// Token: 0x170000E5 RID: 229
	// (get) Token: 0x0600034A RID: 842 RVA: 0x0002A744 File Offset: 0x00028944
	internal string String_0
	{
		get
		{
			if (this.long_1 <= 2L)
			{
				return string.Empty;
			}
			string result;
			if (!this.byte_0.smethod_92(2L, this.long_1 - 2L).smethod_73(out result))
			{
				return string.Empty;
			}
			return result;
		}
	}

	// Token: 0x170000E6 RID: 230
	// (get) Token: 0x0600034B RID: 843 RVA: 0x00005249 File Offset: 0x00003449
	public byte[] Byte_0
	{
		get
		{
			if (this.long_0 <= 0L)
			{
				return this.byte_0;
			}
			return this.byte_0.smethod_92(this.long_0, this.long_1 - this.long_0);
		}
	}

	// Token: 0x170000E7 RID: 231
	// (get) Token: 0x0600034C RID: 844 RVA: 0x0000527A File Offset: 0x0000347A
	public byte[] Byte_1
	{
		get
		{
			if (this.long_0 <= 0L)
			{
				return GClass25.byte_0;
			}
			return this.byte_0.smethod_92(0L, this.long_0);
		}
	}

	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x0600034D RID: 845 RVA: 0x0000529F File Offset: 0x0000349F
	public ulong UInt64_0
	{
		get
		{
			return (ulong)this.long_1;
		}
	}

	// Token: 0x0600034E RID: 846 RVA: 0x0002A788 File Offset: 0x00028988
	internal void method_0(byte[] byte_1)
	{
		for (long num = 0L; num < this.long_1; num += 1L)
		{
			checked
			{
				this.byte_0[(int)((IntPtr)num)] = (this.byte_0[(int)((IntPtr)num)] ^ byte_1[(int)((IntPtr)(num % 4L))]);
			}
		}
	}

	// Token: 0x0600034F RID: 847 RVA: 0x000052A7 File Offset: 0x000034A7
	public IEnumerator<byte> GetEnumerator()
	{
		Class30.Class31 @class = new Class30.Class31(0);
		@class.class30_0 = this;
		return @class;
	}

	// Token: 0x06000350 RID: 848 RVA: 0x000052B6 File Offset: 0x000034B6
	public byte[] method_1()
	{
		return this.byte_0;
	}

	// Token: 0x06000351 RID: 849 RVA: 0x000052BE File Offset: 0x000034BE
	public virtual string ToString()
	{
		return BitConverter.ToString(this.byte_0);
	}

	// Token: 0x06000352 RID: 850 RVA: 0x000052CB File Offset: 0x000034CB
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	// Token: 0x040001DF RID: 479
	private byte[] byte_0;

	// Token: 0x040001E0 RID: 480
	private long long_0;

	// Token: 0x040001E1 RID: 481
	private long long_1;

	// Token: 0x040001E2 RID: 482
	public static readonly Class30 class30_0 = new Class30(GClass25.byte_0, 0L);

	// Token: 0x040001E3 RID: 483
	public static readonly ulong ulong_0 = 9223372036854775807UL;
}
