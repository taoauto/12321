﻿using System;

// Token: 0x0200006C RID: 108
public interface GInterface0
{
	// Token: 0x1700012E RID: 302
	// (get) Token: 0x060004AC RID: 1196
	GEnum8 GEnum8_0 { get; }

	// Token: 0x1700012F RID: 303
	// (get) Token: 0x060004AD RID: 1197
	GClass46 GClass46_0 { get; }

	// Token: 0x17000130 RID: 304
	// (get) Token: 0x060004AE RID: 1198
	string String_0 { get; }

	// Token: 0x17000131 RID: 305
	// (get) Token: 0x060004AF RID: 1199
	string String_1 { get; }

	// Token: 0x17000132 RID: 306
	// (get) Token: 0x060004B0 RID: 1200
	DateTime DateTime_0 { get; }
}
