﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000145 RID: 325
internal class Class130
{
	// Token: 0x06000FB5 RID: 4021 RVA: 0x000594CC File Offset: 0x000576CC
	private Class130(Class141 class141_1, Class141[] class141_2, string string_2)
	{
		this.list_2 = new List<Thread>();
		this.class141_0 = class141_1;
		if (class141_2 == null)
		{
			this.list_0 = new List<Class141>();
		}
		else
		{
			this.list_0 = new List<Class141>(class141_2);
		}
		this.string_0 = string_2;
		this.dictionary_0 = new Dictionary<string, object>();
		this.interface5_0 = class141_1.method_2(this);
		this.interface6_0 = new Class132();
		this.Interface4_0 = new Class143();
	}

	// Token: 0x06000FB6 RID: 4022 RVA: 0x0000D05F File Offset: 0x0000B25F
	public Class130(Class141 class141_1, Class141[] class141_2, string string_2, int int_1) : this(class141_1, class141_2, string_2)
	{
		this.method_1(GEnum21.NeedToPrepare);
		this.dateTime_0 = DateTime.Now;
		this.int_0 = int_1;
		this.list_1 = new List<Class142>();
	}

	// Token: 0x06000FB7 RID: 4023 RVA: 0x00059550 File Offset: 0x00057750
	public Class130(Class141 class141_1, Class141[] class141_2, string string_2, List<Class142> list_3, Class140 class140_1, int int_1, DateTime dateTime_1) : this(class141_1, class141_2, string_2)
	{
		if (list_3.Count > 0)
		{
			this.method_1(GEnum21.Prepared);
		}
		else
		{
			this.method_1(GEnum21.NeedToPrepare);
		}
		this.dateTime_0 = dateTime_1;
		this.class140_0 = class140_1;
		this.int_0 = int_1;
		this.list_1 = list_3;
	}

	// Token: 0x14000038 RID: 56
	// (add) Token: 0x06000FB8 RID: 4024 RVA: 0x000595A0 File Offset: 0x000577A0
	// (remove) Token: 0x06000FB9 RID: 4025 RVA: 0x000595D8 File Offset: 0x000577D8
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x14000039 RID: 57
	// (add) Token: 0x06000FBA RID: 4026 RVA: 0x00059610 File Offset: 0x00057810
	// (remove) Token: 0x06000FBB RID: 4027 RVA: 0x00059648 File Offset: 0x00057848
	public event EventHandler Event_1
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_1;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_1, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003A RID: 58
	// (add) Token: 0x06000FBC RID: 4028 RVA: 0x00059680 File Offset: 0x00057880
	// (remove) Token: 0x06000FBD RID: 4029 RVA: 0x000596B8 File Offset: 0x000578B8
	public event EventHandler Event_2
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_2;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_2;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_2, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003B RID: 59
	// (add) Token: 0x06000FBE RID: 4030 RVA: 0x000596F0 File Offset: 0x000578F0
	// (remove) Token: 0x06000FBF RID: 4031 RVA: 0x00059728 File Offset: 0x00057928
	public event EventHandler<EventArgs2> Event_3
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_3;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_3;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_3, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003C RID: 60
	// (add) Token: 0x06000FC0 RID: 4032 RVA: 0x00059760 File Offset: 0x00057960
	// (remove) Token: 0x06000FC1 RID: 4033 RVA: 0x00059798 File Offset: 0x00057998
	public event EventHandler<EventArgs2> Event_4
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_4;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_4;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_4, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003D RID: 61
	// (add) Token: 0x06000FC2 RID: 4034 RVA: 0x000597D0 File Offset: 0x000579D0
	// (remove) Token: 0x06000FC3 RID: 4035 RVA: 0x00059808 File Offset: 0x00057A08
	public event EventHandler<EventArgs2> Event_5
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_5;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_5;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_5, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003E RID: 62
	// (add) Token: 0x06000FC4 RID: 4036 RVA: 0x00059840 File Offset: 0x00057A40
	// (remove) Token: 0x06000FC5 RID: 4037 RVA: 0x00059878 File Offset: 0x00057A78
	public event EventHandler<EventArgs2> Event_6
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_6;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_6;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_6, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1400003F RID: 63
	// (add) Token: 0x06000FC6 RID: 4038 RVA: 0x000598B0 File Offset: 0x00057AB0
	// (remove) Token: 0x06000FC7 RID: 4039 RVA: 0x000598E8 File Offset: 0x00057AE8
	public event EventHandler<EventArgs2> Event_7
	{
		[CompilerGenerated]
		add
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_7;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<EventArgs2> eventHandler = this.eventHandler_7;
			EventHandler<EventArgs2> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<EventArgs2> value2 = (EventHandler<EventArgs2>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<EventArgs2>>(ref this.eventHandler_7, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1700040A RID: 1034
	// (get) Token: 0x06000FC8 RID: 4040 RVA: 0x0000D08F File Offset: 0x0000B28F
	public Dictionary<string, object> Dictionary_0
	{
		get
		{
			return this.dictionary_0;
		}
	}

	// Token: 0x1700040B RID: 1035
	// (get) Token: 0x06000FC9 RID: 4041 RVA: 0x0000D097 File Offset: 0x0000B297
	public Class141 Class141_0
	{
		get
		{
			return this.class141_0;
		}
	}

	// Token: 0x1700040C RID: 1036
	// (get) Token: 0x06000FCA RID: 4042 RVA: 0x0000D09F File Offset: 0x0000B29F
	public List<Class141> List_0
	{
		get
		{
			return this.list_0;
		}
	}

	// Token: 0x1700040D RID: 1037
	// (get) Token: 0x06000FCB RID: 4043 RVA: 0x0000D0A7 File Offset: 0x0000B2A7
	public long Int64_0
	{
		get
		{
			if (this.class140_0 == null)
			{
				return 0L;
			}
			return this.class140_0.Int64_0;
		}
	}

	// Token: 0x1700040E RID: 1038
	// (get) Token: 0x06000FCC RID: 4044 RVA: 0x0000D0BF File Offset: 0x0000B2BF
	public DateTime DateTime_0
	{
		get
		{
			return this.dateTime_0;
		}
	}

	// Token: 0x1700040F RID: 1039
	// (get) Token: 0x06000FCD RID: 4045 RVA: 0x0000D0C7 File Offset: 0x0000B2C7
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x17000410 RID: 1040
	// (get) Token: 0x06000FCE RID: 4046 RVA: 0x0000D0CF File Offset: 0x0000B2CF
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x17000411 RID: 1041
	// (get) Token: 0x06000FCF RID: 4047 RVA: 0x0000D0D7 File Offset: 0x0000B2D7
	public int Int32_1
	{
		get
		{
			return (int)this.Double_0;
		}
	}

	// Token: 0x17000412 RID: 1042
	// (get) Token: 0x06000FD0 RID: 4048 RVA: 0x00059920 File Offset: 0x00057B20
	public double Double_0
	{
		get
		{
			int count = this.list_1.Count;
			if (count > 0)
			{
				double num = 0.0;
				for (int i = 0; i < count; i++)
				{
					num += this.list_1[i].Double_0;
				}
				return num / (double)count;
			}
			return 0.0;
		}
	}

	// Token: 0x17000413 RID: 1043
	// (get) Token: 0x06000FD1 RID: 4049 RVA: 0x00059978 File Offset: 0x00057B78
	public double Double_1
	{
		get
		{
			double num = 0.0;
			for (int i = 0; i < this.list_1.Count; i++)
			{
				num += this.list_1[i].Double_1;
			}
			return num;
		}
	}

	// Token: 0x17000414 RID: 1044
	// (get) Token: 0x06000FD2 RID: 4050 RVA: 0x000599BC File Offset: 0x00057BBC
	public long Int64_1
	{
		get
		{
			long num = 0L;
			for (int i = 0; i < this.list_1.Count; i++)
			{
				num += this.list_1[i].Int64_2;
			}
			return num;
		}
	}

	// Token: 0x17000415 RID: 1045
	// (get) Token: 0x06000FD3 RID: 4051 RVA: 0x000599F8 File Offset: 0x00057BF8
	public TimeSpan TimeSpan_0
	{
		get
		{
			if (this.Double_1 == 0.0)
			{
				return TimeSpan.MaxValue;
			}
			double num = 0.0;
			for (int i = 0; i < this.list_1.Count; i++)
			{
				num += (double)this.list_1[i].Int64_4;
			}
			return TimeSpan.FromSeconds(num / this.Double_1);
		}
	}

	// Token: 0x17000416 RID: 1046
	// (get) Token: 0x06000FD4 RID: 4052 RVA: 0x0000D0E0 File Offset: 0x0000B2E0
	public List<Class142> List_1
	{
		get
		{
			return this.list_1;
		}
	}

	// Token: 0x17000417 RID: 1047
	// (get) Token: 0x06000FD5 RID: 4053 RVA: 0x0000D0E8 File Offset: 0x0000B2E8
	// (set) Token: 0x06000FD6 RID: 4054 RVA: 0x0000D0F0 File Offset: 0x0000B2F0
	public Exception Exception_0
	{
		get
		{
			return this.exception_0;
		}
		set
		{
			this.exception_0 = value;
		}
	}

	// Token: 0x17000418 RID: 1048
	// (get) Token: 0x06000FD7 RID: 4055 RVA: 0x0000D0F9 File Offset: 0x0000B2F9
	public GEnum21 GEnum21_0
	{
		get
		{
			return this.genum21_0;
		}
	}

	// Token: 0x06000FD8 RID: 4056 RVA: 0x00059A60 File Offset: 0x00057C60
	public bool method_0()
	{
		GEnum21 genum = this.GEnum21_0;
		return genum == GEnum21.Preparing || genum == GEnum21.WaitingForReconnect || genum == GEnum21.Working;
	}

	// Token: 0x17000419 RID: 1049
	// (get) Token: 0x06000FD9 RID: 4057 RVA: 0x0000D101 File Offset: 0x0000B301
	public Class140 Class140_0
	{
		get
		{
			return this.class140_0;
		}
	}

	// Token: 0x1700041A RID: 1050
	// (get) Token: 0x06000FDA RID: 4058 RVA: 0x0000D109 File Offset: 0x0000B309
	// (set) Token: 0x06000FDB RID: 4059 RVA: 0x0000D111 File Offset: 0x0000B311
	public string String_1
	{
		get
		{
			return this.string_1;
		}
		set
		{
			this.string_1 = value;
		}
	}

	// Token: 0x1700041B RID: 1051
	// (get) Token: 0x06000FDC RID: 4060 RVA: 0x0000D11A File Offset: 0x0000B31A
	// (set) Token: 0x06000FDD RID: 4061 RVA: 0x0000D122 File Offset: 0x0000B322
	public Interface6 Interface6_0
	{
		get
		{
			return this.interface6_0;
		}
		set
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			this.interface6_0 = value;
		}
	}

	// Token: 0x1700041C RID: 1052
	// (get) Token: 0x06000FDE RID: 4062 RVA: 0x0000D139 File Offset: 0x0000B339
	// (set) Token: 0x06000FDF RID: 4063 RVA: 0x0000D141 File Offset: 0x0000B341
	public Interface4 Interface4_0
	{
		get
		{
			return this.interface4_0;
		}
		set
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			this.interface4_0 = value;
			this.interface4_0.imethod_0(this);
		}
	}

	// Token: 0x06000FE0 RID: 4064 RVA: 0x0000D164 File Offset: 0x0000B364
	private void method_1(GEnum21 genum21_1)
	{
		this.genum21_0 = genum21_1;
		this.vmethod_5();
	}

	// Token: 0x06000FE1 RID: 4065 RVA: 0x0000D173 File Offset: 0x0000B373
	private void method_2()
	{
		this.thread_0 = new Thread(new ParameterizedThreadStart(this.method_9));
		this.thread_0.IsBackground = true;
		this.thread_0.Start(this.int_0);
	}

	// Token: 0x06000FE2 RID: 4066 RVA: 0x0000D1AE File Offset: 0x0000B3AE
	private void method_3()
	{
		this.thread_0 = new Thread(new ThreadStart(this.method_11));
		this.thread_0.Start();
	}

	// Token: 0x06000FE3 RID: 4067 RVA: 0x0000D1D2 File Offset: 0x0000B3D2
	protected virtual void vmethod_0(Class142 class142_0)
	{
		if (this.eventHandler_3 != null)
		{
			this.eventHandler_3(this, new EventArgs2(this, class142_0));
		}
	}

	// Token: 0x06000FE4 RID: 4068 RVA: 0x0000D1EF File Offset: 0x0000B3EF
	protected virtual void vmethod_1(Class142 class142_0)
	{
		EventHandler<EventArgs2> eventHandler = this.eventHandler_4;
		if (eventHandler == null)
		{
			return;
		}
		eventHandler(this, new EventArgs2(this, class142_0));
	}

	// Token: 0x06000FE5 RID: 4069 RVA: 0x0000D209 File Offset: 0x0000B409
	protected virtual void vmethod_2(Class142 class142_0)
	{
		if (this.eventHandler_7 != null)
		{
			this.eventHandler_7(this, new EventArgs2(this, class142_0));
		}
	}

	// Token: 0x06000FE6 RID: 4070 RVA: 0x0000D226 File Offset: 0x0000B426
	protected virtual void vmethod_3(Class142 class142_0)
	{
		if (this.eventHandler_5 != null)
		{
			this.eventHandler_5(this, new EventArgs2(this, class142_0));
		}
	}

	// Token: 0x06000FE7 RID: 4071 RVA: 0x0000D243 File Offset: 0x0000B443
	protected virtual void vmethod_4(Class142 class142_0)
	{
		if (this.eventHandler_6 != null)
		{
			this.eventHandler_6(this, new EventArgs2(this, class142_0));
		}
	}

	// Token: 0x06000FE8 RID: 4072 RVA: 0x0000D260 File Offset: 0x0000B460
	protected virtual void vmethod_5()
	{
		if (this.eventHandler_2 != null)
		{
			this.eventHandler_2(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000FE9 RID: 4073 RVA: 0x0000D27B File Offset: 0x0000B47B
	protected virtual void vmethod_6()
	{
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000FEA RID: 4074 RVA: 0x0000D296 File Offset: 0x0000B496
	protected virtual void vmethod_7()
	{
		if (this.eventHandler_1 != null)
		{
			this.eventHandler_1(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000FEB RID: 4075 RVA: 0x0000D2B1 File Offset: 0x0000B4B1
	public IDisposable method_4()
	{
		return new Class125(this.list_1);
	}

	// Token: 0x06000FEC RID: 4076 RVA: 0x00059A84 File Offset: 0x00057C84
	public void method_5()
	{
		if (!this.method_0() && this.thread_0 != null && this.thread_0.IsAlive)
		{
			this.thread_0.Join(TimeSpan.FromSeconds(1.0));
		}
		while (this.method_0())
		{
			Thread.Sleep(100);
		}
	}

	// Token: 0x06000FED RID: 4077 RVA: 0x00059ADC File Offset: 0x00057CDC
	public void method_6()
	{
		if (this.genum21_0 != GEnum21.Preparing)
		{
			if (this.genum21_0 != GEnum21.WaitingForReconnect)
			{
				if (this.genum21_0 == GEnum21.Working)
				{
					this.method_1(GEnum21.Pausing);
					while (!this.method_15(5))
					{
					}
					List<Thread> obj = this.list_2;
					lock (obj)
					{
						this.list_2.Clear();
					}
					this.thread_0.Abort();
					this.thread_0 = null;
					if (this.Class140_0 != null && !this.Class140_0.Boolean_0)
					{
						this.List_1[0].Int64_1 = 0L;
					}
					this.method_1(GEnum21.Paused);
				}
				return;
			}
		}
		this.List_1.Clear();
		this.thread_0.Abort();
		this.thread_0 = null;
		this.method_1(GEnum21.NeedToPrepare);
	}

	// Token: 0x06000FEE RID: 4078 RVA: 0x00059BBC File Offset: 0x00057DBC
	public void method_7()
	{
		if (this.genum21_0 == GEnum21.NeedToPrepare)
		{
			this.method_1(GEnum21.Preparing);
			this.method_2();
			return;
		}
		if (this.genum21_0 != GEnum21.Preparing && this.genum21_0 != GEnum21.Pausing && this.genum21_0 != GEnum21.Working && this.genum21_0 != GEnum21.WaitingForReconnect)
		{
			this.method_1(GEnum21.Preparing);
			this.method_3();
		}
	}

	// Token: 0x06000FEF RID: 4079 RVA: 0x00059C10 File Offset: 0x00057E10
	private void method_8()
	{
		FileInfo fileInfo = new FileInfo(this.String_0);
		if (!Directory.Exists(fileInfo.DirectoryName))
		{
			Directory.CreateDirectory(fileInfo.DirectoryName);
		}
		if (fileInfo.Exists)
		{
			int num = 1;
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(this.String_0);
			string extension = Path.GetExtension(this.String_0);
			string path;
			do
			{
				path = Class123.smethod_0(fileInfo.DirectoryName) + fileNameWithoutExtension + string.Format("({0})", num++) + extension;
			}
			while (File.Exists(path));
			this.string_0 = path;
		}
		using (FileStream fileStream = new FileStream(this.String_0, FileMode.Create, FileAccess.Write))
		{
			fileStream.SetLength(Math.Max(this.Int64_0, 0L));
		}
	}

	// Token: 0x06000FF0 RID: 4080 RVA: 0x00059CE0 File Offset: 0x00057EE0
	private void method_9(object object_0)
	{
		this.method_1(GEnum21.Preparing);
		int int_ = Math.Min((int)object_0, Class144.int_4);
		Stream stream_ = null;
		int num = 0;
		for (;;)
		{
			this.exception_0 = null;
			if (this.genum21_0 == GEnum21.Pausing)
			{
				break;
			}
			this.method_1(GEnum21.Preparing);
			num++;
			try
			{
				this.class140_0 = this.interface5_0.imethod_2(this.Class141_0, out stream_);
				goto IL_98;
			}
			catch (ThreadAbortException)
			{
				this.method_1(GEnum21.NeedToPrepare);
				return;
			}
			catch (Exception ex)
			{
				this.exception_0 = ex;
				if (num >= Class144.int_3)
				{
					this.method_1(GEnum21.NeedToPrepare);
					return;
				}
				this.method_1(GEnum21.WaitingForReconnect);
				Thread.Sleep(TimeSpan.FromSeconds((double)Class144.int_2));
			}
		}
		this.method_1(GEnum21.NeedToPrepare);
		return;
		IL_98:
		try
		{
			this.exception_0 = null;
			this.method_10(int_, stream_);
		}
		catch (ThreadAbortException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			this.exception_0 = ex2;
			this.method_1(GEnum21.EndedWithError);
		}
	}

	// Token: 0x06000FF1 RID: 4081 RVA: 0x00059DE4 File Offset: 0x00057FE4
	private void method_10(int int_1, Stream stream_0)
	{
		this.vmethod_7();
		this.method_8();
		GStruct4[] array;
		if (!this.class140_0.Boolean_0)
		{
			array = new GStruct4[]
			{
				new GStruct4(0L, this.class140_0.Int64_0)
			};
		}
		else
		{
			array = this.Interface6_0.imethod_0(int_1, this.class140_0);
		}
		List<Thread> obj = this.list_2;
		lock (obj)
		{
			this.list_2.Clear();
		}
		List<Class142> obj2 = this.list_1;
		lock (obj2)
		{
			this.list_1.Clear();
		}
		for (int i = 0; i < array.Length; i++)
		{
			Class142 @class = new Class142();
			if (i == 0)
			{
				@class.Stream_1 = stream_0;
			}
			@class.Int32_1 = i;
			@class.Int64_0 = array[i].Int64_0;
			@class.Int64_1 = array[i].Int64_0;
			@class.Int64_5 = array[i].Int64_1;
			this.list_1.Add(@class);
		}
		this.method_12();
	}

	// Token: 0x06000FF2 RID: 4082 RVA: 0x00059F28 File Offset: 0x00058128
	private void method_11()
	{
		int num = 0;
		Stream stream;
		Class140 @class;
		try
		{
			for (;;)
			{
				this.exception_0 = null;
				this.method_1(GEnum21.Preparing);
				num++;
				try
				{
					@class = this.interface5_0.imethod_2(this.Class141_0, out stream);
					break;
				}
				catch (Exception ex)
				{
					this.exception_0 = ex;
					if (num >= Class144.int_3)
					{
						return;
					}
					this.method_1(GEnum21.WaitingForReconnect);
					Thread.Sleep(TimeSpan.FromSeconds((double)Class144.int_2));
				}
			}
		}
		finally
		{
			this.method_1(GEnum21.Prepared);
		}
		try
		{
			if (@class.Boolean_0 && !(@class.DateTime_0 > this.Class140_0.DateTime_0))
			{
				if (@class.Int64_0 == this.Class140_0.Int64_0)
				{
					if (stream != null)
					{
						stream.Dispose();
					}
					this.method_12();
					goto IL_B8;
				}
			}
			this.class140_0 = @class;
			this.method_10(this.Int32_0, stream);
			IL_B8:;
		}
		catch (ThreadAbortException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			this.exception_0 = ex2;
			this.method_1(GEnum21.EndedWithError);
		}
	}

	// Token: 0x06000FF3 RID: 4083 RVA: 0x0005A03C File Offset: 0x0005823C
	private void method_12()
	{
		this.method_1(GEnum21.Working);
		using (FileStream fileStream = new FileStream(this.String_0, FileMode.Open, FileAccess.Write))
		{
			for (int i = 0; i < this.List_1.Count; i++)
			{
				this.List_1[i].Stream_0 = fileStream;
				this.method_14(this.List_1[i]);
			}
			while (!this.method_15(1000) || this.method_13())
			{
			}
		}
		for (int j = 0; j < this.List_1.Count; j++)
		{
			if (this.List_1[j].Enum10_0 == Enum10.Error)
			{
				this.method_1(GEnum21.EndedWithError);
				return;
			}
		}
		if (this.GEnum21_0 != GEnum21.Pausing)
		{
			this.vmethod_6();
		}
		this.method_1(GEnum21.Ended);
	}

	// Token: 0x06000FF4 RID: 4084 RVA: 0x0005A118 File Offset: 0x00058318
	private bool method_13()
	{
		bool result = false;
		double num = 0.0;
		for (int i = 0; i < this.List_1.Count; i++)
		{
			if (this.List_1[i].Enum10_0 == Enum10.Error && this.List_1[i].DateTime_0 != DateTime.MinValue && (Class144.int_3 == 0 || this.List_1[i].Int32_0 < Class144.int_3))
			{
				result = true;
				TimeSpan timeSpan = DateTime.Now - this.List_1[i].DateTime_0;
				if (timeSpan.TotalSeconds >= (double)Class144.int_2)
				{
					Class142 @class = this.List_1[i];
					int int32_ = @class.Int32_0;
					@class.Int32_0 = int32_ + 1;
					this.method_14(this.List_1[i]);
					this.vmethod_0(this.List_1[i]);
				}
				else
				{
					num = Math.Max(num, (double)(Class144.int_2 * 1000) - timeSpan.TotalMilliseconds);
				}
			}
		}
		Thread.Sleep((int)num);
		return result;
	}

	// Token: 0x06000FF5 RID: 4085 RVA: 0x0005A23C File Offset: 0x0005843C
	private void method_14(Class142 class142_0)
	{
		Thread thread = new Thread(new ParameterizedThreadStart(this.method_16));
		thread.IsBackground = true;
		thread.Start(class142_0);
		List<Thread> obj = this.list_2;
		lock (obj)
		{
			this.list_2.Add(thread);
		}
	}

	// Token: 0x06000FF6 RID: 4086 RVA: 0x0005A2A4 File Offset: 0x000584A4
	private bool method_15(int int_1)
	{
		bool flag = true;
		List<Thread> obj = this.list_2;
		Thread[] array;
		lock (obj)
		{
			array = this.list_2.ToArray();
		}
		foreach (Thread thread in array)
		{
			bool flag3 = thread.Join(int_1);
			flag = (flag && flag3);
			if (flag3)
			{
				obj = this.list_2;
				lock (obj)
				{
					this.list_2.Remove(thread);
				}
			}
		}
		return flag;
	}

	// Token: 0x06000FF7 RID: 4087 RVA: 0x0005A354 File Offset: 0x00058554
	private void method_16(object object_0)
	{
		Class142 @class = (Class142)object_0;
		@class.Exception_0 = null;
		try
		{
			if (@class.Int64_5 > 0L && @class.Int64_1 >= @class.Int64_5)
			{
				@class.Enum10_0 = Enum10.Finished;
				this.vmethod_1(@class);
			}
			else
			{
				int count = 8192;
				byte[] buffer = new byte[8192];
				@class.Enum10_0 = Enum10.Connecting;
				this.vmethod_3(@class);
				if (@class.Stream_1 == null)
				{
					Class141 class2 = this.Interface4_0.imethod_1();
					Interface5 @interface = class2.method_2(this);
					while (class2 != this.Class141_0)
					{
						Stream stream;
						Class140 class3 = @interface.imethod_2(class2, out stream);
						if (stream != null)
						{
							stream.Dispose();
						}
						if (class3.Int64_0 == this.class140_0.Int64_0 && class3.Boolean_0 == this.class140_0.Boolean_0)
						{
							break;
						}
						List<Class141> obj = this.list_0;
						lock (obj)
						{
							this.list_0.Remove(class2);
						}
						class2 = this.Interface4_0.imethod_1();
						@interface = class2.method_2(this);
					}
					@class.Stream_1 = @interface.imethod_1(class2, @class.Int64_1, @class.Int64_5);
					@class.String_0 = class2.String_0;
				}
				else
				{
					@class.String_0 = this.class141_0.String_0;
				}
				using (@class.Stream_1)
				{
					this.vmethod_4(@class);
					@class.Enum10_0 = Enum10.Downloading;
					@class.Int32_0 = 0;
					for (;;)
					{
						long num = (long)@class.Stream_1.Read(buffer, 0, count);
						if (@class.Int64_5 > 0L && @class.Int64_1 + num > @class.Int64_5)
						{
							num = @class.Int64_5 - @class.Int64_1;
							if (num <= 0L)
							{
								goto Block_20;
							}
						}
						Stream stream_2 = @class.Stream_0;
						lock (stream_2)
						{
							@class.Stream_0.Position = @class.Int64_1;
							@class.Stream_0.Write(buffer, 0, (int)num);
						}
						@class.method_1(num);
						if (@class.Int64_5 > 0L && @class.Int64_1 >= @class.Int64_5)
						{
							goto IL_239;
						}
						if (this.genum21_0 == GEnum21.Pausing)
						{
							break;
						}
						if (num <= 0L)
						{
							goto Block_18;
						}
					}
					@class.Enum10_0 = Enum10.Paused;
					Block_18:
					goto IL_24E;
					Block_20:
					@class.Int64_1 = @class.Int64_5;
					goto IL_24E;
					IL_239:
					@class.Int64_1 = @class.Int64_5;
					IL_24E:
					if (@class.Enum10_0 == Enum10.Downloading)
					{
						@class.Enum10_0 = Enum10.Finished;
						this.method_17();
					}
				}
				this.vmethod_1(@class);
			}
		}
		catch (Exception ex)
		{
			@class.Enum10_0 = Enum10.Error;
			@class.Exception_0 = ex;
			this.vmethod_2(@class);
		}
		finally
		{
			@class.Stream_1 = null;
		}
	}

	// Token: 0x06000FF8 RID: 4088 RVA: 0x0005A67C File Offset: 0x0005887C
	private void method_17()
	{
		List<Class142> obj = this.list_1;
		lock (obj)
		{
			for (int i = 0; i < this.list_1.Count; i++)
			{
				Class142 @class = this.list_1[i];
				if (@class.Enum10_0 == Enum10.Downloading && @class.TimeSpan_0.TotalSeconds > (double)Class144.int_1 && @class.Int64_4 / 2L >= (long)Class144.int_0)
				{
					long num = @class.Int64_4 / 2L;
					Class142 class2 = new Class142();
					class2.Int32_1 = this.list_1.Count;
					class2.Int64_1 = @class.Int64_1 + num;
					class2.Int64_0 = class2.Int64_1;
					class2.Int64_5 = @class.Int64_5;
					class2.Stream_0 = @class.Stream_0;
					@class.Int64_5 -= num;
					this.list_1.Add(class2);
					this.method_14(class2);
					break;
				}
			}
		}
	}

	// Token: 0x0400081B RID: 2075
	private string string_0;

	// Token: 0x0400081C RID: 2076
	private int int_0;

	// Token: 0x0400081D RID: 2077
	private Class141 class141_0;

	// Token: 0x0400081E RID: 2078
	private List<Class141> list_0;

	// Token: 0x0400081F RID: 2079
	private List<Class142> list_1;

	// Token: 0x04000820 RID: 2080
	private Thread thread_0;

	// Token: 0x04000821 RID: 2081
	private List<Thread> list_2;

	// Token: 0x04000822 RID: 2082
	private Class140 class140_0;

	// Token: 0x04000823 RID: 2083
	private GEnum21 genum21_0;

	// Token: 0x04000824 RID: 2084
	private DateTime dateTime_0;

	// Token: 0x04000825 RID: 2085
	private Exception exception_0;

	// Token: 0x04000826 RID: 2086
	private Dictionary<string, object> dictionary_0 = new Dictionary<string, object>();

	// Token: 0x04000827 RID: 2087
	private Interface5 interface5_0;

	// Token: 0x04000828 RID: 2088
	private Interface6 interface6_0;

	// Token: 0x04000829 RID: 2089
	private Interface4 interface4_0;

	// Token: 0x0400082A RID: 2090
	private string string_1;

	// Token: 0x0400082B RID: 2091
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x0400082C RID: 2092
	[CompilerGenerated]
	private EventHandler eventHandler_1;

	// Token: 0x0400082D RID: 2093
	[CompilerGenerated]
	private EventHandler eventHandler_2;

	// Token: 0x0400082E RID: 2094
	[CompilerGenerated]
	private EventHandler<EventArgs2> eventHandler_3;

	// Token: 0x0400082F RID: 2095
	[CompilerGenerated]
	private EventHandler<EventArgs2> eventHandler_4;

	// Token: 0x04000830 RID: 2096
	[CompilerGenerated]
	private EventHandler<EventArgs2> eventHandler_5;

	// Token: 0x04000831 RID: 2097
	[CompilerGenerated]
	private EventHandler<EventArgs2> eventHandler_6;

	// Token: 0x04000832 RID: 2098
	[CompilerGenerated]
	private EventHandler<EventArgs2> eventHandler_7;
}
