﻿using System;
using System.ComponentModel;

// Token: 0x0200014C RID: 332
internal interface Interface1
{
	// Token: 0x14000045 RID: 69
	// (add) Token: 0x06001028 RID: 4136
	// (remove) Token: 0x06001029 RID: 4137
	event PropertyChangedEventHandler Event_0;
}
