﻿using System;

// Token: 0x0200013C RID: 316
internal static class Class121
{
	// Token: 0x06000FA6 RID: 4006 RVA: 0x0000CF87 File Offset: 0x0000B187
	public static bool smethod_0(string string_2)
	{
		return string_2 == "Yes";
	}

	// Token: 0x06000FA7 RID: 4007 RVA: 0x0000CF99 File Offset: 0x0000B199
	public static string smethod_1(bool bool_0)
	{
		if (bool_0)
		{
			return "Yes";
		}
		return "No";
	}

	// Token: 0x0400080D RID: 2061
	private const string string_0 = "Yes";

	// Token: 0x0400080E RID: 2062
	private const string string_1 = "No";
}
