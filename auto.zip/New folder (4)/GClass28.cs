﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using WebSocketSharp.Net;

// Token: 0x0200006F RID: 111
public class GClass28
{
	// Token: 0x060004DE RID: 1246 RVA: 0x00030404 File Offset: 0x0002E604
	public GClass28()
	{
		IPAddress any = IPAddress.Any;
		this.method_6(any.ToString(), any, 80, false);
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x000062A0 File Offset: 0x000044A0
	public GClass28(int int_1) : this(int_1, int_1 == 443)
	{
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x00030430 File Offset: 0x0002E630
	public GClass28(string string_4)
	{
		if (string_4 == null)
		{
			throw new ArgumentNullException("url");
		}
		if (string_4.Length == 0)
		{
			throw new ArgumentException("An empty string.", "url");
		}
		Uri uri;
		string message;
		if (!GClass28.smethod_1(string_4, out uri, out message))
		{
			throw new ArgumentException(message, "url");
		}
		string dnsSafeHost = uri.DnsSafeHost;
		IPAddress ipaddress = dnsSafeHost.smethod_63();
		if (ipaddress == null)
		{
			message = "The host part could not be converted to an IP address.";
			throw new ArgumentException(message, "url");
		}
		if (!ipaddress.smethod_87())
		{
			message = "The IP address of the host is not a local IP address.";
			throw new ArgumentException(message, "url");
		}
		this.method_6(dnsSafeHost, ipaddress, uri.Port, uri.Scheme == "wss");
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x000304DC File Offset: 0x0002E6DC
	public GClass28(int int_1, bool bool_4)
	{
		if (!int_1.smethod_46())
		{
			string message = "Less than 1 or greater than 65535.";
			throw new ArgumentOutOfRangeException("port", message);
		}
		IPAddress any = IPAddress.Any;
		this.method_6(any.ToString(), any, int_1, bool_4);
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x000062B1 File Offset: 0x000044B1
	public GClass28(IPAddress ipaddress_1, int int_1) : this(ipaddress_1, int_1, int_1 == 443)
	{
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x00030520 File Offset: 0x0002E720
	public GClass28(IPAddress ipaddress_1, int int_1, bool bool_4)
	{
		if (ipaddress_1 == null)
		{
			throw new ArgumentNullException("address");
		}
		if (!ipaddress_1.smethod_87())
		{
			throw new ArgumentException("Not a local IP address.", "address");
		}
		if (!int_1.smethod_46())
		{
			string message = "Less than 1 or greater than 65535.";
			throw new ArgumentOutOfRangeException("port", message);
		}
		this.method_6(ipaddress_1.ToString(), ipaddress_1, int_1, bool_4);
	}

	// Token: 0x17000140 RID: 320
	// (get) Token: 0x060004E4 RID: 1252 RVA: 0x000062C3 File Offset: 0x000044C3
	public IPAddress IPAddress_0
	{
		get
		{
			return this.ipaddress_0;
		}
	}

	// Token: 0x17000141 RID: 321
	// (get) Token: 0x060004E5 RID: 1253 RVA: 0x000062CB File Offset: 0x000044CB
	// (set) Token: 0x060004E6 RID: 1254 RVA: 0x00030584 File Offset: 0x0002E784
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.bool_0 = value;
				}
			}
		}
	}

	// Token: 0x17000142 RID: 322
	// (get) Token: 0x060004E7 RID: 1255 RVA: 0x000062D3 File Offset: 0x000044D3
	// (set) Token: 0x060004E8 RID: 1256 RVA: 0x000305F4 File Offset: 0x0002E7F4
	public WebSocketSharp.Net.AuthenticationSchemes AuthenticationSchemes_0
	{
		get
		{
			return this.authenticationSchemes_0;
		}
		set
		{
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.authenticationSchemes_0 = value;
				}
			}
		}
	}

	// Token: 0x17000143 RID: 323
	// (get) Token: 0x060004E9 RID: 1257 RVA: 0x000062DB File Offset: 0x000044DB
	public bool Boolean_1
	{
		get
		{
			return this.enum5_0 == Enum5.Start;
		}
	}

	// Token: 0x17000144 RID: 324
	// (get) Token: 0x060004EA RID: 1258 RVA: 0x000062E8 File Offset: 0x000044E8
	public bool Boolean_2
	{
		get
		{
			return this.bool_3;
		}
	}

	// Token: 0x17000145 RID: 325
	// (get) Token: 0x060004EB RID: 1259 RVA: 0x000062F0 File Offset: 0x000044F0
	// (set) Token: 0x060004EC RID: 1260 RVA: 0x000062FD File Offset: 0x000044FD
	public bool Boolean_3
	{
		get
		{
			return this.gclass30_0.Boolean_0;
		}
		set
		{
			this.gclass30_0.Boolean_0 = value;
		}
	}

	// Token: 0x17000146 RID: 326
	// (get) Token: 0x060004ED RID: 1261 RVA: 0x0000630B File Offset: 0x0000450B
	public GClass24 GClass24_0
	{
		get
		{
			return this.gclass24_0;
		}
	}

	// Token: 0x17000147 RID: 327
	// (get) Token: 0x060004EE RID: 1262 RVA: 0x00006313 File Offset: 0x00004513
	public int Int32_0
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x17000148 RID: 328
	// (get) Token: 0x060004EF RID: 1263 RVA: 0x0000631B File Offset: 0x0000451B
	// (set) Token: 0x060004F0 RID: 1264 RVA: 0x00030664 File Offset: 0x0002E864
	public string String_0
	{
		get
		{
			return this.string_2;
		}
		set
		{
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.string_2 = value;
				}
			}
		}
	}

	// Token: 0x17000149 RID: 329
	// (get) Token: 0x060004F1 RID: 1265 RVA: 0x00006323 File Offset: 0x00004523
	// (set) Token: 0x060004F2 RID: 1266 RVA: 0x000306D4 File Offset: 0x0002E8D4
	public bool Boolean_4
	{
		get
		{
			return this.bool_2;
		}
		set
		{
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.bool_2 = value;
				}
			}
		}
	}

	// Token: 0x1700014A RID: 330
	// (get) Token: 0x060004F3 RID: 1267 RVA: 0x0000632B File Offset: 0x0000452B
	public GClass44 GClass44_0
	{
		get
		{
			if (!this.bool_3)
			{
				throw new InvalidOperationException("This instance does not provide secure connections.");
			}
			return this.method_5();
		}
	}

	// Token: 0x1700014B RID: 331
	// (get) Token: 0x060004F4 RID: 1268 RVA: 0x00006346 File Offset: 0x00004546
	// (set) Token: 0x060004F5 RID: 1269 RVA: 0x00030744 File Offset: 0x0002E944
	public Func<IIdentity, GClass43> Func_0
	{
		get
		{
			return this.func_0;
		}
		set
		{
			string text;
			if (!this.method_2(out text))
			{
				this.gclass24_0.method_6(text);
				return;
			}
			object obj = this.object_0;
			lock (obj)
			{
				if (!this.method_2(out text))
				{
					this.gclass24_0.method_6(text);
				}
				else
				{
					this.func_0 = value;
				}
			}
		}
	}

	// Token: 0x1700014C RID: 332
	// (get) Token: 0x060004F6 RID: 1270 RVA: 0x0000634E File Offset: 0x0000454E
	// (set) Token: 0x060004F7 RID: 1271 RVA: 0x0000635B File Offset: 0x0000455B
	public TimeSpan TimeSpan_0
	{
		get
		{
			return this.gclass30_0.TimeSpan_0;
		}
		set
		{
			this.gclass30_0.TimeSpan_0 = value;
		}
	}

	// Token: 0x1700014D RID: 333
	// (get) Token: 0x060004F8 RID: 1272 RVA: 0x00006369 File Offset: 0x00004569
	public GClass30 GClass30_0
	{
		get
		{
			return this.gclass30_0;
		}
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x000307B4 File Offset: 0x0002E9B4
	private void method_0()
	{
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 != Enum5.Start)
			{
				return;
			}
			this.enum5_0 = Enum5.ShuttingDown;
		}
		try
		{
			try
			{
				this.tcpListener_0.Stop();
			}
			finally
			{
				this.gclass30_0.method_9(1006, string.Empty);
			}
		}
		catch
		{
		}
		this.enum5_0 = Enum5.Stop;
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00006371 File Offset: 0x00004571
	private bool method_1(Class84 class84_0)
	{
		return this.authenticationSchemes_0 == WebSocketSharp.Net.AuthenticationSchemes.Anonymous || (this.authenticationSchemes_0 != WebSocketSharp.Net.AuthenticationSchemes.None && class84_0.method_1(this.authenticationSchemes_0, this.string_3, this.func_0));
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x000063A4 File Offset: 0x000045A4
	private bool method_2(out string string_4)
	{
		string_4 = null;
		if (this.enum5_0 == Enum5.Start)
		{
			string_4 = "The server has already started.";
			return false;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			string_4 = "The server is shutting down.";
			return false;
		}
		return true;
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x000063D2 File Offset: 0x000045D2
	private bool method_3(string string_4)
	{
		return !this.bool_1 || Uri.CheckHostName(string_4) != UriHostNameType.Dns || string_4 == this.string_1;
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x000063F3 File Offset: 0x000045F3
	private static bool smethod_0(GClass44 gclass44_2, out string string_4)
	{
		string_4 = null;
		if (gclass44_2.X509Certificate2_0 == null)
		{
			string_4 = "There is no server certificate for secure connection.";
			return false;
		}
		return true;
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x00030850 File Offset: 0x0002EA50
	private string method_4()
	{
		string text = this.string_2;
		if (text != null && text.Length > 0)
		{
			return text;
		}
		return GClass28.string_0;
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x0000640A File Offset: 0x0000460A
	private GClass44 method_5()
	{
		if (this.gclass44_0 == null)
		{
			this.gclass44_0 = new GClass44();
		}
		return this.gclass44_0;
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x00030878 File Offset: 0x0002EA78
	private void method_6(string string_4, IPAddress ipaddress_1, int int_1, bool bool_4)
	{
		this.string_1 = string_4;
		this.ipaddress_0 = ipaddress_1;
		this.int_0 = int_1;
		this.bool_3 = bool_4;
		this.authenticationSchemes_0 = WebSocketSharp.Net.AuthenticationSchemes.Anonymous;
		this.bool_1 = (Uri.CheckHostName(string_4) == UriHostNameType.Dns);
		this.tcpListener_0 = new TcpListener(ipaddress_1, int_1);
		this.gclass24_0 = new GClass24();
		this.gclass30_0 = new GClass30(this.gclass24_0);
		this.object_0 = new object();
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x000308F0 File Offset: 0x0002EAF0
	private void method_7(Class84 class84_0)
	{
		if (!this.method_1(class84_0))
		{
			class84_0.method_3(GEnum9.Forbidden);
			return;
		}
		Uri uri = class84_0.GClass46.\u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E;
		if (uri == null)
		{
			class84_0.method_3(GEnum9.BadRequest);
			return;
		}
		if (!this.bool_0)
		{
			if (uri.Port != this.int_0)
			{
				class84_0.method_3(GEnum9.BadRequest);
				return;
			}
			if (!this.method_3(uri.DnsSafeHost))
			{
				class84_0.method_3(GEnum9.NotFound);
				return;
			}
		}
		string text = uri.AbsolutePath;
		if (text.IndexOfAny(new char[]
		{
			'%',
			'+'
		}) > -1)
		{
			text = Class78.smethod_27(text, Encoding.UTF8);
		}
		GClass29 gclass;
		if (!this.gclass30_0.method_7(text, out gclass))
		{
			class84_0.method_3(GEnum9.NotImplemented);
			return;
		}
		gclass.method_1(class84_0);
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x000309BC File Offset: 0x0002EBBC
	private void method_8()
	{
		for (;;)
		{
			GClass28.Class52 @class = new GClass28.Class52();
			@class.gclass28_0 = this;
			@class.tcpClient_0 = null;
			try
			{
				@class.tcpClient_0 = this.tcpListener_0.AcceptTcpClient();
				ThreadPool.QueueUserWorkItem(new WaitCallback(@class.method_0));
				continue;
			}
			catch (SocketException ex)
			{
				if (this.enum5_0 == Enum5.ShuttingDown)
				{
					this.gclass24_0.method_4("The underlying listener is stopped.");
				}
				else
				{
					this.gclass24_0.method_3(ex.Message);
					this.gclass24_0.method_1(ex.ToString());
				}
			}
			catch (Exception ex2)
			{
				this.gclass24_0.method_3(ex2.Message);
				this.gclass24_0.method_1(ex2.ToString());
				if (@class.tcpClient_0 != null)
				{
					@class.tcpClient_0.Close();
				}
			}
			break;
		}
		if (this.enum5_0 != Enum5.ShuttingDown)
		{
			this.method_0();
		}
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x00030AAC File Offset: 0x0002ECAC
	private void method_9(GClass44 gclass44_2)
	{
		if (this.enum5_0 == Enum5.Start)
		{
			this.gclass24_0.method_4("The server has already started.");
			return;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			this.gclass24_0.method_6("The server is shutting down.");
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 == Enum5.Start)
			{
				this.gclass24_0.method_4("The server has already started.");
			}
			else if (this.enum5_0 == Enum5.ShuttingDown)
			{
				this.gclass24_0.method_6("The server is shutting down.");
			}
			else
			{
				this.gclass44_1 = gclass44_2;
				this.string_3 = this.method_4();
				this.gclass30_0.method_8();
				try
				{
					this.method_10();
				}
				catch
				{
					this.gclass30_0.method_9(1011, string.Empty);
					throw;
				}
				this.enum5_0 = Enum5.Start;
			}
		}
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x00030BAC File Offset: 0x0002EDAC
	private void method_10()
	{
		if (this.bool_2)
		{
			this.tcpListener_0.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
		}
		try
		{
			this.tcpListener_0.Start();
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException("The underlying listener has failed to start.", innerException);
		}
		this.thread_0 = new Thread(new ThreadStart(this.method_8));
		this.thread_0.IsBackground = true;
		this.thread_0.Start();
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x00030C34 File Offset: 0x0002EE34
	private void method_11(ushort ushort_0, string string_4)
	{
		if (this.enum5_0 == Enum5.Ready)
		{
			this.gclass24_0.method_4("The server is not started.");
			return;
		}
		if (this.enum5_0 == Enum5.ShuttingDown)
		{
			this.gclass24_0.method_4("The server is shutting down.");
			return;
		}
		if (this.enum5_0 == Enum5.Stop)
		{
			this.gclass24_0.method_4("The server has already stopped.");
			return;
		}
		object obj = this.object_0;
		lock (obj)
		{
			if (this.enum5_0 == Enum5.ShuttingDown)
			{
				this.gclass24_0.method_4("The server is shutting down.");
				return;
			}
			if (this.enum5_0 == Enum5.Stop)
			{
				this.gclass24_0.method_4("The server has already stopped.");
				return;
			}
			this.enum5_0 = Enum5.ShuttingDown;
		}
		try
		{
			bool flag2 = false;
			try
			{
				this.method_12(5000);
			}
			catch
			{
				flag2 = true;
				throw;
			}
			finally
			{
				try
				{
					this.gclass30_0.method_9(ushort_0, string_4);
				}
				catch
				{
					if (!flag2)
					{
						throw;
					}
				}
			}
		}
		finally
		{
			this.enum5_0 = Enum5.Stop;
		}
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x00030D6C File Offset: 0x0002EF6C
	private void method_12(int int_1)
	{
		try
		{
			this.tcpListener_0.Stop();
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException("The underlying listener has failed to stop.", innerException);
		}
		this.thread_0.Join(int_1);
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x00006425 File Offset: 0x00004625
	private static bool smethod_1(string string_4, out Uri uri_0, out string string_5)
	{
		if (!string_4.smethod_72(out uri_0, out string_5))
		{
			return false;
		}
		if (uri_0.PathAndQuery != "/")
		{
			uri_0 = null;
			string_5 = "It includes either or both path and query components.";
			return false;
		}
		return true;
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x00030DB0 File Offset: 0x0002EFB0
	[Obsolete("This method will be removed. Use added one instead.")]
	public void method_13<T>(string string_4, Func<T> func_1) where T : GClass27
	{
		if (string_4 == null)
		{
			throw new ArgumentNullException("path");
		}
		if (func_1 == null)
		{
			throw new ArgumentNullException("creator");
		}
		if (string_4.Length == 0)
		{
			throw new ArgumentException("An empty string.", "path");
		}
		if (string_4[0] != '/')
		{
			throw new ArgumentException("Not an absolute path.", "path");
		}
		if (string_4.IndexOfAny(new char[]
		{
			'?',
			'#'
		}) > -1)
		{
			throw new ArgumentException("It includes either or both query and fragment components.", "path");
		}
		this.gclass30_0.method_6<T>(string_4, func_1);
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x00006453 File Offset: 0x00004653
	public void method_14<T>(string string_4) where T : GClass27, new()
	{
		this.gclass30_0.method_10<T>(string_4, null);
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x00006462 File Offset: 0x00004662
	public void method_15<T>(string string_4, Action<T> action_0) where T : GClass27, new()
	{
		this.gclass30_0.method_10<T>(string_4, action_0);
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x00006471 File Offset: 0x00004671
	public bool method_16(string string_4)
	{
		return this.gclass30_0.method_19(string_4);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x00030E44 File Offset: 0x0002F044
	public void method_17()
	{
		GClass44 gclass44_ = null;
		if (this.bool_3)
		{
			gclass44_ = new GClass44(this.method_5());
			string message;
			if (!GClass28.smethod_0(gclass44_, out message))
			{
				throw new InvalidOperationException(message);
			}
		}
		this.method_9(gclass44_);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0000647F File Offset: 0x0000467F
	public void method_18()
	{
		this.method_11(1001, string.Empty);
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x00030E80 File Offset: 0x0002F080
	[Obsolete("This method will be removed.")]
	public void method_19(ushort ushort_0, string string_4)
	{
		if (!ushort_0.smethod_84())
		{
			string message = "Less than 1000 or greater than 4999.";
			throw new ArgumentOutOfRangeException("code", message);
		}
		if (ushort_0 == 1010)
		{
			throw new ArgumentException("1010 cannot be used.", "code");
		}
		if (!string_4.smethod_88())
		{
			if (ushort_0 == 1005)
			{
				throw new ArgumentException("1005 cannot be used.", "code");
			}
			byte[] array;
			if (!string_4.smethod_74(out array))
			{
				throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
			}
			if (array.Length > 123)
			{
				string message2 = "Its size is greater than 123 bytes.";
				throw new ArgumentOutOfRangeException("reason", message2);
			}
		}
		this.method_11(ushort_0, string_4);
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x00030F1C File Offset: 0x0002F11C
	[Obsolete("This method will be removed.")]
	public void method_20(GEnum6 genum6_0, string string_4)
	{
		if (genum6_0 == GEnum6.MandatoryExtension)
		{
			throw new ArgumentException("MandatoryExtension cannot be used.", "code");
		}
		if (!string_4.smethod_88())
		{
			if (genum6_0 == GEnum6.NoStatus)
			{
				throw new ArgumentException("NoStatus cannot be used.", "code");
			}
			byte[] array;
			if (!string_4.smethod_74(out array))
			{
				throw new ArgumentException("It could not be UTF-8-encoded.", "reason");
			}
			if (array.Length > 123)
			{
				string message = "Its size is greater than 123 bytes.";
				throw new ArgumentOutOfRangeException("reason", message);
			}
		}
		this.method_11((ushort)genum6_0, string_4);
	}

	// Token: 0x0400028C RID: 652
	private IPAddress ipaddress_0;

	// Token: 0x0400028D RID: 653
	private bool bool_0;

	// Token: 0x0400028E RID: 654
	private WebSocketSharp.Net.AuthenticationSchemes authenticationSchemes_0;

	// Token: 0x0400028F RID: 655
	private static readonly string string_0 = "SECRET AREA";

	// Token: 0x04000290 RID: 656
	private bool bool_1;

	// Token: 0x04000291 RID: 657
	private string string_1;

	// Token: 0x04000292 RID: 658
	private TcpListener tcpListener_0;

	// Token: 0x04000293 RID: 659
	private GClass24 gclass24_0;

	// Token: 0x04000294 RID: 660
	private int int_0;

	// Token: 0x04000295 RID: 661
	private string string_2;

	// Token: 0x04000296 RID: 662
	private string string_3;

	// Token: 0x04000297 RID: 663
	private Thread thread_0;

	// Token: 0x04000298 RID: 664
	private bool bool_2;

	// Token: 0x04000299 RID: 665
	private bool bool_3;

	// Token: 0x0400029A RID: 666
	private GClass30 gclass30_0;

	// Token: 0x0400029B RID: 667
	private GClass44 gclass44_0;

	// Token: 0x0400029C RID: 668
	private GClass44 gclass44_1;

	// Token: 0x0400029D RID: 669
	private volatile Enum5 enum5_0;

	// Token: 0x0400029E RID: 670
	private object object_0;

	// Token: 0x0400029F RID: 671
	private Func<IIdentity, GClass43> func_0;

	// Token: 0x02000070 RID: 112
	[CompilerGenerated]
	private sealed class Class52
	{
		// Token: 0x06000511 RID: 1297 RVA: 0x00030F9C File Offset: 0x0002F19C
		internal void method_0(object object_0)
		{
			try
			{
				Class84 class84_ = new Class84(this.tcpClient_0, null, this.gclass28_0.bool_3, this.gclass28_0.gclass44_1, this.gclass28_0.gclass24_0);
				this.gclass28_0.method_7(class84_);
			}
			catch (Exception ex)
			{
				this.gclass28_0.gclass24_0.method_2(ex.Message);
				this.gclass28_0.gclass24_0.method_1(ex.ToString());
				this.tcpClient_0.Close();
			}
		}

		// Token: 0x040002A0 RID: 672
		public TcpClient tcpClient_0;

		// Token: 0x040002A1 RID: 673
		public GClass28 gclass28_0;
	}
}
