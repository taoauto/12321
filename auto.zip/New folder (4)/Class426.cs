﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x02000306 RID: 774
internal class Class426
{
	// Token: 0x06002C28 RID: 11304 RVA: 0x00128CD8 File Offset: 0x00126ED8
	public static bool smethod_0(Point point_0, Point point_1, Point point_2, Point point_3)
	{
		int num = point_1.Y * point_3.X - point_1.X * point_3.Y + (point_3.Y - point_1.Y) * point_0.X + (point_1.X - point_3.X) * point_0.Y;
		int num2 = point_1.X * point_2.Y - point_1.Y * point_2.X + (point_1.Y - point_2.Y) * point_0.X + (point_2.X - point_1.X) * point_0.Y;
		if (num < 0 != num2 < 0)
		{
			return false;
		}
		int num3 = -point_2.Y * point_3.X + point_1.Y * (point_3.X - point_2.X) + point_1.X * (point_2.Y - point_3.Y) + point_2.X * point_3.Y;
		if (num3 >= 0)
		{
			return num >= 0 && num + num2 <= num3;
		}
		return num <= 0 && num + num2 >= num3;
	}

	// Token: 0x06002C29 RID: 11305 RVA: 0x00128E08 File Offset: 0x00127008
	private static bool smethod_1(Point point_0, Point point_1, Point point_2, Point point_3)
	{
		int num = point_0.X - point_3.X;
		int num2 = point_0.Y - point_3.Y;
		int num3 = point_3.X - point_2.X;
		int num4 = point_2.Y - point_3.Y;
		int num5 = num4 * (point_1.X - point_3.X) + num3 * (point_1.Y - point_3.Y);
		int num6 = num4 * num + num3 * num2;
		int num7 = (point_3.Y - point_1.Y) * num + (point_1.X - point_3.X) * num2;
		if (num5 < 0)
		{
			return num6 <= 0 && num7 <= 0 && num6 + num7 >= num5;
		}
		return num6 >= 0 && num7 >= 0 && num6 + num7 <= num5;
	}

	// Token: 0x06002C2A RID: 11306 RVA: 0x00128ED8 File Offset: 0x001270D8
	public static bool smethod_2(Point point_0, Point point_1, Point point_2, Point point_3)
	{
		int num = point_0.X - point_1.X;
		int num2 = point_0.Y - point_1.Y;
		bool flag = (point_2.X - point_1.X) * num2 - (point_2.Y - point_1.Y) * num > 0;
		return (point_3.X - point_1.X) * num2 - (point_3.Y - point_1.Y) * num > 0 != flag && (point_3.X - point_2.X) * (point_0.Y - point_2.Y) - (point_3.Y - point_2.Y) * (point_0.X - point_2.X) > 0 == flag;
	}

	// Token: 0x06002C2B RID: 11307 RVA: 0x00128FA0 File Offset: 0x001271A0
	private static float smethod_3(Point point_0, Point point_1, Point point_2)
	{
		return (float)((point_0.X - point_2.X) * (point_1.Y - point_2.Y) - (point_1.Y - point_2.Y) * (point_0.Y - point_2.Y));
	}

	// Token: 0x06002C2C RID: 11308 RVA: 0x000204BA File Offset: 0x0001E6BA
	public static bool smethod_4(Point point_0, Point point_1, Point point_2, Point point_3, Point point_4)
	{
		return Class426.smethod_2(point_0, point_1, point_2, point_3) || Class426.smethod_2(point_0, point_1, point_3, point_4);
	}

	// Token: 0x06002C2D RID: 11309 RVA: 0x000204D3 File Offset: 0x0001E6D3
	public static bool smethod_5(Point point_0, Point point_1, Point point_2, Point point_3, Point point_4, Point point_5)
	{
		return Class426.smethod_4(point_0, point_1, point_2, point_3, point_4) || Class426.smethod_4(point_0, point_1, point_3, point_4, point_5);
	}

	// Token: 0x06002C2E RID: 11310 RVA: 0x00128FF0 File Offset: 0x001271F0
	public static int[] smethod_6(Point point_0, Point point_1)
	{
		int num = point_0.Y - point_1.Y;
		int num2 = point_1.X - point_0.X;
		int num3 = num * -point_0.X + num2 * -point_0.Y;
		return new int[]
		{
			num,
			num2,
			num3
		};
	}

	// Token: 0x06002C2F RID: 11311 RVA: 0x00129048 File Offset: 0x00127248
	public static int[] smethod_7(Point point_0, Point point_1, Point point_2)
	{
		int num = point_1.Y - point_2.Y;
		int num2 = point_2.X - point_1.X;
		int num3 = -num2 * -point_1.X + num * -point_1.Y;
		return new int[]
		{
			-num2,
			num,
			num3
		};
	}

	// Token: 0x06002C30 RID: 11312 RVA: 0x001290A0 File Offset: 0x001272A0
	public static float smethod_8(Point point_0, Point point_1, Point point_2)
	{
		int[] array = Class426.smethod_6(point_1, point_2);
		return (float)((double)Math.Abs(array[0] * point_0.X + array[1] * point_0.Y + array[2]) / Math.Sqrt(Math.Pow((double)array[0], 2.0) + Math.Pow((double)array[1], 2.0)));
	}

	// Token: 0x06002C31 RID: 11313 RVA: 0x00129104 File Offset: 0x00127304
	public static bool smethod_9(string string_2)
	{
		bool result = false;
		string[] array = new string[]
		{
			"--",
			"=",
			"'1",
			"1'",
			";--",
			";",
			"/*",
			"*/",
			"@@",
			"union",
			"nchar",
			"varchar",
			"nvarchar",
			"alter",
			"delete",
			"drop",
			"insert",
			"select",
			"sysobjects",
			"syscolumns",
			"table"
		};
		string text = string_2.Replace("'", "''");
		for (int i = 0; i <= array.Length - 1; i++)
		{
			if (text.IndexOf(array[i], StringComparison.OrdinalIgnoreCase) >= 0)
			{
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06002C32 RID: 11314 RVA: 0x00129200 File Offset: 0x00127400
	public static bool smethod_10(string string_2)
	{
		if (string_2.Trim() == string.Empty)
		{
			return false;
		}
		string pathRoot;
		string fileName;
		bool result;
		try
		{
			pathRoot = Path.GetPathRoot(string_2);
			fileName = Path.GetFileName(string_2);
			goto IL_2C;
		}
		catch (ArgumentException)
		{
			result = false;
		}
		return result;
		IL_2C:
		return !(fileName.Trim() == string.Empty) && pathRoot.IndexOfAny(Path.GetInvalidPathChars()) < 0 && fileName.IndexOfAny(Path.GetInvalidFileNameChars()) < 0;
	}

	// Token: 0x06002C33 RID: 11315 RVA: 0x000204F0 File Offset: 0x0001E6F0
	public static string smethod_11(int int_0)
	{
		return new string(Enumerable.Repeat<string>("abcdefghijklmnopqrstuvwxyz", int_0).Select(new Func<string, char>(Class426.Class431.<>9.method_0)).ToArray<char>());
	}

	// Token: 0x06002C34 RID: 11316 RVA: 0x00129280 File Offset: 0x00127480
	public static string smethod_12()
	{
		int count = Class426.random_0.Next(1, 10);
		return new string(Enumerable.Repeat<string>(" ", count).Select(new Func<string, char>(Class426.Class431.<>9.method_1)).ToArray<char>());
	}

	// Token: 0x06002C35 RID: 11317 RVA: 0x001292D4 File Offset: 0x001274D4
	public static string smethod_13(string string_2, string string_3, string string_4)
	{
		string text = null;
		int num = string_2.IndexOf(string_3);
		if (num != -1)
		{
			text = string_2.Substring(num + string_3.Length);
			if (string.IsNullOrEmpty(string_4))
			{
				return text;
			}
			int num2 = text.IndexOf(string_4);
			if (num2 != -1)
			{
				text = text.Substring(0, num2);
			}
			else
			{
				text = null;
			}
		}
		return text;
	}

	// Token: 0x06002C36 RID: 11318 RVA: 0x00016964 File Offset: 0x00014B64
	public static string smethod_14(int int_0)
	{
		if (int_0 == 0)
		{
			return "0";
		}
		return string.Format("{0:#,###}", int_0);
	}

	// Token: 0x06002C37 RID: 11319 RVA: 0x0002052B File Offset: 0x0001E72B
	public static string smethod_15(double double_0)
	{
		if (double_0 == 0.0)
		{
			return "0";
		}
		return string.Format("{0:#,###}", double_0);
	}

	// Token: 0x06002C38 RID: 11320 RVA: 0x0002054F File Offset: 0x0001E74F
	public static void smethod_16(TextBox textBox_0)
	{
		textBox_0.Select(textBox_0.Text.Length, 0);
		textBox_0.Focus();
		textBox_0.ScrollToCaret();
	}

	// Token: 0x06002C39 RID: 11321 RVA: 0x00020570 File Offset: 0x0001E770
	public static void smethod_17(TextBox textBox_0)
	{
		textBox_0.Select(0, 0);
		textBox_0.Focus();
		textBox_0.ScrollToCaret();
	}

	// Token: 0x06002C3A RID: 11322 RVA: 0x00129324 File Offset: 0x00127524
	public static string smethod_18()
	{
		NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
		string text = string.Empty;
		foreach (NetworkInterface networkInterface in allNetworkInterfaces)
		{
			if (text == string.Empty)
			{
				networkInterface.GetIPProperties();
				text = networkInterface.GetPhysicalAddress().ToString();
			}
		}
		return text;
	}

	// Token: 0x06002C3B RID: 11323 RVA: 0x00129370 File Offset: 0x00127570
	public static string smethod_19(string string_2, string string_3, string string_4, string string_5, NameValueCollection nameValueCollection_0)
	{
		string str = "---------------------------" + DateTime.Now.Ticks.ToString("x");
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_2);
		httpWebRequest.ContentType = "multipart/form-data; boundary=" + str;
		httpWebRequest.Method = "POST";
		httpWebRequest.KeepAlive = true;
		httpWebRequest.ServicePoint.Expect100Continue = false;
		using (Stream requestStream = httpWebRequest.GetRequestStream())
		{
			using (StreamWriter streamWriter = new StreamWriter(requestStream, Encoding.UTF8))
			{
				foreach (object obj in nameValueCollection_0.Keys)
				{
					string text = (string)obj;
					streamWriter.Write("\r\n" + str + "\r\n");
					streamWriter.Write(string.Format("Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}", text, nameValueCollection_0[text]));
				}
				streamWriter.Write("\r\n" + str + "\r\n");
				streamWriter.Write(string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n", string_4, string_3, string_5));
				using (new FileStream(string_3, FileMode.Open, FileAccess.Read))
				{
				}
				streamWriter.Write("\r\n--" + str + "--\r\n");
			}
		}
		try
		{
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				if (httpWebResponse.StatusCode == HttpStatusCode.OK)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						if (responseStream != null)
						{
							using (StreamReader streamReader = new StreamReader(responseStream))
							{
								return streamReader.ReadToEnd();
							}
						}
						return null;
					}
				}
				throw new ApplicationException("Error while upload files. Server status code: " + httpWebResponse.StatusCode.ToString());
			}
		}
		catch (Exception innerException)
		{
			throw new ApplicationException("Error while uploading file", innerException);
		}
		string result;
		return result;
	}

	// Token: 0x06002C3C RID: 11324 RVA: 0x001295DC File Offset: 0x001277DC
	public static void smethod_20(Stream stream_0, Stream stream_1)
	{
		byte[] array = new byte[4096];
		int count;
		while ((count = stream_0.Read(array, 0, array.Length)) != 0)
		{
			stream_1.Write(array, 0, count);
		}
	}

	// Token: 0x06002C3D RID: 11325 RVA: 0x00129610 File Offset: 0x00127810
	public static byte[] smethod_21(Stream stream_0)
	{
		int num = Convert.ToInt32(stream_0.Length);
		byte[] array = new byte[num];
		stream_0.Read(array, 0, num);
		return array;
	}

	// Token: 0x06002C3E RID: 11326 RVA: 0x0001698D File Offset: 0x00014B8D
	public static int smethod_22(bool bool_0)
	{
		if (bool_0)
		{
			return 1;
		}
		return 0;
	}

	// Token: 0x06002C3F RID: 11327 RVA: 0x0012963C File Offset: 0x0012783C
	public static Keys smethod_23(string string_2)
	{
		uint num = Class448.smethod_0(string_2);
		if (num <= 433243402U)
		{
			if (num <= 215134355U)
			{
				if (num <= 87056132U)
				{
					if (num != 3168037U)
					{
						if (num == 87056132U)
						{
							if (string_2 == "Alt 8")
							{
								return Keys.D8;
							}
						}
					}
					else if (string_2 == "Alt 3")
					{
						return Keys.D3;
					}
				}
				else if (num != 103833751U)
				{
					if (num != 198356736U)
					{
						if (num == 215134355U)
						{
							if (string_2 == "F8")
							{
								return Keys.F8;
							}
						}
					}
					else if (string_2 == "F9")
					{
						return Keys.F9;
					}
				}
				else if (string_2 == "Alt 9")
				{
					return Keys.D9;
				}
			}
			else if (num <= 382910545U)
			{
				if (num != 332577688U)
				{
					if (num != 366132926U)
					{
						if (num == 382910545U)
						{
							if (string_2 == "F2")
							{
								return Keys.F2;
							}
						}
					}
					else if (string_2 == "F3")
					{
						return Keys.F3;
					}
				}
				else if (string_2 == "F1")
				{
					return Keys.F1;
				}
			}
			else if (num != 399688164U)
			{
				if (num != 416465783U)
				{
					if (num == 433243402U)
					{
						if (string_2 == "F7")
						{
							return Keys.F7;
						}
					}
				}
				else if (string_2 == "F4")
				{
					return Keys.F4;
				}
			}
			else if (string_2 == "F5")
			{
				return Keys.F5;
			}
		}
		else if (num <= 4180692000U)
		{
			if (num <= 3703400824U)
			{
				if (num != 450021021U)
				{
					if (num == 3703400824U)
					{
						if (string_2 == "F10")
						{
							return Keys.F10;
						}
					}
				}
				else if (string_2 == "F6")
				{
					return Keys.F6;
				}
			}
			else if (num != 3720178443U)
			{
				if (num != 3736956062U)
				{
					if (num == 4180692000U)
					{
						if (string_2 == "Alt 4")
						{
							return Keys.D4;
						}
					}
				}
				else if (string_2 == "F12")
				{
					return Keys.F12;
				}
			}
			else if (string_2 == "F11")
			{
				return Keys.F11;
			}
		}
		else if (num <= 4231024857U)
		{
			if (num != 4197469619U)
			{
				if (num != 4214247238U)
				{
					if (num == 4231024857U)
					{
						if (string_2 == "Alt 7")
						{
							return Keys.D7;
						}
					}
				}
				else if (string_2 == "Alt 6")
				{
					return Keys.D6;
				}
			}
			else if (string_2 == "Alt 5")
			{
				return Keys.D5;
			}
		}
		else if (num != 4247802476U)
		{
			if (num != 4264580095U)
			{
				if (num == 4281357714U)
				{
					if (string_2 == "Alt 2")
					{
						return Keys.D2;
					}
				}
			}
			else if (string_2 == "Alt 1")
			{
				return Keys.D1;
			}
		}
		else if (string_2 == "Alt 0")
		{
			return Keys.D0;
		}
		return Keys.F13;
	}

	// Token: 0x06002C40 RID: 11328 RVA: 0x001298F8 File Offset: 0x00127AF8
	public static Keys smethod_24(int int_0)
	{
		switch (int_0)
		{
		case 0:
			return Keys.F1;
		case 1:
			return Keys.F2;
		case 2:
			return Keys.F3;
		case 3:
			return Keys.F4;
		case 4:
			return Keys.F5;
		case 5:
			return Keys.F6;
		case 6:
			return Keys.F7;
		case 7:
			return Keys.F8;
		case 8:
			return Keys.F9;
		case 9:
			return Keys.F10;
		case 10:
			return Keys.F11;
		case 11:
			return Keys.F12;
		case 12:
			return Keys.D1;
		case 13:
			return Keys.D2;
		case 14:
			return Keys.D3;
		case 15:
			return Keys.D4;
		case 16:
			return Keys.D5;
		case 17:
			return Keys.D6;
		case 18:
			return Keys.D7;
		case 19:
			return Keys.D8;
		case 20:
			return Keys.D9;
		case 21:
			return Keys.D0;
		default:
			return Keys.F13;
		}
	}

	// Token: 0x06002C41 RID: 11329 RVA: 0x001299A8 File Offset: 0x00127BA8
	public static int smethod_25(Keys keys_0)
	{
		switch (keys_0)
		{
		case Keys.D0:
			return 21;
		case Keys.D1:
			return 12;
		case Keys.D2:
			return 13;
		case Keys.D3:
			return 14;
		case Keys.D4:
			return 15;
		case Keys.D5:
			return 16;
		case Keys.D6:
			return 17;
		case Keys.D7:
			return 18;
		case Keys.D8:
			return 19;
		case Keys.D9:
			return 20;
		default:
			switch (keys_0)
			{
			case Keys.F1:
				return 0;
			case Keys.F2:
				return 1;
			case Keys.F3:
				return 2;
			case Keys.F4:
				return 3;
			case Keys.F5:
				return 4;
			case Keys.F6:
				return 5;
			case Keys.F7:
				return 6;
			case Keys.F8:
				return 7;
			case Keys.F9:
				return 8;
			case Keys.F10:
				return 9;
			case Keys.F11:
				return 10;
			case Keys.F12:
				return 11;
			default:
				return 22;
			}
			break;
		}
	}

	// Token: 0x06002C42 RID: 11330 RVA: 0x00129A5C File Offset: 0x00127C5C
	public static int smethod_26(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("namvuc"))
		{
			return 4;
		}
		if (string_2.Contains("quynhchau"))
		{
			return 4;
		}
		if (string_2.Contains("vodi"))
		{
			return 4;
		}
		if (string_2.Contains("haitacdong"))
		{
			return 4;
		}
		if (string_2.Contains("haitocdong"))
		{
			return 4;
		}
		if (string_2.Contains("mieunhandong"))
		{
			return 4;
		}
		if (string_2.Contains("namchieu"))
		{
			return 5;
		}
		if (string_2.Contains("diemho"))
		{
			return 5;
		}
		if (string_2.Contains("bachsadiemkhanh"))
		{
			return 5;
		}
		if (string_2.Contains("bochsadiemkhanh"))
		{
			return 5;
		}
		if (string_2.Contains("thachlam"))
		{
			return 5;
		}
		if (string_2.Contains("thochlam"))
		{
			return 5;
		}
		if (string_2.Contains("mieucuong"))
		{
			return 5;
		}
		if (string_2.Contains("ngockhe"))
		{
			return 5;
		}
		if (string_2.Contains("truongbachson"))
		{
			return 6;
		}
		if (string_2.Contains("truongbochson"))
		{
			return 6;
		}
		if (string_2.Contains("hoanglongphu"))
		{
			return 6;
		}
		if (string_2.Contains("tuyetlangho"))
		{
			return 6;
		}
		if (string_2.Contains("thaonguyen"))
		{
			return 6;
		}
		if (string_2.Contains("thuykinhho"))
		{
			return 6;
		}
		if (string_2.Contains("lieutay"))
		{
			return 6;
		}
		if (string_2.Contains("tienvuongphan"))
		{
			return 6;
		}
		if (string_2.Contains("nganngaituyetnguyen"))
		{
			return 6;
		}
		return -1;
	}

	// Token: 0x06002C43 RID: 11331 RVA: 0x00129BCC File Offset: 0x00127DCC
	public static int smethod_27(DateTime dateTime_0, DateTime dateTime_1)
	{
		return (int)(dateTime_1 - dateTime_0).TotalSeconds;
	}

	// Token: 0x06002C44 RID: 11332 RVA: 0x00129BEC File Offset: 0x00127DEC
	public static int smethod_28(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2 == "modong")
		{
			return 1;
		}
		if (string_2 == "mosat")
		{
			return 2;
		}
		if (string_2 == "mobac")
		{
			return 3;
		}
		if (string_2 == "mohanthiet")
		{
			return 4;
		}
		if (string_2 == "movang")
		{
			return 5;
		}
		if (string_2 == "mohuyenthiet")
		{
			return 6;
		}
		if (string_2 == "mophale")
		{
			return 7;
		}
		if (string_2 == "mophithuy")
		{
			return 8;
		}
		if (string_2 == "mochanvu")
		{
			return 9;
		}
		if (string_2 == "molonghuyet")
		{
			return 10;
		}
		if (string_2 == "mophunghuyet")
		{
			return 11;
		}
		return -1;
	}

	// Token: 0x06002C45 RID: 11333 RVA: 0x00129CAC File Offset: 0x00127EAC
	public static int smethod_29(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2 == "bachanh")
		{
			return 1;
		}
		if (string_2 == "bochanh")
		{
			return 1;
		}
		if (string_2 == "bohoang")
		{
			return 2;
		}
		if (string_2 == "xuyenboi")
		{
			return 3;
		}
		if (string_2 == "nguyenho")
		{
			return 4;
		}
		if (string_2 == "tyba")
		{
			return 5;
		}
		if (string_2 == "camthao")
		{
			return 6;
		}
		if (string_2 == "kimnganhoa")
		{
			return 7;
		}
		if (string_2 == "hoangcam")
		{
			return 8;
		}
		if (string_2 == "cauky")
		{
			return 9;
		}
		if (string_2 == "tramhuong")
		{
			return 10;
		}
		if (string_2 == "dotrong")
		{
			return 11;
		}
		if (string_2 == "thuongthuat")
		{
			return 12;
		}
		if (string_2 == "phuclinh")
		{
			return 13;
		}
		if (string_2 == "phongphong")
		{
			return 14;
		}
		if (string_2 == "huongnhu")
		{
			return 15;
		}
		if (string_2 == "hoanglien")
		{
			return 16;
		}
		if (string_2 == "duongqui")
		{
			return 17;
		}
		if (string_2 == "quetam")
		{
			return 18;
		}
		if (string_2 == "huongphu")
		{
			return 19;
		}
		if (string_2 == "hoachuong")
		{
			return 20;
		}
		if (string_2 == "hoithanthao")
		{
			return 21;
		}
		if (string_2 == "thuo")
		{
			return 22;
		}
		if (string_2 == "dongtrunghathao")
		{
			return 23;
		}
		if (string_2 == "dongtrunghothao")
		{
			return 23;
		}
		if (string_2 == "longquitu")
		{
			return 24;
		}
		if (string_2 == "tuongboi")
		{
			return 25;
		}
		if (string_2 == "nhansam")
		{
			return 26;
		}
		if (string_2 == "linhchi")
		{
			return 27;
		}
		if (string_2 == "tuanthao")
		{
			return 28;
		}
		if (string_2 == "lientu")
		{
			return 29;
		}
		if (string_2 == "khomocxuan")
		{
			return 30;
		}
		return -1;
	}

	// Token: 0x06002C46 RID: 11334 RVA: 0x00129EBC File Offset: 0x001280BC
	public static string smethod_30(uint uint_0)
	{
		if (Class363.dictionary_4.ContainsKey((int)uint_0))
		{
			return Class426.smethod_57(Class363.dictionary_4[(int)uint_0]);
		}
		if ((ulong)uint_0 == (ulong)((long)Class365.Int32_8))
		{
			return "kinhho";
		}
		if (uint_0 == 0U)
		{
			return "lacduong";
		}
		if (uint_0 == 1U)
		{
			return "tochau";
		}
		if (uint_0 == 2U)
		{
			return "daily";
		}
		if (uint_0 == 3U)
		{
			return "tungson";
		}
		if (uint_0 == 4U)
		{
			return "thaiho";
		}
		if (uint_0 == 7U)
		{
			return "kiemcac";
		}
		if (uint_0 == 8U)
		{
			return "donhoang";
		}
		if (uint_0 == 18U)
		{
			return "nhannam";
		}
		if (uint_0 == 19U)
		{
			return "nhanbac";
		}
		if (uint_0 == 20U)
		{
			return "thaonguyen";
		}
		if (uint_0 == 21U)
		{
			return "lieutay";
		}
		if (uint_0 == 22U)
		{
			return "truongbachson";
		}
		if (uint_0 == 23U)
		{
			return "hoanglongphu";
		}
		if (uint_0 == 24U)
		{
			return "nhihai";
		}
		if (uint_0 == 25U)
		{
			return "thuongson";
		}
		if (uint_0 == 26U)
		{
			return "thachlam";
		}
		if (uint_0 == 27U)
		{
			return "ngockhue";
		}
		if (uint_0 == 28U)
		{
			return "namchieu";
		}
		if (uint_0 == 29U)
		{
			return "mieucuong";
		}
		if (uint_0 == 30U)
		{
			return "tayho";
		}
		if (uint_0 == 31U)
		{
			return "longtuyen";
		}
		if (uint_0 == 32U)
		{
			return "vodi";
		}
		if (uint_0 == 33U)
		{
			return "mailinh";
		}
		if (uint_0 == 34U)
		{
			return "namhai";
		}
		if (uint_0 == 35U)
		{
			return "quynhchau";
		}
		return "khongbiet";
	}

	// Token: 0x06002C47 RID: 11335 RVA: 0x0012A008 File Offset: 0x00128208
	public static string smethod_31(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("thaonguyen"))
		{
			if (string_2.Contains("chinhdong"))
			{
				return "271,191,20," + Class424.class424_71.UInt32_0.ToString();
			}
			if (string_2.Contains("chinhbac"))
			{
				return "0,0,20," + Class424.class424_71.UInt32_0.ToString();
			}
			if (string_2.Contains("chinhtay"))
			{
				return "66,202,20," + Class424.class424_72.UInt32_0.ToString();
			}
			if (string_2.Contains("taynam"))
			{
				return "97,281,20," + Class424.class424_70.UInt32_0.ToString();
			}
		}
		else if (!string_2.Contains("nhannam") && !string_2.Contains("nhonnam"))
		{
			if (!string_2.Contains("nhanbac") && !string_2.Contains("nhonbac"))
			{
				if (string_2.Contains("lieutay"))
				{
					if (string_2.Contains("dongnam"))
					{
						return "277,258,21," + Class424.class424_73.UInt32_0.ToString();
					}
					if (string_2.Contains("taybac"))
					{
						return "75,35,21," + Class424.class424_74.UInt32_0.ToString();
					}
					if (string_2.Contains("chinhtay"))
					{
						return "40,142,21," + Class424.class424_75.UInt32_0.ToString();
					}
					if (string_2.Contains("huongnam"))
					{
						return "0,0,21," + Class424.class424_75.UInt32_0.ToString();
					}
				}
				else if (!string_2.Contains("truongbachson") && !string_2.Contains("truongbochson"))
				{
					if (string_2.Contains("hoanglongphu"))
					{
						if (string_2.Contains("dongnam"))
						{
							return "253,285,23," + Class424.class424_81.UInt32_0.ToString();
						}
						if (string_2.Contains("taybac"))
						{
							return "28,54,23," + Class424.class424_80.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhdong"))
						{
							return "290,115,23," + Class424.class424_79.UInt32_0.ToString();
						}
						if (string_2.Contains("huongnam"))
						{
							return "0,0,,23," + Class424.class424_79.UInt32_0.ToString();
						}
					}
					else if (string_2.Contains("nhihai"))
					{
						if (string_2.Contains("chinhdong"))
						{
							return "285,166,24," + Class424.class424_82.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhnam"))
						{
							return "173,283,24," + Class424.class424_83.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhtay"))
						{
							return "34,100,24," + Class424.class424_84.UInt32_0.ToString();
						}
						if (string_2.Contains("huongnam"))
						{
							return "0,0,24," + Class424.class424_84.UInt32_0.ToString();
						}
					}
					else if (string_2.Contains("thuongson"))
					{
						if (string_2.Contains("tay"))
						{
							return "37,172,25," + Class424.class424_85.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhdong"))
						{
							return "294,153,25," + Class424.class424_86.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhnam"))
						{
							return "146,284,25," + Class424.class424_87.UInt32_0.ToString();
						}
						if (string_2.Contains("huongnam"))
						{
							return "0,0,25," + Class424.class424_87.UInt32_0.ToString();
						}
					}
					else if (!string_2.Contains("thachlam") && !string_2.Contains("thochlam"))
					{
						if (string_2.Contains("mieucuong"))
						{
							if (string_2.Contains("dongbac"))
							{
								return "250,45,29," + Class424.class424_97.UInt32_0.ToString();
							}
							if (string_2.Contains("taynam"))
							{
								return "37,251,29," + Class424.class424_98.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhdong"))
							{
								return "281,160,29," + Class424.class424_99.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,29," + Class424.class424_99.UInt32_0.ToString();
							}
						}
						else if (string_2.Contains("tayho"))
						{
							if (string_2.Contains("taynam"))
							{
								return "45,267,30," + Class424.class424_59.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhdong"))
							{
								return "261,231,30," + Class424.class424_58.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhtay"))
							{
								return "39,139,30," + Class424.class424_60.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,30," + Class424.class424_60.UInt32_0.ToString();
							}
						}
						else if (string_2.Contains("longtuyen"))
						{
							if (string_2.Contains("dongnam"))
							{
								return "218,282,31," + Class424.class424_61.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhbac"))
							{
								return "63,33,31," + Class424.class424_62.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhtay"))
							{
								return "35,121,31," + Class424.class424_63.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,31," + Class424.class424_63.UInt32_0.ToString();
							}
						}
						else if (string_2.Contains("vodi"))
						{
							if (string_2.Contains("dongbac"))
							{
								return "254,38,32," + Class424.class424_52.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhnam"))
							{
								return "113,280,32," + Class424.class424_53.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhtay"))
							{
								return "92,172,32," + Class424.class424_54.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,32," + Class424.class424_54.UInt32_0.ToString();
							}
						}
						else if (string_2.Contains("mailinh"))
						{
							if (string_2.Contains("dongbac"))
							{
								return "271,37,33," + Class424.class424_55.UInt32_0.ToString();
							}
							if (string_2.Contains("taybac"))
							{
								return "31,90,33," + Class424.class424_56.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhdong"))
							{
								return "282,236,33," + Class424.class424_57.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,33," + Class424.class424_57.UInt32_0.ToString();
							}
						}
						else if (string_2.Contains("namvuc"))
						{
							if (string_2.Contains("dongbac"))
							{
								return "292,58,34," + Class424.class424_49.UInt32_0.ToString();
							}
							if (string_2.Contains("taynam"))
							{
								return "108,227,34," + Class424.class424_50.UInt32_0.ToString();
							}
							if (string_2.Contains("chinhbac"))
							{
								return "134,40,34," + Class424.class424_51.UInt32_0.ToString();
							}
							if (string_2.Contains("huongnam"))
							{
								return "0,0,34," + Class424.class424_51.UInt32_0.ToString();
							}
						}
						else
						{
							if (!string_2.Contains("quynhchau"))
							{
								return "";
							}
							if (string_2.Contains("dongc"))
							{
								return "243,150,35," + Class424.class424_46.UInt32_0.ToString();
							}
							if (string_2.Contains("dongbac"))
							{
								return "273,52,35," + Class424.class424_47.UInt32_0.ToString();
							}
							if (string_2.Contains("tay"))
							{
								return "80,139,35," + Class424.class424_48.UInt32_0.ToString();
							}
							if (string_2.Contains("nam"))
							{
								return "0,0,35," + Class424.class424_48.UInt32_0.ToString();
							}
						}
					}
					else
					{
						if (string_2.Contains("chinhbac"))
						{
							return "226,36,26," + Class424.class424_88.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhnam"))
						{
							return "278,281,26," + Class424.class424_89.UInt32_0.ToString();
						}
						if (string_2.Contains("chinhtay"))
						{
							return "45,177,26," + Class424.class424_90.UInt32_0.ToString();
						}
						if (string_2.Contains("huongnam"))
						{
							return "0,0,26," + Class424.class424_90.UInt32_0.ToString();
						}
					}
				}
				else
				{
					if (string_2.Contains("chinhnam"))
					{
						return "216,282," + Class424.class424_76.UInt32_0.ToString();
					}
					if (string_2.Contains("taybac"))
					{
						return "39,63," + Class424.class424_77.UInt32_0.ToString();
					}
					if (string_2.Contains("chinhdong"))
					{
						return "280,154," + Class424.class424_78.UInt32_0.ToString();
					}
					if (string_2.Contains("chinhnam"))
					{
						return "0,0,22," + Class424.class424_78.UInt32_0.ToString();
					}
				}
			}
			else
			{
				if (string_2.Contains("dongbac"))
				{
					return "234,24,19," + Class424.class424_67.UInt32_0.ToString();
				}
				if (string_2.Contains("taybac"))
				{
					return "116,29,19," + Class424.class424_68.UInt32_0.ToString();
				}
				if (string_2.Contains("chinhtay"))
				{
					return "32,128,19," + Class424.class424_69.UInt32_0.ToString();
				}
				if (string_2.Contains("huongnam"))
				{
					return "0,0,19," + Class424.class424_69.UInt32_0.ToString();
				}
			}
		}
		else
		{
			if (string_2.Contains("chinhdong"))
			{
				return "283,113,18," + Class424.class424_64.UInt32_0.ToString();
			}
			if (string_2.Contains("chinhbac"))
			{
				return "102,36,18," + Class424.class424_65.UInt32_0.ToString();
			}
			if (string_2.Contains("chinhtay"))
			{
				return "0,0,18," + Class424.class424_65.UInt32_0.ToString();
			}
			if (string_2.Contains("chinhnam"))
			{
				return "72,284,18," + Class424.class424_66.UInt32_0.ToString();
			}
		}
		return "";
	}

	// Token: 0x06002C48 RID: 11336 RVA: 0x0012AC18 File Offset: 0x00128E18
	public static string smethod_32(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("thaonguyen") || string_2.Contains("hoanglongphu") || string_2.Contains("truongbachson") || string_2.Contains("truongbochson") || string_2.Contains("lieutay"))
		{
			return "256,51,20";
		}
		if (string_2.Contains("nhanbac") || string_2.Contains("nhonbac") || string_2.Contains("nhannam") || string_2.Contains("nhonnam"))
		{
			return "277,54,19";
		}
		if (string_2.Contains("nhihai") || string_2.Contains("thuongson"))
		{
			return "77,206,24";
		}
		if (string_2.Contains("thachlam") || string_2.Contains("thochlam") || string_2.Contains("namchieu") || string_2.Contains("ngockhe"))
		{
			return "73,214,26";
		}
		if (string_2.Contains("mieucuong"))
		{
			return "195,49,29";
		}
		if (string_2.Contains("tayho") || string_2.Contains("longtuyen"))
		{
			return "134,165,30";
		}
		if (string_2.Contains("vodi"))
		{
			return "69,106,32";
		}
		if (string_2.Contains("namvuc"))
		{
			return "110,64,34";
		}
		if (string_2.Contains("quynhchau"))
		{
			return "136,236,35";
		}
		if (string_2.Contains("thaiho"))
		{
			return "246,146,4";
		}
		return "-1";
	}

	// Token: 0x06002C49 RID: 11337 RVA: 0x0012ADBC File Offset: 0x00128FBC
	public static int smethod_33(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("lacduong"))
		{
			return 0;
		}
		if (string_2.Contains("locduong"))
		{
			return 0;
		}
		if (string_2.Contains("tochau"))
		{
			return 1;
		}
		if (string_2.Contains("daily"))
		{
			return 2;
		}
		if (string_2.Contains("doily"))
		{
			return 2;
		}
		if (string_2.Contains("doilu"))
		{
			return 2;
		}
		if (string_2.Contains("tungson"))
		{
			return 3;
		}
		if (string_2.Contains("thaiho"))
		{
			return 4;
		}
		if (string_2.Contains("kinhho"))
		{
			return 5;
		}
		if (string_2.Contains("voluongson"))
		{
			return 6;
		}
		if (string_2.Contains("kiemcac"))
		{
			return 7;
		}
		if (string_2.Contains("donhoang"))
		{
			return 8;
		}
		if (string_2.Contains("thieulamtu"))
		{
			return 9;
		}
		if (string_2.Contains("caibangtongda"))
		{
			return 10;
		}
		if (string_2.Contains("quangminhdien"))
		{
			return 11;
		}
		if (string_2.Contains("vodangson"))
		{
			return 12;
		}
		if (string_2.Contains("thienlongtu"))
		{
			return 13;
		}
		if (string_2.Contains("langbadong"))
		{
			return 14;
		}
		if (string_2.Contains("ngamison"))
		{
			return 15;
		}
		if (string_2.Contains("tinhtuchai"))
		{
			return 16;
		}
		if (string_2.Contains("thienson"))
		{
			return 17;
		}
		if (string_2.Contains("nhannam"))
		{
			return 18;
		}
		if (string_2.Contains("nhonnam"))
		{
			return 18;
		}
		if (string_2.Contains("nhanbac"))
		{
			return 19;
		}
		if (string_2.Contains("nhonbac"))
		{
			return 19;
		}
		if (string_2.Contains("thaonguyen"))
		{
			return 20;
		}
		if (string_2.Contains("lieutay"))
		{
			return 21;
		}
		if (string_2.Contains("truongbachson"))
		{
			return 22;
		}
		if (string_2.Contains("truongbochson"))
		{
			return 22;
		}
		if (string_2.Contains("hoanglongphu"))
		{
			return 23;
		}
		if (string_2.Contains("nhihai"))
		{
			return 24;
		}
		if (string_2.Contains("thuongson"))
		{
			return 25;
		}
		if (string_2.Contains("thachlam"))
		{
			return 26;
		}
		if (string_2.Contains("thochlam"))
		{
			return 26;
		}
		if (string_2.Contains("ngockhe"))
		{
			return 27;
		}
		if (string_2.Contains("namchieu"))
		{
			return 28;
		}
		if (string_2.Contains("mieucuong"))
		{
			return 29;
		}
		if (string_2.Contains("tayho"))
		{
			return 30;
		}
		if (string_2.Contains("longtuyen"))
		{
			return 31;
		}
		if (string_2.Contains("vodi"))
		{
			return 32;
		}
		if (string_2.Contains("mailinh"))
		{
			return 33;
		}
		if (string_2.Contains("namvuc"))
		{
			return 34;
		}
		if (string_2.Contains("quynhchau"))
		{
			return 35;
		}
		if (string_2.Contains("huyenvudao"))
		{
			return 112;
		}
		if (string_2.Contains("baotangdongtang1"))
		{
			return 166;
		}
		if (string_2.Contains("baotangdongtang2"))
		{
			return 169;
		}
		if (string_2.Contains("nganngaituyetnguyen"))
		{
			return 229;
		}
		if (string_2.Contains("baotangdongtang3"))
		{
			return 191;
		}
		if (string_2.Contains("baotangdongtang4"))
		{
			return 192;
		}
		if (string_2.Contains("baotangdongtang5"))
		{
			return 193;
		}
		if (string_2.Contains("thaolieutruong"))
		{
			return 199;
		}
		if (string_2.Contains("mieu nhan dong"))
		{
			return 200;
		}
		if (string_2.Contains("thanh thu son"))
		{
			return 201;
		}
		if (string_2.Contains("yenvuongcomotang1"))
		{
			return 202;
		}
		if (string_2.Contains("yenvuongcomotang2"))
		{
			return 203;
		}
		if (string_2.Contains("yenvuongcomotang3"))
		{
			return 204;
		}
		if (string_2.Contains("yenvuongcomotang4"))
		{
			return 205;
		}
		if (string_2.Contains("yenvuongcomotang5"))
		{
			return 206;
		}
		if (string_2.Contains("yenvuongcomotang6"))
		{
			return 207;
		}
		if (string_2.Contains("yenvuongcomotang7"))
		{
			return 208;
		}
		if (string_2.Contains("yenvuongcomotang8"))
		{
			return 209;
		}
		if (string_2.Contains("yenvuongcomotang9"))
		{
			return 210;
		}
		if (string_2.Contains("bentausondong"))
		{
			return 211;
		}
		if (string_2.Contains("kiemgia"))
		{
			return 212;
		}
		if (string_2.Contains("manhaidong"))
		{
			return 213;
		}
		if (string_2.Contains("danhancau"))
		{
			return 214;
		}
		if (string_2.Contains("ontuyendong"))
		{
			return 215;
		}
		if (string_2.Contains("hoanglongdong"))
		{
			return 216;
		}
		if (string_2.Contains("thuykinhho"))
		{
			return 217;
		}
		if (string_2.Contains("tienvuongphan"))
		{
			return 218;
		}
		if (string_2.Contains("thienkhanhthudong"))
		{
			return 219;
		}
		if (string_2.Contains("daohoanguyen"))
		{
			return 220;
		}
		if (string_2.Contains("haitacdong"))
		{
			return 221;
		}
		if (string_2.Contains("tuyetlangho"))
		{
			return 222;
		}
		if (string_2.Contains("diemho"))
		{
			return 235;
		}
		if (string_2.Contains("bachsadiemkhanh"))
		{
			return 237;
		}
		if (string_2.Contains("bochsadiemkhanh"))
		{
			return 237;
		}
		if (string_2.Contains("hoadiemson"))
		{
			return 244;
		}
		if (string_2.Contains("caoxuong"))
		{
			return 245;
		}
		if (string_2.Contains("laulan"))
		{
			return 246;
		}
		if (string_2.Contains("thaplymoc"))
		{
			return 247;
		}
		if (string_2.Contains("thaplumoc"))
		{
			return 247;
		}
		if (string_2.Contains("hoadiemcoc"))
		{
			return 251;
		}
		if (string_2.Contains("caoxuongmecung"))
		{
			return 252;
		}
		if (string_2.Contains("thapkhaclapmacan"))
		{
			return 253;
		}
		if (string_2.Contains("daiuyen"))
		{
			return 249;
		}
		if (string_2.Contains("hanhuyetlinh"))
		{
			return 255;
		}
		if (string_2.Contains("honhuyetlinh"))
		{
			return 255;
		}
		if (string_2.Contains("tanhoangdiacungtang1"))
		{
			return 262;
		}
		if (string_2.Contains("tanhoangdiacungtang2"))
		{
			return 263;
		}
		if (string_2.Contains("tanhoangdiacungtang3"))
		{
			return 264;
		}
		if (string_2.Contains("tanhoangdiacungtang4"))
		{
			return 292;
		}
		if (string_2.Contains("datayho"))
		{
			return 164;
		}
		if (string_2.Contains("dotayho"))
		{
			return 164;
		}
		if (string_2.Contains("conlonphucdia"))
		{
			return 254;
		}
		if (string_2.Contains("conlonson"))
		{
			return 248;
		}
		if (string_2.Contains("thanhnguyen"))
		{
			return 282;
		}
		if (string_2.Contains("thanhnguyensondong"))
		{
			return 283;
		}
		if (string_2.Contains("modungsontrang"))
		{
			return 284;
		}
		if (string_2.Contains("tatmanhihan"))
		{
			return 250;
		}
		if (string_2.Contains("thanhhoacung"))
		{
			return 256;
		}
		if (string_2.Contains("lamhaikhecoc"))
		{
			return 569;
		}
		if (string_2.Contains("macnamthanhnguyen"))
		{
			return 573;
		}
		if (string_2.Contains("vongxuyenhoahai"))
		{
			return 574;
		}
		if (string_2.Contains("thienkynamhoai"))
		{
			return 575;
		}
		if (string_2.Contains("thongthienthapdiacung"))
		{
			return 295;
		}
		if (string_2.Contains("thongthienthaptang1"))
		{
			return 296;
		}
		if (string_2.Contains("thongthienthaptang2"))
		{
			return 297;
		}
		if (string_2.Contains("thongthienthaptang3"))
		{
			return 298;
		}
		if (string_2.Contains("dinhthongthienthap"))
		{
			return 299;
		}
		if (string_2.Contains("phungminhtran"))
		{
			return 580;
		}
		if (string_2.Contains("laulan"))
		{
			return 246;
		}
		if (string_2.Contains("thuchacotran"))
		{
			return 260;
		}
		if (string_2.Contains("denhatkhunghingoitailacduong"))
		{
			return 238;
		}
		if (string_2.Contains("khunghingoitaidaily"))
		{
			return 240;
		}
		if (string_2.Contains("khunghingoitaitochau"))
		{
			return 241;
		}
		if (string_2.Contains("hanngoccoc"))
		{
			return 243;
		}
		if (string_2.Contains("thuynguyetdongthien"))
		{
			return 613;
		}
		if (string_2.Contains("huyenhai"))
		{
			return 611;
		}
		if (string_2.Contains("daicondihai"))
		{
			return 612;
		}
		if (string_2.Contains("phungminhtran"))
		{
			return 580;
		}
		if (string_2.Contains("thuynguyetdongthien"))
		{
			return 613;
		}
		if (string_2.Contains("lacduong"))
		{
			return 242;
		}
		if (string_2.Contains("huyenvudao"))
		{
			return 112;
		}
		if (string_2.Contains("laulan"))
		{
			return 246;
		}
		if (string_2.Contains("thuchacotran"))
		{
			return 260;
		}
		if (string_2.Contains("denhatkhunghingoitailacdduong"))
		{
			return 238;
		}
		if (string_2.Contains("denhikhunghingoitailacduong"))
		{
			return 239;
		}
		if (string_2.Contains("modungsontrang"))
		{
			return 284;
		}
		if (string_2.Contains("tientrang"))
		{
			return 224;
		}
		if (string_2.Contains("phungminhtran"))
		{
			return 580;
		}
		if (string_2.Contains("huyenvudao"))
		{
			return 112;
		}
		if (string_2.Contains("quangminhdong"))
		{
			return 601;
		}
		if (string_2.Contains("daycoctieudao"))
		{
			return 602;
		}
		if (string_2.Contains("linhtinhphong"))
		{
			return 603;
		}
		if (string_2.Contains("caibangtuudieu"))
		{
			return 604;
		}
		if (string_2.Contains("daohoatran"))
		{
			return 605;
		}
		if (string_2.Contains("thaplam"))
		{
			return 606;
		}
		if (string_2.Contains("nguthandong"))
		{
			return 607;
		}
		if (string_2.Contains("chietmaiphong"))
		{
			return 608;
		}
		if (string_2.Contains("chanthap"))
		{
			return 609;
		}
		if (string_2.Contains("tangthuthuycac"))
		{
			return 610;
		}
		if (string_2.Contains("hauhoavien"))
		{
			return 123;
		}
		if (string_2.Contains("tieumocnhanhang"))
		{
			return 122;
		}
		if (string_2.Contains("duonggiabao"))
		{
			return 615;
		}
		if (string_2.Contains("laulan"))
		{
			return 246;
		}
		if (string_2.Contains("thuchacotran"))
		{
			return 260;
		}
		if (string_2.Contains("modungsontrang"))
		{
			return 284;
		}
		if (string_2.Contains("phungminhtran"))
		{
			return 580;
		}
		if (string_2.Contains("dienvotruong"))
		{
			return 617;
		}
		if (string_2.Contains("quanthienthanh"))
		{
			return 581;
		}
		if (string_2.Contains("trieukinhthanh"))
		{
			return 583;
		}
		if (string_2.Contains("laphuthanh"))
		{
			return 582;
		}
		return -1;
	}

	// Token: 0x06002C4A RID: 11338 RVA: 0x0012B894 File Offset: 0x00129A94
	public static string smethod_34(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("trithanhdaisu") || string_2.Contains("bhrwsc_110331_53"))
		{
			return "0,176,192,trithanhdaisu,34";
		}
		if (string_2.Contains("trithanhdoisu") || string_2.Contains("bhrwsc_110331_53"))
		{
			return "0,176,192,trithanhdoisu,34";
		}
		if (string_2.Contains("doanchinhthuan"))
		{
			return "2,71,18,doanchinhthuan,16";
		}
		if (string_2.Contains("tothuc"))
		{
			return "1,166,311,tothuc,2";
		}
		return "";
	}

	// Token: 0x06002C4B RID: 11339 RVA: 0x00020587 File Offset: 0x0001E787
	public static string smethod_35(string string_2)
	{
		if (string_2.Contains("#{SDHDRW_091109_44}"))
		{
			return "104,123";
		}
		return "";
	}

	// Token: 0x06002C4C RID: 11340 RVA: 0x000205A1 File Offset: 0x0001E7A1
	public static string smethod_36(string string_2)
	{
		if (string_2.Contains("#{SDHDRW_091109_41}"))
		{
			return "4,168,200,229,117,114,128,116,186,168,200";
		}
		return "";
	}

	// Token: 0x06002C4D RID: 11341 RVA: 0x0012B914 File Offset: 0x00129B14
	public static string smethod_37(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("longtu"))
		{
			return "186,98,142,hotutruonglao,13035,96,142";
		}
		if (string_2.Contains("modungsontrang"))
		{
			return "289,152,154,congdakhon,9044,160,169";
		}
		if (string_2.Contains("duonggiabao"))
		{
			return "616,152,154,duongmotuong,10051,173,170";
		}
		if (string_2.Contains("tinhtuchai"))
		{
			return "189,100,145,thientoantu,16035,96,142";
		}
		if (string_2.Contains("badong"))
		{
			return "187,45,126,congdatutruong,14035,44,129";
		}
		if (string_2.Contains("thieulamtu"))
		{
			return "182,99,146,huyenchung,9035,96,158";
		}
		if (string_2.Contains("thienson"))
		{
			return "190,94,147,dangba,17035,95,148";
		}
		if (string_2.Contains("ngamison"))
		{
			return "188,95,146,lieutammuoi,15035,89,146";
		}
		if (string_2.Contains("vodangson"))
		{
			return "185,100,181,tieuthiendat,12035,95,192";
		}
		if (string_2.Contains("quangminhdien"))
		{
			return "184,95,162,thaccang,11035,98,159";
		}
		if (string_2.Contains("caibangtongda"))
		{
			return "183,93,152,auduongqua,10035,91,159";
		}
		return "";
	}

	// Token: 0x06002C4E RID: 11342 RVA: 0x0012BA00 File Offset: 0x00129C00
	public static string smethod_38(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		if (string_2.Contains("dietyeukhoiloi"))
		{
			return "127,113,dietyeukhoiloi";
		}
		if (string_2.Contains("trutienkhoiloi"))
		{
			return "95,80,trutienkhoiloi";
		}
		if (string_2.Contains("thithankhoiloi"))
		{
			return "51,72,thithankhoiloi";
		}
		if (string_2.Contains("thambiphitac"))
		{
			return "69,126,thambiphitac";
		}
		if (string_2.Contains("tamthuphitac"))
		{
			return "54,61,tamthuphitac";
		}
		if (string_2.Contains("suubaophitac"))
		{
			return "68,142,phitieuthiettac";
		}
		if (string_2.Contains("tatlethiettac"))
		{
			return "98,70,tatlethiettac";
		}
		if (string_2.Contains("docchamthiettac"))
		{
			return "51,69,docchamthiettac";
		}
		if (string_2.Contains("phitieuthiettac"))
		{
			return "100,181,phitieuthiettac";
		}
		if (string_2.Contains("mocvuongtrithu"))
		{
			return "96,126,mocvuongtrithu";
		}
		if (string_2.Contains("thuyvuongtrithu"))
		{
			return "118,112,thuyvuongtrithu";
		}
		if (string_2.Contains("hoavuongtrithu"))
		{
			return "96,86,hoavuongtrithu";
		}
		if (string_2.Contains("huthekhoiloi"))
		{
			return "52,72,huthekhoiloi";
		}
		if (string_2.Contains("thuctamkhoiloi"))
		{
			return "120,140,thuctamkhoiloi";
		}
		if (string_2.Contains("hoaphachkhoiloi"))
		{
			return "146,58,hoaphachkhoiloi";
		}
		if (string_2.Contains("mocnhanlaula"))
		{
			return "96,110,mocnhanlaula";
		}
		if (string_2.Contains("mocnhantinhanh"))
		{
			return "96,80,mocnhantinhanh";
		}
		if (string_2.Contains("mocnhanvosi"))
		{
			return "40,98,mocnhanvosi";
		}
		if (string_2.Contains("thiensontieutuyetquai"))
		{
			return "96,110,thiensontieutuyetquai";
		}
		if (string_2.Contains("thiensondaituyetquai"))
		{
			return "96,86,thiensondaituyetquai";
		}
		if (string_2.Contains("thiensontuyetquaivuong"))
		{
			return "96,50,thiensontuyetquaivuong";
		}
		if (string_2.Contains("ngamibachmyacvien"))
		{
			return "139,106,ngamibachmyacvien";
		}
		if (string_2.Contains("ngamiloitraoacvien"))
		{
			return "96,63,ngamiloitraoacvien";
		}
		if (string_2.Contains("ngamihungnhu"))
		{
			return "44,45,ngamihungnhu";
		}
		if (string_2.Contains("yeuditamma"))
		{
			return "59,180,yeuditamma";
		}
		if (string_2.Contains("phasantamma"))
		{
			return "78,132,phasantamma";
		}
		if (string_2.Contains("satductamma"))
		{
			return "46,58,satductamma";
		}
		if (string_2.Contains("matthamtienphong"))
		{
			return "97,117,matthamtienphong";
		}
		if (string_2.Contains("thanhkythamma"))
		{
			return "155,102,thanhkythamma";
		}
		if (string_2.Contains("lamkythamma"))
		{
			return "98,65,lamkythamma";
		}
		if (string_2.Contains("phuccuuachau"))
		{
			return "69,145,phuccuuachau";
		}
		if (string_2.Contains("cuongtrangachau"))
		{
			return "45,115,cuongtrangachau";
		}
		if (string_2.Contains("tinhtrangachau"))
		{
			return "44,79,tinhtrangachau";
		}
		return "";
	}

	// Token: 0x06002C4F RID: 11343 RVA: 0x0012BC90 File Offset: 0x00129E90
	public static string smethod_39(string string_2)
	{
		string_2 = string_2.Replace("Vương Đức Phú", "Vương Đức Phúc");
		string_2 = string_2.Replace("Bách Hiểu Sinh", "Bạch Manh Sinh");
		string_2 = string_2.Replace("Mộ Dung Chùy", "Mộ Dung Thùy");
		if (string_2.Contains("Huyền Hồ Uyển"))
		{
			return "INFOAIM139,146,678,TuoiNuoc";
		}
		if (string_2.Contains("Quan Tinh Đài"))
		{
			return "INFOAIM60,42,678,TuoiNuoc";
		}
		if (string_2.Contains("Vu Sơn Cảnh"))
		{
			return "INFOAIM40,100,678,TuoiNuoc";
		}
		if (string_2.Contains("Âm Dương Thiên Đông Trắc"))
		{
			return "INFOAIM128,71,678,TuoiNuoc";
		}
		if (string_2.Contains("Thính Hương Thủy Tạ"))
		{
			return "INFOAIM154,93,284,TuoiNuoc";
		}
		if (string_2.Contains("Cầm Âm Tiểu Trúc"))
		{
			return "INFOAIM78,142,284,TuoiNuoc";
		}
		if (string_2.Contains("Sâm Hợp Trang"))
		{
			return "INFOAIM28,28,284,TuoiNuoc";
		}
		if (string_2.Contains("Mạn Đà Viên"))
		{
			return "INFOAIM119,36,284,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_47}#r"))
		{
			return "INFOAIM67,110,284,MoDungThuy,PhuBan";
		}
		if (string_2.Contains("Túc Thái Âm Tì Kinh Đồng Nhân"))
		{
			return "INFOAIM121,90,13,TuoiNuoc";
		}
		if (string_2.Contains("Thủ Thái Âm Phế Kinh Đồng Nhân"))
		{
			return "INFOAIM62,90,13,TuoiNuoc";
		}
		if (string_2.Contains("Túc Dương Minh Vị Kinh Đồng Nhân"))
		{
			return "INFOAIM106,85,13,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_41}#{SMXL_090819_dali}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM35,86,13,BanTuong,PhuBan";
		}
		if (string_2.Contains("Người đồng thủ dương minh đại trường kinh"))
		{
			return "INFOAIM84,84,13,TuoiNuoc";
		}
		if (string_2.Contains("Hoàng Thổ Kỳ"))
		{
			return "INFOAIM62,38,11,TuoiNuoc";
		}
		if (string_2.Contains("Bạch Kim Kỳ"))
		{
			return "INFOAIM65,139,11,TuoiNuoc";
		}
		if (string_2.Contains("Thanh Mộc Kỳ"))
		{
			return "INFOAIM131,139,11,TuoiNuoc";
		}
		if (string_2.Contains("Hắc Thủy Kỳ"))
		{
			return "INFOAIM129,55,11,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_51}#{SMXL_090819_mingjiao}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM89,56,11,PhuongLap,PhuBan";
		}
		if (string_2.Contains("Đang Thanh Họa"))
		{
			return "INFOAIM142,59,14,TuoiNuoc";
		}
		if (string_2.Contains("Lạn Kha Kỳ"))
		{
			return "INFOAIM136,145,14,TuoiNuoc";
		}
		if (string_2.Contains("Phụng Hoàng Cầm"))
		{
			return "INFOAIM42,144,14,TuoiNuoc";
		}
		if (string_2.Contains("Thánh Hiền Thư"))
		{
			return "INFOAIM47,54,14,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_45}#{SMXL_090819_xiaoyao}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM62,68,14,PhungATam,PhuBan";
		}
		if (string_2.Contains("Kim Điện"))
		{
			return "INFOAIM82,58,12,TuoiNuoc";
		}
		if (string_2.Contains("Thiên Giới"))
		{
			return "INFOAIM45,87,12,TuoiNuoc";
		}
		if (string_2.Contains("Hồi Long Đài"))
		{
			return "INFOAIM76,133,12,TuoiNuoc";
		}
		if (string_2.Contains("Giải Kiếm Trì"))
		{
			return "INFOAIM49,180,12,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_39}#{SMXL_090819_wudang}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM58,73,12,LamLinhTo,PhuBan";
		}
		if (string_2.Contains("Nham Băng Hộ"))
		{
			return "INFOAIM125,50,17,TuoiNuoc";
		}
		if (string_2.Contains("Huyền Băng Hộ"))
		{
			return "INFOAIM65,43,17,TuoiNuoc";
		}
		if (string_2.Contains("Hàn Băng Hộ"))
		{
			return "INFOAIM71,65,17,TuoiNuoc";
		}
		if (string_2.Contains("Toái Băng Hộ"))
		{
			return "INFOAIM123,89,17,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_43}#{SMXL_090819_tianshan}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM101,44,17,CucKiem,PhuBan";
		}
		if (string_2.Contains("Chung Lâu"))
		{
			return "INFOAIM81,69,9,TuoiNuoc";
		}
		if (string_2.Contains("Đại Hùng Bảo Điện"))
		{
			return "INFOAIM96,82,9,TuoiNuoc";
		}
		if (string_2.Contains("Tàng Kinh Các"))
		{
			return "INFOAIM134,132,9,TuoiNuoc";
		}
		if (string_2.Contains("GSơn môn"))
		{
			return "INFOAIM90,110,9,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_35}#{SMXL_090819_shaolin}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM61,62,9,HuyenTrung,PhuBan";
		}
		if (string_2.Contains("Thiên Cơ Phường"))
		{
			return "INFOAIM56,136,615,TuoiNuoc";
		}
		if (string_2.Contains("Đường Gia Nội Bảo"))
		{
			return "INFOAIM80,46,615,TuoiNuoc";
		}
		if (string_2.Contains("Diễn Võ Trường"))
		{
			return "INFOAIM48,80,615,TuoiNuoc";
		}
		if (string_2.Contains("Phong Vũ Lâu"))
		{
			return "INFOAIM102,97,615,TuoiNuoc";
		}
		if (string_2.Contains("#{TMSM_130808_01}#") && string_2.Contains("#{SMRW_090206_01}"))
		{
			return "INFOAIM66,30,615,DuongNhacThien,Phuban";
		}
		if (string_2.Contains("Phật Quang Phụng Hoàng"))
		{
			return "INFOAIM39,152,15,TuoiNuoc";
		}
		if (string_2.Contains("Kim Đỉnh Phụng Hoàng"))
		{
			return "INFOAIM45,42,15,TuoiNuoc";
		}
		if (string_2.Contains("Linh Tuyền Phụng Hoàng"))
		{
			return "INFOAIM146,46,15,TuoiNuoc";
		}
		if (string_2.Contains("Vạn Niên Phụng Hoàng"))
		{
			return "INFOAIM146,156,15,TuoiNuoc";
		}
		if (string_2 == "#{SMFB_120214_37}#{SMXL_090819_emei}#r#{SMRW_090206_01}")
		{
			return "INFOAIM96,73,15,ManhThanhThanh,PhuBan";
		}
		if (string_2.Contains("Đỗ khang từ"))
		{
			return "INFOAIM131,112,10,TuoiNuoc";
		}
		if (string_2.Contains("Tiểu đào viên"))
		{
			return "INFOAIM39,147,10,TuoiNuoc";
		}
		if (string_2.Contains("Diễn binh đàn"))
		{
			return "INFOAIM46,36,10,TuoiNuoc";
		}
		if (string_2.Contains("Tây sương phòng"))
		{
			return "INFOAIM53,88,10,TuoiNuoc";
		}
		if (string_2 == "#{SMFB_120214_49}#{SMXL_090819_gaibang}#r#{SMRW_090206_01}")
		{
			return "INFOAIM41,144,10,PhatAn,PhuBan";
		}
		if (string_2.Contains("Rương Rết Độc"))
		{
			return "INFOAIM87,98,16,TuoiNuoc";
		}
		if (string_2.Contains("Rương Bọ Cạp Độc"))
		{
			return "INFOAIM127,73,16,TuoiNuoc";
		}
		if (string_2.Contains("Rương Nhện Độc"))
		{
			return "INFOAIM106,98,16,TuoiNuoc";
		}
		if (string_2.Contains("Rương Cóc Độc"))
		{
			return "INFOAIM95,56,16,TuoiNuoc";
		}
		if (string_2.Contains("#{SMFB_120214_33}#{SMXL_090819_xingxiu}#r#{SMRW_090206_01}"))
		{
			return "INFOAIM128,78,16,HongNgoc,PhuBan";
		}
		return string_2;
	}

	// Token: 0x06002C50 RID: 11344 RVA: 0x0012C144 File Offset: 0x0012A344
	public static string smethod_40(string string_2)
	{
		string text = string.Empty;
		for (int i = 0; i < string_2.Length; i++)
		{
			if (char.IsDigit(string_2[i]))
			{
				text += string_2[i].ToString();
			}
			else if (text.Length > 0)
			{
				break;
			}
		}
		return text;
	}

	// Token: 0x06002C51 RID: 11345 RVA: 0x0012C198 File Offset: 0x0012A398
	public static int smethod_41(string string_2)
	{
		string text = string.Empty;
		for (int i = 0; i < string_2.Length; i++)
		{
			if (char.IsDigit(string_2[i]))
			{
				text += string_2[i].ToString();
			}
		}
		if (string.IsNullOrEmpty(text))
		{
			return 0;
		}
		int num = 0;
		int.TryParse(text, out num);
		if (string_2.StartsWith("-"))
		{
			return 0 - num;
		}
		return num;
	}

	// Token: 0x06002C52 RID: 11346 RVA: 0x0012C208 File Offset: 0x0012A408
	public static ulong smethod_42(string string_2)
	{
		string text = string.Empty;
		for (int i = 0; i < string_2.Length; i++)
		{
			if (char.IsDigit(string_2[i]))
			{
				text += string_2[i].ToString();
			}
		}
		if (string.IsNullOrEmpty(text))
		{
			return 0UL;
		}
		ulong result = 0UL;
		ulong.TryParse(text, out result);
		return result;
	}

	// Token: 0x06002C53 RID: 11347 RVA: 0x0012C268 File Offset: 0x0012A468
	public static int smethod_43(string string_2)
	{
		int result = 0;
		string text = string.Empty;
		for (int i = 0; i < string_2.Length; i++)
		{
			if (char.IsDigit(string_2[i]))
			{
				text += string_2[i].ToString();
			}
			else if (text.Length > 0)
			{
				break;
			}
		}
		if (text.Length > 0)
		{
			result = int.Parse(text);
		}
		return result;
	}

	// Token: 0x06002C54 RID: 11348 RVA: 0x000E17C8 File Offset: 0x000DF9C8
	public static string smethod_44(string string_2, string string_3, string string_4)
	{
		int num = string_2.IndexOf(string_3);
		if (num < 0)
		{
			return string_2;
		}
		return string_2.Substring(0, num) + string_4 + string_2.Substring(num + string_3.Length);
	}

	// Token: 0x06002C55 RID: 11349 RVA: 0x0012C2D0 File Offset: 0x0012A4D0
	public static string smethod_45()
	{
		string result = "";
		foreach (IPAddress ipaddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
		{
			if (ipaddress.AddressFamily == AddressFamily.InterNetwork)
			{
				result = ipaddress.ToString();
				return result;
			}
		}
		return result;
	}

	// Token: 0x06002C56 RID: 11350 RVA: 0x0012C31C File Offset: 0x0012A51C
	public static List<string> smethod_46(string string_2, string string_3, string string_4)
	{
		if (string_2 == null)
		{
			return null;
		}
		List<string> list = new List<string>();
		for (;;)
		{
			int num = string_2.IndexOf(string_3);
			if (num == -1)
			{
				break;
			}
			string text = string_2.Substring(num + string_3.Length);
			int num2 = text.IndexOf(string_4);
			if (num2 == -1)
			{
				break;
			}
			text = text.Substring(0, num2);
			list.Add(text);
			if (string_2.Length <= num + string_3.Length + text.Length + string_4.Length)
			{
				break;
			}
			string_2 = string_2.Substring(num + string_3.Length + text.Length + string_4.Length);
		}
		return list;
	}

	// Token: 0x06002C57 RID: 11351 RVA: 0x0012C3AC File Offset: 0x0012A5AC
	public static float smethod_47(string string_2, string string_3)
	{
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = 0f;
		if (string_2.Split(new char[]
		{
			','
		}).Length >= 2)
		{
			num = (float)Class426.smethod_43(string_2.Split(new char[]
			{
				','
			})[0]);
			num2 = (float)Class426.smethod_43(string_2.Split(new char[]
			{
				','
			})[1]);
		}
		if (string_3.Split(new char[]
		{
			','
		}).Length >= 2)
		{
			num3 = (float)Class426.smethod_43(string_3.Split(new char[]
			{
				','
			})[0]);
			num4 = (float)Class426.smethod_43(string_3.Split(new char[]
			{
				','
			})[1]);
		}
		return (float)Math.Sqrt(Math.Pow((double)(num - num3), 2.0) + Math.Pow((double)(num2 - num4), 2.0));
	}

	// Token: 0x06002C58 RID: 11352 RVA: 0x000205BB File Offset: 0x0001E7BB
	public static float smethod_48(double double_0, double double_1, double double_2, double double_3)
	{
		return (float)Math.Sqrt(Math.Pow(double_0 - double_2, 2.0) + Math.Pow(double_1 - double_3, 2.0));
	}

	// Token: 0x06002C59 RID: 11353 RVA: 0x0012C490 File Offset: 0x0012A690
	public static int smethod_49(int int_0, int int_1)
	{
		int num = int_0 - int_1;
		if (num < 0)
		{
			num = -num;
		}
		return num;
	}

	// Token: 0x06002C5A RID: 11354 RVA: 0x0012C4AC File Offset: 0x0012A6AC
	public static void smethod_50(string string_2, string string_3, string string_4)
	{
		Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(string_2 + "." + string_3);
		FileStream fileStream = new FileStream(string_4, FileMode.Create);
		int num = 0;
		while ((long)num < manifestResourceStream.Length)
		{
			fileStream.WriteByte((byte)manifestResourceStream.ReadByte());
			num++;
		}
		fileStream.Close();
	}

	// Token: 0x06002C5B RID: 11355 RVA: 0x0012C500 File Offset: 0x0012A700
	public static string smethod_51(string string_2)
	{
		string text = "";
		foreach (char value in string_2)
		{
			if (Class426.string_0.Contains(value))
			{
				text += value.ToString();
			}
		}
		return text;
	}

	// Token: 0x06002C5C RID: 11356 RVA: 0x0012C54C File Offset: 0x0012A74C
	public static string smethod_52(string string_2)
	{
		string result;
		using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(string_2)))
		{
			using (MemoryStream memoryStream2 = new MemoryStream())
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream2, CompressionMode.Compress))
				{
					Class426.smethod_20(memoryStream, gzipStream);
				}
				result = Convert.ToBase64String(memoryStream2.ToArray());
			}
		}
		return result;
	}

	// Token: 0x06002C5D RID: 11357 RVA: 0x0012C5D8 File Offset: 0x0012A7D8
	public static string smethod_53(string string_2)
	{
		string @string;
		using (MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(string_2)))
		{
			using (MemoryStream memoryStream2 = new MemoryStream())
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
				{
					Class426.smethod_20(gzipStream, memoryStream2);
				}
				@string = Encoding.UTF8.GetString(memoryStream2.ToArray());
			}
		}
		return @string;
	}

	// Token: 0x06002C5E RID: 11358 RVA: 0x0012C664 File Offset: 0x0012A864
	public static string smethod_54(string string_2)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in string_2)
		{
			bool flag = false;
			foreach (string text in Class426.string_1)
			{
				int index = 0;
				if (0 < text.Length && text[index] == c)
				{
					flag = true;
				}
				if (flag)
				{
					break;
				}
			}
			if (flag)
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06002C5F RID: 11359 RVA: 0x0012C6E8 File Offset: 0x0012A8E8
	public static string smethod_55(int int_0 = 5)
	{
		string[] array = new string[]
		{
			"b",
			"c",
			"d",
			"f",
			"g",
			"h",
			"j",
			"k",
			"l",
			"m",
			"l",
			"n",
			"p",
			"q",
			"r",
			"s",
			"sh",
			"zh",
			"t",
			"v",
			"w",
			"x"
		};
		string[] array2 = new string[]
		{
			"a",
			"e",
			"i",
			"o",
			"u",
			"ae",
			"y"
		};
		string str = "";
		str += array[Class426.random_1.Next(array.Length)].ToUpper();
		str += array2[Class426.random_1.Next(array2.Length)];
		for (int i = 2; i < int_0; i++)
		{
			str += array[Class426.random_1.Next(array.Length)];
			i++;
			str += array2[Class426.random_1.Next(array2.Length)];
		}
		str += Class426.random_0.Next(1000, 9999).ToString();
		str += array[Class426.random_1.Next(array.Length)].ToUpper();
		str += array2[Class426.random_1.Next(array2.Length)];
		for (int i = 2; i < int_0; i++)
		{
			str += array[Class426.random_1.Next(array.Length)];
			i++;
			str += array2[Class426.random_1.Next(array2.Length)];
		}
		return str + Class426.random_0.Next(1, 100).ToString();
	}

	// Token: 0x06002C60 RID: 11360 RVA: 0x0012C91C File Offset: 0x0012AB1C
	public static string smethod_56(int int_0)
	{
		string[] array = new string[]
		{
			"b",
			"c",
			"d",
			"f",
			"g",
			"h",
			"j",
			"k",
			"l",
			"m",
			"l",
			"n",
			"p",
			"q",
			"r",
			"s",
			"sh",
			"zh",
			"t",
			"v",
			"w",
			"x"
		};
		string[] array2 = new string[]
		{
			"a",
			"e",
			"i",
			"o",
			"u",
			"ae",
			"y"
		};
		string text = "";
		text += array[Class426.random_1.Next(array.Length)].ToUpper();
		text += array2[Class426.random_1.Next(array2.Length)];
		for (int i = 2; i < int_0; i++)
		{
			text += array[Class426.random_1.Next(array.Length)];
			i++;
			text += array2[Class426.random_1.Next(array2.Length)];
		}
		return text;
	}

	// Token: 0x06002C61 RID: 11361 RVA: 0x000205E6 File Offset: 0x0001E7E6
	public static string smethod_57(string string_2)
	{
		if (string.IsNullOrEmpty(string_2))
		{
			return "";
		}
		return Class426.smethod_64(string_2).Replace(" ", "").Replace("\r", "").ToLower();
	}

	// Token: 0x06002C62 RID: 11362 RVA: 0x0002061F File Offset: 0x0001E81F
	public static string smethod_58(string string_2)
	{
		if (string.IsNullOrEmpty(string_2))
		{
			return "";
		}
		return Class426.smethod_64(string_2);
	}

	// Token: 0x06002C63 RID: 11363 RVA: 0x0012CAA4 File Offset: 0x0012ACA4
	public static string smethod_59(string string_2)
	{
		string_2 = Class426.smethod_57(string_2);
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char value in string_2)
		{
			if (Regex.IsMatch(value.ToString(), "[A-Za-z0-9]"))
			{
				stringBuilder.Append(value);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06002C64 RID: 11364 RVA: 0x0012CAFC File Offset: 0x0012ACFC
	public static string smethod_60(string string_2)
	{
		Regex regex = new Regex("\\p{IsCombiningDiacriticalMarks}+");
		string input = string_2.Normalize(NormalizationForm.FormD);
		return regex.Replace(input, string.Empty).Replace('đ', 'd').Replace('Đ', 'D');
	}

	// Token: 0x06002C65 RID: 11365 RVA: 0x0012CB40 File Offset: 0x0012AD40
	public static string smethod_61(string string_2)
	{
		return Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(string_2.ToLower(), "à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ|/g", "a"), "è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ|/g", "e"), "ì|í|ị|ỉ|ĩ|/g", "i"), "ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ|/g", "o"), "ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ|/g", "u"), "ỳ|ý|ỵ|ỷ|ỹ|/g", "y"), "đ", "d");
	}

	// Token: 0x06002C66 RID: 11366 RVA: 0x00020635 File Offset: 0x0001E835
	public static bool smethod_62(string string_2, string string_3)
	{
		return string_3 != null && !(string_3 == "") && Class426.smethod_57(string_2).Contains(Class426.smethod_57(string_3));
	}

	// Token: 0x06002C67 RID: 11367 RVA: 0x0012CBBC File Offset: 0x0012ADBC
	public static bool smethod_63(string string_2)
	{
		bool result = false;
		foreach (Process process in Process.GetProcesses())
		{
			try
			{
				if (process.MainModule.FileName == string_2)
				{
					process.Kill();
					result = true;
				}
			}
			catch
			{
			}
		}
		return result;
	}

	// Token: 0x06002C68 RID: 11368 RVA: 0x0012CC14 File Offset: 0x0012AE14
	public static string smethod_64(string string_2)
	{
		for (int i = 1; i < Class426.string_1.Length; i++)
		{
			for (int j = 0; j < Class426.string_1[i].Length; j++)
			{
				string_2 = string_2.Replace(Class426.string_1[i][j], Class426.string_1[0][i - 1]);
			}
		}
		return string_2;
	}

	// Token: 0x06002C69 RID: 11369 RVA: 0x0012CC70 File Offset: 0x0012AE70
	public static string smethod_65(string string_2)
	{
		if (!File.Exists(string_2))
		{
			return "";
		}
		try
		{
			StreamReader streamReader = new StreamReader(string_2);
			string result = streamReader.ReadToEnd();
			streamReader.Close();
			return result;
		}
		catch
		{
		}
		return "";
	}

	// Token: 0x17000A06 RID: 2566
	// (get) Token: 0x06002C6A RID: 11370 RVA: 0x0012CCBC File Offset: 0x0012AEBC
	public static int Int32_0
	{
		get
		{
			return DateTime.Now.Month * 30 * 24 * 3600 + DateTime.Now.Day * 24 * 3600 + DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second;
		}
	}

	// Token: 0x06002C6B RID: 11371 RVA: 0x0012CD2C File Offset: 0x0012AF2C
	public static void smethod_66(string string_2, string string_3)
	{
		try
		{
			string_3 = string_3 + "\r\n" + Class426.smethod_65(string_2);
			if (string_3.Split(new char[]
			{
				'\n'
			}).Length > 1000)
			{
				string text = "";
				for (int i = 0; i < 1000; i++)
				{
					text = text + string_3.Split(new char[]
					{
						'\n'
					})[i].Trim() + "\r\n";
				}
				string_3 = text;
			}
			new FileStream(string_2, FileMode.Create).Close();
			StreamWriter streamWriter = new StreamWriter(string_2);
			streamWriter.Write(string_3);
			streamWriter.Close();
		}
		catch
		{
		}
	}

	// Token: 0x06002C6C RID: 11372 RVA: 0x0012CDD8 File Offset: 0x0012AFD8
	public static void smethod_67(string string_2, string string_3)
	{
		try
		{
			File.Move(string_2, string_3);
		}
		catch
		{
		}
	}

	// Token: 0x06002C6D RID: 11373 RVA: 0x0012CE04 File Offset: 0x0012B004
	public static void smethod_68(string string_2)
	{
		try
		{
			File.Delete(string_2);
		}
		catch
		{
		}
	}

	// Token: 0x06002C6E RID: 11374 RVA: 0x0012CE2C File Offset: 0x0012B02C
	public static void smethod_69(string string_2, string string_3)
	{
		try
		{
			new FileStream(string_2, FileMode.Create).Close();
			StreamWriter streamWriter = new StreamWriter(string_2);
			streamWriter.Write(string_3);
			streamWriter.Close();
		}
		catch
		{
		}
	}

	// Token: 0x06002C6F RID: 11375 RVA: 0x0012CE6C File Offset: 0x0012B06C
	public static void smethod_70(string string_2, string string_3)
	{
		try
		{
			UTF8Encoding encoding = new UTF8Encoding(false);
			new FileStream(string_2, FileMode.Create).Close();
			StreamWriter streamWriter = new StreamWriter(string_2, false, encoding);
			streamWriter.Write(string_3);
			streamWriter.Close();
		}
		catch
		{
		}
	}

	// Token: 0x06002C70 RID: 11376 RVA: 0x0002065F File Offset: 0x0001E85F
	public static bool smethod_71(string string_2)
	{
		if (!Regex.Match(string_2, "^[0]([0-9]{9})$").Success)
		{
			return Regex.Match(string_2, "^[0]([0-9]{10})$").Success;
		}
		return Regex.Match(string_2, "^[0]([0-9]{9})$").Success;
	}

	// Token: 0x06002C71 RID: 11377 RVA: 0x0012CEB8 File Offset: 0x0012B0B8
	public static bool smethod_72(string string_2)
	{
		string pattern = "^(([^<>()[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		return string_2 != null && string_2 != "" && Regex.IsMatch(string_2, pattern);
	}

	// Token: 0x17000A07 RID: 2567
	// (get) Token: 0x06002C72 RID: 11378 RVA: 0x00020694 File Offset: 0x0001E894
	public static bool Boolean_0
	{
		get
		{
			return Class426.smethod_73(Enum20.VK_CONTROL) || Class426.smethod_73(Enum20.VK_RCONTROL);
		}
	}

	// Token: 0x17000A08 RID: 2568
	// (get) Token: 0x06002C73 RID: 11379 RVA: 0x000206AB File Offset: 0x0001E8AB
	public static bool Boolean_1
	{
		get
		{
			return Class426.smethod_73(Enum20.VK_LSHIFT) || Class426.smethod_73(Enum20.VK_RSHIFT);
		}
	}

	// Token: 0x17000A09 RID: 2569
	// (get) Token: 0x06002C74 RID: 11380 RVA: 0x000206C5 File Offset: 0x0001E8C5
	public static bool Boolean_2
	{
		get
		{
			return Class426.smethod_73(Enum20.VK_LMENU) || Class426.smethod_73(Enum20.VK_RMENU);
		}
	}

	// Token: 0x06002C75 RID: 11381 RVA: 0x0012CEE4 File Offset: 0x0012B0E4
	public static bool smethod_73(Enum20 enum20_0)
	{
		return Convert.ToBoolean((int)Class426.GetKeyState(enum20_0) & 32768);
	}

	// Token: 0x06002C76 RID: 11382
	[DllImport("user32.dll")]
	private static extern short GetKeyState(Enum20 enum20_0);

	// Token: 0x06002C77 RID: 11383
	[DllImport("user32.dll")]
	public static extern bool CloseWindow(IntPtr intptr_0);

	// Token: 0x06002C78 RID: 11384 RVA: 0x00002E18 File Offset: 0x00001018
	private void method_0(string string_2, string string_3)
	{
	}

	// Token: 0x06002C79 RID: 11385 RVA: 0x0012CF04 File Offset: 0x0012B104
	public static string smethod_74(string string_2, string string_3)
	{
		string result;
		try
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(string_2);
			if (registryKey == null)
			{
				result = "";
			}
			else
			{
				result = (string)registryKey.GetValue(string_3);
			}
		}
		catch
		{
			result = "";
		}
		return result;
	}

	// Token: 0x06002C7A RID: 11386 RVA: 0x0012CF54 File Offset: 0x0012B154
	public static int smethod_75(string string_2)
	{
		if (string_2 == "??")
		{
			return -1;
		}
		int result = -1;
		int.TryParse(string_2, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result);
		return result;
	}

	// Token: 0x06002C7B RID: 11387 RVA: 0x0012CF88 File Offset: 0x0012B188
	public static string smethod_76()
	{
		string text = Class426.smethod_74("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "ProductName");
		string text2 = Class426.smethod_74("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "CSDVersion");
		if (text != "")
		{
			return (text.StartsWith("Microsoft") ? "" : "Microsoft ") + text + ((text2 != "") ? (" " + text2) : "");
		}
		return "";
	}

	// Token: 0x04001E5A RID: 7770
	public static Random random_0 = new Random();

	// Token: 0x04001E5B RID: 7771
	public static Dictionary<string, string> dictionary_0 = new Dictionary<string, string>
	{
		{
			"#{XSLC_130831_01}",
			"Duyên khởi vô lượng"
		}
	};

	// Token: 0x04001E5C RID: 7772
	public static Dictionary<string, string> dictionary_1 = new Dictionary<string, string>();

	// Token: 0x04001E5D RID: 7773
	public static readonly char[] char_0 = new char[]
	{
		'\0',
		'\u0001',
		'Ẳ',
		'\u0003',
		'\u0004',
		'Ẵ',
		'Ẫ',
		'\a',
		'\b',
		'\t',
		'\n',
		'\v',
		'\f',
		'\r',
		'\u000e',
		'\u000f',
		'\u0010',
		'\u0011',
		'\u0012',
		'\u0013',
		'Ỷ',
		'\u0015',
		'\u0016',
		'\u0017',
		'\u0018',
		'Ỹ',
		'\u001a',
		'\u001b',
		'\u001c',
		'\u001d',
		'Ỵ',
		'\u001f',
		' ',
		'!',
		'"',
		'#',
		'$',
		'%',
		'&',
		'\'',
		'(',
		')',
		'*',
		'+',
		',',
		'-',
		'.',
		'/',
		'0',
		'1',
		'2',
		'3',
		'4',
		'5',
		'6',
		'7',
		'8',
		'9',
		':',
		';',
		'<',
		'=',
		'>',
		'?',
		'@',
		'A',
		'B',
		'C',
		'D',
		'E',
		'F',
		'G',
		'H',
		'I',
		'J',
		'K',
		'L',
		'M',
		'N',
		'O',
		'P',
		'Q',
		'R',
		'S',
		'T',
		'U',
		'V',
		'W',
		'X',
		'Y',
		'Z',
		'[',
		'\\',
		']',
		'^',
		'_',
		'`',
		'a',
		'b',
		'c',
		'd',
		'e',
		'f',
		'g',
		'h',
		'i',
		'j',
		'k',
		'l',
		'm',
		'n',
		'o',
		'p',
		'q',
		'r',
		's',
		't',
		'u',
		'v',
		'w',
		'x',
		'y',
		'z',
		'{',
		'|',
		'}',
		'~',
		'\u007f',
		'Ạ',
		'Ắ',
		'Ằ',
		'Ặ',
		'Ấ',
		'Ầ',
		'Ẩ',
		'Ậ',
		'Ẽ',
		'Ẹ',
		'Ế',
		'Ề',
		'Ể',
		'Ễ',
		'Ệ',
		'Ố',
		'Ồ',
		'Ổ',
		'Ỗ',
		'Ộ',
		'Ợ',
		'Ớ',
		'Ờ',
		'Ở',
		'Ị',
		'Ỏ',
		'Ọ',
		'Ỉ',
		'Ủ',
		'Ũ',
		'Ụ',
		'Ỳ',
		'Õ',
		'ắ',
		'ằ',
		'ặ',
		'ấ',
		'ầ',
		'ẩ',
		'ậ',
		'ẽ',
		'ẹ',
		'ế',
		'ề',
		'ể',
		'ễ',
		'ệ',
		'ố',
		'ồ',
		'ổ',
		'ỗ',
		'Ỡ',
		'Ơ',
		'ộ',
		'ờ',
		'ở',
		'ị',
		'Ự',
		'Ứ',
		'Ừ',
		'Ử',
		'ơ',
		'ớ',
		'Ư',
		'À',
		'Á',
		'Â',
		'Ã',
		'Ả',
		'Ă',
		'ẳ',
		'ẵ',
		'È',
		'É',
		'Ê',
		'Ẻ',
		'Ì',
		'Í',
		'Ĩ',
		'ỳ',
		'Đ',
		'ứ',
		'Ò',
		'Ó',
		'Ô',
		'ạ',
		'ỷ',
		'ừ',
		'ử',
		'Ù',
		'Ú',
		'ỹ',
		'ỵ',
		'Ý',
		'ỡ',
		'ư',
		'à',
		'á',
		'â',
		'ã',
		'ả',
		'ă',
		'ữ',
		'ẫ',
		'è',
		'é',
		'ê',
		'ẻ',
		'ì',
		'í',
		'ĩ',
		'ỉ',
		'đ',
		'ự',
		'ò',
		'ó',
		'ô',
		'õ',
		'ỏ',
		'ọ',
		'ụ',
		'ù',
		'ú',
		'ũ',
		'ủ',
		'ý',
		'ợ',
		'Ữ'
	};

	// Token: 0x04001E5E RID: 7774
	public static string string_0 = "aAeEoOuUiIdDyYáàạảãâấầậẩẫăắằặẳẵÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴéèẹẻẽêếềệểễÉÈẸẺẼÊẾỀỆỂỄóòọỏõôốồộổỗơớờợởỡÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠúùụủũưứừựửữÚÙỤỦŨƯỨỪỰỬỮíìịỉĩÍÌỊỈĨđĐýỳỵỷỹÝỲỴỶỸ0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789";

	// Token: 0x04001E5F RID: 7775
	public static string[] string_1 = new string[]
	{
		"aAeEoOuUiIdDyY",
		"áàạảãâấầậẩẫăắằặẳẵ",
		"ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
		"éèẹẻẽêếềệểễ",
		"ÉÈẸẺẼÊẾỀỆỂỄ",
		"óòọỏõôốồộổỗơớờợởỡ",
		"ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
		"úùụủũưứừựửữ",
		"ÚÙỤỦŨƯỨỪỰỬỮ",
		"íìịỉĩ",
		"ÍÌỊỈĨ",
		"đ",
		"Đ",
		"ýỳỵỷỹ",
		"ÝỲỴỶỸ"
	};

	// Token: 0x04001E60 RID: 7776
	private static Random random_1 = new Random();

	// Token: 0x04001E61 RID: 7777
	public static Random random_2 = new Random();

	// Token: 0x02000307 RID: 775
	public class Class427
	{
		// Token: 0x04001E62 RID: 7778
		public static int int_0 = 1;

		// Token: 0x04001E63 RID: 7779
		public static int int_1 = 2;

		// Token: 0x04001E64 RID: 7780
		public static int int_2 = 3;

		// Token: 0x04001E65 RID: 7781
		public static int int_3 = 4;

		// Token: 0x04001E66 RID: 7782
		public static int int_4 = 5;

		// Token: 0x04001E67 RID: 7783
		public static int int_5 = 6;

		// Token: 0x04001E68 RID: 7784
		public static int int_6 = 7;

		// Token: 0x04001E69 RID: 7785
		public static int int_7 = 8;

		// Token: 0x04001E6A RID: 7786
		public static int int_8 = 9;

		// Token: 0x04001E6B RID: 7787
		public static int int_9 = 32;

		// Token: 0x04001E6C RID: 7788
		public static int int_10 = 37;

		// Token: 0x04001E6D RID: 7789
		public static int int_11 = 53;

		// Token: 0x04001E6E RID: 7790
		public static int int_12 = 54;

		// Token: 0x04001E6F RID: 7791
		public static int int_13 = 0;
	}

	// Token: 0x02000308 RID: 776
	public class Class428
	{
		// Token: 0x04001E70 RID: 7792
		public static string string_0 = "8B15 ???????? 8B42 ?? 8B80 ???????? 8B40";

		// Token: 0x04001E71 RID: 7793
		public static string string_1 = "CHelperSystem";

		// Token: 0x04001E72 RID: 7794
		public static string string_2 = "E8 ???????? 85C0 0F84";

		// Token: 0x04001E73 RID: 7795
		public static string string_3 = "QUEST_INFO";

		// Token: 0x04001E74 RID: 7796
		public static string string_4 = "LOGIN_MIBAO";
	}

	// Token: 0x02000309 RID: 777
	public class Class429
	{
		// Token: 0x06002C82 RID: 11394 RVA: 0x0012D170 File Offset: 0x0012B370
		public static byte[] smethod_0(string string_0)
		{
			byte[] array;
			if (File.Exists(string_0))
			{
				array = File.ReadAllBytes(string_0);
			}
			else
			{
				array = Encoding.ASCII.GetBytes(string_0);
			}
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
				{
					gzipStream.Write(array, 0, array.Length);
				}
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x06002C83 RID: 11395 RVA: 0x0012D1F0 File Offset: 0x0012B3F0
		public static void smethod_1(string string_0, string string_1)
		{
			byte[] array;
			if (File.Exists(string_0))
			{
				array = File.ReadAllBytes(string_0);
			}
			else
			{
				array = Encoding.ASCII.GetBytes(string_0);
			}
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
				{
					gzipStream.Write(array, 0, array.Length);
				}
				using (FileStream fileStream = new FileStream(string_1, FileMode.Create))
				{
					memoryStream.WriteTo(fileStream);
				}
			}
		}

		// Token: 0x06002C84 RID: 11396 RVA: 0x0012D290 File Offset: 0x0012B490
		public static byte[] smethod_2(string string_0)
		{
			byte[] buffer;
			if (File.Exists(string_0))
			{
				buffer = File.ReadAllBytes(string_0);
			}
			else
			{
				buffer = Encoding.ASCII.GetBytes(string_0);
			}
			byte[] result;
			using (GZipStream gzipStream = new GZipStream(new MemoryStream(buffer), CompressionMode.Decompress))
			{
				byte[] buffer2 = new byte[4096];
				using (MemoryStream memoryStream = new MemoryStream())
				{
					int num;
					do
					{
						num = gzipStream.Read(buffer2, 0, 4096);
						if (num > 0)
						{
							memoryStream.Write(buffer2, 0, num);
						}
					}
					while (num > 0);
					result = memoryStream.ToArray();
				}
			}
			return result;
		}

		// Token: 0x06002C85 RID: 11397 RVA: 0x0012D344 File Offset: 0x0012B544
		public static void smethod_3(string string_0, string string_1)
		{
			byte[] buffer;
			if (File.Exists(string_0))
			{
				buffer = File.ReadAllBytes(string_0);
			}
			else
			{
				buffer = Encoding.ASCII.GetBytes(string_0);
			}
			using (GZipStream gzipStream = new GZipStream(new MemoryStream(buffer), CompressionMode.Decompress))
			{
				byte[] buffer2 = new byte[4096];
				using (MemoryStream memoryStream = new MemoryStream())
				{
					int num;
					do
					{
						num = gzipStream.Read(buffer2, 0, 4096);
						if (num > 0)
						{
							memoryStream.Write(buffer2, 0, num);
						}
					}
					while (num > 0);
					using (FileStream fileStream = new FileStream(string_1, FileMode.Create))
					{
						memoryStream.WriteTo(fileStream);
					}
				}
			}
		}
	}

	// Token: 0x0200030A RID: 778
	public class Class430
	{
		// Token: 0x06002C87 RID: 11399 RVA: 0x00002E70 File Offset: 0x00001070
		private Class430()
		{
		}

		// Token: 0x06002C88 RID: 11400 RVA: 0x00020713 File Offset: 0x0001E913
		private static byte[] smethod_0(string string_0)
		{
			return new UnicodeEncoding().GetBytes(string_0);
		}

		// Token: 0x06002C89 RID: 11401 RVA: 0x00020720 File Offset: 0x0001E920
		private static FileStream smethod_1(string string_0)
		{
			return new FileStream(string_0, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
		}

		// Token: 0x06002C8A RID: 11402 RVA: 0x0012D418 File Offset: 0x0012B618
		public static string smethod_2(string string_0)
		{
			string result = "";
			SHA1CryptoServiceProvider sha1CryptoServiceProvider = new SHA1CryptoServiceProvider();
			try
			{
				FileStream fileStream = Class426.Class430.smethod_1(string_0);
				byte[] value = sha1CryptoServiceProvider.ComputeHash(fileStream);
				fileStream.Close();
				result = BitConverter.ToString(value).Replace("-", "");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1);
			}
			return result;
		}

		// Token: 0x06002C8B RID: 11403 RVA: 0x0012D488 File Offset: 0x0012B688
		public static string smethod_3(string string_0)
		{
			string text = "";
			MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
			try
			{
				if (File.Exists(string_0))
				{
					FileStream fileStream = Class426.Class430.smethod_1(string_0);
					byte[] value = md5CryptoServiceProvider.ComputeHash(fileStream);
					fileStream.Close();
					text = BitConverter.ToString(value).Replace("-", "");
				}
				else
				{
					HashAlgorithm hashAlgorithm = MD5.Create();
					byte[] bytes = Encoding.ASCII.GetBytes(string_0);
					byte[] array = hashAlgorithm.ComputeHash(bytes);
					StringBuilder stringBuilder = new StringBuilder();
					for (int i = 0; i < array.Length; i++)
					{
						stringBuilder.Append(array[i].ToString("X2"));
					}
					text = stringBuilder.ToString();
				}
			}
			catch
			{
				HashAlgorithm hashAlgorithm2 = MD5.Create();
				byte[] bytes2 = Encoding.ASCII.GetBytes(string_0);
				byte[] array2 = hashAlgorithm2.ComputeHash(bytes2);
				StringBuilder stringBuilder2 = new StringBuilder();
				for (int j = 0; j < array2.Length; j++)
				{
					stringBuilder2.Append(array2[j].ToString("X2"));
				}
				text = stringBuilder2.ToString();
			}
			return text.ToUpper();
		}

		// Token: 0x06002C8C RID: 11404 RVA: 0x0012D5A0 File Offset: 0x0012B7A0
		public static string smethod_4(string string_0, string string_1)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(string_0);
			new AppSettingsReader();
			MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
			byte[] key = md5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(string_1));
			md5CryptoServiceProvider.Clear();
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
			tripleDESCryptoServiceProvider.Key = key;
			tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
			tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
			byte[] array = tripleDESCryptoServiceProvider.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length);
			tripleDESCryptoServiceProvider.Clear();
			return Convert.ToBase64String(array, 0, array.Length);
		}

		// Token: 0x06002C8D RID: 11405 RVA: 0x0012D618 File Offset: 0x0012B818
		public static string smethod_5(string string_0, string string_1)
		{
			byte[] array = Convert.FromBase64String(string_0);
			new AppSettingsReader();
			MD5CryptoServiceProvider md5CryptoServiceProvider = new MD5CryptoServiceProvider();
			byte[] key = md5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(string_1));
			md5CryptoServiceProvider.Clear();
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
			tripleDESCryptoServiceProvider.Key = key;
			tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
			tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
			byte[] bytes = tripleDESCryptoServiceProvider.CreateDecryptor().TransformFinalBlock(array, 0, array.Length);
			tripleDESCryptoServiceProvider.Clear();
			return Encoding.UTF8.GetString(bytes);
		}
	}

	// Token: 0x0200030B RID: 779
	[CompilerGenerated]
	[Serializable]
	private sealed class Class431
	{
		// Token: 0x06002C90 RID: 11408 RVA: 0x00020737 File Offset: 0x0001E937
		internal char method_0(string string_0)
		{
			return string_0[Class426.random_0.Next(string_0.Length)];
		}

		// Token: 0x06002C91 RID: 11409 RVA: 0x00020737 File Offset: 0x0001E937
		internal char method_1(string string_0)
		{
			return string_0[Class426.random_0.Next(string_0.Length)];
		}

		// Token: 0x04001E75 RID: 7797
		public static readonly Class426.Class431 <>9 = new Class426.Class431();

		// Token: 0x04001E76 RID: 7798
		public static Func<string, char> <>9__12_0;

		// Token: 0x04001E77 RID: 7799
		public static Func<string, char> <>9__13_0;
	}
}
