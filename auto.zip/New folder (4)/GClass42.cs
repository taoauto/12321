﻿using System;

// Token: 0x020000A0 RID: 160
public class GClass42
{
	// Token: 0x04000421 RID: 1057
	public static readonly Version version_0 = new Version(1, 0);

	// Token: 0x04000422 RID: 1058
	public static readonly Version version_1 = new Version(1, 1);
}
