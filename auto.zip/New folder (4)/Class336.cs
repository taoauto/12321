﻿using System;

// Token: 0x02000285 RID: 645
internal class Class336
{
	// Token: 0x17000777 RID: 1911
	// (get) Token: 0x06002415 RID: 9237 RVA: 0x0001B88F File Offset: 0x00019A8F
	public static string String_0
	{
		get
		{
			return "Thiếu Thất Sơn";
		}
	}

	// Token: 0x040017CC RID: 6092
	public static int int_0 = 566;

	// Token: 0x040017CD RID: 6093
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 11719U,
		Int32_0 = 130,
		Int32_1 = 172,
		Int32_2 = Class336.int_0,
		String_2 = "Cưu Ma Trí"
	};

	// Token: 0x040017CE RID: 6094
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 12005U,
		Int32_0 = 130,
		Int32_1 = 123,
		Int32_2 = Class336.int_0,
		String_2 = "Đinh Xuân Thu"
	};

	// Token: 0x040017CF RID: 6095
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 5402U,
		Int32_0 = 70,
		Int32_1 = 120,
		Int32_2 = Class336.int_0,
		String_2 = "Trang Tụ Hiền"
	};

	// Token: 0x040017D0 RID: 6096
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1079U,
		Int32_0 = 130,
		Int32_1 = 123,
		Int32_2 = Class336.int_0,
		String_2 = "Thiếu Lâm Đệ Tử"
	};

	// Token: 0x040017D1 RID: 6097
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 5538U,
		Int32_0 = 137,
		Int32_1 = 36,
		Int32_2 = Class336.int_0,
		String_2 = "Tảo Địa Thần Tăng"
	};

	// Token: 0x040017D2 RID: 6098
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 11444U,
		Int32_0 = 195,
		Int32_1 = 86,
		Int32_2 = Class336.int_0,
		String_2 = "Mộ Dung Phục"
	};

	// Token: 0x040017D3 RID: 6099
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 524U,
		Int32_0 = 121,
		Int32_1 = 40,
		Int32_2 = Class336.int_0,
		String_2 = "Tiêu Phong"
	};
}
