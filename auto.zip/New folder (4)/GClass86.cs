﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

// Token: 0x02000113 RID: 275
public class GClass86 : IEnumerable, IEnumerable<GStruct2>
{
	// Token: 0x06000DD8 RID: 3544 RVA: 0x0000BF4D File Offset: 0x0000A14D
	public GClass86(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
	}

	// Token: 0x170003AA RID: 938
	// (get) Token: 0x06000DD9 RID: 3545 RVA: 0x0000BF6A File Offset: 0x0000A16A
	public virtual bool Boolean_2
	{
		get
		{
			if (this.Boolean_0)
			{
				return this.GStruct2_0.int_0 == this.GStruct2_1.int_0;
			}
			return GStruct2.smethod_1(this.GStruct2_0, this.GStruct2_1);
		}
	}

	// Token: 0x170003AB RID: 939
	// (get) Token: 0x06000DDA RID: 3546 RVA: 0x0000BF9E File Offset: 0x0000A19E
	// (set) Token: 0x06000DDB RID: 3547 RVA: 0x0000BFA6 File Offset: 0x0000A1A6
	public bool Boolean_0
	{
		get
		{
			return this.bool_0;
		}
		set
		{
			this.bool_0 = value;
		}
	}

	// Token: 0x06000DDC RID: 3548 RVA: 0x0000BFAF File Offset: 0x0000A1AF
	public GClass86(FastColoredTextBox fastColoredTextBox_1, int int_3, int int_4, int int_5, int int_6) : this(fastColoredTextBox_1)
	{
		this.gstruct2_0 = new GStruct2(int_3, int_4);
		this.gstruct2_1 = new GStruct2(int_5, int_6);
	}

	// Token: 0x06000DDD RID: 3549 RVA: 0x0000BFD4 File Offset: 0x0000A1D4
	public GClass86(FastColoredTextBox fastColoredTextBox_1, GStruct2 gstruct2_2, GStruct2 gstruct2_3) : this(fastColoredTextBox_1)
	{
		this.gstruct2_0 = gstruct2_2;
		this.gstruct2_1 = gstruct2_3;
	}

	// Token: 0x06000DDE RID: 3550 RVA: 0x0000BFEB File Offset: 0x0000A1EB
	public GClass86(FastColoredTextBox fastColoredTextBox_1, int int_3) : this(fastColoredTextBox_1)
	{
		this.gstruct2_0 = new GStruct2(0, int_3);
		this.gstruct2_1 = new GStruct2(fastColoredTextBox_1[int_3].Count, int_3);
	}

	// Token: 0x06000DDF RID: 3551 RVA: 0x00050EA8 File Offset: 0x0004F0A8
	public bool method_0(GStruct2 gstruct2_2)
	{
		if (gstruct2_2.int_1 < Math.Min(this.gstruct2_0.int_1, this.gstruct2_1.int_1))
		{
			return false;
		}
		if (gstruct2_2.int_1 > Math.Max(this.gstruct2_0.int_1, this.gstruct2_1.int_1))
		{
			return false;
		}
		GStruct2 gstruct = this.gstruct2_0;
		GStruct2 gstruct2 = this.gstruct2_1;
		if (gstruct.int_1 > gstruct2.int_1 || (gstruct.int_1 == gstruct2.int_1 && gstruct.int_0 > gstruct2.int_0))
		{
			GStruct2 gstruct3 = gstruct;
			gstruct = gstruct2;
			gstruct2 = gstruct3;
		}
		if (this.bool_0)
		{
			if (gstruct2_2.int_0 < gstruct.int_0 || gstruct2_2.int_0 > gstruct2.int_0)
			{
				return false;
			}
		}
		else
		{
			if (gstruct2_2.int_1 == gstruct.int_1 && gstruct2_2.int_0 < gstruct.int_0)
			{
				return false;
			}
			if (gstruct2_2.int_1 == gstruct2.int_1 && gstruct2_2.int_0 > gstruct2.int_0)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x00050FA0 File Offset: 0x0004F1A0
	public virtual GClass86 vmethod_0(GClass86 gclass86_0)
	{
		if (this.Boolean_0)
		{
			return this.method_56(gclass86_0);
		}
		GClass86 gclass = this.method_6();
		GClass86 gclass2 = gclass86_0.method_6();
		gclass.method_40();
		gclass2.method_40();
		GStruct2 gstruct = GStruct2.smethod_4(gclass.GStruct2_0, gclass2.GStruct2_0) ? gclass.GStruct2_0 : gclass2.GStruct2_0;
		GStruct2 gstruct2 = GStruct2.smethod_2(gclass.GStruct2_1, gclass2.GStruct2_1) ? gclass.GStruct2_1 : gclass2.GStruct2_1;
		if (GStruct2.smethod_2(gstruct2, gstruct))
		{
			return new GClass86(this.fastColoredTextBox_0, this.gstruct2_0, this.gstruct2_0);
		}
		return this.fastColoredTextBox_0.method_97(gstruct, gstruct2);
	}

	// Token: 0x06000DE1 RID: 3553 RVA: 0x0005104C File Offset: 0x0004F24C
	public GClass86 method_1(GClass86 gclass86_0)
	{
		GClass86 gclass = this.method_6();
		GClass86 gclass2 = gclass86_0.method_6();
		gclass.method_40();
		gclass2.method_40();
		GStruct2 gstruct = GStruct2.smethod_2(gclass.GStruct2_0, gclass2.GStruct2_0) ? gclass.GStruct2_0 : gclass2.GStruct2_0;
		GStruct2 gstruct2 = GStruct2.smethod_4(gclass.GStruct2_1, gclass2.GStruct2_1) ? gclass.GStruct2_1 : gclass2.GStruct2_1;
		return this.fastColoredTextBox_0.method_97(gstruct, gstruct2);
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x000510C4 File Offset: 0x0004F2C4
	public void method_2()
	{
		this.Boolean_0 = false;
		this.GStruct2_0 = new GStruct2(0, 0);
		if (this.fastColoredTextBox_0.Int32_14 == 0)
		{
			this.GStruct2_0 = new GStruct2(0, 0);
		}
		else
		{
			this.gstruct2_1 = new GStruct2(0, 0);
			this.gstruct2_0 = new GStruct2(this.fastColoredTextBox_0[this.fastColoredTextBox_0.Int32_14 - 1].Count, this.fastColoredTextBox_0.Int32_14 - 1);
		}
		if (this == this.fastColoredTextBox_0.GClass86_5)
		{
			this.fastColoredTextBox_0.method_4();
		}
	}

	// Token: 0x170003AC RID: 940
	// (get) Token: 0x06000DE3 RID: 3555 RVA: 0x0000C019 File Offset: 0x0000A219
	// (set) Token: 0x06000DE4 RID: 3556 RVA: 0x0005115C File Offset: 0x0004F35C
	public GStruct2 GStruct2_0
	{
		get
		{
			return this.gstruct2_0;
		}
		set
		{
			this.gstruct2_0 = value;
			this.gstruct2_1 = value;
			this.int_0 = -1;
			this.method_37();
		}
	}

	// Token: 0x170003AD RID: 941
	// (get) Token: 0x06000DE5 RID: 3557 RVA: 0x0000C021 File Offset: 0x0000A221
	// (set) Token: 0x06000DE6 RID: 3558 RVA: 0x0000C029 File Offset: 0x0000A229
	public GStruct2 GStruct2_1
	{
		get
		{
			return this.gstruct2_1;
		}
		set
		{
			this.gstruct2_1 = value;
			this.method_37();
		}
	}

	// Token: 0x170003AE RID: 942
	// (get) Token: 0x06000DE7 RID: 3559 RVA: 0x00051188 File Offset: 0x0004F388
	public virtual string String_1
	{
		get
		{
			if (this.Boolean_0)
			{
				return this.String_0;
			}
			int num = Math.Min(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
			int num2 = Math.Max(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
			int int32_ = this.Int32_2;
			int int32_2 = this.Int32_3;
			if (num < 0)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = num; i <= num2; i++)
			{
				int num3 = (i == num) ? int32_ : 0;
				int num4 = (i == num2) ? Math.Min(this.fastColoredTextBox_0[i].Count - 1, int32_2 - 1) : (this.fastColoredTextBox_0[i].Count - 1);
				for (int j = num3; j <= num4; j++)
				{
					stringBuilder.Append(this.fastColoredTextBox_0[i][j].char_0);
				}
				if (i != num2 && num != num2)
				{
					stringBuilder.AppendLine();
				}
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x170003AF RID: 943
	// (get) Token: 0x06000DE8 RID: 3560 RVA: 0x00051298 File Offset: 0x0004F498
	public int Int32_0
	{
		get
		{
			if (this.Boolean_0)
			{
				return this.method_59(false);
			}
			int num = Math.Min(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
			int num2 = Math.Max(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
			int num3 = 0;
			if (num < 0)
			{
				return 0;
			}
			for (int i = num; i <= num2; i++)
			{
				int num4 = (i == num) ? this.Int32_2 : 0;
				int num5 = (i == num2) ? Math.Min(this.fastColoredTextBox_0[i].Count - 1, this.Int32_3 - 1) : (this.fastColoredTextBox_0[i].Count - 1);
				num3 += num5 - num4 + 1;
				if (i != num2 && num != num2)
				{
					num3 += Environment.NewLine.Length;
				}
			}
			return num3;
		}
	}

	// Token: 0x170003B0 RID: 944
	// (get) Token: 0x06000DE9 RID: 3561 RVA: 0x0000C038 File Offset: 0x0000A238
	public int Int32_1
	{
		get
		{
			if (this.Boolean_0)
			{
				return this.method_59(true);
			}
			return this.Int32_0;
		}
	}

	// Token: 0x06000DEA RID: 3562 RVA: 0x0005136C File Offset: 0x0004F56C
	internal void method_3(out string string_1, out List<GStruct2> list_1)
	{
		if (this.fastColoredTextBox_0.Int32_6 == this.int_2)
		{
			string_1 = this.string_0;
			list_1 = this.list_0;
			return;
		}
		int num = Math.Min(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
		int num2 = Math.Max(this.gstruct2_1.int_1, this.gstruct2_0.int_1);
		int int32_ = this.Int32_2;
		int int32_2 = this.Int32_3;
		StringBuilder stringBuilder = new StringBuilder((num2 - num) * 50);
		list_1 = new List<GStruct2>(stringBuilder.Capacity);
		if (num >= 0)
		{
			for (int i = num; i <= num2; i++)
			{
				int num3 = (i == num) ? int32_ : 0;
				int num4 = (i == num2) ? Math.Min(int32_2 - 1, this.fastColoredTextBox_0[i].Count - 1) : (this.fastColoredTextBox_0[i].Count - 1);
				for (int j = num3; j <= num4; j++)
				{
					stringBuilder.Append(this.fastColoredTextBox_0[i][j].char_0);
					list_1.Add(new GStruct2(j, i));
				}
				if (i != num2 && num != num2)
				{
					foreach (char value in Environment.NewLine)
					{
						stringBuilder.Append(value);
						list_1.Add(new GStruct2(this.fastColoredTextBox_0[i].Count, i));
					}
				}
			}
		}
		string_1 = stringBuilder.ToString();
		list_1.Add(GStruct2.smethod_4(this.GStruct2_1, this.GStruct2_0) ? this.GStruct2_1 : this.GStruct2_0);
		this.string_0 = string_1;
		this.list_0 = list_1;
		this.int_2 = this.fastColoredTextBox_0.Int32_6;
	}

	// Token: 0x170003B1 RID: 945
	// (get) Token: 0x06000DEB RID: 3563 RVA: 0x0005154C File Offset: 0x0004F74C
	public char Char_0
	{
		get
		{
			if (this.GStruct2_0.int_0 >= this.fastColoredTextBox_0[this.GStruct2_0.int_1].Count)
			{
				return '\n';
			}
			return this.fastColoredTextBox_0[this.GStruct2_0.int_1][this.GStruct2_0.int_0].char_0;
		}
	}

	// Token: 0x170003B2 RID: 946
	// (get) Token: 0x06000DEC RID: 3564 RVA: 0x000515B0 File Offset: 0x0004F7B0
	public char Char_1
	{
		get
		{
			if (this.GStruct2_0.int_0 > this.fastColoredTextBox_0[this.GStruct2_0.int_1].Count)
			{
				return '\n';
			}
			if (this.GStruct2_0.int_0 <= 0)
			{
				return '\n';
			}
			return this.fastColoredTextBox_0[this.GStruct2_0.int_1][this.GStruct2_0.int_0 - 1].char_0;
		}
	}

	// Token: 0x06000DED RID: 3565 RVA: 0x00051628 File Offset: 0x0004F828
	public string method_4(int int_3)
	{
		int num = this.fastColoredTextBox_0.method_92(this.GStruct2_0) - int_3;
		if (num < 0)
		{
			num = 0;
		}
		return new GClass86(this.fastColoredTextBox_0, this.fastColoredTextBox_0.method_93(num), this.GStruct2_0).String_1;
	}

	// Token: 0x06000DEE RID: 3566 RVA: 0x0000C050 File Offset: 0x0000A250
	public string method_5(int int_3)
	{
		return this.method_4(-int_3);
	}

	// Token: 0x06000DEF RID: 3567 RVA: 0x0000C05A File Offset: 0x0000A25A
	public GClass86 method_6()
	{
		return (GClass86)base.MemberwiseClone();
	}

	// Token: 0x170003B3 RID: 947
	// (get) Token: 0x06000DF0 RID: 3568 RVA: 0x00051674 File Offset: 0x0004F874
	internal int Int32_2
	{
		get
		{
			if (this.gstruct2_1.int_1 < this.gstruct2_0.int_1)
			{
				return this.gstruct2_1.int_0;
			}
			if (this.gstruct2_1.int_1 > this.gstruct2_0.int_1)
			{
				return this.gstruct2_0.int_0;
			}
			return Math.Min(this.gstruct2_1.int_0, this.gstruct2_0.int_0);
		}
	}

	// Token: 0x170003B4 RID: 948
	// (get) Token: 0x06000DF1 RID: 3569 RVA: 0x000516E4 File Offset: 0x0004F8E4
	internal int Int32_3
	{
		get
		{
			if (this.gstruct2_1.int_1 < this.gstruct2_0.int_1)
			{
				return this.gstruct2_0.int_0;
			}
			if (this.gstruct2_1.int_1 > this.gstruct2_0.int_1)
			{
				return this.gstruct2_1.int_0;
			}
			return Math.Max(this.gstruct2_1.int_0, this.gstruct2_0.int_0);
		}
	}

	// Token: 0x170003B5 RID: 949
	// (get) Token: 0x06000DF2 RID: 3570 RVA: 0x0000C067 File Offset: 0x0000A267
	public int Int32_4
	{
		get
		{
			return Math.Min(this.GStruct2_0.int_1, this.GStruct2_1.int_1);
		}
	}

	// Token: 0x170003B6 RID: 950
	// (get) Token: 0x06000DF3 RID: 3571 RVA: 0x0000C084 File Offset: 0x0000A284
	public int Int32_5
	{
		get
		{
			return Math.Max(this.GStruct2_0.int_1, this.GStruct2_1.int_1);
		}
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0000C0A1 File Offset: 0x0000A2A1
	public bool method_7()
	{
		GStruct2 gstruct = this.gstruct2_0;
		this.method_11(false);
		return GStruct2.smethod_0(gstruct, this.gstruct2_0);
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x00051754 File Offset: 0x0004F954
	public virtual bool vmethod_1()
	{
		if (this.Boolean_0)
		{
			return this.method_57();
		}
		if (this.gstruct2_0.int_1 >= this.fastColoredTextBox_0.Int32_14 - 1 && this.gstruct2_0.int_0 >= this.fastColoredTextBox_0[this.fastColoredTextBox_0.Int32_14 - 1].Count)
		{
			return false;
		}
		if (this.gstruct2_0.int_0 < this.fastColoredTextBox_0[this.gstruct2_0.int_1].Count)
		{
			this.gstruct2_0.method_0(1, 0);
		}
		else
		{
			this.gstruct2_0 = new GStruct2(0, this.gstruct2_0.int_1 + 1);
		}
		this.int_0 = -1;
		this.gstruct2_1 = this.gstruct2_0;
		this.method_37();
		return true;
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x0000C0BB File Offset: 0x0000A2BB
	public bool method_8()
	{
		this.Boolean_0 = false;
		GStruct2 gstruct = this.gstruct2_0;
		this.method_10(false);
		return GStruct2.smethod_0(gstruct, this.gstruct2_0);
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x00051820 File Offset: 0x0004FA20
	public bool method_9()
	{
		this.Boolean_0 = false;
		if (this.gstruct2_0.int_0 == 0 && this.gstruct2_0.int_1 == 0)
		{
			return false;
		}
		if (this.gstruct2_0.int_0 > 0)
		{
			this.gstruct2_0.method_0(-1, 0);
		}
		else
		{
			this.gstruct2_0 = new GStruct2(this.fastColoredTextBox_0[this.gstruct2_0.int_1 - 1].Count, this.gstruct2_0.int_1 - 1);
		}
		this.int_0 = -1;
		this.gstruct2_1 = this.gstruct2_0;
		this.method_37();
		return true;
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x000518BC File Offset: 0x0004FABC
	public void method_10(bool bool_1)
	{
		this.Boolean_0 = false;
		if (!bool_1 && GStruct2.smethod_4(this.gstruct2_0, this.gstruct2_1))
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		if (this.gstruct2_0.int_0 != 0 || this.gstruct2_0.int_1 != 0)
		{
			if (this.gstruct2_0.int_0 > 0 && this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].genum17_0 == GEnum17.Visible)
			{
				this.gstruct2_0.method_0(-1, 0);
			}
			else
			{
				int num = this.fastColoredTextBox_0.method_106(this.gstruct2_0.int_1);
				if (num == this.gstruct2_0.int_1)
				{
					return;
				}
				this.gstruct2_0 = new GStruct2(this.fastColoredTextBox_0[num].Count, num);
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
		this.int_0 = -1;
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x000519B0 File Offset: 0x0004FBB0
	public void method_11(bool bool_1)
	{
		this.Boolean_0 = false;
		if (!bool_1 && GStruct2.smethod_2(this.gstruct2_0, this.gstruct2_1))
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		if (this.gstruct2_0.int_1 < this.fastColoredTextBox_0.Int32_14 - 1 || this.gstruct2_0.int_0 < this.fastColoredTextBox_0[this.fastColoredTextBox_0.Int32_14 - 1].Count)
		{
			if (this.gstruct2_0.int_0 < this.fastColoredTextBox_0[this.gstruct2_0.int_1].Count && this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].genum17_0 == GEnum17.Visible)
			{
				this.gstruct2_0.method_0(1, 0);
			}
			else
			{
				int num = this.fastColoredTextBox_0.method_105(this.gstruct2_0.int_1);
				if (num == this.gstruct2_0.int_1)
				{
					return;
				}
				this.gstruct2_0 = new GStruct2(0, num);
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
		this.int_0 = -1;
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x00051AD8 File Offset: 0x0004FCD8
	internal void method_12(bool bool_1)
	{
		this.Boolean_0 = false;
		if (!bool_1 && this.gstruct2_0.int_1 > this.gstruct2_1.int_1)
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		if (this.int_0 < 0)
		{
			this.int_0 = this.gstruct2_0.int_0 - this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0));
		}
		int num = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0);
		if (num == 0)
		{
			if (this.gstruct2_0.int_1 <= 0)
			{
				return;
			}
			int num2 = this.fastColoredTextBox_0.method_106(this.gstruct2_0.int_1);
			if (num2 == this.gstruct2_0.int_1)
			{
				return;
			}
			this.gstruct2_0.int_1 = num2;
			num = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0;
		}
		if (num > 0)
		{
			int num3 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_1(num - 1, this.fastColoredTextBox_0[this.gstruct2_0.int_1]);
			this.gstruct2_0.int_0 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(num - 1) + this.int_0;
			if (this.gstruct2_0.int_0 > num3 + 1)
			{
				this.gstruct2_0.int_0 = num3 + 1;
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x00051CCC File Offset: 0x0004FECC
	internal void method_13(bool bool_1)
	{
		this.Boolean_0 = false;
		if (this.int_0 < 0)
		{
			this.int_0 = this.gstruct2_0.int_0 - this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0));
		}
		int num = this.fastColoredTextBox_0.ClientRectangle.Height / this.fastColoredTextBox_0.Int32_2 - 1;
		for (int i = 0; i < num; i++)
		{
			int num2 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0);
			if (num2 == 0)
			{
				if (this.gstruct2_0.int_1 <= 0)
				{
					break;
				}
				int num3 = this.fastColoredTextBox_0.method_106(this.gstruct2_0.int_1);
				if (num3 == this.gstruct2_0.int_1)
				{
					break;
				}
				this.gstruct2_0.int_1 = num3;
				num2 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0;
			}
			if (num2 > 0)
			{
				int num4 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_1(num2 - 1, this.fastColoredTextBox_0[this.gstruct2_0.int_1]);
				this.gstruct2_0.int_0 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(num2 - 1) + this.int_0;
				if (this.gstruct2_0.int_0 > num4 + 1)
				{
					this.gstruct2_0.int_0 = num4 + 1;
				}
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x00051EDC File Offset: 0x000500DC
	internal void method_14(bool bool_1)
	{
		this.Boolean_0 = false;
		if (!bool_1 && this.gstruct2_0.int_1 < this.gstruct2_1.int_1)
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		if (this.int_0 < 0)
		{
			this.int_0 = this.gstruct2_0.int_0 - this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0));
		}
		int num = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0);
		if (num >= this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0 - 1)
		{
			if (this.gstruct2_0.int_1 >= this.fastColoredTextBox_0.Int32_14 - 1)
			{
				return;
			}
			int num2 = this.fastColoredTextBox_0.method_105(this.gstruct2_0.int_1);
			if (num2 == this.gstruct2_0.int_1)
			{
				return;
			}
			this.gstruct2_0.int_1 = num2;
			num = -1;
		}
		if (num < this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0 - 1)
		{
			int num3 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_1(num + 1, this.fastColoredTextBox_0[this.gstruct2_0.int_1]);
			this.gstruct2_0.int_0 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(num + 1) + this.int_0;
			if (this.gstruct2_0.int_0 > num3 + 1)
			{
				this.gstruct2_0.int_0 = num3 + 1;
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000DFD RID: 3581 RVA: 0x00052100 File Offset: 0x00050300
	internal void method_15(bool bool_1)
	{
		this.Boolean_0 = false;
		if (this.int_0 < 0)
		{
			this.int_0 = this.gstruct2_0.int_0 - this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0));
		}
		int num = this.fastColoredTextBox_0.ClientRectangle.Height / this.fastColoredTextBox_0.Int32_2 - 1;
		for (int i = 0; i < num; i++)
		{
			int num2 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_2(this.gstruct2_0.int_0);
			if (num2 >= this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0 - 1)
			{
				if (this.gstruct2_0.int_1 >= this.fastColoredTextBox_0.Int32_14 - 1)
				{
					break;
				}
				int num3 = this.fastColoredTextBox_0.method_105(this.gstruct2_0.int_1);
				if (num3 == this.gstruct2_0.int_1)
				{
					break;
				}
				this.gstruct2_0.int_1 = num3;
				num2 = -1;
			}
			if (num2 < this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].Int32_0 - 1)
			{
				int num4 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_1(num2 + 1, this.fastColoredTextBox_0[this.gstruct2_0.int_1]);
				this.gstruct2_0.int_0 = this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].method_0(num2 + 1) + this.int_0;
				if (this.gstruct2_0.int_0 > num4 + 1)
				{
					this.gstruct2_0.int_0 = num4 + 1;
				}
			}
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000DFE RID: 3582 RVA: 0x00052344 File Offset: 0x00050544
	internal void method_16(bool bool_1)
	{
		this.Boolean_0 = false;
		if (this.gstruct2_0.int_1 < 0)
		{
			return;
		}
		if (this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			return;
		}
		this.gstruct2_0 = new GStruct2(0, this.gstruct2_0.int_1);
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
		this.int_0 = -1;
	}

	// Token: 0x06000DFF RID: 3583 RVA: 0x000523C0 File Offset: 0x000505C0
	internal void method_17(bool bool_1)
	{
		this.Boolean_0 = false;
		if (this.gstruct2_0.int_1 < 0)
		{
			return;
		}
		if (this.fastColoredTextBox_0.list_0[this.gstruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			return;
		}
		this.gstruct2_0 = new GStruct2(this.fastColoredTextBox_0[this.gstruct2_0.int_1].Count, this.gstruct2_0.int_1);
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
		this.int_0 = -1;
	}

	// Token: 0x06000E00 RID: 3584 RVA: 0x00052454 File Offset: 0x00050654
	public void method_18(GClass87 gclass87_0)
	{
		int int_ = this.fastColoredTextBox_0.method_34(gclass87_0);
		this.method_24(GClass86.smethod_0(int_));
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E01 RID: 3585 RVA: 0x00052488 File Offset: 0x00050688
	public void method_19(GClass87 gclass87_0, string string_1)
	{
		StyleIndex styleIndex_ = GClass86.smethod_0(this.fastColoredTextBox_0.method_34(gclass87_0));
		this.method_22(styleIndex_, string_1, RegexOptions.None);
	}

	// Token: 0x06000E02 RID: 3586 RVA: 0x000524B0 File Offset: 0x000506B0
	public void method_20(GClass87 gclass87_0, Regex regex_0)
	{
		StyleIndex styleIndex_ = GClass86.smethod_0(this.fastColoredTextBox_0.method_34(gclass87_0));
		this.method_23(styleIndex_, regex_0);
	}

	// Token: 0x06000E03 RID: 3587 RVA: 0x000524D8 File Offset: 0x000506D8
	public void method_21(GClass87 gclass87_0, string string_1, RegexOptions regexOptions_0)
	{
		StyleIndex styleIndex_ = GClass86.smethod_0(this.fastColoredTextBox_0.method_34(gclass87_0));
		this.method_22(styleIndex_, string_1, regexOptions_0);
	}

	// Token: 0x06000E04 RID: 3588 RVA: 0x00052500 File Offset: 0x00050700
	public void method_22(StyleIndex styleIndex_0, string string_1, RegexOptions regexOptions_0)
	{
		if (Math.Abs(this.GStruct2_0.int_1 - this.GStruct2_1.int_1) > 1000)
		{
			regexOptions_0 |= GClass98.RegexOptions_0;
		}
		foreach (GClass86 gclass in this.method_29(string_1, regexOptions_0))
		{
			gclass.method_24(styleIndex_0);
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E05 RID: 3589 RVA: 0x00052588 File Offset: 0x00050788
	public void method_23(StyleIndex styleIndex_0, Regex regex_0)
	{
		foreach (GClass86 gclass in this.method_33(regex_0))
		{
			gclass.method_24(styleIndex_0);
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E06 RID: 3590 RVA: 0x000525E0 File Offset: 0x000507E0
	public void method_24(StyleIndex styleIndex_0)
	{
		int num = Math.Min(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		int num2 = Math.Max(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		int int32_ = this.Int32_2;
		int int32_2 = this.Int32_3;
		if (num < 0)
		{
			return;
		}
		for (int i = num; i <= num2; i++)
		{
			int num3 = (i == num) ? int32_ : 0;
			int num4 = (i == num2) ? Math.Min(int32_2 - 1, this.fastColoredTextBox_0[i].Count - 1) : (this.fastColoredTextBox_0[i].Count - 1);
			for (int j = num3; j <= num4; j++)
			{
				GStruct0 value = this.fastColoredTextBox_0[i][j];
				value.styleIndex_0 |= styleIndex_0;
				this.fastColoredTextBox_0[i][j] = value;
			}
		}
	}

	// Token: 0x06000E07 RID: 3591 RVA: 0x0000C0DC File Offset: 0x0000A2DC
	public void method_25(string string_1, string string_2)
	{
		this.method_26(string_1, string_2, GClass98.RegexOptions_0);
	}

	// Token: 0x06000E08 RID: 3592 RVA: 0x000526D8 File Offset: 0x000508D8
	public void method_26(string string_1, string string_2, RegexOptions regexOptions_0)
	{
		if (string_1 == string_2)
		{
			this.method_27(string_1, regexOptions_0);
			return;
		}
		foreach (GClass86 gclass in this.method_29(string_1, regexOptions_0))
		{
			this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].String_0 = string_1;
		}
		foreach (GClass86 gclass2 in this.method_29(string_2, regexOptions_0))
		{
			this.fastColoredTextBox_0[gclass2.GStruct2_0.int_1].String_1 = string_1;
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E09 RID: 3593 RVA: 0x000527B0 File Offset: 0x000509B0
	public void method_27(string string_1, RegexOptions regexOptions_0)
	{
		foreach (GClass86 gclass in this.method_29(string_1, regexOptions_0))
		{
			if (gclass.GStruct2_0.int_1 > 0)
			{
				this.fastColoredTextBox_0[gclass.GStruct2_0.int_1 - 1].String_1 = string_1;
			}
			this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].String_0 = string_1;
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E0A RID: 3594 RVA: 0x0000C0EB File Offset: 0x0000A2EB
	public IEnumerable<GClass86> method_28(string string_1)
	{
		return this.method_29(string_1, RegexOptions.None);
	}

	// Token: 0x06000E0B RID: 3595 RVA: 0x0000C0F5 File Offset: 0x0000A2F5
	public IEnumerable<GClass86> method_29(string string_1, RegexOptions regexOptions_0)
	{
		GClass86.Class107 @class = new GClass86.Class107(-2);
		@class.gclass86_1 = this;
		@class.string_1 = string_1;
		@class.regexOptions_1 = regexOptions_0;
		return @class;
	}

	// Token: 0x06000E0C RID: 3596 RVA: 0x0000C113 File Offset: 0x0000A313
	public IEnumerable<GClass86> method_30(string string_1, RegexOptions regexOptions_0)
	{
		GClass86.Class108 @class = new GClass86.Class108(-2);
		@class.gclass86_1 = this;
		@class.string_1 = string_1;
		@class.regexOptions_1 = regexOptions_0;
		return @class;
	}

	// Token: 0x06000E0D RID: 3597 RVA: 0x0000C131 File Offset: 0x0000A331
	public IEnumerable<GClass86> method_31(Regex regex_0)
	{
		GClass86.Class109 @class = new GClass86.Class109(-2);
		@class.gclass86_1 = this;
		@class.regex_1 = regex_0;
		return @class;
	}

	// Token: 0x06000E0E RID: 3598 RVA: 0x0000C148 File Offset: 0x0000A348
	public IEnumerable<GClass86> method_32(string string_1, RegexOptions regexOptions_0)
	{
		GClass86.Class110 @class = new GClass86.Class110(-2);
		@class.gclass86_1 = this;
		@class.string_1 = string_1;
		@class.regexOptions_1 = regexOptions_0;
		return @class;
	}

	// Token: 0x06000E0F RID: 3599 RVA: 0x0000C166 File Offset: 0x0000A366
	public IEnumerable<GClass86> method_33(Regex regex_0)
	{
		GClass86.Class111 @class = new GClass86.Class111(-2);
		@class.gclass86_1 = this;
		@class.regex_1 = regex_0;
		return @class;
	}

	// Token: 0x06000E10 RID: 3600 RVA: 0x0005284C File Offset: 0x00050A4C
	public void method_34(params GClass87[] gclass87_0)
	{
		try
		{
			this.method_35(this.fastColoredTextBox_0.method_33(gclass87_0));
		}
		catch
		{
		}
	}

	// Token: 0x06000E11 RID: 3601 RVA: 0x00052880 File Offset: 0x00050A80
	public void method_35(StyleIndex styleIndex_0)
	{
		int num = Math.Min(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		int num2 = Math.Max(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		int int32_ = this.Int32_2;
		int int32_2 = this.Int32_3;
		if (num < 0)
		{
			return;
		}
		for (int i = num; i <= num2; i++)
		{
			int num3 = (i == num) ? int32_ : 0;
			int num4 = (i == num2) ? Math.Min(int32_2 - 1, this.fastColoredTextBox_0[i].Count - 1) : (this.fastColoredTextBox_0[i].Count - 1);
			for (int j = num3; j <= num4; j++)
			{
				GStruct0 value = this.fastColoredTextBox_0[i][j];
				value.styleIndex_0 &= ~styleIndex_0;
				this.fastColoredTextBox_0[i][j] = value;
			}
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E12 RID: 3602 RVA: 0x00052988 File Offset: 0x00050B88
	public void method_36()
	{
		int num = Math.Min(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		int num2 = Math.Max(this.GStruct2_1.int_1, this.GStruct2_0.int_1);
		if (num < 0)
		{
			return;
		}
		for (int i = num; i <= num2; i++)
		{
			this.fastColoredTextBox_0[i].method_1();
		}
		this.fastColoredTextBox_0.method_4();
	}

	// Token: 0x06000E13 RID: 3603 RVA: 0x0000C17D File Offset: 0x0000A37D
	private void method_37()
	{
		this.int_2 = -1;
		this.string_0 = null;
		this.list_0 = null;
		if (this.fastColoredTextBox_0.GClass86_5 == this && this.int_1 == 0)
		{
			this.fastColoredTextBox_0.vmethod_58();
		}
	}

	// Token: 0x06000E14 RID: 3604 RVA: 0x0000C1B5 File Offset: 0x0000A3B5
	public void method_38()
	{
		this.int_1++;
	}

	// Token: 0x06000E15 RID: 3605 RVA: 0x0000C1C5 File Offset: 0x0000A3C5
	public void method_39()
	{
		this.int_1--;
		if (this.int_1 == 0)
		{
			this.method_37();
		}
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x000529FC File Offset: 0x00050BFC
	public virtual string ToString()
	{
		return "Start: " + this.GStruct2_0.ToString() + " End: " + this.GStruct2_1.ToString();
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x0000C1E3 File Offset: 0x0000A3E3
	public void method_40()
	{
		if (GStruct2.smethod_4(this.GStruct2_0, this.GStruct2_1))
		{
			this.method_41();
		}
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x00052A40 File Offset: 0x00050C40
	public void method_41()
	{
		GStruct2 gstruct = this.gstruct2_0;
		this.gstruct2_0 = this.gstruct2_1;
		this.gstruct2_1 = gstruct;
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x00052A68 File Offset: 0x00050C68
	public void method_42()
	{
		this.method_40();
		this.gstruct2_0 = new GStruct2(0, this.gstruct2_0.int_1);
		this.gstruct2_1 = new GStruct2(this.fastColoredTextBox_0.method_23(this.gstruct2_1.int_1), this.gstruct2_1.int_1);
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x0000C1FE File Offset: 0x0000A3FE
	IEnumerator<GStruct2> IEnumerable<GStruct2>.GetEnumerator()
	{
		GClass86.Class112 @class = new GClass86.Class112(0);
		@class.gclass86_0 = this;
		return @class;
	}

	// Token: 0x06000E1B RID: 3611 RVA: 0x0000C20D File Offset: 0x0000A40D
	IEnumerator IEnumerable.GetEnumerator()
	{
		return ((IEnumerable<GStruct2>)this).GetEnumerator();
	}

	// Token: 0x170003B7 RID: 951
	// (get) Token: 0x06000E1C RID: 3612 RVA: 0x0000C215 File Offset: 0x0000A415
	public IEnumerable<GStruct0> IEnumerable_0
	{
		get
		{
			GClass86.Class113 @class = new GClass86.Class113(-2);
			@class.gclass86_0 = this;
			return @class;
		}
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x0000C225 File Offset: 0x0000A425
	public GClass86 method_43(string string_1)
	{
		return this.method_45(string_1, RegexOptions.None);
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x00052AC0 File Offset: 0x00050CC0
	public GClass86 method_44(GClass87 gclass87_0, bool bool_1)
	{
		StyleIndex styleIndex = this.fastColoredTextBox_0.method_33(new GClass87[]
		{
			gclass87_0
		});
		GClass86 gclass = new GClass86(this.fastColoredTextBox_0);
		gclass.GStruct2_0 = this.GStruct2_0;
		while (gclass.method_9())
		{
			if (bool_1 || gclass.Char_0 != '\n')
			{
				if (gclass.GStruct2_0.int_0 >= this.fastColoredTextBox_0.method_23(gclass.GStruct2_0.int_1) || (this.fastColoredTextBox_0[gclass.GStruct2_0].styleIndex_0 & styleIndex) != StyleIndex.None)
				{
					continue;
				}
				gclass.vmethod_1();
			}
			IL_8B:
			GStruct2 gstruct2_ = gclass.GStruct2_0;
			gclass.GStruct2_0 = this.GStruct2_0;
			do
			{
				if (!bool_1)
				{
					if (gclass.Char_0 == '\n')
					{
						break;
					}
				}
				if (gclass.GStruct2_0.int_0 < this.fastColoredTextBox_0.method_23(gclass.GStruct2_0.int_1) && (this.fastColoredTextBox_0[gclass.GStruct2_0].styleIndex_0 & styleIndex) == StyleIndex.None)
				{
					break;
				}
			}
			while (gclass.vmethod_1());
			GStruct2 gstruct2_2 = gclass.GStruct2_0;
			return new GClass86(this.fastColoredTextBox_0, gstruct2_, gstruct2_2);
		}
		goto IL_8B;
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x00052BDC File Offset: 0x00050DDC
	public GClass86 method_45(string string_1, RegexOptions regexOptions_0)
	{
		GClass86 gclass = new GClass86(this.fastColoredTextBox_0);
		gclass.GStruct2_0 = this.GStruct2_0;
		Regex regex = new Regex(string_1, regexOptions_0);
		while (gclass.method_9())
		{
			if (!regex.IsMatch(gclass.Char_0.ToString()))
			{
				gclass.vmethod_1();
				IL_4A:
				GStruct2 gstruct2_ = gclass.GStruct2_0;
				gclass.GStruct2_0 = this.GStruct2_0;
				while (regex.IsMatch(gclass.Char_0.ToString()) && gclass.vmethod_1())
				{
				}
				GStruct2 gstruct2_2 = gclass.GStruct2_0;
				return new GClass86(this.fastColoredTextBox_0, gstruct2_, gstruct2_2);
			}
		}
		goto IL_4A;
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x0000C22F File Offset: 0x0000A42F
	private bool method_46(char char_0)
	{
		return char.IsLetterOrDigit(char_0) || char_0 == '_';
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x0000C240 File Offset: 0x0000A440
	private bool method_47(char char_0)
	{
		return char_0 == ' ' || char_0 == '\t';
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x00052C7C File Offset: 0x00050E7C
	public void method_48(bool bool_1)
	{
		this.Boolean_0 = false;
		if (!bool_1 && GStruct2.smethod_4(this.gstruct2_0, this.gstruct2_1))
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		GClass86 gclass = this.method_6();
		bool flag = false;
		while (this.method_47(gclass.Char_1))
		{
			flag = true;
			gclass.method_10(bool_1);
		}
		bool flag2 = false;
		while (this.method_46(gclass.Char_1))
		{
			flag2 = true;
			gclass.method_10(bool_1);
		}
		if (!flag2 && (!flag || gclass.Char_1 != '\n'))
		{
			gclass.method_10(bool_1);
		}
		this.GStruct2_0 = gclass.GStruct2_0;
		this.GStruct2_1 = gclass.GStruct2_1;
		if (this.fastColoredTextBox_0.list_0[this.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_11(bool_1);
		}
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x00052D48 File Offset: 0x00050F48
	public void method_49(bool bool_1, bool bool_2 = false)
	{
		this.Boolean_0 = false;
		if (!bool_1 && GStruct2.smethod_2(this.gstruct2_0, this.gstruct2_1))
		{
			this.GStruct2_0 = this.GStruct2_1;
			return;
		}
		GClass86 gclass = this.method_6();
		bool flag = false;
		if (gclass.Char_0 == '\n')
		{
			gclass.method_11(bool_1);
			flag = true;
		}
		bool flag2 = false;
		while (this.method_47(gclass.Char_0))
		{
			flag2 = true;
			gclass.method_11(bool_1);
		}
		if ((!flag2 && !flag) || !bool_2)
		{
			bool flag3 = false;
			while (this.method_46(gclass.Char_0))
			{
				flag3 = true;
				gclass.method_11(bool_1);
			}
			if (!flag3)
			{
				gclass.method_11(bool_1);
			}
			if (bool_2 && !flag2)
			{
				while (this.method_47(gclass.Char_0))
				{
					gclass.method_11(bool_1);
				}
			}
		}
		this.GStruct2_0 = gclass.GStruct2_0;
		this.GStruct2_1 = gclass.GStruct2_1;
		if (this.fastColoredTextBox_0.list_0[this.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.method_10(bool_1);
		}
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x00052E40 File Offset: 0x00051040
	internal void method_50(bool bool_1)
	{
		this.Boolean_0 = false;
		this.gstruct2_0 = new GStruct2(0, 0);
		if (this.fastColoredTextBox_0.list_0[this.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.fastColoredTextBox_0.method_101(this.GStruct2_0.int_1);
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x00052EB0 File Offset: 0x000510B0
	internal void method_51(bool bool_1)
	{
		this.Boolean_0 = false;
		this.gstruct2_0 = new GStruct2(this.fastColoredTextBox_0[this.fastColoredTextBox_0.Int32_14 - 1].Count, this.fastColoredTextBox_0.Int32_14 - 1);
		if (this.fastColoredTextBox_0.list_0[this.GStruct2_0.int_1].genum17_0 != GEnum17.Visible)
		{
			this.fastColoredTextBox_0.method_101(this.GStruct2_0.int_1);
		}
		if (!bool_1)
		{
			this.gstruct2_1 = this.gstruct2_0;
		}
		this.method_37();
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x0000C24E File Offset: 0x0000A44E
	public static StyleIndex smethod_0(int int_3)
	{
		return (StyleIndex)(1 << int_3);
	}

	// Token: 0x170003B8 RID: 952
	// (get) Token: 0x06000E27 RID: 3623 RVA: 0x00052F48 File Offset: 0x00051148
	public GStruct3 GStruct3_0
	{
		get
		{
			int int_ = Math.Min(this.GStruct2_0.int_0, this.GStruct2_1.int_0);
			int int_2 = Math.Min(this.GStruct2_0.int_1, this.GStruct2_1.int_1);
			int int_3 = Math.Max(this.GStruct2_0.int_0, this.GStruct2_1.int_0);
			int int_4 = Math.Max(this.GStruct2_0.int_1, this.GStruct2_1.int_1);
			return new GStruct3(int_2, int_, int_4, int_3);
		}
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x0000C257 File Offset: 0x0000A457
	public IEnumerable<GClass86> method_52(bool bool_1)
	{
		GClass86.Class114 @class = new GClass86.Class114(-2);
		@class.gclass86_1 = this;
		@class.bool_1 = bool_1;
		return @class;
	}

	// Token: 0x170003B9 RID: 953
	// (get) Token: 0x06000E29 RID: 3625 RVA: 0x00052FCC File Offset: 0x000511CC
	// (set) Token: 0x06000E2A RID: 3626 RVA: 0x000531E4 File Offset: 0x000513E4
	public bool Boolean_1
	{
		get
		{
			if (this.fastColoredTextBox_0.Boolean_9)
			{
				return true;
			}
			GClass94 gclass = null;
			foreach (GClass87 gclass2 in this.fastColoredTextBox_0.GClass87_0)
			{
				if (gclass2 is GClass94)
				{
					gclass = (GClass94)gclass2;
					IL_40:
					if (gclass != null)
					{
						StyleIndex styleIndex = GClass86.smethod_0(this.fastColoredTextBox_0.method_32(gclass));
						if (this.Boolean_2)
						{
							GClass81 gclass3 = this.fastColoredTextBox_0[this.gstruct2_0.int_1];
							if (this.bool_0)
							{
								using (IEnumerator<GClass86> enumerator = this.method_52(false).GetEnumerator())
								{
									while (enumerator.MoveNext())
									{
										GClass86 gclass4 = enumerator.Current;
										gclass3 = this.fastColoredTextBox_0[gclass4.gstruct2_0.int_1];
										if (gclass4.gstruct2_0.int_0 < gclass3.Count && gclass4.gstruct2_0.int_0 > 0)
										{
											ref GStruct0 ptr = gclass3[gclass4.gstruct2_0.int_0 - 1];
											GStruct0 gstruct = gclass3[gclass4.gstruct2_0.int_0];
											if ((ptr.styleIndex_0 & styleIndex) != StyleIndex.None && (gstruct.styleIndex_0 & styleIndex) != StyleIndex.None)
											{
												return true;
											}
										}
									}
									return false;
								}
							}
							if (this.gstruct2_0.int_0 >= gclass3.Count || this.gstruct2_0.int_0 <= 0)
							{
								return false;
							}
							ref GStruct0 ptr2 = gclass3[this.gstruct2_0.int_0 - 1];
							GStruct0 gstruct2 = gclass3[this.gstruct2_0.int_0];
							if ((ptr2.styleIndex_0 & styleIndex) != StyleIndex.None && (gstruct2.styleIndex_0 & styleIndex) != StyleIndex.None)
							{
								return true;
							}
							return false;
						}
						else
						{
							using (IEnumerator<GStruct0> enumerator2 = this.IEnumerable_0.GetEnumerator())
							{
								while (enumerator2.MoveNext())
								{
									if ((enumerator2.Current.styleIndex_0 & styleIndex) != StyleIndex.None)
									{
										return true;
									}
								}
								return false;
							}
						}
						bool result;
						return result;
					}
					return false;
				}
			}
			goto IL_40;
		}
		set
		{
			GClass94 gclass = null;
			GClass87[] gclass87_ = this.fastColoredTextBox_0.GClass87_0;
			int i = 0;
			while (i < gclass87_.Length)
			{
				GClass87 gclass2 = gclass87_[i];
				if (!(gclass2 is GClass94))
				{
					i++;
				}
				else
				{
					gclass = (GClass94)gclass2;
					IL_31:
					if (gclass == null)
					{
						gclass = new GClass94();
					}
					if (value)
					{
						this.method_18(gclass);
						return;
					}
					this.method_34(new GClass87[]
					{
						gclass
					});
					return;
				}
			}
			goto IL_31;
		}
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x00053248 File Offset: 0x00051448
	public bool method_53()
	{
		if (this.fastColoredTextBox_0.Boolean_9)
		{
			return true;
		}
		GClass86 gclass = this.method_6();
		gclass.method_40();
		if (gclass.gstruct2_0.int_0 == 0)
		{
			return false;
		}
		if (this.Boolean_0)
		{
			gclass.method_63();
		}
		else
		{
			gclass.method_10(true);
		}
		return gclass.Boolean_1;
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x000532A0 File Offset: 0x000514A0
	public bool method_54()
	{
		if (this.fastColoredTextBox_0.Boolean_9)
		{
			return true;
		}
		GClass86 gclass = this.method_6();
		gclass.method_40();
		if (gclass.gstruct2_1.int_0 >= this.fastColoredTextBox_0[this.gstruct2_1.int_1].Count)
		{
			return false;
		}
		if (this.Boolean_0)
		{
			gclass.method_62();
		}
		else
		{
			gclass.method_11(true);
		}
		return gclass.Boolean_1;
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x0000C26E File Offset: 0x0000A46E
	public IEnumerable<GStruct2> method_55(GStruct2 gstruct2_2, bool bool_1 = false)
	{
		if (bool_1)
		{
			GClass86 gclass = new GClass86(this.fastColoredTextBox_0, gstruct2_2, gstruct2_2);
			while (gclass.method_8() && GStruct2.smethod_5(gclass.gstruct2_0, this.GStruct2_0))
			{
				if (gclass.GStruct2_0.int_0 < this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].Count)
				{
					yield return gclass.GStruct2_0;
				}
			}
			gclass = new GClass86(this.fastColoredTextBox_0, this.GStruct2_1, this.GStruct2_1);
			while (gclass.method_8() && GStruct2.smethod_5(gclass.gstruct2_0, gstruct2_2))
			{
				if (gclass.GStruct2_0.int_0 < this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].Count)
				{
					yield return gclass.GStruct2_0;
				}
			}
			gclass = null;
		}
		else
		{
			GClass86 gclass = new GClass86(this.fastColoredTextBox_0, gstruct2_2, gstruct2_2);
			if (GStruct2.smethod_2(gstruct2_2, this.GStruct2_1))
			{
				do
				{
					if (gclass.GStruct2_0.int_0 < this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].Count)
					{
						yield return gclass.GStruct2_0;
					}
				}
				while (gclass.method_7());
			}
			gclass = new GClass86(this.fastColoredTextBox_0, this.GStruct2_0, this.GStruct2_0);
			if (GStruct2.smethod_2(gclass.GStruct2_0, gstruct2_2))
			{
				do
				{
					if (gclass.GStruct2_0.int_0 < this.fastColoredTextBox_0[gclass.GStruct2_0.int_1].Count)
					{
						yield return gclass.GStruct2_0;
					}
				}
				while (gclass.method_7() && GStruct2.smethod_2(gclass.GStruct2_0, gstruct2_2));
			}
			gclass = null;
		}
		yield break;
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x00053310 File Offset: 0x00051510
	private GClass86 method_56(GClass86 gclass86_0)
	{
		if (gclass86_0.GStruct2_0.int_1 != gclass86_0.GStruct2_1.int_1)
		{
			return new GClass86(this.fastColoredTextBox_0, this.GStruct2_0, this.GStruct2_0);
		}
		GStruct3 gstruct3_ = this.GStruct3_0;
		if (gclass86_0.GStruct2_0.int_1 >= gstruct3_.int_0 && gclass86_0.GStruct2_0.int_1 <= gstruct3_.int_2)
		{
			return new GClass86(this.fastColoredTextBox_0, gstruct3_.int_1, gclass86_0.GStruct2_0.int_1, gstruct3_.int_3, gclass86_0.GStruct2_0.int_1).vmethod_0(gclass86_0);
		}
		return new GClass86(this.fastColoredTextBox_0, this.GStruct2_0, this.GStruct2_0);
	}

	// Token: 0x06000E2F RID: 3631 RVA: 0x000533C8 File Offset: 0x000515C8
	private bool method_57()
	{
		GStruct3 gstruct3_ = this.GStruct3_0;
		bool flag = true;
		int i = gstruct3_.int_0;
		while (i <= gstruct3_.int_2)
		{
			if (gstruct3_.int_3 >= this.fastColoredTextBox_0[i].Count)
			{
				i++;
			}
			else
			{
				flag = false;
				IL_41:
				if (flag)
				{
					return false;
				}
				GStruct2 gstruct = this.GStruct2_0;
				GStruct2 gstruct2 = this.GStruct2_1;
				gstruct.method_0(1, 0);
				gstruct2.method_0(1, 0);
				this.method_38();
				this.GStruct2_0 = gstruct;
				this.GStruct2_1 = gstruct2;
				this.method_39();
				return true;
			}
		}
		goto IL_41;
	}

	// Token: 0x06000E30 RID: 3632 RVA: 0x0000C28C File Offset: 0x0000A48C
	private IEnumerable<GStruct2> method_58()
	{
		GClass86.Class116 @class = new GClass86.Class116(-2);
		@class.gclass86_0 = this;
		return @class;
	}

	// Token: 0x170003BA RID: 954
	// (get) Token: 0x06000E31 RID: 3633 RVA: 0x00053458 File Offset: 0x00051658
	private string String_0
	{
		get
		{
			StringBuilder stringBuilder = new StringBuilder();
			GStruct3 gstruct3_ = this.GStruct3_0;
			if (gstruct3_.int_0 < 0)
			{
				return "";
			}
			for (int i = gstruct3_.int_0; i <= gstruct3_.int_2; i++)
			{
				for (int j = gstruct3_.int_1; j < gstruct3_.int_3; j++)
				{
					if (j < this.fastColoredTextBox_0[i].Count)
					{
						stringBuilder.Append(this.fastColoredTextBox_0[i][j].char_0);
					}
				}
				if (gstruct3_.int_2 != gstruct3_.int_0 && i != gstruct3_.int_2)
				{
					stringBuilder.AppendLine();
				}
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x06000E32 RID: 3634 RVA: 0x00053504 File Offset: 0x00051704
	private int method_59(bool bool_1)
	{
		GStruct3 gstruct3_ = this.GStruct3_0;
		if (gstruct3_.int_0 < 0)
		{
			return 0;
		}
		int num = 0;
		for (int i = gstruct3_.int_0; i <= gstruct3_.int_2; i++)
		{
			for (int j = gstruct3_.int_1; j < gstruct3_.int_3; j++)
			{
				if (j < this.fastColoredTextBox_0[i].Count)
				{
					num++;
				}
			}
			if (bool_1 && gstruct3_.int_2 != gstruct3_.int_0 && i != gstruct3_.int_2)
			{
				num += Environment.NewLine.Length;
			}
		}
		return num;
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x00053594 File Offset: 0x00051794
	internal void method_60()
	{
		int int_ = this.fastColoredTextBox_0.method_105(this.GStruct2_1.int_1);
		this.GStruct2_1 = new GStruct2(this.GStruct2_1.int_0, int_);
	}

	// Token: 0x06000E34 RID: 3636 RVA: 0x000535D0 File Offset: 0x000517D0
	internal void method_61()
	{
		int int_ = this.fastColoredTextBox_0.method_106(this.GStruct2_1.int_1);
		this.GStruct2_1 = new GStruct2(this.GStruct2_1.int_0, int_);
	}

	// Token: 0x06000E35 RID: 3637 RVA: 0x0000C29C File Offset: 0x0000A49C
	internal void method_62()
	{
		this.GStruct2_1 = new GStruct2(this.GStruct2_1.int_0 + 1, this.GStruct2_1.int_1);
	}

	// Token: 0x06000E36 RID: 3638 RVA: 0x0000C2C1 File Offset: 0x0000A4C1
	internal void method_63()
	{
		if (this.GStruct2_1.int_0 > 0)
		{
			this.GStruct2_1 = new GStruct2(this.GStruct2_1.int_0 - 1, this.GStruct2_1.int_1);
		}
	}

	// Token: 0x040006D7 RID: 1751
	private GStruct2 gstruct2_0;

	// Token: 0x040006D8 RID: 1752
	private GStruct2 gstruct2_1;

	// Token: 0x040006D9 RID: 1753
	public readonly FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040006DA RID: 1754
	private int int_0 = -1;

	// Token: 0x040006DB RID: 1755
	private int int_1;

	// Token: 0x040006DC RID: 1756
	private string string_0;

	// Token: 0x040006DD RID: 1757
	private List<GStruct2> list_0;

	// Token: 0x040006DE RID: 1758
	private int int_2 = -1;

	// Token: 0x040006DF RID: 1759
	private bool bool_0;
}
