﻿using System;

// Token: 0x0200003A RID: 58
public class GEventArgs3 : EventArgs
{
	// Token: 0x06000267 RID: 615 RVA: 0x0000499B File Offset: 0x00002B9B
	internal GEventArgs3(string string_1) : this(string_1, null)
	{
	}

	// Token: 0x06000268 RID: 616 RVA: 0x000049A5 File Offset: 0x00002BA5
	internal GEventArgs3(string string_1, Exception exception_1)
	{
		this.string_0 = string_1;
		this.exception_0 = exception_1;
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x06000269 RID: 617 RVA: 0x000049BB File Offset: 0x00002BBB
	public Exception Exception_0
	{
		get
		{
			return this.exception_0;
		}
	}

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x0600026A RID: 618 RVA: 0x000049C3 File Offset: 0x00002BC3
	public string String_0
	{
		get
		{
			return this.string_0;
		}
	}

	// Token: 0x0400017A RID: 378
	private Exception exception_0;

	// Token: 0x0400017B RID: 379
	private string string_0;
}
