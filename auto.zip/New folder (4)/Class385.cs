﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020002BC RID: 700
internal class Class385
{
	// Token: 0x1700086D RID: 2157
	// (get) Token: 0x060026F4 RID: 9972 RVA: 0x0001D077 File Offset: 0x0001B277
	// (set) Token: 0x060026F5 RID: 9973 RVA: 0x0001D07F File Offset: 0x0001B27F
	public uint UInt32_0 { get; set; }

	// Token: 0x1700086E RID: 2158
	// (get) Token: 0x060026F6 RID: 9974 RVA: 0x0001D088 File Offset: 0x0001B288
	// (set) Token: 0x060026F7 RID: 9975 RVA: 0x0001D090 File Offset: 0x0001B290
	public string String_0 { get; set; }

	// Token: 0x1700086F RID: 2159
	// (get) Token: 0x060026F8 RID: 9976 RVA: 0x0001D099 File Offset: 0x0001B299
	// (set) Token: 0x060026F9 RID: 9977 RVA: 0x0001D0A1 File Offset: 0x0001B2A1
	public string String_1 { get; set; } = string.Empty;

	// Token: 0x17000870 RID: 2160
	// (get) Token: 0x060026FA RID: 9978 RVA: 0x0001D0AA File Offset: 0x0001B2AA
	// (set) Token: 0x060026FB RID: 9979 RVA: 0x0001D0B2 File Offset: 0x0001B2B2
	public string String_2 { get; set; } = string.Empty;

	// Token: 0x17000871 RID: 2161
	// (get) Token: 0x060026FC RID: 9980 RVA: 0x0001D0BB File Offset: 0x0001B2BB
	// (set) Token: 0x060026FD RID: 9981 RVA: 0x0001D0C3 File Offset: 0x0001B2C3
	public uint UInt32_1 { get; set; }

	// Token: 0x17000872 RID: 2162
	// (get) Token: 0x060026FE RID: 9982 RVA: 0x0001D0CC File Offset: 0x0001B2CC
	// (set) Token: 0x060026FF RID: 9983 RVA: 0x0001D0D4 File Offset: 0x0001B2D4
	public float Single_0 { get; set; }

	// Token: 0x17000873 RID: 2163
	// (get) Token: 0x06002700 RID: 9984 RVA: 0x0001D0DD File Offset: 0x0001B2DD
	// (set) Token: 0x06002701 RID: 9985 RVA: 0x0001D0E5 File Offset: 0x0001B2E5
	public float Single_1 { get; set; }

	// Token: 0x17000874 RID: 2164
	// (get) Token: 0x06002702 RID: 9986 RVA: 0x0001D0EE File Offset: 0x0001B2EE
	// (set) Token: 0x06002703 RID: 9987 RVA: 0x0001D0F6 File Offset: 0x0001B2F6
	public bool Boolean_0 { get; set; }

	// Token: 0x04001A8F RID: 6799
	[CompilerGenerated]
	private uint uint_0;

	// Token: 0x04001A90 RID: 6800
	[CompilerGenerated]
	private string string_0;

	// Token: 0x04001A91 RID: 6801
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04001A92 RID: 6802
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04001A93 RID: 6803
	[CompilerGenerated]
	private uint uint_1;

	// Token: 0x04001A94 RID: 6804
	[CompilerGenerated]
	private float float_0;

	// Token: 0x04001A95 RID: 6805
	[CompilerGenerated]
	private float float_1;

	// Token: 0x04001A96 RID: 6806
	[CompilerGenerated]
	private bool bool_0;
}
