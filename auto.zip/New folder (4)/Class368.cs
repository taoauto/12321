﻿using System;
using System.Threading;

// Token: 0x020002AA RID: 682
internal class Class368
{
	// Token: 0x06002632 RID: 9778 RVA: 0x0001C755 File Offset: 0x0001A955
	public Class368(Class159 class159_1)
	{
		this.class159_0 = class159_1;
	}

	// Token: 0x06002633 RID: 9779 RVA: 0x0001C771 File Offset: 0x0001A971
	public void method_0()
	{
		this.method_37("setmetatable(_G, { __index = Bank_Env}); this:Hide(); setmetatable(_G, { __index = BigBank_Env}); this:Hide();");
	}

	// Token: 0x17000842 RID: 2114
	// (set) Token: 0x06002634 RID: 9780 RVA: 0x0001C77E File Offset: 0x0001A97E
	public int Int32_0
	{
		set
		{
			Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, value, 56);
		}
	}

	// Token: 0x06002635 RID: 9781 RVA: 0x0001C799 File Offset: 0x0001A999
	public void method_1()
	{
		this.method_37("if Player:IsInTeam() == 1 then Player:LeaveTeam() elseif Player:IsInRaid() == 1 then Player:LeaveRiad() end");
	}

	// Token: 0x06002636 RID: 9782 RVA: 0x0001C7A6 File Offset: 0x0001A9A6
	public void method_2(int int_1)
	{
		this.method_37("GameProduceLogin:MoveToCharacter(" + int_1.ToString() + ");");
	}

	// Token: 0x06002637 RID: 9783 RVA: 0x0001C7C4 File Offset: 0x0001A9C4
	public void method_3(int int_1)
	{
		this.method_37("QuestFrameMissionComplete(" + int_1.ToString() + ");");
	}

	// Token: 0x06002638 RID: 9784 RVA: 0x0001C7E2 File Offset: 0x0001A9E2
	public void method_4(int int_1, int int_2)
	{
		this.method_37(string.Concat(new string[]
		{
			"QuestFrameOptionClicked(-1,",
			int_1.ToString(),
			", ",
			int_2.ToString(),
			");"
		}));
	}

	// Token: 0x06002639 RID: 9785 RVA: 0x0001C821 File Offset: 0x0001AA21
	public void method_5()
	{
		this.method_37("SelectRole_EnterGame();");
	}

	// Token: 0x0600263A RID: 9786 RVA: 0x0001C82E File Offset: 0x0001AA2E
	public void method_6()
	{
		this.method_37("setmetatable(_G, {__index = TheFireStove_Env }); TheFireStove_FireButton_OnClick();");
	}

	// Token: 0x0600263B RID: 9787 RVA: 0x0001C83B File Offset: 0x0001AA3B
	public void method_7()
	{
		this.method_37("setmetatable(_G, {__index = TheFireStove_Env }); TheFireStove_StoneButton_OnClick();");
	}

	// Token: 0x0600263C RID: 9788 RVA: 0x0001C848 File Offset: 0x0001AA48
	public void method_8()
	{
		this.method_37("setmetatable(_G, { __index = TheFireStove_MessageBox_Env }); TheFireStove_MessageBox_OK_Clicked();");
	}

	// Token: 0x0600263D RID: 9789 RVA: 0x0001C855 File Offset: 0x0001AA55
	public void method_9(int int_1)
	{
		this.method_37("setmetatable(_G, {__index = XingYun_Env }); if this:IsVisible() then setmetatable(_G, {__index = XingYun_Env }); Play_Ani(" + int_1.ToString() + "); end");
	}

	// Token: 0x0600263E RID: 9790 RVA: 0x0001C873 File Offset: 0x0001AA73
	public void method_10(int int_1)
	{
		this.method_37("setmetatable(_G, {__index = LoginLogOn_Env}); LogOn_Region:SetCurrentSelect(" + int_1.ToString() + ");");
	}

	// Token: 0x0600263F RID: 9791 RVA: 0x0001C891 File Offset: 0x0001AA91
	public void method_11()
	{
		this.method_37("DataPool:ReConnect();");
	}

	// Token: 0x06002640 RID: 9792 RVA: 0x0001C89E File Offset: 0x0001AA9E
	public void method_12()
	{
		this.method_37("setmetatable(_G, {__index = LoginSelectServerQuest_Env}); SelectServerQuest_Bn1Click(); LogOn_ExitToSelectServer();");
	}

	// Token: 0x06002641 RID: 9793 RVA: 0x0001C8AB File Offset: 0x0001AAAB
	public void method_13(int int_1)
	{
		this.Int32_0 = int_1;
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, 45, 105);
	}

	// Token: 0x06002642 RID: 9794 RVA: 0x0001C8CE File Offset: 0x0001AACE
	public void method_14()
	{
		this.method_37("PushEvent('TOGLE_MISSION_OUTLINE');");
	}

	// Token: 0x06002643 RID: 9795 RVA: 0x0001C8DB File Offset: 0x0001AADB
	public void method_15()
	{
		this.method_37("AskRet2SelServer();");
	}

	// Token: 0x06002644 RID: 9796 RVA: 0x0001C8E8 File Offset: 0x0001AAE8
	public void method_16()
	{
		this.method_37("Player:CreateTeamSelf();");
	}

	// Token: 0x06002645 RID: 9797 RVA: 0x0001C8F5 File Offset: 0x0001AAF5
	public void method_17()
	{
		this.method_37("OpenWindow('MissionTrack');");
	}

	// Token: 0x06002646 RID: 9798 RVA: 0x0001C902 File Offset: 0x0001AB02
	public void method_18()
	{
		this.method_37("HuoDongRiCheng_next_click();");
	}

	// Token: 0x06002647 RID: 9799 RVA: 0x0001C90F File Offset: 0x0001AB0F
	public void method_19()
	{
		this.method_37("setmetatable(_G, {__index = TextValidate_Env}); TextValidate_BtnCloseClick(); setmetatable(_G, {__index = LoginOverTime_Env}); LoginOverTime_Bn1Click();");
	}

	// Token: 0x06002648 RID: 9800 RVA: 0x00110448 File Offset: 0x0010E648
	public void method_20(int int_1, int int_2)
	{
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, int_1, 57);
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, int_2, 58);
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, 52, 105);
	}

	// Token: 0x06002649 RID: 9801 RVA: 0x0001C91C File Offset: 0x0001AB1C
	public void method_21()
	{
		this.method_37("PushEvent('TOGGLE_YUANBAOSHOP');");
	}

	// Token: 0x0600264A RID: 9802 RVA: 0x0001C929 File Offset: 0x0001AB29
	public void method_22()
	{
		this.class159_0.method_282("setmetatable(_G, {__index = YuanbaoShop_Env}); this:Hide();", false);
	}

	// Token: 0x0600264B RID: 9803 RVA: 0x0001C93C File Offset: 0x0001AB3C
	public void method_23()
	{
		this.method_24();
	}

	// Token: 0x0600264C RID: 9804 RVA: 0x0001C944 File Offset: 0x0001AB44
	public void method_24()
	{
		if (this.class159_0.Class432_0.UInt32_28 == 9U)
		{
			this.method_37("Player:SendReliveMessage_OutGhost();");
		}
	}

	// Token: 0x0600264D RID: 9805 RVA: 0x0001C965 File Offset: 0x0001AB65
	public void method_25()
	{
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, 55, 105);
	}

	// Token: 0x0600264E RID: 9806 RVA: 0x0001C981 File Offset: 0x0001AB81
	public void method_26()
	{
		Class438.PostMessage(this.class159_0.IntPtr_0, Class268.int_17, 56, 105);
	}

	// Token: 0x0600264F RID: 9807 RVA: 0x0001C99D File Offset: 0x0001AB9D
	public void method_27()
	{
		this.method_37("Player:SendReliveMessage_Relive();");
	}

	// Token: 0x06002650 RID: 9808 RVA: 0x001104A4 File Offset: 0x0010E6A4
	public void method_28(string string_0)
	{
		int num = Class426.smethod_43(string_0);
		int num2 = Class426.smethod_43(string_0.Replace(num.ToString() + ",", ""));
		this.method_29((float)num, (float)num2);
	}

	// Token: 0x06002651 RID: 9809 RVA: 0x001104E4 File Offset: 0x0010E6E4
	public void method_29(float float_0, float float_1)
	{
		if (!this.class159_0.Class432_0.Boolean_51 && !this.class159_0.Boolean_27)
		{
			this.method_37(string.Concat(new string[]
			{
				"AutoRunToTarget(",
				((int)Math.Round((double)float_0, 0, MidpointRounding.AwayFromZero)).ToString(),
				",",
				((int)Math.Round((double)float_1, 0, MidpointRounding.AwayFromZero)).ToString(),
				")"
			}));
			return;
		}
	}

	// Token: 0x06002652 RID: 9810 RVA: 0x0001C9AA File Offset: 0x0001ABAA
	public void method_30(int int_1, int int_2)
	{
		this.method_37(string.Concat(new string[]
		{
			"NpcShop:BulkBuyItem(",
			int_1.ToString(),
			",",
			int_2.ToString(),
			",0)"
		}));
	}

	// Token: 0x06002653 RID: 9811 RVA: 0x0001C9E9 File Offset: 0x0001ABE9
	public void method_31(string string_0)
	{
		this.method_35();
		Thread.Sleep(1000);
		this.method_37("local cnt = 0; while true do local name, content = DataPool:GetPlayerMission_Memo(cnt); if string.find(name, '" + string_0.Trim() + "') then DataPool:Mission_Abnegate_Popup(cnt,DataPool:GetPlayerMission_Memo(cnt)); end cnt = cnt + 1; if cnt == 20 then return end end");
		Thread.Sleep(1000);
		this.method_41();
	}

	// Token: 0x06002654 RID: 9812 RVA: 0x0001CA26 File Offset: 0x0001AC26
	public void method_32(string string_0, string string_1)
	{
		this.method_37(string.Concat(new string[]
		{
			"Talk:SendChatMessage('",
			string_0,
			"', '",
			string_1,
			"');"
		}));
	}

	// Token: 0x06002655 RID: 9813 RVA: 0x0001CA59 File Offset: 0x0001AC59
	public void method_33()
	{
		this.method_37("QuestFrameMissionComplete(1);");
	}

	// Token: 0x06002656 RID: 9814 RVA: 0x0001CA66 File Offset: 0x0001AC66
	public void method_34()
	{
		this.method_37("QuestFrameMissionContinue(1);");
	}

	// Token: 0x06002657 RID: 9815 RVA: 0x0001CA73 File Offset: 0x0001AC73
	public void method_35()
	{
		this.method_37("PushEvent('TOGLE_MISSION');");
	}

	// Token: 0x06002658 RID: 9816 RVA: 0x0001CA80 File Offset: 0x0001AC80
	public void method_36()
	{
		this.method_37("setmetatable(_G, {__index = QuestLog_Env}); this:Hide();");
	}

	// Token: 0x06002659 RID: 9817 RVA: 0x0001CA8D File Offset: 0x0001AC8D
	public void method_37(string string_0)
	{
		this.class159_0.method_282(string_0, false);
	}

	// Token: 0x0600265A RID: 9818 RVA: 0x0001CA9C File Offset: 0x0001AC9C
	public void method_38()
	{
		this.class159_0.method_282("PlayerPackage:PackUpPacket(0); PlayerPackage:PackUpPacket(1);", false);
		if (this.class159_0.Class392_0.UInt32_106 == 1U)
		{
			this.class159_0.method_282("setmetatable(_G, {__index = Packet_Temporary_Env}); Packet_Temporary_CleanButtonClk(); ", false);
		}
	}

	// Token: 0x0600265B RID: 9819 RVA: 0x0001CAD3 File Offset: 0x0001ACD3
	public void method_39()
	{
		this.method_37("setmetatable(_G, {__index = PetEquipSuitDepart_Env}); if this:IsVisible() then PetEquipSuitDepart_Buttons_Clicked() end");
	}

	// Token: 0x0600265C RID: 9820 RVA: 0x0001CAE0 File Offset: 0x0001ACE0
	public void method_40()
	{
		this.method_37("setmetatable(_G, {__index = LoginSelectServerQuest_Env}); if this:IsVisible() then SelectServerQuest_Bn1Click() end");
	}

	// Token: 0x0600265D RID: 9821 RVA: 0x0001CAED File Offset: 0x0001ACED
	public void method_41()
	{
		this.method_37("setmetatable(_G, {__index = MessageBox_Self_Env}); if this:IsVisible() then MessageBox_Self_OK_Clicked(); end");
	}

	// Token: 0x0600265E RID: 9822 RVA: 0x0001CAFA File Offset: 0x0001ACFA
	public void method_42()
	{
		this.method_37("setmetatable(_G, { __index = MessageBox_Self2_Env}); if this:IsVisible() then MessageBox_Self2_Ok_Clicked(); end");
	}

	// Token: 0x0600265F RID: 9823 RVA: 0x0001CB07 File Offset: 0x0001AD07
	public void method_43()
	{
		this.method_37("setmetatable(_G, {__index = AcceptBox_Env}); if this:IsVisible() then AcceptBox_OK_Clicked(); end");
	}

	// Token: 0x06002660 RID: 9824 RVA: 0x0001CB14 File Offset: 0x0001AD14
	public void method_44()
	{
		this.method_37("QuestFrameAcceptClicked();");
	}

	// Token: 0x06002661 RID: 9825 RVA: 0x0001CB21 File Offset: 0x0001AD21
	public void method_45()
	{
		this.method_37("setmetatable(_G, {__index = Packet_Env})\r\n                    this:Show()");
	}

	// Token: 0x040019B8 RID: 6584
	private Class159 class159_0;

	// Token: 0x040019B9 RID: 6585
	public int[] int_0 = new int[20];
}
