﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020000BE RID: 190
[ToolboxItem(false)]
public class GControl0 : UserControl, IDisposable
{
	// Token: 0x14000013 RID: 19
	// (add) Token: 0x06000911 RID: 2321 RVA: 0x0003D3A8 File Offset: 0x0003B5A8
	// (remove) Token: 0x06000912 RID: 2322 RVA: 0x0003D3E0 File Offset: 0x0003B5E0
	public event EventHandler Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x1700028E RID: 654
	// (get) Token: 0x06000913 RID: 2323 RVA: 0x00008EB4 File Offset: 0x000070B4
	private int Int32_0
	{
		get
		{
			return this.Font.Height + 2;
		}
	}

	// Token: 0x1700028F RID: 655
	// (get) Token: 0x06000914 RID: 2324 RVA: 0x00008EC3 File Offset: 0x000070C3
	private GClass55 GClass55_0
	{
		get
		{
			return base.Parent as GClass55;
		}
	}

	// Token: 0x17000290 RID: 656
	// (get) Token: 0x06000915 RID: 2325 RVA: 0x00008ED0 File Offset: 0x000070D0
	// (set) Token: 0x06000916 RID: 2326 RVA: 0x00008ED8 File Offset: 0x000070D8
	internal bool Boolean_0 { get; set; }

	// Token: 0x17000291 RID: 657
	// (get) Token: 0x06000917 RID: 2327 RVA: 0x00008EE1 File Offset: 0x000070E1
	// (set) Token: 0x06000918 RID: 2328 RVA: 0x00008EE9 File Offset: 0x000070E9
	public ImageList ImageList_0 { get; set; }

	// Token: 0x17000292 RID: 658
	// (get) Token: 0x06000919 RID: 2329 RVA: 0x00008EF2 File Offset: 0x000070F2
	// (set) Token: 0x0600091A RID: 2330 RVA: 0x00008EFF File Offset: 0x000070FF
	internal int Int32_1
	{
		get
		{
			return this.timer_0.Interval;
		}
		set
		{
			this.timer_0.Interval = value;
		}
	}

	// Token: 0x17000293 RID: 659
	// (get) Token: 0x0600091B RID: 2331 RVA: 0x00008F0D File Offset: 0x0000710D
	// (set) Token: 0x0600091C RID: 2332 RVA: 0x00008F15 File Offset: 0x00007115
	internal int Int32_2 { get; set; }

	// Token: 0x17000294 RID: 660
	// (get) Token: 0x0600091D RID: 2333 RVA: 0x00008F1E File Offset: 0x0000711E
	// (set) Token: 0x0600091E RID: 2334 RVA: 0x00008F26 File Offset: 0x00007126
	internal Size Size_0 { get; set; }

	// Token: 0x17000295 RID: 661
	// (get) Token: 0x0600091F RID: 2335 RVA: 0x00008F2F File Offset: 0x0000712F
	// (set) Token: 0x06000920 RID: 2336 RVA: 0x00008F3C File Offset: 0x0000713C
	internal bool Boolean_1
	{
		get
		{
			return this.toolTip_0.ShowAlways;
		}
		set
		{
			this.toolTip_0.ShowAlways = value;
		}
	}

	// Token: 0x17000296 RID: 662
	// (get) Token: 0x06000921 RID: 2337 RVA: 0x00008F4A File Offset: 0x0000714A
	// (set) Token: 0x06000922 RID: 2338 RVA: 0x00008F52 File Offset: 0x00007152
	public Color Color_0 { get; set; }

	// Token: 0x17000297 RID: 663
	// (get) Token: 0x06000923 RID: 2339 RVA: 0x00008F5B File Offset: 0x0000715B
	// (set) Token: 0x06000924 RID: 2340 RVA: 0x00008F63 File Offset: 0x00007163
	public Color Color_1 { get; set; }

	// Token: 0x17000298 RID: 664
	// (get) Token: 0x06000925 RID: 2341 RVA: 0x00008F6C File Offset: 0x0000716C
	// (set) Token: 0x06000926 RID: 2342 RVA: 0x00008F74 File Offset: 0x00007174
	public int Int32_3
	{
		get
		{
			return this.int_0;
		}
		set
		{
			if (this.int_0 != value)
			{
				this.int_0 = value;
				if (this.eventHandler_0 != null)
				{
					this.eventHandler_0(this, EventArgs.Empty);
				}
			}
		}
	}

	// Token: 0x17000299 RID: 665
	// (get) Token: 0x06000927 RID: 2343 RVA: 0x00008F9F File Offset: 0x0000719F
	// (set) Token: 0x06000928 RID: 2344 RVA: 0x00008FD0 File Offset: 0x000071D0
	public GClass51 GClass51_0
	{
		get
		{
			if (this.Int32_3 >= 0 && this.int_0 < this.list_0.Count)
			{
				return this.list_0[this.int_0];
			}
			return null;
		}
		set
		{
			this.Int32_3 = this.list_0.IndexOf(value);
		}
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x0003D418 File Offset: 0x0003B618
	internal GControl0(FastColoredTextBox fastColoredTextBox_1)
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		base.Font = new Font(FontFamily.GenericSansSerif, 9f);
		this.list_0 = new List<GClass51>();
		base.VerticalScroll.SmallChange = this.Int32_0;
		this.MaximumSize = new Size(base.Size.Width, 180);
		this.toolTip_0.ShowAlways = false;
		this.Int32_1 = 500;
		this.timer_0.Tick += this.timer_0_Tick;
		this.Color_0 = Color.Orange;
		this.Color_1 = Color.Red;
		this.Int32_2 = 3000;
		this.toolTip_0.Popup += this.toolTip_0_Popup;
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
		fastColoredTextBox_1.KeyDown += this.method_6;
		fastColoredTextBox_1.Event_6 += this.method_5;
		fastColoredTextBox_1.Event_13 += this.method_1;
		Form form = fastColoredTextBox_1.FindForm();
		if (form != null)
		{
			form.LocationChanged += this.method_16;
			form.ResizeBegin += this.method_17;
			form.FormClosing += this.method_18;
			form.LostFocus += this.method_19;
		}
		fastColoredTextBox_1.LostFocus += this.method_20;
		fastColoredTextBox_1.Scroll += this.method_21;
		base.VisibleChanged += this.GControl0_VisibleChanged;
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x0003D5DC File Offset: 0x0003B7DC
	private void toolTip_0_Popup(object sender, PopupEventArgs e)
	{
		if (this.Size_0.Height > 0 && this.Size_0.Width > 0)
		{
			e.ToolTipSize = this.Size_0;
		}
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x0003D618 File Offset: 0x0003B818
	protected virtual void Dispose(bool disposing)
	{
		if (this.toolTip_0 != null)
		{
			this.toolTip_0.Popup -= this.toolTip_0_Popup;
			this.toolTip_0.Dispose();
		}
		if (this.fastColoredTextBox_0 != null)
		{
			this.fastColoredTextBox_0.KeyDown -= this.method_6;
			this.fastColoredTextBox_0.Event_13 -= this.method_1;
			this.fastColoredTextBox_0.Event_6 -= this.method_5;
		}
		if (this.timer_0 != null)
		{
			this.timer_0.Stop();
			this.timer_0.Tick -= this.timer_0_Tick;
			this.timer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x00008FE4 File Offset: 0x000071E4
	private void method_0()
	{
		if (this.GClass55_0 != null && !this.GClass55_0.IsDisposed)
		{
			this.GClass55_0.method_1();
		}
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x0003D6D8 File Offset: 0x0003B8D8
	private void method_1(object sender, KeyPressEventArgs e)
	{
		bool flag = e.KeyChar == '\b' || e.KeyChar == 'ÿ';
		if (this.GClass55_0.Visible && !flag)
		{
			this.method_4(false);
			return;
		}
		this.method_2(this.timer_0);
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x00009006 File Offset: 0x00007206
	private void timer_0_Tick(object sender, EventArgs e)
	{
		this.timer_0.Stop();
		this.method_4(false);
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x0000901A File Offset: 0x0000721A
	private void method_2(System.Windows.Forms.Timer timer_1)
	{
		timer_1.Stop();
		timer_1.Start();
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x00009028 File Offset: 0x00007228
	internal void method_3()
	{
		this.method_4(false);
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x0003D724 File Offset: 0x0003B924
	internal void method_4(bool bool_1)
	{
		if (!this.GClass55_0.Enabled)
		{
			this.GClass55_0.method_1();
			return;
		}
		this.list_0.Clear();
		this.Int32_3 = 0;
		base.VerticalScroll.Value = 0;
		base.AutoScrollMinSize -= new Size(1, 0);
		base.AutoScrollMinSize += new Size(1, 0);
		GClass86 gclass = this.fastColoredTextBox_0.GClass86_5.method_43(this.GClass55_0.String_0);
		string string_ = gclass.String_1;
		Point position = this.fastColoredTextBox_0.method_95(gclass.GStruct2_1);
		position.Offset(2, this.fastColoredTextBox_0.Int32_2);
		if (bool_1 || (string_.Length >= this.GClass55_0.Int32_0 && this.fastColoredTextBox_0.GClass86_5.Boolean_2 && (GStruct2.smethod_4(this.fastColoredTextBox_0.GClass86_5.GStruct2_0, gclass.GStruct2_0) || string_.Length == 0)))
		{
			this.GClass55_0.GClass86_0 = gclass;
			bool flag = false;
			foreach (GClass51 gclass2 in this.ienumerable_0)
			{
				gclass2.GClass55_0 = this.GClass55_0;
				GEnum10 genum = gclass2.GClass51.\u206A\u200E\u206A\u206E\u200F\u206C\u202D\u200F\u206D\u200E\u200C\u202D\u200D\u202E\u206C\u200B\u200E\u206F\u200D\u202D\u202E\u206A\u206D\u202A\u206E\u202B\u206F\u202D\u200B\u200B\u206D\u206D\u206D\u202D\u202A\u200F\u200C\u202A\u206F\u200D\u202E(string_);
				if (genum != GEnum10.Hidden)
				{
					this.list_0.Add(gclass2);
				}
				if (genum == GEnum10.VisibleAndSelected && !flag)
				{
					flag = true;
					this.Int32_3 = this.list_0.Count - 1;
				}
			}
			if (flag)
			{
				this.method_7();
				this.method_12();
			}
		}
		if (this.Int32_4 > 0)
		{
			if (!this.GClass55_0.Visible)
			{
				CancelEventArgs cancelEventArgs = new CancelEventArgs();
				this.GClass55_0.method_0(cancelEventArgs);
				if (!cancelEventArgs.Cancel)
				{
					this.GClass55_0.Show(this.fastColoredTextBox_0, position);
				}
			}
			this.method_12();
			base.Invalidate();
			return;
		}
		this.GClass55_0.method_1();
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x0003D930 File Offset: 0x0003BB30
	private void method_5(object sender, EventArgs e)
	{
		if (this.GClass55_0.Visible)
		{
			bool flag = false;
			if (!this.fastColoredTextBox_0.GClass86_5.Boolean_2)
			{
				flag = true;
			}
			else if (!this.GClass55_0.GClass86_0.method_0(this.fastColoredTextBox_0.GClass86_5.GStruct2_0))
			{
				if (this.fastColoredTextBox_0.GClass86_5.GStruct2_0.int_1 == this.GClass55_0.GClass86_0.GStruct2_1.int_1 && this.fastColoredTextBox_0.GClass86_5.GStruct2_0.int_0 == this.GClass55_0.GClass86_0.GStruct2_1.int_0 + 1)
				{
					if (!Regex.IsMatch(this.fastColoredTextBox_0.GClass86_5.Char_1.ToString(), this.GClass55_0.String_0))
					{
						flag = true;
					}
				}
				else
				{
					flag = true;
				}
			}
			if (flag)
			{
				this.GClass55_0.method_1();
			}
		}
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x0003DA28 File Offset: 0x0003BC28
	private void method_6(object sender, KeyEventArgs e)
	{
		FastColoredTextBox fastColoredTextBox = sender as FastColoredTextBox;
		if (this.GClass55_0.Visible && this.method_10(e.KeyCode, e.Modifiers))
		{
			e.Handled = true;
		}
		if (!this.GClass55_0.Visible)
		{
			if (fastColoredTextBox.GClass79_0.ContainsKey(e.KeyData) && fastColoredTextBox.GClass79_0[e.KeyData] == FCTBAction.AutocompleteMenu)
			{
				this.method_3();
				e.Handled = true;
				return;
			}
			if (e.KeyCode == Keys.Escape && this.timer_0.Enabled)
			{
				this.timer_0.Stop();
			}
		}
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x0003DAC8 File Offset: 0x0003BCC8
	private void method_7()
	{
		if (this.int_2 == this.list_0.Count)
		{
			return;
		}
		int num = this.Int32_0 * this.list_0.Count + 1;
		base.Height = Math.Min(num, this.MaximumSize.Height);
		this.GClass55_0.method_2();
		base.AutoScrollMinSize = new Size(0, num);
		this.int_2 = this.list_0.Count;
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x0003DB44 File Offset: 0x0003BD44
	protected virtual void OnPaint(PaintEventArgs e)
	{
		this.method_7();
		int int32_ = this.Int32_0;
		int val = base.VerticalScroll.Value / int32_ - 1;
		int num = (base.VerticalScroll.Value + base.ClientSize.Height) / int32_ + 1;
		int num2 = Math.Max(val, 0);
		num = Math.Min(num, this.list_0.Count);
		int num3 = 0;
		int num4 = 18;
		for (int i = num2; i < num; i++)
		{
			num3 = i * int32_ - base.VerticalScroll.Value;
			GClass51 gclass = this.list_0[i];
			if (gclass.Color_1 != Color.Transparent)
			{
				using (SolidBrush solidBrush = new SolidBrush(gclass.Color_1))
				{
					e.Graphics.FillRectangle(solidBrush, 1, num3, base.ClientSize.Width - 1 - 1, int32_ - 1);
				}
			}
			if (this.ImageList_0 != null && this.list_0[i].int_0 >= 0)
			{
				e.Graphics.DrawImage(this.ImageList_0.Images[gclass.int_0], 1, num3);
			}
			if (i == this.Int32_3)
			{
				using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Point(0, num3 - 3), new Point(0, num3 + int32_), Color.Transparent, this.Color_0))
				{
					using (Pen pen = new Pen(this.Color_0))
					{
						e.Graphics.FillRectangle(linearGradientBrush, num4, num3, base.ClientSize.Width - 1 - num4, int32_ - 1);
						e.Graphics.DrawRectangle(pen, num4, num3, base.ClientSize.Width - 1 - num4, int32_ - 1);
					}
				}
			}
			if (i == this.int_1)
			{
				using (Pen pen2 = new Pen(this.Color_1))
				{
					e.Graphics.DrawRectangle(pen2, num4, num3, base.ClientSize.Width - 1 - num4, int32_ - 1);
				}
			}
			using (SolidBrush solidBrush2 = new SolidBrush((gclass.Color_0 != Color.Transparent) ? gclass.Color_0 : this.ForeColor))
			{
				e.Graphics.DrawString(gclass.ToString(), this.Font, solidBrush2, (float)num4, (float)num3);
			}
		}
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x00009031 File Offset: 0x00007231
	protected virtual void OnScroll(ScrollEventArgs se)
	{
		base.OnScroll(se);
		base.Invalidate();
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x00009040 File Offset: 0x00007240
	protected virtual void OnMouseClick(MouseEventArgs e)
	{
		base.OnMouseClick(e);
		if (e.Button == MouseButtons.Left)
		{
			this.Int32_3 = this.method_9(e.Location);
			this.method_12();
			base.Invalidate();
		}
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x00009074 File Offset: 0x00007274
	protected virtual void OnMouseDoubleClick(MouseEventArgs e)
	{
		base.OnMouseDoubleClick(e);
		this.Int32_3 = this.method_9(e.Location);
		base.Invalidate();
		this.vmethod_0();
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x0003DDF8 File Offset: 0x0003BFF8
	internal virtual void vmethod_0()
	{
		if (this.Int32_3 >= 0 && this.Int32_3 < this.list_0.Count)
		{
			this.fastColoredTextBox_0.GClass99_0.GClass59_0.method_4();
			try
			{
				GClass51 gclass51_ = this.GClass51_0;
				GEventArgs6 geventArgs = new GEventArgs6
				{
					GClass51_0 = gclass51_,
					Int32_0 = this.Int32_3
				};
				this.GClass55_0.method_4(geventArgs);
				if (geventArgs.Boolean_0)
				{
					this.Int32_3 = geventArgs.Int32_0;
					base.Invalidate();
				}
				else
				{
					if (!geventArgs.Boolean_1)
					{
						GClass86 gclass86_ = this.GClass55_0.GClass86_0;
						this.method_8(gclass51_, gclass86_);
					}
					this.GClass55_0.method_1();
					GEventArgs7 geventArgs7_ = new GEventArgs7
					{
						GClass51_0 = gclass51_,
						FastColoredTextBox_0 = this.GClass55_0.GClass86_0.fastColoredTextBox_0
					};
					gclass51_.GClass51.\u202E\u200D\u206F\u200D\u202B\u202A\u202B\u200B\u206B\u202B\u206A\u202A\u206E\u200B\u206D\u206A\u200F\u202C\u200B\u206F\u200B\u206F\u202B\u202B\u206F\u202D\u206D\u206B\u202C\u200D\u202B\u202D\u202C\u200D\u206A\u206F\u206B\u202D\u200C\u202E(this.GClass55_0, geventArgs7_);
					this.GClass55_0.method_5(geventArgs7_);
				}
			}
			finally
			{
				this.fastColoredTextBox_0.GClass99_0.GClass59_0.method_3();
			}
			return;
		}
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x0003DF10 File Offset: 0x0003C110
	private void method_8(GClass51 gclass51_0, GClass86 gclass86_0)
	{
		string string_ = gclass51_0.GClass51.\u200F\u206C\u202D\u206E\u206B\u200F\u202C\u202E\u200C\u206A\u200E\u206F\u200F\u206A\u200D\u202A\u202B\u206C\u202C\u206D\u202C\u200D\u206E\u206B\u202D\u202A\u206A\u206E\u206C\u206B\u206C\u202A\u200C\u200D\u200F\u206A\u206A\u206F\u206A\u206F\u202E();
		FastColoredTextBox fastColoredTextBox = gclass86_0.fastColoredTextBox_0;
		fastColoredTextBox.method_108();
		fastColoredTextBox.GClass99_0.GClass59_0.vmethod_0(new GClass69(fastColoredTextBox.GClass99_0));
		if (fastColoredTextBox.GClass86_5.Boolean_0)
		{
			GStruct2 gstruct2_ = fastColoredTextBox.GClass86_5.GStruct2_0;
			GStruct2 gstruct2_2 = fastColoredTextBox.GClass86_5.GStruct2_1;
			gstruct2_.int_0 = gclass86_0.GStruct2_0.int_0;
			gstruct2_2.int_0 = gclass86_0.GStruct2_1.int_0;
			fastColoredTextBox.GClass86_5.GStruct2_0 = gstruct2_;
			fastColoredTextBox.GClass86_5.GStruct2_1 = gstruct2_2;
		}
		else
		{
			fastColoredTextBox.GClass86_5.GStruct2_0 = gclass86_0.GStruct2_0;
			fastColoredTextBox.GClass86_5.GStruct2_1 = gclass86_0.GStruct2_1;
		}
		fastColoredTextBox.vmethod_20(string_);
		fastColoredTextBox.GClass99_0.GClass59_0.vmethod_0(new GClass69(fastColoredTextBox.GClass99_0));
		fastColoredTextBox.method_109();
		fastColoredTextBox.Focus();
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x0000909B File Offset: 0x0000729B
	private int method_9(Point point_0)
	{
		return (point_0.Y + base.VerticalScroll.Value) / this.Int32_0;
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x000090B7 File Offset: 0x000072B7
	protected virtual bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		this.method_10(keyData, Keys.None);
		return base.ProcessCmdKey(ref msg, keyData);
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x0003E000 File Offset: 0x0003C200
	private bool method_10(Keys keys_0, Keys keys_1)
	{
		if (keys_1 == Keys.None)
		{
			if (keys_0 <= Keys.Escape)
			{
				if (keys_0 != Keys.Tab)
				{
					if (keys_0 == Keys.Return)
					{
						this.vmethod_0();
						return true;
					}
					if (keys_0 == Keys.Escape)
					{
						this.GClass55_0.method_1();
						return true;
					}
				}
				else if (this.Boolean_0)
				{
					this.vmethod_0();
					return true;
				}
			}
			else if (keys_0 <= Keys.Next)
			{
				if (keys_0 == Keys.Prior)
				{
					this.method_11(-10);
					return true;
				}
				if (keys_0 == Keys.Next)
				{
					this.method_11(10);
					return true;
				}
			}
			else
			{
				if (keys_0 == Keys.Up)
				{
					this.method_11(-1);
					return true;
				}
				if (keys_0 == Keys.Down)
				{
					this.method_11(1);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x000090CA File Offset: 0x000072CA
	public void method_11(int int_4)
	{
		this.Int32_3 = Math.Max(0, Math.Min(this.Int32_3 + int_4, this.list_0.Count - 1));
		this.method_12();
		base.Invalidate();
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x0003E090 File Offset: 0x0003C290
	private void method_12()
	{
		if (this.GClass51_0 != null)
		{
			this.method_13(this.GClass51_0);
		}
		int num = this.Int32_3 * this.Int32_0 - base.VerticalScroll.Value;
		if (num < 0)
		{
			base.VerticalScroll.Value = this.Int32_3 * this.Int32_0;
		}
		if (num > base.ClientSize.Height - this.Int32_0)
		{
			base.VerticalScroll.Value = Math.Min(base.VerticalScroll.Maximum, this.Int32_3 * this.Int32_0 - base.ClientSize.Height + this.Int32_0);
		}
		base.AutoScrollMinSize -= new Size(1, 0);
		base.AutoScrollMinSize += new Size(1, 0);
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x0003E16C File Offset: 0x0003C36C
	private void method_13(GClass51 gclass51_0)
	{
		string string_ = gclass51_0.String_0;
		string string_2 = gclass51_0.String_1;
		if (string.IsNullOrEmpty(string_))
		{
			this.toolTip_0.ToolTipTitle = null;
			this.toolTip_0.SetToolTip(this, null);
			return;
		}
		if (base.Parent != null)
		{
			IWin32Window window = base.Parent ?? this;
			Point point;
			if (base.PointToScreen(base.Location).X + this.Size_0.Width + 105 < Screen.FromControl(base.Parent).WorkingArea.Right)
			{
				point = new Point(base.Right + 5, 0);
			}
			else
			{
				point = new Point(base.Left - 105 - this.MaximumSize.Width, 0);
			}
			if (string.IsNullOrEmpty(string_2))
			{
				this.toolTip_0.ToolTipTitle = null;
				this.toolTip_0.Show(string_, window, point.X, point.Y, this.Int32_2);
				return;
			}
			this.toolTip_0.ToolTipTitle = string_;
			this.toolTip_0.Show(string_2, window, point.X, point.Y, this.Int32_2);
		}
	}

	// Token: 0x1700029A RID: 666
	// (get) Token: 0x06000941 RID: 2369 RVA: 0x000090FE File Offset: 0x000072FE
	public int Int32_4
	{
		get
		{
			return this.list_0.Count;
		}
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x0003E29C File Offset: 0x0003C49C
	public void method_14(ICollection<string> icollection_0)
	{
		List<GClass51> list = new List<GClass51>(icollection_0.Count);
		foreach (string string_ in icollection_0)
		{
			list.Add(new GClass51(string_));
		}
		this.method_15(list);
	}

	// Token: 0x06000943 RID: 2371 RVA: 0x0000910B File Offset: 0x0000730B
	public void method_15(IEnumerable<GClass51> ienumerable_1)
	{
		this.ienumerable_0 = ienumerable_1;
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x00009114 File Offset: 0x00007314
	[CompilerGenerated]
	private void method_16(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x00009114 File Offset: 0x00007314
	[CompilerGenerated]
	private void method_17(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x00009114 File Offset: 0x00007314
	[CompilerGenerated]
	private void method_18(object sender, FormClosingEventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x00009114 File Offset: 0x00007314
	[CompilerGenerated]
	private void method_19(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x0000911C File Offset: 0x0000731C
	[CompilerGenerated]
	private void method_20(object sender, EventArgs e)
	{
		if (this.GClass55_0 != null && !this.GClass55_0.IsDisposed && !this.GClass55_0.Focused)
		{
			this.method_0();
		}
	}

	// Token: 0x06000949 RID: 2377 RVA: 0x00009114 File Offset: 0x00007314
	[CompilerGenerated]
	private void method_21(object sender, ScrollEventArgs e)
	{
		this.method_0();
	}

	// Token: 0x0600094A RID: 2378 RVA: 0x00009146 File Offset: 0x00007346
	[CompilerGenerated]
	private void GControl0_VisibleChanged(object sender, EventArgs e)
	{
		if (base.Visible)
		{
			this.method_12();
		}
	}

	// Token: 0x04000496 RID: 1174
	[CompilerGenerated]
	private EventHandler eventHandler_0;

	// Token: 0x04000497 RID: 1175
	internal List<GClass51> list_0;

	// Token: 0x04000498 RID: 1176
	private IEnumerable<GClass51> ienumerable_0 = new List<GClass51>();

	// Token: 0x04000499 RID: 1177
	private int int_0;

	// Token: 0x0400049A RID: 1178
	private int int_1 = -1;

	// Token: 0x0400049B RID: 1179
	private int int_2;

	// Token: 0x0400049C RID: 1180
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x0400049D RID: 1181
	internal ToolTip toolTip_0 = new ToolTip();

	// Token: 0x0400049E RID: 1182
	private System.Windows.Forms.Timer timer_0 = new System.Windows.Forms.Timer();

	// Token: 0x0400049F RID: 1183
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040004A0 RID: 1184
	[CompilerGenerated]
	private ImageList imageList_0;

	// Token: 0x040004A1 RID: 1185
	[CompilerGenerated]
	private int int_3;

	// Token: 0x040004A2 RID: 1186
	[CompilerGenerated]
	private Size size_0;

	// Token: 0x040004A3 RID: 1187
	[CompilerGenerated]
	private Color color_0;

	// Token: 0x040004A4 RID: 1188
	[CompilerGenerated]
	private Color color_1;
}
