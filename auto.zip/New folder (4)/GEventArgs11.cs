﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000E8 RID: 232
public class GEventArgs11 : EventArgs
{
	// Token: 0x06000C80 RID: 3200 RVA: 0x0000B060 File Offset: 0x00009260
	public GEventArgs11(GClass86 gclass86_1)
	{
		this.GClass86_0 = gclass86_1;
	}

	// Token: 0x1700034A RID: 842
	// (get) Token: 0x06000C81 RID: 3201 RVA: 0x0000B06F File Offset: 0x0000926F
	// (set) Token: 0x06000C82 RID: 3202 RVA: 0x0000B077 File Offset: 0x00009277
	public GClass86 GClass86_0 { get; set; }

	// Token: 0x040005BD RID: 1469
	[CompilerGenerated]
	private GClass86 gclass86_0;
}
