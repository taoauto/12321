﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;

// Token: 0x02000103 RID: 259
internal class Class104 : UITypeEditor
{
	// Token: 0x06000D55 RID: 3413 RVA: 0x0000B975 File Offset: 0x00009B75
	public virtual UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
	{
		return UITypeEditorEditStyle.Modal;
	}

	// Token: 0x06000D56 RID: 3414 RVA: 0x0004F904 File Offset: 0x0004DB04
	public virtual object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
	{
		if (provider != null && (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService)) != null)
		{
			HotkeysEditorForm hotkeysEditorForm = new HotkeysEditorForm(GClass79.smethod_0(value as string));
			if (hotkeysEditorForm.ShowDialog() == DialogResult.OK)
			{
				value = hotkeysEditorForm.method_2().ToString();
			}
		}
		return value;
	}
}
