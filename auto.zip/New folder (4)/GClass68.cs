﻿using System;
using System.Collections.Generic;

// Token: 0x020000D4 RID: 212
public class GClass68 : GClass61
{
	// Token: 0x060009D9 RID: 2521 RVA: 0x00009682 File Offset: 0x00007882
	public GClass68(GClass61 gclass61_1) : base(gclass61_1.gclass99_0)
	{
		this.gclass61_0 = gclass61_1;
		this.gclass86_0 = this.gclass99_0.FastColoredTextBox_0.GClass86_5.method_6();
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x0004012C File Offset: 0x0003E32C
	public override void \u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E()
	{
		this.list_0.Clear();
		GClass86 gclass = this.gclass86_0.method_6();
		int num = -1;
		int int_ = gclass.GStruct2_0.int_1;
		int int_2 = gclass.GStruct2_1.int_1;
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0 = false;
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.method_38();
		this.gclass99_0.FastColoredTextBox_0.method_87();
		this.gclass99_0.FastColoredTextBox_0.bool_0 = false;
		try
		{
			if (this.gclass61_0 is GClass63)
			{
				this.method_0(ref num, (this.gclass61_0 as GClass63).string_0);
			}
			else if (this.gclass61_0 is GClass62 && (this.gclass61_0 as GClass62).char_0 != '\0' && (this.gclass61_0 as GClass62).char_0 != '\b')
			{
				this.method_0(ref num, (this.gclass61_0 as GClass62).char_0.ToString());
			}
			else
			{
				this.method_1(ref num);
			}
		}
		catch (ArgumentOutOfRangeException)
		{
		}
		finally
		{
			this.gclass99_0.FastColoredTextBox_0.bool_0 = true;
			this.gclass99_0.FastColoredTextBox_0.method_88();
			this.gclass99_0.FastColoredTextBox_0.GClass86_5 = this.gclass86_0;
			if (num >= 0)
			{
				this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(num, int_);
				this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1 = new GStruct2(num, int_2);
			}
			this.gclass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0 = true;
			this.gclass99_0.FastColoredTextBox_0.GClass86_5.method_39();
		}
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x000402FC File Offset: 0x0003E4FC
	private void method_0(ref int int_0, string string_0)
	{
		string[] array = string_0.Split(new char[]
		{
			'\n'
		});
		int num = 0;
		foreach (GClass86 gclass in this.gclass86_0.method_52(true))
		{
			GClass81 gclass2 = this.gclass99_0.FastColoredTextBox_0[gclass.GStruct2_0.int_1];
			if (!GStruct2.smethod_2(gclass.GStruct2_1, gclass.GStruct2_0) || gclass2.Int32_2 != gclass2.Count)
			{
				string text = array[num % array.Length];
				if (GStruct2.smethod_2(gclass.GStruct2_1, gclass.GStruct2_0) && text != "")
				{
					text = new string(' ', gclass.GStruct2_0.int_0 - gclass.GStruct2_1.int_0) + text;
					gclass.GStruct2_0 = gclass.GStruct2_1;
				}
				this.gclass99_0.FastColoredTextBox_0.GClass86_5 = gclass;
				GClass63 gclass3 = new GClass63(this.gclass99_0, text);
				gclass3.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
				if (this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1.int_0 > int_0)
				{
					int_0 = this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1.int_0;
				}
				this.list_0.Add(gclass3);
			}
			num++;
		}
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00040488 File Offset: 0x0003E688
	private void method_1(ref int int_0)
	{
		foreach (GClass86 gclass86_ in this.gclass86_0.method_52(false))
		{
			this.gclass99_0.FastColoredTextBox_0.GClass86_5 = gclass86_;
			GClass61 gclass = this.gclass61_0.GClass61.\u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E();
			gclass.GClass60.\u202E\u202D\u202E\u206E\u202C\u200B\u202E\u206D\u200F\u206E\u206B\u206B\u200B\u200F\u206E\u202C\u200F\u202D\u206E\u200C\u202E\u206C\u206E\u206D\u202C\u200E\u206A\u202E\u206B\u202C\u202E\u202B\u200D\u202B\u200C\u200F\u206C\u206B\u200D\u206C\u202E();
			if (this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1.int_0 > int_0)
			{
				int_0 = this.gclass99_0.FastColoredTextBox_0.GClass86_5.GStruct2_1.int_0;
			}
			this.list_0.Add(gclass);
		}
	}

	// Token: 0x060009DD RID: 2525 RVA: 0x00040540 File Offset: 0x0003E740
	public override void \u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E()
	{
		this.gclass99_0.FastColoredTextBox_0.method_87();
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.method_38();
		try
		{
			for (int i = this.list_0.Count - 1; i >= 0; i--)
			{
				this.list_0[i].GClass61.\u202B\u206D\u206E\u200B\u202B\u206A\u202B\u200C\u206D\u206E\u206A\u202D\u206D\u202B\u206B\u200B\u202E\u202A\u200B\u202B\u206C\u206B\u202E\u200B\u202D\u202C\u200D\u202D\u200E\u202A\u200B\u206E\u200D\u206D\u206D\u202B\u200E\u206D\u206F\u202E\u202E();
			}
		}
		finally
		{
			this.gclass99_0.FastColoredTextBox_0.GClass86_5.method_39();
			this.gclass99_0.FastColoredTextBox_0.method_88();
		}
		this.gclass99_0.FastColoredTextBox_0.GClass86_5 = this.gclass86_0.method_6();
		this.gclass99_0.FastColoredTextBox_0.vmethod_56(this.gclass86_0);
		this.gclass99_0.FastColoredTextBox_0.vmethod_58();
		this.gclass99_0.FastColoredTextBox_0.GClass86_5.Boolean_0 = true;
	}

	// Token: 0x060009DE RID: 2526 RVA: 0x000096BD File Offset: 0x000078BD
	public override GClass61 \u202C\u206E\u206F\u202C\u206A\u206B\u200B\u206C\u206A\u202C\u200D\u202E\u206E\u200F\u202B\u202D\u200E\u206E\u206A\u206C\u206D\u202E\u200E\u200C\u200C\u200D\u206B\u200B\u206F\u200D\u206D\u200B\u206B\u202D\u200D\u202C\u200B\u202B\u202D\u202C\u202E()
	{
		throw new NotImplementedException();
	}

	// Token: 0x040004D9 RID: 1241
	private GClass61 gclass61_0;

	// Token: 0x040004DA RID: 1242
	private GClass86 gclass86_0;

	// Token: 0x040004DB RID: 1243
	private List<GClass61> list_0 = new List<GClass61>();
}
