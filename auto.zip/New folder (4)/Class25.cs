﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

// Token: 0x02000045 RID: 69
internal abstract class Class25
{
	// Token: 0x060002F5 RID: 757 RVA: 0x00004D75 File Offset: 0x00002F75
	protected Class25(Version version_1, NameValueCollection nameValueCollection_1)
	{
		this.version_0 = version_1;
		this.nameValueCollection_0 = nameValueCollection_1;
	}

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060002F6 RID: 758 RVA: 0x00029BD0 File Offset: 0x00027DD0
	public string String_0
	{
		get
		{
			if (this.byte_0 != null && (long)this.byte_0.Length != 0L)
			{
				Encoding encoding = null;
				string text = this.nameValueCollection_0["Content-Type"];
				if (text != null && text.Length > 0)
				{
					encoding = Class78.smethod_17(text);
				}
				return (encoding ?? Encoding.UTF8).GetString(this.byte_0);
			}
			return string.Empty;
		}
	}

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060002F7 RID: 759 RVA: 0x00004D8B File Offset: 0x00002F8B
	public NameValueCollection NameValueCollection_0
	{
		get
		{
			return this.nameValueCollection_0;
		}
	}

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060002F8 RID: 760 RVA: 0x00004D93 File Offset: 0x00002F93
	public Version Version_0
	{
		get
		{
			return this.version_0;
		}
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x00029C30 File Offset: 0x00027E30
	private static byte[] smethod_0(Stream stream_0, string string_1)
	{
		long num;
		if (!long.TryParse(string_1, out num))
		{
			throw new ArgumentException("Cannot be parsed.", "length");
		}
		if (num < 0L)
		{
			throw new ArgumentOutOfRangeException("length", "Less than zero.");
		}
		if (num > 1024L)
		{
			return stream_0.smethod_55(num, 1024);
		}
		if (num <= 0L)
		{
			return null;
		}
		return stream_0.smethod_54((int)num);
	}

	// Token: 0x060002FA RID: 762 RVA: 0x00029C94 File Offset: 0x00027E94
	private static string[] smethod_1(Stream stream_0, int int_1)
	{
		Class25.Class28 @class = new Class25.Class28();
		@class.list_0 = new List<byte>();
		@class.int_0 = 0;
		Action<int> action_ = new Action<int>(@class.method_0);
		bool flag = false;
		while (@class.int_0 < int_1)
		{
			if (stream_0.ReadByte().smethod_28('\r', action_) && stream_0.ReadByte().smethod_28('\n', action_) && stream_0.ReadByte().smethod_28('\r', action_) && stream_0.ReadByte().smethod_28('\n', action_))
			{
				flag = true;
				IL_76:
				if (!flag)
				{
					throw new GException3("The length of header part is greater than the max length.");
				}
				return Encoding.UTF8.GetString(@class.list_0.ToArray()).Replace("\r\n ", " ").Replace("\r\n\t", " ").Split(new string[]
				{
					"\r\n"
				}, StringSplitOptions.RemoveEmptyEntries);
			}
		}
		goto IL_76;
	}

	// Token: 0x060002FB RID: 763 RVA: 0x00029D6C File Offset: 0x00027F6C
	protected static T smethod_2<T>(Stream stream_0, Func<string[], T> func_0, int int_1) where T : Class25
	{
		Class25.Class29<T> @class = new Class25.Class29<T>();
		@class.stream_0 = stream_0;
		@class.bool_0 = false;
		Timer timer = new Timer(new TimerCallback(@class.method_0), null, int_1, -1);
		T t = default(T);
		Exception ex = null;
		try
		{
			t = func_0(Class25.smethod_1(@class.stream_0, 8192));
			string text = t.NameValueCollection_0["Content-Length"];
			if (text != null && text.Length > 0)
			{
				t.byte_0 = Class25.smethod_0(@class.stream_0, text);
			}
		}
		catch (Exception ex)
		{
		}
		finally
		{
			timer.Change(-1, -1);
			timer.Dispose();
		}
		string text2 = @class.bool_0 ? "A timeout has occurred while reading an HTTP request/response." : ((ex != null) ? "An exception has occurred while reading an HTTP request/response." : null);
		if (text2 != null)
		{
			throw new GException3(text2, ex);
		}
		return t;
	}

	// Token: 0x060002FC RID: 764 RVA: 0x00004D9B File Offset: 0x00002F9B
	public byte[] method_0()
	{
		return Encoding.UTF8.GetBytes(this.ToString());
	}

	// Token: 0x040001B4 RID: 436
	private NameValueCollection nameValueCollection_0;

	// Token: 0x040001B5 RID: 437
	private const int int_0 = 8192;

	// Token: 0x040001B6 RID: 438
	private Version version_0;

	// Token: 0x040001B7 RID: 439
	internal byte[] byte_0;

	// Token: 0x040001B8 RID: 440
	protected const string string_0 = "\r\n";

	// Token: 0x02000046 RID: 70
	[CompilerGenerated]
	private sealed class Class28
	{
		// Token: 0x060002FE RID: 766 RVA: 0x00029E5C File Offset: 0x0002805C
		internal void method_0(int int_1)
		{
			if (int_1 == -1)
			{
				throw new EndOfStreamException("The header cannot be read from the data source.");
			}
			this.list_0.Add((byte)int_1);
			int num = this.int_0;
			this.int_0 = num + 1;
		}

		// Token: 0x040001B9 RID: 441
		public List<byte> list_0;

		// Token: 0x040001BA RID: 442
		public int int_0;
	}

	// Token: 0x02000047 RID: 71
	[CompilerGenerated]
	private sealed class Class29<T> where T : Class25
	{
		// Token: 0x06000300 RID: 768 RVA: 0x00004DAD File Offset: 0x00002FAD
		internal void method_0(object object_0)
		{
			this.bool_0 = true;
			this.stream_0.Close();
		}

		// Token: 0x040001BB RID: 443
		public bool bool_0;

		// Token: 0x040001BC RID: 444
		public Stream stream_0;
	}
}
