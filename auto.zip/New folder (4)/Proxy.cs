﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200015B RID: 347
internal class Proxy : UserControl
{
	// Token: 0x06001073 RID: 4211 RVA: 0x0005B3B4 File Offset: 0x000595B4
	public Proxy()
	{
		this.Text = "Proxy";
		this.InitializeComponent();
		this.Boolean_0 = Class144.bool_0;
		this.String_0 = Class144.string_1;
		this.Int32_0 = Class144.int_5;
		this.Boolean_1 = Class144.bool_1;
		this.String_1 = Class144.string_2;
		this.String_2 = Class144.string_3;
		this.String_3 = Class144.string_4;
		this.method_0();
	}

	// Token: 0x17000438 RID: 1080
	// (get) Token: 0x06001074 RID: 4212 RVA: 0x0000D559 File Offset: 0x0000B759
	// (set) Token: 0x06001075 RID: 4213 RVA: 0x0000D566 File Offset: 0x0000B766
	public bool Boolean_0
	{
		get
		{
			return this.chkUseProxy.Checked;
		}
		set
		{
			this.chkUseProxy.Checked = value;
		}
	}

	// Token: 0x17000439 RID: 1081
	// (get) Token: 0x06001076 RID: 4214 RVA: 0x0000D574 File Offset: 0x0000B774
	// (set) Token: 0x06001077 RID: 4215 RVA: 0x0000D581 File Offset: 0x0000B781
	public string String_0
	{
		get
		{
			return this.txtProxtAddress.Text;
		}
		set
		{
			this.txtProxtAddress.Text = value;
		}
	}

	// Token: 0x1700043A RID: 1082
	// (get) Token: 0x06001078 RID: 4216 RVA: 0x0000D58F File Offset: 0x0000B78F
	// (set) Token: 0x06001079 RID: 4217 RVA: 0x0000D5A1 File Offset: 0x0000B7A1
	public int Int32_0
	{
		get
		{
			return (int)this.numProxyPort.Value;
		}
		set
		{
			this.numProxyPort.Value = value;
		}
	}

	// Token: 0x1700043B RID: 1083
	// (get) Token: 0x0600107A RID: 4218 RVA: 0x0000D5B4 File Offset: 0x0000B7B4
	// (set) Token: 0x0600107B RID: 4219 RVA: 0x0000D5C1 File Offset: 0x0000B7C1
	public bool Boolean_1
	{
		get
		{
			return this.chkBypass.Checked;
		}
		set
		{
			this.chkBypass.Checked = value;
		}
	}

	// Token: 0x1700043C RID: 1084
	// (get) Token: 0x0600107C RID: 4220 RVA: 0x0000D5CF File Offset: 0x0000B7CF
	// (set) Token: 0x0600107D RID: 4221 RVA: 0x0000D5DC File Offset: 0x0000B7DC
	public string String_1
	{
		get
		{
			return this.txtUsername.Text;
		}
		set
		{
			this.txtUsername.Text = value;
		}
	}

	// Token: 0x1700043D RID: 1085
	// (get) Token: 0x0600107E RID: 4222 RVA: 0x0000D5EA File Offset: 0x0000B7EA
	// (set) Token: 0x0600107F RID: 4223 RVA: 0x0000D5F7 File Offset: 0x0000B7F7
	public string String_2
	{
		get
		{
			return this.txtPassword.Text;
		}
		set
		{
			this.txtPassword.Text = value;
		}
	}

	// Token: 0x1700043E RID: 1086
	// (get) Token: 0x06001080 RID: 4224 RVA: 0x0000D605 File Offset: 0x0000B805
	// (set) Token: 0x06001081 RID: 4225 RVA: 0x0000D612 File Offset: 0x0000B812
	public string String_3
	{
		get
		{
			return this.txtDomain.Text;
		}
		set
		{
			this.txtDomain.Text = value;
		}
	}

	// Token: 0x06001082 RID: 4226 RVA: 0x0000D620 File Offset: 0x0000B820
	private void chkUseProxy_CheckedChanged(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001083 RID: 4227 RVA: 0x0005B42C File Offset: 0x0005962C
	private void method_0()
	{
		for (int i = 0; i < base.Controls.Count; i++)
		{
			if (base.Controls[i] != this.chkUseProxy)
			{
				base.Controls[i].Enabled = this.chkUseProxy.Checked;
			}
		}
	}

	// Token: 0x06001084 RID: 4228 RVA: 0x0000D628 File Offset: 0x0000B828
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001085 RID: 4229 RVA: 0x0005B480 File Offset: 0x00059680
	private void InitializeComponent()
	{
		this.chkUseProxy = new CheckBox();
		this.txtProxtAddress = new TextBox();
		this.label1 = new Label();
		this.label2 = new Label();
		this.numProxyPort = new NumericUpDown();
		this.label3 = new Label();
		this.txtUsername = new TextBox();
		this.label4 = new Label();
		this.txtPassword = new TextBox();
		this.label5 = new Label();
		this.txtDomain = new TextBox();
		this.chkBypass = new CheckBox();
		((ISupportInitialize)this.numProxyPort).BeginInit();
		base.SuspendLayout();
		this.chkUseProxy.AutoSize = true;
		this.chkUseProxy.Location = new Point(3, 3);
		this.chkUseProxy.Name = "chkUseProxy";
		this.chkUseProxy.Size = new Size(73, 17);
		this.chkUseProxy.TabIndex = 0;
		this.chkUseProxy.Text = "Use proxy";
		this.chkUseProxy.UseVisualStyleBackColor = true;
		this.chkUseProxy.CheckedChanged += this.chkUseProxy_CheckedChanged;
		this.txtProxtAddress.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
		this.txtProxtAddress.Location = new Point(3, 43);
		this.txtProxtAddress.Name = "txtProxtAddress";
		this.txtProxtAddress.Size = new Size(304, 20);
		this.txtProxtAddress.TabIndex = 2;
		this.label1.AutoSize = true;
		this.label1.Location = new Point(3, 27);
		this.label1.Name = "label1";
		this.label1.Size = new Size(77, 13);
		this.label1.TabIndex = 1;
		this.label1.Text = "Proxy Address:";
		this.label2.AutoSize = true;
		this.label2.Location = new Point(3, 74);
		this.label2.Name = "label2";
		this.label2.Size = new Size(58, 13);
		this.label2.TabIndex = 3;
		this.label2.Text = "Proxy Port:";
		this.numProxyPort.Location = new Point(2, 90);
		NumericUpDown numericUpDown = this.numProxyPort;
		int[] array = new int[4];
		array[0] = 65535;
		numericUpDown.Maximum = new decimal(array);
		NumericUpDown numericUpDown2 = this.numProxyPort;
		int[] array2 = new int[4];
		array2[0] = 1;
		numericUpDown2.Minimum = new decimal(array2);
		this.numProxyPort.Name = "numProxyPort";
		this.numProxyPort.Size = new Size(88, 20);
		this.numProxyPort.TabIndex = 4;
		NumericUpDown numericUpDown3 = this.numProxyPort;
		int[] array3 = new int[4];
		array3[0] = 80;
		numericUpDown3.Value = new decimal(array3);
		this.label3.AutoSize = true;
		this.label3.Location = new Point(3, 169);
		this.label3.Name = "label3";
		this.label3.Size = new Size(63, 13);
		this.label3.TabIndex = 6;
		this.label3.Text = "User Name:";
		this.txtUsername.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
		this.txtUsername.Location = new Point(2, 185);
		this.txtUsername.Name = "txtUsername";
		this.txtUsername.Size = new Size(306, 20);
		this.txtUsername.TabIndex = 7;
		this.label4.AutoSize = true;
		this.label4.Location = new Point(3, 211);
		this.label4.Name = "label4";
		this.label4.Size = new Size(56, 13);
		this.label4.TabIndex = 8;
		this.label4.Text = "Password:";
		this.txtPassword.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
		this.txtPassword.Location = new Point(2, 227);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new Size(306, 20);
		this.txtPassword.TabIndex = 9;
		this.label5.AutoSize = true;
		this.label5.Location = new Point(3, 258);
		this.label5.Name = "label5";
		this.label5.Size = new Size(46, 13);
		this.label5.TabIndex = 10;
		this.label5.Text = "Domain:";
		this.txtDomain.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
		this.txtDomain.Location = new Point(3, 274);
		this.txtDomain.Name = "txtDomain";
		this.txtDomain.Size = new Size(304, 20);
		this.txtDomain.TabIndex = 11;
		this.chkBypass.AutoSize = true;
		this.chkBypass.Location = new Point(2, 126);
		this.chkBypass.Name = "chkBypass";
		this.chkBypass.Size = new Size(100, 17);
		this.chkBypass.TabIndex = 5;
		this.chkBypass.Text = "Bypass on local";
		this.chkBypass.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.txtDomain);
		base.Controls.Add(this.txtPassword);
		base.Controls.Add(this.txtUsername);
		base.Controls.Add(this.txtProxtAddress);
		base.Controls.Add(this.chkBypass);
		base.Controls.Add(this.label5);
		base.Controls.Add(this.label4);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.numProxyPort);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.chkUseProxy);
		base.Name = "Proxy";
		base.Size = new Size(308, 308);
		((ISupportInitialize)this.numProxyPort).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000850 RID: 2128
	private IContainer icontainer_0;

	// Token: 0x04000851 RID: 2129
	private CheckBox chkUseProxy;

	// Token: 0x04000852 RID: 2130
	private TextBox txtProxtAddress;

	// Token: 0x04000853 RID: 2131
	private Label label1;

	// Token: 0x04000854 RID: 2132
	private Label label2;

	// Token: 0x04000855 RID: 2133
	private NumericUpDown numProxyPort;

	// Token: 0x04000856 RID: 2134
	private Label label3;

	// Token: 0x04000857 RID: 2135
	private TextBox txtUsername;

	// Token: 0x04000858 RID: 2136
	private Label label4;

	// Token: 0x04000859 RID: 2137
	private TextBox txtPassword;

	// Token: 0x0400085A RID: 2138
	private Label label5;

	// Token: 0x0400085B RID: 2139
	private TextBox txtDomain;

	// Token: 0x0400085C RID: 2140
	private CheckBox chkBypass;
}
