﻿using System;
using System.Collections.Specialized;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x0200007F RID: 127
internal class Class64 : Class62
{
	// Token: 0x060005AB RID: 1451 RVA: 0x0000698D File Offset: 0x00004B8D
	private Class64(AuthenticationSchemes authenticationSchemes_1, NameValueCollection nameValueCollection_1) : base(authenticationSchemes_1, nameValueCollection_1)
	{
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x000069E9 File Offset: 0x00004BE9
	internal Class64(GClass43 gclass43_0) : this(AuthenticationSchemes.Basic, new NameValueCollection(), gclass43_0, 0U)
	{
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x000069F9 File Offset: 0x00004BF9
	internal Class64(Class63 class63_0, GClass43 gclass43_0, uint uint_1) : this(class63_0.AuthenticationSchemes_0, class63_0.nameValueCollection_0, gclass43_0, uint_1)
	{
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x00033508 File Offset: 0x00031708
	internal Class64(AuthenticationSchemes authenticationSchemes_1, NameValueCollection nameValueCollection_1, GClass43 gclass43_0, uint uint_1) : base(authenticationSchemes_1, nameValueCollection_1)
	{
		this.nameValueCollection_0["username"] = gclass43_0.String_3;
		this.nameValueCollection_0["password"] = gclass43_0.String_1;
		this.nameValueCollection_0["uri"] = gclass43_0.String_0;
		this.uint_0 = uint_1;
		if (authenticationSchemes_1 == AuthenticationSchemes.Digest)
		{
			this.method_0();
		}
	}

	// Token: 0x17000172 RID: 370
	// (get) Token: 0x060005AF RID: 1455 RVA: 0x00006A0F File Offset: 0x00004C0F
	internal uint UInt32_0
	{
		get
		{
			if (this.uint_0 >= 4294967295U)
			{
				return 0U;
			}
			return this.uint_0;
		}
	}

	// Token: 0x17000173 RID: 371
	// (get) Token: 0x060005B0 RID: 1456 RVA: 0x00006A22 File Offset: 0x00004C22
	public string String_5
	{
		get
		{
			return this.nameValueCollection_0["cnonce"];
		}
	}

	// Token: 0x17000174 RID: 372
	// (get) Token: 0x060005B1 RID: 1457 RVA: 0x00006A34 File Offset: 0x00004C34
	public string String_6
	{
		get
		{
			return this.nameValueCollection_0["nc"];
		}
	}

	// Token: 0x17000175 RID: 373
	// (get) Token: 0x060005B2 RID: 1458 RVA: 0x00006A46 File Offset: 0x00004C46
	public string String_7
	{
		get
		{
			return this.nameValueCollection_0["password"];
		}
	}

	// Token: 0x17000176 RID: 374
	// (get) Token: 0x060005B3 RID: 1459 RVA: 0x00006A58 File Offset: 0x00004C58
	public string String_8
	{
		get
		{
			return this.nameValueCollection_0["response"];
		}
	}

	// Token: 0x17000177 RID: 375
	// (get) Token: 0x060005B4 RID: 1460 RVA: 0x00006A6A File Offset: 0x00004C6A
	public string String_9
	{
		get
		{
			return this.nameValueCollection_0["uri"];
		}
	}

	// Token: 0x17000178 RID: 376
	// (get) Token: 0x060005B5 RID: 1461 RVA: 0x00006A7C File Offset: 0x00004C7C
	public string String_10
	{
		get
		{
			return this.nameValueCollection_0["username"];
		}
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00006A8E File Offset: 0x00004C8E
	private static string smethod_2(string string_0, string string_1, string string_2)
	{
		return string.Format("{0}:{1}:{2}", string_0, string_2, string_1);
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00006A9D File Offset: 0x00004C9D
	private static string smethod_3(string string_0, string string_1, string string_2, string string_3, string string_4)
	{
		return string.Format("{0}:{1}:{2}", Class64.smethod_6(Class64.smethod_2(string_0, string_1, string_2)), string_3, string_4);
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00006AB9 File Offset: 0x00004CB9
	private static string smethod_4(string string_0, string string_1)
	{
		return string.Format("{0}:{1}", string_0, string_1);
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00006AC7 File Offset: 0x00004CC7
	private static string smethod_5(string string_0, string string_1, string string_2)
	{
		return string.Format("{0}:{1}:{2}", string_0, string_1, Class64.smethod_6(string_2));
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x00033574 File Offset: 0x00031774
	private static string smethod_6(string string_0)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(string_0);
		byte[] array = MD5.Create().ComputeHash(bytes);
		StringBuilder stringBuilder = new StringBuilder(64);
		foreach (byte b in array)
		{
			stringBuilder.Append(b.ToString("x2"));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x000335D0 File Offset: 0x000317D0
	private void method_0()
	{
		string text = this.nameValueCollection_0["qop"];
		if (text != null)
		{
			if (text.Split(new char[]
			{
				','
			}).smethod_17(new Func<string, bool>(Class64.Class65.<>9.method_0)))
			{
				this.nameValueCollection_0["qop"] = "auth";
				this.nameValueCollection_0["cnonce"] = Class62.smethod_0();
				NameValueCollection nameValueCollection_ = this.nameValueCollection_0;
				string name = "nc";
				string format = "{0:x8}";
				uint num = this.uint_0 + 1U;
				this.uint_0 = num;
				nameValueCollection_[name] = string.Format(format, num);
			}
			else
			{
				this.nameValueCollection_0["qop"] = null;
			}
		}
		this.nameValueCollection_0["method"] = "GET";
		this.nameValueCollection_0["response"] = Class64.smethod_7(this.nameValueCollection_0);
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x000336C8 File Offset: 0x000318C8
	internal static string smethod_7(NameValueCollection nameValueCollection_1)
	{
		string string_ = nameValueCollection_1["username"];
		string string_2 = nameValueCollection_1["password"];
		string string_3 = nameValueCollection_1["realm"];
		string text = nameValueCollection_1["nonce"];
		string string_4 = nameValueCollection_1["uri"];
		string text2 = nameValueCollection_1["algorithm"];
		string text3 = nameValueCollection_1["qop"];
		string text4 = nameValueCollection_1["cnonce"];
		string text5 = nameValueCollection_1["nc"];
		string string_5 = nameValueCollection_1["method"];
		string string_6 = (text2 == null || !(text2.ToLower() == "md5-sess")) ? Class64.smethod_2(string_, string_2, string_3) : Class64.smethod_3(string_, string_2, string_3, text, text4);
		string string_7 = (text3 == null || !(text3.ToLower() == "auth-int")) ? Class64.smethod_4(string_5, string_4) : Class64.smethod_5(string_5, string_4, nameValueCollection_1["entity"]);
		string arg = Class64.smethod_6(string_6);
		string arg2 = (text3 != null) ? string.Format("{0}:{1}:{2}:{3}:{4}", new object[]
		{
			text,
			text5,
			text4,
			text3,
			Class64.smethod_6(string_7)
		}) : string.Format("{0}:{1}", text, Class64.smethod_6(string_7));
		return Class64.smethod_6(string.Format("{0}:{1}", arg, arg2));
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x00033818 File Offset: 0x00031A18
	internal static Class64 smethod_8(string string_0)
	{
		try
		{
			string[] array = string_0.Split(new char[]
			{
				' '
			}, 2);
			if (array.Length != 2)
			{
				return null;
			}
			string a = array[0].ToLower();
			return (a == "basic") ? new Class64(AuthenticationSchemes.Basic, Class64.smethod_9(array[1])) : ((a == "digest") ? new Class64(AuthenticationSchemes.Digest, Class62.smethod_1(array[1])) : null);
		}
		catch
		{
		}
		return null;
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x000338A0 File Offset: 0x00031AA0
	internal static NameValueCollection smethod_9(string string_0)
	{
		string @string = Encoding.Default.GetString(Convert.FromBase64String(string_0));
		int num = @string.IndexOf(':');
		string text = @string.Substring(0, num);
		string value = (num < @string.Length - 1) ? @string.Substring(num + 1) : string.Empty;
		num = text.IndexOf('\\');
		if (num > -1)
		{
			text = text.Substring(num + 1);
		}
		NameValueCollection nameValueCollection = new NameValueCollection();
		nameValueCollection["username"] = text;
		nameValueCollection["password"] = value;
		return nameValueCollection;
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x00033920 File Offset: 0x00031B20
	internal override string \u202E\u200F\u202D\u206F\u206C\u200B\u200F\u202C\u200F\u200D\u200F\u206F\u202C\u200C\u202A\u202D\u206F\u206A\u200E\u200B\u200B\u200E\u200E\u206C\u200D\u202E\u206A\u202A\u206A\u200E\u206F\u206E\u200E\u200B\u202A\u202E\u206B\u200D\u202E\u202C\u202E()
	{
		string s = string.Format("{0}:{1}", this.nameValueCollection_0["username"], this.nameValueCollection_0["password"]);
		string str = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
		return "Basic " + str;
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x00033974 File Offset: 0x00031B74
	internal override string \u206D\u206A\u200E\u202B\u200B\u202A\u206E\u200C\u206E\u202C\u206F\u202C\u206C\u206D\u202C\u206F\u206E\u206D\u200B\u200E\u202D\u202D\u206D\u200C\u200F\u206C\u202D\u206F\u206D\u200F\u206C\u200B\u202E\u200D\u206B\u206B\u200E\u206C\u200B\u206F\u202E()
	{
		StringBuilder stringBuilder = new StringBuilder(256);
		stringBuilder.AppendFormat("Digest username=\"{0}\", realm=\"{1}\", nonce=\"{2}\", uri=\"{3}\", response=\"{4}\"", new object[]
		{
			this.nameValueCollection_0["username"],
			this.nameValueCollection_0["realm"],
			this.nameValueCollection_0["nonce"],
			this.nameValueCollection_0["uri"],
			this.nameValueCollection_0["response"]
		});
		string text = this.nameValueCollection_0["opaque"];
		if (text != null)
		{
			stringBuilder.AppendFormat(", opaque=\"{0}\"", text);
		}
		string text2 = this.nameValueCollection_0["algorithm"];
		if (text2 != null)
		{
			stringBuilder.AppendFormat(", algorithm={0}", text2);
		}
		string text3 = this.nameValueCollection_0["qop"];
		if (text3 != null)
		{
			stringBuilder.AppendFormat(", qop={0}, cnonce=\"{1}\", nc={2}", text3, this.nameValueCollection_0["cnonce"], this.nameValueCollection_0["nc"]);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x00033A88 File Offset: 0x00031C88
	public IIdentity method_1()
	{
		AuthenticationSchemes authenticationSchemes_ = base.AuthenticationSchemes_0;
		if (authenticationSchemes_ != AuthenticationSchemes.Basic)
		{
			return (authenticationSchemes_ == AuthenticationSchemes.Digest) ? new GClass36(this.nameValueCollection_0) : null;
		}
		return new GClass35(this.nameValueCollection_0["username"], this.nameValueCollection_0["password"]);
	}

	// Token: 0x040002D5 RID: 725
	private uint uint_0;

	// Token: 0x02000080 RID: 128
	[CompilerGenerated]
	[Serializable]
	private sealed class Class65
	{
		// Token: 0x060005C4 RID: 1476 RVA: 0x00006AE7 File Offset: 0x00004CE7
		internal bool method_0(string string_0)
		{
			return string_0.Trim().ToLower() == "auth";
		}

		// Token: 0x040002D6 RID: 726
		public static readonly Class64.Class65 <>9 = new Class64.Class65();

		// Token: 0x040002D7 RID: 727
		public static Func<string, bool> <>9__24_0;
	}
}
