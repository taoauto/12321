﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200017C RID: 380
[Serializable]
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct GStruct5
{
	// Token: 0x040009A0 RID: 2464
	public uint VirtualAddress;

	// Token: 0x040009A1 RID: 2465
	public uint SizeOfBlock;
}
