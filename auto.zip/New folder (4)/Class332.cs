﻿using System;

// Token: 0x02000281 RID: 641
internal class Class332
{
	// Token: 0x17000773 RID: 1907
	// (get) Token: 0x06002409 RID: 9225 RVA: 0x0001B873 File Offset: 0x00019A73
	public static string String_0
	{
		get
		{
			return "Đào Hoa Đảo";
		}
	}

	// Token: 0x040017BD RID: 6077
	public static int int_0 = 731;

	// Token: 0x040017BE RID: 6078
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 4U,
		Int32_0 = 103,
		Int32_1 = 138,
		Int32_2 = Class332.int_0,
		String_2 = "Hoàng Chí Tri"
	};

	// Token: 0x040017BF RID: 6079
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 0U,
		Int32_0 = 207,
		Int32_1 = 72,
		Int32_2 = Class332.int_0,
		String_2 = "Quân Hoàn Châu"
	};

	// Token: 0x040017C0 RID: 6080
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 2U,
		Int32_0 = 160,
		Int32_1 = 72,
		Int32_2 = Class332.int_0,
		String_2 = "Tiêu Thanh Yết"
	};

	// Token: 0x040017C1 RID: 6081
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 207,
		Int32_1 = 66,
		Int32_2 = Class332.int_0,
		String_2 = "Yến Phản"
	};
}
