﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using _i;

// Token: 0x020001FA RID: 506
public class DiChuyen : UserControl
{
	// Token: 0x06001A55 RID: 6741 RVA: 0x00013160 File Offset: 0x00011360
	public DiChuyen()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001A56 RID: 6742 RVA: 0x000C691C File Offset: 0x000C4B1C
	private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
	{
		while (this.lstv.SelectedItems.Count > 0)
		{
			this.lstv.SelectedItems[0].Remove();
		}
		string text = string.Empty;
		foreach (object obj in this.lstv.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			string[] array = new string[7];
			array[0] = text;
			int num = 1;
			object tag = listViewItem.Tag;
			array[num] = ((tag != null) ? tag.ToString() : null);
			array[2] = "|";
			array[3] = listViewItem.Text;
			array[4] = "|";
			array[5] = listViewItem.SubItems[1].Text;
			array[6] = "\r\n";
			text = string.Concat(array);
		}
		Class159.Class220_0.method_1("Item", "DiChuyen", text);
	}

	// Token: 0x06001A57 RID: 6743 RVA: 0x000C6A18 File Offset: 0x000C4C18
	private void DiChuyen_Load(object sender, EventArgs e)
	{
		this.class159_0 = Main.class159_0;
		if (this.class159_0 != null)
		{
			base.Tag = "Di Chuyển (" + this.class159_0.Class432_0.String_2 + ")";
			this.textBoxEx1.Text = (this.label3.Text = string.Concat(new string[]
			{
				this.class159_0.Class432_0.string_7,
				" [",
				this.class159_0.Int32_12.ToString(),
				",",
				this.class159_0.Int32_13.ToString(),
				"]"
			}));
			this.string_0 = string.Concat(new string[]
			{
				this.class159_0.Int32_12.ToString(),
				",",
				this.class159_0.Int32_13.ToString(),
				",",
				this.class159_0.Class432_0.UInt32_29.ToString()
			});
			string[] array = Class159.Class220_0.method_0("Item", "DiChuyen").Split(new char[]
			{
				'\n'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Split(new char[]
				{
					'|'
				}).Length == 3)
				{
					string tag = text.Split(new char[]
					{
						'|'
					})[0];
					string text2 = text.Split(new char[]
					{
						'|'
					})[1];
					string text3 = text.Split(new char[]
					{
						'|'
					})[2];
					ListViewItem listViewItem = new ListViewItem(text2);
					listViewItem.SubItems.Add(text3);
					listViewItem.Tag = tag;
					this.lstv.Items.Add(listViewItem);
				}
			}
		}
	}

	// Token: 0x06001A58 RID: 6744 RVA: 0x000C6C14 File Offset: 0x000C4E14
	private void button1_Click(object sender, EventArgs e)
	{
		if (this.class159_0 == null)
		{
			return;
		}
		this.textBoxEx1.Text = this.textBoxEx1.Text.Replace("|", "");
		ListViewItem listViewItem = new ListViewItem(this.label3.Text);
		if (this.textBoxEx1.Text.Length > 0)
		{
			listViewItem.SubItems.Add(this.textBoxEx1.Text);
		}
		else
		{
			listViewItem.SubItems.Add(this.label3.Text);
		}
		listViewItem.Tag = this.string_0;
		this.lstv.Items.Add(listViewItem);
		string text = string.Empty;
		foreach (object obj in this.lstv.Items)
		{
			ListViewItem listViewItem2 = (ListViewItem)obj;
			string[] array = new string[7];
			array[0] = text;
			int num = 1;
			object tag = listViewItem2.Tag;
			array[num] = ((tag != null) ? tag.ToString() : null);
			array[2] = "|";
			array[3] = listViewItem2.Text;
			array[4] = "|";
			array[5] = listViewItem2.SubItems[1].Text;
			array[6] = "\r\n";
			text = string.Concat(array);
		}
		Class159.Class220_0.method_1("Item", "DiChuyen", text);
	}

	// Token: 0x06001A59 RID: 6745 RVA: 0x000C6D84 File Offset: 0x000C4F84
	private void button2_Click(object sender, EventArgs e)
	{
		this.textBoxEx1.Text = (this.label3.Text = string.Concat(new string[]
		{
			this.class159_0.Class432_0.string_7,
			" [",
			this.class159_0.Int32_12.ToString(),
			",",
			this.class159_0.Int32_13.ToString(),
			"]"
		}));
		this.string_0 = string.Concat(new string[]
		{
			this.class159_0.Int32_12.ToString(),
			",",
			this.class159_0.Int32_13.ToString(),
			",",
			this.class159_0.Class432_0.UInt32_29.ToString()
		});
	}

	// Token: 0x06001A5A RID: 6746 RVA: 0x0001316E File Offset: 0x0001136E
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001A5B RID: 6747 RVA: 0x000C6E74 File Offset: 0x000C5074
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(DiChuyen));
		this.lstv = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.contextMenuStrip1 = new ContextMenuStrip(this.icontainer_0);
		this.deleteToolStripMenuItem = new ToolStripMenuItem();
		this.textBoxEx1 = new Class85();
		this.button1 = new Button();
		this.tableLayoutPanel1 = new TableLayoutPanel();
		this.label3 = new Label();
		this.label2 = new Label();
		this.label1 = new Label();
		this.button2 = new Button();
		this.contextMenuStrip1.SuspendLayout();
		this.tableLayoutPanel1.SuspendLayout();
		base.SuspendLayout();
		this.lstv.AllowColumnReorder = true;
		this.lstv.AllowDrop = true;
		this.lstv.AllowReorder = true;
		this.lstv.AllowSort = false;
		this.lstv.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1
		});
		this.lstv.ContextMenuStrip = this.contextMenuStrip1;
		this.lstv.Dock = DockStyle.Fill;
		this.lstv.DoubleClickActivation = false;
		this.lstv.FullRowSelect = true;
		this.lstv.GridLines = true;
		this.lstv.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lstv.hideItems");
		this.lstv.HideSelection = false;
		this.lstv.LineColor = Color.Red;
		this.lstv.Location = new Point(0, 0);
		this.lstv.Name = "lstv";
		this.lstv.Size = new Size(430, 300);
		this.lstv.TabIndex = 1;
		this.lstv.UseCompatibleStateImageBehavior = false;
		this.lstv.View = View.Details;
		this.columnHeader_0.Text = "Tọa độ";
		this.columnHeader_0.Width = 182;
		this.columnHeader_1.Text = "Tên";
		this.columnHeader_1.Width = 156;
		this.contextMenuStrip1.Items.AddRange(new ToolStripItem[]
		{
			this.deleteToolStripMenuItem
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new Size(108, 26);
		this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
		this.deleteToolStripMenuItem.Size = new Size(107, 22);
		this.deleteToolStripMenuItem.Text = "Delete";
		this.deleteToolStripMenuItem.Click += this.deleteToolStripMenuItem_Click;
		this.textBoxEx1.Dock = DockStyle.Fill;
		this.textBoxEx1.Location = new Point(3, 27);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new Size(209, 20);
		this.textBoxEx1.TabIndex = 2;
		this.textBoxEx1.String_0 = "Đặt tên cho tọa độ hiện tại";
		this.textBoxEx1.Color_0 = Color.Gray;
		this.textBoxEx1.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = Color.LightGray;
		this.button1.Dock = DockStyle.Bottom;
		this.button1.Location = new Point(0, 372);
		this.button1.Name = "button1";
		this.button1.Size = new Size(430, 23);
		this.button1.TabIndex = 3;
		this.button1.Text = "Add";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.tableLayoutPanel1.ColumnCount = 2;
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		this.tableLayoutPanel1.Controls.Add(this.label3, 1, 1);
		this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
		this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
		this.tableLayoutPanel1.Controls.Add(this.textBoxEx1, 0, 1);
		this.tableLayoutPanel1.Dock = DockStyle.Bottom;
		this.tableLayoutPanel1.Location = new Point(0, 300);
		this.tableLayoutPanel1.Name = "tableLayoutPanel1";
		this.tableLayoutPanel1.RowCount = 2;
		this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		this.tableLayoutPanel1.Size = new Size(430, 49);
		this.tableLayoutPanel1.TabIndex = 4;
		this.label3.Dock = DockStyle.Fill;
		this.label3.Location = new Point(218, 24);
		this.label3.Name = "label3";
		this.label3.Size = new Size(209, 25);
		this.label3.TabIndex = 3;
		this.label3.Text = "Tọa Độ";
		this.label3.TextAlign = ContentAlignment.MiddleCenter;
		this.label2.Dock = DockStyle.Fill;
		this.label2.Location = new Point(218, 0);
		this.label2.Name = "label2";
		this.label2.Size = new Size(209, 24);
		this.label2.TabIndex = 1;
		this.label2.Text = "Tọa Độ";
		this.label2.TextAlign = ContentAlignment.MiddleCenter;
		this.label1.Dock = DockStyle.Fill;
		this.label1.Location = new Point(3, 0);
		this.label1.Name = "label1";
		this.label1.Size = new Size(209, 24);
		this.label1.TabIndex = 0;
		this.label1.Text = "Tên Hiển Thị";
		this.label1.TextAlign = ContentAlignment.MiddleCenter;
		this.button2.Dock = DockStyle.Bottom;
		this.button2.Location = new Point(0, 349);
		this.button2.Name = "button2";
		this.button2.Size = new Size(430, 23);
		this.button2.TabIndex = 5;
		this.button2.Text = "Lấy Tọa Độ Hiện Tại";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += this.button2_Click;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.lstv);
		base.Controls.Add(this.tableLayoutPanel1);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.button1);
		base.Name = "DiChuyen";
		base.Size = new Size(430, 395);
		base.Load += this.DiChuyen_Load;
		this.contextMenuStrip1.ResumeLayout(false);
		this.tableLayoutPanel1.ResumeLayout(false);
		this.tableLayoutPanel1.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x0400106F RID: 4207
	private Class159 class159_0;

	// Token: 0x04001070 RID: 4208
	private string string_0;

	// Token: 0x04001071 RID: 4209
	private IContainer icontainer_0;

	// Token: 0x04001072 RID: 4210
	private ListViewEx lstv;

	// Token: 0x04001073 RID: 4211
	private ColumnHeader columnHeader_0;

	// Token: 0x04001074 RID: 4212
	private ColumnHeader columnHeader_1;

	// Token: 0x04001075 RID: 4213
	private Class85 textBoxEx1;

	// Token: 0x04001076 RID: 4214
	private Button button1;

	// Token: 0x04001077 RID: 4215
	private ContextMenuStrip contextMenuStrip1;

	// Token: 0x04001078 RID: 4216
	private ToolStripMenuItem deleteToolStripMenuItem;

	// Token: 0x04001079 RID: 4217
	private TableLayoutPanel tableLayoutPanel1;

	// Token: 0x0400107A RID: 4218
	private Label label3;

	// Token: 0x0400107B RID: 4219
	private Label label2;

	// Token: 0x0400107C RID: 4220
	private Label label1;

	// Token: 0x0400107D RID: 4221
	private Button button2;
}
