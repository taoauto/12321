﻿using System;
using System.Drawing;

// Token: 0x02000136 RID: 310
public class GClass102 : GClass101
{
	// Token: 0x06000F95 RID: 3989 RVA: 0x0000CEB1 File Offset: 0x0000B0B1
	public GClass102(int int_1, Rectangle rectangle_1) : base(rectangle_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000F96 RID: 3990 RVA: 0x00059238 File Offset: 0x00057438
	public void method_0(Graphics graphics_0, Pen pen_0, Brush brush_0, Pen pen_1)
	{
		graphics_0.FillRectangle(brush_0, this.rectangle_0);
		graphics_0.DrawRectangle(pen_0, this.rectangle_0);
		graphics_0.DrawLine(pen_1, this.rectangle_0.Left + 2, this.rectangle_0.Top + this.rectangle_0.Height / 2, this.rectangle_0.Right - 2, this.rectangle_0.Top + this.rectangle_0.Height / 2);
	}

	// Token: 0x04000805 RID: 2053
	public readonly int int_0;
}
