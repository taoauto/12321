﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using _i;

// Token: 0x020001DE RID: 478
internal class FastTask : UserControl
{
	// Token: 0x0600197F RID: 6527 RVA: 0x000B74BC File Offset: 0x000B56BC
	public FastTask(Class159 class159_1)
	{
		this.class159_0 = class159_1;
		this.InitializeComponent();
		base.Disposed += this.FastTask_Disposed;
		base.Tag = class159_1.Class432_0.String_2;
	}

	// Token: 0x06001980 RID: 6528 RVA: 0x000B750C File Offset: 0x000B570C
	private void FastTask_Disposed(object sender, EventArgs e)
	{
		foreach (object obj in this.lvGame.Items)
		{
			(((ListViewItem)obj).Tag as Class159).Boolean_86 = false;
		}
	}

	// Token: 0x1700063F RID: 1599
	// (get) Token: 0x06001981 RID: 6529 RVA: 0x000B7574 File Offset: 0x000B5774
	private Class159 Class159_0
	{
		get
		{
			foreach (object obj in this.lvGame.Items)
			{
				Class159 @class = ((ListViewItem)obj).Tag as Class159;
				if (@class.Class432_0.String_8 == this.string_0)
				{
					return @class;
				}
			}
			return null;
		}
	}

	// Token: 0x06001982 RID: 6530 RVA: 0x000B75F8 File Offset: 0x000B57F8
	private void FastTask_Load(object sender, EventArgs e)
	{
		this.comboBox1.SelectedIndex = 0;
		foreach (Class159 @class in this.class159_0.List_25)
		{
			if (!@class.Class432_0.Boolean_32)
			{
				ListViewItem listViewItem = new ListViewItem(@class.Class432_0.String_2);
				listViewItem.SubItems.Add("Thành Viên");
				listViewItem.Tag = @class;
				this.lvGame.Items.Add(listViewItem);
			}
			else
			{
				ListViewItem listViewItem2 = new ListViewItem(@class.Class432_0.String_2)
				{
					UseItemStyleForSubItems = false
				};
				listViewItem2.ForeColor = Color.Blue;
				listViewItem2.SubItems.Add("Đội Trưởng");
				listViewItem2.Tag = @class;
				this.lvGame.Items.Add(listViewItem2);
				this.string_0 = @class.Class432_0.String_8;
			}
		}
		this.lvGame.Columns[0].Text = "Tổ Đội [" + this.lvGame.Items.Count.ToString() + "]";
		string text = Class159.Class220_0.method_0("CanQuet", this.string_0);
		if (string.IsNullOrEmpty(text))
		{
			text = Class159.Class220_0.method_0("Item", "FastTask");
		}
		List<ListViewItem> list = new List<ListViewItem>();
		foreach (string text2 in text.Split(new char[]
		{
			'\n'
		}))
		{
			if (text2.Trim().Length > 2 && text2.Split(new char[]
			{
				'|'
			}).Length == 2)
			{
				ListViewItem listViewItem3 = new ListViewItem(text2.Split(new char[]
				{
					'|'
				})[0].Trim());
				if (text2.Split(new char[]
				{
					'|'
				})[1].Trim() == "1")
				{
					listViewItem3.Checked = true;
				}
				listViewItem3.SubItems.Add("Đang Chờ");
				listViewItem3.SubItems.Add("00:00");
				list.Add(listViewItem3);
			}
		}
		this.lvTask.Items.AddRange(list.ToArray());
		this.label1.Text = this.lvGame.Items.Count.ToString();
	}

	// Token: 0x06001983 RID: 6531 RVA: 0x000B7894 File Offset: 0x000B5A94
	private void button1_Click(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem(this.comboBox1.Text);
		listViewItem.SubItems.Add("Đang Chờ");
		listViewItem.SubItems.Add("00:00");
		listViewItem.Checked = true;
		this.lvTask.Items.Add(listViewItem);
		this.method_2();
	}

	// Token: 0x06001984 RID: 6532 RVA: 0x000B78F4 File Offset: 0x000B5AF4
	private void button3_Click(object sender, EventArgs e)
	{
		this.lvTask.Items.Clear();
		foreach (object obj in this.comboBox1.Items)
		{
			if (!(obj.ToString() == "Luyện Kim") && !obj.ToString().Contains("Sửa Trang Bị"))
			{
				ListViewItem listViewItem = new ListViewItem(obj.ToString());
				listViewItem.Checked = true;
				listViewItem.SubItems.Add("Đang Chờ");
				listViewItem.SubItems.Add("00:00");
				this.lvTask.Items.Add(listViewItem);
			}
		}
		this.method_2();
	}

	// Token: 0x06001985 RID: 6533 RVA: 0x000B79C8 File Offset: 0x000B5BC8
	private void method_0(object sender, EventArgs e)
	{
		if (this.button2.Text == "Start")
		{
			this.timer_0.Enabled = true;
			this.button2.Text = "Stop";
			return;
		}
		this.timer_0.Enabled = false;
		this.button2.Text = "Start";
	}

	// Token: 0x06001986 RID: 6534 RVA: 0x000128D1 File Offset: 0x00010AD1
	private void toolStripMenuItem_0_Click(object sender, EventArgs e)
	{
		while (this.lvTask.SelectedItems.Count > 0)
		{
			this.lvTask.SelectedItems[0].Remove();
		}
		this.method_2();
	}

	// Token: 0x17000640 RID: 1600
	// (get) Token: 0x06001987 RID: 6535 RVA: 0x00012905 File Offset: 0x00010B05
	// (set) Token: 0x06001988 RID: 6536 RVA: 0x0001290D File Offset: 0x00010B0D
	public int Int32_0 { get; set; }

	// Token: 0x06001989 RID: 6537 RVA: 0x000B7A28 File Offset: 0x000B5C28
	private void timer_0_Tick(object sender, EventArgs e)
	{
		try
		{
			if (this.lvTask.Items.Cast<ListViewItem>().Where(new Func<ListViewItem, bool>(FastTask.Class218.<>9.method_0)).Count<ListViewItem>() != 0)
			{
				foreach (object obj in this.lvGame.Items)
				{
					ListViewItem listViewItem = (ListViewItem)obj;
					foreach (Class159 @class in Main.Main_0.IEnumerable_5)
					{
						if (@class.Class432_0.String_2 == listViewItem.Text)
						{
							listViewItem.Tag = @class;
							break;
						}
					}
				}
				this.Int32_0 = 0;
				foreach (object obj2 in this.lvTask.Items)
				{
					string text = ((ListViewItem)obj2).SubItems[2].Text;
					if (text.Split(new char[]
					{
						':'
					}).Length == 2)
					{
						int num = Class426.smethod_41(text.Split(new char[]
						{
							':'
						})[0]);
						int num2 = Class426.smethod_41(text.Split(new char[]
						{
							':'
						})[1]);
						this.Int32_0 += num * 60 + num2;
					}
				}
				int num3 = this.Int32_0 % 60;
				int num4 = (int)Math.Floor(this.Int32_0 / 60m);
				this.lvTask.Columns[2].Text = string.Format("{0:00}", num4) + ":" + string.Format("{0:00}", num3);
				if (this.Class159_0 != null && this.Class159_0.Class432_0.UInt32_32 >= 10U)
				{
					if (this.Class159_0.Class432_0.UInt32_26 == 4294967295U)
					{
						bool flag = false;
						foreach (object obj3 in this.lvGame.Items)
						{
							Class159 class2 = ((ListViewItem)obj3).Tag as Class159;
							if (class2 != this.Class159_0 && class2.Class432_0.UInt32_26 != 4294967295U && !class2.method_54(this.Class159_0.Class432_0))
							{
								this.Class159_0.method_276(class2.Class432_0.Byte_0);
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							this.Class159_0.method_282("Player:CreateTeamSelf();", false);
						}
					}
					else if (!this.Class159_0.Class432_0.Boolean_32)
					{
						foreach (Class159 class3 in this.Class159_0.List_25)
						{
							if (class3.Class432_0.Boolean_32)
							{
								class3.method_336(this.Class159_0.Class432_0.String_2);
								break;
							}
						}
					}
					else
					{
						foreach (object obj4 in this.lvGame.Items)
						{
							(((ListViewItem)obj4).Tag as Class159).Boolean_86 = false;
						}
						foreach (object obj5 in this.lvGame.Items)
						{
							ListViewItem listViewItem2 = (ListViewItem)obj5;
							Class159 class4 = listViewItem2.Tag as Class159;
							if (class4.Process_0.HasExited)
							{
								this.Class159_0.Boolean_86 = true;
								using (IEnumerator<Class159> enumerator2 = Main.Main_0.IEnumerable_5.GetEnumerator())
								{
									while (enumerator2.MoveNext())
									{
										Class159 class5 = enumerator2.Current;
										if (class5.Class432_0.String_2 == listViewItem2.Text)
										{
											listViewItem2.Tag = class5;
											break;
										}
									}
									continue;
								}
							}
							if (class4 != this.Class159_0)
							{
								if (class4.method_54(this.Class159_0.Class432_0))
								{
									class4.method_70(this.Class159_0.Single_3, this.Class159_0.Single_4, (int)this.Class159_0.Class432_0.UInt32_29, false, 3f, 30f);
									this.Class159_0.Boolean_86 = true;
									foreach (object obj6 in this.lvGame.Items)
									{
										(((ListViewItem)obj6).Tag as Class159).Boolean_86 = true;
									}
								}
								if (class4.Class432_0.UInt32_26 == 4294967295U)
								{
									class4.method_276(this.Class159_0.Class432_0.Byte_0);
									foreach (object obj7 in this.lvGame.Items)
									{
										(((ListViewItem)obj7).Tag as Class159).Boolean_86 = true;
										this.Class159_0.Boolean_86 = true;
									}
								}
							}
						}
						foreach (ListViewItem listViewItem3 in this.lvTask.Items.Cast<ListViewItem>().Where(new Func<ListViewItem, bool>(FastTask.Class218.<>9.method_1)))
						{
							if (listViewItem3.SubItems[1].Text == "Đang Làm")
							{
								string text2 = listViewItem3.SubItems[2].Text;
								if (text2.Split(new char[]
								{
									':'
								}).Length == 2)
								{
									int num5 = Class426.smethod_41(text2.Split(new char[]
									{
										':'
									})[0]);
									int num6 = Class426.smethod_41(text2.Split(new char[]
									{
										':'
									})[1]);
									TimeSpan timeSpan = TimeSpan.FromSeconds((double)(num5 * 60 + num6 + 1));
									listViewItem3.SubItems[2].Text = (timeSpan.Hours * 60 + timeSpan.Minutes).ToString() + ":" + timeSpan.Seconds.ToString();
								}
								if (listViewItem3.Text == "Nhận Phỉ Thúy")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.NhanPhiThuy))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Nhận x2")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.NhanX2))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Đông x2")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.DongX2))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Nhận Chiến Công + Kiếm Chỉ")
								{
									foreach (object obj8 in this.lvGame.Items)
									{
										Class159 class6 = ((ListViewItem)obj8).Tag as Class159;
										if (class6.List_0.Contains(Enum14.NhanChienCong) || class6.List_0.Contains(Enum14.NhanKiemChi))
										{
											return;
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Hàng Ngày")
								{
									foreach (object obj9 in this.lvGame.Items)
									{
										Class159 class7 = ((ListViewItem)obj9).Tag as Class159;
										if (class7.List_0.Contains(Enum14.ThuTaiVanMay) || class7.List_0.Contains(Enum14.LoLyHoa) || class7.List_0.Contains(Enum14.NguyenVongThienLinh))
										{
											return;
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Bán Đồ - Cất Đồ - Trị Liệu")
								{
									foreach (object obj10 in this.lvGame.Items)
									{
										Class159 class8 = ((ListViewItem)obj10).Tag as Class159;
										if (class8.List_0.Contains(Enum14.TriLieu) || class8.List_0.Contains(Enum14.BanRac) || class8.List_0.Contains(Enum14.CatVang) || class8.List_0.Contains(Enum14.CatDo))
										{
											return;
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Luyện Kim")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.LuyenKim))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Luyện Kim Nhanh")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.LuyenKimNhanh))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Sửa Trang Bị")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.SuaTrangBi))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Phiêu Miễu Phong")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiPhieuMieuPhong))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Q Tô Châu")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiQ123ToChau))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Q Lâu Lan")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiQ123LauLan))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Phân Giải Trang Bị Pet")
								{
									using (IEnumerator enumerator = this.lvGame.Items.GetEnumerator())
									{
										while (enumerator.MoveNext())
										{
											if ((((ListViewItem)enumerator.Current).Tag as Class159).List_0.Contains(Enum14.PhanGiaiTrangBiPet))
											{
												return;
											}
										}
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Phiêu Miễu Phong Huyết Chiến")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiKhieuChienPhieuMieuPhong))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Yến Tử Ô")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiYenTuO))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Sát Tinh")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiSatTinh))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Tứ Tuyệt Trang")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiTuTuyetTrang))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Thiếu Thất Sơn")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiThieuThatSon))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Vương Lăng")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiVuongLang))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Tam Thần Huyễn Cảnh")
								{
									if (this.Class159_0.List_0.Contains(Enum14.DatDoiTamThan))
									{
										return;
									}
									listViewItem3.SubItems[1].Text = "Hoàn Thành";
								}
								if (listViewItem3.Text == "Lan Hoàn Phúc Địa")
								{
									if (!this.Class159_0.List_0.Contains(Enum14.DatDoiPhucDia))
									{
										listViewItem3.SubItems[1].Text = "Hoàn Thành";
									}
								}
								return;
							}
						}
						foreach (object obj11 in this.lvTask.Items)
						{
							ListViewItem listViewItem4 = (ListViewItem)obj11;
							if (listViewItem4.Checked && listViewItem4.SubItems[1].Text == "Đang Chờ")
							{
								if (listViewItem4.Text == "Nhận Phỉ Thúy")
								{
									foreach (object obj12 in this.lvGame.Items)
									{
										(((ListViewItem)obj12).Tag as Class159).method_48(Enum14.NhanPhiThuy, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Nhận x2")
								{
									foreach (object obj13 in this.lvGame.Items)
									{
										(((ListViewItem)obj13).Tag as Class159).method_48(Enum14.NhanX2, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Đông x2")
								{
									foreach (object obj14 in this.lvGame.Items)
									{
										(((ListViewItem)obj14).Tag as Class159).method_48(Enum14.DongX2, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Nhận Chiến Công + Kiếm Chỉ")
								{
									foreach (object obj15 in this.lvGame.Items)
									{
										Class159 class9 = ((ListViewItem)obj15).Tag as Class159;
										class9.method_48(Enum14.NhanChienCong, true);
										class9.method_48(Enum14.NhanKiemChi, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Hàng Ngày")
								{
									foreach (object obj16 in this.lvGame.Items)
									{
										Class159 class10 = ((ListViewItem)obj16).Tag as Class159;
										class10.method_48(Enum14.ThuTaiVanMay, true);
										class10.method_48(Enum14.LoLyHoa, true);
										foreach (Class209 class11 in class10.Class196_0.IEnumerable_0)
										{
											if (class11.String_3 == "nguyenlinhtuyen" && class11.UInt32_5 >= 5U)
											{
												class10.method_48(Enum14.NguyenVongThienLinh, true);
												break;
											}
										}
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Bán Đồ - Cất Đồ - Trị Liệu")
								{
									foreach (object obj17 in this.lvGame.Items)
									{
										(((ListViewItem)obj17).Tag as Class159).method_49(new Enum14[]
										{
											Enum14.TriLieu,
											Enum14.BanRac,
											Enum14.CatVang,
											Enum14.CatDo
										});
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Luyện Kim")
								{
									foreach (object obj18 in this.lvGame.Items)
									{
										(((ListViewItem)obj18).Tag as Class159).method_48(Enum14.LuyenKim, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Luyện Kim Nhanh")
								{
									foreach (object obj19 in this.lvGame.Items)
									{
										(((ListViewItem)obj19).Tag as Class159).method_48(Enum14.LuyenKimNhanh, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Sửa Trang Bị")
								{
									foreach (object obj20 in this.lvGame.Items)
									{
										(((ListViewItem)obj20).Tag as Class159).method_48(Enum14.SuaTrangBi, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Q Lâu Lan")
								{
									this.Class159_0.method_48(Enum14.DatDoiQ123LauLan, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Q Tô Châu")
								{
									this.Class159_0.method_48(Enum14.DatDoiQ123ToChau, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Phiêu Miễu Phong")
								{
									this.Class159_0.method_48(Enum14.DatDoiPhieuMieuPhong, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Phân Giải Trang Bị Pet")
								{
									foreach (object obj21 in this.lvGame.Items)
									{
										(((ListViewItem)obj21).Tag as Class159).method_48(Enum14.PhanGiaiTrangBiPet, true);
									}
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Phiêu Miễu Phong Huyết Chiến")
								{
									this.Class159_0.method_48(Enum14.DatDoiKhieuChienPhieuMieuPhong, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Yến Tử Ô")
								{
									this.Class159_0.method_48(Enum14.DatDoiYenTuO, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Sát Tinh")
								{
									this.Class159_0.method_48(Enum14.DatDoiSatTinh, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Tứ Tuyệt Trang")
								{
									this.Class159_0.method_48(Enum14.DatDoiTuTuyetTrang, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Thiếu Thất Sơn")
								{
									this.Class159_0.method_48(Enum14.DatDoiThieuThatSon, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Vương Lăng")
								{
									this.Class159_0.method_48(Enum14.DatDoiVuongLang, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Tam Thần Huyễn Cảnh")
								{
									this.Class159_0.method_48(Enum14.DatDoiTamThan, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								if (listViewItem4.Text == "Lan Hoàn Phúc Địa")
								{
									this.Class159_0.method_48(Enum14.DatDoiPhucDia, true);
									listViewItem4.SubItems[1].Text = "Đang Làm";
								}
								break;
							}
						}
					}
				}
			}
		}
		catch
		{
		}
	}

	// Token: 0x0600198A RID: 6538 RVA: 0x000B9514 File Offset: 0x000B7714
	private void method_1(object sender, FormClosingEventArgs e)
	{
		this.method_2();
		foreach (object obj in this.lvGame.Items)
		{
			(((ListViewItem)obj).Tag as Class159).Boolean_86 = false;
		}
	}

	// Token: 0x0600198B RID: 6539 RVA: 0x000B9584 File Offset: 0x000B7784
	private void method_2()
	{
		string text = "";
		foreach (object obj in this.lvTask.Items)
		{
			ListViewItem listViewItem = (ListViewItem)obj;
			text = string.Concat(new string[]
			{
				text,
				listViewItem.Text,
				"|",
				listViewItem.Checked.smethod_17().ToString(),
				"\r\n"
			});
		}
		Class159.Class220_0.method_1("Item", "FastTask", text);
		Class159.Class220_0.method_1("CanQuet", this.string_0, text);
	}

	// Token: 0x0600198C RID: 6540 RVA: 0x00012916 File Offset: 0x00010B16
	private void lvGame_DoubleClick(object sender, EventArgs e)
	{
		if (this.lvGame.SelectedItems.Count > 0)
		{
			(this.lvGame.SelectedItems[0].Tag as Class159).method_223();
		}
	}

	// Token: 0x0600198D RID: 6541 RVA: 0x0001294B File Offset: 0x00010B4B
	private void button4_Click(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_4)).Start();
	}

	// Token: 0x0600198E RID: 6542 RVA: 0x000B9650 File Offset: 0x000B7850
	private void checkAllToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.lvTask.Items)
		{
			((ListViewItem)obj).Checked = true;
		}
	}

	// Token: 0x0600198F RID: 6543 RVA: 0x000B96B0 File Offset: 0x000B78B0
	private void uncheckAllToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.lvTask.Items)
		{
			((ListViewItem)obj).Checked = false;
		}
	}

	// Token: 0x06001990 RID: 6544 RVA: 0x000B9710 File Offset: 0x000B7910
	private void exitToolStripMenuItem_Click(object sender, EventArgs e)
	{
		foreach (object obj in this.lvGame.Items)
		{
			(((ListViewItem)obj).Tag as Class159).method_224(true);
		}
	}

	// Token: 0x06001991 RID: 6545 RVA: 0x00012963 File Offset: 0x00010B63
	private void lvTask_DragDrop(object sender, DragEventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06001992 RID: 6546 RVA: 0x00002E18 File Offset: 0x00001018
	private void lvTask_ItemCheck(object sender, ItemCheckEventArgs e)
	{
	}

	// Token: 0x06001993 RID: 6547 RVA: 0x00002E18 File Offset: 0x00001018
	private void FastTask_Resize(object sender, EventArgs e)
	{
	}

	// Token: 0x17000641 RID: 1601
	// (get) Token: 0x06001994 RID: 6548 RVA: 0x0001296B File Offset: 0x00010B6B
	// (set) Token: 0x06001995 RID: 6549 RVA: 0x00012972 File Offset: 0x00010B72
	public static bool Boolean_0 { get; set; }

	// Token: 0x06001996 RID: 6550 RVA: 0x000B9778 File Offset: 0x000B7978
	private void timer_1_Tick(object sender, EventArgs e)
	{
		if (FastTask.Boolean_0 && DateTime.Now.Hour == 0 && DateTime.Now.Minute == 0 && DateTime.Now.Second <= 5)
		{
			if (this.button2.Text == "Start")
			{
				this.timer_0.Enabled = true;
				this.button2.Text = "Stop";
			}
			this.lvTask.Items.Cast<ListViewItem>().Where(new Func<ListViewItem, bool>(FastTask.Class218.<>9.method_2)).smethod_13(new Action<ListViewItem>(FastTask.Class218.<>9.method_3));
		}
	}

	// Token: 0x06001997 RID: 6551 RVA: 0x00012963 File Offset: 0x00010B63
	private void lvTask_ItemChecked(object sender, ItemCheckedEventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06001998 RID: 6552 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_3(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x06001999 RID: 6553 RVA: 0x00002E18 File Offset: 0x00001018
	private void label1_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x0600199A RID: 6554 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void button5_Click(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x0600199B RID: 6555 RVA: 0x000B79C8 File Offset: 0x000B5BC8
	private void button2_Click(object sender, EventArgs e)
	{
		if (this.button2.Text == "Start")
		{
			this.timer_0.Enabled = true;
			this.button2.Text = "Stop";
			return;
		}
		this.timer_0.Enabled = false;
		this.button2.Text = "Start";
	}

	// Token: 0x0600199C RID: 6556 RVA: 0x0001297A File Offset: 0x00010B7A
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0600199D RID: 6557 RVA: 0x000B9854 File Offset: 0x000B7A54
	private void InitializeComponent()
	{
		this.icontainer_0 = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(FastTask));
		this.comboBox1 = new ComboBox();
		this.button1 = new Button();
		this.button3 = new Button();
		this.timer_0 = new System.Windows.Forms.Timer(this.icontainer_0);
		this.contextMenuStrip1 = new ContextMenuStrip(this.icontainer_0);
		this.toolStripMenuItem_0 = new ToolStripMenuItem();
		this.checkAllToolStripMenuItem = new ToolStripMenuItem();
		this.uncheckAllToolStripMenuItem = new ToolStripMenuItem();
		this.button4 = new Button();
		this.contextMenuStrip2 = new ContextMenuStrip(this.icontainer_0);
		this.exitToolStripMenuItem = new ToolStripMenuItem();
		this.panel1 = new Panel();
		this.timer_1 = new System.Windows.Forms.Timer(this.icontainer_0);
		this.splitContainer1 = new SplitContainer();
		this.splitContainer2 = new SplitContainer();
		this.lvTask = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.columnHeader_1 = new ColumnHeader();
		this.columnHeader_4 = new ColumnHeader();
		this.lvGame = new ListViewEx();
		this.columnHeader_2 = new ColumnHeader();
		this.columnHeader_3 = new ColumnHeader();
		this.label1 = new Label();
		this.panel2 = new Panel();
		this.button2 = new Button();
		this.button5 = new Button();
		this.panel3 = new Panel();
		this.contextMenuStrip1.SuspendLayout();
		this.contextMenuStrip2.SuspendLayout();
		this.panel1.SuspendLayout();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.splitContainer2.Panel1.SuspendLayout();
		this.splitContainer2.Panel2.SuspendLayout();
		this.splitContainer2.SuspendLayout();
		this.panel2.SuspendLayout();
		this.panel3.SuspendLayout();
		base.SuspendLayout();
		this.comboBox1.Dock = DockStyle.Fill;
		this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
		this.comboBox1.FormattingEnabled = true;
		this.comboBox1.Items.AddRange(new object[]
		{
			"Hàng Ngày",
			"Phiêu Miễu Phong",
			"Phiêu Miễu Phong Huyết Chiến",
			"Yến Tử Ô",
			"Thiếu Thất Sơn",
			"Vương Lăng",
			"Tam Thần Huyễn Cảnh",
			"Lan Hoàn Phúc Địa",
			"Sửa Trang Bị",
			"Q Lâu Lan",
			"Q Tô Châu",
			"Sát Tinh",
			"Tứ Tuyệt Trang",
			"Luyện Kim Nhanh",
			"Luyện Kim",
			"Phân Giải Trang Bị Pet",
			"Bán Đồ - Cất Đồ - Trị Liệu",
			"Nhận x2",
			"Đông x2",
			"Nhận Chiến Công + Kiếm Chỉ",
			"Nhận Phỉ Thúy"
		});
		this.comboBox1.Location = new Point(125, 0);
		this.comboBox1.Name = "comboBox1";
		this.comboBox1.Size = new Size(228, 21);
		this.comboBox1.TabIndex = 0;
		this.button1.Dock = DockStyle.Fill;
		this.button1.Location = new Point(125, 0);
		this.button1.Name = "button1";
		this.button1.Size = new Size(228, 21);
		this.button1.TabIndex = 2;
		this.button1.Text = "Thêm";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += this.button1_Click;
		this.button3.Dock = DockStyle.Left;
		this.button3.Location = new Point(0, 0);
		this.button3.Name = "button3";
		this.button3.Size = new Size(125, 21);
		this.button3.TabIndex = 6;
		this.button3.Text = "Thêm Toàn Bộ";
		this.button3.UseVisualStyleBackColor = true;
		this.button3.Click += this.button3_Click;
		this.timer_0.Interval = 1000;
		this.timer_0.Tick += this.timer_0_Tick;
		this.contextMenuStrip1.Items.AddRange(new ToolStripItem[]
		{
			this.toolStripMenuItem_0,
			this.checkAllToolStripMenuItem,
			this.uncheckAllToolStripMenuItem
		});
		this.contextMenuStrip1.Name = "contextMenuStrip1";
		this.contextMenuStrip1.Size = new Size(138, 70);
		this.toolStripMenuItem_0.Name = "xóaToolStripMenuItem";
		this.toolStripMenuItem_0.Size = new Size(137, 22);
		this.toolStripMenuItem_0.Text = "Xóa";
		this.toolStripMenuItem_0.Click += this.toolStripMenuItem_0_Click;
		this.checkAllToolStripMenuItem.Name = "checkAllToolStripMenuItem";
		this.checkAllToolStripMenuItem.Size = new Size(137, 22);
		this.checkAllToolStripMenuItem.Text = "Check All";
		this.checkAllToolStripMenuItem.Click += this.checkAllToolStripMenuItem_Click;
		this.uncheckAllToolStripMenuItem.Name = "uncheckAllToolStripMenuItem";
		this.uncheckAllToolStripMenuItem.Size = new Size(137, 22);
		this.uncheckAllToolStripMenuItem.Text = "Uncheck All";
		this.uncheckAllToolStripMenuItem.Click += this.uncheckAllToolStripMenuItem_Click;
		this.button4.Dock = DockStyle.Left;
		this.button4.Location = new Point(0, 0);
		this.button4.Name = "button4";
		this.button4.Size = new Size(125, 22);
		this.button4.TabIndex = 7;
		this.button4.Text = "Kiểm Tra";
		this.button4.UseVisualStyleBackColor = true;
		this.button4.Click += this.button4_Click;
		this.contextMenuStrip2.Items.AddRange(new ToolStripItem[]
		{
			this.exitToolStripMenuItem
		});
		this.contextMenuStrip2.Name = "contextMenuStrip2";
		this.contextMenuStrip2.Size = new Size(94, 26);
		this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
		this.exitToolStripMenuItem.Size = new Size(93, 22);
		this.exitToolStripMenuItem.Text = "Exit";
		this.exitToolStripMenuItem.Click += this.exitToolStripMenuItem_Click;
		this.panel1.Controls.Add(this.button1);
		this.panel1.Controls.Add(this.button3);
		this.panel1.Dock = DockStyle.Top;
		this.panel1.Location = new Point(0, 22);
		this.panel1.Name = "panel1";
		this.panel1.Size = new Size(353, 21);
		this.panel1.TabIndex = 8;
		this.timer_1.Enabled = true;
		this.timer_1.Interval = 1000;
		this.timer_1.Tick += this.timer_1_Tick;
		this.splitContainer1.Dock = DockStyle.Fill;
		this.splitContainer1.IsSplitterFixed = true;
		this.splitContainer1.Location = new Point(0, 43);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Orientation = Orientation.Horizontal;
		this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
		this.splitContainer1.Panel2.Controls.Add(this.panel2);
		this.splitContainer1.Panel2MinSize = 20;
		this.splitContainer1.Size = new Size(353, 432);
		this.splitContainer1.SplitterDistance = 408;
		this.splitContainer1.SplitterWidth = 1;
		this.splitContainer1.TabIndex = 9;
		this.splitContainer2.Dock = DockStyle.Fill;
		this.splitContainer2.IsSplitterFixed = true;
		this.splitContainer2.Location = new Point(0, 0);
		this.splitContainer2.Name = "splitContainer2";
		this.splitContainer2.Panel1.Controls.Add(this.lvTask);
		this.splitContainer2.Panel2.Controls.Add(this.lvGame);
		this.splitContainer2.Panel2.Controls.Add(this.label1);
		this.splitContainer2.Panel2MinSize = 70;
		this.splitContainer2.Size = new Size(353, 408);
		this.splitContainer2.SplitterDistance = 275;
		this.splitContainer2.SplitterWidth = 1;
		this.splitContainer2.TabIndex = 2;
		this.lvTask.AllowColumnReorder = true;
		this.lvTask.AllowDrop = true;
		this.lvTask.AllowReorder = true;
		this.lvTask.AllowSort = false;
		this.lvTask.CheckBoxes = true;
		this.lvTask.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0,
			this.columnHeader_1,
			this.columnHeader_4
		});
		this.lvTask.ContextMenuStrip = this.contextMenuStrip1;
		this.lvTask.Dock = DockStyle.Fill;
		this.lvTask.DoubleClickActivation = false;
		this.lvTask.FullRowSelect = true;
		this.lvTask.GridLines = true;
		this.lvTask.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvTask.hideItems");
		this.lvTask.HideSelection = false;
		this.lvTask.LineColor = Color.Red;
		this.lvTask.Location = new Point(0, 0);
		this.lvTask.Name = "lvTask";
		this.lvTask.Size = new Size(275, 408);
		this.lvTask.TabIndex = 1;
		this.lvTask.UseCompatibleStateImageBehavior = false;
		this.lvTask.View = View.Details;
		this.lvTask.ItemCheck += this.lvTask_ItemCheck;
		this.lvTask.ItemChecked += this.lvTask_ItemChecked;
		this.lvTask.DragDrop += this.lvTask_DragDrop;
		this.columnHeader_0.Text = "Công Việc";
		this.columnHeader_0.Width = 140;
		this.columnHeader_1.Text = "Tiến Độ";
		this.columnHeader_1.Width = 70;
		this.columnHeader_4.Text = "Time";
		this.columnHeader_4.Width = 40;
		this.lvGame.Alignment = ListViewAlignment.Left;
		this.lvGame.AllowColumnReorder = true;
		this.lvGame.AllowDrop = true;
		this.lvGame.AllowReorder = true;
		this.lvGame.AllowSort = false;
		this.lvGame.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_2,
			this.columnHeader_3
		});
		this.lvGame.Dock = DockStyle.Fill;
		this.lvGame.DoubleClickActivation = false;
		this.lvGame.FullRowSelect = true;
		this.lvGame.GridLines = true;
		this.lvGame.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvGame.hideItems");
		this.lvGame.HideSelection = false;
		this.lvGame.LineColor = Color.Red;
		this.lvGame.Location = new Point(0, 16);
		this.lvGame.Name = "lvGame";
		this.lvGame.Size = new Size(77, 392);
		this.lvGame.TabIndex = 3;
		this.lvGame.UseCompatibleStateImageBehavior = false;
		this.lvGame.View = View.SmallIcon;
		this.lvGame.DoubleClick += this.lvGame_DoubleClick;
		this.columnHeader_2.Text = "Tổ Đội";
		this.columnHeader_2.Width = 128;
		this.columnHeader_3.Text = "Chức Vụ";
		this.columnHeader_3.Width = 80;
		this.label1.Dock = DockStyle.Top;
		this.label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
		this.label1.Location = new Point(0, 0);
		this.label1.Name = "label1";
		this.label1.Size = new Size(77, 16);
		this.label1.TabIndex = 4;
		this.label1.Text = "6";
		this.label1.TextAlign = ContentAlignment.MiddleCenter;
		this.label1.Click += this.label1_Click;
		this.panel2.Controls.Add(this.button2);
		this.panel2.Controls.Add(this.button5);
		this.panel2.Dock = DockStyle.Fill;
		this.panel2.Location = new Point(0, 0);
		this.panel2.Name = "panel2";
		this.panel2.Size = new Size(353, 23);
		this.panel2.TabIndex = 11;
		this.button2.Dock = DockStyle.Fill;
		this.button2.Location = new Point(125, 0);
		this.button2.Name = "button2";
		this.button2.Size = new Size(228, 23);
		this.button2.TabIndex = 5;
		this.button2.Text = "Start";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += this.button2_Click;
		this.button5.Dock = DockStyle.Left;
		this.button5.Location = new Point(0, 0);
		this.button5.Name = "button5";
		this.button5.Size = new Size(125, 23);
		this.button5.TabIndex = 0;
		this.button5.Text = "Close";
		this.button5.UseVisualStyleBackColor = true;
		this.button5.Click += this.button5_Click;
		this.panel3.Controls.Add(this.comboBox1);
		this.panel3.Controls.Add(this.button4);
		this.panel3.Dock = DockStyle.Top;
		this.panel3.Location = new Point(0, 0);
		this.panel3.Name = "panel3";
		this.panel3.Size = new Size(353, 22);
		this.panel3.TabIndex = 11;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.panel3);
		base.Name = "FastTask";
		base.Size = new Size(353, 475);
		base.Load += this.FastTask_Load;
		base.Resize += this.FastTask_Resize;
		this.contextMenuStrip1.ResumeLayout(false);
		this.contextMenuStrip2.ResumeLayout(false);
		this.panel1.ResumeLayout(false);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.ResumeLayout(false);
		this.splitContainer2.Panel1.ResumeLayout(false);
		this.splitContainer2.Panel2.ResumeLayout(false);
		this.splitContainer2.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel3.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x0600199E RID: 6558 RVA: 0x000BA890 File Offset: 0x000B8A90
	[CompilerGenerated]
	private void method_4()
	{
		Thread.CurrentThread.IsBackground = true;
		if (this.Class159_0 != null)
		{
			this.Class159_0.method_282("QUEST = '';\r\nActiveCount = GetActivePointCount();\r\nfor i = 0,ActiveCount - 1 do\r\n\tlocal id,Name,missionIndex,Level,Number,Time,Pattern,Content,activepoint,activeIsConst = EnumActivePoint(i);\r\n\tlocal level =Player:GetData('LEVEL');\r\n\tif(( id==11 or id==15 or id==7) and level < 70) then\r\n\t\tactivepoint=activepoint/2;\r\n\tend\r\n\tlocal Micount = DataPool:GetPlayerMission_DataCountByte(missionIndex/4+580,math.mod(missionIndex,4));\r\n\t\r\n\tlocal npoint = 0;\r\n\tif 2 == id and level < 60 then\r\n\t\tnpoint = 0;\r\n\telse\r\n\t\t_, npoint = EnumActivePointRatio(level);\r\n\t\tif activeIsConst == 0 then\r\n\t\t\tnpoint = math.floor(activepoint);\r\n\t\telse\r\n\t\t\tnpoint = math.floor(npoint*activepoint);\r\n\t\tend\r\n\t\tif npoint == 0 then\r\n\t\t\tnpoint = 1;\r\n\t\tend\r\n\tend\r\n\tQUEST = QUEST .. '[' .. Name..'/'..Micount..'/'..Number..'/'..npoint..']';\r\nend\r\nreturn QUEST;", false);
			this.Class159_0.method_396("AllQuest");
			Thread.Sleep(300);
			string text = this.Class159_0.method_396("AllQuest");
			string text2 = "Mèo kiểm tra thấy nhân vật này đã làm xong các nhiệm vụ sau";
			if (text.Contains("Thử Tài Vận May/1/1"))
			{
				text2 += "\r\nHàng Ngày";
			}
			if (text.Contains("Yến Tử Ổ/1/1"))
			{
				text2 += "\r\nYến Tử Ô";
			}
			if (text.Contains("Sát Tinh/2/3"))
			{
				text2 += "\r\nSát Tinh";
			}
			if (text.Contains("Tứ Tuyệt Trang/2/3"))
			{
				text2 += "\r\nTứ Tuyệt Trang";
			}
			if (text.Contains("Sơ Chiến Phiêu Miễu Phong/1/1"))
			{
				text2 += "\r\nPhiêu Miễu Phong";
			}
			if (text.Contains("Thiếu Thất Sơn/1/1"))
			{
				text2 += "\r\nThiếu Thất Sơn";
			}
			if (text.Contains("Vương Lăng/1/1"))
			{
				text2 += "\r\nVương Lăng";
			}
			if (text.Contains("Khiêu Chiến Phiêu Miễu Phong/1/1"))
			{
				text2 += "\r\nPhiêu Miễu Phong Huyết Chiến";
			}
			if (text.Contains("Kiếm Trừ Yêu Ma/1/1"))
			{
				text2 += "\r\nQ Lâu Lan";
			}
			if (text.Contains("Trừ Phỉ Phá Tam Quan/1/1"))
			{
				text2 += "\r\nQ Tô Châu";
			}
			if (text.Contains("Tam Thần Huyễn Cảnh/1/1"))
			{
				text2 += "\r\nTam Thần Huyễn Cảnh";
			}
			if (text.Contains("Lang Hoàn Phúc Địa/1/1"))
			{
				text2 += "\r\nLan Hoàn Phúc Địa";
			}
			text2 += "\r\n";
			foreach (object obj in this.lvTask.Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (listViewItem.Text == "Đang Chờ" && text2.Contains("\r\n" + listViewItem.Text + "\r\n"))
				{
					listViewItem.SubItems[1].Text = "Hoàn Thành";
				}
			}
		}
	}

	// Token: 0x04000EFF RID: 3839
	private Class159 class159_0;

	// Token: 0x04000F00 RID: 3840
	private string string_0 = "";

	// Token: 0x04000F01 RID: 3841
	[CompilerGenerated]
	private int int_0;

	// Token: 0x04000F02 RID: 3842
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x04000F03 RID: 3843
	private IContainer icontainer_0;

	// Token: 0x04000F04 RID: 3844
	private ComboBox comboBox1;

	// Token: 0x04000F05 RID: 3845
	private ListViewEx lvTask;

	// Token: 0x04000F06 RID: 3846
	private ColumnHeader columnHeader_0;

	// Token: 0x04000F07 RID: 3847
	private ColumnHeader columnHeader_1;

	// Token: 0x04000F08 RID: 3848
	private Button button1;

	// Token: 0x04000F09 RID: 3849
	private ListViewEx lvGame;

	// Token: 0x04000F0A RID: 3850
	private ColumnHeader columnHeader_2;

	// Token: 0x04000F0B RID: 3851
	private ColumnHeader columnHeader_3;

	// Token: 0x04000F0C RID: 3852
	private Button button3;

	// Token: 0x04000F0D RID: 3853
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000F0E RID: 3854
	private ContextMenuStrip contextMenuStrip1;

	// Token: 0x04000F0F RID: 3855
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000F10 RID: 3856
	private ColumnHeader columnHeader_4;

	// Token: 0x04000F11 RID: 3857
	private Button button4;

	// Token: 0x04000F12 RID: 3858
	private ToolStripMenuItem checkAllToolStripMenuItem;

	// Token: 0x04000F13 RID: 3859
	private ToolStripMenuItem uncheckAllToolStripMenuItem;

	// Token: 0x04000F14 RID: 3860
	private ContextMenuStrip contextMenuStrip2;

	// Token: 0x04000F15 RID: 3861
	private ToolStripMenuItem exitToolStripMenuItem;

	// Token: 0x04000F16 RID: 3862
	private Panel panel1;

	// Token: 0x04000F17 RID: 3863
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x04000F18 RID: 3864
	private SplitContainer splitContainer1;

	// Token: 0x04000F19 RID: 3865
	private Panel panel3;

	// Token: 0x04000F1A RID: 3866
	private Label label1;

	// Token: 0x04000F1B RID: 3867
	private SplitContainer splitContainer2;

	// Token: 0x04000F1C RID: 3868
	private Panel panel2;

	// Token: 0x04000F1D RID: 3869
	private Button button2;

	// Token: 0x04000F1E RID: 3870
	private Button button5;

	// Token: 0x020001DF RID: 479
	[CompilerGenerated]
	[Serializable]
	private sealed class Class218
	{
		// Token: 0x060019A1 RID: 6561 RVA: 0x000129A5 File Offset: 0x00010BA5
		internal bool method_0(ListViewItem listViewItem_0)
		{
			return listViewItem_0.SubItems[1].Text.Contains("Đang");
		}

		// Token: 0x060019A2 RID: 6562 RVA: 0x000129C2 File Offset: 0x00010BC2
		internal bool method_1(ListViewItem listViewItem_0)
		{
			return listViewItem_0.SubItems[1].Text == "Đang Làm";
		}

		// Token: 0x060019A3 RID: 6563 RVA: 0x000129DF File Offset: 0x00010BDF
		internal bool method_2(ListViewItem listViewItem_0)
		{
			return listViewItem_0.SubItems[1].Text.Contains("Hoàn Thành");
		}

		// Token: 0x060019A4 RID: 6564 RVA: 0x000129FC File Offset: 0x00010BFC
		internal void method_3(ListViewItem listViewItem_0)
		{
			listViewItem_0.SubItems[1].Text = "Đang Chờ";
		}

		// Token: 0x04000F1F RID: 3871
		public static readonly FastTask.Class218 <>9 = new FastTask.Class218();

		// Token: 0x04000F20 RID: 3872
		public static Func<ListViewItem, bool> <>9__15_0;

		// Token: 0x04000F21 RID: 3873
		public static Func<ListViewItem, bool> <>9__15_1;

		// Token: 0x04000F22 RID: 3874
		public static Func<ListViewItem, bool> <>9__30_0;

		// Token: 0x04000F23 RID: 3875
		public static Action<ListViewItem> <>9__30_1;
	}
}
