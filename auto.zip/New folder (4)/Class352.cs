﻿using System;

// Token: 0x02000298 RID: 664
internal class Class352
{
	// Token: 0x1700078E RID: 1934
	// (get) Token: 0x06002499 RID: 9369 RVA: 0x0001BC91 File Offset: 0x00019E91
	public static string String_0
	{
		get
		{
			return "Lạc Dương";
		}
	}

	// Token: 0x04001862 RID: 6242
	public static int int_0 = 0;

	// Token: 0x04001863 RID: 6243
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 224U,
		Int32_0 = 296,
		Int32_1 = 225,
		Int32_2 = Class352.int_0,
		String_2 = "Chu Bá Hành"
	};

	// Token: 0x04001864 RID: 6244
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 131U,
		Int32_0 = 183,
		Int32_1 = 231,
		Int32_2 = Class352.int_0,
		String_2 = "Triệu Tiền Tôn"
	};

	// Token: 0x04001865 RID: 6245
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 86U,
		Int32_0 = 235,
		Int32_1 = 322,
		Int32_2 = Class352.int_0,
		String_2 = "Ngô Đức Xương"
	};

	// Token: 0x04001866 RID: 6246
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 131U,
		Int32_0 = 330,
		Int32_1 = 299,
		Int32_2 = Class352.int_0,
		String_2 = "Kiều Phúc Thịnh"
	};

	// Token: 0x04001867 RID: 6247
	public static Class424 class424_4 = new Class424
	{
		UInt32_0 = 133U,
		Int32_0 = 239,
		Int32_1 = 204,
		Int32_2 = Class352.int_0,
		String_2 = "Trần Phu Chi"
	};

	// Token: 0x04001868 RID: 6248
	public static Class424 class424_5 = new Class424
	{
		UInt32_0 = 159U,
		Int32_0 = 230,
		Int32_1 = 308,
		Int32_2 = Class352.int_0,
		String_2 = "Bạch Manh Sinh"
	};

	// Token: 0x04001869 RID: 6249
	public static Class424 class424_6 = new Class424
	{
		UInt32_0 = 177U,
		Int32_0 = 237,
		Int32_1 = 236,
		Int32_2 = Class352.int_0,
		String_2 = "Phạm Thuần Nhân"
	};

	// Token: 0x0400186A RID: 6250
	public static Class424 class424_7 = new Class424
	{
		UInt32_0 = 58U,
		Int32_0 = 348,
		Int32_1 = 285,
		Int32_2 = Class352.int_0,
		String_2 = "Nhuế Phúc Tường"
	};

	// Token: 0x0400186B RID: 6251
	public static Class424 class424_8 = new Class424
	{
		UInt32_0 = 156U,
		Int32_0 = 361,
		Int32_1 = 183,
		Int32_2 = Class352.int_0,
		String_2 = "Khổng Tông Uyên"
	};

	// Token: 0x0400186C RID: 6252
	public static Class424 class424_9 = new Class424
	{
		UInt32_0 = 226U,
		Int32_0 = 153,
		Int32_1 = 184,
		Int32_2 = Class352.int_0,
		String_2 = "Trương Đại Thúc"
	};

	// Token: 0x0400186D RID: 6253
	public static Class424 class424_10 = new Class424
	{
		UInt32_0 = 49U,
		Int32_0 = 275,
		Int32_1 = 295,
		Int32_2 = Class352.int_0,
		String_2 = "Vân Diêu Diêu"
	};

	// Token: 0x0400186E RID: 6254
	public static Class424 class424_11 = new Class424
	{
		UInt32_0 = 17U,
		Int32_0 = 242,
		Int32_1 = 233,
		Int32_2 = Class352.int_0,
		String_2 = "Lưu Kiện Minh"
	};

	// Token: 0x0400186F RID: 6255
	public static Class424 class424_12 = new Class424
	{
		UInt32_0 = 144U,
		Int32_0 = 274,
		Int32_1 = 322,
		Int32_2 = Class352.int_0,
		String_2 = "Đào Đắc Bảo"
	};

	// Token: 0x04001870 RID: 6256
	public static Class424 class424_13 = new Class424
	{
		UInt32_0 = 227U,
		Int32_0 = 151,
		Int32_1 = 187,
		Int32_2 = Class352.int_0,
		String_2 = "Mộc Tử Tỷ Tỷ"
	};

	// Token: 0x04001871 RID: 6257
	public static Class424 class424_14 = new Class424
	{
		UInt32_0 = 187U,
		Int32_0 = 347,
		Int32_1 = 248,
		Int32_2 = Class352.int_0,
		String_2 = "Vệ tiên sinh"
	};

	// Token: 0x04001872 RID: 6258
	public static Class424 class424_15 = new Class424
	{
		UInt32_0 = 187U,
		Int32_0 = 347,
		Int32_1 = 249,
		Int32_2 = Class352.int_0,
		String_2 = "Vệ tiên sinh "
	};

	// Token: 0x04001873 RID: 6259
	public static Class424 class424_16 = new Class424
	{
		UInt32_0 = 142U,
		Int32_0 = 366,
		Int32_1 = 228,
		Int32_2 = Class352.int_0,
		String_2 = "Vương Tích Tân"
	};

	// Token: 0x04001874 RID: 6260
	public static Class424 class424_17 = new Class424
	{
		UInt32_0 = 34U,
		Int32_0 = 176,
		Int32_1 = 192,
		Int32_2 = Class352.int_0,
		String_2 = "Trí Thanh Đại Sư"
	};

	// Token: 0x04001875 RID: 6261
	public static Class424 class424_18 = new Class424
	{
		UInt32_0 = 71U,
		Int32_0 = 258,
		Int32_1 = 163,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001876 RID: 6262
	public static Class424 class424_19 = new Class424
	{
		UInt32_0 = 190U,
		Int32_0 = 256,
		Int32_1 = 320,
		Int32_2 = Class352.int_0
	};

	// Token: 0x04001877 RID: 6263
	public static Class424 class424_20 = new Class424
	{
		UInt32_0 = 192U,
		Int32_0 = 253,
		Int32_1 = 320,
		Int32_2 = Class352.int_0
	};
}
