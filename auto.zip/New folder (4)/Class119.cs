﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

// Token: 0x02000132 RID: 306
internal class Class119 : CustomTypeDescriptor
{
	// Token: 0x06000F7F RID: 3967 RVA: 0x0000CDD9 File Offset: 0x0000AFD9
	public Class119(ICustomTypeDescriptor icustomTypeDescriptor_1, object object_1) : base(icustomTypeDescriptor_1)
	{
		this.icustomTypeDescriptor_0 = icustomTypeDescriptor_1;
		this.object_0 = object_1;
	}

	// Token: 0x06000F80 RID: 3968 RVA: 0x00059048 File Offset: 0x00057248
	public virtual string GetComponentName()
	{
		Control control = this.object_0 as Control;
		if (control != null)
		{
			return control.Name;
		}
		return null;
	}

	// Token: 0x06000F81 RID: 3969 RVA: 0x0005906C File Offset: 0x0005726C
	public virtual EventDescriptorCollection GetEvents()
	{
		EventDescriptorCollection events = base.GetEvents();
		EventDescriptor[] array = new EventDescriptor[events.Count];
		for (int i = 0; i < events.Count; i++)
		{
			if (events[i].Name == "TextChanged")
			{
				array[i] = new Class120(events[i]);
			}
			else
			{
				array[i] = events[i];
			}
		}
		return new EventDescriptorCollection(array);
	}

	// Token: 0x040007FE RID: 2046
	private ICustomTypeDescriptor icustomTypeDescriptor_0;

	// Token: 0x040007FF RID: 2047
	private object object_0;
}
