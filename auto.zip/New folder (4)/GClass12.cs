﻿using System;
using System.Text;

// Token: 0x02000026 RID: 38
public class GClass12 : GClass10
{
	// Token: 0x060001E5 RID: 485 RVA: 0x000043E1 File Offset: 0x000025E1
	public GClass12(string string_1) : this(string_1, Encoding.UTF8)
	{
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x000269C8 File Offset: 0x00024BC8
	public GClass12(string string_1, Encoding encoding_0)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("content");
		}
		if (encoding_0 == null)
		{
			throw new ArgumentNullException("encoding");
		}
		this.byte_0 = encoding_0.GetBytes(string_1);
		this.int_0 = 0;
		this.int_1 = this.byte_0.Length;
		this.string_0 = "text/plain";
	}
}
