﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x020001D1 RID: 465
public class BachBaoCac : UserControl
{
	// Token: 0x06001930 RID: 6448 RVA: 0x0001252A File Offset: 0x0001072A
	public BachBaoCac()
	{
		this.InitializeComponent();
	}

	// Token: 0x06001931 RID: 6449 RVA: 0x000B42B4 File Offset: 0x000B24B4
	private void BachBaoCac_Load(object sender, EventArgs e)
	{
		this.cboPlayer.Items.Clear();
		this.cboPlayer.Items.Add(new Class339("0000FFFF", "Thiết Lập - Toàn Bộ"));
		Main.Main_0.IEnumerable_5.ToList<Class159>().ForEach(new Action<Class159>(this.method_0));
		this.cboPlayer.SelectedIndex = 0;
	}

	// Token: 0x06001932 RID: 6450 RVA: 0x000B4320 File Offset: 0x000B2520
	private void cboPlayer_SelectedIndexChanged(object sender, EventArgs e)
	{
		this.Boolean_0 = true;
		this.lvItems.Items.Cast<ListViewItem>().ToList<ListViewItem>().ForEach(new Action<ListViewItem>(BachBaoCac.Class212.<>9.method_0));
		string string_ = (this.cboPlayer.SelectedItem as Class339).String_0;
		string text = "";
		if (string_ == "0000FFFF")
		{
			this.Text = "Mua Bách Bảo - All";
			text = Class159.Class220_0.method_0("BachBao", "All") + "*" + Class159.Class220_0.method_0("QuyThi", "All");
		}
		else
		{
			foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
			{
				if (keyValuePair.Value.Class432_0.String_1 == string_)
				{
					Class159 value = keyValuePair.Value;
					this.Text = "Mua Bách Bảo - " + value.Class432_0.String_2;
					text = Class159.Class220_0.method_0("BachBao", value.Class432_0.String_0) + "*" + Class159.Class220_0.method_0("QuyThi", value.Class432_0.String_0);
				}
			}
		}
		foreach (string text2 in text.Split(new char[]
		{
			'*'
		}))
		{
			BachBaoCac.Class211 @class = new BachBaoCac.Class211();
			@class.string_0 = text2.Trim();
			if (@class.string_0.Length > 5)
			{
				this.lvItems.Items.Cast<ListViewItem>().ToList<ListViewItem>().ForEach(new Action<ListViewItem>(@class.method_0));
			}
		}
		this.Boolean_0 = false;
	}

	// Token: 0x1700063C RID: 1596
	// (get) Token: 0x06001933 RID: 6451 RVA: 0x00012538 File Offset: 0x00010738
	// (set) Token: 0x06001934 RID: 6452 RVA: 0x00012540 File Offset: 0x00010740
	private bool Boolean_0 { get; set; }

	// Token: 0x06001935 RID: 6453 RVA: 0x000B451C File Offset: 0x000B271C
	private void lvItems_ItemChecked(object sender, ItemCheckedEventArgs e)
	{
		if (this.Boolean_0)
		{
			return;
		}
		string text = "";
		foreach (ListViewItem listViewItem in this.lvItems.Items.Cast<ListViewItem>().ToList<ListViewItem>().Concat(this.lvItems.hideItems))
		{
			if (!listViewItem.Text.Contains("Quỷ Thị") && listViewItem.Checked)
			{
				text = text + "*" + listViewItem.Text;
			}
		}
		if (this.Text.Contains(" - All"))
		{
			Class159.Class220_0.method_1("BachBao", "All", text);
		}
		else
		{
			Class159.Class220_0.method_1("BachBao", Class426.smethod_51(this.Text.Replace("Mua Bách Bảo - ", "")), text);
		}
		text = "";
		foreach (ListViewItem listViewItem2 in this.lvItems.Items.Cast<ListViewItem>().ToList<ListViewItem>().Concat(this.lvItems.hideItems))
		{
			if (listViewItem2.Text.Contains("Quỷ Thị") && listViewItem2.Checked)
			{
				text = text + "*" + listViewItem2.Text;
			}
		}
		if (this.Text.Contains(" - All"))
		{
			Class159.Class220_0.method_1("QuyThi", "All", text);
			return;
		}
		Class159.Class220_0.method_1("QuyThi", Class426.smethod_51(this.Text.Replace("Mua Bách Bảo - ", "")), text);
	}

	// Token: 0x06001936 RID: 6454 RVA: 0x00012549 File Offset: 0x00010749
	private void textBoxEx1_TextChanged(object sender, EventArgs e)
	{
		this.lvItems.Search(this.textBoxEx1.Text);
	}

	// Token: 0x06001937 RID: 6455 RVA: 0x00012562 File Offset: 0x00010762
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x06001938 RID: 6456 RVA: 0x000B46EC File Offset: 0x000B28EC
	private void InitializeComponent()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BachBaoCac));
		ListViewItem listViewItem = new ListViewItem("Hoán Linh Dịch");
		ListViewItem listViewItem2 = new ListViewItem("Thiên Hoang Tinh Thạch");
		ListViewItem listViewItem3 = new ListViewItem("Thiên Linh Đan");
		ListViewItem listViewItem4 = new ListViewItem("Công Lực Đan");
		ListViewItem listViewItem5 = new ListViewItem("Tịnh Tâm Hoàn");
		ListViewItem listViewItem6 = new ListViewItem("Hồi Thiên Thần Thạch");
		ListViewItem listViewItem7 = new ListViewItem("Bách Thối Thần Ngọc");
		ListViewItem listViewItem8 = new ListViewItem("Kim Cương Sa");
		ListViewItem listViewItem9 = new ListViewItem("Hồng Diệu Thạch");
		ListViewItem listViewItem10 = new ListViewItem("Huyễn Hồn Đan");
		ListViewItem listViewItem11 = new ListViewItem("Chân Nguyên Phách");
		ListViewItem listViewItem12 = new ListViewItem("Miên Bố Cấp 3");
		ListViewItem listViewItem13 = new ListViewItem("Bí Ngân Cấp 3");
		ListViewItem listViewItem14 = new ListViewItem("Điển Tịch Chú Giải");
		ListViewItem listViewItem15 = new ListViewItem("Ngộ Linh Châu");
		ListViewItem listViewItem16 = new ListViewItem("Tử Phủ Tinh Tủy");
		ListViewItem listViewItem17 = new ListViewItem("Hào Hiệp Huy Hiệu");
		ListViewItem listViewItem18 = new ListViewItem("Ngự Tứ Lệnh Thưởng");
		ListViewItem listViewItem19 = new ListViewItem("Nhuận Vật Lộ");
		ListViewItem listViewItem20 = new ListViewItem("Thổ Linh Châu");
		ListViewItem listViewItem21 = new ListViewItem("Tử Vi Linh Phách");
		ListViewItem listViewItem22 = new ListViewItem("Phục Hy Ngọc Toái");
		ListViewItem listViewItem23 = new ListViewItem("Trung Cấp Câu Thiên Thái");
		ListViewItem listViewItem24 = new ListViewItem("Cao Cấp Câu Thiên Thái");
		ListViewItem listViewItem25 = new ListViewItem("Cửu Thiên Ngọc Toái");
		ListViewItem listViewItem26 = new ListViewItem("Huyền Binh Thạch");
		ListViewItem listViewItem27 = new ListViewItem("Chú Văn Huyết Ngọc");
		ListViewItem listViewItem28 = new ListViewItem("Tịnh Vân Thủy");
		ListViewItem listViewItem29 = new ListViewItem("Điểm Kim Ngọc");
		ListViewItem listViewItem30 = new ListViewItem("Lễ Trát-Tốt");
		ListViewItem listViewItem31 = new ListViewItem("Lễ Trát-Tinh");
		ListViewItem listViewItem32 = new ListViewItem("Tàn Ấn Tập Lục-Tốt");
		ListViewItem listViewItem33 = new ListViewItem("Thúy Ngọc Linh Châu");
		ListViewItem listViewItem34 = new ListViewItem("Ngộ Tức Đan");
		ListViewItem listViewItem35 = new ListViewItem("Mệnh Hồn Ngọc");
		ListViewItem listViewItem36 = new ListViewItem("Sơ Cấp Câu Thiên Thái Hợp Thành Phù");
		ListViewItem listViewItem37 = new ListViewItem("Trung Cấp Câu Thiên Thái Hợp Thành Phù");
		ListViewItem listViewItem38 = new ListViewItem("Mảnh Khí Định Thần Nhàn");
		ListViewItem listViewItem39 = new ListViewItem("Mảnh Lực Phá Càn Khôn");
		ListViewItem listViewItem40 = new ListViewItem("Mảnh Canh Khí Hộ Thể");
		ListViewItem listViewItem41 = new ListViewItem("Mảnh Tán Hồn Trận Thuật");
		ListViewItem listViewItem42 = new ListViewItem("Mảnh Khí Xung Tiêu Hán");
		ListViewItem listViewItem43 = new ListViewItem("Mảnh Thập Tam Thái Bảo");
		ListViewItem listViewItem44 = new ListViewItem("Mảnh Dục Huyết Tàn Thương");
		ListViewItem listViewItem45 = new ListViewItem("Mảnh Vu Cổ Kỳ Thuật");
		ListViewItem listViewItem46 = new ListViewItem("[Quỷ Thị] Phiếu Đổi Bảo Thạch Cấp 3");
		ListViewItem listViewItem47 = new ListViewItem("[Quỷ Thị] Kim Tàm Ti");
		ListViewItem listViewItem48 = new ListViewItem("[Quỷ Thị] Hồng Diệu Thạch");
		ListViewItem listViewItem49 = new ListViewItem("[Quỷ Thị] Xuyết Mộng Linh Thạch");
		ListViewItem listViewItem50 = new ListViewItem("[Quỷ Thị] Huyền Linh Đan");
		ListViewItem listViewItem51 = new ListViewItem("[Quỷ Thị] Bí Ngân Cấp 3");
		ListViewItem listViewItem52 = new ListViewItem("[Quỷ Thị] Miên Bố Cấp 3");
		ListViewItem listViewItem53 = new ListViewItem("[Quỷ Thị] Trung Cấp Câu Thiên Thái Hợp Thành Phù");
		ListViewItem listViewItem54 = new ListViewItem("[Quỷ Thị] Điển Tịch Lục Lễ Hạp");
		this.lvItems = new ListViewEx();
		this.columnHeader_0 = new ColumnHeader();
		this.cboPlayer = new ComboBox();
		this.textBoxEx1 = new Class85();
		base.SuspendLayout();
		this.lvItems.AllowColumnReorder = true;
		this.lvItems.AllowDrop = true;
		this.lvItems.AllowReorder = true;
		this.lvItems.AllowSort = false;
		this.lvItems.CheckBoxes = true;
		this.lvItems.Columns.AddRange(new ColumnHeader[]
		{
			this.columnHeader_0
		});
		this.lvItems.Dock = DockStyle.Fill;
		this.lvItems.DoubleClickActivation = false;
		this.lvItems.FullRowSelect = true;
		this.lvItems.GridLines = true;
		this.lvItems.hideItems = (List<ListViewItem>)componentResourceManager.GetObject("lvItems.hideItems");
		this.lvItems.HideSelection = false;
		listViewItem.StateImageIndex = 0;
		listViewItem2.StateImageIndex = 0;
		listViewItem3.StateImageIndex = 0;
		listViewItem4.StateImageIndex = 0;
		listViewItem5.StateImageIndex = 0;
		listViewItem6.StateImageIndex = 0;
		listViewItem7.StateImageIndex = 0;
		listViewItem8.StateImageIndex = 0;
		listViewItem9.StateImageIndex = 0;
		listViewItem10.StateImageIndex = 0;
		listViewItem11.StateImageIndex = 0;
		listViewItem12.StateImageIndex = 0;
		listViewItem13.StateImageIndex = 0;
		listViewItem14.StateImageIndex = 0;
		listViewItem15.StateImageIndex = 0;
		listViewItem16.StateImageIndex = 0;
		listViewItem17.StateImageIndex = 0;
		listViewItem18.StateImageIndex = 0;
		listViewItem19.StateImageIndex = 0;
		listViewItem20.StateImageIndex = 0;
		listViewItem21.StateImageIndex = 0;
		listViewItem22.StateImageIndex = 0;
		listViewItem23.StateImageIndex = 0;
		listViewItem24.StateImageIndex = 0;
		listViewItem25.StateImageIndex = 0;
		listViewItem26.StateImageIndex = 0;
		listViewItem27.StateImageIndex = 0;
		listViewItem28.StateImageIndex = 0;
		listViewItem29.StateImageIndex = 0;
		listViewItem30.StateImageIndex = 0;
		listViewItem31.StateImageIndex = 0;
		listViewItem32.StateImageIndex = 0;
		listViewItem33.StateImageIndex = 0;
		listViewItem34.StateImageIndex = 0;
		listViewItem35.StateImageIndex = 0;
		listViewItem36.StateImageIndex = 0;
		listViewItem37.StateImageIndex = 0;
		listViewItem38.StateImageIndex = 0;
		listViewItem39.StateImageIndex = 0;
		listViewItem40.StateImageIndex = 0;
		listViewItem41.StateImageIndex = 0;
		listViewItem42.StateImageIndex = 0;
		listViewItem43.StateImageIndex = 0;
		listViewItem44.StateImageIndex = 0;
		listViewItem45.StateImageIndex = 0;
		listViewItem46.StateImageIndex = 0;
		listViewItem47.StateImageIndex = 0;
		listViewItem48.StateImageIndex = 0;
		listViewItem49.StateImageIndex = 0;
		listViewItem50.StateImageIndex = 0;
		listViewItem51.StateImageIndex = 0;
		listViewItem52.StateImageIndex = 0;
		listViewItem53.StateImageIndex = 0;
		listViewItem54.StateImageIndex = 0;
		this.lvItems.Items.AddRange(new ListViewItem[]
		{
			listViewItem,
			listViewItem2,
			listViewItem3,
			listViewItem4,
			listViewItem5,
			listViewItem6,
			listViewItem7,
			listViewItem8,
			listViewItem9,
			listViewItem10,
			listViewItem11,
			listViewItem12,
			listViewItem13,
			listViewItem14,
			listViewItem15,
			listViewItem16,
			listViewItem17,
			listViewItem18,
			listViewItem19,
			listViewItem20,
			listViewItem21,
			listViewItem22,
			listViewItem23,
			listViewItem24,
			listViewItem25,
			listViewItem26,
			listViewItem27,
			listViewItem28,
			listViewItem29,
			listViewItem30,
			listViewItem31,
			listViewItem32,
			listViewItem33,
			listViewItem34,
			listViewItem35,
			listViewItem36,
			listViewItem37,
			listViewItem38,
			listViewItem39,
			listViewItem40,
			listViewItem41,
			listViewItem42,
			listViewItem43,
			listViewItem44,
			listViewItem45,
			listViewItem46,
			listViewItem47,
			listViewItem48,
			listViewItem49,
			listViewItem50,
			listViewItem51,
			listViewItem52,
			listViewItem53,
			listViewItem54
		});
		this.lvItems.LineColor = Color.Red;
		this.lvItems.Location = new Point(0, 20);
		this.lvItems.Name = "lvItems";
		this.lvItems.Size = new Size(312, 316);
		this.lvItems.TabIndex = 0;
		this.lvItems.UseCompatibleStateImageBehavior = false;
		this.lvItems.View = View.Details;
		this.lvItems.ItemChecked += this.lvItems_ItemChecked;
		this.columnHeader_0.Text = "Name";
		this.columnHeader_0.Width = 255;
		this.cboPlayer.Dock = DockStyle.Bottom;
		this.cboPlayer.DropDownStyle = ComboBoxStyle.DropDownList;
		this.cboPlayer.FormattingEnabled = true;
		this.cboPlayer.Items.AddRange(new object[]
		{
			"Thiết Lập Dành Cho Tất Cả"
		});
		this.cboPlayer.Location = new Point(0, 336);
		this.cboPlayer.Name = "cboPlayer";
		this.cboPlayer.Size = new Size(312, 21);
		this.cboPlayer.TabIndex = 238;
		this.cboPlayer.SelectedIndexChanged += this.cboPlayer_SelectedIndexChanged;
		this.textBoxEx1.Dock = DockStyle.Top;
		this.textBoxEx1.Location = new Point(0, 0);
		this.textBoxEx1.Name = "textBoxEx1";
		this.textBoxEx1.Size = new Size(312, 20);
		this.textBoxEx1.TabIndex = 239;
		this.textBoxEx1.String_0 = "Search...";
		this.textBoxEx1.Color_0 = Color.Gray;
		this.textBoxEx1.Font_0 = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
		this.textBoxEx1.Color_1 = Color.LightGray;
		this.textBoxEx1.TextChanged += this.textBoxEx1_TextChanged;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(312, 357);
		base.Controls.Add(this.lvItems);
		base.Controls.Add(this.textBoxEx1);
		base.Controls.Add(this.cboPlayer);
		base.Name = "BachBaoCac";
		this.Text = "Tự Mua Đồ Shop";
		base.Load += this.BachBaoCac_Load;
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x06001939 RID: 6457 RVA: 0x00012581 File Offset: 0x00010781
	[CompilerGenerated]
	private void method_0(Class159 class159_0)
	{
		this.cboPlayer.Items.Add(new Class339(class159_0.Class432_0.String_1, "Thiết Lập - " + class159_0.Class432_0.String_2));
	}

	// Token: 0x04000EC0 RID: 3776
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x04000EC1 RID: 3777
	private IContainer icontainer_0;

	// Token: 0x04000EC2 RID: 3778
	private ListViewEx lvItems;

	// Token: 0x04000EC3 RID: 3779
	private ColumnHeader columnHeader_0;

	// Token: 0x04000EC4 RID: 3780
	private ComboBox cboPlayer;

	// Token: 0x04000EC5 RID: 3781
	private Class85 textBoxEx1;

	// Token: 0x020001D2 RID: 466
	[CompilerGenerated]
	private sealed class Class211
	{
		// Token: 0x0600193B RID: 6459 RVA: 0x000125B9 File Offset: 0x000107B9
		internal void method_0(ListViewItem listViewItem_0)
		{
			if (listViewItem_0.Text == this.string_0)
			{
				listViewItem_0.Checked = true;
			}
		}

		// Token: 0x04000EC6 RID: 3782
		public string string_0;
	}

	// Token: 0x020001D3 RID: 467
	[CompilerGenerated]
	[Serializable]
	private sealed class Class212
	{
		// Token: 0x0600193E RID: 6462 RVA: 0x000125E1 File Offset: 0x000107E1
		internal void method_0(ListViewItem listViewItem_0)
		{
			listViewItem_0.Checked = false;
		}

		// Token: 0x04000EC7 RID: 3783
		public static readonly BachBaoCac.Class212 <>9 = new BachBaoCac.Class212();

		// Token: 0x04000EC8 RID: 3784
		public static Action<ListViewItem> <>9__2_0;
	}
}
