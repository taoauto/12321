﻿using System;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x02000097 RID: 151
public sealed class GClass40
{
	// Token: 0x06000705 RID: 1797 RVA: 0x000078BB File Offset: 0x00005ABB
	internal GClass40(GClass38 gclass38_1)
	{
		this.gclass38_0 = gclass38_1;
		this.class70_0 = gclass38_1.Class70_0;
		this.long_0 = -1L;
		this.gclass45_0 = new GClass45();
		this.guid_0 = Guid.NewGuid();
	}

	// Token: 0x170001DF RID: 479
	// (get) Token: 0x06000706 RID: 1798 RVA: 0x00037950 File Offset: 0x00035B50
	public string[] String_0
	{
		get
		{
			string text = this.gclass45_0["Accept"];
			if (text == null)
			{
				return null;
			}
			if (this.string_0 == null)
			{
				this.string_0 = text.smethod_59(new char[]
				{
					','
				}).smethod_68().smethod_64<string>().ToArray();
			}
			return this.string_0;
		}
	}

	// Token: 0x170001E0 RID: 480
	// (get) Token: 0x06000707 RID: 1799 RVA: 0x00004192 File Offset: 0x00002392
	public int Int32_0
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	// Token: 0x170001E1 RID: 481
	// (get) Token: 0x06000708 RID: 1800 RVA: 0x000078F4 File Offset: 0x00005AF4
	public Encoding Encoding_0
	{
		get
		{
			if (this.encoding_0 == null)
			{
				this.encoding_0 = (this.method_1() ?? Encoding.UTF8);
			}
			return this.encoding_0;
		}
	}

	// Token: 0x170001E2 RID: 482
	// (get) Token: 0x06000709 RID: 1801 RVA: 0x00007919 File Offset: 0x00005B19
	public long Int64_0
	{
		get
		{
			return this.long_0;
		}
	}

	// Token: 0x170001E3 RID: 483
	// (get) Token: 0x0600070A RID: 1802 RVA: 0x00007921 File Offset: 0x00005B21
	public string String_1
	{
		get
		{
			return this.gclass45_0["Content-Type"];
		}
	}

	// Token: 0x170001E4 RID: 484
	// (get) Token: 0x0600070B RID: 1803 RVA: 0x00007933 File Offset: 0x00005B33
	public GClass34 GClass34_0
	{
		get
		{
			if (this.gclass34_0 == null)
			{
				this.gclass34_0 = this.gclass45_0.smethod_30(false);
			}
			return this.gclass34_0;
		}
	}

	// Token: 0x170001E5 RID: 485
	// (get) Token: 0x0600070C RID: 1804 RVA: 0x00007955 File Offset: 0x00005B55
	public bool Boolean_0
	{
		get
		{
			return this.long_0 > 0L || this.bool_0;
		}
	}

	// Token: 0x170001E6 RID: 486
	// (get) Token: 0x0600070D RID: 1805 RVA: 0x00007969 File Offset: 0x00005B69
	public NameValueCollection NameValueCollection_0
	{
		get
		{
			return this.gclass45_0;
		}
	}

	// Token: 0x170001E7 RID: 487
	// (get) Token: 0x0600070E RID: 1806 RVA: 0x00007971 File Offset: 0x00005B71
	public string String_2
	{
		get
		{
			return this.string_1;
		}
	}

	// Token: 0x170001E8 RID: 488
	// (get) Token: 0x0600070F RID: 1807 RVA: 0x00007979 File Offset: 0x00005B79
	public Stream Stream_0
	{
		get
		{
			if (this.stream_0 == null)
			{
				this.stream_0 = (this.method_2() ?? Stream.Null);
			}
			return this.stream_0;
		}
	}

	// Token: 0x170001E9 RID: 489
	// (get) Token: 0x06000710 RID: 1808 RVA: 0x0000799E File Offset: 0x00005B9E
	public bool Boolean_1
	{
		get
		{
			return this.gclass38_0.IPrincipal_0 != null;
		}
	}

	// Token: 0x170001EA RID: 490
	// (get) Token: 0x06000711 RID: 1809 RVA: 0x000079AE File Offset: 0x00005BAE
	public bool Boolean_2
	{
		get
		{
			return this.class70_0.Boolean_1;
		}
	}

	// Token: 0x170001EB RID: 491
	// (get) Token: 0x06000712 RID: 1810 RVA: 0x000079BB File Offset: 0x00005BBB
	public bool Boolean_3
	{
		get
		{
			return this.class70_0.Boolean_2;
		}
	}

	// Token: 0x170001EC RID: 492
	// (get) Token: 0x06000713 RID: 1811 RVA: 0x000079C8 File Offset: 0x00005BC8
	public bool Boolean_4
	{
		get
		{
			return this.string_1 == "GET" && this.version_0 > GClass42.version_0 && this.gclass45_0.smethod_77("websocket");
		}
	}

	// Token: 0x170001ED RID: 493
	// (get) Token: 0x06000714 RID: 1812 RVA: 0x00007A00 File Offset: 0x00005C00
	public bool Boolean_5
	{
		get
		{
			return this.gclass45_0.smethod_52(this.version_0);
		}
	}

	// Token: 0x170001EE RID: 494
	// (get) Token: 0x06000715 RID: 1813 RVA: 0x00007A13 File Offset: 0x00005C13
	public IPEndPoint IPEndPoint_0
	{
		get
		{
			return this.class70_0.IPEndPoint_0;
		}
	}

	// Token: 0x170001EF RID: 495
	// (get) Token: 0x06000716 RID: 1814 RVA: 0x00007A20 File Offset: 0x00005C20
	public Version Version_0
	{
		get
		{
			return this.version_0;
		}
	}

	// Token: 0x170001F0 RID: 496
	// (get) Token: 0x06000717 RID: 1815 RVA: 0x000379A8 File Offset: 0x00035BA8
	public NameValueCollection NameValueCollection_1
	{
		get
		{
			if (this.nameValueCollection_0 == null)
			{
				Uri uri = this.Uri_0;
				this.nameValueCollection_0 = Class79.smethod_2((uri != null) ? uri.Query : null, Encoding.UTF8);
			}
			return this.nameValueCollection_0;
		}
	}

	// Token: 0x170001F1 RID: 497
	// (get) Token: 0x06000718 RID: 1816 RVA: 0x00007A28 File Offset: 0x00005C28
	public string String_3
	{
		get
		{
			return this.string_2;
		}
	}

	// Token: 0x170001F2 RID: 498
	// (get) Token: 0x06000719 RID: 1817 RVA: 0x00007A30 File Offset: 0x00005C30
	public IPEndPoint IPEndPoint_1
	{
		get
		{
			return this.class70_0.IPEndPoint_1;
		}
	}

	// Token: 0x170001F3 RID: 499
	// (get) Token: 0x0600071A RID: 1818 RVA: 0x00007A3D File Offset: 0x00005C3D
	public Guid Guid_0
	{
		get
		{
			return this.guid_0;
		}
	}

	// Token: 0x170001F4 RID: 500
	// (get) Token: 0x0600071B RID: 1819 RVA: 0x000379EC File Offset: 0x00035BEC
	public Uri Uri_0
	{
		get
		{
			if (!this.bool_1)
			{
				this.uri_0 = Class78.smethod_15(this.string_2, this.string_3 ?? this.String_5, this.Boolean_4, this.Boolean_3);
				this.bool_1 = true;
			}
			return this.uri_0;
		}
	}

	// Token: 0x170001F5 RID: 501
	// (get) Token: 0x0600071C RID: 1820 RVA: 0x00037A3C File Offset: 0x00035C3C
	public Uri Uri_1
	{
		get
		{
			string text = this.gclass45_0["Referer"];
			if (text == null)
			{
				return null;
			}
			if (this.uri_1 == null)
			{
				this.uri_1 = text.smethod_105();
			}
			return this.uri_1;
		}
	}

	// Token: 0x170001F6 RID: 502
	// (get) Token: 0x0600071D RID: 1821 RVA: 0x00007A45 File Offset: 0x00005C45
	public string String_4
	{
		get
		{
			return this.gclass45_0["User-Agent"];
		}
	}

	// Token: 0x170001F7 RID: 503
	// (get) Token: 0x0600071E RID: 1822 RVA: 0x00007A57 File Offset: 0x00005C57
	public string String_5
	{
		get
		{
			return this.class70_0.IPEndPoint_0.ToString();
		}
	}

	// Token: 0x170001F8 RID: 504
	// (get) Token: 0x0600071F RID: 1823 RVA: 0x00007A69 File Offset: 0x00005C69
	public string String_6
	{
		get
		{
			return this.string_3;
		}
	}

	// Token: 0x170001F9 RID: 505
	// (get) Token: 0x06000720 RID: 1824 RVA: 0x00037A80 File Offset: 0x00035C80
	public string[] String_7
	{
		get
		{
			string text = this.gclass45_0["Accept-Language"];
			if (text == null)
			{
				return null;
			}
			if (this.string_4 == null)
			{
				this.string_4 = text.Split(new char[]
				{
					','
				}).smethod_68().smethod_64<string>().ToArray();
			}
			return this.string_4;
		}
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x00037AD8 File Offset: 0x00035CD8
	private void method_0()
	{
		if (this.gclass45_0["Transfer-Encoding"] != null)
		{
			this.gclass38_0.String_0 = "Invalid Transfer-Encoding header";
			return;
		}
		if (this.string_1 == "POST")
		{
			if (this.long_0 == -1L)
			{
				this.gclass38_0.String_0 = "Content-Length header required";
				return;
			}
			if (this.long_0 == 0L)
			{
				this.gclass38_0.String_0 = "Invalid Content-Length header";
				return;
			}
		}
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x00037B50 File Offset: 0x00035D50
	private Encoding method_1()
	{
		string text = this.gclass45_0["Content-Type"];
		if (text == null)
		{
			return null;
		}
		Encoding result;
		Class78.smethod_18(text, out result);
		return result;
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x00007A71 File Offset: 0x00005C71
	private Stream2 method_2()
	{
		if (this.long_0 <= 0L && !this.bool_0)
		{
			return null;
		}
		return this.class70_0.method_13(this.long_0, this.bool_0);
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x00037B80 File Offset: 0x00035D80
	internal void method_3(string string_5)
	{
		char c = string_5[0];
		if (c != ' ')
		{
			if (c != '\t')
			{
				int num = string_5.IndexOf(':');
				if (num < 1)
				{
					this.gclass38_0.String_0 = "Invalid header field";
					return;
				}
				string text = string_5.Substring(0, num).Trim();
				if (text.Length == 0 || !text.smethod_51())
				{
					this.gclass38_0.String_0 = "Invalid header name";
					return;
				}
				string text2 = (num < string_5.Length - 1) ? string_5.Substring(num + 1).Trim() : string.Empty;
				this.gclass45_0.method_6(text, text2, false);
				string a = text.ToLower(CultureInfo.InvariantCulture);
				if (a == "host")
				{
					if (this.string_3 != null)
					{
						this.gclass38_0.String_0 = "Invalid Host header";
						return;
					}
					if (text2.Length == 0)
					{
						this.gclass38_0.String_0 = "Invalid Host header";
						return;
					}
					this.string_3 = text2;
					return;
				}
				else
				{
					if (!(a == "content-length"))
					{
						return;
					}
					if (this.long_0 > -1L)
					{
						this.gclass38_0.String_0 = "Invalid Content-Length header";
						return;
					}
					long num2;
					if (!long.TryParse(text2, out num2))
					{
						this.gclass38_0.String_0 = "Invalid Content-Length header";
						return;
					}
					if (num2 < 0L)
					{
						this.gclass38_0.String_0 = "Invalid Content-Length header";
						return;
					}
					this.long_0 = num2;
					return;
				}
			}
		}
		this.gclass38_0.String_0 = "Invalid header field";
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x00037CF4 File Offset: 0x00035EF4
	internal void method_4()
	{
		if (this.version_0 == GClass42.version_0)
		{
			this.method_0();
			return;
		}
		if (this.string_3 == null)
		{
			this.gclass38_0.String_0 = "Host header required";
			return;
		}
		string text = this.gclass45_0["Transfer-Encoding"];
		if (text != null)
		{
			if (!text.Equals("chunked", StringComparison.OrdinalIgnoreCase))
			{
				this.gclass38_0.String_0 = string.Empty;
				this.gclass38_0.Int32_0 = 501;
				return;
			}
			this.bool_0 = true;
		}
		if ((this.string_1 == "POST" || this.string_1 == "PUT") && this.long_0 <= 0L && !this.bool_0)
		{
			this.gclass38_0.String_0 = string.Empty;
			this.gclass38_0.Int32_0 = 411;
			return;
		}
		string text2 = this.gclass45_0["Expect"];
		if (text2 != null)
		{
			if (!text2.Equals("100-continue", StringComparison.OrdinalIgnoreCase))
			{
				this.gclass38_0.String_0 = "Invalid Expect header";
				return;
			}
			this.class70_0.method_14().method_7(GClass40.byte_0, 0, GClass40.byte_0.Length);
		}
	}

	// Token: 0x06000726 RID: 1830 RVA: 0x00037E24 File Offset: 0x00036024
	internal bool method_5()
	{
		Stream stream = this.Stream_0;
		if (stream == Stream.Null)
		{
			return true;
		}
		int num = 2048;
		if (this.long_0 > 0L && this.long_0 < (long)num)
		{
			num = (int)this.long_0;
		}
		byte[] buffer = new byte[num];
		bool result;
		for (;;)
		{
			try
			{
				IAsyncResult asyncResult = stream.BeginRead(buffer, 0, num, null, null);
				if (!asyncResult.IsCompleted && !asyncResult.AsyncWaitHandle.WaitOne(100))
				{
					result = false;
					break;
				}
				if (stream.EndRead(asyncResult) <= 0)
				{
					result = true;
					break;
				}
			}
			catch
			{
				result = false;
				break;
			}
		}
		return result;
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x00007A9E File Offset: 0x00005C9E
	internal bool method_6(string string_5)
	{
		return this.gclass45_0.smethod_77(string_5);
	}

	// Token: 0x06000728 RID: 1832 RVA: 0x00037EC4 File Offset: 0x000360C4
	internal void method_7(string string_5)
	{
		string[] array = string_5.Split(new char[]
		{
			' '
		}, 3);
		if (array.Length < 3)
		{
			this.gclass38_0.String_0 = "Invalid request line (parts)";
			return;
		}
		string text = array[0];
		if (text.Length == 0)
		{
			this.gclass38_0.String_0 = "Invalid request line (method)";
			return;
		}
		string text2 = array[1];
		if (text2.Length == 0)
		{
			this.gclass38_0.String_0 = "Invalid request line (target)";
			return;
		}
		string text3 = array[2];
		if (text3.Length != 8)
		{
			this.gclass38_0.String_0 = "Invalid request line (version)";
			return;
		}
		if (text3.IndexOf("HTTP/") != 0)
		{
			this.gclass38_0.String_0 = "Invalid request line (version)";
			return;
		}
		Version version;
		if (!text3.Substring(5).smethod_71(out version))
		{
			this.gclass38_0.String_0 = "Invalid request line (version)";
			return;
		}
		if (version.Major < 1)
		{
			this.gclass38_0.String_0 = "Invalid request line (version)";
			return;
		}
		if (!text.smethod_45(version))
		{
			this.gclass38_0.String_0 = "Invalid request line (method)";
			return;
		}
		this.string_1 = text;
		this.string_2 = text2;
		this.version_0 = version;
	}

	// Token: 0x06000729 RID: 1833 RVA: 0x00004192 File Offset: 0x00002392
	public IAsyncResult method_8(AsyncCallback asyncCallback_0, object object_0)
	{
		throw new NotSupportedException();
	}

	// Token: 0x0600072A RID: 1834 RVA: 0x00004192 File Offset: 0x00002392
	public X509Certificate2 method_9(IAsyncResult iasyncResult_0)
	{
		throw new NotSupportedException();
	}

	// Token: 0x0600072B RID: 1835 RVA: 0x00004192 File Offset: 0x00002392
	public X509Certificate2 method_10()
	{
		throw new NotSupportedException();
	}

	// Token: 0x0600072C RID: 1836 RVA: 0x00007AAC File Offset: 0x00005CAC
	public string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(64);
		stringBuilder.AppendFormat("{0} {1} HTTP/{2}\r\n", this.string_1, this.string_2, this.version_0).Append(this.gclass45_0.ToString());
		return stringBuilder.ToString();
	}

	// Token: 0x04000367 RID: 871
	private static readonly byte[] byte_0 = Encoding.ASCII.GetBytes("HTTP/1.1 100 Continue\r\n\r\n");

	// Token: 0x04000368 RID: 872
	private string[] string_0;

	// Token: 0x04000369 RID: 873
	private bool bool_0;

	// Token: 0x0400036A RID: 874
	private Class70 class70_0;

	// Token: 0x0400036B RID: 875
	private Encoding encoding_0;

	// Token: 0x0400036C RID: 876
	private long long_0;

	// Token: 0x0400036D RID: 877
	private GClass38 gclass38_0;

	// Token: 0x0400036E RID: 878
	private GClass34 gclass34_0;

	// Token: 0x0400036F RID: 879
	private GClass45 gclass45_0;

	// Token: 0x04000370 RID: 880
	private string string_1;

	// Token: 0x04000371 RID: 881
	private Stream stream_0;

	// Token: 0x04000372 RID: 882
	private Version version_0;

	// Token: 0x04000373 RID: 883
	private NameValueCollection nameValueCollection_0;

	// Token: 0x04000374 RID: 884
	private string string_2;

	// Token: 0x04000375 RID: 885
	private Guid guid_0;

	// Token: 0x04000376 RID: 886
	private Uri uri_0;

	// Token: 0x04000377 RID: 887
	private Uri uri_1;

	// Token: 0x04000378 RID: 888
	private bool bool_1;

	// Token: 0x04000379 RID: 889
	private string string_3;

	// Token: 0x0400037A RID: 890
	private string[] string_4;
}
