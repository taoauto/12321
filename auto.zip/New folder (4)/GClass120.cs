﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000195 RID: 405
public static class GClass120
{
	// Token: 0x06001274 RID: 4724
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool CloseHandle(IntPtr intptr_0);

	// Token: 0x06001275 RID: 4725 RVA: 0x000696F4 File Offset: 0x000678F4
	public static IntPtr smethod_0(IntPtr intptr_0, byte[] byte_0, int int_0)
	{
		IntPtr intPtr = IntPtr.Zero;
		if (byte_0 != null && intptr_0 != IntPtr.Zero)
		{
			intPtr = GClass120.VirtualAllocEx(intptr_0, IntPtr.Zero, (uint)byte_0.Length, 12288, int_0);
			uint num = 0U;
			if (intPtr != IntPtr.Zero && GClass120.WriteProcessMemory(intptr_0, intPtr, byte_0, byte_0.Length, out num) && (ulong)num == (ulong)((long)byte_0.Length))
			{
				return intPtr;
			}
			if (intPtr != IntPtr.Zero)
			{
				GClass120.VirtualFreeEx(intptr_0, intPtr, 0, 32768);
				intPtr = IntPtr.Zero;
			}
		}
		return intPtr;
	}

	// Token: 0x06001276 RID: 4726
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern IntPtr CreateRemoteThread(IntPtr intptr_0, int int_0, int int_1, IntPtr intptr_1, uint uint_0, int int_2, int int_3);

	// Token: 0x06001277 RID: 4727
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool GetExitCodeThread(IntPtr intptr_0, out uint uint_0);

	// Token: 0x06001278 RID: 4728 RVA: 0x00069778 File Offset: 0x00067978
	public static uint smethod_1(IntPtr intptr_0)
	{
		IntPtr procAddress = GClass120.GetProcAddress(GClass120.GetModuleHandleA("kernel32.dll"), "GetLastError");
		return GClass120.smethod_7(intptr_0, procAddress, 0U, 1000);
	}

	// Token: 0x06001279 RID: 4729
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern IntPtr GetModuleHandleA(string string_0);

	// Token: 0x0600127A RID: 4730 RVA: 0x000697A8 File Offset: 0x000679A8
	public static IntPtr smethod_2(IntPtr intptr_0, string string_0)
	{
		IntPtr procAddress = GClass120.GetProcAddress(GClass120.GetModuleHandleA("kernel32.dll"), "GetModuleHandleW");
		IntPtr result = IntPtr.Zero;
		if (!procAddress.smethod_4())
		{
			IntPtr intPtr = GClass120.smethod_0(intptr_0, Encoding.Unicode.GetBytes(string_0 + "\0"), 4);
			if (!intPtr.smethod_4())
			{
				result = GClass119.smethod_3((long)((ulong)GClass120.smethod_7(intptr_0, procAddress, (uint)intPtr.ToInt32(), 1000)));
				GClass120.VirtualFreeEx(intptr_0, intPtr, 0, 32768);
			}
		}
		return result;
	}

	// Token: 0x0600127B RID: 4731
	[DllImport("kernel32.dll")]
	public static extern IntPtr LoadLibrary(string string_0);

	// Token: 0x0600127C RID: 4732
	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
	public static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

	// Token: 0x0600127D RID: 4733
	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", SetLastError = true)]
	public static extern IntPtr GetProcAddress_1(IntPtr intptr_0, uint uint_0);

	// Token: 0x0600127E RID: 4734 RVA: 0x00069828 File Offset: 0x00067A28
	public static IntPtr smethod_3(IntPtr intptr_0, IntPtr intptr_1, object object_0)
	{
		IntPtr result = IntPtr.Zero;
		byte[] array = GClass120.smethod_4(intptr_0, intptr_1, 64U);
		if (array != null)
		{
			if (BitConverter.ToUInt16(array, 0) == 23117)
			{
				uint num = BitConverter.ToUInt32(array, 60);
				if (num <= 0U)
				{
					return result;
				}
				byte[] array2 = GClass120.smethod_4(intptr_0, intptr_1.smethod_0((long)((ulong)num)), 264U);
				if (array2 != null)
				{
					if (BitConverter.ToUInt32(array2, 0) == 17744U)
					{
						uint num2 = BitConverter.ToUInt32(array2, 120);
						uint num3 = BitConverter.ToUInt32(array2, 124);
						if (num2 <= 0U || num3 <= 0U)
						{
							return result;
						}
						byte[] array3 = GClass120.smethod_4(intptr_0, intptr_1.smethod_0((long)((ulong)num2)), 40U);
						uint num4 = BitConverter.ToUInt32(array3, 28);
						uint num5 = BitConverter.ToUInt32(array3, 36);
						uint num6 = BitConverter.ToUInt32(array3, 20);
						int num7 = -1;
						if (num4 <= 0U || num5 <= 0U)
						{
							return result;
						}
						if (object_0.GetType().Equals(typeof(string)))
						{
							int num8 = GClass120.smethod_8(intptr_0, intptr_1, array3, (string)object_0);
							if (num8 > -1)
							{
								byte[] array4 = GClass120.smethod_4(intptr_0, intptr_1.smethod_0((long)((ulong)num5 + (ulong)((long)((long)num8 << 1)))), 2U);
								num7 = ((array4 == null) ? -1 : ((int)BitConverter.ToUInt16(array4, 0)));
							}
						}
						else if (object_0.GetType().Equals(typeof(short)) || object_0.GetType().Equals(typeof(ushort)))
						{
							num7 = int.Parse(object_0.ToString());
						}
						if (num7 <= -1 || (long)num7 >= (long)((ulong)num6))
						{
							return result;
						}
						byte[] array5 = GClass120.smethod_4(intptr_0, intptr_1.smethod_0((long)((ulong)num4 + (ulong)((long)((long)num7 << 2)))), 4U);
						if (array5 == null)
						{
							return result;
						}
						uint num9 = BitConverter.ToUInt32(array5, 0);
						if (num9 >= num2 && num9 < num2 + num3)
						{
							string text = GClass120.smethod_6(intptr_0, intptr_1.smethod_0((long)((ulong)num9)), null);
							if (!string.IsNullOrEmpty(text) && text.Contains("."))
							{
								result = GClass120.smethod_3(intptr_0, GClass120.smethod_2(intptr_0, text.Split(new char[]
								{
									'.'
								})[0]), text.Split(new char[]
								{
									'.'
								})[1]);
							}
							return result;
						}
						return intptr_1.smethod_0((long)((ulong)num9));
					}
				}
				return result;
			}
		}
		return result;
	}

	// Token: 0x0600127F RID: 4735
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern int GetProcessId(IntPtr intptr_0);

	// Token: 0x06001280 RID: 4736
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool GetThreadContext(IntPtr intptr_0, ref GClass120.GStruct18 gstruct18_0);

	// Token: 0x06001281 RID: 4737
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern IntPtr OpenProcess(uint uint_0, bool bool_0, int int_0);

	// Token: 0x06001282 RID: 4738
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern IntPtr OpenThread(uint uint_0, bool bool_0, int int_0);

	// Token: 0x06001283 RID: 4739
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool ReadProcessMemory(IntPtr intptr_0, IntPtr intptr_1, byte[] byte_0, int int_0, out uint uint_0);

	// Token: 0x06001284 RID: 4740 RVA: 0x00069A58 File Offset: 0x00067C58
	public static byte[] smethod_4(IntPtr intptr_0, IntPtr intptr_1, uint uint_0)
	{
		byte[] array = new byte[uint_0];
		uint num = 0U;
		if (!GClass120.ReadProcessMemory(intptr_0, intptr_1, array, array.Length, out num) || num != uint_0)
		{
			array = null;
		}
		return array;
	}

	// Token: 0x06001285 RID: 4741 RVA: 0x00069A84 File Offset: 0x00067C84
	public static IntPtr smethod_5(IntPtr intptr_0, IntPtr intptr_1)
	{
		IntPtr zero = IntPtr.Zero;
		if (!intptr_0.smethod_4() && !intptr_1.smethod_4())
		{
			byte[] array = GClass120.smethod_4(intptr_0, intptr_1, (uint)IntPtr.Size);
			if (array != null)
			{
				zero = new IntPtr(BitConverter.ToInt32(array, 0));
			}
		}
		return zero;
	}

	// Token: 0x06001286 RID: 4742 RVA: 0x00069AC8 File Offset: 0x00067CC8
	public static string smethod_6(IntPtr intptr_0, IntPtr intptr_1, Encoding encoding_0 = null)
	{
		if (encoding_0 == null)
		{
			encoding_0 = Encoding.ASCII;
		}
		StringBuilder stringBuilder = new StringBuilder();
		byte[] array = new byte[256];
		uint num = 0U;
		int num2 = -1;
		while (num2 < 0 && GClass120.ReadProcessMemory(intptr_0, intptr_1, array, array.Length, out num) && num > 0U)
		{
			intptr_1 = intptr_1.smethod_0((long)((ulong)num));
			int length = stringBuilder.Length;
			stringBuilder.Append(encoding_0.GetString(array, 0, (int)num));
			num2 = stringBuilder.ToString().IndexOf('\0', length);
		}
		return stringBuilder.ToString().Substring(0, num2);
	}

	// Token: 0x06001287 RID: 4743
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern uint ResumeThread(IntPtr intptr_0);

	// Token: 0x06001288 RID: 4744 RVA: 0x00069B50 File Offset: 0x00067D50
	public static uint smethod_7(IntPtr intptr_0, IntPtr intptr_1, uint uint_0, int int_0 = 1000)
	{
		uint maxValue = uint.MaxValue;
		IntPtr intPtr = GClass120.CreateRemoteThread(intptr_0, 0, 0, intptr_1, uint_0, 0, 0);
		if (intPtr != IntPtr.Zero && (ulong)GClass120.WaitForSingleObject(intPtr, int_0) == 0UL)
		{
			GClass120.GetExitCodeThread(intPtr, out maxValue);
		}
		return maxValue;
	}

	// Token: 0x06001289 RID: 4745 RVA: 0x00069B90 File Offset: 0x00067D90
	private static int smethod_8(IntPtr intptr_0, IntPtr intptr_1, byte[] byte_0, string string_0)
	{
		uint num = BitConverter.ToUInt32(byte_0, 24);
		uint num2 = BitConverter.ToUInt32(byte_0, 32);
		int num3 = -1;
		if (num > 0U && num2 > 0U)
		{
			byte[] array = GClass120.smethod_4(intptr_0, intptr_1.smethod_0((long)((ulong)num2)), num << 2);
			if (array == null)
			{
				return num3;
			}
			uint[] array2 = new uint[num];
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i] = BitConverter.ToUInt32(array, i << 2);
			}
			int num4 = 0;
			int num5 = array2.Length - 1;
			string text = string.Empty;
			while (num4 >= 0 && num4 <= num5)
			{
				if (num3 != -1)
				{
					break;
				}
				int num6 = (num4 + num5) / 2;
				text = GClass120.smethod_6(intptr_0, intptr_1.smethod_0((long)((ulong)array2[num6])), null);
				if (text.Equals(string_0))
				{
					num3 = num6;
				}
				else if (string.CompareOrdinal(text, string_0) < 0)
				{
					num4 = num6 - 1;
				}
				else
				{
					num5 = num6 + 1;
				}
			}
		}
		return num3;
	}

	// Token: 0x0600128A RID: 4746
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool SetThreadContext(IntPtr intptr_0, ref GClass120.GStruct18 gstruct18_0);

	// Token: 0x0600128B RID: 4747
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern uint SuspendThread(IntPtr intptr_0);

	// Token: 0x0600128C RID: 4748
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern IntPtr VirtualAllocEx(IntPtr intptr_0, IntPtr intptr_1, uint uint_0, int int_0, int int_1);

	// Token: 0x0600128D RID: 4749
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool VirtualFreeEx(IntPtr intptr_0, IntPtr intptr_1, int int_0, int int_1);

	// Token: 0x0600128E RID: 4750
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool VirtualProtectEx(IntPtr intptr_0, IntPtr intptr_1, uint uint_0, uint uint_1, out uint uint_2);

	// Token: 0x0600128F RID: 4751
	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern uint WaitForSingleObject(IntPtr intptr_0, int int_0);

	// Token: 0x06001290 RID: 4752
	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool WriteProcessMemory(IntPtr intptr_0, IntPtr intptr_1, byte[] byte_0, int int_0, out uint uint_0);

	// Token: 0x02000196 RID: 406
	public struct GStruct18
	{
		// Token: 0x04000A32 RID: 2610
		public uint uint_0;

		// Token: 0x04000A33 RID: 2611
		public uint uint_1;

		// Token: 0x04000A34 RID: 2612
		public uint uint_2;

		// Token: 0x04000A35 RID: 2613
		public uint uint_3;

		// Token: 0x04000A36 RID: 2614
		public uint uint_4;

		// Token: 0x04000A37 RID: 2615
		public uint uint_5;

		// Token: 0x04000A38 RID: 2616
		public uint uint_6;

		// Token: 0x04000A39 RID: 2617
		public GClass120.GStruct19 gstruct19_0;

		// Token: 0x04000A3A RID: 2618
		public uint uint_7;

		// Token: 0x04000A3B RID: 2619
		public uint uint_8;

		// Token: 0x04000A3C RID: 2620
		public uint uint_9;

		// Token: 0x04000A3D RID: 2621
		public uint uint_10;

		// Token: 0x04000A3E RID: 2622
		public uint uint_11;

		// Token: 0x04000A3F RID: 2623
		public uint uint_12;

		// Token: 0x04000A40 RID: 2624
		public uint uint_13;

		// Token: 0x04000A41 RID: 2625
		public uint uint_14;

		// Token: 0x04000A42 RID: 2626
		public uint uint_15;

		// Token: 0x04000A43 RID: 2627
		public uint uint_16;

		// Token: 0x04000A44 RID: 2628
		public uint uint_17;

		// Token: 0x04000A45 RID: 2629
		public uint uint_18;

		// Token: 0x04000A46 RID: 2630
		public uint uint_19;

		// Token: 0x04000A47 RID: 2631
		public uint uint_20;

		// Token: 0x04000A48 RID: 2632
		public uint uint_21;

		// Token: 0x04000A49 RID: 2633
		public uint uint_22;

		// Token: 0x04000A4A RID: 2634
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 512)]
		public byte[] byte_0;
	}

	// Token: 0x02000197 RID: 407
	public struct GStruct19
	{
		// Token: 0x04000A4B RID: 2635
		public uint uint_0;

		// Token: 0x04000A4C RID: 2636
		public uint uint_1;

		// Token: 0x04000A4D RID: 2637
		public uint uint_2;

		// Token: 0x04000A4E RID: 2638
		public uint uint_3;

		// Token: 0x04000A4F RID: 2639
		public uint uint_4;

		// Token: 0x04000A50 RID: 2640
		public uint uint_5;

		// Token: 0x04000A51 RID: 2641
		public uint uint_6;

		// Token: 0x04000A52 RID: 2642
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 80)]
		public byte[] byte_0;

		// Token: 0x04000A53 RID: 2643
		public uint uint_7;
	}
}
