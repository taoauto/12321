﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Security.Principal;

// Token: 0x020000AB RID: 171
public class GClass47 : GClass46
{
	// Token: 0x06000832 RID: 2098 RVA: 0x00008580 File Offset: 0x00006780
	internal GClass47(GClass38 gclass38_1, string string_0)
	{
		this.gclass38_0 = gclass38_1;
		this.gclass25_0 = new GClass25(this, string_0);
	}

	// Token: 0x17000234 RID: 564
	// (get) Token: 0x06000833 RID: 2099 RVA: 0x0000859C File Offset: 0x0000679C
	internal GClass24 GClass24_0
	{
		get
		{
			return this.gclass38_0.GClass37_0.GClass24_0;
		}
	}

	// Token: 0x17000235 RID: 565
	// (get) Token: 0x06000834 RID: 2100 RVA: 0x000085AE File Offset: 0x000067AE
	internal Stream Stream_0
	{
		get
		{
			return this.gclass38_0.Class70_0.Stream_0;
		}
	}

	// Token: 0x17000236 RID: 566
	// (get) Token: 0x06000835 RID: 2101 RVA: 0x000085C0 File Offset: 0x000067C0
	public override GClass34 \u206E\u200B\u200E\u206F\u200C\u206E\u202C\u202A\u206E\u206A\u202D\u202E\u200C\u200B\u202B\u206B\u202B\u206C\u200B\u202A\u202A\u202B\u200F\u200C\u200F\u202B\u206F\u206D\u200D\u200C\u202C\u200B\u206F\u200F\u200F\u206A\u202E\u206B\u202A\u206B\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.GClass34_0;
		}
	}

	// Token: 0x17000237 RID: 567
	// (get) Token: 0x06000836 RID: 2102 RVA: 0x000085D2 File Offset: 0x000067D2
	public override NameValueCollection \u202C\u200D\u202A\u202A\u206F\u206C\u200E\u200F\u206A\u206A\u200D\u202D\u206D\u206E\u200C\u200E\u206E\u202E\u202D\u200D\u206F\u202E\u206B\u200E\u202B\u206E\u202D\u200B\u206F\u202A\u206A\u202A\u206F\u200C\u206D\u200F\u206E\u202C\u202D\u206F\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.NameValueCollection_0;
		}
	}

	// Token: 0x17000238 RID: 568
	// (get) Token: 0x06000837 RID: 2103 RVA: 0x000085E4 File Offset: 0x000067E4
	public override string \u206A\u200F\u206E\u206E\u206F\u200F\u200E\u206C\u200E\u200C\u206D\u200B\u202A\u206C\u206B\u200D\u200D\u200C\u202E\u202A\u202C\u200E\u206D\u206D\u200C\u206A\u202B\u200E\u200D\u206B\u200C\u200B\u206C\u202C\u206E\u202A\u202C\u206C\u202C\u202E\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.String_6;
		}
	}

	// Token: 0x17000239 RID: 569
	// (get) Token: 0x06000838 RID: 2104 RVA: 0x000085F6 File Offset: 0x000067F6
	public override bool \u200E\u206C\u200E\u206B\u202D\u200E\u202A\u200F\u202A\u206C\u200B\u206A\u206B\u200B\u202D\u202D\u202E\u202E\u200F\u206B\u202C\u200C\u206C\u202B\u206B\u206B\u206D\u200E\u206F\u200B\u206C\u206B\u206A\u202B\u202C\u202C\u206A\u202A\u206C\u202A\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.Boolean_1;
		}
	}

	// Token: 0x1700023A RID: 570
	// (get) Token: 0x06000839 RID: 2105 RVA: 0x00008608 File Offset: 0x00006808
	public override bool \u202C\u202C\u200C\u200E\u202B\u206D\u206D\u206B\u206C\u202B\u200B\u206A\u200E\u200E\u200B\u206F\u200C\u202E\u202B\u200C\u200D\u206E\u206F\u202D\u206F\u202A\u202E\u206B\u206C\u202A\u202C\u200E\u202C\u202A\u202A\u202C\u206D\u200E\u200E\u200C\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.Boolean_2;
		}
	}

	// Token: 0x1700023B RID: 571
	// (get) Token: 0x0600083A RID: 2106 RVA: 0x0000861A File Offset: 0x0000681A
	public override bool \u202A\u206B\u206D\u206A\u200C\u206D\u200E\u206F\u200E\u200E\u200B\u200D\u206D\u200E\u206E\u200D\u202C\u200B\u202D\u202C\u202A\u206F\u200B\u200C\u202A\u206E\u206D\u206E\u202C\u202D\u200B\u206E\u202B\u202D\u202E\u200C\u206D\u202B\u202A\u200E\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.Boolean_3;
		}
	}

	// Token: 0x1700023C RID: 572
	// (get) Token: 0x0600083B RID: 2107 RVA: 0x0000862C File Offset: 0x0000682C
	public override bool \u206B\u206B\u206C\u206F\u202D\u202C\u202A\u206E\u202C\u200F\u206E\u202C\u202A\u206B\u200C\u206F\u200C\u202A\u206C\u206B\u202A\u206C\u206F\u200C\u206B\u200C\u200F\u206F\u200B\u206B\u200D\u206B\u206B\u200F\u202E\u206F\u200C\u200B\u200F\u200E\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.Boolean_4;
		}
	}

	// Token: 0x1700023D RID: 573
	// (get) Token: 0x0600083C RID: 2108 RVA: 0x0000863E File Offset: 0x0000683E
	public override string \u200C\u202D\u200E\u202C\u202E\u206A\u206D\u206B\u206C\u202C\u202D\u202E\u206B\u206C\u200F\u202B\u200F\u200B\u202D\u206F\u202B\u206C\u206E\u206C\u200C\u206D\u202B\u202A\u200F\u206D\u202E\u200D\u206D\u206A\u206B\u200D\u202B\u200F\u200E\u206E\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.NameValueCollection_0["Origin"];
		}
	}

	// Token: 0x1700023E RID: 574
	// (get) Token: 0x0600083D RID: 2109 RVA: 0x0000865A File Offset: 0x0000685A
	public override NameValueCollection \u206F\u206F\u206D\u202A\u206F\u202D\u200C\u202C\u202D\u200B\u206E\u202A\u202A\u200F\u200F\u206D\u202A\u206A\u206F\u202D\u202C\u200D\u202C\u206F\u200F\u200D\u200F\u200F\u202E\u200F\u206F\u200C\u206D\u200F\u200B\u202B\u200D\u206F\u202D\u202D\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.NameValueCollection_1;
		}
	}

	// Token: 0x1700023F RID: 575
	// (get) Token: 0x0600083E RID: 2110 RVA: 0x0000866C File Offset: 0x0000686C
	public override Uri \u206E\u206E\u206D\u202B\u206D\u200E\u206B\u206F\u206C\u202E\u202A\u200C\u206E\u206C\u206D\u202B\u200C\u206E\u200D\u206B\u206C\u206D\u202E\u202D\u200F\u206D\u202E\u200E\u200D\u206C\u202C\u200B\u200D\u206B\u206C\u202A\u202A\u206D\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.Uri_0;
		}
	}

	// Token: 0x17000240 RID: 576
	// (get) Token: 0x0600083F RID: 2111 RVA: 0x0000867E File Offset: 0x0000687E
	public override string \u206F\u206B\u200F\u202B\u200D\u202E\u202B\u202B\u200D\u206E\u202C\u206D\u202A\u200D\u206E\u200B\u206E\u202B\u202D\u200F\u202E\u200B\u202A\u200C\u206C\u206E\u206C\u200B\u200F\u200B\u202E\u202A\u200C\u202D\u202E\u206D\u202A\u206E\u206F\u206A\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.NameValueCollection_0["Sec-WebSocket-Key"];
		}
	}

	// Token: 0x17000241 RID: 577
	// (get) Token: 0x06000840 RID: 2112 RVA: 0x0000869A File Offset: 0x0000689A
	public override IEnumerable<string> \u202C\u206C\u200B\u200F\u202B\u200C\u202E\u200D\u200E\u206C\u206E\u206E\u202B\u200B\u202D\u202B\u206F\u206B\u206A\u202E\u202C\u206E\u206C\u202E\u206C\u206A\u206E\u200F\u200E\u202A\u202A\u200E\u202A\u202B\u206D\u200D\u206E\u200C\u206C\u202C\u202E
	{
		get
		{
			string text = this.gclass38_0.GClass40_0.NameValueCollection_0["Sec-WebSocket-Protocol"];
			if (text != null && text.Length != 0)
			{
				string[] array = text.Split(new char[]
				{
					','
				});
				for (int i = 0; i < array.Length; i++)
				{
					string text2 = array[i].Trim();
					if (text2.Length != 0)
					{
						yield return text2;
					}
				}
				array = null;
				yield break;
			}
			yield break;
		}
	}

	// Token: 0x17000242 RID: 578
	// (get) Token: 0x06000841 RID: 2113 RVA: 0x000086AA File Offset: 0x000068AA
	public override string \u202B\u202C\u200E\u206E\u202E\u200D\u206A\u206F\u206D\u200C\u200F\u202B\u206C\u200E\u200E\u206A\u202A\u202E\u206B\u206F\u200B\u206F\u202D\u206A\u202A\u202E\u206A\u202C\u206E\u200B\u200E\u206A\u206F\u206B\u206B\u206B\u206D\u200E\u200E\u202A\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.NameValueCollection_0["Sec-WebSocket-Version"];
		}
	}

	// Token: 0x17000243 RID: 579
	// (get) Token: 0x06000842 RID: 2114 RVA: 0x000086C6 File Offset: 0x000068C6
	public override IPEndPoint \u200B\u202E\u206C\u206F\u202B\u206C\u200D\u206A\u200D\u200F\u206A\u200C\u206B\u206F\u206C\u202D\u206B\u202D\u202D\u206F\u206C\u200F\u202C\u202D\u200C\u200C\u202B\u206E\u200E\u202A\u200D\u200B\u202B\u200D\u206F\u202E\u206B\u202E\u200E\u202C\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.IPEndPoint_0;
		}
	}

	// Token: 0x17000244 RID: 580
	// (get) Token: 0x06000843 RID: 2115 RVA: 0x000086D8 File Offset: 0x000068D8
	public override IPrincipal \u200B\u206A\u202D\u200C\u200E\u200C\u206F\u206B\u200E\u202B\u200D\u206E\u206A\u200F\u202E\u200F\u202D\u200E\u206E\u200B\u206B\u200D\u200F\u206B\u200F\u202E\u200D\u206A\u202B\u206C\u200B\u202C\u200C\u206B\u206A\u202E\u200B\u202C\u200D\u200E\u202E
	{
		get
		{
			return this.gclass38_0.IPrincipal_0;
		}
	}

	// Token: 0x17000245 RID: 581
	// (get) Token: 0x06000844 RID: 2116 RVA: 0x000086E5 File Offset: 0x000068E5
	public override IPEndPoint \u202D\u200D\u202A\u200B\u206B\u202E\u206F\u202A\u206C\u206F\u200B\u206C\u202C\u200B\u206A\u206C\u200D\u200D\u202D\u206A\u206B\u206D\u206D\u206C\u206E\u206F\u200C\u206F\u206A\u206E\u206D\u202B\u206B\u206F\u206B\u202C\u206B\u206F\u202A\u206F\u202E
	{
		get
		{
			return this.gclass38_0.GClass40_0.IPEndPoint_1;
		}
	}

	// Token: 0x17000246 RID: 582
	// (get) Token: 0x06000845 RID: 2117 RVA: 0x000086F7 File Offset: 0x000068F7
	public override GClass25 \u202A\u200B\u206A\u200B\u206F\u206F\u202B\u200D\u200B\u206E\u202B\u200F\u206F\u200D\u200E\u202E\u206E\u202E\u206A\u202C\u200D\u200B\u206D\u202E\u206D\u206A\u206A\u202A\u202A\u206E\u206A\u206E\u206D\u200F\u202A\u200E\u200F\u200E\u202C\u202A\u202E
	{
		get
		{
			return this.gclass25_0;
		}
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x000086FF File Offset: 0x000068FF
	internal void method_0()
	{
		this.gclass38_0.Class70_0.method_10(true);
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x00008712 File Offset: 0x00006912
	internal void method_1(GEnum9 genum9_0)
	{
		this.gclass38_0.GClass41_0.smethod_9(genum9_0);
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x00008725 File Offset: 0x00006925
	public virtual string ToString()
	{
		return this.gclass38_0.GClass40_0.ToString();
	}

	// Token: 0x04000453 RID: 1107
	private GClass38 gclass38_0;

	// Token: 0x04000454 RID: 1108
	private GClass25 gclass25_0;
}
