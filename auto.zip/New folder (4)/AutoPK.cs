﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using _i;

// Token: 0x02000168 RID: 360
public partial class AutoPK : Form
{
	// Token: 0x170004A2 RID: 1186
	// (get) Token: 0x06001172 RID: 4466 RVA: 0x0000DFB6 File Offset: 0x0000C1B6
	// (set) Token: 0x06001173 RID: 4467 RVA: 0x0000DFBD File Offset: 0x0000C1BD
	public static bool Boolean_0 { get; set; }

	// Token: 0x06001174 RID: 4468 RVA: 0x0000DFC5 File Offset: 0x0000C1C5
	public AutoPK()
	{
		this.InitializeComponent();
		base.Disposed += this.AutoPK_Disposed;
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x0000DFF0 File Offset: 0x0000C1F0
	private void AutoPK_Disposed(object sender, EventArgs e)
	{
		AutoPK.Boolean_0 = false;
		AutoPK.String_0 = string.Empty;
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x0005EB9C File Offset: 0x0005CD9C
	private void AutoPK_Load(object sender, EventArgs e)
	{
		base.Icon = GClass130.Icon_1;
		AutoPK.Boolean_0 = true;
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_7 && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
		Class438.smethod_14(this, Class438.Enum22.BottomRight);
	}

	// Token: 0x170004A3 RID: 1187
	// (get) Token: 0x06001177 RID: 4471 RVA: 0x0000E002 File Offset: 0x0000C202
	// (set) Token: 0x06001178 RID: 4472 RVA: 0x0000E009 File Offset: 0x0000C209
	public static string String_0 { get; set; } = string.Empty;

	// Token: 0x06001179 RID: 4473 RVA: 0x0005ECA8 File Offset: 0x0005CEA8
	private void button2_Click(object sender, EventArgs e)
	{
		this.listViewName.Items.Clear();
		this.hashSet_0.Clear();
		foreach (KeyValuePair<int, Class159> keyValuePair in Main.dictionary_3)
		{
			foreach (Class393 @class in keyValuePair.Value.Class394_0.list_0)
			{
				if (!(@class.String_2.Trim() == "") && @class.Boolean_7 && !Class159.HashSet_1.Contains(@class.String_2) && !this.hashSet_0.Contains(@class.String_2))
				{
					this.hashSet_0.Add(@class.String_2);
					this.listViewName.Items.Add(@class.String_2);
				}
			}
		}
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x0000E011 File Offset: 0x0000C211
	private void txtSearch_TextChanged(object sender, EventArgs e)
	{
		this.listViewName.Search(this.txtSearch.Text);
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x0005EDCC File Offset: 0x0005CFCC
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		if (this.checkBox1.Checked)
		{
			if (this.listViewName.SelectedItems.Count > 0)
			{
				AutoPK.String_0 = this.listViewName.SelectedItems[0].Text;
			}
			else
			{
				AutoPK.String_0 = string.Empty;
			}
		}
		else
		{
			AutoPK.String_0 = string.Empty;
		}
		this.label1.Text = AutoPK.String_0;
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x0005EE3C File Offset: 0x0005D03C
	private void listViewName_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (this.checkBox1.Checked)
		{
			if (this.listViewName.SelectedItems.Count > 0)
			{
				AutoPK.String_0 = this.listViewName.SelectedItems[0].Text;
			}
			else
			{
				AutoPK.String_0 = string.Empty;
			}
		}
		this.label1.Text = AutoPK.String_0;
	}

	// Token: 0x0600117D RID: 4477 RVA: 0x0000E02A File Offset: 0x0000C22A
	private void method_0(object sender, EventArgs e)
	{
		base.Dispose();
	}

	// Token: 0x0600117E RID: 4478 RVA: 0x0000E032 File Offset: 0x0000C232
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x040008E8 RID: 2280
	[CompilerGenerated]
	private static bool bool_0;

	// Token: 0x040008E9 RID: 2281
	private HashSet<string> hashSet_0 = new HashSet<string>();

	// Token: 0x040008EA RID: 2282
	[CompilerGenerated]
	private static string string_0;

	// Token: 0x040008EB RID: 2283
	private IContainer icontainer_0;
}
