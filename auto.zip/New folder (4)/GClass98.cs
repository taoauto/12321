﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Xml;

// Token: 0x0200012C RID: 300
public class GClass98 : IDisposable
{
	// Token: 0x170003DD RID: 989
	// (get) Token: 0x06000EE3 RID: 3811 RVA: 0x0000C90F File Offset: 0x0000AB0F
	public static RegexOptions RegexOptions_0
	{
		get
		{
			if (GClass98.genum19_0 == GEnum19.X86)
			{
				return RegexOptions.Compiled;
			}
			return RegexOptions.None;
		}
	}

	// Token: 0x06000EE4 RID: 3812 RVA: 0x00056534 File Offset: 0x00054734
	public GClass98(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
	}

	// Token: 0x06000EE5 RID: 3813 RVA: 0x00056618 File Offset: 0x00054818
	public void Dispose()
	{
		foreach (GClass95 gclass in this.dictionary_0.Values)
		{
			gclass.Dispose();
		}
	}

	// Token: 0x06000EE6 RID: 3814 RVA: 0x00056670 File Offset: 0x00054870
	public virtual void vmethod_0(GEnum20 genum20_0, GClass86 gclass86_0)
	{
		switch (genum20_0)
		{
		case GEnum20.CSharp:
			this.vmethod_5(gclass86_0);
			return;
		case GEnum20.VB:
			this.vmethod_6(gclass86_0);
			return;
		case GEnum20.HTML:
			this.vmethod_7(gclass86_0);
			return;
		case GEnum20.XML:
			this.vmethod_8(gclass86_0);
			return;
		case GEnum20.SQL:
			this.vmethod_9(gclass86_0);
			return;
		case GEnum20.PHP:
			this.vmethod_10(gclass86_0);
			return;
		case GEnum20.JS:
			this.vmethod_11(gclass86_0);
			return;
		case GEnum20.Lua:
			this.vmethod_12(gclass86_0);
			return;
		case GEnum20.JSON:
			this.vmethod_13(gclass86_0);
			return;
		default:
			return;
		}
	}

	// Token: 0x06000EE7 RID: 3815 RVA: 0x000566F4 File Offset: 0x000548F4
	public virtual void vmethod_1(string string_0, GClass86 gclass86_0)
	{
		GClass95 gclass = null;
		if (!this.dictionary_0.TryGetValue(string_0, out gclass))
		{
			XmlDocument xmlDocument = new XmlDocument();
			string path = string_0;
			if (!File.Exists(path))
			{
				path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Path.GetFileName(path));
			}
			xmlDocument.LoadXml(File.ReadAllText(path));
			gclass = GClass98.smethod_0(xmlDocument);
			this.dictionary_0[string_0] = gclass;
		}
		this.method_6(gclass, gclass86_0);
	}

	// Token: 0x06000EE8 RID: 3816 RVA: 0x00056760 File Offset: 0x00054960
	public virtual void vmethod_2(object sender, GEventArgs14 e)
	{
		switch ((sender as FastColoredTextBox).GEnum20_0)
		{
		case GEnum20.CSharp:
			this.method_5(sender, e);
			return;
		case GEnum20.VB:
			this.method_4(sender, e);
			return;
		case GEnum20.HTML:
			this.method_2(sender, e);
			return;
		case GEnum20.XML:
			this.method_3(sender, e);
			return;
		case GEnum20.SQL:
			this.method_1(sender, e);
			return;
		case GEnum20.PHP:
			this.method_0(sender, e);
			return;
		case GEnum20.JS:
			this.method_5(sender, e);
			return;
		case GEnum20.Lua:
			this.method_19(sender, e);
			return;
		default:
			return;
		}
	}

	// Token: 0x06000EE9 RID: 3817 RVA: 0x000567EC File Offset: 0x000549EC
	protected void method_0(object sender, GEventArgs14 e)
	{
		if (Regex.IsMatch(e.String_0, "^[^\"']*\\{.*\\}[^\"']*$"))
		{
			return;
		}
		if (Regex.IsMatch(e.String_0, "^[^\"']*\\{"))
		{
			e.Int32_3 = e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "}[^\"']*$"))
		{
			e.Int32_2 = -e.Int32_1;
			e.Int32_3 = -e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_1, "^\\s*(if|for|foreach|while|[\\}\\s]*else)\\b[^{]*$") && !Regex.IsMatch(e.String_1, "(;\\s*$)|(;\\s*//)"))
		{
			e.Int32_2 = e.Int32_1;
			return;
		}
	}

	// Token: 0x06000EEA RID: 3818 RVA: 0x0000C91B File Offset: 0x0000AB1B
	protected void method_1(object sender, GEventArgs14 e)
	{
		(sender as FastColoredTextBox).vmethod_46(sender, e);
	}

	// Token: 0x06000EEB RID: 3819 RVA: 0x0000C91B File Offset: 0x0000AB1B
	protected void method_2(object sender, GEventArgs14 e)
	{
		(sender as FastColoredTextBox).vmethod_46(sender, e);
	}

	// Token: 0x06000EEC RID: 3820 RVA: 0x0000C91B File Offset: 0x0000AB1B
	protected void method_3(object sender, GEventArgs14 e)
	{
		(sender as FastColoredTextBox).vmethod_46(sender, e);
	}

	// Token: 0x06000EED RID: 3821 RVA: 0x0005688C File Offset: 0x00054A8C
	protected void method_4(object sender, GEventArgs14 e)
	{
		if (Regex.IsMatch(e.String_0, "^\\s*(End|EndIf|Next|Loop)\\b", RegexOptions.IgnoreCase))
		{
			e.Int32_2 = -e.Int32_1;
			e.Int32_3 = -e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "\\b(Class|Property|Enum|Structure|Sub|Function|Namespace|Interface|Get)\\b|(Set\\s*\\()", RegexOptions.IgnoreCase))
		{
			e.Int32_3 = e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "\\b(Then)\\s*\\S+", RegexOptions.IgnoreCase))
		{
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*(If|While|For|Do|Try|With|Using|Select)\\b", RegexOptions.IgnoreCase))
		{
			e.Int32_3 = e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*(Else|ElseIf|Case|Catch|Finally)\\b", RegexOptions.IgnoreCase))
		{
			e.Int32_2 = -e.Int32_1;
			return;
		}
		if (e.String_1.TrimEnd(new char[0]).EndsWith("_"))
		{
			e.Int32_2 = e.Int32_1;
			return;
		}
	}

	// Token: 0x06000EEE RID: 3822 RVA: 0x00056968 File Offset: 0x00054B68
	protected void method_5(object sender, GEventArgs14 e)
	{
		if (Regex.IsMatch(e.String_0, "^[^\"']*\\{.*\\}[^\"']*$"))
		{
			return;
		}
		if (Regex.IsMatch(e.String_0, "^[^\"']*\\{"))
		{
			e.Int32_3 = e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "}[^\"']*$"))
		{
			e.Int32_2 = -e.Int32_1;
			e.Int32_3 = -e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*\\w+\\s*:\\s*($|//)") && !Regex.IsMatch(e.String_0, "^\\s*default\\s*:"))
		{
			e.Int32_2 = -e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*(case|default)\\b.*:\\s*($|//)"))
		{
			e.Int32_2 = -e.Int32_1 / 2;
			return;
		}
		if (Regex.IsMatch(e.String_1, "^\\s*(if|for|foreach|while|[\\}\\s]*else)\\b[^{]*$") && !Regex.IsMatch(e.String_1, "(;\\s*$)|(;\\s*//)"))
		{
			e.Int32_2 = e.Int32_1;
			return;
		}
	}

	// Token: 0x06000EEF RID: 3823 RVA: 0x00056A5C File Offset: 0x00054C5C
	public virtual void vmethod_3(string string_0, XmlDocument xmlDocument_0)
	{
		GClass95 value = GClass98.smethod_0(xmlDocument_0);
		this.dictionary_0[string_0] = value;
	}

	// Token: 0x06000EF0 RID: 3824 RVA: 0x0000C92A File Offset: 0x0000AB2A
	public virtual void vmethod_4(GClass87 gclass87_33)
	{
		if (this.list_0.Contains(gclass87_33))
		{
			return;
		}
		this.fastColoredTextBox_0.method_22();
		this.list_0.Add(gclass87_33);
	}

	// Token: 0x06000EF1 RID: 3825 RVA: 0x00056A80 File Offset: 0x00054C80
	public static GClass95 smethod_0(XmlDocument xmlDocument_0)
	{
		GClass95 gclass = new GClass95();
		XmlNode xmlNode = xmlDocument_0.SelectSingleNode("doc/brackets");
		if (xmlNode != null)
		{
			if (xmlNode.Attributes["left"] != null && xmlNode.Attributes["right"] != null && !(xmlNode.Attributes["left"].Value == "") && !(xmlNode.Attributes["right"].Value == ""))
			{
				gclass.char_0 = xmlNode.Attributes["left"].Value[0];
				gclass.char_1 = xmlNode.Attributes["right"].Value[0];
			}
			else
			{
				gclass.char_0 = '\0';
				gclass.char_1 = '\0';
			}
			if (xmlNode.Attributes["left2"] != null && xmlNode.Attributes["right2"] != null && !(xmlNode.Attributes["left2"].Value == "") && !(xmlNode.Attributes["right2"].Value == ""))
			{
				gclass.char_2 = xmlNode.Attributes["left2"].Value[0];
				gclass.char_3 = xmlNode.Attributes["right2"].Value[0];
			}
			else
			{
				gclass.char_2 = '\0';
				gclass.char_3 = '\0';
			}
			if (xmlNode.Attributes["strategy"] != null && !(xmlNode.Attributes["strategy"].Value == ""))
			{
				gclass.genum14_0 = (GEnum14)Enum.Parse(typeof(GEnum14), xmlNode.Attributes["strategy"].Value);
			}
			else
			{
				gclass.genum14_0 = GEnum14.Strategy2;
			}
		}
		Dictionary<string, GClass87> dictionary = new Dictionary<string, GClass87>();
		foreach (object obj in xmlDocument_0.SelectNodes("doc/style"))
		{
			XmlNode xmlNode2 = (XmlNode)obj;
			GClass87 gclass2 = GClass98.smethod_3(xmlNode2);
			dictionary[xmlNode2.Attributes["name"].Value] = gclass2;
			gclass.list_0.Add(gclass2);
		}
		foreach (object obj2 in xmlDocument_0.SelectNodes("doc/rule"))
		{
			XmlNode xmlNode_ = (XmlNode)obj2;
			gclass.list_1.Add(GClass98.smethod_2(xmlNode_, dictionary));
		}
		foreach (object obj3 in xmlDocument_0.SelectNodes("doc/folding"))
		{
			XmlNode xmlNode_2 = (XmlNode)obj3;
			gclass.list_2.Add(GClass98.smethod_1(xmlNode_2));
		}
		return gclass;
	}

	// Token: 0x06000EF2 RID: 3826 RVA: 0x00056DD4 File Offset: 0x00054FD4
	protected static GClass97 smethod_1(XmlNode xmlNode_0)
	{
		GClass97 gclass = new GClass97();
		gclass.string_0 = xmlNode_0.Attributes["start"].Value;
		gclass.string_1 = xmlNode_0.Attributes["finish"].Value;
		XmlAttribute xmlAttribute = xmlNode_0.Attributes["options"];
		if (xmlAttribute != null)
		{
			gclass.regexOptions_0 = (RegexOptions)Enum.Parse(typeof(RegexOptions), xmlAttribute.Value);
		}
		return gclass;
	}

	// Token: 0x06000EF3 RID: 3827 RVA: 0x00056E54 File Offset: 0x00055054
	protected static GClass96 smethod_2(XmlNode xmlNode_0, Dictionary<string, GClass87> dictionary_1)
	{
		GClass96 gclass = new GClass96();
		gclass.string_0 = xmlNode_0.InnerText;
		XmlAttribute xmlAttribute = xmlNode_0.Attributes["style"];
		XmlAttribute xmlAttribute2 = xmlNode_0.Attributes["options"];
		if (xmlAttribute == null)
		{
			throw new Exception("Rule must contain style name.");
		}
		if (!dictionary_1.ContainsKey(xmlAttribute.Value))
		{
			throw new Exception("Style '" + xmlAttribute.Value + "' is not found.");
		}
		gclass.gclass87_0 = dictionary_1[xmlAttribute.Value];
		if (xmlAttribute2 != null)
		{
			gclass.regexOptions_0 = (RegexOptions)Enum.Parse(typeof(RegexOptions), xmlAttribute2.Value);
		}
		return gclass;
	}

	// Token: 0x06000EF4 RID: 3828 RVA: 0x00056F04 File Offset: 0x00055104
	protected static GClass87 smethod_3(XmlNode xmlNode_0)
	{
		XmlAttribute xmlAttribute = xmlNode_0.Attributes["type"];
		XmlAttribute xmlAttribute2 = xmlNode_0.Attributes["color"];
		XmlAttribute xmlAttribute3 = xmlNode_0.Attributes["backColor"];
		XmlAttribute xmlAttribute4 = xmlNode_0.Attributes["fontStyle"];
		XmlAttribute xmlAttribute5 = xmlNode_0.Attributes["name"];
		SolidBrush brush_ = null;
		if (xmlAttribute2 != null)
		{
			brush_ = new SolidBrush(GClass98.smethod_4(xmlAttribute2.Value));
		}
		SolidBrush brush_2 = null;
		if (xmlAttribute3 != null)
		{
			brush_2 = new SolidBrush(GClass98.smethod_4(xmlAttribute3.Value));
		}
		FontStyle fontStyle_ = FontStyle.Regular;
		if (xmlAttribute4 != null)
		{
			fontStyle_ = (FontStyle)Enum.Parse(typeof(FontStyle), xmlAttribute4.Value);
		}
		return new GClass88(brush_, brush_2, fontStyle_);
	}

	// Token: 0x06000EF5 RID: 3829 RVA: 0x00056FC0 File Offset: 0x000551C0
	protected static Color smethod_4(string string_0)
	{
		if (!string_0.StartsWith("#"))
		{
			return Color.FromName(string_0);
		}
		if (string_0.Length <= 7)
		{
			return Color.FromArgb(255, Color.FromArgb(int.Parse(string_0.Substring(1), NumberStyles.AllowHexSpecifier)));
		}
		return Color.FromArgb(int.Parse(string_0.Substring(1), NumberStyles.AllowHexSpecifier));
	}

	// Token: 0x06000EF6 RID: 3830 RVA: 0x00057024 File Offset: 0x00055224
	public void method_6(GClass95 gclass95_0, GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.method_29();
		for (int i = 0; i < gclass95_0.list_0.Count; i++)
		{
			gclass86_0.fastColoredTextBox_0.GClass87_0[i] = gclass95_0.list_0[i];
		}
		int count = gclass95_0.list_0.Count;
		for (int j = 0; j < this.list_0.Count; j++)
		{
			gclass86_0.fastColoredTextBox_0.GClass87_0[count + j] = this.list_0[j];
		}
		char[] char_ = this.method_8(gclass86_0.fastColoredTextBox_0);
		gclass86_0.fastColoredTextBox_0.Char_1 = gclass95_0.char_0;
		gclass86_0.fastColoredTextBox_0.Char_2 = gclass95_0.char_1;
		gclass86_0.fastColoredTextBox_0.Char_3 = gclass95_0.char_2;
		gclass86_0.fastColoredTextBox_0.Char_4 = gclass95_0.char_3;
		gclass86_0.method_34(gclass95_0.list_0.ToArray());
		foreach (GClass96 gclass in gclass95_0.list_1)
		{
			gclass86_0.method_20(gclass.gclass87_0, gclass.Regex_0);
		}
		gclass86_0.method_36();
		foreach (GClass97 gclass2 in gclass95_0.list_2)
		{
			gclass86_0.method_26(gclass2.string_0, gclass2.string_1, gclass2.regexOptions_0);
		}
		this.method_7(gclass86_0.fastColoredTextBox_0, char_);
	}

	// Token: 0x06000EF7 RID: 3831 RVA: 0x0000C953 File Offset: 0x0000AB53
	protected void method_7(FastColoredTextBox fastColoredTextBox_1, char[] char_0)
	{
		fastColoredTextBox_1.Char_1 = char_0[0];
		fastColoredTextBox_1.Char_2 = char_0[1];
		fastColoredTextBox_1.Char_3 = char_0[2];
		fastColoredTextBox_1.Char_4 = char_0[3];
	}

	// Token: 0x06000EF8 RID: 3832 RVA: 0x0000C979 File Offset: 0x0000AB79
	protected char[] method_8(FastColoredTextBox fastColoredTextBox_1)
	{
		return new char[]
		{
			fastColoredTextBox_1.Char_1,
			fastColoredTextBox_1.Char_2,
			fastColoredTextBox_1.Char_3,
			fastColoredTextBox_1.Char_4
		};
	}

	// Token: 0x06000EF9 RID: 3833 RVA: 0x000571CC File Offset: 0x000553CC
	protected void method_9()
	{
		this.regex_7 = new Regex("\n                            # Character definitions:\n                            '\n                            (?> # disable backtracking\n                              (?:\n                                \\\\[^\\r\\n]|    # escaped meta char\n                                [^'\\r\\n]      # any character except '\n                              )*\n                            )\n                            '?\n                            |\n                            # Normal string & verbatim strings definitions:\n                            (?<verbatimIdentifier>@)?         # this group matches if it is an verbatim string\n                            \"\n                            (?> # disable backtracking\n                              (?:\n                                # match and consume an escaped character including escaped double quote (\") char\n                                (?(verbatimIdentifier)        # if it is a verbatim string ...\n                                  \"\"|                         #   then: only match an escaped double quote (\") char\n                                  \\\\.                         #   else: match an escaped sequence\n                                )\n                                | # OR\n            \n                                # match any char except double quote char (\")\n                                [^\"]\n                              )*\n                            )\n                            \"\n                        ", RegexOptions.ExplicitCapture | RegexOptions.Singleline | RegexOptions.IgnorePatternWhitespace | GClass98.RegexOptions_0);
		this.regex_2 = new Regex("//.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_3 = new Regex("(/\\*.*?\\*/)|(/\\*.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_4 = new Regex("(/\\*.*?\\*/)|(.*\\*/)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_6 = new Regex("\\b\\d+[\\.]?\\d*([eE]\\-?\\d+)?[lLdDfF]?\\b|\\b0x[a-fA-F\\d]+\\b", GClass98.RegexOptions_0);
		this.regex_0 = new Regex("^\\s*(?<range>\\[.+?\\])\\s*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_1 = new Regex("\\b(class|struct|enum|interface)\\s+(?<range>\\w+?)\\b", GClass98.RegexOptions_0);
		this.regex_5 = new Regex("\\b(abstract|add|alias|as|ascending|async|await|base|bool|break|by|byte|case|catch|char|checked|class|const|continue|decimal|default|delegate|descending|do|double|dynamic|else|enum|equals|event|explicit|extern|false|finally|fixed|float|for|foreach|from|get|global|goto|group|if|implicit|in|int|interface|internal|into|is|join|let|lock|long|nameof|namespace|new|null|object|on|operator|orderby|out|override|params|partial|private|protected|public|readonly|ref|remove|return|sbyte|sealed|select|set|short|sizeof|stackalloc|static|static|string|struct|switch|this|throw|true|try|typeof|uint|ulong|unchecked|unsafe|ushort|using|using|value|var|virtual|void|volatile|when|where|while|yield)\\b|#region\\b|#endregion\\b", GClass98.RegexOptions_0);
	}

	// Token: 0x06000EFA RID: 3834 RVA: 0x00057290 File Offset: 0x00055490
	public void method_10(GEnum20 genum20_0)
	{
		switch (genum20_0)
		{
		case GEnum20.CSharp:
			this.GClass87_0 = this.gclass87_3;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_3 = this.gclass87_5;
			this.GClass87_4 = this.gclass87_2;
			this.GClass87_5 = this.gclass87_1;
			this.GClass87_6 = this.gclass87_4;
			return;
		case GEnum20.VB:
			this.GClass87_0 = this.gclass87_3;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_4 = this.gclass87_2;
			this.GClass87_5 = this.gclass87_1;
			return;
		case GEnum20.HTML:
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_8 = this.gclass87_1;
			this.GClass87_9 = this.gclass87_7;
			this.GClass87_3 = this.gclass87_8;
			this.GClass87_7 = this.gclass87_1;
			this.GClass87_10 = this.gclass87_8;
			return;
		case GEnum20.XML:
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_13 = this.gclass87_1;
			this.GClass87_14 = this.gclass87_7;
			this.GClass87_11 = this.gclass87_8;
			this.GClass87_12 = this.gclass87_1;
			this.GClass87_15 = this.gclass87_8;
			this.GClass87_16 = this.gclass87_9;
			return;
		case GEnum20.SQL:
			this.GClass87_0 = this.gclass87_8;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_5 = this.gclass87_0;
			this.GClass87_20 = this.gclass87_0;
			this.GClass87_21 = this.gclass87_7;
			this.GClass87_17 = this.gclass87_7;
			this.GClass87_22 = this.gclass87_3;
			return;
		case GEnum20.PHP:
			this.GClass87_0 = this.gclass87_8;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_8;
			this.GClass87_17 = this.gclass87_7;
			this.GClass87_5 = this.gclass87_6;
			this.GClass87_18 = this.gclass87_1;
			this.GClass87_19 = this.gclass87_4;
			return;
		case GEnum20.JS:
			this.GClass87_0 = this.gclass87_3;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_5 = this.gclass87_1;
			return;
		case GEnum20.Lua:
			this.GClass87_0 = this.gclass87_3;
			this.GClass87_1 = this.gclass87_5;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_5 = this.gclass87_0;
			this.GClass87_21 = this.gclass87_7;
			return;
		case GEnum20.JSON:
			this.GClass87_0 = this.gclass87_3;
			this.GClass87_2 = this.gclass87_6;
			this.GClass87_5 = this.gclass87_1;
			return;
		default:
			return;
		}
	}

	// Token: 0x06000EFB RID: 3835 RVA: 0x00057544 File Offset: 0x00055744
	public virtual void vmethod_5(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "//";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '{';
		gclass86_0.fastColoredTextBox_0.Char_4 = '}';
		gclass86_0.fastColoredTextBox_0.GEnum14_0 = GEnum14.Strategy2;
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\n^\\s*(case|default)\\s*[^:]*(?<range>:)\\s*(?<range>[^;]+);\n";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_1,
			this.GClass87_2,
			this.GClass87_3,
			this.GClass87_4,
			this.GClass87_5
		});
		if (this.regex_7 == null)
		{
			this.method_9();
		}
		gclass86_0.method_20(this.GClass87_0, this.regex_7);
		gclass86_0.method_20(this.GClass87_1, this.regex_2);
		gclass86_0.method_20(this.GClass87_1, this.regex_3);
		gclass86_0.method_20(this.GClass87_1, this.regex_4);
		gclass86_0.method_20(this.GClass87_2, this.regex_6);
		gclass86_0.method_20(this.GClass87_3, this.regex_0);
		gclass86_0.method_20(this.GClass87_4, this.regex_1);
		gclass86_0.method_20(this.GClass87_5, this.regex_5);
		foreach (GClass86 gclass in gclass86_0.method_29("^\\s*///.*$", RegexOptions.Multiline))
		{
			gclass.method_35(StyleIndex.All);
			if (this.regex_16 == null)
			{
				this.method_12();
			}
			gclass.method_18(this.GClass87_1);
			foreach (GClass86 gclass2 in gclass.method_33(this.regex_14))
			{
				gclass2.method_35(StyleIndex.All);
				gclass2.method_18(this.GClass87_6);
			}
			foreach (GClass86 gclass3 in gclass.method_29("^\\s*///", RegexOptions.Multiline))
			{
				gclass3.method_35(StyleIndex.All);
				gclass3.method_18(this.GClass87_6);
			}
		}
		gclass86_0.method_36();
		gclass86_0.method_25("{", "}");
		gclass86_0.method_25("#region\\b", "#endregion\\b");
		gclass86_0.method_25("/\\*", "\\*/");
	}

	// Token: 0x06000EFC RID: 3836 RVA: 0x000577D4 File Offset: 0x000559D4
	protected void method_11()
	{
		this.regex_68 = new Regex("\"\"|\".*?[^\\\\]\"", GClass98.RegexOptions_0);
		this.regex_65 = new Regex("'.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_67 = new Regex("\\b\\d+[\\.]?\\d*([eE]\\-?\\d+)?\\b", GClass98.RegexOptions_0);
		this.regex_64 = new Regex("\\b(Class|Structure|Enum|Interface)[ ]+(?<range>\\w+?)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
		this.regex_66 = new Regex("\\b(AddHandler|AddressOf|Alias|And|AndAlso|As|Boolean|ByRef|Byte|ByVal|Call|Case|Catch|CBool|CByte|CChar|CDate|CDbl|CDec|Char|CInt|Class|CLng|CObj|Const|Continue|CSByte|CShort|CSng|CStr|CType|CUInt|CULng|CUShort|Date|Decimal|Declare|Default|Delegate|Dim|DirectCast|Do|Double|Each|Else|ElseIf|End|EndIf|Enum|Erase|Error|Event|Exit|False|Finally|For|Friend|Function|Get|GetType|GetXMLNamespace|Global|GoSub|GoTo|Handles|If|Implements|Imports|In|Inherits|Integer|Interface|Is|IsNot|Let|Lib|Like|Long|Loop|Me|Mod|Module|MustInherit|MustOverride|MyBase|MyClass|Namespace|Narrowing|New|Next|Not|Nothing|NotInheritable|NotOverridable|Object|Of|On|Operator|Option|Optional|Or|OrElse|Overloads|Overridable|Overrides|ParamArray|Partial|Private|Property|Protected|Public|RaiseEvent|ReadOnly|ReDim|REM|RemoveHandler|Resume|Return|SByte|Select|Set|Shadows|Shared|Short|Single|Static|Step|Stop|String|Structure|Sub|SyncLock|Then|Throw|To|True|Try|TryCast|TypeOf|UInteger|ULong|UShort|Using|Variant|Wend|When|While|Widening|With|WithEvents|WriteOnly|Xor|Region)\\b|(#Const|#Else|#ElseIf|#End|#If|#Region)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
	}

	// Token: 0x06000EFD RID: 3837 RVA: 0x00057850 File Offset: 0x00055A50
	public virtual void vmethod_6(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "'";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '\0';
		gclass86_0.fastColoredTextBox_0.Char_4 = '\0';
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*[\\w\\.\\(\\)]+\\s*(?<range>=)\\s*(?<range>.+)\n";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_1,
			this.GClass87_2,
			this.GClass87_4,
			this.GClass87_5
		});
		if (this.regex_68 == null)
		{
			this.method_11();
		}
		gclass86_0.method_20(this.GClass87_0, this.regex_68);
		gclass86_0.method_20(this.GClass87_1, this.regex_65);
		gclass86_0.method_20(this.GClass87_2, this.regex_67);
		gclass86_0.method_20(this.GClass87_4, this.regex_64);
		gclass86_0.method_20(this.GClass87_5, this.regex_66);
		gclass86_0.method_36();
		gclass86_0.method_26("#Region\\b", "#End\\s+Region\\b", RegexOptions.IgnoreCase);
		gclass86_0.method_26("\\b(Class|Property|Enum|Structure|Interface)[ \\t]+\\S+", "\\bEnd (Class|Property|Enum|Structure|Interface)\\b", RegexOptions.IgnoreCase);
		gclass86_0.method_26("^\\s*(?<range>While)[ \\t]+\\S+", "^\\s*(?<range>End While)\\b", RegexOptions.IgnoreCase | RegexOptions.Multiline);
		gclass86_0.method_26("\\b(Sub|Function)[ \\t]+[^\\s']+", "\\bEnd (Sub|Function)\\b", RegexOptions.IgnoreCase);
		gclass86_0.method_26("(\\r|\\n|^)[ \\t]*(?<range>Get|Set)[ \\t]*(\\r|\\n|$)", "\\bEnd (Get|Set)\\b", RegexOptions.IgnoreCase);
		gclass86_0.method_26("^\\s*(?<range>For|For\\s+Each)\\b", "^\\s*(?<range>Next)\\b", RegexOptions.IgnoreCase | RegexOptions.Multiline);
		gclass86_0.method_26("^\\s*(?<range>Do)\\b", "^\\s*(?<range>Loop)\\b", RegexOptions.IgnoreCase | RegexOptions.Multiline);
	}

	// Token: 0x06000EFE RID: 3838 RVA: 0x000579D0 File Offset: 0x00055BD0
	protected void method_12()
	{
		this.regex_10 = new Regex("(<!--.*?-->)|(<!--.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_11 = new Regex("(<!--.*?-->)|(.*-->)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_16 = new Regex("<|/>|</|>", GClass98.RegexOptions_0);
		this.regex_15 = new Regex("<(?<range>[!\\w:]+)", GClass98.RegexOptions_0);
		this.regex_12 = new Regex("</(?<range>[\\w:]+)>", GClass98.RegexOptions_0);
		this.regex_14 = new Regex("<[^>]+>", GClass98.RegexOptions_0);
		this.regex_8 = new Regex("(?<range>[\\w\\d\\-]{1,20}?)='[^']*'|(?<range>[\\w\\d\\-]{1,20})=\"[^\"]*\"|(?<range>[\\w\\d\\-]{1,20})=[\\w\\d\\-]{1,20}", GClass98.RegexOptions_0);
		this.regex_9 = new Regex("[\\w\\d\\-]{1,20}?=(?<range>'[^']*')|[\\w\\d\\-]{1,20}=(?<range>\"[^\"]*\")|[\\w\\d\\-]{1,20}=(?<range>[\\w\\d\\-]{1,20})", GClass98.RegexOptions_0);
		this.regex_13 = new Regex("\\&(amp|gt|lt|nbsp|quot|apos|copy|reg|#[0-9]{1,8}|#x[0-9a-f]{1,8});", GClass98.RegexOptions_0 | RegexOptions.IgnoreCase);
	}

	// Token: 0x06000EFF RID: 3839 RVA: 0x00057AA4 File Offset: 0x00055CA4
	public virtual void vmethod_7(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = null;
		gclass86_0.fastColoredTextBox_0.Char_1 = '<';
		gclass86_0.fastColoredTextBox_0.Char_2 = '>';
		gclass86_0.fastColoredTextBox_0.Char_3 = '(';
		gclass86_0.fastColoredTextBox_0.Char_4 = ')';
		gclass86_0.fastColoredTextBox_0.String_6 = "";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_1,
			this.GClass87_8,
			this.GClass87_9,
			this.GClass87_3,
			this.GClass87_7,
			this.GClass87_10
		});
		if (this.regex_16 == null)
		{
			this.method_12();
		}
		gclass86_0.method_20(this.GClass87_1, this.regex_10);
		gclass86_0.method_20(this.GClass87_1, this.regex_11);
		gclass86_0.method_20(this.GClass87_8, this.regex_16);
		gclass86_0.method_20(this.GClass87_9, this.regex_15);
		gclass86_0.method_20(this.GClass87_9, this.regex_12);
		gclass86_0.method_20(this.GClass87_3, this.regex_8);
		gclass86_0.method_20(this.GClass87_7, this.regex_9);
		gclass86_0.method_20(this.GClass87_10, this.regex_13);
		gclass86_0.method_36();
		gclass86_0.method_26("<head", "</head>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<body", "</body>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<table", "</table>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<form", "</form>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<div", "</div>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<script", "</script>", RegexOptions.IgnoreCase);
		gclass86_0.method_26("<tr", "</tr>", RegexOptions.IgnoreCase);
	}

	// Token: 0x06000F00 RID: 3840 RVA: 0x00057C60 File Offset: 0x00055E60
	protected void method_13()
	{
		this.regex_19 = new Regex("(<!--.*?-->)|(<!--.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_20 = new Regex("(<!--.*?-->)|(.*-->)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_25 = new Regex("<\\?|</|>|<|/>|\\?>", GClass98.RegexOptions_0);
		this.regex_24 = new Regex("<[?](?<range1>[x][m][l]{1})|<(?<range>[!\\w:\\-\\.]+)", GClass98.RegexOptions_0);
		this.regex_21 = new Regex("</(?<range>[\\w:\\-\\.]+)>", GClass98.RegexOptions_0);
		this.regex_23 = new Regex("<[^>]+>", GClass98.RegexOptions_0);
		this.regex_17 = new Regex("(?<range>[\\w\\d\\-\\:]+)[ ]*=[ ]*'[^']*'|(?<range>[\\w\\d\\-\\:]+)[ ]*=[ ]*\"[^\"]*\"|(?<range>[\\w\\d\\-\\:]+)[ ]*=[ ]*[\\w\\d\\-\\:]+", GClass98.RegexOptions_0);
		this.regex_18 = new Regex("[\\w\\d\\-]+?=(?<range>'[^']*')|[\\w\\d\\-]+[ ]*=[ ]*(?<range>\"[^\"]*\")|[\\w\\d\\-]+[ ]*=[ ]*(?<range>[\\w\\d\\-]+)", GClass98.RegexOptions_0);
		this.regex_22 = new Regex("\\&(amp|gt|lt|nbsp|quot|apos|copy|reg|#[0-9]{1,8}|#x[0-9a-f]{1,8});", GClass98.RegexOptions_0 | RegexOptions.IgnoreCase);
		this.regex_26 = new Regex("<!\\s*\\[CDATA\\s*\\[(?<text>(?>[^]]+|](?!]>))*)]]>", GClass98.RegexOptions_0 | RegexOptions.IgnoreCase);
		this.regex_27 = new Regex("<(?<range>/?[\\w:\\-\\.]+)\\s[^>]*?[^/]>|<(?<range>/?[\\w:\\-\\.]+)\\s*>", RegexOptions.Singleline | GClass98.RegexOptions_0);
	}

	// Token: 0x06000F01 RID: 3841 RVA: 0x00057D64 File Offset: 0x00055F64
	public virtual void vmethod_8(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = null;
		gclass86_0.fastColoredTextBox_0.Char_1 = '<';
		gclass86_0.fastColoredTextBox_0.Char_2 = '>';
		gclass86_0.fastColoredTextBox_0.Char_3 = '(';
		gclass86_0.fastColoredTextBox_0.Char_4 = ')';
		gclass86_0.fastColoredTextBox_0.String_6 = "";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_1,
			this.GClass87_13,
			this.GClass87_14,
			this.GClass87_11,
			this.GClass87_12,
			this.GClass87_15,
			this.GClass87_16
		});
		if (this.regex_25 == null)
		{
			this.method_13();
		}
		gclass86_0.method_20(this.GClass87_16, this.regex_26);
		gclass86_0.method_20(this.GClass87_1, this.regex_19);
		gclass86_0.method_20(this.GClass87_1, this.regex_20);
		gclass86_0.method_20(this.GClass87_13, this.regex_25);
		gclass86_0.method_20(this.GClass87_14, this.regex_24);
		gclass86_0.method_20(this.GClass87_14, this.regex_21);
		gclass86_0.method_20(this.GClass87_11, this.regex_17);
		gclass86_0.method_20(this.GClass87_12, this.regex_18);
		gclass86_0.method_20(this.GClass87_15, this.regex_22);
		gclass86_0.method_36();
		this.method_14(gclass86_0);
	}

	// Token: 0x06000F02 RID: 3842 RVA: 0x00057ECC File Offset: 0x000560CC
	private void method_14(GClass86 gclass86_0)
	{
		Stack<GClass98.Class117> stack = new Stack<GClass98.Class117>();
		int num = 0;
		FastColoredTextBox fastColoredTextBox = gclass86_0.fastColoredTextBox_0;
		foreach (GClass86 gclass in gclass86_0.method_33(this.regex_27))
		{
			string string_ = gclass.String_1;
			int int_ = gclass.GStruct2_0.int_1;
			if (string_[0] != '/')
			{
				GClass98.Class117 @class = new GClass98.Class117
				{
					string_0 = string_,
					int_0 = num++,
					int_1 = gclass.GStruct2_0.int_1
				};
				stack.Push(@class);
				if (string.IsNullOrEmpty(fastColoredTextBox[int_].String_0))
				{
					fastColoredTextBox[int_].String_0 = @class.String_0;
				}
			}
			else if (stack.Count > 0)
			{
				GClass98.Class117 class2 = stack.Pop();
				if (int_ == class2.int_1)
				{
					if (fastColoredTextBox[int_].String_0 == class2.String_0)
					{
						fastColoredTextBox[int_].String_0 = null;
					}
				}
				else if (string.IsNullOrEmpty(fastColoredTextBox[int_].String_1))
				{
					fastColoredTextBox[int_].String_1 = class2.String_0;
				}
			}
		}
	}

	// Token: 0x06000F03 RID: 3843 RVA: 0x00058030 File Offset: 0x00056230
	protected void method_15()
	{
		this.regex_61 = new Regex("\"\"|''|\".*?[^\\\\]\"|'.*?[^\\\\]'", GClass98.RegexOptions_0);
		this.regex_59 = new Regex("\\b\\d+[\\.]?\\d*([eE]\\-?\\d+)?\\b", GClass98.RegexOptions_0);
		this.regex_53 = new Regex("--.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_54 = new Regex("(/\\*.*?\\*/)|(/\\*.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_55 = new Regex("(/\\*.*?\\*/)|(.*\\*/)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_56 = new Regex("#.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_63 = new Regex("@[a-zA-Z_\\d]*\\b", GClass98.RegexOptions_0);
		this.regex_60 = new Regex("\\b(ALTER APPLICATION ROLE|ALTER ASSEMBLY|ALTER ASYMMETRIC KEY|ALTER AUTHORIZATION|ALTER BROKER PRIORITY|ALTER CERTIFICATE|ALTER CREDENTIAL|ALTER CRYPTOGRAPHIC PROVIDER|ALTER DATABASE|ALTER DATABASE AUDIT SPECIFICATION|ALTER DATABASE ENCRYPTION KEY|ALTER ENDPOINT|ALTER EVENT SESSION|ALTER FULLTEXT CATALOG|ALTER FULLTEXT INDEX|ALTER FULLTEXT STOPLIST|ALTER FUNCTION|ALTER INDEX|ALTER LOGIN|ALTER MASTER KEY|ALTER MESSAGE TYPE|ALTER PARTITION FUNCTION|ALTER PARTITION SCHEME|ALTER PROCEDURE|ALTER QUEUE|ALTER REMOTE SERVICE BINDING|ALTER RESOURCE GOVERNOR|ALTER RESOURCE POOL|ALTER ROLE|ALTER ROUTE|ALTER SCHEMA|ALTER SERVER AUDIT|ALTER SERVER AUDIT SPECIFICATION|ALTER SERVICE|ALTER SERVICE MASTER KEY|ALTER SYMMETRIC KEY|ALTER TABLE|ALTER TRIGGER|ALTER USER|ALTER VIEW|ALTER WORKLOAD GROUP|ALTER XML SCHEMA COLLECTION|BULK INSERT|CREATE AGGREGATE|CREATE APPLICATION ROLE|CREATE ASSEMBLY|CREATE ASYMMETRIC KEY|CREATE BROKER PRIORITY|CREATE CERTIFICATE|CREATE CONTRACT|CREATE CREDENTIAL|CREATE CRYPTOGRAPHIC PROVIDER|CREATE DATABASE|CREATE DATABASE AUDIT SPECIFICATION|CREATE DATABASE ENCRYPTION KEY|CREATE DEFAULT|CREATE ENDPOINT|CREATE EVENT NOTIFICATION|CREATE EVENT SESSION|CREATE FULLTEXT CATALOG|CREATE FULLTEXT INDEX|CREATE FULLTEXT STOPLIST|CREATE FUNCTION|CREATE INDEX|CREATE LOGIN|CREATE MASTER KEY|CREATE MESSAGE TYPE|CREATE PARTITION FUNCTION|CREATE PARTITION SCHEME|CREATE PROCEDURE|CREATE QUEUE|CREATE REMOTE SERVICE BINDING|CREATE RESOURCE POOL|CREATE ROLE|CREATE ROUTE|CREATE RULE|CREATE SCHEMA|CREATE SERVER AUDIT|CREATE SERVER AUDIT SPECIFICATION|CREATE SERVICE|CREATE SPATIAL INDEX|CREATE STATISTICS|CREATE SYMMETRIC KEY|CREATE SYNONYM|CREATE TABLE|CREATE TRIGGER|CREATE TYPE|CREATE USER|CREATE VIEW|CREATE WORKLOAD GROUP|CREATE XML INDEX|CREATE XML SCHEMA COLLECTION|DELETE|DISABLE TRIGGER|DROP AGGREGATE|DROP APPLICATION ROLE|DROP ASSEMBLY|DROP ASYMMETRIC KEY|DROP BROKER PRIORITY|DROP CERTIFICATE|DROP CONTRACT|DROP CREDENTIAL|DROP CRYPTOGRAPHIC PROVIDER|DROP DATABASE|DROP DATABASE AUDIT SPECIFICATION|DROP DATABASE ENCRYPTION KEY|DROP DEFAULT|DROP ENDPOINT|DROP EVENT NOTIFICATION|DROP EVENT SESSION|DROP FULLTEXT CATALOG|DROP FULLTEXT INDEX|DROP FULLTEXT STOPLIST|DROP FUNCTION|DROP INDEX|DROP LOGIN|DROP MASTER KEY|DROP MESSAGE TYPE|DROP PARTITION FUNCTION|DROP PARTITION SCHEME|DROP PROCEDURE|DROP QUEUE|DROP REMOTE SERVICE BINDING|DROP RESOURCE POOL|DROP ROLE|DROP ROUTE|DROP RULE|DROP SCHEMA|DROP SERVER AUDIT|DROP SERVER AUDIT SPECIFICATION|DROP SERVICE|DROP SIGNATURE|DROP STATISTICS|DROP SYMMETRIC KEY|DROP SYNONYM|DROP TABLE|DROP TRIGGER|DROP TYPE|DROP USER|DROP VIEW|DROP WORKLOAD GROUP|DROP XML SCHEMA COLLECTION|ENABLE TRIGGER|EXEC|EXECUTE|REPLACE|FROM|INSERT|MERGE|OPTION|OUTPUT|SELECT|TOP|TRUNCATE TABLE|UPDATE|UPDATE STATISTICS|WHERE|WITH|INTO|IN|SET)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
		this.regex_58 = new Regex("\\b(ADD|ALL|AND|ANY|AS|ASC|AUTHORIZATION|BACKUP|BEGIN|BETWEEN|BREAK|BROWSE|BY|CASCADE|CHECK|CHECKPOINT|CLOSE|CLUSTERED|COLLATE|COLUMN|COMMIT|COMPUTE|CONSTRAINT|CONTAINS|CONTINUE|CROSS|CURRENT|CURRENT_DATE|CURRENT_TIME|CURSOR|DATABASE|DBCC|DEALLOCATE|DECLARE|DEFAULT|DENY|DESC|DISK|DISTINCT|DISTRIBUTED|DOUBLE|DUMP|ELSE|END|ERRLVL|ESCAPE|EXCEPT|EXISTS|EXIT|EXTERNAL|FETCH|FILE|FILLFACTOR|FOR|FOREIGN|FREETEXT|FULL|FUNCTION|GOTO|GRANT|GROUP|HAVING|HOLDLOCK|IDENTITY|IDENTITY_INSERT|IDENTITYCOL|IF|INDEX|INNER|INTERSECT|IS|JOIN|KEY|KILL|LIKE|LINENO|LOAD|NATIONAL|NOCHECK|NONCLUSTERED|NOT|NULL|OF|OFF|OFFSETS|ON|OPEN|OR|ORDER|OUTER|OVER|PERCENT|PIVOT|PLAN|PRECISION|PRIMARY|PRINT|PROC|PROCEDURE|PUBLIC|RAISERROR|READ|READTEXT|RECONFIGURE|REFERENCES|REPLICATION|RESTORE|RESTRICT|RETURN|REVERT|REVOKE|ROLLBACK|ROWCOUNT|ROWGUIDCOL|RULE|SAVE|SCHEMA|SECURITYAUDIT|SHUTDOWN|SOME|STATISTICS|TABLE|TABLESAMPLE|TEXTSIZE|THEN|TO|TRAN|TRANSACTION|TRIGGER|TSEQUAL|UNION|UNIQUE|UNPIVOT|UPDATETEXT|USE|USER|VALUES|VARYING|VIEW|WAITFOR|WHEN|WHILE|WRITETEXT)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
		this.regex_57 = new Regex("(@@CONNECTIONS|@@CPU_BUSY|@@CURSOR_ROWS|@@DATEFIRST|@@DATEFIRST|@@DBTS|@@ERROR|@@FETCH_STATUS|@@IDENTITY|@@IDLE|@@IO_BUSY|@@LANGID|@@LANGUAGE|@@LOCK_TIMEOUT|@@MAX_CONNECTIONS|@@MAX_PRECISION|@@NESTLEVEL|@@OPTIONS|@@PACKET_ERRORS|@@PROCID|@@REMSERVER|@@ROWCOUNT|@@SERVERNAME|@@SERVICENAME|@@SPID|@@TEXTSIZE|@@TRANCOUNT|@@VERSION)\\b|\\b(ABS|ACOS|APP_NAME|ASCII|ASIN|ASSEMBLYPROPERTY|AsymKey_ID|ASYMKEY_ID|asymkeyproperty|ASYMKEYPROPERTY|ATAN|ATN2|AVG|CASE|CAST|CEILING|Cert_ID|Cert_ID|CertProperty|CHAR|CHARINDEX|CHECKSUM_AGG|COALESCE|COL_LENGTH|COL_NAME|COLLATIONPROPERTY|COLLATIONPROPERTY|COLUMNPROPERTY|COLUMNS_UPDATED|COLUMNS_UPDATED|CONTAINSTABLE|CONVERT|COS|COT|COUNT|COUNT_BIG|CRYPT_GEN_RANDOM|CURRENT_TIMESTAMP|CURRENT_TIMESTAMP|CURRENT_USER|CURRENT_USER|CURSOR_STATUS|DATABASE_PRINCIPAL_ID|DATABASE_PRINCIPAL_ID|DATABASEPROPERTY|DATABASEPROPERTYEX|DATALENGTH|DATALENGTH|DATEADD|DATEDIFF|DATENAME|DATEPART|DAY|DB_ID|DB_NAME|DECRYPTBYASYMKEY|DECRYPTBYCERT|DECRYPTBYKEY|DECRYPTBYKEYAUTOASYMKEY|DECRYPTBYKEYAUTOCERT|DECRYPTBYPASSPHRASE|DEGREES|DENSE_RANK|DIFFERENCE|ENCRYPTBYASYMKEY|ENCRYPTBYCERT|ENCRYPTBYKEY|ENCRYPTBYPASSPHRASE|ERROR_LINE|ERROR_MESSAGE|ERROR_NUMBER|ERROR_PROCEDURE|ERROR_SEVERITY|ERROR_STATE|EVENTDATA|EXP|FILE_ID|FILE_IDEX|FILE_NAME|FILEGROUP_ID|FILEGROUP_NAME|FILEGROUPPROPERTY|FILEPROPERTY|FLOOR|fn_helpcollations|fn_listextendedproperty|fn_servershareddrives|fn_virtualfilestats|fn_virtualfilestats|FORMATMESSAGE|FREETEXTTABLE|FULLTEXTCATALOGPROPERTY|FULLTEXTSERVICEPROPERTY|GETANSINULL|GETDATE|GETUTCDATE|GROUPING|HAS_PERMS_BY_NAME|HOST_ID|HOST_NAME|IDENT_CURRENT|IDENT_CURRENT|IDENT_INCR|IDENT_INCR|IDENT_SEED|IDENTITY\\(|INDEX_COL|INDEXKEY_PROPERTY|INDEXPROPERTY|IS_MEMBER|IS_OBJECTSIGNED|IS_SRVROLEMEMBER|ISDATE|ISDATE|ISNULL|ISNUMERIC|Key_GUID|Key_GUID|Key_ID|Key_ID|KEY_NAME|KEY_NAME|LEFT|LEN|LOG|LOG10|LOWER|LTRIM|MAX|MIN|MONTH|NCHAR|NEWID|NTILE|NULLIF|OBJECT_DEFINITION|OBJECT_ID|OBJECT_NAME|OBJECT_SCHEMA_NAME|OBJECTPROPERTY|OBJECTPROPERTYEX|OPENDATASOURCE|OPENQUERY|OPENROWSET|OPENXML|ORIGINAL_LOGIN|ORIGINAL_LOGIN|PARSENAME|PATINDEX|PATINDEX|PERMISSIONS|PI|POWER|PUBLISHINGSERVERNAME|PWDCOMPARE|PWDENCRYPT|QUOTENAME|RADIANS|RAND|RANK|REPLICATE|REVERSE|RIGHT|ROUND|ROW_NUMBER|ROWCOUNT_BIG|RTRIM|SCHEMA_ID|SCHEMA_ID|SCHEMA_NAME|SCHEMA_NAME|SCOPE_IDENTITY|SERVERPROPERTY|SESSION_USER|SESSION_USER|SESSIONPROPERTY|SETUSER|SIGN|SignByAsymKey|SignByCert|SIN|SOUNDEX|SPACE|SQL_VARIANT_PROPERTY|SQRT|SQUARE|STATS_DATE|STDEV|STDEVP|STR|STUFF|SUBSTRING|SUM|SUSER_ID|SUSER_NAME|SUSER_SID|SUSER_SNAME|SWITCHOFFSET|SYMKEYPROPERTY|symkeyproperty|sys\\.dm_db_index_physical_stats|sys\\.fn_builtin_permissions|sys\\.fn_my_permissions|SYSDATETIME|SYSDATETIMEOFFSET|SYSTEM_USER|SYSTEM_USER|SYSUTCDATETIME|TAN|TERTIARY_WEIGHTS|TEXTPTR|TODATETIMEOFFSET|TRIGGER_NESTLEVEL|TYPE_ID|TYPE_NAME|TYPEPROPERTY|UNICODE|UPDATE\\(|UPPER|USER_ID|USER_NAME|USER_NAME|VAR|VARP|VerifySignedByAsymKey|VerifySignedByCert|XACT_STATE|YEAR)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
		this.regex_62 = new Regex("\\b(BIGINT|NUMERIC|BIT|SMALLINT|DECIMAL|SMALLMONEY|INT|TINYINT|MONEY|FLOAT|REAL|DATE|DATETIMEOFFSET|DATETIME2|SMALLDATETIME|DATETIME|TIME|CHAR|VARCHAR|TEXT|NCHAR|NVARCHAR|NTEXT|BINARY|VARBINARY|IMAGE|TIMESTAMP|HIERARCHYID|TABLE|UNIQUEIDENTIFIER|SQL_VARIANT|XML)\\b", RegexOptions.IgnoreCase | GClass98.RegexOptions_0);
	}

	// Token: 0x06000F04 RID: 3844 RVA: 0x00058138 File Offset: 0x00056338
	public virtual void vmethod_9(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "--";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '\0';
		gclass86_0.fastColoredTextBox_0.Char_4 = '\0';
		gclass86_0.fastColoredTextBox_0.String_6 = "";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_1,
			this.GClass87_0,
			this.GClass87_2,
			this.GClass87_17,
			this.GClass87_20,
			this.GClass87_5,
			this.GClass87_21,
			this.GClass87_22
		});
		if (this.regex_61 == null)
		{
			this.method_15();
		}
		gclass86_0.method_20(this.GClass87_1, this.regex_53);
		gclass86_0.method_20(this.GClass87_1, this.regex_54);
		gclass86_0.method_20(this.GClass87_1, this.regex_55);
		gclass86_0.method_20(this.GClass87_1, this.regex_56);
		gclass86_0.method_20(this.GClass87_0, this.regex_61);
		gclass86_0.method_20(this.GClass87_2, this.regex_59);
		gclass86_0.method_20(this.GClass87_22, this.regex_62);
		gclass86_0.method_20(this.GClass87_17, this.regex_63);
		gclass86_0.method_20(this.GClass87_20, this.regex_60);
		gclass86_0.method_20(this.GClass87_5, this.regex_58);
		gclass86_0.method_20(this.GClass87_21, this.regex_57);
		gclass86_0.method_36();
		gclass86_0.method_26("\\bBEGIN\\b", "\\bEND\\b", RegexOptions.IgnoreCase);
		gclass86_0.method_25("/\\*", "\\*/");
	}

	// Token: 0x06000F05 RID: 3845 RVA: 0x000582E8 File Offset: 0x000564E8
	protected void method_16()
	{
		this.regex_51 = new Regex("\"\"|''|\".*?[^\\\\]\"|'.*?[^\\\\]'", GClass98.RegexOptions_0);
		this.regex_50 = new Regex("\\b\\d+[\\.]?\\d*\\b", GClass98.RegexOptions_0);
		this.regex_44 = new Regex("(//|#).*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_45 = new Regex("(/\\*.*?\\*/)|(/\\*.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_46 = new Regex("(/\\*.*?\\*/)|(.*\\*/)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_52 = new Regex("\\$[a-zA-Z_\\d]*\\b", GClass98.RegexOptions_0);
		this.regex_47 = new Regex("\\b(die|echo|empty|exit|eval|include|include_once|isset|list|require|require_once|return|print|unset)\\b", GClass98.RegexOptions_0);
		this.regex_48 = new Regex("\\b(abstract|and|array|as|break|case|catch|cfunction|class|clone|const|continue|declare|default|do|else|elseif|enddeclare|endfor|endforeach|endif|endswitch|endwhile|extends|final|for|foreach|function|global|goto|if|implements|instanceof|interface|namespace|new|or|private|protected|public|static|switch|throw|try|use|var|while|xor)\\b", GClass98.RegexOptions_0);
		this.regex_49 = new Regex("__CLASS__|__DIR__|__FILE__|__LINE__|__FUNCTION__|__METHOD__|__NAMESPACE__", GClass98.RegexOptions_0);
	}

	// Token: 0x06000F06 RID: 3846 RVA: 0x000583BC File Offset: 0x000565BC
	public virtual void vmethod_10(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "//";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '{';
		gclass86_0.fastColoredTextBox_0.Char_4 = '}';
		gclass86_0.fastColoredTextBox_0.GEnum14_0 = GEnum14.Strategy2;
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_1,
			this.GClass87_2,
			this.GClass87_17,
			this.GClass87_5,
			this.GClass87_18,
			this.GClass87_19
		});
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*\\$[\\w\\.\\[\\]\\'\\\"]+\\s*(?<range>=)\\s*(?<range>[^;]+);\n";
		if (this.regex_51 == null)
		{
			this.method_16();
		}
		gclass86_0.method_20(this.GClass87_0, this.regex_51);
		gclass86_0.method_20(this.GClass87_1, this.regex_44);
		gclass86_0.method_20(this.GClass87_1, this.regex_45);
		gclass86_0.method_20(this.GClass87_1, this.regex_46);
		gclass86_0.method_20(this.GClass87_2, this.regex_50);
		gclass86_0.method_20(this.GClass87_17, this.regex_52);
		gclass86_0.method_20(this.GClass87_5, this.regex_47);
		gclass86_0.method_20(this.GClass87_18, this.regex_48);
		gclass86_0.method_20(this.GClass87_19, this.regex_49);
		gclass86_0.method_36();
		gclass86_0.method_25("{", "}");
		gclass86_0.method_25("/\\*", "\\*/");
	}

	// Token: 0x06000F07 RID: 3847 RVA: 0x0005854C File Offset: 0x0005674C
	protected void method_17()
	{
		this.regex_33 = new Regex("\"\"|''|\".*?[^\\\\]\"|'.*?[^\\\\]'", GClass98.RegexOptions_0);
		this.regex_28 = new Regex("//.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_29 = new Regex("(/\\*.*?\\*/)|(/\\*.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_30 = new Regex("(/\\*.*?\\*/)|(.*\\*/)", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_32 = new Regex("\\b\\d+[\\.]?\\d*([eE]\\-?\\d+)?[lLdDfF]?\\b|\\b0x[a-fA-F\\d]+\\b", GClass98.RegexOptions_0);
		this.regex_31 = new Regex("\\b(true|false|break|case|catch|const|continue|default|delete|do|else|export|for|function|if|in|instanceof|new|null|return|switch|this|throw|try|var|void|while|with|typeof)\\b", GClass98.RegexOptions_0);
	}

	// Token: 0x06000F08 RID: 3848 RVA: 0x000585E0 File Offset: 0x000567E0
	public virtual void vmethod_11(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "//";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '{';
		gclass86_0.fastColoredTextBox_0.Char_4 = '}';
		gclass86_0.fastColoredTextBox_0.GEnum14_0 = GEnum14.Strategy2;
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;]+);\n";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_1,
			this.GClass87_2,
			this.GClass87_5
		});
		if (this.regex_33 == null)
		{
			this.method_17();
		}
		gclass86_0.method_20(this.GClass87_0, this.regex_33);
		gclass86_0.method_20(this.GClass87_1, this.regex_28);
		gclass86_0.method_20(this.GClass87_1, this.regex_29);
		gclass86_0.method_20(this.GClass87_1, this.regex_30);
		gclass86_0.method_20(this.GClass87_2, this.regex_32);
		gclass86_0.method_20(this.GClass87_5, this.regex_31);
		gclass86_0.method_36();
		gclass86_0.method_25("{", "}");
		gclass86_0.method_25("/\\*", "\\*/");
	}

	// Token: 0x06000F09 RID: 3849 RVA: 0x00058720 File Offset: 0x00056920
	protected void method_18()
	{
		this.regex_42 = new Regex("\"\"|''|\".*?[^\\\\]\"|'.*?[^\\\\]'", GClass98.RegexOptions_0);
		this.regex_37 = new Regex("--.*$", RegexOptions.Multiline | GClass98.RegexOptions_0);
		this.regex_38 = new Regex("(--\\[\\[.*?\\]\\])|(--\\[\\[.*)", RegexOptions.Singleline | GClass98.RegexOptions_0);
		this.regex_39 = new Regex("(--\\[\\[.*?\\]\\])|(.*\\]\\])", RegexOptions.Singleline | RegexOptions.RightToLeft | GClass98.RegexOptions_0);
		this.regex_41 = new Regex("\\b\\d+[\\.]?\\d*([eE]\\-?\\d+)?[lLdDfF]?\\b|\\b0x[a-fA-F\\d]+\\b", GClass98.RegexOptions_0);
		this.regex_40 = new Regex("\\b(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while)\\b", GClass98.RegexOptions_0);
		this.regex_43 = new Regex("\\b(assert|collectgarbage|dofile|error|getfenv|getmetatable|ipairs|load|loadfile|loadstring|module|next|pairs|pcall|print|rawequal|rawget|rawset|require|select|setfenv|setmetatable|tonumber|tostring|type|unpack|xpcall)\\b", GClass98.RegexOptions_0);
	}

	// Token: 0x06000F0A RID: 3850 RVA: 0x000587C8 File Offset: 0x000569C8
	public virtual void vmethod_12(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.String_1 = "--";
		gclass86_0.fastColoredTextBox_0.Char_1 = '(';
		gclass86_0.fastColoredTextBox_0.Char_2 = ')';
		gclass86_0.fastColoredTextBox_0.Char_3 = '{';
		gclass86_0.fastColoredTextBox_0.Char_4 = '}';
		gclass86_0.fastColoredTextBox_0.GEnum14_0 = GEnum14.Strategy2;
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>.+)\n";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_1,
			this.GClass87_2,
			this.GClass87_5,
			this.GClass87_21
		});
		if (this.regex_42 == null)
		{
			this.method_18();
		}
		gclass86_0.method_20(this.GClass87_0, this.regex_42);
		gclass86_0.method_20(this.GClass87_1, this.regex_37);
		gclass86_0.method_20(this.GClass87_1, this.regex_38);
		gclass86_0.method_20(this.GClass87_1, this.regex_39);
		gclass86_0.method_20(this.GClass87_2, this.regex_41);
		gclass86_0.method_20(this.GClass87_5, this.regex_40);
		gclass86_0.method_20(this.GClass87_21, this.regex_43);
		gclass86_0.method_36();
		gclass86_0.method_25("{", "}");
		gclass86_0.method_25("--\\[\\[", "\\]\\]");
	}

	// Token: 0x06000F0B RID: 3851 RVA: 0x00058920 File Offset: 0x00056B20
	protected void method_19(object sender, GEventArgs14 e)
	{
		if (Regex.IsMatch(e.String_0, "^\\s*(end|until)\\b"))
		{
			e.Int32_2 = -e.Int32_1;
			e.Int32_3 = -e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "\\b(then)\\s*\\S+"))
		{
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*(function|do|for|while|repeat|if)\\b"))
		{
			e.Int32_3 = e.Int32_1;
			return;
		}
		if (Regex.IsMatch(e.String_0, "^\\s*(else|elseif)\\b", RegexOptions.IgnoreCase))
		{
			e.Int32_2 = -e.Int32_1;
			return;
		}
	}

	// Token: 0x06000F0C RID: 3852 RVA: 0x000589B0 File Offset: 0x00056BB0
	protected void method_20()
	{
		this.regex_36 = new Regex("\"([^\\\\\"]|\\\\\")*\"", GClass98.RegexOptions_0);
		this.regex_35 = new Regex("\\b(\\d+[\\.]?\\d*|true|false|null)\\b", GClass98.RegexOptions_0);
		this.regex_34 = new Regex("(?<range>\"([^\\\\\"]|\\\\\")*\")\\s*:", GClass98.RegexOptions_0);
	}

	// Token: 0x06000F0D RID: 3853 RVA: 0x000589FC File Offset: 0x00056BFC
	public virtual void vmethod_13(GClass86 gclass86_0)
	{
		gclass86_0.fastColoredTextBox_0.Char_1 = '[';
		gclass86_0.fastColoredTextBox_0.Char_2 = ']';
		gclass86_0.fastColoredTextBox_0.Char_3 = '{';
		gclass86_0.fastColoredTextBox_0.Char_4 = '}';
		gclass86_0.fastColoredTextBox_0.GEnum14_0 = GEnum14.Strategy2;
		gclass86_0.fastColoredTextBox_0.String_6 = "\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;]+);\n";
		gclass86_0.method_34(new GClass87[]
		{
			this.GClass87_0,
			this.GClass87_2,
			this.GClass87_5
		});
		if (this.regex_36 == null)
		{
			this.method_20();
		}
		gclass86_0.method_20(this.GClass87_5, this.regex_34);
		gclass86_0.method_20(this.GClass87_0, this.regex_36);
		gclass86_0.method_20(this.GClass87_2, this.regex_35);
		gclass86_0.method_36();
		gclass86_0.method_25("{", "}");
		gclass86_0.method_25("\\[", "\\]");
	}

	// Token: 0x170003DE RID: 990
	// (get) Token: 0x06000F0E RID: 3854 RVA: 0x0000C9A5 File Offset: 0x0000ABA5
	// (set) Token: 0x06000F0F RID: 3855 RVA: 0x0000C9AD File Offset: 0x0000ABAD
	public GClass87 GClass87_0 { get; set; }

	// Token: 0x170003DF RID: 991
	// (get) Token: 0x06000F10 RID: 3856 RVA: 0x0000C9B6 File Offset: 0x0000ABB6
	// (set) Token: 0x06000F11 RID: 3857 RVA: 0x0000C9BE File Offset: 0x0000ABBE
	public GClass87 GClass87_1 { get; set; }

	// Token: 0x170003E0 RID: 992
	// (get) Token: 0x06000F12 RID: 3858 RVA: 0x0000C9C7 File Offset: 0x0000ABC7
	// (set) Token: 0x06000F13 RID: 3859 RVA: 0x0000C9CF File Offset: 0x0000ABCF
	public GClass87 GClass87_2 { get; set; }

	// Token: 0x170003E1 RID: 993
	// (get) Token: 0x06000F14 RID: 3860 RVA: 0x0000C9D8 File Offset: 0x0000ABD8
	// (set) Token: 0x06000F15 RID: 3861 RVA: 0x0000C9E0 File Offset: 0x0000ABE0
	public GClass87 GClass87_3 { get; set; }

	// Token: 0x170003E2 RID: 994
	// (get) Token: 0x06000F16 RID: 3862 RVA: 0x0000C9E9 File Offset: 0x0000ABE9
	// (set) Token: 0x06000F17 RID: 3863 RVA: 0x0000C9F1 File Offset: 0x0000ABF1
	public GClass87 GClass87_4 { get; set; }

	// Token: 0x170003E3 RID: 995
	// (get) Token: 0x06000F18 RID: 3864 RVA: 0x0000C9FA File Offset: 0x0000ABFA
	// (set) Token: 0x06000F19 RID: 3865 RVA: 0x0000CA02 File Offset: 0x0000AC02
	public GClass87 GClass87_5 { get; set; }

	// Token: 0x170003E4 RID: 996
	// (get) Token: 0x06000F1A RID: 3866 RVA: 0x0000CA0B File Offset: 0x0000AC0B
	// (set) Token: 0x06000F1B RID: 3867 RVA: 0x0000CA13 File Offset: 0x0000AC13
	public GClass87 GClass87_6 { get; set; }

	// Token: 0x170003E5 RID: 997
	// (get) Token: 0x06000F1C RID: 3868 RVA: 0x0000CA1C File Offset: 0x0000AC1C
	// (set) Token: 0x06000F1D RID: 3869 RVA: 0x0000CA24 File Offset: 0x0000AC24
	public GClass87 GClass87_7 { get; set; }

	// Token: 0x170003E6 RID: 998
	// (get) Token: 0x06000F1E RID: 3870 RVA: 0x0000CA2D File Offset: 0x0000AC2D
	// (set) Token: 0x06000F1F RID: 3871 RVA: 0x0000CA35 File Offset: 0x0000AC35
	public GClass87 GClass87_8 { get; set; }

	// Token: 0x170003E7 RID: 999
	// (get) Token: 0x06000F20 RID: 3872 RVA: 0x0000CA3E File Offset: 0x0000AC3E
	// (set) Token: 0x06000F21 RID: 3873 RVA: 0x0000CA46 File Offset: 0x0000AC46
	public GClass87 GClass87_9 { get; set; }

	// Token: 0x170003E8 RID: 1000
	// (get) Token: 0x06000F22 RID: 3874 RVA: 0x0000CA4F File Offset: 0x0000AC4F
	// (set) Token: 0x06000F23 RID: 3875 RVA: 0x0000CA57 File Offset: 0x0000AC57
	public GClass87 GClass87_10 { get; set; }

	// Token: 0x170003E9 RID: 1001
	// (get) Token: 0x06000F24 RID: 3876 RVA: 0x0000CA60 File Offset: 0x0000AC60
	// (set) Token: 0x06000F25 RID: 3877 RVA: 0x0000CA68 File Offset: 0x0000AC68
	public GClass87 GClass87_11 { get; set; }

	// Token: 0x170003EA RID: 1002
	// (get) Token: 0x06000F26 RID: 3878 RVA: 0x0000CA71 File Offset: 0x0000AC71
	// (set) Token: 0x06000F27 RID: 3879 RVA: 0x0000CA79 File Offset: 0x0000AC79
	public GClass87 GClass87_12 { get; set; }

	// Token: 0x170003EB RID: 1003
	// (get) Token: 0x06000F28 RID: 3880 RVA: 0x0000CA82 File Offset: 0x0000AC82
	// (set) Token: 0x06000F29 RID: 3881 RVA: 0x0000CA8A File Offset: 0x0000AC8A
	public GClass87 GClass87_13 { get; set; }

	// Token: 0x170003EC RID: 1004
	// (get) Token: 0x06000F2A RID: 3882 RVA: 0x0000CA93 File Offset: 0x0000AC93
	// (set) Token: 0x06000F2B RID: 3883 RVA: 0x0000CA9B File Offset: 0x0000AC9B
	public GClass87 GClass87_14 { get; set; }

	// Token: 0x170003ED RID: 1005
	// (get) Token: 0x06000F2C RID: 3884 RVA: 0x0000CAA4 File Offset: 0x0000ACA4
	// (set) Token: 0x06000F2D RID: 3885 RVA: 0x0000CAAC File Offset: 0x0000ACAC
	public GClass87 GClass87_15 { get; set; }

	// Token: 0x170003EE RID: 1006
	// (get) Token: 0x06000F2E RID: 3886 RVA: 0x0000CAB5 File Offset: 0x0000ACB5
	// (set) Token: 0x06000F2F RID: 3887 RVA: 0x0000CABD File Offset: 0x0000ACBD
	public GClass87 GClass87_16 { get; set; }

	// Token: 0x170003EF RID: 1007
	// (get) Token: 0x06000F30 RID: 3888 RVA: 0x0000CAC6 File Offset: 0x0000ACC6
	// (set) Token: 0x06000F31 RID: 3889 RVA: 0x0000CACE File Offset: 0x0000ACCE
	public GClass87 GClass87_17 { get; set; }

	// Token: 0x170003F0 RID: 1008
	// (get) Token: 0x06000F32 RID: 3890 RVA: 0x0000CAD7 File Offset: 0x0000ACD7
	// (set) Token: 0x06000F33 RID: 3891 RVA: 0x0000CADF File Offset: 0x0000ACDF
	public GClass87 GClass87_18 { get; set; }

	// Token: 0x170003F1 RID: 1009
	// (get) Token: 0x06000F34 RID: 3892 RVA: 0x0000CAE8 File Offset: 0x0000ACE8
	// (set) Token: 0x06000F35 RID: 3893 RVA: 0x0000CAF0 File Offset: 0x0000ACF0
	public GClass87 GClass87_19 { get; set; }

	// Token: 0x170003F2 RID: 1010
	// (get) Token: 0x06000F36 RID: 3894 RVA: 0x0000CAF9 File Offset: 0x0000ACF9
	// (set) Token: 0x06000F37 RID: 3895 RVA: 0x0000CB01 File Offset: 0x0000AD01
	public GClass87 GClass87_20 { get; set; }

	// Token: 0x170003F3 RID: 1011
	// (get) Token: 0x06000F38 RID: 3896 RVA: 0x0000CB0A File Offset: 0x0000AD0A
	// (set) Token: 0x06000F39 RID: 3897 RVA: 0x0000CB12 File Offset: 0x0000AD12
	public GClass87 GClass87_21 { get; set; }

	// Token: 0x170003F4 RID: 1012
	// (get) Token: 0x06000F3A RID: 3898 RVA: 0x0000CB1B File Offset: 0x0000AD1B
	// (set) Token: 0x06000F3B RID: 3899 RVA: 0x0000CB23 File Offset: 0x0000AD23
	public GClass87 GClass87_22 { get; set; }

	// Token: 0x04000776 RID: 1910
	protected static readonly GEnum19 genum19_0 = GClass85.smethod_0();

	// Token: 0x04000777 RID: 1911
	public readonly GClass87 gclass87_0 = new GClass88(Brushes.Blue, null, FontStyle.Bold);

	// Token: 0x04000778 RID: 1912
	public readonly GClass87 gclass87_1 = new GClass88(Brushes.Blue, null, FontStyle.Regular);

	// Token: 0x04000779 RID: 1913
	public readonly GClass87 gclass87_2 = new GClass88(null, null, FontStyle.Bold | FontStyle.Underline);

	// Token: 0x0400077A RID: 1914
	public readonly GClass87 gclass87_3 = new GClass88(Brushes.Brown, null, FontStyle.Italic);

	// Token: 0x0400077B RID: 1915
	public readonly GClass87 gclass87_4 = new GClass88(Brushes.Gray, null, FontStyle.Regular);

	// Token: 0x0400077C RID: 1916
	public readonly GClass87 gclass87_5 = new GClass88(Brushes.Green, null, FontStyle.Italic);

	// Token: 0x0400077D RID: 1917
	public readonly GClass87 gclass87_6 = new GClass88(Brushes.Magenta, null, FontStyle.Regular);

	// Token: 0x0400077E RID: 1918
	public readonly GClass87 gclass87_7 = new GClass88(Brushes.Maroon, null, FontStyle.Regular);

	// Token: 0x0400077F RID: 1919
	public readonly GClass87 gclass87_8 = new GClass88(Brushes.Red, null, FontStyle.Regular);

	// Token: 0x04000780 RID: 1920
	public readonly GClass87 gclass87_9 = new GClass88(Brushes.Black, null, FontStyle.Regular);

	// Token: 0x04000781 RID: 1921
	protected readonly Dictionary<string, GClass95> dictionary_0 = new Dictionary<string, GClass95>();

	// Token: 0x04000782 RID: 1922
	protected readonly List<GClass87> list_0 = new List<GClass87>(5);

	// Token: 0x04000783 RID: 1923
	protected Regex regex_0;

	// Token: 0x04000784 RID: 1924
	protected Regex regex_1;

	// Token: 0x04000785 RID: 1925
	protected Regex regex_2;

	// Token: 0x04000786 RID: 1926
	protected Regex regex_3;

	// Token: 0x04000787 RID: 1927
	protected Regex regex_4;

	// Token: 0x04000788 RID: 1928
	protected Regex regex_5;

	// Token: 0x04000789 RID: 1929
	protected Regex regex_6;

	// Token: 0x0400078A RID: 1930
	protected Regex regex_7;

	// Token: 0x0400078B RID: 1931
	protected Regex regex_8;

	// Token: 0x0400078C RID: 1932
	protected Regex regex_9;

	// Token: 0x0400078D RID: 1933
	protected Regex regex_10;

	// Token: 0x0400078E RID: 1934
	protected Regex regex_11;

	// Token: 0x0400078F RID: 1935
	protected Regex regex_12;

	// Token: 0x04000790 RID: 1936
	protected Regex regex_13;

	// Token: 0x04000791 RID: 1937
	protected Regex regex_14;

	// Token: 0x04000792 RID: 1938
	protected Regex regex_15;

	// Token: 0x04000793 RID: 1939
	protected Regex regex_16;

	// Token: 0x04000794 RID: 1940
	protected Regex regex_17;

	// Token: 0x04000795 RID: 1941
	protected Regex regex_18;

	// Token: 0x04000796 RID: 1942
	protected Regex regex_19;

	// Token: 0x04000797 RID: 1943
	protected Regex regex_20;

	// Token: 0x04000798 RID: 1944
	protected Regex regex_21;

	// Token: 0x04000799 RID: 1945
	protected Regex regex_22;

	// Token: 0x0400079A RID: 1946
	protected Regex regex_23;

	// Token: 0x0400079B RID: 1947
	protected Regex regex_24;

	// Token: 0x0400079C RID: 1948
	protected Regex regex_25;

	// Token: 0x0400079D RID: 1949
	protected Regex regex_26;

	// Token: 0x0400079E RID: 1950
	protected Regex regex_27;

	// Token: 0x0400079F RID: 1951
	protected Regex regex_28;

	// Token: 0x040007A0 RID: 1952
	protected Regex regex_29;

	// Token: 0x040007A1 RID: 1953
	protected Regex regex_30;

	// Token: 0x040007A2 RID: 1954
	protected Regex regex_31;

	// Token: 0x040007A3 RID: 1955
	protected Regex regex_32;

	// Token: 0x040007A4 RID: 1956
	protected Regex regex_33;

	// Token: 0x040007A5 RID: 1957
	protected Regex regex_34;

	// Token: 0x040007A6 RID: 1958
	protected Regex regex_35;

	// Token: 0x040007A7 RID: 1959
	protected Regex regex_36;

	// Token: 0x040007A8 RID: 1960
	protected Regex regex_37;

	// Token: 0x040007A9 RID: 1961
	protected Regex regex_38;

	// Token: 0x040007AA RID: 1962
	protected Regex regex_39;

	// Token: 0x040007AB RID: 1963
	protected Regex regex_40;

	// Token: 0x040007AC RID: 1964
	protected Regex regex_41;

	// Token: 0x040007AD RID: 1965
	protected Regex regex_42;

	// Token: 0x040007AE RID: 1966
	protected Regex regex_43;

	// Token: 0x040007AF RID: 1967
	protected Regex regex_44;

	// Token: 0x040007B0 RID: 1968
	protected Regex regex_45;

	// Token: 0x040007B1 RID: 1969
	protected Regex regex_46;

	// Token: 0x040007B2 RID: 1970
	protected Regex regex_47;

	// Token: 0x040007B3 RID: 1971
	protected Regex regex_48;

	// Token: 0x040007B4 RID: 1972
	protected Regex regex_49;

	// Token: 0x040007B5 RID: 1973
	protected Regex regex_50;

	// Token: 0x040007B6 RID: 1974
	protected Regex regex_51;

	// Token: 0x040007B7 RID: 1975
	protected Regex regex_52;

	// Token: 0x040007B8 RID: 1976
	protected Regex regex_53;

	// Token: 0x040007B9 RID: 1977
	protected Regex regex_54;

	// Token: 0x040007BA RID: 1978
	protected Regex regex_55;

	// Token: 0x040007BB RID: 1979
	protected Regex regex_56;

	// Token: 0x040007BC RID: 1980
	protected Regex regex_57;

	// Token: 0x040007BD RID: 1981
	protected Regex regex_58;

	// Token: 0x040007BE RID: 1982
	protected Regex regex_59;

	// Token: 0x040007BF RID: 1983
	protected Regex regex_60;

	// Token: 0x040007C0 RID: 1984
	protected Regex regex_61;

	// Token: 0x040007C1 RID: 1985
	protected Regex regex_62;

	// Token: 0x040007C2 RID: 1986
	protected Regex regex_63;

	// Token: 0x040007C3 RID: 1987
	protected Regex regex_64;

	// Token: 0x040007C4 RID: 1988
	protected Regex regex_65;

	// Token: 0x040007C5 RID: 1989
	protected Regex regex_66;

	// Token: 0x040007C6 RID: 1990
	protected Regex regex_67;

	// Token: 0x040007C7 RID: 1991
	protected Regex regex_68;

	// Token: 0x040007C8 RID: 1992
	protected FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040007C9 RID: 1993
	[CompilerGenerated]
	private GClass87 gclass87_10;

	// Token: 0x040007CA RID: 1994
	[CompilerGenerated]
	private GClass87 gclass87_11;

	// Token: 0x040007CB RID: 1995
	[CompilerGenerated]
	private GClass87 gclass87_12;

	// Token: 0x040007CC RID: 1996
	[CompilerGenerated]
	private GClass87 gclass87_13;

	// Token: 0x040007CD RID: 1997
	[CompilerGenerated]
	private GClass87 gclass87_14;

	// Token: 0x040007CE RID: 1998
	[CompilerGenerated]
	private GClass87 gclass87_15;

	// Token: 0x040007CF RID: 1999
	[CompilerGenerated]
	private GClass87 gclass87_16;

	// Token: 0x040007D0 RID: 2000
	[CompilerGenerated]
	private GClass87 gclass87_17;

	// Token: 0x040007D1 RID: 2001
	[CompilerGenerated]
	private GClass87 gclass87_18;

	// Token: 0x040007D2 RID: 2002
	[CompilerGenerated]
	private GClass87 gclass87_19;

	// Token: 0x040007D3 RID: 2003
	[CompilerGenerated]
	private GClass87 gclass87_20;

	// Token: 0x040007D4 RID: 2004
	[CompilerGenerated]
	private GClass87 gclass87_21;

	// Token: 0x040007D5 RID: 2005
	[CompilerGenerated]
	private GClass87 gclass87_22;

	// Token: 0x040007D6 RID: 2006
	[CompilerGenerated]
	private GClass87 gclass87_23;

	// Token: 0x040007D7 RID: 2007
	[CompilerGenerated]
	private GClass87 gclass87_24;

	// Token: 0x040007D8 RID: 2008
	[CompilerGenerated]
	private GClass87 gclass87_25;

	// Token: 0x040007D9 RID: 2009
	[CompilerGenerated]
	private GClass87 gclass87_26;

	// Token: 0x040007DA RID: 2010
	[CompilerGenerated]
	private GClass87 gclass87_27;

	// Token: 0x040007DB RID: 2011
	[CompilerGenerated]
	private GClass87 gclass87_28;

	// Token: 0x040007DC RID: 2012
	[CompilerGenerated]
	private GClass87 gclass87_29;

	// Token: 0x040007DD RID: 2013
	[CompilerGenerated]
	private GClass87 gclass87_30;

	// Token: 0x040007DE RID: 2014
	[CompilerGenerated]
	private GClass87 gclass87_31;

	// Token: 0x040007DF RID: 2015
	[CompilerGenerated]
	private GClass87 gclass87_32;

	// Token: 0x0200012D RID: 301
	private class Class117
	{
		// Token: 0x170003F5 RID: 1013
		// (get) Token: 0x06000F3D RID: 3901 RVA: 0x0000CB38 File Offset: 0x0000AD38
		public string String_0
		{
			get
			{
				return this.string_0 + this.int_0.ToString();
			}
		}

		// Token: 0x040007E0 RID: 2016
		public string string_0;

		// Token: 0x040007E1 RID: 2017
		public int int_0;

		// Token: 0x040007E2 RID: 2018
		public int int_1;
	}
}
