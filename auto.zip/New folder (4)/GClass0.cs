﻿using System;
using System.IO;
using System.Media;

// Token: 0x02000002 RID: 2
public class GClass0
{
	// Token: 0x06000002 RID: 2 RVA: 0x00002E1A File Offset: 0x0000101A
	public GClass0(byte[] byte_0)
	{
		GClass0.soundPlayer_0 = new SoundPlayer(new MemoryStream(byte_0, true));
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002E33 File Offset: 0x00001033
	public void method_0()
	{
		GClass0.soundPlayer_0.Play();
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00021B0C File Offset: 0x0001FD0C
	public static void smethod_0(byte[] byte_0)
	{
		using (SoundPlayer soundPlayer = new SoundPlayer(new MemoryStream(byte_0, true)
		{
			Position = 0L
		}))
		{
			soundPlayer.Play();
		}
	}

	// Token: 0x04000001 RID: 1
	private static SoundPlayer soundPlayer_0;
}
