﻿using System;

// Token: 0x02000284 RID: 644
internal class Class335
{
	// Token: 0x17000776 RID: 1910
	// (get) Token: 0x06002412 RID: 9234 RVA: 0x0001B888 File Offset: 0x00019A88
	public static string String_0
	{
		get
		{
			return "Phiêu Miễu Phong";
		}
	}

	// Token: 0x040017C9 RID: 6089
	public static int int_0 = Class365.Int32_91;

	// Token: 0x040017CA RID: 6090
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 12163U,
		Int32_0 = 124,
		Int32_1 = 86,
		Int32_2 = Class335.int_0,
		String_2 = "Cáp Đại Bá"
	};

	// Token: 0x040017CB RID: 6091
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 12164U,
		Int32_0 = 41,
		Int32_1 = 105,
		Int32_2 = Class335.int_0,
		String_2 = "Tang Thổ Công"
	};
}
