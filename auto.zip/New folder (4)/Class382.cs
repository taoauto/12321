﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Xml;

// Token: 0x020002B9 RID: 697
internal class Class382
{
	// Token: 0x1700084D RID: 2125
	// (get) Token: 0x060026AE RID: 9902 RVA: 0x0001CE85 File Offset: 0x0001B085
	public static string String_0
	{
		get
		{
			return Class268.String_4 + "\\Config\\Scripts.xml";
		}
	}

	// Token: 0x1700084E RID: 2126
	// (get) Token: 0x060026AF RID: 9903 RVA: 0x0001CE96 File Offset: 0x0001B096
	// (set) Token: 0x060026B0 RID: 9904 RVA: 0x0001CE9D File Offset: 0x0001B09D
	public static List<Class383> List_0 { get; set; }

	// Token: 0x060026B1 RID: 9905 RVA: 0x00115AA8 File Offset: 0x00113CA8
	public static List<Class383> smethod_0()
	{
		try
		{
			Class382.xmlDocument_0.Load(Class387.String_0 + "/scripts.xml");
		}
		catch
		{
			if (Class382.xmlDocument_0.SelectSingleNode("/*") == null)
			{
				Class382.xmlDocument_0.InsertBefore(Class382.xmlDocument_0.CreateXmlDeclaration("1.0", "UTF-8", null), Class382.xmlDocument_0.DocumentElement);
				Class382.xmlDocument_0.AppendChild(Class382.xmlDocument_0.CreateNode(XmlNodeType.Element, "Scripts", ""));
			}
		}
		List<Class383> list = new List<Class383>();
		foreach (object obj in Class382.xmlDocument_0.SelectSingleNode("Scripts").SelectNodes("Script"))
		{
			XmlNode xmlNode_ = (XmlNode)obj;
			list.Add(new Class383
			{
				XmlNode_0 = xmlNode_
			});
		}
		Class382.List_0 = list;
		return list;
	}

	// Token: 0x060026B2 RID: 9906 RVA: 0x00115BB8 File Offset: 0x00113DB8
	public static Class383 smethod_1(string string_0)
	{
		foreach (Class383 @class in Class382.List_0)
		{
			if (@class.String_0 == string_0 || @class.String_3.Contains(string_0))
			{
				return @class;
			}
		}
		return null;
	}

	// Token: 0x060026B3 RID: 9907 RVA: 0x00115C28 File Offset: 0x00113E28
	public static Class383 smethod_2(string string_0)
	{
		foreach (Class383 @class in Class382.List_0)
		{
			if (Class426.smethod_57(@class.String_6) == Class426.smethod_57(string_0))
			{
				return @class;
			}
		}
		return null;
	}

	// Token: 0x060026B4 RID: 9908 RVA: 0x00115C94 File Offset: 0x00113E94
	public static string smethod_3(Class383 class383_0)
	{
		foreach (object obj in Class382.xmlDocument_0.SelectSingleNode("Scripts").SelectNodes("Script"))
		{
			XmlNode xmlNode_ = (XmlNode)obj;
			Class383 @class = new Class383();
			@class.XmlNode_0 = xmlNode_;
			if (@class.String_3.Contains(class383_0.String_3) || (@class.String_0 == class383_0.String_0 && class383_0.String_0 != ""))
			{
				return "Script Đã Tồn Tại";
			}
		}
		Class382.xmlDocument_0.SelectSingleNode("/*").AppendChild(class383_0.XmlNode_0);
		Class382.smethod_4();
		return "";
	}

	// Token: 0x060026B5 RID: 9909 RVA: 0x00002E18 File Offset: 0x00001018
	public static void smethod_4()
	{
	}

	// Token: 0x060026B6 RID: 9910 RVA: 0x0001CEA5 File Offset: 0x0001B0A5
	public static void smethod_5(Class383 class383_0)
	{
		Class382.xmlDocument_0.SelectSingleNode("/*").RemoveChild(class383_0.XmlNode_0);
	}

	// Token: 0x04001A88 RID: 6792
	public static XmlDocument xmlDocument_0 = new XmlDocument();

	// Token: 0x04001A89 RID: 6793
	[CompilerGenerated]
	private static List<Class383> list_0;
}
