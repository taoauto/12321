﻿using System;

// Token: 0x020002AB RID: 683
internal class Class369
{
	// Token: 0x17000843 RID: 2115
	// (get) Token: 0x06002662 RID: 9826 RVA: 0x0001CB2E File Offset: 0x0001AD2E
	public static string String_0
	{
		get
		{
			return "Quang Minh Điện";
		}
	}

	// Token: 0x040019BA RID: 6586
	public static int int_0 = 11;

	// Token: 0x040019BB RID: 6587
	public static Class424 class424_0 = new Class424
	{
		UInt32_0 = 9U,
		Int32_0 = 65,
		Int32_1 = 116,
		Int32_2 = Class369.int_0,
		String_2 = "Đặng Nguyên Giác"
	};

	// Token: 0x040019BC RID: 6588
	public static Class424 class424_1 = new Class424
	{
		UInt32_0 = 11U,
		Int32_0 = 108,
		Int32_1 = 56,
		Int32_2 = Class369.int_0,
		String_2 = "Lã Sư Tương"
	};

	// Token: 0x040019BD RID: 6589
	public static Class424 class424_2 = new Class424
	{
		UInt32_0 = 1U,
		Int32_0 = 98,
		Int32_1 = 105,
		Int32_2 = Class369.int_0,
		String_2 = "Lâm Nham"
	};

	// Token: 0x040019BE RID: 6590
	public static Class424 class424_3 = new Class424
	{
		UInt32_0 = 12U,
		Int32_0 = 109,
		Int32_1 = 59,
		Int32_2 = Class369.int_0,
		String_2 = "Bàng Vạn Xuân"
	};
}
