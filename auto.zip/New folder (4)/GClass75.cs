﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x020000EC RID: 236
public class GClass75
{
	// Token: 0x06000C8F RID: 3215 RVA: 0x0000B0F2 File Offset: 0x000092F2
	public GClass75()
	{
		this.Boolean_2 = true;
		this.String_0 = "";
		this.String_1 = "";
		this.String_2 = "";
	}

	// Token: 0x17000350 RID: 848
	// (get) Token: 0x06000C90 RID: 3216 RVA: 0x0000B122 File Offset: 0x00009322
	// (set) Token: 0x06000C91 RID: 3217 RVA: 0x0000B12A File Offset: 0x0000932A
	public bool Boolean_0 { get; set; }

	// Token: 0x17000351 RID: 849
	// (get) Token: 0x06000C92 RID: 3218 RVA: 0x0000B133 File Offset: 0x00009333
	// (set) Token: 0x06000C93 RID: 3219 RVA: 0x0000B13B File Offset: 0x0000933B
	public bool Boolean_1 { get; set; }

	// Token: 0x17000352 RID: 850
	// (get) Token: 0x06000C94 RID: 3220 RVA: 0x0000B144 File Offset: 0x00009344
	// (set) Token: 0x06000C95 RID: 3221 RVA: 0x0000B14C File Offset: 0x0000934C
	public bool Boolean_2 { get; set; }

	// Token: 0x17000353 RID: 851
	// (get) Token: 0x06000C96 RID: 3222 RVA: 0x0000B155 File Offset: 0x00009355
	// (set) Token: 0x06000C97 RID: 3223 RVA: 0x0000B15D File Offset: 0x0000935D
	public string String_0 { get; set; }

	// Token: 0x17000354 RID: 852
	// (get) Token: 0x06000C98 RID: 3224 RVA: 0x0000B166 File Offset: 0x00009366
	// (set) Token: 0x06000C99 RID: 3225 RVA: 0x0000B16E File Offset: 0x0000936E
	public string String_1 { get; set; }

	// Token: 0x17000355 RID: 853
	// (get) Token: 0x06000C9A RID: 3226 RVA: 0x0000B177 File Offset: 0x00009377
	// (set) Token: 0x06000C9B RID: 3227 RVA: 0x0000B17F File Offset: 0x0000937F
	public string String_2 { get; set; }

	// Token: 0x17000356 RID: 854
	// (get) Token: 0x06000C9C RID: 3228 RVA: 0x0000B188 File Offset: 0x00009388
	// (set) Token: 0x06000C9D RID: 3229 RVA: 0x0000B190 File Offset: 0x00009390
	public bool Boolean_3 { get; set; }

	// Token: 0x040005C9 RID: 1481
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040005CA RID: 1482
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x040005CB RID: 1483
	[CompilerGenerated]
	private bool bool_2;

	// Token: 0x040005CC RID: 1484
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040005CD RID: 1485
	[CompilerGenerated]
	private string string_1;

	// Token: 0x040005CE RID: 1486
	[CompilerGenerated]
	private string string_2;

	// Token: 0x040005CF RID: 1487
	[CompilerGenerated]
	private bool bool_3;
}
