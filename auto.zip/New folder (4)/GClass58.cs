﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;

// Token: 0x020000C4 RID: 196
public class GClass58
{
	// Token: 0x170002A7 RID: 679
	// (get) Token: 0x06000981 RID: 2433 RVA: 0x0000933A File Offset: 0x0000753A
	// (set) Token: 0x06000982 RID: 2434 RVA: 0x00009342 File Offset: 0x00007542
	public FastColoredTextBox FastColoredTextBox_0 { get; private set; }

	// Token: 0x170002A8 RID: 680
	// (get) Token: 0x06000983 RID: 2435 RVA: 0x0000934B File Offset: 0x0000754B
	// (set) Token: 0x06000984 RID: 2436 RVA: 0x00009353 File Offset: 0x00007553
	public string String_0 { get; set; }

	// Token: 0x170002A9 RID: 681
	// (get) Token: 0x06000985 RID: 2437 RVA: 0x0000935C File Offset: 0x0000755C
	// (set) Token: 0x06000986 RID: 2438 RVA: 0x00009364 File Offset: 0x00007564
	public int Int32_0 { get; set; }

	// Token: 0x170002AA RID: 682
	// (get) Token: 0x06000987 RID: 2439 RVA: 0x0000936D File Offset: 0x0000756D
	// (set) Token: 0x06000988 RID: 2440 RVA: 0x00009375 File Offset: 0x00007575
	public Color Color_0 { get; set; }

	// Token: 0x06000989 RID: 2441 RVA: 0x0000937E File Offset: 0x0000757E
	public virtual void vmethod_0()
	{
		this.FastColoredTextBox_0.GClass86_5.GStruct2_0 = new GStruct2(0, this.Int32_0);
		this.FastColoredTextBox_0.method_53(this.FastColoredTextBox_0.GClass86_5, true);
		this.FastColoredTextBox_0.method_4();
	}

	// Token: 0x0600098A RID: 2442 RVA: 0x000093BE File Offset: 0x000075BE
	public GClass58(FastColoredTextBox fastColoredTextBox_1, string string_1, int int_1)
	{
		this.FastColoredTextBox_0 = fastColoredTextBox_1;
		this.String_0 = string_1;
		this.Int32_0 = int_1;
		this.Color_0 = fastColoredTextBox_1.Color_0;
	}

	// Token: 0x0600098B RID: 2443 RVA: 0x0003E71C File Offset: 0x0003C91C
	public virtual void vmethod_1(Graphics graphics_0, Rectangle rectangle_0)
	{
		int num = this.FastColoredTextBox_0.Int32_2 - 1;
		using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Rectangle(0, rectangle_0.Top, num, num), Color.White, this.Color_0, 45f))
		{
			graphics_0.FillEllipse(linearGradientBrush, 0, rectangle_0.Top, num, num);
		}
		using (Pen pen = new Pen(this.Color_0))
		{
			graphics_0.DrawEllipse(pen, 0, rectangle_0.Top, num, num);
		}
	}

	// Token: 0x040004B2 RID: 1202
	[CompilerGenerated]
	private FastColoredTextBox fastColoredTextBox_0;

	// Token: 0x040004B3 RID: 1203
	[CompilerGenerated]
	private string string_0;

	// Token: 0x040004B4 RID: 1204
	[CompilerGenerated]
	private int int_0;

	// Token: 0x040004B5 RID: 1205
	[CompilerGenerated]
	private Color color_0;
}
