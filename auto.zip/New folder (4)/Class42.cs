﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x0200005F RID: 95
internal class Class42 : IEnumerable<byte>, IEnumerable
{
	// Token: 0x06000412 RID: 1042 RVA: 0x00002E70 File Offset: 0x00001070
	private Class42()
	{
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x00005943 File Offset: 0x00003B43
	internal Class42(Enum3 enum3_1, Class30 class30_1, bool bool_0) : this(Enum1.Final, enum3_1, class30_1, false, bool_0)
	{
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x00005950 File Offset: 0x00003B50
	internal Class42(Enum1 enum1_1, Enum3 enum3_1, byte[] byte_4, bool bool_0, bool bool_1) : this(enum1_1, enum3_1, new Class30(byte_4), bool_0, bool_1)
	{
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x0002E344 File Offset: 0x0002C544
	internal Class42(Enum1 enum1_1, Enum3 enum3_1, Class30 class30_1, bool bool_0, bool bool_1)
	{
		this.enum1_0 = enum1_1;
		this.enum3_0 = enum3_1;
		this.enum4_0 = ((enum3_1.smethod_44() && bool_0) ? Enum4.On : Enum4.Off);
		this.enum4_1 = Enum4.Off;
		this.enum4_2 = Enum4.Off;
		ulong uint64_ = class30_1.UInt64_0;
		if (uint64_ < 126UL)
		{
			this.byte_2 = (byte)uint64_;
			this.byte_0 = GClass25.byte_0;
		}
		else if (uint64_ < 65536UL)
		{
			this.byte_2 = 126;
			this.byte_0 = ((ushort)uint64_).smethod_38(GEnum5.Big);
		}
		else
		{
			this.byte_2 = 127;
			this.byte_0 = uint64_.smethod_39(GEnum5.Big);
		}
		if (bool_1)
		{
			this.enum2_0 = Enum2.On;
			this.byte_1 = Class42.smethod_0();
			class30_1.method_0(this.byte_1);
		}
		else
		{
			this.enum2_0 = Enum2.Off;
			this.byte_1 = GClass25.byte_0;
		}
		this.class30_0 = class30_1;
	}

	// Token: 0x17000102 RID: 258
	// (get) Token: 0x06000416 RID: 1046 RVA: 0x00005964 File Offset: 0x00003B64
	internal ulong UInt64_0
	{
		get
		{
			if (this.byte_2 < 126)
			{
				return (ulong)this.byte_2;
			}
			if (this.byte_2 != 126)
			{
				return this.byte_0.smethod_67(GEnum5.Big);
			}
			return (ulong)this.byte_0.smethod_66(GEnum5.Big);
		}
	}

	// Token: 0x17000103 RID: 259
	// (get) Token: 0x06000417 RID: 1047 RVA: 0x0000599C File Offset: 0x00003B9C
	internal int Int32_0
	{
		get
		{
			if (this.byte_2 < 126)
			{
				return 0;
			}
			if (this.byte_2 != 126)
			{
				return 8;
			}
			return 2;
		}
	}

	// Token: 0x17000104 RID: 260
	// (get) Token: 0x06000418 RID: 1048 RVA: 0x000059B7 File Offset: 0x00003BB7
	public byte[] Byte_0
	{
		get
		{
			return this.byte_0;
		}
	}

	// Token: 0x17000105 RID: 261
	// (get) Token: 0x06000419 RID: 1049 RVA: 0x000059BF File Offset: 0x00003BBF
	public Enum1 Enum1_0
	{
		get
		{
			return this.enum1_0;
		}
	}

	// Token: 0x17000106 RID: 262
	// (get) Token: 0x0600041A RID: 1050 RVA: 0x000059C7 File Offset: 0x00003BC7
	public bool Boolean_0
	{
		get
		{
			return this.enum3_0 == Enum3.Binary;
		}
	}

	// Token: 0x17000107 RID: 263
	// (get) Token: 0x0600041B RID: 1051 RVA: 0x000059D2 File Offset: 0x00003BD2
	public bool Boolean_1
	{
		get
		{
			return this.enum3_0 == Enum3.Close;
		}
	}

	// Token: 0x17000108 RID: 264
	// (get) Token: 0x0600041C RID: 1052 RVA: 0x000059DD File Offset: 0x00003BDD
	public bool Boolean_2
	{
		get
		{
			return this.enum4_0 == Enum4.On;
		}
	}

	// Token: 0x17000109 RID: 265
	// (get) Token: 0x0600041D RID: 1053 RVA: 0x000059E8 File Offset: 0x00003BE8
	public bool Boolean_3
	{
		get
		{
			return this.enum3_0 == Enum3.Cont;
		}
	}

	// Token: 0x1700010A RID: 266
	// (get) Token: 0x0600041E RID: 1054 RVA: 0x000059F3 File Offset: 0x00003BF3
	public bool Boolean_4
	{
		get
		{
			return this.enum3_0 >= Enum3.Close;
		}
	}

	// Token: 0x1700010B RID: 267
	// (get) Token: 0x0600041F RID: 1055 RVA: 0x00005A01 File Offset: 0x00003C01
	public bool Boolean_5
	{
		get
		{
			return this.enum3_0 == Enum3.Text || this.enum3_0 == Enum3.Binary;
		}
	}

	// Token: 0x1700010C RID: 268
	// (get) Token: 0x06000420 RID: 1056 RVA: 0x00005A17 File Offset: 0x00003C17
	public bool Boolean_6
	{
		get
		{
			return this.enum1_0 == Enum1.Final;
		}
	}

	// Token: 0x1700010D RID: 269
	// (get) Token: 0x06000421 RID: 1057 RVA: 0x00005A22 File Offset: 0x00003C22
	public bool Boolean_7
	{
		get
		{
			return this.enum1_0 == Enum1.More || this.enum3_0 == Enum3.Cont;
		}
	}

	// Token: 0x1700010E RID: 270
	// (get) Token: 0x06000422 RID: 1058 RVA: 0x00005A37 File Offset: 0x00003C37
	public bool Boolean_8
	{
		get
		{
			return this.enum2_0 == Enum2.On;
		}
	}

	// Token: 0x1700010F RID: 271
	// (get) Token: 0x06000423 RID: 1059 RVA: 0x00005A42 File Offset: 0x00003C42
	public bool Boolean_9
	{
		get
		{
			return this.enum3_0 == Enum3.Ping;
		}
	}

	// Token: 0x17000110 RID: 272
	// (get) Token: 0x06000424 RID: 1060 RVA: 0x00005A4E File Offset: 0x00003C4E
	public bool Boolean_10
	{
		get
		{
			return this.enum3_0 == Enum3.Pong;
		}
	}

	// Token: 0x17000111 RID: 273
	// (get) Token: 0x06000425 RID: 1061 RVA: 0x00005A5A File Offset: 0x00003C5A
	public bool Boolean_11
	{
		get
		{
			return this.enum3_0 == Enum3.Text;
		}
	}

	// Token: 0x17000112 RID: 274
	// (get) Token: 0x06000426 RID: 1062 RVA: 0x00005A65 File Offset: 0x00003C65
	public ulong UInt64_1
	{
		get
		{
			return (ulong)(2L + (long)(this.byte_0.Length + this.byte_1.Length) + (long)this.class30_0.UInt64_0);
		}
	}

	// Token: 0x17000113 RID: 275
	// (get) Token: 0x06000427 RID: 1063 RVA: 0x00005A88 File Offset: 0x00003C88
	public Enum2 Enum2_0
	{
		get
		{
			return this.enum2_0;
		}
	}

	// Token: 0x17000114 RID: 276
	// (get) Token: 0x06000428 RID: 1064 RVA: 0x00005A90 File Offset: 0x00003C90
	public byte[] Byte_1
	{
		get
		{
			return this.byte_1;
		}
	}

	// Token: 0x17000115 RID: 277
	// (get) Token: 0x06000429 RID: 1065 RVA: 0x00005A98 File Offset: 0x00003C98
	public Enum3 Enum3_0
	{
		get
		{
			return this.enum3_0;
		}
	}

	// Token: 0x17000116 RID: 278
	// (get) Token: 0x0600042A RID: 1066 RVA: 0x00005AA0 File Offset: 0x00003CA0
	public Class30 Class30_0
	{
		get
		{
			return this.class30_0;
		}
	}

	// Token: 0x17000117 RID: 279
	// (get) Token: 0x0600042B RID: 1067 RVA: 0x00005AA8 File Offset: 0x00003CA8
	public byte Byte_2
	{
		get
		{
			return this.byte_2;
		}
	}

	// Token: 0x17000118 RID: 280
	// (get) Token: 0x0600042C RID: 1068 RVA: 0x00005AB0 File Offset: 0x00003CB0
	public Enum4 Enum4_0
	{
		get
		{
			return this.enum4_0;
		}
	}

	// Token: 0x17000119 RID: 281
	// (get) Token: 0x0600042D RID: 1069 RVA: 0x00005AB8 File Offset: 0x00003CB8
	public Enum4 Enum4_1
	{
		get
		{
			return this.enum4_1;
		}
	}

	// Token: 0x1700011A RID: 282
	// (get) Token: 0x0600042E RID: 1070 RVA: 0x00005AC0 File Offset: 0x00003CC0
	public Enum4 Enum4_2
	{
		get
		{
			return this.enum4_2;
		}
	}

	// Token: 0x0600042F RID: 1071 RVA: 0x0002E420 File Offset: 0x0002C620
	private static byte[] smethod_0()
	{
		byte[] array = new byte[4];
		GClass25.randomNumberGenerator_0.GetBytes(array);
		return array;
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x0002E440 File Offset: 0x0002C640
	private static string smethod_1(Class42 class42_0)
	{
		Class42.Class43 @class = new Class42.Class43();
		ulong uint64_ = class42_0.UInt64_1;
		long num = (long)(uint64_ / 4UL);
		int num2 = (int)(uint64_ % 4UL);
		int num3;
		string arg;
		if (num < 10000L)
		{
			num3 = 4;
			arg = "{0,4}";
		}
		else if (num < 65536L)
		{
			num3 = 4;
			arg = "{0,4:X}";
		}
		else if (num < 4294967296L)
		{
			num3 = 8;
			arg = "{0,8:X}";
		}
		else
		{
			num3 = 16;
			arg = "{0,16:X}";
		}
		string arg2 = string.Format("{{0,{0}}}", num3);
		string format = string.Format("\n{0} 01234567 89ABCDEF 01234567 89ABCDEF\n{0}+--------+--------+--------+--------+\\n", arg2);
		@class.string_0 = string.Format("{0}|{{1,8}} {{2,8}} {{3,8}} {{4,8}}|\n", arg);
		string format2 = string.Format("{0}+--------+--------+--------+--------+", arg2);
		@class.stringBuilder_0 = new StringBuilder(64);
		Action<string, string, string, string> action = new Func<Action<string, string, string, string>>(@class.method_0)();
		byte[] array = class42_0.method_3();
		@class.stringBuilder_0.AppendFormat(format, string.Empty);
		for (long num4 = 0L; num4 <= num; num4 += 1L)
		{
			long num5 = num4 * 4L;
			checked
			{
				if (num4 < num)
				{
					action(Convert.ToString(array[(int)((IntPtr)num5)], 2).PadLeft(8, '0'), Convert.ToString(array[(int)((IntPtr)(unchecked(num5 + 1L)))], 2).PadLeft(8, '0'), Convert.ToString(array[(int)((IntPtr)(unchecked(num5 + 2L)))], 2).PadLeft(8, '0'), Convert.ToString(array[(int)((IntPtr)(unchecked(num5 + 3L)))], 2).PadLeft(8, '0'));
				}
				else if (num2 > 0)
				{
					action(Convert.ToString(array[(int)((IntPtr)num5)], 2).PadLeft(8, '0'), (num2 >= 2) ? Convert.ToString(array[(int)((IntPtr)(unchecked(num5 + 1L)))], 2).PadLeft(8, '0') : string.Empty, (num2 == 3) ? Convert.ToString(array[(int)((IntPtr)(unchecked(num5 + 2L)))], 2).PadLeft(8, '0') : string.Empty, string.Empty);
				}
			}
		}
		@class.stringBuilder_0.AppendFormat(format2, string.Empty);
		return @class.stringBuilder_0.ToString();
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x0002E634 File Offset: 0x0002C834
	private static string smethod_2(Class42 class42_0)
	{
		byte b = class42_0.byte_2;
		string text = (b > 125) ? class42_0.UInt64_0.ToString() : string.Empty;
		string text2 = BitConverter.ToString(class42_0.byte_1);
		string text3 = (b == 0) ? string.Empty : ((b > 125) ? "---" : ((!class42_0.Boolean_11 || class42_0.Boolean_7 || class42_0.Boolean_8 || class42_0.Boolean_2) ? class42_0.class30_0.ToString() : Class42.smethod_12(class42_0.class30_0.Byte_0)));
		return string.Format("\n                    FIN: {0}\n                   RSV1: {1}\n                   RSV2: {2}\n                   RSV3: {3}\n                 Opcode: {4}\n                   MASK: {5}\n         Payload Length: {6}\nExtended Payload Length: {7}\n            Masking Key: {8}\n           Payload Data: {9}", new object[]
		{
			class42_0.enum1_0,
			class42_0.enum4_0,
			class42_0.enum4_1,
			class42_0.enum4_2,
			class42_0.enum3_0,
			class42_0.enum2_0,
			b,
			text,
			text2,
			text3
		});
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x0002E740 File Offset: 0x0002C940
	private static Class42 smethod_3(byte[] byte_4)
	{
		if (byte_4.Length != 2)
		{
			throw new GException3("The header part of a frame could not be read.");
		}
		Enum1 @enum = ((byte_4[0] & 128) == 128) ? Enum1.Final : Enum1.More;
		Enum4 enum2 = ((byte_4[0] & 64) == 64) ? Enum4.On : Enum4.Off;
		Enum4 enum3 = ((byte_4[0] & 32) == 32) ? Enum4.On : Enum4.Off;
		Enum4 enum4 = ((byte_4[0] & 16) == 16) ? Enum4.On : Enum4.Off;
		byte b = byte_4[0] & 15;
		Enum2 enum5 = ((byte_4[1] & 128) == 128) ? Enum2.On : Enum2.Off;
		byte b2 = byte_4[1] & 127;
		if (!b.smethod_49())
		{
			string string_ = "A frame has an unsupported opcode.";
			throw new GException3(GEnum6.ProtocolError, string_);
		}
		if (!b.smethod_43() && enum2 == Enum4.On)
		{
			string string_2 = "A non data frame is compressed.";
			throw new GException3(GEnum6.ProtocolError, string_2);
		}
		if (b.smethod_41())
		{
			if (@enum == Enum1.More)
			{
				string string_3 = "A control frame is fragmented.";
				throw new GException3(GEnum6.ProtocolError, string_3);
			}
			if (b2 > 125)
			{
				string string_4 = "A control frame has too long payload length.";
				throw new GException3(GEnum6.ProtocolError, string_4);
			}
		}
		return new Class42
		{
			enum1_0 = @enum,
			enum4_0 = enum2,
			enum4_1 = enum3,
			enum4_2 = enum4,
			enum3_0 = (Enum3)b,
			enum2_0 = enum5,
			byte_2 = b2
		};
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x0002E87C File Offset: 0x0002CA7C
	private static Class42 smethod_4(Stream stream_0, Class42 class42_0)
	{
		int int32_ = class42_0.Int32_0;
		if (int32_ == 0)
		{
			class42_0.byte_0 = GClass25.byte_0;
			return class42_0;
		}
		byte[] array = stream_0.smethod_54(int32_);
		if (array.Length != int32_)
		{
			throw new GException3("The extended payload length of a frame could not be read.");
		}
		class42_0.byte_0 = array;
		return class42_0;
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x0002E8C4 File Offset: 0x0002CAC4
	private static void smethod_5(Stream stream_0, Class42 class42_0, Action<Class42> action_0, Action<Exception> action_1)
	{
		Class42.Class45 @class = new Class42.Class45();
		@class.class42_0 = class42_0;
		@class.action_0 = action_0;
		@class.int_0 = @class.class42_0.Int32_0;
		if (@class.int_0 == 0)
		{
			@class.class42_0.byte_0 = GClass25.byte_0;
			@class.action_0(@class.class42_0);
			return;
		}
		stream_0.smethod_56(@class.int_0, new Action<byte[]>(@class.method_0), action_1);
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x00005AC8 File Offset: 0x00003CC8
	private static Class42 smethod_6(Stream stream_0)
	{
		return Class42.smethod_3(stream_0.smethod_54(2));
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x0002E93C File Offset: 0x0002CB3C
	private static void smethod_7(Stream stream_0, Action<Class42> action_0, Action<Exception> action_1)
	{
		Class42.Class46 @class = new Class42.Class46();
		@class.action_0 = action_0;
		stream_0.smethod_56(2, new Action<byte[]>(@class.method_0), action_1);
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x0002E96C File Offset: 0x0002CB6C
	private static Class42 smethod_8(Stream stream_0, Class42 class42_0)
	{
		if (!class42_0.Boolean_8)
		{
			class42_0.byte_1 = GClass25.byte_0;
			return class42_0;
		}
		byte[] array = stream_0.smethod_54(4);
		if (array.Length != 4)
		{
			throw new GException3("The masking key of a frame could not be read.");
		}
		class42_0.byte_1 = array;
		return class42_0;
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x0002E9B0 File Offset: 0x0002CBB0
	private static void smethod_9(Stream stream_0, Class42 class42_0, Action<Class42> action_0, Action<Exception> action_1)
	{
		Class42.Class47 @class = new Class42.Class47();
		@class.class42_0 = class42_0;
		@class.action_0 = action_0;
		if (!@class.class42_0.Boolean_8)
		{
			@class.class42_0.byte_1 = GClass25.byte_0;
			@class.action_0(@class.class42_0);
			return;
		}
		@class.int_0 = 4;
		stream_0.smethod_56(@class.int_0, new Action<byte[]>(@class.method_0), action_1);
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x0002EA20 File Offset: 0x0002CC20
	private static Class42 smethod_10(Stream stream_0, Class42 class42_0)
	{
		ulong uint64_ = class42_0.UInt64_0;
		if (uint64_ > Class30.ulong_0)
		{
			string string_ = "A frame has too long payload length.";
			throw new GException3(GEnum6.TooBig, string_);
		}
		if (uint64_ == 0UL)
		{
			class42_0.class30_0 = Class30.class30_0;
			return class42_0;
		}
		long num = (long)uint64_;
		byte[] array = (class42_0.byte_2 < 127) ? stream_0.smethod_54((int)uint64_) : stream_0.smethod_55(num, 1024);
		if ((long)array.Length != num)
		{
			throw new GException3("The payload data of a frame could not be read.");
		}
		class42_0.class30_0 = new Class30(array, num);
		return class42_0;
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x0002EAA0 File Offset: 0x0002CCA0
	private static void smethod_11(Stream stream_0, Class42 class42_0, Action<Class42> action_0, Action<Exception> action_1)
	{
		Class42.Class48 @class = new Class42.Class48();
		@class.class42_0 = class42_0;
		@class.action_0 = action_0;
		ulong uint64_ = @class.class42_0.UInt64_0;
		if (uint64_ > Class30.ulong_0)
		{
			string string_ = "A frame has too long payload length.";
			throw new GException3(GEnum6.TooBig, string_);
		}
		if (uint64_ == 0UL)
		{
			@class.class42_0.class30_0 = Class30.class30_0;
			@class.action_0(@class.class42_0);
			return;
		}
		@class.long_0 = (long)uint64_;
		Action<byte[]> action_2 = new Action<byte[]>(@class.method_0);
		if (@class.class42_0.byte_2 < 127)
		{
			stream_0.smethod_56((int)uint64_, action_2, action_1);
			return;
		}
		stream_0.smethod_57(@class.long_0, 1024, action_2, action_1);
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x0002EB50 File Offset: 0x0002CD50
	private static string smethod_12(byte[] byte_4)
	{
		string result;
		try
		{
			result = Encoding.UTF8.GetString(byte_4);
		}
		catch
		{
			result = null;
		}
		return result;
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x00005AD6 File Offset: 0x00003CD6
	internal static Class42 smethod_13(Class30 class30_1, bool bool_0)
	{
		return new Class42(Enum1.Final, Enum3.Close, class30_1, false, bool_0);
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x00005AE2 File Offset: 0x00003CE2
	internal static Class42 smethod_14(bool bool_0)
	{
		return new Class42(Enum1.Final, Enum3.Ping, Class30.class30_0, false, bool_0);
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00005AF3 File Offset: 0x00003CF3
	internal static Class42 smethod_15(byte[] byte_4, bool bool_0)
	{
		return new Class42(Enum1.Final, Enum3.Ping, new Class30(byte_4), false, bool_0);
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x00005B05 File Offset: 0x00003D05
	internal static Class42 smethod_16(Class30 class30_1, bool bool_0)
	{
		return new Class42(Enum1.Final, Enum3.Pong, class30_1, false, bool_0);
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x0002EB84 File Offset: 0x0002CD84
	internal static Class42 smethod_17(Stream stream_0, bool bool_0)
	{
		Class42 @class = Class42.smethod_6(stream_0);
		Class42.smethod_4(stream_0, @class);
		Class42.smethod_8(stream_0, @class);
		Class42.smethod_10(stream_0, @class);
		if (bool_0)
		{
			@class.method_0();
		}
		return @class;
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x0002EBBC File Offset: 0x0002CDBC
	internal static void smethod_18(Stream stream_0, bool bool_0, Action<Class42> action_0, Action<Exception> action_1)
	{
		Class42.Class49 @class = new Class42.Class49();
		@class.stream_0 = stream_0;
		@class.bool_0 = bool_0;
		@class.action_0 = action_0;
		@class.action_1 = action_1;
		Class42.smethod_7(@class.stream_0, new Action<Class42>(@class.method_0), @class.action_1);
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00005B12 File Offset: 0x00003D12
	internal void method_0()
	{
		if (this.enum2_0 == Enum2.Off)
		{
			return;
		}
		this.enum2_0 = Enum2.Off;
		this.class30_0.method_0(this.byte_1);
		this.byte_1 = GClass25.byte_0;
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x00005B40 File Offset: 0x00003D40
	public IEnumerator<byte> GetEnumerator()
	{
		Class42.Class50 @class = new Class42.Class50(0);
		@class.class42_0 = this;
		return @class;
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x00005B4F File Offset: 0x00003D4F
	public void method_1(bool bool_0)
	{
		Console.WriteLine(bool_0 ? Class42.smethod_1(this) : Class42.smethod_2(this));
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00005B67 File Offset: 0x00003D67
	public string method_2(bool bool_0)
	{
		if (!bool_0)
		{
			return Class42.smethod_2(this);
		}
		return Class42.smethod_1(this);
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x0002EC08 File Offset: 0x0002CE08
	public byte[] method_3()
	{
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			int num = (int)this.enum1_0;
			num = (int)((byte)(num << 1) + this.enum4_0);
			num = (int)((byte)(num << 1) + this.enum4_1);
			num = (int)((byte)(num << 1) + this.enum4_2);
			num = (int)((byte)(num << 4) + this.enum3_0);
			num = (int)((byte)(num << 1) + this.enum2_0);
			num = (num << 7) + (int)this.byte_2;
			memoryStream.Write(((ushort)num).smethod_38(GEnum5.Big), 0, 2);
			if (this.byte_2 > 125)
			{
				memoryStream.Write(this.byte_0, 0, (this.byte_2 == 126) ? 2 : 8);
			}
			if (this.enum2_0 == Enum2.On)
			{
				memoryStream.Write(this.byte_1, 0, 4);
			}
			if (this.byte_2 > 0)
			{
				byte[] array = this.class30_0.method_1();
				if (this.byte_2 < 127)
				{
					memoryStream.Write(array, 0, array.Length);
				}
				else
				{
					memoryStream.smethod_80(array, 1024);
				}
			}
			memoryStream.Close();
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00005B79 File Offset: 0x00003D79
	public virtual string ToString()
	{
		return BitConverter.ToString(this.method_3());
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00005B86 File Offset: 0x00003D86
	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	// Token: 0x0400023C RID: 572
	private byte[] byte_0;

	// Token: 0x0400023D RID: 573
	private Enum1 enum1_0;

	// Token: 0x0400023E RID: 574
	private Enum2 enum2_0;

	// Token: 0x0400023F RID: 575
	private byte[] byte_1;

	// Token: 0x04000240 RID: 576
	private Enum3 enum3_0;

	// Token: 0x04000241 RID: 577
	private Class30 class30_0;

	// Token: 0x04000242 RID: 578
	private byte byte_2;

	// Token: 0x04000243 RID: 579
	private Enum4 enum4_0;

	// Token: 0x04000244 RID: 580
	private Enum4 enum4_1;

	// Token: 0x04000245 RID: 581
	private Enum4 enum4_2;

	// Token: 0x04000246 RID: 582
	internal static readonly byte[] byte_3 = Class42.smethod_14(false).method_3();

	// Token: 0x02000060 RID: 96
	[CompilerGenerated]
	private sealed class Class43
	{
		// Token: 0x0600044A RID: 1098 RVA: 0x00005B8E File Offset: 0x00003D8E
		internal Action<string, string, string, string> method_0()
		{
			return new Action<string, string, string, string>(new Class42.Class44
			{
				class43_0 = this,
				long_0 = 0L
			}.method_0);
		}

		// Token: 0x04000247 RID: 583
		public StringBuilder stringBuilder_0;

		// Token: 0x04000248 RID: 584
		public string string_0;
	}

	// Token: 0x02000061 RID: 97
	[CompilerGenerated]
	private sealed class Class44
	{
		// Token: 0x0600044C RID: 1100 RVA: 0x0002ED14 File Offset: 0x0002CF14
		internal void method_0(string string_0, string string_1, string string_2, string string_3)
		{
			StringBuilder stringBuilder_ = this.class43_0.stringBuilder_0;
			string string_4 = this.class43_0.string_0;
			object[] array = new object[5];
			int num = 0;
			long num2 = this.long_0 + 1L;
			this.long_0 = num2;
			array[num] = num2;
			array[1] = string_0;
			array[2] = string_1;
			array[3] = string_2;
			array[4] = string_3;
			stringBuilder_.AppendFormat(string_4, array);
		}

		// Token: 0x04000249 RID: 585
		public long long_0;

		// Token: 0x0400024A RID: 586
		public Class42.Class43 class43_0;
	}

	// Token: 0x02000062 RID: 98
	[CompilerGenerated]
	private sealed class Class45
	{
		// Token: 0x0600044E RID: 1102 RVA: 0x00005BAF File Offset: 0x00003DAF
		internal void method_0(byte[] byte_0)
		{
			if (byte_0.Length != this.int_0)
			{
				throw new GException3("The extended payload length of a frame could not be read.");
			}
			this.class42_0.byte_0 = byte_0;
			this.action_0(this.class42_0);
		}

		// Token: 0x0400024B RID: 587
		public int int_0;

		// Token: 0x0400024C RID: 588
		public Class42 class42_0;

		// Token: 0x0400024D RID: 589
		public Action<Class42> action_0;
	}

	// Token: 0x02000063 RID: 99
	[CompilerGenerated]
	private sealed class Class46
	{
		// Token: 0x06000450 RID: 1104 RVA: 0x00005BE4 File Offset: 0x00003DE4
		internal void method_0(byte[] byte_0)
		{
			this.action_0(Class42.smethod_3(byte_0));
		}

		// Token: 0x0400024E RID: 590
		public Action<Class42> action_0;
	}

	// Token: 0x02000064 RID: 100
	[CompilerGenerated]
	private sealed class Class47
	{
		// Token: 0x06000452 RID: 1106 RVA: 0x00005BF7 File Offset: 0x00003DF7
		internal void method_0(byte[] byte_0)
		{
			if (byte_0.Length != this.int_0)
			{
				throw new GException3("The masking key of a frame could not be read.");
			}
			this.class42_0.byte_1 = byte_0;
			this.action_0(this.class42_0);
		}

		// Token: 0x0400024F RID: 591
		public int int_0;

		// Token: 0x04000250 RID: 592
		public Class42 class42_0;

		// Token: 0x04000251 RID: 593
		public Action<Class42> action_0;
	}

	// Token: 0x02000065 RID: 101
	[CompilerGenerated]
	private sealed class Class48
	{
		// Token: 0x06000454 RID: 1108 RVA: 0x00005C2C File Offset: 0x00003E2C
		internal void method_0(byte[] byte_0)
		{
			if ((long)byte_0.Length != this.long_0)
			{
				throw new GException3("The payload data of a frame could not be read.");
			}
			this.class42_0.class30_0 = new Class30(byte_0, this.long_0);
			this.action_0(this.class42_0);
		}

		// Token: 0x04000252 RID: 594
		public long long_0;

		// Token: 0x04000253 RID: 595
		public Class42 class42_0;

		// Token: 0x04000254 RID: 596
		public Action<Class42> action_0;
	}

	// Token: 0x02000066 RID: 102
	[CompilerGenerated]
	private sealed class Class49
	{
		// Token: 0x06000456 RID: 1110 RVA: 0x0002ED70 File Offset: 0x0002CF70
		internal void method_0(Class42 class42_0)
		{
			Stream stream = this.stream_0;
			Action<Class42> action;
			if ((action = this.action_4) == null)
			{
				action = (this.action_4 = new Action<Class42>(this.method_1));
			}
			Class42.smethod_5(stream, class42_0, action, this.action_1);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0002EDB0 File Offset: 0x0002CFB0
		internal void method_1(Class42 class42_0)
		{
			Stream stream = this.stream_0;
			Action<Class42> action;
			if ((action = this.action_3) == null)
			{
				action = (this.action_3 = new Action<Class42>(this.method_2));
			}
			Class42.smethod_9(stream, class42_0, action, this.action_1);
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0002EDF0 File Offset: 0x0002CFF0
		internal void method_2(Class42 class42_0)
		{
			Stream stream = this.stream_0;
			Action<Class42> action;
			if ((action = this.action_2) == null)
			{
				action = (this.action_2 = new Action<Class42>(this.method_3));
			}
			Class42.smethod_11(stream, class42_0, action, this.action_1);
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00005C6C File Offset: 0x00003E6C
		internal void method_3(Class42 class42_0)
		{
			if (this.bool_0)
			{
				class42_0.method_0();
			}
			this.action_0(class42_0);
		}

		// Token: 0x04000255 RID: 597
		public Stream stream_0;

		// Token: 0x04000256 RID: 598
		public bool bool_0;

		// Token: 0x04000257 RID: 599
		public Action<Class42> action_0;

		// Token: 0x04000258 RID: 600
		public Action<Exception> action_1;

		// Token: 0x04000259 RID: 601
		public Action<Class42> action_2;

		// Token: 0x0400025A RID: 602
		public Action<Class42> action_3;

		// Token: 0x0400025B RID: 603
		public Action<Class42> action_4;
	}
}
