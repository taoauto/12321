﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000315 RID: 789
public class GClass129 : Encoder
{
	// Token: 0x17000AA0 RID: 2720
	// (get) Token: 0x06002DB7 RID: 11703 RVA: 0x000215D8 File Offset: 0x0001F7D8
	// (set) Token: 0x06002DB8 RID: 11704 RVA: 0x000215E0 File Offset: 0x0001F7E0
	protected char Char_0 { get; set; }

	// Token: 0x06002DB9 RID: 11705 RVA: 0x00133C10 File Offset: 0x00131E10
	static GClass129()
	{
		for (int i = 0; i < Class437.char_0.Length; i++)
		{
			GClass129.byte_0[(int)Class437.char_0[i]] = (byte)i;
		}
	}

	// Token: 0x06002DBA RID: 11706 RVA: 0x00133C50 File Offset: 0x00131E50
	public virtual int GetByteCount(char[] chars, int index, int count, bool flush)
	{
		if (chars == null)
		{
			throw new ArgumentNullException("chars");
		}
		if (index < 0 || index > chars.Length)
		{
			throw new ArgumentOutOfRangeException("index");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		if (index + count > chars.Length)
		{
			throw new ArgumentOutOfRangeException("chars");
		}
		EncoderFallbackBuffer encoderFallbackBuffer = null;
		char c = this.Char_0;
		int num = 0;
		int num2 = index + count;
		while (index < num2)
		{
			char c2 = chars[index];
			if (c == '\0')
			{
				goto IL_AD;
			}
			if (encoderFallbackBuffer == null)
			{
				encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
			}
			if (!char.IsLowSurrogate(c2))
			{
				if (encoderFallbackBuffer.Fallback(c, index - 1))
				{
					GClass129.smethod_0(encoderFallbackBuffer, ref num);
				}
				c = '\0';
				goto IL_AD;
			}
			if (encoderFallbackBuffer.Fallback(c, c2, index - 1))
			{
				GClass129.smethod_0(encoderFallbackBuffer, ref num);
			}
			c = '\0';
			IL_105:
			index++;
			continue;
			IL_AD:
			if ((int)c2 < GClass129.byte_0.Length && (GClass129.byte_0[(int)c2] != 0 || c2 == '\0'))
			{
				num++;
				goto IL_105;
			}
			if (char.IsHighSurrogate(c2))
			{
				c = c2;
				goto IL_105;
			}
			if (encoderFallbackBuffer == null)
			{
				encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
			}
			if (encoderFallbackBuffer.Fallback(c2, index))
			{
				GClass129.smethod_0(encoderFallbackBuffer, ref num);
				goto IL_105;
			}
			goto IL_105;
		}
		if (flush && c != '\0')
		{
			if (encoderFallbackBuffer == null)
			{
				encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
			}
			if (encoderFallbackBuffer.Fallback(c, index - 1))
			{
				GClass129.smethod_0(encoderFallbackBuffer, ref num);
			}
		}
		return num;
	}

	// Token: 0x06002DBB RID: 11707 RVA: 0x00133DB0 File Offset: 0x00131FB0
	public virtual int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex, bool flush)
	{
		if (chars == null)
		{
			throw new ArgumentNullException("chars");
		}
		if (charIndex < 0 || charIndex > chars.Length)
		{
			throw new ArgumentOutOfRangeException("charIndex");
		}
		if (charCount < 0)
		{
			throw new ArgumentOutOfRangeException("charCount");
		}
		if (charIndex + charCount > chars.Length)
		{
			throw new ArgumentOutOfRangeException("chars");
		}
		if (bytes == null)
		{
			throw new ArgumentNullException("bytes");
		}
		if (byteIndex >= 0 && byteIndex <= bytes.Length)
		{
			EncoderFallbackBuffer encoderFallbackBuffer = null;
			char c = this.Char_0;
			int num = charIndex + charCount;
			int num2 = byteIndex;
			while (charIndex < num)
			{
				char c2 = chars[charIndex];
				if (c == '\0')
				{
					goto IL_D4;
				}
				if (encoderFallbackBuffer == null)
				{
					encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
				}
				if (!char.IsLowSurrogate(c2))
				{
					if (encoderFallbackBuffer.Fallback(c, charIndex - 1))
					{
						GClass129.smethod_1(encoderFallbackBuffer, bytes, ref num2);
					}
					c = '\0';
					goto IL_D4;
				}
				if (encoderFallbackBuffer.Fallback(c, c2, charIndex - 1))
				{
					GClass129.smethod_1(encoderFallbackBuffer, bytes, ref num2);
				}
				c = '\0';
				IL_13B:
				charIndex++;
				continue;
				IL_D4:
				byte byte_;
				if ((int)c2 < GClass129.byte_0.Length && ((byte_ = GClass129.byte_0[(int)c2]) != 0 || c2 == '\0'))
				{
					GClass129.smethod_2(bytes, num2, byte_);
					num2++;
					goto IL_13B;
				}
				if (char.IsHighSurrogate(c2))
				{
					c = c2;
					goto IL_13B;
				}
				if (encoderFallbackBuffer == null)
				{
					encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
				}
				if (encoderFallbackBuffer.Fallback(c2, charIndex))
				{
					GClass129.smethod_1(encoderFallbackBuffer, bytes, ref num2);
					goto IL_13B;
				}
				goto IL_13B;
			}
			if (flush)
			{
				if (c != '\0')
				{
					if (encoderFallbackBuffer == null)
					{
						encoderFallbackBuffer = (base.Fallback ?? EncoderFallback.ReplacementFallback).CreateFallbackBuffer();
					}
					if (encoderFallbackBuffer.Fallback(c, charIndex - 1))
					{
						GClass129.smethod_1(encoderFallbackBuffer, bytes, ref num2);
					}
				}
			}
			else
			{
				this.Char_0 = c;
			}
			return num2 - byteIndex;
		}
		throw new ArgumentOutOfRangeException("byteIndex");
	}

	// Token: 0x06002DBC RID: 11708 RVA: 0x00133F60 File Offset: 0x00132160
	protected static void smethod_0(EncoderFallbackBuffer encoderFallbackBuffer_0, ref int int_0)
	{
		while (encoderFallbackBuffer_0.Remaining > 0)
		{
			char nextChar = encoderFallbackBuffer_0.GetNextChar();
			if ((int)nextChar >= GClass129.byte_0.Length || (GClass129.byte_0[(int)nextChar] == 0 && nextChar != '\0'))
			{
				throw new EncoderFallbackException();
			}
			int_0++;
		}
	}

	// Token: 0x06002DBD RID: 11709 RVA: 0x00133FA4 File Offset: 0x001321A4
	protected static void smethod_1(EncoderFallbackBuffer encoderFallbackBuffer_0, byte[] byte_1, ref int int_0)
	{
		while (encoderFallbackBuffer_0.Remaining > 0)
		{
			char nextChar = encoderFallbackBuffer_0.GetNextChar();
			byte byte_2;
			if ((int)nextChar >= GClass129.byte_0.Length || ((byte_2 = GClass129.byte_0[(int)nextChar]) == 0 && nextChar != '\0'))
			{
				throw new EncoderFallbackException();
			}
			GClass129.smethod_2(byte_1, int_0, byte_2);
			int_0++;
		}
	}

	// Token: 0x06002DBE RID: 11710 RVA: 0x0000897C File Offset: 0x00006B7C
	protected static void smethod_2(byte[] byte_1, int int_0, byte byte_2)
	{
		if (int_0 == byte_1.Length)
		{
			throw new ArgumentException("bytes");
		}
		byte_1[int_0] = byte_2;
	}

	// Token: 0x04001F03 RID: 7939
	private static readonly byte[] byte_0 = new byte[7930];

	// Token: 0x04001F04 RID: 7940
	[CompilerGenerated]
	private char char_0;
}
