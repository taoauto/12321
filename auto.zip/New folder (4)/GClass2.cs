﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

// Token: 0x02000005 RID: 5
public static class GClass2
{
	// Token: 0x0600000A RID: 10 RVA: 0x00002E78 File Offset: 0x00001078
	public static string smethod_0(this string string_0)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		return new Regex("(\\&(?<text>\\w{1,4})\\;)|(\\&#(?<code>\\w{1,4})\\;)", RegexOptions.Compiled).Replace(string_0, new MatchEvaluator(GClass2.Class1.<>9.method_0));
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00021B54 File Offset: 0x0001FD54
	public static string smethod_1(this string string_0)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		return new Regex("\\\\u(?<code>[0-9a-f]{4})", RegexOptions.IgnoreCase | RegexOptions.Compiled).Replace(string_0, new MatchEvaluator(GClass2.Class1.<>9.method_1));
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00021BA0 File Offset: 0x0001FDA0
	public static string smethod_2(this string string_0, string string_1, int int_0, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("left");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("left");
		}
		if (int_0 < 0)
		{
			throw Class13.smethod_1<int>("startIndex", 0);
		}
		if (int_0 >= string_0.Length)
		{
			throw new ArgumentOutOfRangeException("startIndex", Class2.String_9);
		}
		int num = string_0.IndexOf(string_1, int_0, stringComparison_0);
		if (num == -1)
		{
			return string.Empty;
		}
		int num2 = num + string_1.Length;
		int length = string_0.Length - num2;
		return string_0.Substring(num2, length);
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00002EB8 File Offset: 0x000010B8
	public static string smethod_3(this string string_0, string string_1, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		return string_0.smethod_2(string_1, 0, stringComparison_0);
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00021C34 File Offset: 0x0001FE34
	public static string smethod_4(this string string_0, string string_1, string string_2, int int_0, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("left");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("left");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("right");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("right");
		}
		if (int_0 < 0)
		{
			throw Class13.smethod_1<int>("startIndex", 0);
		}
		if (int_0 >= string_0.Length)
		{
			throw new ArgumentOutOfRangeException("startIndex", Class2.String_9);
		}
		int num = string_0.IndexOf(string_1, int_0, stringComparison_0);
		if (num == -1)
		{
			return string.Empty;
		}
		int num2 = num + string_1.Length;
		int num3 = string_0.IndexOf(string_2, num2, stringComparison_0);
		if (num3 == -1)
		{
			return string.Empty;
		}
		int length = num3 - num2;
		return string_0.Substring(num2, length);
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002EC3 File Offset: 0x000010C3
	public static string smethod_5(this string string_0, string string_1, string string_2, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		return string_0.smethod_4(string_1, string_2, 0, stringComparison_0);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00021CFC File Offset: 0x0001FEFC
	public static string smethod_6(this string string_0, string string_1, int int_0, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("left");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("left");
		}
		if (int_0 < 0)
		{
			throw Class13.smethod_1<int>("startIndex", 0);
		}
		if (int_0 >= string_0.Length)
		{
			throw new ArgumentOutOfRangeException("startIndex", Class2.String_9);
		}
		int num = string_0.LastIndexOf(string_1, int_0, stringComparison_0);
		if (num == -1)
		{
			return string.Empty;
		}
		int num2 = num + string_1.Length;
		int length = string_0.Length - num2;
		return string_0.Substring(num2, length);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00002ECF File Offset: 0x000010CF
	public static string smethod_7(this string string_0, string string_1, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		return string_0.smethod_6(string_1, string_0.Length - 1, stringComparison_0);
	}

	// Token: 0x06000012 RID: 18 RVA: 0x00021D90 File Offset: 0x0001FF90
	public static string smethod_8(this string string_0, string string_1, string string_2, int int_0, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("left");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("left");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("right");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("right");
		}
		if (int_0 < 0)
		{
			throw Class13.smethod_1<int>("startIndex", 0);
		}
		if (int_0 >= string_0.Length)
		{
			throw new ArgumentOutOfRangeException("startIndex", Class2.String_9);
		}
		int num = string_0.LastIndexOf(string_1, int_0, stringComparison_0);
		if (num == -1)
		{
			return string.Empty;
		}
		int num2 = num + string_1.Length;
		int num3 = string_0.IndexOf(string_2, num2, stringComparison_0);
		if (num3 != -1)
		{
			int length = num3 - num2;
			return string_0.Substring(num2, length);
		}
		if (num == 0)
		{
			return string.Empty;
		}
		return string_0.smethod_8(string_1, string_2, num - 1, stringComparison_0);
	}

	// Token: 0x06000013 RID: 19 RVA: 0x00002EEF File Offset: 0x000010EF
	public static string smethod_9(this string string_0, string string_1, string string_2, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return string.Empty;
		}
		return string_0.smethod_8(string_1, string_2, string_0.Length - 1, stringComparison_0);
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00021E68 File Offset: 0x00020068
	public static string[] smethod_10(this string string_0, string string_1, string string_2, int int_0, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return new string[0];
		}
		if (string_1 == null)
		{
			throw new ArgumentNullException("left");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("left");
		}
		if (string_2 == null)
		{
			throw new ArgumentNullException("right");
		}
		if (string_2.Length == 0)
		{
			throw Class13.smethod_0("right");
		}
		if (int_0 < 0)
		{
			throw Class13.smethod_1<int>("startIndex", 0);
		}
		if (int_0 >= string_0.Length)
		{
			throw new ArgumentOutOfRangeException("startIndex", Class2.String_9);
		}
		int startIndex = int_0;
		List<string> list = new List<string>();
		for (;;)
		{
			int num = string_0.IndexOf(string_1, startIndex, stringComparison_0);
			if (num == -1)
			{
				break;
			}
			int num2 = num + string_1.Length;
			int num3 = string_0.IndexOf(string_2, num2, stringComparison_0);
			if (num3 == -1)
			{
				break;
			}
			int length = num3 - num2;
			list.Add(string_0.Substring(num2, length));
			startIndex = num3 + string_2.Length;
		}
		return list.ToArray();
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002F10 File Offset: 0x00001110
	public static string[] smethod_11(this string string_0, string string_1, string string_2, StringComparison stringComparison_0 = StringComparison.Ordinal)
	{
		return string_0.smethod_10(string_1, string_2, 0, stringComparison_0);
	}

	// Token: 0x04000002 RID: 2
	private static readonly Dictionary<string, string> dictionary_0 = new Dictionary<string, string>
	{
		{
			"apos",
			"'"
		},
		{
			"quot",
			"\""
		},
		{
			"amp",
			"&"
		},
		{
			"lt",
			"<"
		},
		{
			"gt",
			">"
		}
	};

	// Token: 0x02000006 RID: 6
	[CompilerGenerated]
	[Serializable]
	private sealed class Class1
	{
		// Token: 0x06000019 RID: 25 RVA: 0x00021FB4 File Offset: 0x000201B4
		internal string method_0(Match match_0)
		{
			if (match_0.Groups["text"].Success)
			{
				string result;
				if (GClass2.dictionary_0.TryGetValue(match_0.Groups["text"].Value, out result))
				{
					return result;
				}
			}
			else if (match_0.Groups["code"].Success)
			{
				return ((char)int.Parse(match_0.Groups["code"].Value)).ToString();
			}
			return match_0.Value;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00022040 File Offset: 0x00020240
		internal string method_1(Match match_0)
		{
			return ((char)int.Parse(match_0.Groups["code"].Value, NumberStyles.HexNumber)).ToString();
		}

		// Token: 0x04000003 RID: 3
		public static readonly GClass2.Class1 <>9 = new GClass2.Class1();

		// Token: 0x04000004 RID: 4
		public static MatchEvaluator <>9__1_0;

		// Token: 0x04000005 RID: 5
		public static MatchEvaluator <>9__2_0;
	}
}
