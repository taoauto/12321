﻿using System;
using System.Drawing;

// Token: 0x02000126 RID: 294
public class GClass92 : GClass87
{
	// Token: 0x06000ED4 RID: 3796 RVA: 0x0000C87E File Offset: 0x0000AA7E
	public GClass92(Pen pen_1)
	{
		this.pen_0 = pen_1;
	}

	// Token: 0x06000ED5 RID: 3797 RVA: 0x000562F4 File Offset: 0x000544F4
	public override void \u206F\u202D\u202D\u206E\u200C\u200D\u200B\u200C\u206A\u200D\u200C\u200D\u206F\u202E\u202B\u202A\u202E\u202A\u206C\u202B\u200C\u202A\u206C\u202E\u206D\u206A\u206C\u206F\u206B\u206C\u206F\u200F\u202D\u206C\u202E\u200D\u200F\u200C\u202D\u200C\u202E(Graphics graphics_0, Point point_0, GClass86 gclass86_0)
	{
		Point point = gclass86_0.fastColoredTextBox_0.method_95(gclass86_0.GStruct2_1);
		Rectangle rectangle_ = new Rectangle(point.X - 5, point.Y + gclass86_0.fastColoredTextBox_0.Int32_2 - 2, 4, 3);
		graphics_0.FillPath(Brushes.White, GClass87.smethod_1(rectangle_, 1));
		graphics_0.DrawPath(this.pen_0, GClass87.smethod_1(rectangle_, 1));
		this.vmethod_1(gclass86_0.fastColoredTextBox_0, new GClass105(new Rectangle(point.X - gclass86_0.fastColoredTextBox_0.Int32_4, point.Y, gclass86_0.fastColoredTextBox_0.Int32_4, gclass86_0.fastColoredTextBox_0.Int32_2), this));
	}

	// Token: 0x04000765 RID: 1893
	public Pen pen_0;
}
