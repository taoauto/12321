﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x02000210 RID: 528
public class GClass121 : ToolStrip
{
	// Token: 0x06001B3D RID: 6973 RVA: 0x00013B35 File Offset: 0x00011D35
	public GClass121()
	{
		this.method_0();
	}

	// Token: 0x06001B3E RID: 6974 RVA: 0x000D0C48 File Offset: 0x000CEE48
	public GClass121(params GClass122[] gclass122_1) : base(gclass122_1)
	{
		this.method_0();
	}

	// Token: 0x06001B3F RID: 6975 RVA: 0x000D0C70 File Offset: 0x000CEE70
	protected void method_0()
	{
		base.RenderMode = ToolStripRenderMode.ManagerRenderMode;
		base.Renderer = this.class244_0;
		this.class244_0.ToolStripRenderMode_0 = this.ToolStripRenderMode_1;
		this.designerVerb_0 = new DesignerVerb("Insert tab page", new EventHandler(this.method_1));
	}

	// Token: 0x1700067B RID: 1659
	// (get) Token: 0x06001B40 RID: 6976 RVA: 0x000D0CC0 File Offset: 0x000CEEC0
	// (set) Token: 0x06001B41 RID: 6977 RVA: 0x00013B4E File Offset: 0x00011D4E
	public virtual ISite Site
	{
		get
		{
			ISite site = base.Site;
			if (site != null && site.DesignMode)
			{
				IContainer container = site.Container;
				if (container != null)
				{
					IDesignerHost designerHost = container as IDesignerHost;
					if (designerHost != null)
					{
						IDesigner designer = designerHost.GetDesigner(site.Component);
						if (designer != null && !designer.Verbs.Contains(this.designerVerb_0))
						{
							designer.Verbs.Add(this.designerVerb_0);
						}
					}
				}
			}
			return site;
		}
		set
		{
			base.Site = value;
		}
	}

	// Token: 0x06001B42 RID: 6978 RVA: 0x000D0D2C File Offset: 0x000CEF2C
	protected void method_1(object sender, EventArgs e)
	{
		ISite site = base.Site;
		if (site != null && site.DesignMode)
		{
			IContainer container = site.Container;
			if (container != null)
			{
				GClass122 gclass = new GClass122();
				container.Add(gclass);
				gclass.Text = gclass.Name;
			}
		}
	}

	// Token: 0x1700067C RID: 1660
	// (get) Token: 0x06001B43 RID: 6979 RVA: 0x00013B57 File Offset: 0x00011D57
	// (set) Token: 0x06001B44 RID: 6980 RVA: 0x00013B5F File Offset: 0x00011D5F
	public ToolStripRenderer ToolStripRenderer_0
	{
		get
		{
			return this.class244_0;
		}
		set
		{
			base.Renderer = this.class244_0;
		}
	}

	// Token: 0x1700067D RID: 1661
	// (get) Token: 0x06001B45 RID: 6981 RVA: 0x00013B6D File Offset: 0x00011D6D
	// (set) Token: 0x06001B46 RID: 6982 RVA: 0x00013B75 File Offset: 0x00011D75
	public ToolStripLayoutStyle ToolStripLayoutStyle_0
	{
		get
		{
			return base.LayoutStyle;
		}
		set
		{
			switch (value)
			{
			case ToolStripLayoutStyle.StackWithOverflow:
			case ToolStripLayoutStyle.HorizontalStackWithOverflow:
			case ToolStripLayoutStyle.VerticalStackWithOverflow:
				base.LayoutStyle = ToolStripLayoutStyle.StackWithOverflow;
				return;
			case ToolStripLayoutStyle.Flow:
				base.LayoutStyle = ToolStripLayoutStyle.Flow;
				return;
			case ToolStripLayoutStyle.Table:
				base.LayoutStyle = ToolStripLayoutStyle.Table;
				return;
			default:
				base.LayoutStyle = ToolStripLayoutStyle.StackWithOverflow;
				return;
			}
		}
	}

	// Token: 0x1700067E RID: 1662
	// (get) Token: 0x06001B47 RID: 6983 RVA: 0x00013BB0 File Offset: 0x00011DB0
	// (set) Token: 0x06001B48 RID: 6984 RVA: 0x00013BB8 File Offset: 0x00011DB8
	[Obsolete("Use RenderStyle instead")]
	[Browsable(false)]
	public ToolStripRenderMode ToolStripRenderMode_0
	{
		get
		{
			return base.RenderMode;
		}
		set
		{
			this.ToolStripRenderMode_1 = value;
		}
	}

	// Token: 0x1700067F RID: 1663
	// (get) Token: 0x06001B49 RID: 6985 RVA: 0x00013BC1 File Offset: 0x00011DC1
	// (set) Token: 0x06001B4A RID: 6986 RVA: 0x00013BCE File Offset: 0x00011DCE
	[Category("Appearance")]
	[Description("Gets or sets render style for TabStrip. You should use this property instead of RenderMode.")]
	public ToolStripRenderMode ToolStripRenderMode_1
	{
		get
		{
			return this.class244_0.ToolStripRenderMode_0;
		}
		set
		{
			this.class244_0.ToolStripRenderMode_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000680 RID: 1664
	// (get) Token: 0x06001B4B RID: 6987 RVA: 0x00013BE2 File Offset: 0x00011DE2
	protected virtual Padding DefaultPadding
	{
		get
		{
			return Padding.Empty;
		}
	}

	// Token: 0x17000681 RID: 1665
	// (get) Token: 0x06001B4C RID: 6988 RVA: 0x00013BE9 File Offset: 0x00011DE9
	// (set) Token: 0x06001B4D RID: 6989 RVA: 0x00002E18 File Offset: 0x00001018
	[Browsable(false)]
	public Padding Padding_0
	{
		get
		{
			return this.DefaultPadding;
		}
		set
		{
		}
	}

	// Token: 0x17000682 RID: 1666
	// (get) Token: 0x06001B4E RID: 6990 RVA: 0x00013BF1 File Offset: 0x00011DF1
	// (set) Token: 0x06001B4F RID: 6991 RVA: 0x00013BFE File Offset: 0x00011DFE
	[Category("Appearance")]
	[Description("Specifies if TabStrip should use system visual styles for painting items")]
	public bool Boolean_0
	{
		get
		{
			return this.class244_0.Boolean_1;
		}
		set
		{
			this.class244_0.Boolean_1 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000683 RID: 1667
	// (get) Token: 0x06001B50 RID: 6992 RVA: 0x00013C12 File Offset: 0x00011E12
	// (set) Token: 0x06001B51 RID: 6993 RVA: 0x00013C1F File Offset: 0x00011E1F
	[Category("Appearance")]
	[Description("Specifies if TabButtons should be drawn flipped (for right- and bottom-aligned TabStrips)")]
	public bool Boolean_1
	{
		get
		{
			return this.class244_0.Boolean_0;
		}
		set
		{
			this.class244_0.Boolean_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000684 RID: 1668
	// (get) Token: 0x06001B52 RID: 6994 RVA: 0x00013C33 File Offset: 0x00011E33
	// (set) Token: 0x06001B53 RID: 6995 RVA: 0x00013C3B File Offset: 0x00011E3B
	public GClass122 GClass122_0
	{
		get
		{
			return this.gclass122_0;
		}
		set
		{
			if (value == null)
			{
				return;
			}
			if (this.gclass122_0 == value)
			{
				return;
			}
			if (value.Owner != this)
			{
				throw new ArgumentException("Cannot select TabButtons that do not belong to this TabStrip");
			}
			this.OnItemClicked(new ToolStripItemClickedEventArgs(value));
		}
	}

	// Token: 0x1400004A RID: 74
	// (add) Token: 0x06001B54 RID: 6996 RVA: 0x000D0D70 File Offset: 0x000CEF70
	// (remove) Token: 0x06001B55 RID: 6997 RVA: 0x000D0DA8 File Offset: 0x000CEFA8
	public event EventHandler<GEventArgs22> Event_0
	{
		[CompilerGenerated]
		add
		{
			EventHandler<GEventArgs22> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs22> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs22> value2 = (EventHandler<GEventArgs22>)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs22>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler<GEventArgs22> eventHandler = this.eventHandler_0;
			EventHandler<GEventArgs22> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<GEventArgs22> value2 = (EventHandler<GEventArgs22>)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs22>>(ref this.eventHandler_0, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x06001B56 RID: 6998 RVA: 0x00013C6B File Offset: 0x00011E6B
	protected void method_2(GClass122 gclass122_1)
	{
		base.Invalidate();
		if (this.eventHandler_0 != null)
		{
			this.eventHandler_0(this, new GEventArgs22(gclass122_1));
		}
	}

	// Token: 0x06001B57 RID: 6999 RVA: 0x00013C8D File Offset: 0x00011E8D
	protected virtual void OnItemAdded(ToolStripItemEventArgs e)
	{
		base.OnItemAdded(e);
		if (e.Item is GClass122)
		{
			this.GClass122_0 = (GClass122)e.Item;
		}
	}

	// Token: 0x06001B58 RID: 7000 RVA: 0x000D0DE0 File Offset: 0x000CEFE0
	protected virtual void OnItemClicked(ToolStripItemClickedEventArgs e)
	{
		GClass122 gclass = e.ClickedItem as GClass122;
		if (gclass != null)
		{
			base.SuspendLayout();
			this.gclass122_0 = gclass;
			base.ResumeLayout();
			this.method_2(gclass);
		}
		base.OnItemClicked(e);
	}

	// Token: 0x04001150 RID: 4432
	private Class244 class244_0 = new Class244();

	// Token: 0x04001151 RID: 4433
	protected GClass122 gclass122_0;

	// Token: 0x04001152 RID: 4434
	private DesignerVerb designerVerb_0;

	// Token: 0x04001153 RID: 4435
	[CompilerGenerated]
	private EventHandler<GEventArgs22> eventHandler_0;
}
