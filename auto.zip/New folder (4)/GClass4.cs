﻿using System;
using System.IO;
using System.Security;
using Microsoft.Win32;

// Token: 0x0200000A RID: 10
public static class GClass4
{
	// Token: 0x17000043 RID: 67
	// (get) Token: 0x06000063 RID: 99 RVA: 0x000220C4 File Offset: 0x000202C4
	public static bool Boolean_0
	{
		get
		{
			Class15.Enum0 @enum = (Class15.Enum0)0;
			return Class15.InternetGetConnectedState(ref @enum, 0);
		}
	}

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000064 RID: 100 RVA: 0x000034F7 File Offset: 0x000016F7
	public static bool Boolean_1
	{
		get
		{
			return GClass4.smethod_5(Class15.Enum0.INTERNET_CONNECTION_MODEM);
		}
	}

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x06000065 RID: 101 RVA: 0x000034FF File Offset: 0x000016FF
	public static bool Boolean_2
	{
		get
		{
			return GClass4.smethod_5(Class15.Enum0.INTERNET_CONNECTION_LAN);
		}
	}

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x06000066 RID: 102 RVA: 0x00003507 File Offset: 0x00001707
	public static bool Boolean_3
	{
		get
		{
			return GClass4.smethod_5(Class15.Enum0.INTERNET_CONNECTION_PROXY);
		}
	}

	// Token: 0x17000047 RID: 71
	// (get) Token: 0x06000067 RID: 103 RVA: 0x000220DC File Offset: 0x000202DC
	// (set) Token: 0x06000068 RID: 104 RVA: 0x0002213C File Offset: 0x0002033C
	public static bool Boolean_4
	{
		get
		{
			bool result;
			try
			{
				result = GClass4.smethod_0();
			}
			catch (IOException)
			{
				result = false;
			}
			catch (SecurityException)
			{
				result = false;
			}
			catch (ObjectDisposedException)
			{
				result = false;
			}
			catch (UnauthorizedAccessException)
			{
				result = false;
			}
			return result;
		}
		set
		{
			try
			{
				GClass4.smethod_1(value);
			}
			catch (IOException)
			{
			}
			catch (SecurityException)
			{
			}
			catch (ObjectDisposedException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x06000069 RID: 105 RVA: 0x00022194 File Offset: 0x00020394
	// (set) Token: 0x0600006A RID: 106 RVA: 0x00022200 File Offset: 0x00020400
	public static GClass18 GClass18_0
	{
		get
		{
			string string_;
			GClass18 result;
			try
			{
				string_ = GClass4.smethod_2();
				goto IL_1E;
			}
			catch (IOException)
			{
				result = null;
			}
			catch (SecurityException)
			{
				result = null;
			}
			catch (ObjectDisposedException)
			{
				result = null;
			}
			catch (UnauthorizedAccessException)
			{
				result = null;
			}
			return result;
			IL_1E:
			GClass18 result2;
			GClass18.smethod_3(string_, out result2);
			return result2;
		}
		set
		{
			try
			{
				if (value != null)
				{
					GClass4.smethod_4(value.ToString());
				}
				else
				{
					GClass4.smethod_4(string.Empty);
				}
			}
			catch (SecurityException)
			{
			}
			catch (ObjectDisposedException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}

	// Token: 0x0600006B RID: 107 RVA: 0x0002225C File Offset: 0x0002045C
	public static bool smethod_0()
	{
		bool result;
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"))
		{
			object value = registryKey.GetValue("ProxyEnable");
			if (value == null)
			{
				result = false;
			}
			else
			{
				result = ((int)value != 0);
			}
		}
		return result;
	}

	// Token: 0x0600006C RID: 108 RVA: 0x000222B8 File Offset: 0x000204B8
	public static void smethod_1(bool bool_0)
	{
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"))
		{
			registryKey.SetValue("ProxyEnable", bool_0 ? 1 : 0);
		}
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00022308 File Offset: 0x00020508
	public static string smethod_2()
	{
		string result;
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"))
		{
			result = ((registryKey.GetValue("ProxyServer") as string) ?? string.Empty);
		}
		return result;
	}

	// Token: 0x0600006E RID: 110 RVA: 0x0002235C File Offset: 0x0002055C
	public static void smethod_3(string string_1, int int_0)
	{
		if (string_1 == null)
		{
			throw new ArgumentNullException("host");
		}
		if (string_1.Length == 0)
		{
			throw Class13.smethod_0("host");
		}
		if (!Class13.smethod_5(int_0))
		{
			throw Class13.smethod_4("port");
		}
		GClass4.smethod_4(string_1 + ":" + int_0.ToString());
	}

	// Token: 0x0600006F RID: 111 RVA: 0x000223B4 File Offset: 0x000205B4
	public static void smethod_4(string string_1)
	{
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"))
		{
			registryKey.SetValue("ProxyServer", string_1 ?? string.Empty);
		}
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00022404 File Offset: 0x00020604
	private static bool smethod_5(Class15.Enum0 enum0_0)
	{
		Class15.Enum0 @enum = (Class15.Enum0)0;
		Class15.InternetGetConnectedState(ref @enum, 0);
		return (@enum & enum0_0) > (Class15.Enum0)0;
	}

	// Token: 0x04000008 RID: 8
	private const string string_0 = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
}
