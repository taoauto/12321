﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x020000D8 RID: 216
public class GClass72
{
	// Token: 0x170002B7 RID: 695
	// (get) Token: 0x06000A01 RID: 2561 RVA: 0x000098D0 File Offset: 0x00007AD0
	// (set) Token: 0x06000A02 RID: 2562 RVA: 0x000098D8 File Offset: 0x00007AD8
	public bool Boolean_0 { get; set; }

	// Token: 0x170002B8 RID: 696
	// (get) Token: 0x06000A03 RID: 2563 RVA: 0x000098E1 File Offset: 0x00007AE1
	// (set) Token: 0x06000A04 RID: 2564 RVA: 0x000098E9 File Offset: 0x00007AE9
	public bool Boolean_1 { get; set; }

	// Token: 0x170002B9 RID: 697
	// (get) Token: 0x06000A05 RID: 2565 RVA: 0x000098F2 File Offset: 0x00007AF2
	// (set) Token: 0x06000A06 RID: 2566 RVA: 0x000098FA File Offset: 0x00007AFA
	public bool Boolean_2 { get; set; }

	// Token: 0x170002BA RID: 698
	// (get) Token: 0x06000A07 RID: 2567 RVA: 0x00009903 File Offset: 0x00007B03
	// (set) Token: 0x06000A08 RID: 2568 RVA: 0x0000990B File Offset: 0x00007B0B
	public bool Boolean_3 { get; set; }

	// Token: 0x170002BB RID: 699
	// (get) Token: 0x06000A09 RID: 2569 RVA: 0x00009914 File Offset: 0x00007B14
	// (set) Token: 0x06000A0A RID: 2570 RVA: 0x0000991C File Offset: 0x00007B1C
	public bool Boolean_4 { get; set; }

	// Token: 0x170002BC RID: 700
	// (get) Token: 0x06000A0B RID: 2571 RVA: 0x00009925 File Offset: 0x00007B25
	// (set) Token: 0x06000A0C RID: 2572 RVA: 0x0000992D File Offset: 0x00007B2D
	public bool Boolean_5 { get; set; }

	// Token: 0x06000A0D RID: 2573 RVA: 0x00009936 File Offset: 0x00007B36
	public GClass72()
	{
		this.Boolean_0 = true;
		this.Boolean_2 = true;
		this.Boolean_3 = true;
		this.Boolean_4 = true;
	}

	// Token: 0x06000A0E RID: 2574 RVA: 0x000411D4 File Offset: 0x0003F3D4
	public string method_0(FastColoredTextBox fastColoredTextBox_1)
	{
		this.fastColoredTextBox_0 = fastColoredTextBox_1;
		GClass86 gclass = new GClass86(fastColoredTextBox_1);
		gclass.method_2();
		return this.method_1(gclass);
	}

	// Token: 0x06000A0F RID: 2575 RVA: 0x000411FC File Offset: 0x0003F3FC
	public string method_1(GClass86 gclass86_0)
	{
		this.fastColoredTextBox_0 = gclass86_0.fastColoredTextBox_0;
		Dictionary<StyleIndex, object> dictionary = new Dictionary<StyleIndex, object>();
		StringBuilder stringBuilder = new StringBuilder();
		StringBuilder stringBuilder2 = new StringBuilder();
		StyleIndex styleIndex = StyleIndex.None;
		gclass86_0.method_40();
		int int_ = gclass86_0.GStruct2_0.int_1;
		dictionary[StyleIndex.None] = null;
		if (this.Boolean_2)
		{
			stringBuilder.AppendFormat("<font style=\"font-family: {0}, monospace; font-size: {1}pt; line-height: {2}px;\">", gclass86_0.fastColoredTextBox_0.Font.Name, gclass86_0.fastColoredTextBox_0.Font.SizeInPoints, gclass86_0.fastColoredTextBox_0.Int32_2);
		}
		if (this.Boolean_5)
		{
			stringBuilder2.AppendFormat("<span class=lineNumber>{0}</span>  ", int_ + 1);
		}
		bool flag = false;
		foreach (GStruct2 gstruct in ((IEnumerable<GStruct2>)gclass86_0))
		{
			GStruct0 gstruct2 = gclass86_0.fastColoredTextBox_0[gstruct.int_1][gstruct.int_0];
			if (gstruct2.styleIndex_0 != styleIndex)
			{
				this.method_4(stringBuilder, stringBuilder2, styleIndex);
				styleIndex = gstruct2.styleIndex_0;
				dictionary[styleIndex] = null;
			}
			if (gstruct.int_1 != int_)
			{
				for (int i = int_; i < gstruct.int_1; i++)
				{
					stringBuilder2.Append(this.Boolean_4 ? "<br>" : "\r\n");
					if (this.Boolean_5)
					{
						stringBuilder2.AppendFormat("<span class=lineNumber>{0}</span>  ", i + 2);
					}
				}
				int_ = gstruct.int_1;
				flag = false;
			}
			char char_ = gstruct2.char_0;
			if (char_ <= '&')
			{
				if (char_ != ' ')
				{
					if (char_ == '&')
					{
						stringBuilder2.Append("&amp;");
						continue;
					}
				}
				else if ((!flag && this.Boolean_1) || this.Boolean_0)
				{
					stringBuilder2.Append("&nbsp;");
					continue;
				}
			}
			else
			{
				if (char_ == '<')
				{
					stringBuilder2.Append("&lt;");
					continue;
				}
				if (char_ == '>')
				{
					stringBuilder2.Append("&gt;");
					continue;
				}
			}
			flag = true;
			stringBuilder2.Append(gstruct2.char_0);
		}
		this.method_4(stringBuilder, stringBuilder2, styleIndex);
		if (this.Boolean_2)
		{
			stringBuilder.Append("</font>");
		}
		if (this.Boolean_3)
		{
			stringBuilder2.Length = 0;
			stringBuilder2.Append("<style type=\"text/css\">");
			foreach (StyleIndex styleIndex_ in dictionary.Keys)
			{
				stringBuilder2.AppendFormat(".fctb{0}{{ {1} }}\r\n", this.method_3(styleIndex_), this.method_2(styleIndex_));
			}
			stringBuilder2.Append("</style>");
			stringBuilder.Insert(0, stringBuilder2.ToString());
		}
		if (this.Boolean_5)
		{
			stringBuilder.Insert(0, this.string_0);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000A10 RID: 2576 RVA: 0x00041500 File Offset: 0x0003F700
	private string method_2(StyleIndex styleIndex_0)
	{
		List<GClass87> list = new List<GClass87>();
		GClass88 gclass = null;
		int num = 1;
		bool flag = false;
		for (int i = 0; i < this.fastColoredTextBox_0.GClass87_0.Length; i++)
		{
			if (this.fastColoredTextBox_0.GClass87_0[i] != null && ((int)styleIndex_0 & num) != 0 && this.fastColoredTextBox_0.GClass87_0[i].GClass87.\u202E\u206C\u206D\u202A\u206F\u202C\u200B\u202D\u200F\u206F\u206D\u202A\u206A\u206A\u202C\u200F\u202B\u206E\u202A\u202D\u200C\u206F\u202E\u200F\u202B\u200E\u202D\u202A\u202C\u206F\u206E\u206C\u206B\u202D\u202C\u202C\u206F\u202B\u206A\u206B\u202E)
			{
				GClass87 gclass2 = this.fastColoredTextBox_0.GClass87_0[i];
				list.Add(gclass2);
				if (gclass2 is GClass88 && (!flag || this.fastColoredTextBox_0.Boolean_16))
				{
					flag = true;
					gclass = (gclass2 as GClass88);
				}
			}
			num <<= 1;
		}
		string text = "";
		if (!flag)
		{
			text = this.fastColoredTextBox_0.GClass88_0.GClass87.\u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E();
		}
		else
		{
			text = gclass.GClass87.\u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E();
		}
		foreach (GClass87 gclass3 in list)
		{
			if (!(gclass3 is GClass88))
			{
				text += gclass3.GClass87.\u200F\u202B\u200E\u206E\u202A\u206E\u202D\u206D\u202D\u206A\u206B\u202E\u206A\u202E\u200B\u200D\u200C\u202B\u202D\u202C\u200B\u200B\u202A\u206A\u206C\u202B\u206B\u206B\u206A\u200B\u202A\u206D\u200B\u206D\u202D\u200E\u200B\u200F\u200C\u200E\u202E();
			}
		}
		return text;
	}

	// Token: 0x06000A11 RID: 2577 RVA: 0x00041624 File Offset: 0x0003F824
	public static string smethod_0(Color color_0)
	{
		if (color_0 == Color.Transparent)
		{
			return "";
		}
		return string.Format("#{0:x2}{1:x2}{2:x2}", color_0.R, color_0.G, color_0.B);
	}

	// Token: 0x06000A12 RID: 2578 RVA: 0x00009965 File Offset: 0x00007B65
	private string method_3(StyleIndex styleIndex_0)
	{
		return styleIndex_0.ToString().Replace(" ", "").Replace(",", "");
	}

	// Token: 0x06000A13 RID: 2579 RVA: 0x00041674 File Offset: 0x0003F874
	private void method_4(StringBuilder stringBuilder_0, StringBuilder stringBuilder_1, StyleIndex styleIndex_0)
	{
		if (stringBuilder_1.Length == 0)
		{
			return;
		}
		if (this.Boolean_3)
		{
			stringBuilder_0.AppendFormat("<font class=fctb{0}>{1}</font>", this.method_3(styleIndex_0), stringBuilder_1.ToString());
		}
		else
		{
			string text = this.method_2(styleIndex_0);
			if (text != "")
			{
				stringBuilder_0.AppendFormat("<font style=\"{0}\">", text);
			}
			stringBuilder_0.Append(stringBuilder_1.ToString());
			if (text != "")
			{
				stringBuilder_0.Append("</font>");
			}
		}
		stringBuilder_1.Length = 0;
	}

	// Token: 0x040004E3 RID: 1251
	public string string_0 = "<style type=\"text/css\"> .lineNumber{font-family : monospace; font-size : small; font-style : normal; font-weight : normal; color : Teal; background-color : ThreedFace;} </style>";

	// Token: 0x040004E4 RID: 1252
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x040004E5 RID: 1253
	[CompilerGenerated]
	private bool bool_1;

	// Token: 0x040004E6 RID: 1254
	[CompilerGenerated]
	private bool bool_2;

	// Token: 0x040004E7 RID: 1255
	[CompilerGenerated]
	private bool bool_3;

	// Token: 0x040004E8 RID: 1256
	[CompilerGenerated]
	private bool bool_4;

	// Token: 0x040004E9 RID: 1257
	[CompilerGenerated]
	private bool bool_5;

	// Token: 0x040004EA RID: 1258
	private FastColoredTextBox fastColoredTextBox_0;
}
