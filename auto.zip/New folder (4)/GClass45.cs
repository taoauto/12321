﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;
using WebSocketSharp.Net;

// Token: 0x020000AA RID: 170
[ComVisible(true)]
[Serializable]
public class GClass45 : NameValueCollection, ISerializable
{
	// Token: 0x060007FF RID: 2047 RVA: 0x0000844A File Offset: 0x0000664A
	internal GClass45(Enum6 enum6_0, bool bool_0)
	{
		this._state = enum6_0;
		this._internallyUsed = bool_0;
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0003B854 File Offset: 0x00039A54
	protected GClass45(SerializationInfo serializationInfo_0, StreamingContext streamingContext_0)
	{
		if (serializationInfo_0 == null)
		{
			throw new ArgumentNullException("serializationInfo");
		}
		try
		{
			this._internallyUsed = serializationInfo_0.GetBoolean("InternallyUsed");
			this._state = (Enum6)serializationInfo_0.GetInt32("State");
			int @int = serializationInfo_0.GetInt32("Count");
			for (int i = 0; i < @int; i++)
			{
				base.Add(serializationInfo_0.GetString(i.ToString()), serializationInfo_0.GetString((@int + i).ToString()));
			}
		}
		catch (SerializationException ex)
		{
			throw new ArgumentException(ex.Message, "serializationInfo", ex);
		}
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x00008196 File Offset: 0x00006396
	public GClass45()
	{
	}

	// Token: 0x1700022E RID: 558
	// (get) Token: 0x06000802 RID: 2050 RVA: 0x00008460 File Offset: 0x00006660
	internal Enum6 Enum6_0
	{
		get
		{
			return this._state;
		}
	}

	// Token: 0x1700022F RID: 559
	// (get) Token: 0x06000803 RID: 2051 RVA: 0x00008468 File Offset: 0x00006668
	public virtual string[] AllKeys
	{
		get
		{
			return base.AllKeys;
		}
	}

	// Token: 0x17000230 RID: 560
	// (get) Token: 0x06000804 RID: 2052 RVA: 0x00008470 File Offset: 0x00006670
	public virtual int Count
	{
		get
		{
			return base.Count;
		}
	}

	// Token: 0x17000231 RID: 561
	public string this[HttpRequestHeader httpRequestHeader_0]
	{
		get
		{
			string name = GClass45.smethod_3(httpRequestHeader_0.ToString());
			return this.Get(name);
		}
		set
		{
			this.method_10(httpRequestHeader_0, value);
		}
	}

	// Token: 0x17000232 RID: 562
	public string this[HttpResponseHeader httpResponseHeader_0]
	{
		get
		{
			string name = GClass45.smethod_3(httpResponseHeader_0.ToString());
			return this.Get(name);
		}
		set
		{
			this.method_11(httpResponseHeader_0, value);
		}
	}

	// Token: 0x17000233 RID: 563
	// (get) Token: 0x06000809 RID: 2057 RVA: 0x0000848C File Offset: 0x0000668C
	public virtual NameObjectCollectionBase.KeysCollection Keys
	{
		get
		{
			return base.Keys;
		}
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x00008494 File Offset: 0x00006694
	private void method_0(string string_0, string string_1, Enum6 enum6_0)
	{
		base.Add(string_0, string_1);
		if (this._state != Enum6.Unspecified)
		{
			return;
		}
		if (enum6_0 == Enum6.Unspecified)
		{
			return;
		}
		this._state = enum6_0;
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x000084B2 File Offset: 0x000066B2
	private void method_1(Enum6 enum6_0)
	{
		if (this._state == Enum6.Unspecified)
		{
			return;
		}
		if (enum6_0 == Enum6.Unspecified)
		{
			return;
		}
		if (enum6_0 != this._state)
		{
			throw new InvalidOperationException("This instance does not allow the header.");
		}
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x0003B94C File Offset: 0x00039B4C
	private static string smethod_0(string string_0, string string_1)
	{
		if (string_0 == null)
		{
			string message = "The name is null.";
			throw new ArgumentNullException(string_1, message);
		}
		if (string_0.Length == 0)
		{
			throw new ArgumentException("The name is an empty string.", string_1);
		}
		string_0 = string_0.Trim();
		if (string_0.Length == 0)
		{
			throw new ArgumentException("The name is a string of spaces.", string_1);
		}
		if (!string_0.smethod_51())
		{
			throw new ArgumentException("The name contains an invalid character.", string_1);
		}
		return string_0;
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x0003B9B0 File Offset: 0x00039BB0
	private void method_2(string string_0, Enum6 enum6_0)
	{
		if (this._internallyUsed)
		{
			return;
		}
		bool bool_ = enum6_0 == Enum6.Response;
		if (GClass45.smethod_6(string_0, bool_))
		{
			throw new ArgumentException("The header is a restricted header.");
		}
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x0003B9E0 File Offset: 0x00039BE0
	private static string smethod_1(string string_0, string string_1)
	{
		if (string_0 == null)
		{
			return string.Empty;
		}
		string_0 = string_0.Trim();
		int length = string_0.Length;
		if (length == 0)
		{
			return string_0;
		}
		if (length > 65535)
		{
			string message = "The length of the value is greater than 65,535 characters.";
			throw new ArgumentOutOfRangeException(string_1, message);
		}
		if (!string_0.smethod_50())
		{
			throw new ArgumentException("The value contains an invalid character.", string_1);
		}
		return string_0;
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x0003BA38 File Offset: 0x00039C38
	private static Class71 smethod_2(string string_0)
	{
		StringComparison comparisonType = StringComparison.InvariantCultureIgnoreCase;
		foreach (Class71 @class in GClass45._headers.Values)
		{
			if (@class.String_0.Equals(string_0, comparisonType))
			{
				return @class;
			}
		}
		return null;
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x0003BAA4 File Offset: 0x00039CA4
	private static string smethod_3(string string_0)
	{
		Class71 @class;
		if (!GClass45._headers.TryGetValue(string_0, out @class))
		{
			return null;
		}
		return @class.String_0;
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x0003BAC8 File Offset: 0x00039CC8
	private static Enum6 smethod_4(string string_0)
	{
		Class71 @class = GClass45.smethod_2(string_0);
		if (@class == null)
		{
			return Enum6.Unspecified;
		}
		if (@class.Boolean_2)
		{
			if (@class.Boolean_3)
			{
				return Enum6.Unspecified;
			}
			return Enum6.Request;
		}
		else
		{
			if (!@class.Boolean_3)
			{
				return Enum6.Unspecified;
			}
			return Enum6.Response;
		}
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x0003BB00 File Offset: 0x00039D00
	private static bool smethod_5(string string_0, bool bool_0)
	{
		Class71 @class = GClass45.smethod_2(string_0);
		return @class != null && @class.method_0(bool_0);
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x0003BB20 File Offset: 0x00039D20
	private static bool smethod_6(string string_0, bool bool_0)
	{
		Class71 @class = GClass45.smethod_2(string_0);
		return @class != null && @class.method_1(bool_0);
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x000084D5 File Offset: 0x000066D5
	private void method_3(string string_0, string string_1, Enum6 enum6_0)
	{
		base.Set(string_0, string_1);
		if (this._state != Enum6.Unspecified)
		{
			return;
		}
		if (enum6_0 == Enum6.Unspecified)
		{
			return;
		}
		this._state = enum6_0;
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x000084F3 File Offset: 0x000066F3
	internal void method_4(string string_0)
	{
		base.Remove(string_0);
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x0003BB40 File Offset: 0x00039D40
	internal void method_5(string string_0, bool bool_0)
	{
		int num = string_0.IndexOf(':');
		if (num == -1)
		{
			throw new ArgumentException("It does not contain a colon character.", "header");
		}
		string text = string_0.Substring(0, num);
		string text2 = (num < string_0.Length - 1) ? string_0.Substring(num + 1) : string.Empty;
		text = GClass45.smethod_0(text, "header");
		text2 = GClass45.smethod_1(text2, "header");
		if (GClass45.smethod_5(text, bool_0))
		{
			base.Add(text, text2);
			return;
		}
		base.Set(text, text2);
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x000084FC File Offset: 0x000066FC
	internal void method_6(string string_0, string string_1, bool bool_0)
	{
		string_1 = GClass45.smethod_1(string_1, "value");
		if (GClass45.smethod_5(string_0, bool_0))
		{
			base.Add(string_0, string_1);
			return;
		}
		base.Set(string_0, string_1);
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x0003BBC4 File Offset: 0x00039DC4
	internal string method_7(bool bool_0)
	{
		int count = this.Count;
		if (count == 0)
		{
			return "\r\n";
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < count; i++)
		{
			string key = this.GetKey(i);
			if (GClass45.smethod_5(key, bool_0))
			{
				foreach (string arg in this.GetValues(i))
				{
					stringBuilder.AppendFormat("{0}: {1}\r\n", key, arg);
				}
			}
			else
			{
				stringBuilder.AppendFormat("{0}: {1}\r\n", key, this.Get(i));
			}
		}
		stringBuilder.Append("\r\n");
		return stringBuilder.ToString();
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x0003BC60 File Offset: 0x00039E60
	protected void method_8(string string_0, string string_1)
	{
		string_0 = GClass45.smethod_0(string_0, "headerName");
		string_1 = GClass45.smethod_1(string_1, "headerValue");
		Enum6 enum6_ = GClass45.smethod_4(string_0);
		this.method_1(enum6_);
		this.method_0(string_0, string_1, enum6_);
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x0003BCA0 File Offset: 0x00039EA0
	public void method_9(string string_0)
	{
		if (string_0 == null)
		{
			throw new ArgumentNullException("header");
		}
		int length = string_0.Length;
		if (length == 0)
		{
			throw new ArgumentException("An empty string.", "header");
		}
		int num = string_0.IndexOf(':');
		if (num == -1)
		{
			throw new ArgumentException("It does not contain a colon character.", "header");
		}
		string string_ = string_0.Substring(0, num);
		string text = (num < length - 1) ? string_0.Substring(num + 1) : string.Empty;
		string_ = GClass45.smethod_0(string_, "header");
		text = GClass45.smethod_1(text, "header");
		Enum6 enum6_ = GClass45.smethod_4(string_);
		this.method_2(string_, enum6_);
		this.method_1(enum6_);
		this.method_0(string_, text, enum6_);
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x0003BD50 File Offset: 0x00039F50
	public void method_10(HttpRequestHeader httpRequestHeader_0, string string_0)
	{
		string_0 = GClass45.smethod_1(string_0, "value");
		string string_ = GClass45.smethod_3(httpRequestHeader_0.ToString());
		this.method_2(string_, Enum6.Request);
		this.method_1(Enum6.Request);
		this.method_0(string_, string_0, Enum6.Request);
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x0003BD98 File Offset: 0x00039F98
	public void method_11(HttpResponseHeader httpResponseHeader_0, string string_0)
	{
		string_0 = GClass45.smethod_1(string_0, "value");
		string string_ = GClass45.smethod_3(httpResponseHeader_0.ToString());
		this.method_2(string_, Enum6.Response);
		this.method_1(Enum6.Response);
		this.method_0(string_, string_0, Enum6.Response);
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x0003BDE0 File Offset: 0x00039FE0
	public virtual void Add(string name, string value)
	{
		name = GClass45.smethod_0(name, "name");
		value = GClass45.smethod_1(value, "value");
		Enum6 enum6_ = GClass45.smethod_4(name);
		this.method_2(name, enum6_);
		this.method_1(enum6_);
		this.method_0(name, value, enum6_);
	}

	// Token: 0x0600081E RID: 2078 RVA: 0x00008525 File Offset: 0x00006725
	public virtual void Clear()
	{
		base.Clear();
		this._state = Enum6.Unspecified;
	}

	// Token: 0x0600081F RID: 2079 RVA: 0x00008534 File Offset: 0x00006734
	public virtual string Get(int index)
	{
		return base.Get(index);
	}

	// Token: 0x06000820 RID: 2080 RVA: 0x0000853D File Offset: 0x0000673D
	public virtual string Get(string name)
	{
		return base.Get(name);
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x00008546 File Offset: 0x00006746
	public virtual IEnumerator GetEnumerator()
	{
		return base.GetEnumerator();
	}

	// Token: 0x06000822 RID: 2082 RVA: 0x0000854E File Offset: 0x0000674E
	public virtual string GetKey(int index)
	{
		return base.GetKey(index);
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x0003BE28 File Offset: 0x0003A028
	public virtual string[] GetValues(int index)
	{
		string[] values = base.GetValues(index);
		if (values != null && values.Length != 0)
		{
			return values;
		}
		return null;
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x0003BE48 File Offset: 0x0003A048
	public virtual string[] GetValues(string name)
	{
		string[] values = base.GetValues(name);
		if (values != null && values.Length != 0)
		{
			return values;
		}
		return null;
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x0003BE68 File Offset: 0x0003A068
	[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		if (info == null)
		{
			throw new ArgumentNullException("serializationInfo");
		}
		info.AddValue("InternallyUsed", this._internallyUsed);
		info.AddValue("State", (int)this._state);
		int count = this.Count;
		info.AddValue("Count", count);
		for (int i = 0; i < count; i++)
		{
			info.AddValue(i.ToString(), this.GetKey(i));
			info.AddValue((count + i).ToString(), this.Get(i));
		}
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x00008557 File Offset: 0x00006757
	public static bool smethod_7(string string_0)
	{
		return GClass45.smethod_8(string_0, false);
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x00008560 File Offset: 0x00006760
	public static bool smethod_8(string string_0, bool bool_0)
	{
		string_0 = GClass45.smethod_0(string_0, "headerName");
		return GClass45.smethod_6(string_0, bool_0);
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x00002E18 File Offset: 0x00001018
	public virtual void OnDeserialization(object sender)
	{
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x0003BEF0 File Offset: 0x0003A0F0
	public void method_12(HttpRequestHeader httpRequestHeader_0)
	{
		string text = GClass45.smethod_3(httpRequestHeader_0.ToString());
		this.method_2(text, Enum6.Request);
		this.method_1(Enum6.Request);
		base.Remove(text);
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x0003BF28 File Offset: 0x0003A128
	public void method_13(HttpResponseHeader httpResponseHeader_0)
	{
		string text = GClass45.smethod_3(httpResponseHeader_0.ToString());
		this.method_2(text, Enum6.Response);
		this.method_1(Enum6.Response);
		base.Remove(text);
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0003BF60 File Offset: 0x0003A160
	public virtual void Remove(string name)
	{
		name = GClass45.smethod_0(name, "name");
		Enum6 enum6_ = GClass45.smethod_4(name);
		this.method_2(name, enum6_);
		this.method_1(enum6_);
		base.Remove(name);
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x0003BF98 File Offset: 0x0003A198
	public void method_14(HttpRequestHeader httpRequestHeader_0, string string_0)
	{
		string_0 = GClass45.smethod_1(string_0, "value");
		string string_ = GClass45.smethod_3(httpRequestHeader_0.ToString());
		this.method_2(string_, Enum6.Request);
		this.method_1(Enum6.Request);
		this.method_3(string_, string_0, Enum6.Request);
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x0003BFE0 File Offset: 0x0003A1E0
	public void method_15(HttpResponseHeader httpResponseHeader_0, string string_0)
	{
		string_0 = GClass45.smethod_1(string_0, "value");
		string string_ = GClass45.smethod_3(httpResponseHeader_0.ToString());
		this.method_2(string_, Enum6.Response);
		this.method_1(Enum6.Response);
		this.method_3(string_, string_0, Enum6.Response);
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x0003C028 File Offset: 0x0003A228
	public virtual void Set(string name, string value)
	{
		name = GClass45.smethod_0(name, "name");
		value = GClass45.smethod_1(value, "value");
		Enum6 enum6_ = GClass45.smethod_4(name);
		this.method_2(name, enum6_);
		this.method_1(enum6_);
		this.method_3(name, value, enum6_);
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x00004D9B File Offset: 0x00002F9B
	public byte[] method_16()
	{
		return Encoding.UTF8.GetBytes(this.ToString());
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x0003C070 File Offset: 0x0003A270
	public virtual string ToString()
	{
		int count = this.Count;
		if (count == 0)
		{
			return "\r\n";
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < count; i++)
		{
			stringBuilder.AppendFormat("{0}: {1}\r\n", this.GetKey(i), this.Get(i));
		}
		stringBuilder.Append("\r\n");
		return stringBuilder.ToString();
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x00008576 File Offset: 0x00006776
	[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter, SerializationFormatter = true)]
	void ISerializable.GetObjectData(SerializationInfo serializationInfo, StreamingContext streamingContext)
	{
		this.GetObjectData(serializationInfo, streamingContext);
	}

	// Token: 0x04000450 RID: 1104
	private static readonly Dictionary<string, Class71> _headers = new Dictionary<string, Class71>(StringComparer.InvariantCultureIgnoreCase)
	{
		{
			"Accept",
			new Class71("Accept", Enum6.Request | Enum6.Restricted | Enum6.MultiValue)
		},
		{
			"AcceptCharset",
			new Class71("Accept-Charset", Enum6.Request | Enum6.MultiValue)
		},
		{
			"AcceptEncoding",
			new Class71("Accept-Encoding", Enum6.Request | Enum6.MultiValue)
		},
		{
			"AcceptLanguage",
			new Class71("Accept-Language", Enum6.Request | Enum6.MultiValue)
		},
		{
			"AcceptRanges",
			new Class71("Accept-Ranges", Enum6.Response | Enum6.MultiValue)
		},
		{
			"Age",
			new Class71("Age", Enum6.Response)
		},
		{
			"Allow",
			new Class71("Allow", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"Authorization",
			new Class71("Authorization", Enum6.Request | Enum6.MultiValue)
		},
		{
			"CacheControl",
			new Class71("Cache-Control", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"Connection",
			new Class71("Connection", Enum6.Request | Enum6.Response | Enum6.Restricted | Enum6.MultiValue)
		},
		{
			"ContentEncoding",
			new Class71("Content-Encoding", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"ContentLanguage",
			new Class71("Content-Language", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"ContentLength",
			new Class71("Content-Length", Enum6.Request | Enum6.Response | Enum6.Restricted)
		},
		{
			"ContentLocation",
			new Class71("Content-Location", Enum6.Request | Enum6.Response)
		},
		{
			"ContentMd5",
			new Class71("Content-MD5", Enum6.Request | Enum6.Response)
		},
		{
			"ContentRange",
			new Class71("Content-Range", Enum6.Request | Enum6.Response)
		},
		{
			"ContentType",
			new Class71("Content-Type", Enum6.Request | Enum6.Response | Enum6.Restricted)
		},
		{
			"Cookie",
			new Class71("Cookie", Enum6.Request)
		},
		{
			"Cookie2",
			new Class71("Cookie2", Enum6.Request)
		},
		{
			"Date",
			new Class71("Date", Enum6.Request | Enum6.Response | Enum6.Restricted)
		},
		{
			"Expect",
			new Class71("Expect", Enum6.Request | Enum6.Restricted | Enum6.MultiValue)
		},
		{
			"Expires",
			new Class71("Expires", Enum6.Request | Enum6.Response)
		},
		{
			"ETag",
			new Class71("ETag", Enum6.Response)
		},
		{
			"From",
			new Class71("From", Enum6.Request)
		},
		{
			"Host",
			new Class71("Host", Enum6.Request | Enum6.Restricted)
		},
		{
			"IfMatch",
			new Class71("If-Match", Enum6.Request | Enum6.MultiValue)
		},
		{
			"IfModifiedSince",
			new Class71("If-Modified-Since", Enum6.Request | Enum6.Restricted)
		},
		{
			"IfNoneMatch",
			new Class71("If-None-Match", Enum6.Request | Enum6.MultiValue)
		},
		{
			"IfRange",
			new Class71("If-Range", Enum6.Request)
		},
		{
			"IfUnmodifiedSince",
			new Class71("If-Unmodified-Since", Enum6.Request)
		},
		{
			"KeepAlive",
			new Class71("Keep-Alive", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"LastModified",
			new Class71("Last-Modified", Enum6.Request | Enum6.Response)
		},
		{
			"Location",
			new Class71("Location", Enum6.Response)
		},
		{
			"MaxForwards",
			new Class71("Max-Forwards", Enum6.Request)
		},
		{
			"Pragma",
			new Class71("Pragma", Enum6.Request | Enum6.Response)
		},
		{
			"ProxyAuthenticate",
			new Class71("Proxy-Authenticate", Enum6.Response | Enum6.MultiValue)
		},
		{
			"ProxyAuthorization",
			new Class71("Proxy-Authorization", Enum6.Request)
		},
		{
			"ProxyConnection",
			new Class71("Proxy-Connection", Enum6.Request | Enum6.Response | Enum6.Restricted)
		},
		{
			"Public",
			new Class71("Public", Enum6.Response | Enum6.MultiValue)
		},
		{
			"Range",
			new Class71("Range", Enum6.Request | Enum6.Restricted | Enum6.MultiValue)
		},
		{
			"Referer",
			new Class71("Referer", Enum6.Request | Enum6.Restricted)
		},
		{
			"RetryAfter",
			new Class71("Retry-After", Enum6.Response)
		},
		{
			"SecWebSocketAccept",
			new Class71("Sec-WebSocket-Accept", Enum6.Response | Enum6.Restricted)
		},
		{
			"SecWebSocketExtensions",
			new Class71("Sec-WebSocket-Extensions", Enum6.Request | Enum6.Response | Enum6.Restricted | Enum6.MultiValueInRequest)
		},
		{
			"SecWebSocketKey",
			new Class71("Sec-WebSocket-Key", Enum6.Request | Enum6.Restricted)
		},
		{
			"SecWebSocketProtocol",
			new Class71("Sec-WebSocket-Protocol", Enum6.Request | Enum6.Response | Enum6.MultiValueInRequest)
		},
		{
			"SecWebSocketVersion",
			new Class71("Sec-WebSocket-Version", Enum6.Request | Enum6.Response | Enum6.Restricted | Enum6.MultiValueInResponse)
		},
		{
			"Server",
			new Class71("Server", Enum6.Response)
		},
		{
			"SetCookie",
			new Class71("Set-Cookie", Enum6.Response | Enum6.MultiValue)
		},
		{
			"SetCookie2",
			new Class71("Set-Cookie2", Enum6.Response | Enum6.MultiValue)
		},
		{
			"Te",
			new Class71("TE", Enum6.Request)
		},
		{
			"Trailer",
			new Class71("Trailer", Enum6.Request | Enum6.Response)
		},
		{
			"TransferEncoding",
			new Class71("Transfer-Encoding", Enum6.Request | Enum6.Response | Enum6.Restricted | Enum6.MultiValue)
		},
		{
			"Translate",
			new Class71("Translate", Enum6.Request)
		},
		{
			"Upgrade",
			new Class71("Upgrade", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"UserAgent",
			new Class71("User-Agent", Enum6.Request | Enum6.Restricted)
		},
		{
			"Vary",
			new Class71("Vary", Enum6.Response | Enum6.MultiValue)
		},
		{
			"Via",
			new Class71("Via", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"Warning",
			new Class71("Warning", Enum6.Request | Enum6.Response | Enum6.MultiValue)
		},
		{
			"WwwAuthenticate",
			new Class71("WWW-Authenticate", Enum6.Response | Enum6.Restricted | Enum6.MultiValue)
		}
	};

	// Token: 0x04000451 RID: 1105
	private bool _internallyUsed;

	// Token: 0x04000452 RID: 1106
	private Enum6 _state;
}
