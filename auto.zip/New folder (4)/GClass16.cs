﻿using System;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading;

// Token: 0x0200002F RID: 47
public abstract class GClass16 : IEquatable<GClass16>
{
	// Token: 0x170000B4 RID: 180
	// (get) Token: 0x0600021F RID: 543 RVA: 0x00004612 File Offset: 0x00002812
	public virtual GEnum4 GEnum4_0
	{
		get
		{
			return this.genum4_0;
		}
	}

	// Token: 0x170000B5 RID: 181
	// (get) Token: 0x06000220 RID: 544 RVA: 0x0000461A File Offset: 0x0000281A
	// (set) Token: 0x06000221 RID: 545 RVA: 0x00004622 File Offset: 0x00002822
	public virtual string \u206A\u200F\u206E\u206E\u206F\u200F\u200E\u206C\u200E\u200C\u206D\u200B\u202A\u206C\u206B\u200D\u200D\u200C\u202E\u202A\u202C\u200E\u206D\u206D\u200C\u206A\u202B\u200E\u200D\u206B\u200C\u200B\u206C\u202C\u206E\u202A\u202C\u206C\u202C\u202E\u202E
	{
		get
		{
			return this.string_0;
		}
		set
		{
			if (value == null)
			{
				throw new ArgumentNullException("Host");
			}
			if (value.Length == 0)
			{
				throw Class13.smethod_0("Host");
			}
			this.string_0 = value;
		}
	}

	// Token: 0x170000B6 RID: 182
	// (get) Token: 0x06000222 RID: 546 RVA: 0x0000464C File Offset: 0x0000284C
	// (set) Token: 0x06000223 RID: 547 RVA: 0x00004654 File Offset: 0x00002854
	public virtual int \u202E\u200D\u202E\u200E\u200F\u206F\u200D\u200F\u202A\u202D\u202D\u202A\u200B\u202C\u206D\u200D\u206B\u202E\u206A\u206F\u202A\u200C\u200B\u206A\u200E\u200E\u206E\u200D\u202B\u200F\u202C\u200F\u206E\u200E\u206E\u202A\u206A\u202C\u202E\u202A\u202E
	{
		get
		{
			return this.int_0;
		}
		set
		{
			if (!Class13.smethod_5(value))
			{
				throw Class13.smethod_4("Port");
			}
			this.int_0 = value;
		}
	}

	// Token: 0x170000B7 RID: 183
	// (get) Token: 0x06000224 RID: 548 RVA: 0x00004670 File Offset: 0x00002870
	// (set) Token: 0x06000225 RID: 549 RVA: 0x00004678 File Offset: 0x00002878
	public virtual string \u202D\u206E\u200E\u200D\u202D\u206D\u202B\u202C\u200F\u202E\u200C\u206B\u206E\u200E\u200E\u206A\u202D\u202D\u202B\u200C\u202B\u202D\u200E\u206F\u206E\u200F\u202A\u200F\u202E\u206E\u206B\u206B\u200E\u206A\u200D\u206C\u202E\u206A\u202B\u200D\u202E
	{
		get
		{
			return this.string_1;
		}
		set
		{
			if (value != null && value.Length > 255)
			{
				throw new ArgumentOutOfRangeException("Username", string.Format(Class2.String_10, 255));
			}
			this.string_1 = value;
		}
	}

	// Token: 0x170000B8 RID: 184
	// (get) Token: 0x06000226 RID: 550 RVA: 0x000046B0 File Offset: 0x000028B0
	// (set) Token: 0x06000227 RID: 551 RVA: 0x000046B8 File Offset: 0x000028B8
	public virtual string \u202E\u206C\u206C\u206B\u206D\u206B\u200E\u202D\u200D\u206A\u200F\u200C\u202E\u206E\u200C\u200C\u200C\u206F\u202D\u200E\u200F\u206F\u206B\u206E\u206B\u202A\u200C\u202A\u200E\u206F\u200C\u200E\u202A\u206D\u202A\u206C\u200D\u202B\u206F\u200D\u202E
	{
		get
		{
			return this.string_2;
		}
		set
		{
			if (value != null && value.Length > 255)
			{
				throw new ArgumentOutOfRangeException("Password", string.Format(Class2.String_10, 255));
			}
			this.string_2 = value;
		}
	}

	// Token: 0x170000B9 RID: 185
	// (get) Token: 0x06000228 RID: 552 RVA: 0x000046F0 File Offset: 0x000028F0
	// (set) Token: 0x06000229 RID: 553 RVA: 0x000046F8 File Offset: 0x000028F8
	public virtual int \u202B\u206E\u206C\u200C\u200F\u202D\u206A\u206A\u206D\u200B\u200E\u200D\u206B\u206B\u202B\u200C\u200C\u206F\u200C\u206B\u200D\u202D\u206A\u200E\u202A\u200C\u206A\u200D\u202E\u202C\u206C\u206F\u206D\u200B\u200C\u202E\u206B\u206F\u202D\u200D\u202E
	{
		get
		{
			return this.int_1;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("ConnectTimeout", 0);
			}
			this.int_1 = value;
		}
	}

	// Token: 0x170000BA RID: 186
	// (get) Token: 0x0600022A RID: 554 RVA: 0x00004711 File Offset: 0x00002911
	// (set) Token: 0x0600022B RID: 555 RVA: 0x00004719 File Offset: 0x00002919
	public virtual int \u206B\u202B\u200B\u206F\u202A\u202D\u202E\u206B\u200D\u200D\u200F\u202B\u202B\u206E\u200F\u206E\u202C\u206C\u200E\u200E\u202E\u206C\u202B\u202E\u200C\u206A\u206B\u200E\u206D\u206F\u206D\u200E\u206F\u200C\u206F\u206B\u200B\u206E\u202E\u202B\u202E
	{
		get
		{
			return this.int_2;
		}
		set
		{
			if (value < 0)
			{
				throw Class13.smethod_1<int>("ReadWriteTimeout", 0);
			}
			this.int_2 = value;
		}
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00004732 File Offset: 0x00002932
	protected internal GClass16(GEnum4 genum4_1)
	{
		this.genum4_0 = genum4_1;
	}

	// Token: 0x0600022D RID: 557 RVA: 0x0000475E File Offset: 0x0000295E
	protected internal GClass16(GEnum4 genum4_1, string string_3, int int_3)
	{
		this.genum4_0 = genum4_1;
		this.string_0 = string_3;
		this.int_0 = int_3;
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00026F20 File Offset: 0x00025120
	protected internal GClass16(GEnum4 genum4_1, string string_3, int int_3, string string_4, string string_5)
	{
		this.genum4_0 = genum4_1;
		this.string_0 = string_3;
		this.int_0 = int_3;
		this.string_1 = string_4;
		this.string_2 = string_5;
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00026F78 File Offset: 0x00025178
	public static GClass16 smethod_0(GEnum4 genum4_1, string string_3)
	{
		if (string_3 == null)
		{
			throw new ArgumentNullException("proxyAddress");
		}
		if (string_3.Length == 0)
		{
			throw Class13.smethod_0("proxyAddress");
		}
		string[] array = string_3.Split(new char[]
		{
			':'
		});
		int num = 0;
		string text = array[0];
		if (array.Length >= 2)
		{
			try
			{
				num = int.Parse(array[1]);
			}
			catch (Exception ex)
			{
				if (!(ex is FormatException) && !(ex is OverflowException))
				{
					throw;
				}
				throw new FormatException(Class2.String_35, ex);
			}
			if (!Class13.smethod_5(num))
			{
				throw new FormatException(Class2.String_35);
			}
		}
		string text2 = null;
		string text3 = null;
		if (array.Length >= 3)
		{
			text2 = array[2];
		}
		if (array.Length >= 4)
		{
			text3 = array[3];
		}
		return Class14.smethod_0(genum4_1, text, num, text2, text3);
	}

	// Token: 0x06000230 RID: 560 RVA: 0x0002703C File Offset: 0x0002523C
	public static bool smethod_1(GEnum4 genum4_1, string string_3, out GClass16 gclass16_0)
	{
		gclass16_0 = null;
		if (string.IsNullOrEmpty(string_3))
		{
			return false;
		}
		string[] array = string_3.Split(new char[]
		{
			':'
		});
		int num = 0;
		string text = array[0];
		if (array.Length >= 2 && (!int.TryParse(array[1], out num) || !Class13.smethod_5(num)))
		{
			return false;
		}
		string text2 = null;
		string text3 = null;
		if (array.Length >= 3)
		{
			text2 = array[2];
		}
		if (array.Length >= 4)
		{
			text3 = array[3];
		}
		bool result;
		try
		{
			gclass16_0 = Class14.smethod_0(genum4_1, text, num, text2, text3);
			return true;
		}
		catch (InvalidOperationException)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000231 RID: 561
	public abstract TcpClient \u202E\u202C\u200D\u202B\u200B\u206A\u202C\u206C\u202C\u200B\u200C\u202B\u202C\u202E\u200D\u200B\u200F\u202D\u200E\u202E\u200B\u206C\u206E\u206A\u206E\u202C\u206D\u200B\u200B\u202B\u200F\u202A\u206A\u202B\u202D\u202E\u202E\u200F\u206B\u200C\u202E(string string_3, int int_3, TcpClient tcpClient_0 = null);

	// Token: 0x06000232 RID: 562 RVA: 0x00004798 File Offset: 0x00002998
	public virtual string \u202B\u202E\u206A\u200C\u202B\u206D\u206F\u200E\u200D\u200C\u206F\u200E\u206F\u200F\u200F\u202B\u206E\u200C\u206B\u206E\u202C\u200B\u206F\u206E\u206C\u200D\u202C\u206C\u200B\u200F\u206D\u206C\u206C\u202A\u202B\u202A\u206E\u206E\u200D\u206B\u202E()
	{
		return string.Format("{0}:{1}", this.string_0, this.int_0);
	}

	// Token: 0x06000233 RID: 563 RVA: 0x000270D0 File Offset: 0x000252D0
	public virtual string vmethod_0()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendFormat("{0}:{1}", this.string_0, this.int_0);
		if (!string.IsNullOrEmpty(this.string_1))
		{
			stringBuilder.AppendFormat(":{0}", this.string_1);
			if (!string.IsNullOrEmpty(this.string_2))
			{
				stringBuilder.AppendFormat(":{0}", this.string_2);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000234 RID: 564 RVA: 0x000047B5 File Offset: 0x000029B5
	public virtual int GetHashCode()
	{
		if (string.IsNullOrEmpty(this.string_0))
		{
			return 0;
		}
		return this.string_0.GetHashCode() ^ this.int_0;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x000047D8 File Offset: 0x000029D8
	public bool Equals(GClass16 proxy)
	{
		return proxy != null && this.string_0 != null && (this.string_0.Equals(proxy.string_0, StringComparison.OrdinalIgnoreCase) && this.int_0 == proxy.int_0);
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00027144 File Offset: 0x00025344
	public virtual bool Equals(object obj)
	{
		GClass16 gclass = obj as GClass16;
		return gclass != null && this.Equals(gclass);
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00027164 File Offset: 0x00025364
	protected TcpClient method_0()
	{
		GClass16.Class16 @class = new GClass16.Class16();
		@class.tcpClient_0 = null;
		@class.tcpClient_0 = new TcpClient();
		@class.exception_0 = null;
		@class.manualResetEventSlim_0 = new ManualResetEventSlim();
		try
		{
			@class.tcpClient_0.BeginConnect(this.string_0, this.int_0, new AsyncCallback(@class.method_0), @class.tcpClient_0);
		}
		catch (Exception ex)
		{
			@class.tcpClient_0.Close();
			if (!(ex is SocketException) && !(ex is SecurityException))
			{
				throw;
			}
			throw this.method_2(Class2.String_42, ex);
		}
		if (!@class.manualResetEventSlim_0.Wait(this.int_1))
		{
			@class.tcpClient_0.Close();
			throw this.method_2(Class2.String_39, null);
		}
		if (@class.exception_0 != null)
		{
			@class.tcpClient_0.Close();
			if (@class.exception_0 is SocketException)
			{
				throw this.method_2(Class2.String_42, @class.exception_0);
			}
			throw @class.exception_0;
		}
		else
		{
			if (!@class.tcpClient_0.Connected)
			{
				@class.tcpClient_0.Close();
				throw this.method_2(Class2.String_42, null);
			}
			@class.tcpClient_0.SendTimeout = this.int_2;
			@class.tcpClient_0.ReceiveTimeout = this.int_2;
			return @class.tcpClient_0;
		}
	}

	// Token: 0x06000238 RID: 568 RVA: 0x000272B4 File Offset: 0x000254B4
	protected void method_1()
	{
		if (string.IsNullOrEmpty(this.string_0))
		{
			throw new InvalidOperationException(Class2.String_33);
		}
		if (!Class13.smethod_5(this.int_0))
		{
			throw new InvalidOperationException(Class2.String_35);
		}
		if (this.string_1 != null && this.string_1.Length > 255)
		{
			throw new InvalidOperationException(Class2.String_36);
		}
		if (this.string_2 != null && this.string_2.Length > 255)
		{
			throw new InvalidOperationException(Class2.String_34);
		}
	}

	// Token: 0x06000239 RID: 569 RVA: 0x0000480C File Offset: 0x00002A0C
	protected GException2 method_2(string string_3, Exception exception_0 = null)
	{
		return new GException2(string.Format(string_3, this.ToString()), this, exception_0);
	}

	// Token: 0x04000131 RID: 305
	protected GEnum4 genum4_0;

	// Token: 0x04000132 RID: 306
	protected string string_0;

	// Token: 0x04000133 RID: 307
	protected int int_0 = 1;

	// Token: 0x04000134 RID: 308
	protected string string_1;

	// Token: 0x04000135 RID: 309
	protected string string_2;

	// Token: 0x04000136 RID: 310
	protected int int_1 = 60000;

	// Token: 0x04000137 RID: 311
	protected int int_2 = 60000;

	// Token: 0x02000030 RID: 48
	[CompilerGenerated]
	private sealed class Class16
	{
		// Token: 0x0600023B RID: 571 RVA: 0x0002733C File Offset: 0x0002553C
		internal void method_0(IAsyncResult iasyncResult_0)
		{
			if (this.tcpClient_0.Client != null)
			{
				try
				{
					this.tcpClient_0.EndConnect(iasyncResult_0);
				}
				catch (Exception ex)
				{
					this.exception_0 = ex;
				}
				this.manualResetEventSlim_0.Set();
			}
		}

		// Token: 0x04000138 RID: 312
		public TcpClient tcpClient_0;

		// Token: 0x04000139 RID: 313
		public Exception exception_0;

		// Token: 0x0400013A RID: 314
		public ManualResetEventSlim manualResetEventSlim_0;
	}
}
