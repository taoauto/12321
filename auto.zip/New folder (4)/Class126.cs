﻿using System;
using System.Threading;

// Token: 0x02000141 RID: 321
internal class Class126
{
	// Token: 0x06000FAD RID: 4013 RVA: 0x0000CFD0 File Offset: 0x0000B1D0
	public Class126()
	{
		this.readerWriterLock_0 = new ReaderWriterLock();
		this.idisposable_0 = new Class126.Class129(this);
		this.idisposable_1 = new Class126.Class128(this);
	}

	// Token: 0x06000FAE RID: 4014 RVA: 0x0000CFFB File Offset: 0x0000B1FB
	public IDisposable method_0()
	{
		this.readerWriterLock_0.AcquireReaderLock(-1);
		return this.idisposable_1;
	}

	// Token: 0x06000FAF RID: 4015 RVA: 0x0000D00F File Offset: 0x0000B20F
	public IDisposable method_1()
	{
		this.readerWriterLock_0.AcquireWriterLock(-1);
		return this.idisposable_0;
	}

	// Token: 0x04000817 RID: 2071
	private ReaderWriterLock readerWriterLock_0;

	// Token: 0x04000818 RID: 2072
	private IDisposable idisposable_0;

	// Token: 0x04000819 RID: 2073
	private IDisposable idisposable_1;

	// Token: 0x02000142 RID: 322
	private class Class127
	{
		// Token: 0x06000FB0 RID: 4016 RVA: 0x0000D023 File Offset: 0x0000B223
		public Class127(Class126 class126_1)
		{
			this.class126_0 = class126_1;
		}

		// Token: 0x0400081A RID: 2074
		protected Class126 class126_0;
	}

	// Token: 0x02000143 RID: 323
	private class Class128 : Class126.Class127, IDisposable
	{
		// Token: 0x06000FB1 RID: 4017 RVA: 0x0000D032 File Offset: 0x0000B232
		public Class128(Class126 class126_1) : base(class126_1)
		{
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x0000D03B File Offset: 0x0000B23B
		public void Dispose()
		{
			this.class126_0.readerWriterLock_0.ReleaseReaderLock();
		}
	}

	// Token: 0x02000144 RID: 324
	private class Class129 : Class126.Class127, IDisposable
	{
		// Token: 0x06000FB3 RID: 4019 RVA: 0x0000D032 File Offset: 0x0000B232
		public Class129(Class126 class126_1) : base(class126_1)
		{
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x0000D04D File Offset: 0x0000B24D
		public void Dispose()
		{
			this.class126_0.readerWriterLock_0.ReleaseWriterLock();
		}
	}
}
